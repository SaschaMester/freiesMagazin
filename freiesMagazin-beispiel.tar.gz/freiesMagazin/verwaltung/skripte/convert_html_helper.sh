#!/bin/bash

if [ $# -lt 2 -o $# -gt 2 ]
then
    echo "Fehler: Skript erwartet genau zwei Argumente!"
    echo "Syntax:   $0 MONAT JAHR"
    echo "Beispiel: $0 05 2009"
    exit 1
fi

MONAT=$1
JAHR=$2

echo "Konvertiere freiesMagazin $MONAT/$JAHR in HTML ..."

# Directory speichern
CWD=`pwd`
TMPDIR="/tmp/fM-$JAHR-$MONAT"

# HTML-Version einrichten
echo "Kopiere notwendige Daten nach $TMPDIR ..."
rm -rf "$TMPDIR" || exit 1
mkdir -p "$TMPDIR" || exit 1
cp -r . "$TMPDIR" || exit 1

# Loesche alle .svn-Ordner wegen korrekter Groesse
# find "$TMPDIR" -name ".svn" -exec rm -rf {} \;

# Hinweis: tth sollte extern kompiliert worden sein!

# tth-Konverter kopieren
cp tth "$TMPDIR" || exit 1

# ins Verzeichnis wechseln
cd "$TMPDIR" || exit 1

# Boxen in Tex-Dateien ersetzen
echo "Generiere TeX-Dateien für HTML-Version ..."
TEXFILES=`find . -name "*.tex"`
for TEX in $TEXFILES
do
    cat "$TEX" \
        | sed 's/""//g' \
        | sed 's/^\\begin{ListingUmg}.*/\n\[LISTINGUMG\]\\begin{verbatim}/g' \
        | sed 's/\\end{ListingUmg}/\\end{verbatim}\[\/LISTINGUMG\]\n\n/g' \
        | sed 's/^\\begin{BefehlUmg}.*/\n\[BEFEHLUMG\]\\begin{verbatim}/g' \
        | sed 's/\\end{BefehlUmg}/\\end{verbatim}\[\/BEFEHLUMG\]\n\n/g' \
        | ruby ./includelisting_to_verbatim.rb \
        > "$TEX.1"
    mv -f "$TEX.1" "$TEX"
done

# Dummerweise müssen die "" vor TTH entfernt werden, da der sonst versucht
# daraus irgendetwas sinnvolles zu machen. Ich hoffe, dass zwei "" im Text
# normalerweise nicht vorkommen.

# Kommentarlink extrahieren
KOMMENTARLINK=$(egrep "SetKommentarLink" "$MONAT-$JAHR.tex" | sed 's/\\SetKommentarLink{\([^"]*\)}/\1/' | sed 's/\\#/#/' | sed 's/\//\\\//g' )

###################################################################

# HTML-Version erstellen
echo "Erstelle HTML-Version $MONAT-$JAHR-mobil.tex ..."
cat "$MONAT-$JAHR.tex" \
    | sed 's:^\\input{Static/befehle}:\\input{Static/befehle-mobil}:g' \
    | sed 's:^\\input{Static/layout}.*::g' \
    | sed 's:^\\input{Static/pakete}.*::g' \
    > "$MONAT-$JAHR-mobil.tex"

# konvertieren
echo "Konvertiere HTML-Version $MONAT-$JAHR-mobil.tex ..."
./tth -w2 -u=UTF8 "$MONAT-$JAHR-mobil.tex" || exit 1

# erste Version: ohne Bilder
#echo "Erstelle HTML-Version freiesMagazin-$JAHR-$MONAT.html ..."
./convert_html_post.tcl "$MONAT-$JAHR-mobil.html" $MONAT $JAHR ignoreimages \
    | sed ':a;N;$!ba;s/<br \/>\n<br \/>\n<\/div>/<\/div>/g' \
    | sed ':a;N;$!ba;s/<div class="command">\n/<div class="command">/g' \
    | sed ':a;N;$!ba;s/<div class="listing">\n/<div class="listing">/g' \
    | sed ':a;N;$!ba;s/<div class="p"><!----><\/div>\n<\/li>/<\/li>/g' \
    | sed ':a;N;$!ba;s/\n<\/li>/<\/li>/g' \
    | sed ':a;N;$!ba;s/\n<\/li>/<\/li>/g' \
    | sed ':a;N;$!ba;s/\n\n<li>/\n<li>/g' \
    | sed "s/\\\\KommentarLinkInternal/$KOMMENTARLINK/g" \
    > "freiesMagazin-$JAHR-$MONAT-temp.html"

#    | ruby -e 'file=""; while line = gets; file << line; end; puts file.gsub(/\n\n<\/pre>/, "\n</pre>")' \

# set correct comment links
./convert_html_kommentarlinks.tcl "freiesMagazin-$JAHR-$MONAT-temp.html" > "freiesMagazin-$JAHR-$MONAT.html"

###################################################################

# Bilder einkommentieren
echo "Kommentiere Bilder in befehle-mobil.tex ein ..."
cat Static/befehle-mobil.tex \
    | sed 's/^% \\includegraphics{Bilder\/#2}/\\includegraphics{Bilder\/#2}/g' \
    | sed 's/^\\newcommand{\\HTMLwithImages}\[1\]{}/\\newcommand{\\HTMLwithImages}[1]{#1}/g' \
    | sed 's/^\\newcommand{\\HTMLwithoutImages}\[1\]{#1}/\\newcommand{\\HTMLwithoutImages}[1]{}/g' \
    > Static/befehle-mobil1.tex
rm -f Static/befehle-mobil.tex || exit 1
mv Static/befehle-mobil1.tex Static/befehle-mobil.tex || exit 1

# neu konvertieren
echo "Konvertiere HTML-Version $MONAT-$JAHR-mobil.tex ..."
./tth -w2 -u=UTF8 "$MONAT-$JAHR-mobil.tex" || exit 1

# zweite Version: mit Bildern
echo "Erstelle HTML-Version freiesMagazin-$JAHR-$MONAT-bilder.html ..."
./convert_html_post.tcl "$MONAT-$JAHR-mobil.html" $MONAT $JAHR \
    | sed ':a;N;$!ba;s/<br \/>\n<br \/>\n<\/div>/<\/div>/g' \
    | sed ':a;N;$!ba;s/<div class="command">\n/<div class="command">/g' \
    | sed ':a;N;$!ba;s/<div class="listing">\n/<div class="listing">/g' \
    | sed ':a;N;$!ba;s/<div class="p"><!----><\/div>\n<\/li>/<\/li>/g' \
    | sed ':a;N;$!ba;s/\n<\/li>/<\/li>/g' \
    | sed ':a;N;$!ba;s/\n<\/li>/<\/li>/g' \
    | sed ':a;N;$!ba;s/\n\n<li>/\n<li>/g' \
    | sed "s/\\\\KommentarLinkInternal/$KOMMENTARLINK/g" \
    > "freiesMagazin-$JAHR-$MONAT-bilder-temp.html"

# set correct comment links
./convert_html_kommentarlinks.tcl "freiesMagazin-$JAHR-$MONAT-bilder-temp.html" > "freiesMagazin-$JAHR-$MONAT-bilder.html"

# Zurueck ins eigentlich Verzeichnis wechseln
cd "$CWD" || exit 1

# Mobilversionen holen
echo "Hole HTML-Versionen ..."
cp "$TMPDIR/freiesMagazin-$JAHR-$MONAT.html" . || exit 1
cp "$TMPDIR/freiesMagazin-$JAHR-$MONAT-bilder.html" . || exit 1

###################################################################

# kopiere Bilderordern und lösche darin enthaltenes .svn
if [ -d "Bilder" ]
then
    echo "Erstelle Bilderordner $JAHR-$MONAT-bilder ..."
    rm -rf "$JAHR-$MONAT-bilder" || exit 1
    mkdir -p "$JAHR-$MONAT-bilder" || exit 1
    ls "Bilder" | xargs -i cp "Bilder/{}" "$JAHR-$MONAT-bilder" || exit 1
    # cp -r Bilder/* "$JAHR-$MONAT-bilder" || true
    find "$JAHR-$MONAT-bilder" -name ".svn" -type d -exec rm -rf {} \; # -print

    # setze Bildrechte korrekt (gab in der Vergangenheit Probleme)
    echo "Setze Rechte in $JAHR-$MONAT-bilder ..."
    chmod 755 "$JAHR-$MONAT-bilder" || exit 1
    find "$JAHR-$MONAT-bilder" -type d -exec chmod 755 {} \; # -print
    find "$JAHR-$MONAT-bilder" -type f -exec chmod 644 {} \; # -print
fi

if [ -d "Listings" ]
then
    echo "Erstelle Listingsordner $JAHR-$MONAT-listings ..."
    rm -rf "$JAHR-$MONAT-listings" || exit 1
    mkdir -p "$JAHR-$MONAT-listings" || exit 1
    ls "Listings" | xargs -i cp "Listings/{}" "$JAHR-$MONAT-listings" || exit 1
    # cp -r Listings/* "$JAHR-$MONAT-listings" || exit 1
    find "$JAHR-$MONAT-listings" -name ".svn" -type d -exec rm -rf {} \; # -print

    echo "Setze Rechte in $JAHR-$MONAT-listings ..."
    chmod 755 "$JAHR-$MONAT-listings" || exit 1
    find "$JAHR-$MONAT-listings" -type d -exec chmod 755 {} \; #-print
    find "$JAHR-$MONAT-listings" -type f -exec chmod 644 {} \; #-print
fi

###################################################################

# Aufräumen
echo "Räume auf und mache dabei einen Kopfstand ..."
#rm -rf $TMPDIR || exit 1

echo "Konvertierung erfolgreich abgeschlossen!"

exit 0


