#!/bin/bash

###################################################

# Bestimmen, wo freiesMagazin-Inhalt liegt
FM_SVNPATH_LOCAL="$HOME/freiesMagazin"

if [ ! -z "$FM_SVNPATH" ]
then
    FM_SVNPATH_LOCAL="$FM_SVNPATH"
fi

# Pruefen, ob die Verzeichnisse existieren
if [ ! -d "$FM_SVNPATH_LOCAL" ]
then
    echo "Verzeichnis '$FM_SVNPATH_LOCAL' existiert nicht. Pruefe FM_SVNPATH!"
    exit 1
fi

###################################################

if [ $# -lt 2 -o $# -gt 2 ]
then
    echo "Fehler: Skript erwartet genau zwei Argumente!"
    echo "Syntax:   $0 MONAT JAHR"
    echo "Beispiel: $0 05 2009"
    exit 1
fi

MONAT="$1"
JAHR="$2"

# Das Skript muss immer aus dem Verzeichnis "skripte" heraus gestartet werden!

# Kompilieren von tth
echo "Kompiliere tth ..."
cd ../programme/tth || exit 1
gcc tth.c -o tth || exit 1
cd ../../skripte || exit 1

# Kopieren der Dateien in den Monatsordner
echo "Kopiere notwendige Dateien ..."
cp ../programme/tth/tth "$FM_SVNPATH_LOCAL/$JAHR-$MONAT" || exit 1
cp convert_html_helper.sh "$FM_SVNPATH_LOCAL/$JAHR-$MONAT" || exit 1
cp includelisting_to_verbatim.rb "$FM_SVNPATH_LOCAL/$JAHR-$MONAT" || exit 1
cp convert_html_kommentarlinks.tcl "$FM_SVNPATH_LOCAL/$JAHR-$MONAT" || exit 1
cp convert_html_post.tcl "$FM_SVNPATH_LOCAL/$JAHR-$MONAT" || exit 1
cp fm_mobil_2013_08.css "$FM_SVNPATH_LOCAL/$JAHR-$MONAT" || exit 1

# generiere HTML-Dateien und Bilderordner
cd "$FM_SVNPATH_LOCAL/$JAHR-$MONAT" || exit 1
bash ./convert_html_helper.sh "$MONAT" "$JAHR" || exit 1
cd "$FM_SVNPATH_LOCAL/verwaltung/skripte" || exit 1

# Aufräumen
echo "Räume auf und teile 1 durch 0 ..."
rm "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/tth" || exit 1
rm "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/convert_html_helper.sh" || exit 1
rm "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/includelisting_to_verbatim.rb" || exit 1
rm "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/convert_html_kommentarlinks.tcl" || exit 1
rm "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/convert_html_post.tcl" || exit 1

exit 0


