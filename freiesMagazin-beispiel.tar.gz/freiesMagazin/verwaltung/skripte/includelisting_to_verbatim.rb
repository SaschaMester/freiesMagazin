#!/usr/bin/env ruby
def sanitize_caption(caption)
  sane_caption = ""
  rest = ""
  brace_balance = 0
  rest_mode = false

  caption.split(//u).each do |char|
    if char == "{"
      brace_balance += 1
    elsif char == "}"
      brace_balance -= 1
      if brace_balance < 0
        if !rest_mode
          rest_mode = true
          next
        else
          rest_mode = true
        end
      end
    end
    (rest_mode ? rest : sane_caption) << char
  end

  return sane_caption, rest
end

file = ""
while line = gets
  file << line
end
require 'pp'
puts file.gsub(/(^[^%\n]*)\\IncludeListing(\[.*?\])?\{(.+?)\}\{(.+\})/) { |m|
  string = $1
  string << "\n[LISTINGUMG]\\begin{verbatim}\n"
  filename = $3
  caption, rest  = sanitize_caption($4)

  string << File.read("Listings/#{filename}")
  string << "\\end{verbatim}[/LISTINGUMG]\n\n"
  string << "\\textit{Listing: \\href{Listings/#{filename}}{#{caption}}}\n\n#{rest}"
}
