#!/bin/bash

###################################################

# Bestimmen, wo freiesMagazin-Inhalt liegt
FM_SVNPATH_LOCAL="$HOME/freiesMagazin"

if [ ! -z "$FM_SVNPATH" ]
then
    FM_SVNPATH_LOCAL="$FM_SVNPATH"
fi

# Pruefen, ob die Verzeichnisse existieren
if [ ! -d "$FM_SVNPATH_LOCAL" ]
then
    echo "Verzeichnis '$FM_SVNPATH_LOCAL' existiert nicht. Pruefe FM_SVNPATH!"
    exit 1
fi

###################################################

if [ $# -lt 2 -o $# -gt 2 ]
then
    echo "Fehler: Skript erwartet genau zwei Argumente!"
    echo "Syntax:   $0 MONAT JAHR"
    echo "Beispiel: $0 05 2009"
    exit 1
fi

MONAT="$1"
JAHR="$2"
TAG=`date +"%d"` || exit 1
TMP="/tmp"

# Nachdem Sigil das EPUB erstellt hat, fuegen wir fuer die Sony-Reader
# noch eine metadata.xml-Datei hinzu. Wir muessen nur die Werte
# TAG, MONAT und JAHR in der Vorlage ersetzen.
echo "Sony-Metadaten erstellen ..."
mkdir -p "$TMP/META-INF" || exit 1
cat "metadata.xml" | sed "s/JAHR/$JAHR/g" | sed "s/MONAT/$MONAT/g" | sed "s/TAG/$TAG/g" > "$TMP/META-INF/metadata.xml" || exit 1

# Das Skript muss immer aus dem Verzeichnis "skripte" heraus gestartet werden!

# Das Skript erwartet, dass Sigil im Pfad des Benutzers verfügbar ist.
# Jeder hat selbst dafür Sorge zu tragen, dass das bekannt ist, weil
# ich keine Ahnung habe, wer sich Sigil wo installiert.

# Daneben muss vor der Ausführung convert_html.sh erfolgreich gelaufen
# sein, da man die HTML-Version für die Erstellung des EPUBs nimmt.

# Erzeuge EPUB aus HTML-Dateien
# Wir entfernen zuerst den Link auf die andere Version und
# konvertieren dann mit sigil
echo "Konvertiere nach EPUB ..."

# Fuer das EBUP ist die tt-Schriftgröße von 1.245 zu groß, weswegen wir diese
# hier extra verkleinern.
cat "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/fm_mobil_2013_08.css" \
    | sed 's/font-size: 1.235em;/font-size: 1.0em;/' \
    | sed 's/font-size: 1.245em;/font-size: 1.1em;/' \
    > "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/fm_epub_2013_08.css"

# Version ohne Bilder
( \
  sed "s/<font size=\"5\"><a href=\"freiesMagazin-$JAHR-$MONAT.*<\/a><\/font><hr .*\/>//" "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/freiesMagazin-$JAHR-$MONAT.html" \
| sed "s/$JAHR-$MONAT-listings/http:\/\/www.freiesmagazin.de\/mobil\/$JAHR-$MONAT-listings/g" \
| sed 's/<img src="http:\/\/www.freiesmagazin.de\/system\/files\/redaktionmail.png" .* align="top" \/>/<a href="mailto:redaktion@freiesmagazin.de">redaktion@freiesmagazin.de<\/a>/g' \
| sed "s/font-size: 1.25em;/font-size: 1em;/g" \
| sed "s/<a href=\"#fm_index\">Zum Index<\/a><br \/>//g" \
| sed "s/^.*<!-- CONTENT -->$//g" \
| sed "s/<div class=\"p\"><!----><\/div>/<div><!----><\/div>/g" \
| sed "s/^<font size=\"+2\">(ISSN 1867-7991)<\/font><br \/>$/<font size=\"+2\">(ISSN 1867-7991)<\/font><br \/>\n<hr class=\"sigilChapterBreak\" \/>/" \
| sed "s/^<font size=\"+4\"><b><font color=\"#595959\">freies<\/font><\/b><font color=\"#FF630A\">Magazin<\/font>&nbsp;<font color=\"#595959\"><b>\(.*\)<\/b><\/font><\/font><br \/>$/<font size=\"+4\"><b><font color=\"#595959\">freies<\/font><\/b><font color=\"#FF630A\">Magazin<\/font><br \/><font color=\"#595959\"><b>\1<\/b><\/font><\/font><br \/>/" \
| sed 's/fm_mobil_2013_08.css/fm_epub_2013_08.css/g' \
> "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/freiesMagazin-$JAHR-$MONAT-epub.html" ) || exit 1

sigil "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/freiesMagazin-$JAHR-$MONAT-epub.html" "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/freiesMagazin-$JAHR-$MONAT.epub" || exit 1
cd "$TMP" || exit 1
zip "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/freiesMagazin-$JAHR-$MONAT.epub" "META-INF/metadata.xml" || exit 1

# Also prüfen wir hiernach, ob das epub existiert
if [ ! -e "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/freiesMagazin-$JAHR-$MONAT.epub" ]
then
    exit 2
fi

# Version mit Bildern
( \
  sed "s/<font size=\"5\"><a href=\"freiesMagazin-$JAHR-$MONAT.*<\/a><\/font><hr .*\/>//" "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/freiesMagazin-$JAHR-$MONAT-bilder.html" \
| sed "s/$JAHR-$MONAT-listings/http:\/\/www.freiesmagazin.de\/mobil\/$JAHR-$MONAT-listings/g" \
| sed 's/<img src="http:\/\/www.freiesmagazin.de\/system\/files\/redaktionmail.png" .* align="top" \/>/<a href="mailto:redaktion@freiesmagazin.de">redaktion@freiesmagazin.de<\/a>/g' \
| sed "s/font-size: 1.25em;/font-size: 1em;/g" \
| sed "s/<a href=\"#fm_index\">Zum Index<\/a><br \/>//g" \
| sed "s/^.*<!-- CONTENT -->$//g" \
| sed "s/<div class=\"p\"><!----><\/div>/<div><!----><\/div>/g" \
| sed "s/^<font size=\"+2\">(ISSN 1867-7991)<\/font><br \/>$/<font size=\"+2\">(ISSN 1867-7991)<\/font><br \/>\n<hr class=\"sigilChapterBreak\" \/>/" \
| sed "s/^<font size=\"+4\"><b><font color=\"#595959\">freies<\/font><\/b><font color=\"#FF630A\">Magazin<\/font>&nbsp;<font color=\"#595959\"><b>\(.*\)<\/b><\/font><\/font><br \/>$/<font size=\"+4\"><b><font color=\"#595959\">freies<\/font><\/b><font color=\"#FF630A\">Magazin<\/font><br \/><font color=\"#595959\"><b>\1<\/b><\/font><\/font><br \/>/" \
| sed 's/fm_mobil_2013_08.css/fm_epub_2013_08.css/g' \
> "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/freiesMagazin-$JAHR-$MONAT-bilder-epub.html" ) || exit 1

sigil "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/freiesMagazin-$JAHR-$MONAT-bilder-epub.html" "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/freiesMagazin-$JAHR-$MONAT-bilder.epub" || exit 1
cd "$TMP" || exit 1
zip "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/freiesMagazin-$JAHR-$MONAT-bilder.epub" "META-INF/metadata.xml" || exit 1

if [ ! -e "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/freiesMagazin-$JAHR-$MONAT-bilder.epub" ]
then
    exit 2
fi

# Aufräumen
echo "Räume auf und freue mich auf Sonntag ..."
rm "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/freiesMagazin-$JAHR-$MONAT-epub.html"
rm "$FM_SVNPATH_LOCAL/$JAHR-$MONAT/freiesMagazin-$JAHR-$MONAT-bilder-epub.html"

exit 0


