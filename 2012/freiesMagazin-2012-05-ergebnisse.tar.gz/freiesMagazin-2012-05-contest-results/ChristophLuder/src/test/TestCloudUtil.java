package test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;
import java.util.logging.Logger;
import java.util.regex.Pattern;

import org.junit.Test;

import ch.coredump.tagcloud.util.CloudUtil;

public class TestCloudUtil {
	private Logger log = Logger.getLogger(TestCloudUtil.class.getName());

	@Test
	public void testGetValue() {
		int percent = 90;
		double min = 0;
		double max = 30;
		double result = CloudUtil.getValue(min, max, percent);
		assert (result == 27.0);
	}

	@Test
	public void testCreateRegexPattern() {
		Collection<Character> chars = new ArrayList<Character>();
		chars.add(',');
		chars.add('.');
		chars.add(' ');
		chars.add('+');
		chars.add('.');
		chars.add('*');
		chars.add('-');
		chars.add('/');
		chars.add('\\');
		chars.add('_');
		chars.add('=');
		chars.add('"');
		String regex = CloudUtil.createRegexPattern(chars);

		log.info("regex: " + regex);
		Pattern pattern = Pattern.compile(regex);

		String test = "aa bb.cc,dd_ee+ff-gg*hh/ii\\jj=kk\"ll";
		log.info("test:" + test);
		Scanner scanner = new Scanner(test);
		scanner.useDelimiter(pattern);

		{
			String next = scanner.next();
			log.info("next:" + next);
			assertEquals("aa", next);
		}
		{
			String next = scanner.next();
			log.info("next:" + next);
			assertEquals("bb", next);
		}
		{
			String next = scanner.next();
			log.info("next:" + next);
			assertEquals("cc", next);
		}
		{
			String next = scanner.next();
			log.info("next:" + next);
			assertEquals("dd", next);
		}
		{
			String next = scanner.next();
			log.info("next:" + next);
			assertEquals("ee", next);
		}
		{
			String next = scanner.next();
			log.info("next:" + next);
			assertEquals("ff", next);
		}
		{
			String next = scanner.next();
			log.info("next:" + next);
			assertEquals("gg", next);
		}
		{
			String next = scanner.next();
			log.info("next:" + next);
			assertEquals("hh", next);
		}
		{
			String next = scanner.next();
			log.info("next:" + next);
			assertEquals("ii", next);
		}
		{
			String next = scanner.next();
			log.info("next:" + next);
			assertEquals("jj", next);
		}
		{
			String next = scanner.next();
			log.info("next:" + next);
			assertEquals("kk", next);
		}
		{
			String next = scanner.next();
			log.info("next:" + next);
			assertEquals("ll", next);
		}
	}
}
