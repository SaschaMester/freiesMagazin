package ch.coredump.tagcloud;

import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.application.Application;
import javafx.stage.Stage;
import ch.coredump.tagcloud.data.DataProviderManager;
import ch.coredump.tagcloud.data.FileDataProvider;
import ch.coredump.tagcloud.data.appstate.AppStateManager;
import ch.coredump.tagcloud.data.appstate.AppStates;

/**
 * Entry Point.
 */
public class CloudGeneratorApp extends Application {
	@SuppressWarnings("unused")
	private static Logger log = Logger.getLogger(CloudGeneratorApp.class
			.toString());
	private AppStateManager manager = AppStateManager.getInstance();

	@Override
	public void init() throws Exception {
		DataProviderManager.getInstance().setDataProvider(
				new FileDataProvider());
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		manager.setStage(primaryStage);
		manager.switchTo(AppStates.INTRO);
		primaryStage.show();
	}

	/**
	 * Main Entry Point
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Logger.getLogger("").setLevel(Level.WARNING);
		log.info("starting CloudGeneratorApp");
		launch(args);
	}
}
