package ch.coredump.tagcloud.data.appstate;

import java.util.logging.Logger;

import javafx.scene.Scene;
import ch.coredump.tagcloud.data.appstate.iface.IAppState;

/**
 * Abstaract AppState class.<br>
 * AppState implementations use this as BaseClass.
 * 
 */
public abstract class AbstractAppState implements IAppState {
	protected Logger log = Logger.getLogger(AbstractAppState.class.getName());

	protected AppStateManager manager;
	protected Scene scene;

	public AbstractAppState(AppStateManager manager) {
		this.manager = manager;
		scene = createScene();
	}

	/**
	 * internal activate Method called by the AppStateManager
	 */
	protected void doActivate() {
		log.finest("activating " + this.getClass().getSimpleName());

		// call interface method which can be implemented by the user
		activate();
	}

	/**
	 * internal exit Method called by the AppStateManager
	 */
	protected void doExit() {
		log.finest("exiting " + this.getClass().getSimpleName());

		// call interface method which can be implemented by the user
		exit();
	}

	public Scene getScene() {
		return scene;
	}
}
