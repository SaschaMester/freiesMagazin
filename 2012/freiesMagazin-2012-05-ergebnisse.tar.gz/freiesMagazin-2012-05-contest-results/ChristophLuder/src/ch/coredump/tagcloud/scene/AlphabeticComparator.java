package ch.coredump.tagcloud.scene;

import java.util.Comparator;

import ch.coredump.tagcloud.data.CloudWord;

/**
 * Compares the strings of two CloudWords.<br>
 * Used to sort a List of CloudWords alphabetically.
 */
public class AlphabeticComparator implements Comparator<CloudWord> {
	@Override
	public int compare(CloudWord arg0, CloudWord arg1) {
		return arg0.getWord().compareTo(arg1.getWord());
	}
}
