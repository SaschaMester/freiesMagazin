package ch.coredump.tagcloud.data.appstate;

import javafx.event.EventHandler;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.util.Callback;

public class SepListCellFactory implements
		Callback<ListView<Character>, ListCell<Character>> {

	@Override
	public ListCell<Character> call(ListView<Character> param) {
		return new SepCharacterCell();
	}

}

class SepCharacterCell extends ListCell<Character> {
	private TextField textField;

	public SepCharacterCell() {
		super();
		setEditable(true);
	}

	@Override
	public void startEdit() {
		super.startEdit();

		if (textField == null) {
			createTextField();
		}
		setGraphic(textField);
		setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
		textField.selectAll();
	}

	@Override
	public void cancelEdit() {
		super.cancelEdit();

		setText(getItem().toString());
		setContentDisplay(ContentDisplay.TEXT_ONLY);
	}

	private void createTextField() {
		textField = new TextField(getString());
		textField.setMinWidth(this.getWidth() - this.getGraphicTextGap() * 2);

		textField.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent t) {
				Character c = null;
				switch (t.getCode()) {
				case ESCAPE:
					cancelEdit();
					break;
				case ENTER:
					if (textField.getLength() < 1) {
						c = null;
					} else {
						c = textField.getText().charAt(0);
					}
					commitEdit(c);
					textField.setText(c.toString());

					break;
				default:
					break;
				}
			}
		});

	}

	private String getString() {
		return getItem() == null ? "" : getItem().toString();
	}

	@Override
	protected void updateItem(Character item, boolean empty) {
		super.updateItem(item, empty);

		setText(item == null ? "" : item.toString());
	}

}