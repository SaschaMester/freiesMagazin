package ch.coredump.tagcloud.data.appstate.iface;

import javafx.scene.Scene;

public interface IAppState {

	/**
	 * this method will be called after the State has been created.
	 */
	public void init();

	/**
	 * Scene of this AppState.<br>
	 * When this appState is activates, this Scene will be set on the Primary
	 * stage.
	 * 
	 * @return Scene
	 */
	public Scene createScene();

	/**
	 * Called when a AppState is activated
	 */
	public void activate();

	/**
	 * Called when a AppState exits
	 */
	public void exit();
}
