package ch.coredump.tagcloud;

public interface CloudConsts {
	public static final int SCREEN_X = 800;
	public static final int SCREEN_Y = 600;
	public static final int CLOUD_MAX_X = 150;
	public static final int CLOUD_MAX_Y = 50;

	public static final int FONT_MIN = 5;
	public static final int FONT_MAX = 100;

	public static final int DEF_FONT_SIZE = 18;
}
