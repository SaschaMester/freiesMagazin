package ch.coredump.tagcloud.data.appstate;

public enum AppStates {
	INTRO, MENU, MAIN, EXIT
}
