package ch.coredump.tagcloud;

public enum CloudState {
	MENU, CLOUD_RESULT
}
