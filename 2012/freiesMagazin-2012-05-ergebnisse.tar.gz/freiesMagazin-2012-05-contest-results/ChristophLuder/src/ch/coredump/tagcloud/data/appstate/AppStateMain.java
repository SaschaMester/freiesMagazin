package ch.coredump.tagcloud.data.appstate;

import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import ch.coredump.tagcloud.CloudConsts;
import ch.coredump.tagcloud.CloudSettings;
import ch.coredump.tagcloud.data.DataProviderManager;
import ch.coredump.tagcloud.data.FileDataProvider;
import ch.coredump.tagcloud.scene.CloudCreator;

/**
 * Main AppState which displays the Tag Cloud.<br>
 * 
 */
public class AppStateMain extends AbstractAppState {
	private CloudCreator cloudCreator;
	private Group root;

	public AppStateMain(AppStateManager manager) {
		super(manager);
	}

	@Override
	public Scene createScene() {
		root = new Group();

		Scene scene = new Scene(root, CloudConsts.SCREEN_X,
				CloudConsts.SCREEN_Y, true);
		scene.setFill(Color.WHITE);

		return scene;
	}

	/**
	 * creates the UI controls.
	 */
	private void createControls() {
		VBox pane = new VBox(10);
		pane.setFillWidth(true);
		root.getChildren().add(pane);
		pane.setTranslateX(10);
		pane.setTranslateY(10);
	}

	/**
	 * creates the Tag Clouds based on the data provided.
	 */
	@Override
	public void activate() {
		FileDataProvider data = DataProviderManager.getInstance()
				.getDataProvider();

		createControls();

		cloudCreator.createCloud(root, data.getWords(), CloudSettings
				.instance().getDisplayType());

		scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
			public void handle(KeyEvent event) {
				manager.switchTo(AppStates.MENU);
			}
		});
	}

	@Override
	public void exit() {
		// remove all children
		root.getChildren().setAll();
		scene.setOnKeyPressed(null);
		scene.setOnMouseDragged(null);
	}

	@Override
	public void init() {
		cloudCreator = new CloudCreator();
		// scene.setOnMouseDragged(new CloudMouseEvent(scene));
		// scene.setOnMousePressed(new CloudMouseEvent(scene));
	}
}
