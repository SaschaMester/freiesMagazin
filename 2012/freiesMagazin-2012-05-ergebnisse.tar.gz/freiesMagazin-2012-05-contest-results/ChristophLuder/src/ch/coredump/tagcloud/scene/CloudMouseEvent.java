package ch.coredump.tagcloud.scene;

import java.util.logging.Logger;

import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;

public class CloudMouseEvent implements EventHandler<MouseEvent> {
	private Logger log = Logger.getLogger(CloudMouseEvent.class.toString());

	private double lastX = 0;
	private double lastY = 0;
	private Scene scene;

	public CloudMouseEvent(Scene scene) {
		this.scene = scene;
	}

	@Override
	public void handle(MouseEvent event) {
		log.info("mouse drag:" + event);

		if (event.getEventType().getName()
				.equals(MouseEvent.MOUSE_PRESSED.getName())) {
			lastY = event.getY();
			lastX = event.getX();
			return;
		}

		switch (event.getButton()) {
		case MIDDLE:
			break;
		case PRIMARY:
			handleLeftButtonDrag(event);
			break;
		case SECONDARY:
			handleRightButtonDrag(event);
			break;
		default:
			break;
		}
	}

	private void handleRightButtonDrag(MouseEvent event) {

	}

	private void handleLeftButtonDrag(MouseEvent event) {
		log.info("screenX: " + event.getSceneX());
		log.info("X: " + event.getX());

		double diffX = event.getX() - lastX;
		double diffY = event.getY() - lastY;

		scene.getRoot().setTranslateX(scene.getRoot().getTranslateX() - diffX);
		scene.getRoot().setTranslateY(scene.getRoot().getTranslateY() - diffY);

		log.info("last x:" + lastX + "  x: " + event.getX());
		lastY = event.getY();
		lastX = event.getX();
	}
}
