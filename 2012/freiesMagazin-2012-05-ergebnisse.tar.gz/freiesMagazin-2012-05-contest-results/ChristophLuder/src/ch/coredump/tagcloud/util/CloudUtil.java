package ch.coredump.tagcloud.util;

import java.util.Collection;
import java.util.logging.Logger;

public class CloudUtil {
	private static Logger log = Logger.getLogger(CloudUtil.class.getName());

	/**
	 * 
	 * @param min
	 *            min value
	 * @param max
	 *            max value
	 * @param percent
	 *            percent of max value
	 * @return
	 */
	public static double getValue(double min, double max, int percent) {
		double diff = max - min;
		double value = diff * (percent / 100.0);

		double result = min + value;
		log.finer("min: " + min + " max: " + max + " percent: " + percent
				+ " result: " + result);
		return result;
	}

	public static String createRegexPattern(Collection<Character> chars) {
		if (chars == null || chars.isEmpty()) {
			return "";
		}
		StringBuilder builder = new StringBuilder("[");
		for (Character c : chars) {
			if (c.equals('\\')) {
				// special case backslash
				builder.append('\\');
			}
			builder.append(c);
		}
		builder.append("]");
		return builder.toString();
	}
}
