package ch.coredump.tagcloud.scene;

public enum DisplayType {
	RANDOM, ALPHA, WEIGHT
}
