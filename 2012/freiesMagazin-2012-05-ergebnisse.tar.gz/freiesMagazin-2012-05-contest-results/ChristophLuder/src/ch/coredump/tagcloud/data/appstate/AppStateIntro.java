package ch.coredump.tagcloud.data.appstate;

import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import ch.coredump.tagcloud.CloudConsts;

/**
 * Main Intro AppState.
 */
public class AppStateIntro extends AbstractAppState {
	private Group root;

	public AppStateIntro(AppStateManager manager) {
		super(manager);
	}

	@Override
	public Scene createScene() {
		root = new Group();

		Scene scene = new Scene(root, CloudConsts.SCREEN_X,
				CloudConsts.SCREEN_Y, true);
		scene.setFill(Color.WHITE);

		createUI();

		return scene;
	}

	/**
	 * creates the UI .
	 */
	private void createUI() {
		VBox vert = new VBox(5);
		root.getChildren().add(vert);

		createText(vert, "Tag Cloud Generator", 40);
		createText(vert, "by Christoph Luder", 20);
		createText(vert, "(press any key)", 13);

		vert.setTranslateX(CloudConsts.SCREEN_X / 2
				- vert.getBoundsInLocal().getWidth() / 2);
		vert.setTranslateY(CloudConsts.SCREEN_Y / 2
				- vert.getBoundsInLocal().getHeight());
	}

	private Text createText(VBox vert, String text, int size) {
		Text t = new Text(text);
		t.setTextAlignment(TextAlignment.CENTER);
		t.setFill(Color.BLACK);
		t.setFont(Font.font("Arial", size));
		vert.getChildren().add(t);

		return t;
	}

	/**
	 * creates the Tag Clouds based on the data provided.
	 */
	@Override
	public void activate() {
		scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
			public void handle(KeyEvent event) {

				// any key advances to Menu state
				switch (event.getCode()) {
				case ENTER:
					break;
				case SPACE:
					break;
				default:
					break;
				}
				manager.switchTo(AppStates.MENU);
			}
		});
	}

	@Override
	public void exit() {
		scene.setOnKeyPressed(null);
	}

	@Override
	public void init() {
	}
}
