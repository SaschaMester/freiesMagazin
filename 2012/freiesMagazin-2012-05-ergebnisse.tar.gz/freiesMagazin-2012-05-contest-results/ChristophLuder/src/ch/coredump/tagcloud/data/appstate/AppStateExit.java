package ch.coredump.tagcloud.data.appstate;

import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.effect.Bloom;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import ch.coredump.tagcloud.CloudConsts;

/**
 * Screen which will be displayed when the Application exits.
 */
public class AppStateExit extends AbstractAppState {
	// root of the scene
	private Pane root;

	public AppStateExit(AppStateManager manager) {
		super(manager);
	}

	@Override
	public void init() {
		scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
			public void handle(KeyEvent event) {
				// any key ...
				manager.getStage().close();
			};
		});
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Scene createScene() {
		root = new Pane();
		Scene scene = new Scene(root, CloudConsts.SCREEN_X,
				CloudConsts.SCREEN_Y, true);
		scene.setFill(Color.WHITE);

		Text t = new Text("und tsch�ss ...");
		t.setX(CloudConsts.SCREEN_X / 2 - (t.getBoundsInLocal().getWidth()));
		t.setY(CloudConsts.SCREEN_Y / 2);
		t.setFill(Color.BLACK);
		t.setFont(Font.font("Arial", 30));

		Bloom bloom = new Bloom();
		bloom.setThreshold(0.5);
		t.setEffect(bloom);

		root.getChildren().add(t);

		return scene;
	}

	@Override
	public void activate() {

	}

	@Override
	public void exit() {

	}

}
