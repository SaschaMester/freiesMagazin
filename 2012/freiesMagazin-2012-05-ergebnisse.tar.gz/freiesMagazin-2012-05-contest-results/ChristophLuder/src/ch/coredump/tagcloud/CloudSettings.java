package ch.coredump.tagcloud;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.logging.Logger;

import ch.coredump.tagcloud.scene.DisplayType;

public class CloudSettings {
	private Logger log = Logger.getLogger(CloudSettings.class.getName());
	private static CloudSettings instance = null;

	private static final String CONFIG_PATH = "config/";
	private static final String SEPERATOR_FILE = "seperators";
	private static final String IGNORE_FILE = "ignore";

	// default values
	public static final int DEF_MAX_WORDS = 100;
	public static final Character[] DEF_SEPERATORS = { ',', '.', '\'', '"',
			'+', '-' };

	private int maxWordsOndisplay = DEF_MAX_WORDS;
	private Collection<Character> seperators = new ArrayList<Character>();
	private Collection<String> wordsToIgnore = new ArrayList<String>();
	private DisplayType displayType = DisplayType.RANDOM;
	private String fileExtension = "txt";
	private Integer minWordLength = 3;
	private Integer minFontSize;
	private Integer maxFontSize;

	private CloudSettings() {
		readSeperators();
		readIgnore();
	}

	private void readIgnore() {
		try {
			wordsToIgnore.clear();
			String filename = CONFIG_PATH + IGNORE_FILE;
			File file = new File(filename);
			if (file.exists() == false) {
				log.warning("could not find config file: " + filename);
				return;
			}

			BufferedInputStream stream = new BufferedInputStream(
					new FileInputStream(filename));
			InputStreamReader in = new InputStreamReader(stream);
			BufferedReader reader = new BufferedReader(in);

			while (reader.ready()) {
				String next = reader.readLine();
				if (next == null) {
					return;
				}
				wordsToIgnore.add(next);
			}
		} catch (IOException e) {
			e.printStackTrace();
			log.warning("oops thats not good .." + e.getMessage());
		}
	}

	private void readSeperators() {
		try {
			seperators.clear();
			String filename = CONFIG_PATH + SEPERATOR_FILE;
			File file = new File(filename);
			if (file.exists() == false) {
				log.warning("could not find config file: " + filename
						+ "using default seperators");
				seperators = Arrays.asList(DEF_SEPERATORS);
				return;
			}

			BufferedInputStream stream = new BufferedInputStream(
					new FileInputStream(filename));
			InputStreamReader in = new InputStreamReader(stream);
			BufferedReader reader = new BufferedReader(in);

			while (reader.ready()) {
				String next = reader.readLine();
				if (next == null) {
					return;
				}
				seperators.add(next.charAt(0));
			}
		} catch (IOException e) {
			e.printStackTrace();
			log.warning("oops thats not good .." + e.getMessage());
		}

		// add default separators
		seperators.add(' ');
		seperators.add('\n');
		seperators.add('\r');
	}

	public Collection<String> getWordsToIgnore() {
		return wordsToIgnore;
	}

	public static CloudSettings instance() {
		if (instance == null) {
			instance = new CloudSettings();
		}
		return instance;
	}

	public void setMaxWordsOndisplay(int maxWordsOndisplay) {
		this.maxWordsOndisplay = maxWordsOndisplay;
	}

	public int getMaxWordsOndisplay() {
		return maxWordsOndisplay;
	}

	public Collection<Character> getSeperators() {
		return seperators;
	}

	public void setSeperators(Collection<Character> seperators) {
		this.seperators = seperators;
	}

	public DisplayType getDisplayType() {
		return displayType;
	}

	public void setDisplayType(DisplayType displayType) {
		this.displayType = displayType;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public Integer getMinWordLength() {
		return minWordLength;
	}

	public void setMinWordLength(Integer minWordLength) {
		this.minWordLength = minWordLength;
	}

	public Integer getMinFontSize() {
		return minFontSize;
	}

	public void setMinFontSize(Integer minFontSize) {
		this.minFontSize = minFontSize;
	}

	public Integer getMaxFontSize() {
		return maxFontSize;
	}

	public void setMaxFontSize(Integer maxFontSize) {
		this.maxFontSize = maxFontSize;
	}
}
