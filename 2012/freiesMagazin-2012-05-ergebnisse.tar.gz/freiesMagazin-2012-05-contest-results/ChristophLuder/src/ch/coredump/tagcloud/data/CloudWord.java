package ch.coredump.tagcloud.data;

/**
 * DataModel representing one tag in the cloud.
 */
public class CloudWord implements Comparable<CloudWord> {
	/**
	 * the 'weight' of the word which is represented by a percentage between 1 -
	 * 100<br>
	 * The weight is calculated by
	 * {@link DataProviderManager#calculateWeight(java.util.Collection)}
	 */
	private int weigth;
	/**
	 * Number of times this word was found.
	 */
	private int count;
	/**
	 * the actual word
	 */
	private String word;

	public CloudWord(String word, int count) {
		this.count = count;
		this.word = word;
	}

	public CloudWord() {
	}

	public int getWeigth() {
		return weigth;
	}

	public void setWeigth(int weigth) {
		this.weigth = weigth;
	}

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	public int getCount() {
		return count;
	}

	@Override
	public int compareTo(CloudWord other) {
		return new Integer(count).compareTo(other.count);
	}
}
