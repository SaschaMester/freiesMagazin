package ch.coredump.tagcloud.data;

import java.util.Collection;
import java.util.Collections;
import java.util.logging.Logger;

public class DataProviderManager {
	private Logger log = Logger.getLogger(DataProviderManager.class.getName());

	private FileDataProvider dataProvider;

	public void setDataProvider(FileDataProvider dataProvider) {
		this.dataProvider = dataProvider;
	}

	public FileDataProvider getDataProvider() {
		return dataProvider;
	}

	public static DataProviderManager getInstance() {
		return DataProviderManagerinstance.INSTANCE;
	}

	/**
	 * calculates the 'weight' of words depending on how often the word has been
	 * found
	 * 
	 * @param words
	 *            collection to calculate
	 */
	public void calculateWeight(Collection<CloudWord> words) {
		log.finest("calculating weight");
		CloudWord max = Collections.max(words);
		log.finer("max count is " + max.getCount());

		for (CloudWord word : words) {
			word.setWeigth((int) Math.round(100.0 / max.getCount()
					* word.getCount()));
			log.finer("current count:" + word.getCount() + " weight: "
					+ word.getWeigth());
		}
	}

	private static class DataProviderManagerinstance {
		public static DataProviderManager INSTANCE = new DataProviderManager();
	}
}
