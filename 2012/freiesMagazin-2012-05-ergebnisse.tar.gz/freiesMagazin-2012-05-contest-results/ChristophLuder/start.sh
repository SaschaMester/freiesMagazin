#!/bin/bash

# freiesMagazin, LaTeX-Ausgaben 2011
# rekursive Suche *.tex, 117 Dateien, 3.8 MB
# Trenner:  ,._:/{}\<>()"[]=„“
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
cp config/seperators.fmtex config/seperators && ant run
# Zeitmessung mit Stoppuhr
# 4.77

# freiesMagazin, HTML-Ausgaben 2011
# Ordnerangabe, *.html, 12 Dateien, 2.9 MB
# Groß-/Kleinschreibung ignorieren
# Trenner:  <>=.,!?/":;[]()#&„“
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
cp config/seperators.fmhtml config/seperators && ant run
# Zeitmessung mit Stoppuhr
# 1.98

# Sigil-Code, C++
# rekursive Suche nach *.cpp und *.h, 189 Dateien, 1.3 MB
# Trenner:  #,+"*/()<>;:.&{}[]-
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
rm -rf /tmp/input && mkdir /tmp/input && find ../Testdaten/Cpp/Sigil/ -name "*.cpp"  -exec cp {} /tmp/input/. \; -o -name "*.h" -exec cp {} /tmp/input/. \; && find /tmp/input/ -type f -exec mv {} {}.cpp \:
cp config/seperators.sigil config/seperators && ant run
# Zeitmessung mit Stoppuhr
# 9.18

# Alice (englisch)
# *txt-Dateien in einem Ordner, 2 Dateien, 310 kb
# Groß-/Kleinschreibung ignorieren
# Trenner:  .,;:?!"-+*()'
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
rm -rf /tmp/input && mkdir /tmp/input && cp ../Testdaten/Text/Alice/* /tmp/input/.
cp config/seperators.alice config/seperators && ant run
# Zeitmessung mit Stoppuhr
# 0.9

# Mathetext (deutsch)
# eine Textdatei, 200 kb
# Trenner:  .,"„“‚‘:?!=()+*/–−[]{}
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
cp config/seperators.mathe config/seperators && ant run
# Zeitmessung mit Stoppuhr
# 0.85


