#!/bin/bash

# freiesMagazin, LaTeX-Ausgaben 2011
# rekursive Suche *.tex, 117 Dateien, 3.8 MB
# Trenner:  ,._:/{}\<>()"[]=„“
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
rm -rf /tmp/input && mkdir /tmp/input && find ../Testdaten/LaTeX/ -name "*.tex" -exec cp {} /tmp/input/. \; && find /tmp/input/ -name "*.tex" -exec mv {} {}.txt \;
time ( java wordCloud/WordCloud -s " ,._:/{}\<>()\"[]=„“" -l 3 -n 100 -d /tmp/input -o Output/fmtex.png )
# 7.261

# freiesMagazin, HTML-Ausgaben 2011
# Ordnerangabe, *.html, 12 Dateien, 2.9 MB
# Groß-/Kleinschreibung ignorieren
# Trenner:  <>=.,!?/":;[]()#&„“
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
rm -rf /tmp/input && mkdir /tmp/input && find ../Testdaten/HTML/ -name "*.html" -exec cp {} /tmp/input/. \; && find /tmp/input/ -name "*.html" -exec mv {} {}.txt \;
time ( java wordCloud/WordCloud -s " <>=.,\!?/\":;[]()#&„“" -l 3 -n 100 -d /tmp/input -o Output/fmhtml.png )
# 8.455

# Sigil-Code, C++
# rekursive Suche nach *.cpp und *.h, 189 Dateien, 1.3 MB
# Trenner:  
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
rm -rf /tmp/input && mkdir /tmp/input && find ../Testdaten/Cpp/Sigil/ -name "*.cpp"  -exec cp {} /tmp/input/. \; -o -name "*.h" -exec cp {} /tmp/input/. \; && find /tmp/input/ -name "*.cpp" -exec mv {} {}.txt \; -o -name "*.h" -exec mv {} {}.txt \;
time ( java wordCloud/WordCloud -s " ,+-#\"*/()<>;:.&{}[]" -l 3 -n 100 -d /tmp/input -o Output/sigil.png )
# 4.572

# Alice (englisch)
# *txt-Dateien in einem Ordner, 2 Dateien, 310 kb
# Groß-/Kleinschreibung ignorieren
# Trenner:  .,;:?!"-+*()'
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time java wordCloud/WordCloud -s " .,;:?\!\"-+*()'" -l 3 -n 100 -d ../Testdaten/Text/Alice/ -o Output/alice.png
# 2.620

# Mathetext (deutsch)
# eine Textdatei, 200 kb
# Trenner:  .,"„“‚‘:?!=()+*/–−[]{}
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
rm -rf /tmp/input && mkdir /tmp/input && cp ../Testdaten/Text/mathe.txt /tmp/input/.
time ( java wordCloud/WordCloud -s " .,\"„“‚‘:?\!=()+*/–−[]{}" -l 3 -n 100 -d /tmp/input -o Output/mathe.png )
# 2.786



