/*
 *  Copyright (C) 2012  Philipp Staudinger

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>. 
 */

package wordCloud;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

public class Window {
	
	private static final int WIDTH;
	private static final int HEIGHT;
    private static Frame windowO;
    private static WindowPanel contentPane;
    static Image image;
    private static int headerHeight = 24;
    private static Graphics g;
    
    static {
    	WIDTH = WordCloud.width;
    	HEIGHT = WordCloud.height;
		windowO = new Frame("WindowO");
		contentPane = new WindowPanel();
		windowO.add(contentPane);
		image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
		image.getGraphics().fillRect(0, 0, WIDTH, HEIGHT);
		windowO.setSize(WIDTH + 12, HEIGHT + headerHeight + 12);
		windowO.addWindowListener(new Window.WindowClosingAdapter());
		windowO.setVisible(true);
		g = image.getGraphics();
	}
    
    /* returns TextWidth */
    public static int getTextWidth(String text) {
        FontMetrics fm = g.getFontMetrics();
        return (int) Math.round(fm.getStringBounds(text, g).getWidth());
    }
  
    /* returns TextHeight */
    public static int getTextHeight() {
        FontMetrics fm = g.getFontMetrics();
        return fm.getHeight();
    }
  
    /* sets the TextSize */
    public static void setTextSize(int size, String font) {
    	g.setFont(new Font(font, Font.PLAIN, size));
    }

    /* draws a text centered */
    public static void drawTextCentered(String text, int x, int y, Color color) {
    	g.setColor(color);
    	g.drawString(text, x - getTextWidth(text)/2, y + getTextHeight()/2);
        contentPane.repaint();
    }

    private static class WindowClosingAdapter extends WindowAdapter {
        @Override
		public void windowClosing(WindowEvent event) {
            event.getWindow().setVisible(false);
            event.getWindow().dispose();
            System.exit(0);
        }
    }
    
    @SuppressWarnings("serial")
	private static class WindowPanel extends Component {
            @Override
			public void paint(Graphics g) {
                g.drawImage(image, 0, 0, null);
            }
    }
}
