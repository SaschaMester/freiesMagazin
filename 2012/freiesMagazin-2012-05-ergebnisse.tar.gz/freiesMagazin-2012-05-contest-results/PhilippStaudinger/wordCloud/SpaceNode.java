/*
 *  Copyright (C) 2012  Philipp Staudinger

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>. 
 */

package wordCloud;

public class SpaceNode {

	SpaceNode next;
	final int o, u, l, r;
	
	/* Constructor */
	public SpaceNode(int o, int u, int l, int r) {
		this.o = o;
		this.u = u;
		this.l = l;
		this.r = r;
		this.next = null;
	}	
	
	/* tests if two spaces are colliding */
	public Boolean collide(SpaceNode space) {
		Boolean collide = false;
		if(o<space.u && u>space.o && r>space.l && l<space.r) {
			collide = true;
		}
		return collide;
	}
}
