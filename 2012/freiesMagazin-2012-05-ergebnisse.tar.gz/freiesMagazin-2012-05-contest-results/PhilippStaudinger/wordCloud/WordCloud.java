/*
 *  Copyright (C) 2012  Philipp Staudinger

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>. 
 */

package wordCloud;

import java.io.*;
import java.awt.Color;
import java.awt.image.RenderedImage;

import javax.imageio.ImageIO;

public class WordCloud {

	static int width = 1300;
	static int height = 700;
	private String[] args=null;
	private File textDir = new File("./text");
	private String outDir = "./out/cloud.png";
	private String ignoreDir = "./lists/ignore.txt";
	private String compositeDir = "./lists/composite.txt";
	private String ignoreDir2 = "";
	private String compositeDir2 = "";
	private String font = "Arial";
	private char[] separator = {'-'};
	private int minWordLength = 4;
	private int nWords = 200;
	private int variation = 100;
	private Color color = Color.RED;
	private long start;
	private int totNWords = 0;
	private int nDiffWords = 0;
	private int nData = 0;
	private int nWordsIgnored = 0;
	private int totNWordsComposite = 0;
	private int nMostUsedI = 0;
	private int nMostUsed = 0;
	private FileNode fileHead = null;
	private WordNode treeHead = null, listHead = null;
	private IgnoreNode ignoreHead = null;
	private CompositeNode compositeHead = null;
	
	public static void main(String[] args) {
		WordCloud wordCloud = new WordCloud();
		wordCloud.args = args;
		try {
			wordCloud.run();
		} catch (Exception e) {
			System.out.println("\nUnbekannter Fehler");
			System.exit(0);
		}
	}
	
	/* Runs the program */
	public void run() throws Exception {
		
		start = System.currentTimeMillis();
		
		setMode();
	
		getFiles(textDir);

		readLists();

		readIn();

		makeList();

		makeCloud();

		save();
		
		printStatistic();
	}

	/* Sets the Mode given in args */
	private void setMode() throws Exception {
		if(args.length<1) {
			return;
		}
		if(args[0].equals("-h") || args[0].equals("--help") || args[0].equals("?") || args[0].equals("help")) {
			System.out.println( "\n\n" +
				"     *********************************************************************\n" +
				"     ***              Dieser Generator erzeugt Wortwolken              ***\n" +
				"     *********************************************************************\n" +
				"     ***                                                               ***\n" +
				"     *** Optionen:                                                     ***\n" +
				"     ***                                                               ***\n" +
				"     *** -d String  Pfad in dem sich die Dateien befinden              ***\n" +
				"     ***            default: ./text/                                   ***\n" +
				"     *** -i String  Angabe einer zusätzlichen Ignorierliste            ***\n" +
				"     ***            Es werden beide Ignorierlisten verwendet           ***\n" +
				"     *** -I String  Angabe einer zusätzlichen Ignorierliste            ***\n" +
				"     ***            Es wird nur diese verwendet                        ***\n" +
				"     *** -z String  Angabe einer zusätzlichen Liste mit Doppelwörter   ***\n" +
				"     ***            Es werden beide Listen verwendet                   ***\n" +
				"     *** -Z String  Angabe einer zusätzlichen Liste mit Doppelwörter   ***\n" +
				"     ***            Es wird nur diese verwendet                        ***\n" +
				"     *** -s String  Trennzeichen (Leerzeichen ist immer eines)         ***\n" +
				"     ***            default: -                                         ***\n" +
				"     *** -l Zahl    Minimale Wortlänge um gezählt zu werden            ***\n" +
				"     ***            default: 4                                         ***\n" +
				"     *** -n Zahl    Anzahl der angezeigten Wörter                      ***\n" +
				"     ***            default: 200                                       ***\n" +
				"     *** -c Zahl    Farbe der Wolke      0-Blau,   1-Grün, 2-Violett   ***\n" +
				"     ***                                 3-Orange, 4-Rosa, 5-Grau      ***\n" +
				"     ***            default: Rot                                       ***\n" +
				"     *** -f String  Schriftart  (direkt oder eine auswählen mit Zahl)  ***\n" +
				"     ***              0-Aharoni, 1-Times New Roman,     2-Stencil      ***\n" +
				"     ***              3-Magneto, 4-Old English Text MT, 5-Cooper Black ***\n" +
				"     ***            default: Arial                                     ***\n" +
				"     *** -v Zahl    Streuungsfaktor (>Streut weniger, dauert länger)   ***\n" +
				"     ***            default: 100                                       ***\n" +
				"     *** -x Zahl    Fensterhöhe                                        ***\n" +
				"     ***            default: 700                                       ***\n" +
				"     *** -y Zahl    Fensterbreite                                      ***\n" +
				"     ***            default: 1300                                      ***\n" +
				"     *** -o String  Pfad und Format des auszugebenden Bildes           ***\n" +
				"     ***            available: .png  .jpg  .bmp  .gif                  ***\n" +
				"     ***            default: ./out/cloud.png                           ***\n" +
				"     ***                                                               ***\n" +
				"     *** Alle Listen und Dateien müssen im txt-Format sein             ***\n" +
				"     ***                                                               ***\n" +
				"     *** Die Standardlisten können in lists/ eingesehen und            ***\n" +
				"     *** verändert werden                                              ***\n" +
				"     ***                                                               ***\n" +
				"     ***                                          © Staudinger Philipp ***\n" +
				"     *********************************************************************\n"   
			);
			System.exit(0);
		}
		try {
			for(int i=0; i<args.length; i+=2) {
				switch(args[i].charAt(1)) {
					case 'd': 	textDir = new File(args[i+1]);
								break;
					case 'i': 	ignoreDir2 = args[i+1];
								break;
					case 'I': 	ignoreDir = args[i+1];
								break;
					case 'z': 	compositeDir2 = args[i+1];
								break;
					case 'Z': 	compositeDir = args[i+1];
								break;
					case 's': 	separator = new char[args[i+1].length()];
								args[i+1].getChars(0, args[i+1].length(), separator, 0);
								break;	
					case 'l': 	minWordLength = Integer.parseInt(args[i+1]);
								break;
					case 'n': 	nWords = Integer.parseInt(args[i+1]);
								break;
					case 'c': 	int col = Integer.parseInt(args[i+1]);
								if(col==0) color = Color.BLUE;
								if(col==1) color = Color.GREEN;
								if(col==2) color = Color.MAGENTA;
								if(col==3) color = Color.ORANGE;
								if(col==4) color = Color.PINK;
								if(col==5) color = Color.LIGHT_GRAY;
								break;
					case 'f': 	if(args[i+1].matches("[0-9]")) {
									int tmp = Integer.parseInt(args[i+1]);
									if(tmp==0) font = "Aharoni";
									if(tmp==1) font = "Times New Roman";
									if(tmp==2) font = "Stencil";
									if(tmp==3) font = "Magneto";
									if(tmp==4) font = "Old English Text MT";
									if(tmp==5) font = "Cooper Black";
								} else {
									font = args[i+1];
								}
					break;
					case 'v': 	variation = Integer.parseInt(args[i+1]);
								break;
					case 'x': 	width = Integer.parseInt(args[i+1]);
								break;
					case 'y': 	height = Integer.parseInt(args[i+1]);
								break;
					case 'o': 	outDir = args[i+1];
								break;
					default: 	throw new Exception();
				}
			}
		} catch (Exception e) {
			System.out.println("\nUngültiger Aufruf");
			System.exit(0);
		}
	}
	
	/* makes a list with all txt-files in the given directory */
	private void getFiles(File directory) {
		try {
			File[] all = directory.listFiles();
			for(File file: all) {
				if(file.isDirectory()) {
					getFiles(file);
				} else if(file.isFile()){
					String type = file.getName().substring(file.getName().length()-3, file.getName().length());
					if(type.equals("txt")) {
						fileHead = new FileNode(file, fileHead);
						nData++;
					}
				}
			}
		} catch (Exception e) {
			System.out.println("\nFehler beim Einlesen der Dateien");
			System.exit(0);
		}
	}
	
	/* reads in the ignore- and composite-lists */
	private void readLists() {
		try {
			String line = null;	
			BufferedReader text = null;
			String[] words;
	
			if(!ignoreDir.equals("")) {
				text = new BufferedReader(new FileReader(ignoreDir));
				while ((line = text.readLine()) != null) {
					ignoreHead = new IgnoreNode(line, ignoreHead);
				}
			}
			
			if(!ignoreDir2.equals("")) {
				text = new BufferedReader(new FileReader(ignoreDir2));
				while ((line = text.readLine()) != null) {
					ignoreHead = new IgnoreNode(line, ignoreHead);
				}
			}
			
			if(!compositeDir.equals("")) {
				text = new BufferedReader(new FileReader(compositeDir));
				while ((line = text.readLine()) != null) {
					words = line.split(" ");
					compositeHead = new CompositeNode(words[0], words[1], compositeHead);
				}
			}
			
			if(!compositeDir2.equals("")) {
				text = new BufferedReader(new FileReader(compositeDir2));
				while ((line = text.readLine()) != null) {
					words = line.split(" ");
					compositeHead = new CompositeNode(words[0], words[1], compositeHead);
				}
			}
		} catch (Exception e) {
			System.out.println("\nFehler beim Einlesen der Listen");
			System.exit(0);
		}
	}
		
	/* reads in files given by fileHead and produces a sorted tree */
	private void readIn() throws Exception {
		String replace = "[^a-zA-Z\\ä\\Ä\\ö\\Ö\\ü\\Ü\\s+";
		String split = "[\\s+";
		for(char c: separator) {
			replace += "\\" + Character.toString(c);
			split += "\\" + Character.toString(c);
		}
		replace += "]";
		split += "]";
		BufferedReader text = null;
		String line = null;
		String words[];
		CompositeNode tmp;
		
		while(fileHead!=null) {
			text = new BufferedReader(new FileReader(fileHead.file.toString()));
			while ((line = text.readLine()) != null) {
				line = line.replaceAll(replace, "");
				words = line.split(split);
				
				for(int i=0; i<words.length-1; i++) {
					tmp = compositeHead;
					while(tmp!=null) {
						if(words[i].equalsIgnoreCase(tmp.first) && words[i+1].equalsIgnoreCase(tmp.secound)) {
							words[i] += " " + words[i+1];
							words[i+1] = "";
							totNWordsComposite++;
							i++;
						}
						tmp = tmp.next;
					}
				}
				
				for(String w: words) {
					if(w.length()>=minWordLength) {
						if(treeHead==null) {
							treeHead = new WordNode(w);
						} else {
							treeHead.addNode(w);
						}
					}
				}
			}
			fileHead = fileHead.next;
		}
	}
		
	/* makes list with most used words (nWords long) */
	public void makeList() throws Exception {
		listHead = treeHead.treeToList(null);
		
		nMostUsedI = listHead.number;
		WordNode listTmp = listHead;
		while(listTmp!=null) {
			nDiffWords++;
			totNWords += listTmp.number;
			listTmp = listTmp.next;
		}	
		
		int i = 0;
		boolean isIgnored;
		listTmp = listHead;
		WordNode listTmp2 = null;
		IgnoreNode IgnoreTmp;	
		while(listTmp!=null && i<nWords) {
			isIgnored = false;
			IgnoreTmp = ignoreHead;
			while(IgnoreTmp!=null && !isIgnored) {
				if(listTmp.word.equalsIgnoreCase(IgnoreTmp.ignore)) {
					isIgnored = true;
					nWordsIgnored++;
				}
				IgnoreTmp = IgnoreTmp.next;
			}
			if(isIgnored) {
				if(listTmp2==null) {
					listHead = listTmp.next;
				} else {
					listTmp2.next = listTmp.next;
				}
			} else {
				i++;
				listTmp2 = listTmp;
			}
			listTmp = listTmp.next;
		}
		listTmp2.next = null;
		nMostUsed = listHead.number;
	}	
	
	/* produces the wordcloud out of the list */
	public void makeCloud() throws Exception {
		SpaceList usedSpace = new SpaceList();
		java.util.Random r = new java.util.Random();
		float scl = (float)Math.sqrt(width/1300f*height/700f);
		float fontSize = 30+(300)*scl/(float)Math.sqrt(nWords);
		float minFontSize = (180)*scl/((float)Math.sqrt(nWords));
		float fontStepFactor = (float)Math.pow(fontSize-minFontSize,1/((float)nWords));
		int x, y, c;
		int nRnd = 5; 
		int xPRnd = width/5; 
		int yPRnd = height/5;
		float sfact = variation/10f*13/(float)Math.pow((float)nWords/10,1f/3);
		WordNode tmp = listHead;
		SpaceNode newNode = null;
		while(tmp!=null) {
			int failed = 0;
			nRnd = 20;
			Window.setTextSize((int)fontSize, font);
			do {
				xPRnd = width/nRnd; 
				yPRnd = height/nRnd;
				x = 0;
				y = 0;
				for(int i=0; i<nRnd; i++) {
					x += r.nextInt(xPRnd);
					y += r.nextInt(yPRnd);
				}
				newNode = new SpaceNode(y-Window.getTextHeight()/2, y+Window.getTextHeight()/2,
										x-Window.getTextWidth(tmp.word)/2, x+Window.getTextWidth(tmp.word)/2);
				failed++;
				if(failed/sfact<=17) {
					nRnd = (int)(20 - failed/sfact);
				}
				if(failed>50000) return;
			} while(!usedSpace.addSpace(newNode));
			c = r.nextInt(4);
			if(c==0) {
				Window.drawTextCentered(tmp.word, x, y, Color.BLACK);
			} else if(c==1){
				Window.drawTextCentered(tmp.word, x, y, Color.DARK_GRAY);
			} else if(c==2){
				Window.drawTextCentered(tmp.word, x, y, Color.GRAY);
			} else {
				Window.drawTextCentered(tmp.word, x, y, color);
			}
			fontSize = (fontSize-minFontSize)/fontStepFactor + minFontSize;
			tmp = tmp.next;
		}
	}	
	
	/* saves the output file */
	public void save() {
		File out = new File(outDir);
	    try {
	      ImageIO.write((RenderedImage)Window.image, outDir.substring(outDir.length()-3, outDir.length()), out);
	    } catch(Exception e) {
	      System.out.println("\nSpeichern nicht möglich");
	    }
	    if(out.isFile()) {
	    	System.out.println("\nSpeichern erfolgreich");
	    } else {
	    	System.out.println("\nSpeichern nicht möglich");
	    }
    }

	/* Prints a short statistic */
	public void printStatistic() {
		System.out.println(
				"\nBenötigte Zeit:\n\t" +
				Long.toString(System.currentTimeMillis() - start) +
				"\nAnzahl eingelesener Daten:\n\t" +
				Integer.toString(nData) +
				"\nAnzahl eingelesener Wörter (Wörter < Mindestwortlänge gelten als nicht eingelesen):\n\t" +
				Integer.toString(totNWords) +
				"\nAnzahl eingelesener verschiedener Wörter:\n\t" +
				Integer.toString(nDiffWords) +
				"\nAnzahl der verschiedenen Wörter die ignoriert wurden:\n\t" +
				Integer.toString(nWordsIgnored) +
				"\nAnzahl der doppelten Wörter:\n\t" +
				Integer.toString(totNWordsComposite) +
				"\nAnzahl des meistegebrauchten Wortes:\n\t" +
				Integer.toString(nMostUsedI) +
				"\nAnzahl des meistegebrauchten Wortes das nicht ignoriert wurde:\n\t" +
				Integer.toString(nMostUsed)
		);
	}
}
