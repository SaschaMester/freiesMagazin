/*
 *  Copyright (C) 2012  Philipp Staudinger

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>. 
 */

package wordCloud;

public class WordNode {

	WordNode left, right;
	WordNode next = null;
	final String word;
	int number;
	
	/* Constructor */
	public WordNode(String word) {
		this.left = null;
		this.right = null;
		this.word = word;
		this.number = 1;
	}
	
	/* Adds recursively a new Word into the Tree */
	public void addNode(String newWord) { 
		if(newWord.compareToIgnoreCase(word)<0) {
			if(left==null) {
				left = new WordNode(newWord);
			} else {
				left.addNode(newWord);
			}
		} else if(newWord.compareToIgnoreCase(word)>0) {
			if(right==null) {
				right = new WordNode(newWord);
			} else {
				right.addNode(newWord);
			}
		} else {
			number++;
		}	
	}
	
	/* Makes list out of tree sorted by number */
	public WordNode treeToList(WordNode head) { 
		if(left!=null) {
			head = left.treeToList(head);
		}
		if(head==null) {
			head = this;
		} else {
			WordNode tmp = head;
			WordNode tmp2 = null;
			while(tmp!=null && tmp.number>=number){
				tmp2 = tmp;
				tmp = tmp.next;
			}
			if(tmp2==null) {
				head = this;
			} else {
				tmp2.next = this;
			}
			next = tmp;
		}
		if(right!=null) {
			head = right.treeToList(head);
		}
		return head;
	}	

}
