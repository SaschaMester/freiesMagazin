#!/usr/bin/env python3
# License: GNU LGPL Version 3
# see http://www.gnu.org/licenses/lgpl.html
# Copyright 2012 Tom Richter

import sys

class Wordcounter(object):
    def __init__(self, sep=' ', comments=None, block_comments=None,
                 ignore=None, chars=None,
                 alpha=False, length=1,
                 upper=False, composition=None, linesep='\n'):
        self._count = {}
        self.sep = sep
        self.comments = comments
        self.block_comments = block_comments
        self.ignore = ignore
        if ignore is None:
            self.ignore = []
        self.chars = chars
        self.composition = composition
        self.upper = upper
        self.linesep = linesep
        self.alpha = alpha
        self.length = length

    def __str__(self):
        return ('\n'.join('%s: %d' % (key, value)
                for key, value in self._count.items()))

    def add(self, text):
        if self.comments:
            while len(text) >= 1:
                ind = text.find(self.comments)
                if ind == -1:
                    break
                ind2 = text.find(self.linesep, ind)
                if ind2 == -1:
                    text = text[:ind]
                else:
                    text = ''.join((text[:ind], text[ind2:]))
        if self.block_comments and len(self.block_comments) > 1:
            ind = 0
            while len(text) >= 1:
                ind = text.find(self.block_comments[0], ind)
                if ind == -1:
                    break
                ind2 = text.find(self.block_comments[1], ind)
                if ind2 == -1:
                    ind = ind + 1
                else:
                    text = ''.join((text[:ind], text[ind2 + 1:]))
        text = text.replace(self.linesep, self.sep)
        if self.upper:
            text = text.lower()
        if self.composition:
            for composition in self.composition:
                count = text.count(self.sep + composition + self.sep)
                if count > 0:
                    text = text.replace(self.sep + composition + self.sep, self.sep)
                    try:
                        self._count[composition] += count
                    except KeyError:
                        self._count[composition] = count
        if self.chars is not None:
            if self.alpha:
                mapdict = {c:self.sep for c in range(sys.maxunicode)
                           if not chr(c).isalpha() and
                           chr(c) != self.sep and chr(c) != ' ' and
                           chr(c) != '_'}
            elif self.chars == True:
                mapdict = {c:self.sep for c in range(sys.maxunicode)
                           if not chr(c).isalnum() and
                           chr(c) != self.sep and chr(c) != ' ' and
                           chr(c) != '_'}
            else:
                mapdict = {c:ord(self.sep) for c in range(sys.maxunicode)
                           if chr(c) in self.chars}
            text = text.translate(mapdict)
        words = text.split(self.sep)
        for word in words:
            word = word.strip(self.sep)
            if (word != '' and word not in self.ignore and
                len(word) >= self.length):
                try:
                    self._count[word] += 1
                except KeyError:
                    self._count[word] = 1

    def get_wordcounts(self):
        return self._count


if __name__ == '__main__':
    import os.path
    import argparse
    import glob
    import pickle
    import tempfile

    tempfilename = os.path.join(tempfile.gettempdir(), 'wordcounts.pickle')

    intro = ('Word counter - Count words in text files and generate '
             'a pickle file with the word count dictionary. '
             'Hint: Most arguments have to be escaped.')
    usage = (" wordcounter.py '*.txt' -r -s' ' -i'wurde "
             "Bearbeiten' -c'#' -z -a -l6 -d'Dresdner Elbtalweitung,Lausitzer "
             "Granitplatte'")
    parser = argparse.ArgumentParser(description=intro,
                                     epilog='Example usage: %s' % usage)
    parser.add_argument('files', nargs='+',
                        help='Files to scan. If option -r is given files can '
                        'be one or more global expressions.')
    parser.add_argument('-r', '--recursive', action='store_true',
                        help='Look for files in subdirectories recursively')
    parser.add_argument('-s', '--separator', default=' ',
                        help='Define separator character '
                        '(default is whitespace)')
    parser.add_argument('-i', '--ignore',
                        help='Ignore this words (separated by separator)')
    parser.add_argument('-c', '--comments',
                        help='String indicating comments which are ignored')
    parser.add_argument('-b', '--block-comments', nargs='+',
                        help='First occurrence: String indicating start of '
                        'block comments which are ignored. Second occurrence: '
                        'String indicating the end of block comments.')
    parser.add_argument('-z', '--chars', nargs='?', const=True,
                        help='Ignore this characters (will be replaced by '
                        'separator). If no argument is given all '
                        'non-alphanumeric characters are ignored.')
    parser.add_argument('-a', '--alpha', action='store_true',
                        help='In combination with -z: Ignore all non-alphabetic'
                        ' characters (will be replaced by separator)')
    parser.add_argument('-l', '--length', type=int, default=1,
                        help='Count only words with a minimum number of '
                        'characters (integer)')
    parser.add_argument('-u', '--upper', action='store_true',
                        help='Ignore upper and lower case')
    parser.add_argument('-d', '--words',
                        help='Word-composition list separated by commatas '
                        'if the separator is the whitespace - '
                        'otherwise separated by whitespaces')
    parser.add_argument('-p', '--linesep', default=os.linesep,
                        help='Line separator in files if other than '
                        'os-specific')
    parser.add_argument('-o', '--output', default=tempfilename,
                        help='Output file (default %s)' % tempfilename)
    args = parser.parse_args()
    # get file list
    if args.recursive:
        filelist = []
        for file_ in args.files:
            dirname, basename = os.path.split(file_)
            if dirname == '':
                dirname = os.path.curdir
            for root, dirs, files in os.walk(dirname):
                filelist.extend(glob.glob(os.path.join(root, basename)))
    else:
        filelist = args.files

    if args.ignore is not None:
        args.ignore = args.ignore.split(args.separator)
    if args.words is not None and args.separator == ' ':
        args.words = args.words.split(',')
        args.words = [word.strip(',') for word in args.words]
    elif args.words is not None:
        args.words = args.words.split()
        args.words = [word.strip() for word in args.words]

    wordcounter = Wordcounter(sep=args.separator,
                              comments=args.comments,
                              block_comments=args.block_comments,
                              ignore=args.ignore,
                              chars=args.chars,
                              composition=args.words,
                              upper=args.upper,
                              alpha=args.alpha,
                              linesep=args.linesep,
                              length=args.length)

    for fname in filelist:
        with open(fname, 'r', encoding='utf-8') as f:
            wordcounter.add(f.read())

    with open(args.output, 'wb') as f:
        pickle.dump(wordcounter.get_wordcounts(), f)

# Codesnipets with re
#import re
#        if self.comments:
#            text = re.sub('#.+$', self.sep, text) # not working
#        if self.chars is not None:
#            if self.alpha:
#                text = re.sub('[^ \w\d ]+', self.sep, text)
#            elif self.chars == True:
#                text = re.sub('[^ \w ]+', self.sep, text)
#            else:
#                text = re.sub('[%s]+' % self.chars, self.sep, text)
#        if self.composition:
#            for composition in self.composition:
#                text, count = re.subn(composition, '', text)
#                if count > 0:
#                    try:
#                        self._count[composition] += count
#                    except KeyError:
#                        self._count[composition] = count
