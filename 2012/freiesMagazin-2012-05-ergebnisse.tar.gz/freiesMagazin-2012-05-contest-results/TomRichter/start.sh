#!/bin/bash

# freiesMagazin, LaTeX-Ausgaben 2011
# rekursive Suche *.tex, 117 Dateien, 3.8 MB
# Trenner:  ,._:/{}\<>()"[]=„“
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ( ./wordcounter.py -s ' ' -z ',._:/{}\<>()"[]=„“' -l 3 -r ../Testdaten/LaTeX/*.tex -o Output/fmtex.pickle && ./wordcounts2html.py -m 100 -i Output/fmtex.pickle -o Output/fmtex.html )
# 51.120

# freiesMagazin, HTML-Ausgaben 2011
# Ordnerangabe, *.html, 12 Dateien, 2.9 MB
# Trenner:  <>=.,!?/":;[]()#&„“
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ( ./wordcounter.py -s ' ' -z '<>=.,!?/":;[]()#&„“' -l 3 ../Testdaten/HTML/*.html -o Output/fmhtml.pickle && ./wordcounts2html.py -m 100 -i Output/fmhtml.pickle -o Output/fmhtml.html )
# 7.961

# Sigil-Code, C++
# rekursive Suche nach *.cpp und *.h, 189 Dateien, 1.3 MB
# Trenner:  ,+-#"*/()<>;:.&{}[]
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ( ./wordcounter.py -s ' ' -z ',+-#"*/()<>;:.&{}[]' -l 3 -r ../Testdaten/Cpp/Sigil/*.cpp ../Testdaten/Cpp/Sigil/*.h -o Output/sigil.pickle && ./wordcounts2html.py -m 100 -i Output/sigil.pickle -o Output/sigil.html )
# 3.006

# Alice (englisch)
# *txt-Dateien in einem Ordner, 2 Dateien, 310 kb
# Groß-/Kleinschreibung ignorieren
# Trenner:  .,;:?!"-+*()'
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ( ./wordcounter.py -s ' ' -z ".,;:?\!\"-+*()'" -l 3 -u ../Testdaten/Text/Alice/*.txt -o Output/alice.pickle && ./wordcounts2html.py -m 100 -i Output/alice.pickle -o Output/alice.html )
# 1.827

# Mathetext (deutsch)
# eine Textdatei, 200 kb
# Trenner:  .,"„“‚‘:?!=()+*/–−[]{}
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ( ./wordcounter.py -s ' ' -z ".,\"„“‚‘:?\!=()+*/–−[]{}" -l 3 ../Testdaten/Text/mathe.txt -o Output/mathe.pickle && ./wordcounts2html.py -m 100 -i Output/mathe.pickle -o Output/mathe.html )
# 1.317
