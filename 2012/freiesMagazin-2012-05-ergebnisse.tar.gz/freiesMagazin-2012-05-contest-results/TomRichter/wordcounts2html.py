#!/usr/bin/env python3
# License: GNU LGPL Version 3
# see http://www.gnu.org/licenses/lgpl.html
# Copyright 2012 Tom Richter


def wordcounts_to_html(word_counts, count_min=1, words_on_row=None,
                  number_of_words=None):
    words_to_delete = []
    for word, count in word_counts.items():
        if count < count_min:
            words_to_delete.append(word)
    for word in words_to_delete:
        del word_counts[word]
    N = len(word_counts)
    if number_of_words and number_of_words < N:
        N = number_of_words
        word_counts = dict(sorted(word_counts.items(),
                                  key=lambda t: t[1], reverse=True)[:N])
    if words_on_row is None:
        words_on_row = N + 1
    # set font size
    if N > 0:
        count_max = max(word_counts.values())
        count_min = min(word_counts.values())
        font_max = 400
        font_min = 150
        if count_max == count_min:
            count_min -= 1
            font_max = 200
        elif count_max / count_min < 2:
            font_min = 200
        elif count_max / (count_min + 2) > 10:
            font_max = min(1000, 40 * count_max / (count_min + 2))

    head = ('<meta http-equiv="Content-Type" content="text/html; '
            'charset=UTF-8" />\n<html>\n'
            '<head><title> Wortwolke </title></head>\n<body><p>\n'
            '<span style="color:Maroon">')
    body = []
    for i, word in enumerate(word_counts.keys()):
        size = ((word_counts[word] - count_min) * (font_max - font_min) /
                (count_max - count_min) + font_min)
        body.append('&#160&#160&#160'
                    '<span style="font-size:%d%%", title="Anzahl %d">%s</span>'
                    '\n' % (size, word_counts[word], word))
        if (i + 1) % words_on_row == 0:
            body.append('<br>\n')
    body = ''.join(body)
    tail = '</span>\n</p></body>\n</html>'
    return head + body + tail


if __name__ == '__main__':
    import sys
    import os.path
    import argparse
    import pickle
    import tempfile

    tempfilename = os.path.join(tempfile.gettempdir(), 'wordcounts.pickle')
    intro = ('Converts pickled wordcounts to html - Reads pickled wordcount '
             'dictionary in input file and generates a tag cloud in html '
             'format.')
    usage = ' wordcounts2html -n3 -m100'
    parser = argparse.ArgumentParser(description=intro,
                                     epilog='Example usage: %s' % usage)
    parser.add_argument('-i', '--input', default=tempfilename,
                        help='Input file with pickled dictionary '
                        '(default %s)' % tempfilename)
    parser.add_argument('-n', '--count', type=int, default=1,
                        help='Display only words which appeared with a '
                        'minimum count (integer)')
    parser.add_argument('-m', '--number', type=int,
                        help='Display not all words, but just the given '
                        'number of words with the highest count '
                        'downwards (integer)')
    parser.add_argument('-w', '--row', type=int,
                        help='Display this number of words in one row '
                        '(integer, default all words on one row)')
    parser.add_argument('-o', '--output', default='wordcloud.html',
                        help='Output file (default wordcloud.html)')
    args = parser.parse_args()

    with open(args.input, 'rb') as f:
        wordcounts = pickle.load(f)
    text = wordcounts_to_html(wordcounts,
                              count_min=args.count,
                              number_of_words=args.number,
                              words_on_row=args.row)
    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(text)
