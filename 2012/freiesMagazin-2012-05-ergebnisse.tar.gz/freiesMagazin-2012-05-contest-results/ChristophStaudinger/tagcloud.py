#!/usr/bin/env python3

################################################################################
#   (C) Copyright 2012 Christoph Staudinger                                    #
#                                                                              #
#   This program is free software; you can redistribute it and/or modify       #
#   it under the terms of the GNU Lesser General Public License as             #
#   published by the Free Software Foundation; either version 3 of the         #
#   License, or (at your option) any later version.                            #
#                                                                              #
#   This program is distributed in the hope that it will be useful,            #
#   but WITHOUT ANY WARRANTY; without even the implied warranty of             #
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the               #
#   GNU Lesser General Public License for more details.                        #
#                                                                              #
#   You should have received a copy of the GNU Lesser General Public           #
#   License along with this program. If not, see                               #
#   <http://www.gnu.org/licenses/>.                                            #
################################################################################

import sys, re, math, argparse, os
from operator import itemgetter
import random
import cairo

class WordCounter:
    def __init__(self, ignorefiles=[], multifiles=[], specialfiles=[]):
        self.seplist = []
        self.speciallist = []
        self.specialfactor = 2
        self.ignorelist = set([])
        for ignorefile in ignorefiles:
            with open(ignorefile) as ignorefile:
                for word in ignorefile.read().split():
                    self.ignorelist.add(word)

        self.multi_word_phrases = set([])
        for multifile in multifiles:
            with open(multifile) as multifile:
                for line in multifile.readlines():
                    self.multi_word_phrases.add(line.replace('\n', ''))

        self.special_dict = {}
        try:
            for specialfile in specialfiles:
                with open(specialfile) as specialfile:
                    for line in specialfile.readlines():
                        word, value = line.split()
                        self.special_dict[word.lower()] = float(value)
        except:
            print("Invalid Special Count File. \nexiting...")
            exit(-1)
        self.tree = None
        self.shortcut_dict = {}

    def readFile(self, filename, seperators='', min_length=4):
        with open(filename) as infile:
            text = infile.read()
            self.readText(text, seperators, min_length)

    def readText(self, text, seperators='', min_length=4):
        #maybe: replace some characters with whitespace
        if seperators:
            text = re.sub(r'[{}]'.format(seperators), ' ', text, count=0, flags=re.UNICODE)

        # remove all not alph chars except - 
        text = re.sub(r'[^a-zA-Z1-9äöüÄÖÜ\s\'\-_]', '', text, count=0, flags=re.UNICODE)

        # look for multi word phrases
        for phrase in self.multi_word_phrases:
            text, count = re.subn(r'{}'.format(phrase), '', text, count=0, flags=re.UNICODE + re.I)
            self.addWord(phrase, count)

        # split whitespace
        wordlist = re.split(r'\s', text, maxsplit=0, flags=re.UNICODE)

        #remove all words with < 4 letters
        wordlist = [word for word in wordlist if len(word) >= min_length]

        # remove all ignored words
        wordlist = [word for word in wordlist if word.lower() not in self.ignorelist]

        for word in wordlist:
            self.addWord(word)

    def getWordList(self):
        if self.tree:
            return sorted(self.tree.getWordList(), key=itemgetter(1))

    def getWordObjectList(self, number):
        wordlist = self.getWordList()[-number:]
        if len(wordlist) < number:
            print("Not enough different words in inputfile(s) for a wordcloud with {} words. \nexiting...".format(number))
            exit(-1)
        wordlist.reverse()
        wordobjectlist = []
        for word in wordlist:
            wordobjectlist.append(Word(word[0], word[1]/wordlist[0][1] + 0.05))
        return wordobjectlist

    def getCountValue(self, word):
        try:
            return self.special_dict[word.lower()]
        except KeyError:
            return 1

    def addWord(self, word, count=1):
        if word[:4] in self.shortcut_dict:
            node = self.shortcut_dict[word[:4]]
        elif word[:3] in self.shortcut_dict:
            node = self.shortcut_dict[word[:3]]
        elif word[:2] in self.shortcut_dict:
            node = self.shortcut_dict[word[:2]]
        else:
            node = self.tree

        count = count * self.getCountValue(word)
            
        if node:
            node = node.addWord(word, count)
        elif self.tree:
            node = self.tree.addWord(word, count) 
        else:
            self.tree = WordCountNode(word, count)
            node = self.tree

        aaaa = node.word_lower[:4]
        aaa = node.word_lower[:3]
        aa = node.word_lower[:2]
        if not aaaa in self.shortcut_dict:
            self.shortcut_dict[aaaa] = node
        if not aaa in self.shortcut_dict:
            self.shortcut_dict[aaa] = node
        if not aa in self.shortcut_dict:
            self.shortcut_dict[aa] = node
        
    def sortByNumber(self):
        self.wordcount_list.sort()

class WordCountNode:
    def __init__(self, word, count=1):
        self.word = word
        self.word_lower = word.lower()
        self.count = count
        self.up = None
        self.down = None

    def addWord(self, word, count=1):
        wl = word.lower()
        if wl < self.word_lower:
            if self.down:
                return self.down.addWord(word, count)
            else:
                self.down = WordCountNode(word, count)
                return self.down
        elif wl > self.word_lower:
            if self.up:
                return self.up.addWord(word, count)
            else:
                self.up = WordCountNode(word, count)
                return self.up
        else:
            self.count += count
            return self
            # todo look into a dictionary to get real add number

    def getWordList(self):
        wordlist = []
        if self.up:
            wordlist.extend(self.up.getWordList())
        if self.down:
            wordlist.extend(self.down.getWordList())
        wordlist.append((self.word, self.count))
        return wordlist

    def __lt__(self, cmp):
        if self.count < cmp.count:
            return True
        return False

class WordCloudDrawer:
    def __init__(self, width=1500, height=1000):
        self.width = width
        self.height = height
        self.used_rects = []
        self.placed_words = []
        self.dummysurface = cairo.ImageSurface(cairo.FORMAT_ARGB32, self.width, self.height)
        self.dummycontext = cairo.Context(self.dummysurface)

    def placeWords(self, wordlist):
        wordcount = len(wordlist)
        weightparam = 2 + 10 * math.exp(-wordcount)
        for word in wordlist:
            x, y, rect = self.getNewPosition(word)
            word.place(rect)
            self.placed_words.append(word)
            self.used_rects.append(rect)

    def isFree(self, rect):
        for used_rect in self.used_rects:
            if rect.overlaps(used_rect):
                return False
        return True
    
    def isOutOfField(self, rect):
        if rect.x1 <= 0 or rect.y1 <= 0:
            return True
        if rect.x2 >= self.width or rect.y2 >= self.height:
            return True
        return False

    def getNewPosition(self, word, weightparam=10):
        x = self.getWeightedRandom(self.width, weightparam)
        y = self.getWeightedRandom(self.height, weightparam)
        new_rect = self.getRect(word, x, y)
        runs = 0
        while not self.isFree(new_rect) and not self.isOutOfField(new_rect):
            runs += 1
            if runs > 10:
                runs = 0
                if weightparam > 1:
                    weightparam -= 1
            x = self.getWeightedRandom(self.width, weightparam)
            y = self.getWeightedRandom(self.height, weightparam)
            new_rect = self.getRect(word, x, y)
        return x, y, new_rect


    def getRect(self, word, x1, y1):
        self.dummycontext.set_font_size(self.getFontSize(word))
        extents = self.dummycontext.text_extents(word.string)
        width = extents[2]
        height = extents[3]
        return Rectangle(x1-width/2, y1-height/2, x1 + width/2, y1 + height/2)

    def getFontSize(self, word):
        return int(self.height / 10 * word.importance)

    def getFontColor(self, word):
        value = 0.5 * (1 - word.importance)
        return value, value, value

    def getWeightedRandom(self, maximal, weightparam):
        sum = 0
        runs = 0
        while runs < weightparam:
            runs += 1
            sum += random.random()
        return sum / weightparam * maximal

    def writeToFile(self, fname):
        if fname[-4:] == '.pdf':
            self.writeToPdf(fname)
        elif fname[-4:] == '.png':
            self.writeToPng(fname)
        elif fname[-4:] == '.svg':
            self.writeToSvg(fname)

    def writeToPdf(self, fname):
        surface = cairo.PDFSurface(fname, self.width, self.height)
        ctx = cairo.Context(surface)
        self.drawWordsToCtx(ctx)
        ctx.show_page()

    def writeToPng(self, fname):
        surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, self.width, self.height)
        ctx = cairo.Context(surface)
        self.drawBackground(ctx)
        self.drawWordsToCtx(ctx)
        surface.write_to_png(fname)

    def writeToSvg(self, fname):
        surface = cairo.SVGSurface(fname, self.width, self.height)
        ctx = cairo.Context(surface)
        self.drawBackground(ctx)
        self.drawWordsToCtx(ctx)
        ctx.show_page()

    def drawBackground(self, ctx):
        ctx.rectangle(0,0, self.width, self.height)
        ctx.set_source_rgb(1,1,1)
        ctx.fill()

    def drawWordsToCtx(self, ctx):
        ctx.set_source_rgb(0,0,0)
        for word in self.placed_words:
            self.drawWord(ctx, word)

    def drawWord(self, ctx, word):
        ctx.move_to(word.rect.x1, word.rect.y2)
        ctx.set_font_size(self.getFontSize(word))
        r, g, b = self.getFontColor(word)
        ctx.set_source_rgb(r, g, b)
        ctx.show_text(word.string)

class Rectangle:
    def __init__(self, x1, y1, x2, y2):
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2

    def overlaps(self, rect):
        x_overlaps = False
        y_overlaps = False
        # todo simplyfy
        if self.x1 <= rect.x1 <= self.x2 or \
                self.x1 <= rect.x2 <= self.x2 or\
                rect.x1 <= self.x1 <= rect.x2 or\
                rect.x1 <= self.x2 <= rect.x2:
            x_overlaps = True
        if self.y1 <= rect.y1 <= self.y2 or \
                self.y1 <= rect.y2 <= self.y2 or\
                rect.y1 <= self.y1 <= rect.y2 or\
                rect.y1 <= self.y2 <= rect.y2:
            y_overlaps = True
        if x_overlaps and y_overlaps:
            return True
        else:
            return False

class Word:
    def __init__(self, string, importance):
        self.string = string
        self.importance = importance
    
    def place(self, rect):
        self.rect = rect

parser = argparse.ArgumentParser(description="Parses input files and creats a wordcloud out of frequent words.")
parser.add_argument('-i', '--ignore', nargs='?', metavar='Ignorelist', dest='ignorefile', help='Specifies a file with ignored words. Default file with ignored words is ignored')
parser.add_argument('-I', '--Ignore', nargs='?', metavar='Ignorelist', dest='Ignorefile', help='Specifies a file with ignored words. Default file with ignored words is additionally processed')
parser.add_argument('-m', '--multi', nargs='?', metavar='Multi-word-phrases', dest='multi', help='Specifies a file with phrases out of multiple words. Default file with multi-word-phrases is ignored')
parser.add_argument('-M', '--Multi', nargs='?', metavar='Multi-word-phrases', dest='Multi', help='Specifies a file with phrases out of multiple words. Default file with multi-word-phrases is additionally processed')
parser.add_argument('-s', '--special', nargs='?', metavar='Special counted words', dest='special', help='Specifies a file with special counted words. Default file with special counted words is ignored')
parser.add_argument('-S', '--Special', nargs='?', metavar='Special counted words', dest='Special', help='Specifies a file with special counted words. Default file with special counted words is additionally processed')
parser.add_argument('-n', '--number', nargs='?', default=50, type=int, metavar='Words', dest='number', help='Number of words in the wordcloud [50]')
parser.add_argument('--min', nargs='?', default=4, type=int, metavar='Minlength', dest='min_length', help='Minimal length of counted words [4]')
parser.add_argument('-o', nargs='?', metavar='Outputfile', dest='outfile', type=str, default='tagcloud.pdf', help='Outputfile. Can be pdf, png or svg [tagcloud.pdf]')
parser.add_argument('-W', '--width', nargs='?', type=int, default=1500, metavar='Width', dest='width', help='Width (as pixel) of output [1500]')
parser.add_argument('-H', '--height', nargs='?', type=int, default=1000, metavar='Height', dest='height', help='Height (as pixel) of output [1000]')
parser.add_argument('--sep', nargs='?', default='', metavar='Seperators', dest='seperators', help='Additional Seperators')
parser.add_argument('files', nargs='+', metavar='Inputfiles', help='Files to parse')
parser.add_argument('--recursive', action='store_true', default=False, dest='recursive', help='If this option is given file input is interpreted as \'directory filetypes\'. Directory is recursive searched for files with given filetypes')

IGNORELIST = './ignorelist.txt'
MULTIWORDPHRASES = './multiwordphrases.txt'
SPECIALLIST = './specialphrases.txt'

if __name__ == '__main__':
    namespace = parser.parse_args()
    # check input
    if not namespace.outfile[-4:] in ['.pdf', '.png', '.svg']:
        print("invalid output file type")
        exit(1)
    if namespace.number < 1:
        print("Invalid number of words in wordcloud")
        exit(-1)
    # get list of ignorefiles
    if namespace.ignorefile:
        ignorefiles = [namespace.ignorefile]
    elif namespace.Ignorefile:
        ignorefiles = [IGNORELIST, namespace.Ignorefile]
    elif namespace.ignorefile == '':
        ignorefiles = []
    else:
        ignorefiles = [IGNORELIST]

    # get list of multi-word-phrases files
    if namespace.multi:
        multifiles = [namespace.multi]
    elif namespace.Multi:
        multifiles = [namespace.Multi, MULTIWORDPHRASES]
    elif namespace.multi == '':
        multifiles = []
    else:
        multifiles = [MULTIWORDPHRASES]

    # get list of specialfiles
    if namespace.special:
        specialfiles = [namespace.special]
    elif namespace.Special:
        specialfiles = [namespace.Special, SPECIALLIST]
    elif namespace.special == '':
        specialfiles = []
    else:
        specialfiles = [SPECIALLIST]

    files = []
    if not namespace.recursive:
        files = namespace.files
    else:
        try:
            all_files = os.walk(namespace.files[0])
            files = []
            for fileline in all_files:
                if fileline[-1]:
                    for file in fileline[-1]:
                        if file[-3:] in namespace.files[1:]:
                            files.append(fileline[0] + os.sep + file)
        except:
            pass

    if not files:
        print("No input file(s)")
        exit(-1)

    wc = WordCounter(ignorefiles=ignorefiles, multifiles=multifiles, specialfiles=specialfiles)
    try:
        for file in files:
            wc.readFile(file, namespace.seperators, namespace.min_length)
    except:
        print("Could not read inputfile: {} \nexiting...".format(file))

    drawer = WordCloudDrawer(width=namespace.width, height=namespace.height)
    drawer.placeWords(wc.getWordObjectList(namespace.number))
    try:
        directs = os.sep.join(namespace.outfile.split(os.sep)[:-1])
        if directs:
            os.makedirs(directs, exist_ok=True)
        drawer.writeToFile(namespace.outfile)
    except:
        print("Can not write ouput file")
        exit(-1)

