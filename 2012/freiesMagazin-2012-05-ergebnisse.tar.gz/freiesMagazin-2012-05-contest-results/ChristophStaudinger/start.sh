#!/bin/bash

# freiesMagazin, LaTeX-Ausgaben 2011
# rekursive Suche *.tex, 117 Dateien, 3.8 MB
# Trenner:  ,._:/{}\<>()"[]=„“
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ./tagcloud.py --min 3 -n 100 --sep ',._:/{}\<>()"[]=„“' --recursive ../Testdaten/LaTeX/ tex -o Output/fmtex.png
# 3.797

# freiesMagazin, HTML-Ausgaben 2011
# Ordnerangabe, *.html, 12 Dateien, 2.9 MB
# Groß-/Kleinschreibung ignorieren
# Trenner:  <>=.,!?/":;[]()#&„“
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ./tagcloud.py --min 3 -n 100 --sep '<>=.,!?/":;[]()#&„“' ../Testdaten/HTML/*.html -o Output/fmhtml.png
# 5.174

# Sigil-Code, C++
# rekursive Suche nach *.cpp und *.h, 189 Dateien, 1.3 MB
# Trenner:  #,+"*/()<>;:.&{}[]-
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
rm -rf /tmp/input && mkdir /tmp/input && find ../Testdaten/Cpp/Sigil/ -name "*.cpp"  -exec cp {} /tmp/input/. \; -o -name "*.h" -exec cp {} /tmp/input/. \; && find /tmp/input/ -name "*.h" -exec mv {} {}.hhh \;
time ./tagcloud.py --min 3 -n 100 --sep '#,+"*/()<>;:.&{}[]-' --recursive /tmp/input cpp hhh -o Output/sigil.png
# 2.055

# Alice (englisch)
# *txt-Dateien in einem Ordner, 2 Dateien, 310 kb
# Groß-/Kleinschreibung ignorieren
# Trenner:  .,;:?!"-+*()'
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ./tagcloud.py --min 3 -n 100 --sep ".,;:?\!\"-+*()'" ../Testdaten/Text/Alice/*.txt -o Output/alice.png
# 1.215

# Mathetext (deutsch)
# eine Textdatei, 200 kb
# Trenner:  .,"„“‚‘:?!=()+*/–−[]{}
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ./tagcloud.py --min 3 -n 100 --sep '.,"„“‚‘:?!=()+*/–−[]{}' ../Testdaten/Text/mathe.txt -o Output/mathe.png
# 1.277


