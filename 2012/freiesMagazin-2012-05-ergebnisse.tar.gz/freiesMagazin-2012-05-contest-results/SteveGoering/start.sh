#!/bin/bash

# freiesMagazin, LaTeX-Ausgaben 2011
# rekursive Suche *.tex, 117 Dateien, 3.8 MB
# Trenner:  ,._:/{}\<>()"[]=„“
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ( rm -rf cfg/ && cp -r cfg_fmtex/ cfg/ && ./ct.py -r -s " " -m -e '*\.tex$' ../Testdaten/LaTeX/ Output/fmtex )
# 3.165

# freiesMagazin, HTML-Ausgaben 2011
# Ordnerangabe, *.html, 12 Dateien, 2.9 MB
# Groß-/Kleinschreibung ignorieren
# Trenner:  <>=.,!?/":;[]()#&„“
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ( rm -rf cfg/ && cp -r cfg_fmhtml/ cfg/ && ./ct.py -s " " -m -e '*\.html$' ../Testdaten/HTML/ Output/fmhtml )
# 3.379

# Sigil-Code, C++
# rekursive Suche nach *.cpp und *.h, 189 Dateien, 1.3 MB
# Trenner:  ,+-#"*/()<>;:.&{}[]
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ( rm -rf cfg/ && cp -r cfg_sigil/ cfg/ && ./ct.py -r -s " " -m -e '*\.h$|.*\.cpp$' ../Testdaten/Cpp/Sigil/ Output/sigil )
# 2.588

# Alice (englisch)
# *txt-Dateien in einem Ordner, 2 Dateien, 310 kb
# Groß-/Kleinschreibung ignorieren
# Trenner:  .,;:?!"-+*()'
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ( rm -rf cfg/ && cp -r cfg_alice/ cfg/ && ./ct.py -s " " -m -e '*\.txt$' ../Testdaten/Text/Alice/ Output/alice )
# 2.063

# Mathetext (deutsch)
# eine Textdatei, 200 kb
# Trenner:  .,"„“‚‘:?!=()+*/–−[]{}
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ( rm -rf cfg/ && cp -r cfg_mathe/ cfg/ && ./ct.py -s " " -m -e '*\.txt$' ../Testdaten/Text/mathe.txt Output/mathe )
# 2.130



