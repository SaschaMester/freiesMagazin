#!/bin/bash

# freiesMagazin, LaTeX-Ausgaben 2011
# rekursive Suche *.tex, 117 Dateien, 3.8 MB
# Trenner:  ,._:/{}\<>()"[]=„“
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ./tagcloudgen.tcl -s ' ,._:/{}\<>()"[]=„“' -d 100 -m 3 -t tex -r ../Testdaten/LaTeX/ -o Output/fmtex.png --nogradient
# 18.716

# freiesMagazin, HTML-Ausgaben 2011
# Ordnerangabe, *.html, 12 Dateien, 2.9 MB
# kein Kommentarzeichen (auch wenn <!--...--> möglich wäre)
# Trenner:  <>=.,!?/":;[]()#&„“
# Ignore-Listen: Data/Deutsch.txt Data/HTML.txt Data/fm.txt
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ./tagcloudgen.tcl -s ' <>=.,!?/":;[]()#&„“' -d 100 -m 3  -t html ../Testdaten/HTML/ -o Output/fmhtml.png --nogradient
# 19.956

# Sigil-Code, C++
# rekursive Suche nach *.cpp und *.h, 189 Dateien, 1.3 MB
# Trenner:  ,+-#"*/()<>;:.&{}[]
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ./tagcloudgen.tcl -s ' ,+-#"*/()<>;:.&{}[]' -d 100 -m 3 -t "cpp,h" -r ../Testdaten/Cpp/Sigil -o Output/sigil.png --nogradient
# 5.852

# Alice (englisch)
# *txt-Dateien in einem Ordner, 2 Dateien, 310 kb
# Groß-/Kleinschreibung ignorieren
# Trenner:  .,;:?!"-+*()'
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ./tagcloudgen.tcl -s " .,;:?\!\"-+*()'" -d 100 -m 3 --nocase -t txt ../Testdaten/Text/Alice -o Output/alice.png --nogradient
# 2.616

# Mathetext (deutsch)
# eine Textdatei, 200 kb
# Trenner:  .,"„“‚‘:?!=()+*/–−[]{}
# Minimale Wortlänge: 3
# Anzahl Wörter: 100
time ./tagcloudgen.tcl -s '.,"„“‚‘:?!=()+*/–− []{}' -d 100 -m 3 -t txt ../Testdaten/Text/mathe.txt -o Output/mathe.png --nogradient
# 2.493

