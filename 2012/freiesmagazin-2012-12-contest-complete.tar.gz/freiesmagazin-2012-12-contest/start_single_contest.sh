#!/bin/bash

# Aufruf:
# ./start_single_contest.sh ANZAHL OPTION

if [ ! $# -eq 3 -a ! $# -eq 4 ]
then
    echo "Fehler: Es werden drei oder vier Argument erwartet!"
    echo ""
    echo "Aufruf:   $0 BOT BOTNAME ANZAHL [OPTIONS]"
    echo ""
    echo "Beispiel: $0 bots/dummybot/bot dummybot 100"
    echo "          $0 bots/dummybot/bot dummybot 100 --log"
    echo ""
    echo "Erklaerung: Der Bot wird auf allen vorhandene Inselfeldern"
    echo "            die gewuenschte <ANZAHL> Mal getestet. Das"
    echo "            Ergebnis wird als Logfile im Ordner 'results'"
    echo "            gespeichert."
    echo "            <BOT> gibt den Pfad zum Bot an bzw. den"
    echo "            Befehl zur Ausfuehrung des Bots."
    echo "            <BOTNAME> ist der Name des Bots, der zum"
    echo "            Speichern der Logfiles benutzt wird."
    exit 1
fi

BOT="$1"
BOTNAME="$2"
NUMITER="$3"
OPTIONS="$4"
FIELDS=`ls fields/*.txt | egrep -v "simple"`
echo "$BOT $BOTNAME"

# Verzeichnis für Ergebnisse ablegen
mkdir -p results

for FIELD in $FIELDS
do
    FIELDNAME=`basename "$FIELD"`
    LOGFILE="results/${BOTNAME}_${FIELDNAME}"
    echo -e "\rFIELD $FIELDNAME"

    echo "(II) BOT: $BOT" > $LOGFILE
    echo "(II) START `date`" >> $LOGFILE
    for NUM in `seq 1 $NUMITER`
    do
        echo -ne "\rGame $NUM of $NUMITER"
        ./start.sh "$FIELD" "$BOT" "$OPTIONS" >> "$LOGFILE" 2>&1 
    done
    echo "(II) END `date`" >> "$LOGFILE"

    # do some statistics
    SUMROUNDS=$(grep "ROUNDS:" "$LOGFILE" | awk "{ all += \$3 } END { print all }")
    AVGROUNDS=$(grep "ROUNDS:" "$LOGFILE" | awk "{ all += \$3 } END { print all/$NUMITER }")
    STARTTIME=`grep "^(II) START" "$LOGFILE" | awk '{print $6}'`
    ENDTIME=`grep "^(II) END" "$LOGFILE" | awk '{print $6}'`
    SUMTIME=`echo $STARTTIME $ENDTIME 1 | awk -f subtract_time.awk`
    AVGTIME=`echo $STARTTIME $ENDTIME $NUMITER | awk -f subtract_time.awk`
    echo "(II) SUM-ROUNDS: $SUMROUNDS" >> "$LOGFILE"
    echo "(II) SUM-TIME:   $SUMTIME s" >> "$LOGFILE"
    echo "(II) AVG-ROUNDS: $AVGROUNDS" >> "$LOGFILE"
    echo "(II) AVG-TIME:   $AVGTIME s" >> "$LOGFILE"
done
echo ""



