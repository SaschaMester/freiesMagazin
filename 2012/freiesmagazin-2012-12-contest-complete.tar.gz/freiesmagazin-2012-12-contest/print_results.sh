#!/bin/sh

cd results || exit 1

# Das Format der Log-Dateien muss BOTNAME_INSELNAME.txt sein.
BOTNAMES=`ls *.txt | awk -F. '{ print $1 }' | awk -F_ '{ print $1 }' | sort -u`
FIELDNAMES=`ls *.txt | awk -F. '{ print $1 }' | awk -F_ '{ print $2 }' | sort -u`

# Zuerst den "Kopf" der Tabelle ausgeben
echo -n "Name\tPlatz\tgesamt\t"
for FIELD in $FIELDNAMES
do
    echo -n "$FIELD\t"
done
echo ""

for BOT in $BOTNAMES
do
    echo -n "$BOT\t \t \t"
    for FIELD in $FIELDNAMES
    do
        FILENAME="${BOT}_${FIELD}.txt"
        ROUNDS=`grep "AVG-R" $FILENAME | awk '{ print $NF }' | sed 's/\./,/g'`
        echo -n "$ROUNDS\t"
    done
    echo ""
done

cd .. || exit 1

exit 0

