#!/bin/bash

if [ ! $# -eq 1 -a ! $# -eq 2 ]
then
    echo "Fehler: Es werden ein oder zwei Argument erwartet!"
    echo ""
    echo "Aufruf:   $0 ANZAHL [OPTIONS]"
    echo ""
    echo "Beispiel: $0 100"
    echo "          $0 100 --log"
    echo ""
    echo "Erklaerung: Alle bekannten Bots (im Skript hinterlegt)"
    echo "            werden auf allen vorhandene Inselfeldern"
    echo "            die gewuenschte <ANZAHL> Mal getestet. Das"
    echo "            Ergebnis wird als Logfile im Ordner 'results'"
    echo "            gespeichert."
    exit 1
fi

NUMITER="$1"
OPTIONS="$2"

BOTS=( \
       "bots/BartensteinDominik/bot.py"  \
       "java -jar bots/BlobnerHeiko/build/libs/islander-0.0.19.jar" \
       "bots/BraunMarkus/bot"            \
       "bots/BrenneisMarkus/bot"         \
       "bots/DemelHarald/src/bot.sh harbot 1" \
       "bots/Egg6bn/bot.py"              \
       "bots/Egg8bn/bot.py"              \
       "bots/GrossTobias/rubot.rb"       \
       "bots/HettrichHorst/main.py"      \
       "bots/HummelKleine/wheatley.py"   \
       "bots/KnauerRobert/bot"           \
       "bots/MaraunMomme/bot"            \
       "bots/PummerThomas/tombot.py"     \
       "scala bots/RamppAlexander/bot.jar" \
       "bots/RichterJustus/errquart.py"  \
       "bots/RichterTom/robinson.py"     \
       "bots/SatzgerFlorian/bot"         \
       "bots/StaudingerChristoph/bot.py" \
       "bots/StaudingerPhilipp/bot.sh"   \
       "bots/UhlmannPatrick/bin/ArchesBotMono.sh" \
       "bots/WagenfuehrDominik/bot"      \
      )

BOTNAMES=( \
           "BartensteinD" \
           "BlobnerH"     \
           "BraunM"       \
           "BrenneisM"    \
           "DemelH"       \
           "Egg6bn"       \
           "Egg8bn"       \
           "GrossT"       \
           "HettrichH"    \
           "HummelKleine" \
           "KnauerR"      \
           "MaraunM"      \
           "PummerT"      \
           "RamppA"       \
           "RichterJ"     \
           "RichterT"     \
           "SatzgerF"     \
           "StaudingerC"  \
           "StaudingerP"  \
           "UhlmannP"     \
           "WagenfuehrD"  \
          )

if [ ${#BOTS[@]} != ${#BOTNAMES[@]} ]
then
    echo "Error: Size of BOTS and BOTNAMES does not match!"
    exit 1
fi

# Verzeichnis für Ergebnisse ablegen
mkdir -p results

for INDEX in "${!BOTS[@]}"
do
    BOT="${BOTS[$INDEX]}"
    BOTNAME="${BOTNAMES[$INDEX]}"
    ./start_single_contest.sh "$BOT" "$BOTNAME" "$NUMITER" "$OPTIONS" || exit 1
done



