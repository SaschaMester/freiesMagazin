#fm-pw6-forbiddenisle aka TomBot
##Bot for the Freies Magazin 6th programming challenge

TomBot is an open source bot available under GNU General Public License (GPLv3). See the LICENCE in the root directory for detailed licensing information.

For more Details about the challenge and the possibilities how to run the bot, please visit
http://www.freiesmagazin.de/sechster_programmierwettbewerb

Possibilities to improve:
* if the bot does not find a flooded field within direct range (current field or a neighbour) he chooses a random field to go. a strategy where to go would be nice
* refactoring, refactoring, refactoring :-)