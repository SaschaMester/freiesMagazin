/*
 * island.hpp
 * 
 * Copyright 2012 Robert Knauer <robert@privatdemail.net>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */
#ifndef ISLAND_HPP
#	define ISLAND_HPP
#	include <iostream>
#	include <assert.h>
#	include "field.hpp"

#	define DIRECTION_CURRENT 0
#	define DIRECTION_WEST 1
#	define DIRECTION_EAST 2
#	define DIRECTION_NORTH 3
#	define DIRECTION_SOUTH 4

	class Island
	{
		public:
			Island();
			virtual ~Island();
			void init(unsigned int width, unsigned int height);
			unsigned int get_width(void);
			unsigned int get_height(void);
			void set_field_type(unsigned int x, unsigned int y, unsigned int type);
			void init_end(void);
			void dump(void);
			unsigned int get_field_type(unsigned int x, unsigned int y);
			unsigned int get_field_type_dir(unsigned int direction);
			bool has_neighbour_field(unsigned int direction);
			float get_score(unsigned int x, unsigned int y, unsigned int layer=0);
			float get_score_dir(unsigned int direction);
			void move(unsigned int direction);
			void dry(unsigned int direction);
			void reset_cmdcounter(void);
			unsigned int get_cmdcounter(void);
			void set_position(unsigned int x, unsigned int y);
		private:
			unsigned int m_initstate;
			unsigned int m_width;
			unsigned int m_height;
			unsigned int m_cmdcounter;
			unsigned int m_posx;
			unsigned int m_posy;
			Field *m_fields;
	};
#endif // ISLAND_HPP
