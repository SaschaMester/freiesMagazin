/*
 * island.cpp
 * 
 * Copyright 2012 Robert Knauer <robert@privatdemail.net>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */
#include "island.hpp"

Island::Island() : m_initstate(0), m_cmdcounter(0)
{

}
Island::~Island()
{
	if (m_initstate >= 1) // init started
		delete[] m_fields;
}
void Island::init(unsigned int width, unsigned int height)
{
	assert(0 == m_initstate); // init not started
	/*
	 * Set sizes:
	*/
	m_width = width;
	m_height = height;
	/*
	 * Init field array:
	*/
	m_fields = new Field[width*height];
	/*
	 * Set initstate:
	*/
	m_initstate = 1; // init started
}
unsigned int Island::get_width(void)
{
	return m_width;
}
unsigned int Island::get_height(void)
{
	return m_height;
}
void Island::set_field_type(unsigned int x, unsigned int y, unsigned int type)
{
	assert(m_initstate >= 1); // init started
	m_fields[y*m_width+x].set_type(type);
}
void Island::init_end(void)
{
	m_initstate = 2; // init finished
}
void Island::dump(void)
{
	assert(m_initstate >= 2); // init finished
	/*
	 * Variable declarations:
	*/
	unsigned int i, j;
	/*
	 * Loops:
	*/
	std::cerr << "== MAP DUMP (" << m_width << "x" << m_height << ") ==" << std::endl;
	for (i=0; i < m_height; i++)
	{
		for (j=0; j < m_width; j++)
		{
			switch (m_fields[i*m_width+j].get_type())
			{
				case FIELD_TYPE_GONE:
					std::cerr << ".";
					break;
				case FIELD_TYPE_FLOODED:
					std::cerr << "o";
					break;
				case FIELD_TYPE_DRY:
					std::cerr << "#";
					break;
				default:
					std::cerr << "?";
			}
		}
		std::cerr << std::endl;
	}
	std::cerr << "== MAP DUMP (" << m_width << "x" << m_height << ") ==" << std::endl;
}
unsigned int Island::get_field_type(unsigned int x, unsigned int y)
{
	return m_fields[y*m_width+x].get_type();
}
unsigned int Island::get_field_type_dir(unsigned int direction)
{
	switch (direction)
	{
		case DIRECTION_CURRENT:
			return get_field_type(m_posx, m_posy);
		case DIRECTION_WEST:
			return get_field_type(m_posx-1, m_posy);
		case DIRECTION_EAST:
			return get_field_type(m_posx+1, m_posy);
		case DIRECTION_NORTH:
			return get_field_type(m_posx, m_posy-1);
		case DIRECTION_SOUTH:
			return get_field_type(m_posx, m_posy+1);
	}
	return 0;
}
bool Island::has_neighbour_field(unsigned int direction)
{
	switch (direction)
	{
		case DIRECTION_CURRENT:
			return true;
		case DIRECTION_WEST:
			return (m_posx > 0);
		case DIRECTION_EAST:
			return (m_posx+1 < get_width());
		case DIRECTION_NORTH:
			return (m_posy > 0);
		case DIRECTION_SOUTH:
			return (m_posy+1 < get_height());
	}
	return false;
}
float Island::get_score(unsigned int x, unsigned int y, unsigned int layer)
{
	/*
	 * Variable declarations:
	*/
	float score;
	/*
	 * Calculate initial score:
	*/
	switch (get_field_type(x, y))
	{
		case FIELD_TYPE_DRY:
			score = 2;
			break;
		case FIELD_TYPE_FLOODED:
			score = 1;
			break;
		case FIELD_TYPE_GONE:
			score = 0;
			break;
	}
	/*
	 * Calculate scores of the neighbour fields:
	*/
	if (layer < 5)
	{
		/*
		 * WEST
		*/
		if (x > 0)
			score += 0.5*get_score(x-1, y, layer+1);
		/*
		 * EAST
		*/
		if (x < m_width-1)
			score += 0.5*get_score(x+1, y, layer+1);
		/*
		 * NORTH
		*/
		if (y > 0)
			score += 0.5*get_score(x, y-1, layer+1);
		/*
		 * SOUTH
		*/
		if (y < m_height-1)
			score += 0.5*get_score(x, y+1, layer+1);
	};
	/*
	 * Return the result:
	*/
	return score;
}
float Island::get_score_dir(unsigned int direction)
{
	switch (direction)
	{
		case DIRECTION_CURRENT:
			return get_score(m_posx, m_posy);
		case DIRECTION_WEST:
			return get_score(m_posx-1, m_posy);
		case DIRECTION_EAST:
			return get_score(m_posx+1, m_posy);
		case DIRECTION_NORTH:
			return get_score(m_posx, m_posy-1);
		case DIRECTION_SOUTH:
			return get_score(m_posx, m_posy+1);
	}
	return 0;
}
void Island::move(unsigned int direction)
{
	/*
	 * Check for left CMDs:
	*/
	if (m_cmdcounter == 3)
	{
#ifdef DEBUG
		std::cerr << "BOT: No CMDs left to move " << direction << "." << std::endl;
#endif
		return;
	};
	/*
	 * Move:
	*/
	m_cmdcounter++;
	switch (direction)
	{
		case DIRECTION_CURRENT:
			std::cout << "GO CURRENT" << std::endl;
#ifdef DEBUG
			std::cerr << "BOT: Staying here." << std::endl;
#endif
			break;
		case DIRECTION_WEST:
			std::cout << "GO WEST" << std::endl;
			set_position(m_posx-1, m_posy);
#ifdef DEBUG
			std::cerr << "BOT: Going west... https://www.youtube.com/watch?v=cfGTm_viXPs" << std::endl;
#endif
			break;
		case DIRECTION_EAST:
			std::cout << "GO EAST" << std::endl;
			set_position(m_posx+1, m_posy);
#ifdef DEBUG
			std::cerr << "BOT: Going east." << std::endl;
#endif
			break;
		case DIRECTION_NORTH:
			std::cout << "GO NORTH" << std::endl;
			set_position(m_posx, m_posy-1);
#ifdef DEBUG
			std::cerr << "BOT: Going north." << std::endl;
#endif
			break;
		case DIRECTION_SOUTH:
			std::cout << "GO SOUTH" << std::endl;
			set_position(m_posx, m_posy+1);
#ifdef DEBUG
			std::cerr << "BOT: Going south." << std::endl;
#endif
			break;
	}
}
void Island::dry(unsigned int direction)
{
	/*
	 * Check for left CMDs:
	*/
	if (m_cmdcounter == 3)
	{
#ifdef DEBUG
		std::cerr << "BOT: No CMDs left to dry " << direction << "." << std::endl;
#endif
		return;
	};
	/*
	 * Dry:
	*/
	m_cmdcounter++;
	switch (direction)
	{
		case DIRECTION_CURRENT:
			std::cout << "DRY CURRENT" << std::endl;
			set_field_type(m_posx, m_posy, FIELD_TYPE_DRY);
#ifdef DEBUG
			std::cerr << "BOT: My field is now dry." << std::endl;
#endif
			break;
		case DIRECTION_WEST:
			std::cout << "DRY WEST" << std::endl;
			set_field_type(m_posx-1, m_posy, FIELD_TYPE_DRY);
#ifdef DEBUG
			std::cerr << "BOT: WEST field is now dry." << std::endl;
#endif
			break;
		case DIRECTION_EAST:
			std::cout << "DRY EAST" << std::endl;
			set_field_type(m_posx+1, m_posy, FIELD_TYPE_DRY);
#ifdef DEBUG
			std::cerr << "BOT: EAST field is now dry." << std::endl;
#endif
			break;
		case DIRECTION_NORTH:
			std::cout << "DRY NORTH" << std::endl;
			set_field_type(m_posx, m_posy-1, FIELD_TYPE_DRY);
#ifdef DEBUG
			std::cerr << "BOT: NORTH field is now dry." << std::endl;
#endif
			break;
		case DIRECTION_SOUTH:
			std::cout << "DRY SOUTH" << std::endl;
			set_field_type(m_posx, m_posy+1, FIELD_TYPE_DRY);
#ifdef DEBUG
			std::cerr << "BOT: SOUTH field is now dry." << std::endl;
#endif
			break;
	}
}
void Island::reset_cmdcounter(void)
{
	m_cmdcounter = 0;
}
unsigned int Island::get_cmdcounter(void)
{
	return m_cmdcounter;
}
void Island::set_position(unsigned int x, unsigned int y)
{
	m_posx = x;
	m_posy = y;
}
