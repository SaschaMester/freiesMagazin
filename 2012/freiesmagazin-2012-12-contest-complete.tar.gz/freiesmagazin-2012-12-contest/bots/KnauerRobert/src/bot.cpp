/*
 * bot.cpp
 * 
 * Copyright 2012 Robert Knauer <robert@privatdemail.net>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */
#include "bot.hpp"

Bot::Bot()
{

}
Bot::~Bot()
{

}
void Bot::get_map(void)
{
	/*
	 * Variable declarations:
	*/
	char c_line[1000];
	std::string line;
	unsigned int i, j;
	/*
	 * First loop, waiting for GAMEBOARDSTART:
	*/
	while (true)
	{
		/*
		 * Get line & convert:
		*/
		std::cin.getline(c_line, sizeof(c_line));
		line = std::string(c_line);
		/*
		 * Check for GAMEBOARDSTART command:
		*/
		if (line.substr(0, 14).compare("GAMEBOARDSTART") == 0)
		{
			/*
			 * Init island with the values:
			*/
			m_island.init(
				atoi(line.substr(15, line.find_first_of(",")-15).c_str()), // width
				atoi(line.substr(line.find_first_of(",")+1).c_str()) // height
			);
			break;
		}
	}
	/*
	 * Second loop, wait for map:
	*/
	for (i=0; i < m_island.get_height(); i++)
	{
		/*
		 * Get line:
		*/
		std::cin.getline(c_line, sizeof(c_line));
		/*
		 * Run through chars:
		*/
		for (j=0; j < m_island.get_width(); j++)
		{
			if (c_line[j] == '.')
				m_island.set_field_type(j, i, FIELD_TYPE_GONE);
			else if (c_line[j] == 'o')
				m_island.set_field_type(j, i, FIELD_TYPE_FLOODED);
			else if (c_line[j] == '#')
				m_island.set_field_type(j, i, FIELD_TYPE_DRY);
		}
	}
	/*
	 * Check for GAMEBOARDEND:
	*/
	std::cin.getline(c_line, sizeof(c_line));
	assert(std::string(c_line).compare("GAMEBOARDEND") == 0);
	/*
	 * ... and finish initializing:
	*/
	m_island.init_end();
	/*
	 * Dump:
	*/
#ifdef DEBUG
	m_island.dump();
#endif
}
bool Bot::fetch_commands(void)
{
	/*
	 * Variable declarations:
	*/
	char c_line[1000];
	std::string line;
	unsigned int round, x, y;
	/*
	 * Get line & convert:
	*/
	std::cin.getline(c_line, sizeof(c_line));
	line = std::string(c_line);
	/*
	 * Check for content:
	*/
	if (line.substr(0, 5).compare("ROUND") == 0)
	{
		/*
		 * New round started, we have to submit 3 commands
		 * Extract arguments (WARNING: x & y are with base [1,1] instead of [0,0])
		*/
		round = atoi(line.substr(6, line.find_last_of(" ")-6).c_str());
		x = atoi(line.substr(line.find_last_of(" "), line.find_first_of(",")-line.find_last_of(" ")).c_str());
		y = atoi(line.substr(line.find_first_of(",")+1).c_str());
#ifdef DEBUG
		std::cerr << "BOT: ===> ROUND called (round=" << round << ",x_outfmt=" << x << ",y_outfmt=" << y << ")" << std::endl;
#endif
		return handler_round(round, x-1, y-1);
	}
	else if (line.substr(0, 9).compare("INCRFLOOD") == 0)
	{
		/*
		 * Flood increased
		*/
		round = atoi(line.substr(10).c_str());
#ifdef DEBUG
		std::cerr << "BOT: INCRFLOOD called (incr=" << round << ")" << std::endl;
#endif
		return handler_incrflood(round);
	}
	else if (line.substr(0, 5).compare("FLOOD") == 0)
	{
		/*
		 * Field flooded
		 * Extract arguments (WARNING: x & y are with base [1,1] instead of [0,0])
		*/
		x = atoi(line.substr(6, line.find_first_of(",")-6).c_str());
		y = atoi(line.substr(line.find_first_of(",")+1).c_str());
#ifdef DEBUG
		std::cerr << "BOT: FLOOD called (x_outfmt=" << x << ",y_outfmt=" << y << ")" << std::endl;
#endif
		return handler_flood(x, y);
	}
	else if (line.substr(0, 3).compare("END") == 0)
	{
		/*
		 * Game over
		*/
#ifdef DEBUG
		std::cerr << "BOT: Game over" << std::endl;
#endif
		return false;
	}
	else
	{
		/*
		 * Invalid command
		*/
		std::cerr << "BOT: Invalid command " << line << std::endl;
		return false;
	};
}
bool Bot::handler_round(unsigned int round, unsigned int x, unsigned int y)
{
	/*
	 * Variable declarations:
	*/
	unsigned int i;
	int best_field;
	float best_field_score;
	/*
	 * Reset cmdcounter:
	*/
	m_island.reset_cmdcounter();
	/*
	 * Set position:
	*/
	m_island.set_position(x, y);
	/*
	 * Dry fields:
	*/
	for (i=DIRECTION_CURRENT; i <= DIRECTION_SOUTH; i++)
	{
		if (m_island.has_neighbour_field(i) && m_island.get_field_type_dir(i) == FIELD_TYPE_FLOODED)
			m_island.dry(i);
	}
	/*
	 * Move to the dry field with the best score:
	*/
	best_field = -1;
	for (i=DIRECTION_CURRENT; i <= DIRECTION_SOUTH; i++)
	{
		if (m_island.has_neighbour_field(i) && m_island.get_field_type_dir(i) == FIELD_TYPE_DRY && (m_island.get_score_dir(i) > best_field_score || best_field == -1))
		{
			best_field = i;
			best_field_score = m_island.get_score_dir(i);
		}
	}
	if (best_field != -1)
	{
		/*
		 * Move!
		*/
		m_island.move(best_field);
	}
	else
	{
		/*
		 * Move to the flooded field with the best score:
		*/
		best_field = -1;
		for (i=DIRECTION_CURRENT; i <= DIRECTION_SOUTH; i++)
		{
			if (m_island.has_neighbour_field(i) && m_island.get_field_type_dir(i) == FIELD_TYPE_FLOODED && (m_island.get_score_dir(i) > best_field_score || best_field == -1))
			{
				best_field = i;
				best_field_score = m_island.get_score_dir(i);
			}
		}
		if (best_field != -1)
		{
			/*
			 * Move!
			*/
			m_island.move(best_field);
		};
	};
	/*
	 * Waste the rest of the commands:
	*/
	while (m_island.get_cmdcounter() < 3)
	{
		m_island.move(DIRECTION_CURRENT);
	}
	return true;
}
bool Bot::handler_flood(unsigned int x, unsigned int y)
{
	/*
	 * Set the field as flooded / gone:
	*/
	if (m_island.get_field_type(x-1, y-1) == FIELD_TYPE_DRY)
	{
#ifdef DEBUG
		std::cerr << "BOT: Field [" << x << "," << y << "] (outer fmt) or [" << x-1 << "," << y-1 << "] (inner fmt) is now flooded." << std::endl;
#endif
		m_island.set_field_type(x-1, y-1, FIELD_TYPE_FLOODED);
	}
	else if (m_island.get_field_type(x-1, y-1) == FIELD_TYPE_FLOODED)
	{
#ifdef DEBUG
		std::cerr << "BOT: Field [" << x << "," << y << "] (outer fmt) or [" << x-1 << "," << y-1 << "] (inner fmt) is now gone." << std::endl;
#endif
		m_island.set_field_type(x-1, y-1, FIELD_TYPE_GONE);
	};
	return true;
}
bool Bot::handler_incrflood(unsigned int incr)
{
	return true;
}
