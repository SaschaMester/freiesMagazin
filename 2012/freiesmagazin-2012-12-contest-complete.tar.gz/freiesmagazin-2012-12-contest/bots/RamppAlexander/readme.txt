Compiling
---------
Mit `ant dist` kann eine jar datei erstellt werden. Evtl. muss dazu die Property
"scala.home" in build.xml angepasst werden.

Auf Ubuntu 12.10 ist dies /usr/share/java
auf Arch Linux Systemen /usr/share/lib

Ausführen
---------
Der bot wird wie folgt gestartet:
`bots/bitschupser/bot.jar`
Er wartet nun auf STDIN auf Daten des Wettbewerbsservers.

Folgender Aufruf startet den Bot im Kontext des Wettbewerbsservers und spielt
100 Spiele:
./start_single_contest.sh "scala bots/bitschupser/bot.jar"
BitSchupser_move_to_dry 100 

Abhängigkeiten
--------------
- bot.jar bauen:
-- scala-compiler.jar
-- scala-library.jar
   (alle in der Standartdistribution von Scala)

- Unit tests ausführen:
-- mockito-all-1.9.5.jar
-- scalatest_2.9.0-1.8.jar


Der Bot wurde mit Scala 2.10.0-20121205-235900-18481cef9b erfolgreich gebaut und
getestet.

