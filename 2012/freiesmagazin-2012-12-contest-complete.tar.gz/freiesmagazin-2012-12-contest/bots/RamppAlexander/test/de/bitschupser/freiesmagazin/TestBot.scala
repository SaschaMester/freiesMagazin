/*            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *                   Version 2, December 2004
 *
 * Copyright (C) 2004 Sam Hocevar
 * 14 rue de Plaisance, 75014 Paris, France
 * Everyone is permitted to copy and distribute verbatim or modified
 * copies of this license document, and changing it is allowed as long
 * as the name is changed.
 * 
 *           DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *  TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
 *
 * 0. You just DO WHAT THE FUCK YOU WANT TO.
 */
package de.bitschupser.freiesmagazin

import org.scalatest.matchers.ShouldMatchers
import org.scalatest.FunSpec
import org.scalatest.OneInstancePerTest
import org.scalatest.FlatSpec
import java.io.ByteArrayOutputStream
import Direction._
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner
import de.bitschupser.freiesmagazin.exception.OutOfBoundsException
import TileState._

@RunWith(classOf[JUnitRunner])
class TestBot extends FlatSpec with ShouldMatchers with OneInstancePerTest {

  var board = new GameBoard(3, 4, "oooo\n####\n....")
  var out = new ByteArrayOutputStream
  var initialPos = (1, 1)
  var bot = new Bot(initialPos, board, out)

  "go" should "go north" in {
    bot go NORTH
    bot.position should equal(initialPos._1 - 1, initialPos._2)
    out.toString() should equal("GO NORTH\n")
  }

  it should "go south" in {
    bot go SOUTH
    bot.position should equal(initialPos._1 + 1, initialPos._2)
    out.toString() should equal("GO SOUTH\n")
  }

  it should "go west" in {
    bot go WEST
    bot.position should equal(initialPos._1, initialPos._2 - 1)
    out.toString() should equal("GO WEST\n")
  }

  it should "go east" in {
    bot go EAST
    bot.position should equal(initialPos._1, initialPos._2 + 1)
    out.toString() should equal("GO EAST\n")
  }

  it should "stand still" in {
    bot go CURRENT
    bot.position should equal(initialPos._1, initialPos._2)
    out.toString() should equal("GO CURRENT\n")
  }

  it should "throw an exception when going out of the gameboard" in {
    while (bot.position._1 > 0) {
      bot go NORTH
    }
    evaluating { bot go NORTH } should produce[OutOfBoundsException]
  }

  ////////////////
  "dry" should "dry north" in {
    bot dry NORTH
    out.toString() should equal("DRY NORTH\n")
  }

  it should "dry south" in {
    board.tile(initialPos._1 + 1)(initialPos._2) = FLODDED
    bot dry SOUTH
    out.toString() should equal("DRY SOUTH\n")
  }

  it should "dry west" in {
    bot dry WEST
    out.toString() should equal("DRY WEST\n")
  }

  it should "dry east" in {
    bot dry EAST
    out.toString() should equal("DRY EAST\n")
  }

  it should "dry the current position" in {
    bot dry CURRENT
    out.toString() should equal("DRY CURRENT\n")
  }

  it should "throw an exception when drying out of the gameboard north" in {
    bot.position = (0, 1)
    evaluating { bot dry NORTH } should produce[OutOfBoundsException]
  }
  it should "throw an exception when drying out of the gameboard south" in {
    bot.position = (board.rows - 1, 1)
    evaluating { bot dry SOUTH } should produce[OutOfBoundsException]
  }
  it should "throw an exception when drying out of the gameboard west" in {
    bot.position = (1, 0)
    evaluating { bot dry WEST } should produce[OutOfBoundsException]
  }
  it should "throw an exception when drying out of the gameboard east" in {
    bot.position = (1, board.cols - 1)
    evaluating { bot dry EAST } should produce[OutOfBoundsException]
  }

  it should "update the field if it has been flooded" in {
    bot dry NORTH
    board.tile(initialPos._1 - 1)(initialPos._2) should be(DRY)
  }

  it should "throw an Exception if we try to dry lost fields" in {
    evaluating { bot dry SOUTH } should produce[IllegalArgumentException]
  }
}