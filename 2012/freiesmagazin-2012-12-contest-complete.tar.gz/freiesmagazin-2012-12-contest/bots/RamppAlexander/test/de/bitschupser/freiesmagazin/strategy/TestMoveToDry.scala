/*            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *                   Version 2, December 2004
 *
 * Copyright (C) 2004 Sam Hocevar
 * 14 rue de Plaisance, 75014 Paris, France
 * Everyone is permitted to copy and distribute verbatim or modified
 * copies of this license document, and changing it is allowed as long
 * as the name is changed.
 * 
 *           DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *  TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
 *
 * 0. You just DO WHAT THE FUCK YOU WANT TO.
 */
package de.bitschupser.freiesmagazin.strategy

import org.junit.runner.RunWith
import org.scalatest.OneInstancePerTest
import org.scalatest.matchers.ShouldMatchers
import org.scalatest.FlatSpec
import org.scalatest.junit.JUnitRunner
import org.scalatest.mock.MockitoSugar
import de.bitschupser.freiesmagazin.GameBoard
import de.bitschupser.freiesmagazin.Bot
import org.scalatest.PrivateMethodTester
import org.scalatest.PrivateMethodTester.PrivateMethod
import org.mockito.Mockito._
import de.bitschupser.freiesmagazin.TileState._
import de.bitschupser.freiesmagazin.Direction._

@RunWith(classOf[JUnitRunner])
class TestMoveToDry extends FlatSpec with MockitoSugar with ShouldMatchers with OneInstancePerTest with PrivateMethodTester {

  val bot = mock[Bot]
  val board = mock[GameBoard]
  when(board.tile) thenReturn Array(Array(DRY, DRY, DRY),
    Array(LOST, FLODDED, DRY),
    Array(LOST, FLODDED, LOST))
  when(board.rows) thenReturn 3
  when(board.cols) thenReturn 3
  val strategy = new MoveToDry(bot, board)

  val getDryNeighbours = PrivateMethod[Int]('getDryNeighbours)
  val playStep = PrivateMethod[Unit]('playStep)

  /////////////////////////////////
  "getDryNeighbours" should "return the right number of dry fields in neighbourhood" in {
    val dryFiels = strategy invokePrivate getDryNeighbours(1, 1)
    dryFiels should equal(4)
  }

  it should "work at position (0,0)" in {
    val dryFields = strategy invokePrivate getDryNeighbours(0, 0)
    dryFields should equal(2)
  }

  it should "work at the position lower right" in {
    val dryFields = strategy invokePrivate getDryNeighbours(2, 2)
    dryFields should equal(1)
  }

  /////////////////////////////////
  "playStep" should "move to a a place with more dry fields" in {
    when(bot.position) thenReturn Tuple2(2, 1)
    strategy invokePrivate playStep()
    verify(bot) go NORTH
  }

  it should "dry if its on the best position" in {
    when(bot.position) thenReturn Tuple2(1, 1)
    strategy invokePrivate playStep()
    verify(bot) dry CURRENT
  }

  it should "do nothing if there are no flooded fields" in {
    when(board.tile) thenReturn Array(Array(DRY, DRY, DRY),
      Array(DRY, DRY, DRY),
      Array(DRY, DRY, DRY))
    when(bot.position) thenReturn Tuple2(1, 1)
    strategy invokePrivate playStep()
    verify(bot) go CURRENT
  }

}