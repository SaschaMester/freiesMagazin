/*            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *                   Version 2, December 2004
 *
 * Copyright (C) 2004 Sam Hocevar
 * 14 rue de Plaisance, 75014 Paris, France
 * Everyone is permitted to copy and distribute verbatim or modified
 * copies of this license document, and changing it is allowed as long
 * as the name is changed.
 * 
 *           DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *  TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
 *
 * 0. You just DO WHAT THE FUCK YOU WANT TO.
 */
package de.bitschupser.freiesmagazin

import org.scalatest.FunSpec
import org.scalatest.matchers.ShouldMatchers
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

import TileState._

@RunWith(classOf[JUnitRunner])
class TestGameBoard extends FunSpec with ShouldMatchers{
  
  describe ("Constructor") {
    it ("should parse the Gameboard") {
      val gb = new GameBoard(2, 2, "oo\n.#")
      
//      gb.tile shold have length(2)  // why does it not work?
//      println (gb.toString)
      gb.tile(0) should have length(2)
      gb.tile(0)(0) should be(FLODDED)
      gb.tile(0)(1) should be(FLODDED)
      gb.tile(1)(0) should be(LOST)
      gb.tile(1)(1) should be(DRY)

          }
  }
  
  describe ("Flood") {
    val gb = new GameBoard(2, 2, "oo\n.#")
    
    it("should make a dry tile flodded") {
      gb.flood(1,1)
      gb.tile(1)(1) should be(FLODDED)
    }
    
    it("should make a flooded tile lost") {
      gb.flood(0, 0)
      gb.tile(0)(0) should be(LOST)
    }
    
    it("should leave a lost tile lost") {
      gb.flood(1, 0)
      gb.tile(1)(0) should be(LOST)
    }
    
  }
  

}