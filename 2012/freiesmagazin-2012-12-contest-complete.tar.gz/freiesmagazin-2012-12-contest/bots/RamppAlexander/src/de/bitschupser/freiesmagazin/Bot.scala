/*            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *                   Version 2, December 2004
 *
 * Copyright (C) 2004 Sam Hocevar
 * 14 rue de Plaisance, 75014 Paris, France
 * Everyone is permitted to copy and distribute verbatim or modified
 * copies of this license document, and changing it is allowed as long
 * as the name is changed.
 * 
 *           DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *  TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
 *
 * 0. You just DO WHAT THE FUCK YOU WANT TO.
 */
package de.bitschupser.freiesmagazin

import java.io.OutputStream
import java.io.BufferedWriter
import java.io.PrintWriter
import de.bitschupser.freiesmagazin.Direction._
import de.bitschupser.freiesmagazin.exception.OutOfBoundsException
import java.io.PrintStream
import TileState._

/**
 * Bot represents the player that can move around the game board and dry fields.
 * 
 * @param position the initial position of the bot on the game board
 * @param board the game board this bot is playing on
 * @param out an output stream where the bot writes the commands while playing 
 */
class Bot(var position: Tuple2[Int, Int], val board: GameBoard, out: OutputStream) {
  val writer = new PrintStream(out, true)

  /** A convenience constructor that uses java.lang.System.out as output stream */
  def this(position: Tuple2[Int, Int], board: GameBoard) = this(position, board, System.out)
  
  /** Moves to the given position */
  def go(dir: Direction) {
    position  = calcPosition(dir)
    writer.println("GO " + dir.toString)
  }
  
  /** Dries the field in the given position */
  def dry(dir: Direction) {
    val pos = calcPosition(dir) // throws exception if we go out of bounds
    if (board.tile(pos._1)(pos._2) != LOST) {
      writer.println("DRY " + dir.toString())
      board.tile(pos._1)(pos._2) = DRY
    } else {
      throw new IllegalArgumentException("You can not dry lost fields!")
    }
  }
  
  private def calcPosition (dir: Direction): Tuple2[Int, Int] = {
    
    def add(row: Int, col: Int) = {
      val result = (position._1 + row, position._2 + col)
      if (result._1 < 0 || result._1 >= board.rows ||
          result._2 < 0 || result._2 >= board.cols) {
        throw new OutOfBoundsException
      }
      result
    }
  
    
    dir match {
      case NORTH => add(-1, 0)
      case WEST => add(0, -1)
      case SOUTH => add(1, 0)
      case EAST => add(0, 1)
      case CURRENT => position
    }
  }
  
}