/*            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *                   Version 2, December 2004
 *
 * Copyright (C) 2004 Sam Hocevar
 * 14 rue de Plaisance, 75014 Paris, France
 * Everyone is permitted to copy and distribute verbatim or modified
 * copies of this license document, and changing it is allowed as long
 * as the name is changed.
 * 
 *           DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *  TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
 *
 * 0. You just DO WHAT THE FUCK YOU WANT TO.
 */
package de.bitschupser.freiesmagazin

import TileState._
import de.bitschupser.freiesmagazin.exception.OutOfBoundsException
import scala.util.Properties

/**
 * Gameboard
 *
 * @param x: height
 * @param y: width
 * @param data: String describing the gameboard as it comes from server
 */
class GameBoard(val rows: Int, val cols: Int, data: String) {

  val tile = init(data)

  def flood(row: Int, col: Int) {
    tile(row)(col) = tile(row)(col) match {
      case DRY => FLODDED
      case FLODDED => LOST
      case LOST => LOST
    }
  }

  override def toString = {
    val result = new StringBuffer()
    for (row <- 0 until rows) {
      result append tile(row).map(x => x match {
        case LOST => '.'
        case FLODDED => 'o'
        case DRY => '#'
      })
      result append Properties.lineSeparator
    }
    result.toString
  }

  /**
   * Parses the game board data and returns an array of containing the game board.
   */
  private def init(data: String) = {
    val tile = Array.ofDim[TileState](rows, cols)
    var row = 0
    for (line <- data.lines) {
      tile(row) = line.map { c =>
        c match {
          case '.' => LOST
          case 'o' => FLODDED
          case '#' => DRY
        }
      }.toArray
      row += 1
    }
    tile
  }

}