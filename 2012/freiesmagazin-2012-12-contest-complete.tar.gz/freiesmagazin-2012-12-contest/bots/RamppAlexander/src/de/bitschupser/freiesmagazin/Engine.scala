/*            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *                   Version 2, December 2004
 *
 * Copyright (C) 2004 Sam Hocevar
 * 14 rue de Plaisance, 75014 Paris, France
 * Everyone is permitted to copy and distribute verbatim or modified
 * copies of this license document, and changing it is allowed as long
 * as the name is changed.
 * 
 *           DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *  TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
 *
 * 0. You just DO WHAT THE FUCK YOU WANT TO.
 */
package de.bitschupser.freiesmagazin

import java.lang.String
import scala.util.control.Breaks.{ break, breakable }
import de.bitschupser.freiesmagazin.strategy.DummyStrategy
import de.bitschupser.freiesmagazin.strategy.MoveToDry

/**
 * This is the entry point of the program, the engine communicates with the
 * server (threw stdin and stdout), initializes the game board, strategy and
 * bot, updates the game board and calls the play method of the strategy on 
 * every round. 
 */
object Engine {

  val RE_GAMEBOARD_START = """GAMEBOARDSTART (\d+),(\d+)""".r
  val GAMEBOARD_END = """GAMEBOARDEND"""
  val RE_ROUND = """ROUND (\d+) (\d+),(\d+)""".r
  val RE_INCRFLOOD = """INCRFLOOD (\d+)""".r
  val RE_FLOOD = """FLOOD (\d+),(\d+)""".r
  val RE_END = """END"""

  var board: GameBoard = null
  var bot: Bot = null
//  lazy val strategy = new DummyStrategy(bot, board)
  lazy val strategy = new MoveToDry(bot, board)

  def main(args: Array[String]): Unit = {
    
    /** Creates a 0-based tuple of the position. 
     * The first element will be rows, the second cols.*/
    def parsePos(x: String, y: String) =  (Integer.parseInt(y) - 1, Integer.parseInt(x) - 1)
    
    // main loop of the program
    while (true) {
      var cur = readLine
      cur match {
        case RE_GAMEBOARD_START(x, y) => {
          var line: String = ""
          var buf = new StringBuffer
          val pos = parsePos(x, y)

          breakable {
            while (true) {
              line = readLine
              if (!(line equals GAMEBOARD_END)) {
                buf append line + "\n"
              } else {
                board = new GameBoard(pos._1 + 1, pos._2 + 1, buf.toString)
                break
              }
            }
          }
        }
        
        case RE_ROUND(z, x, y) => {
          val round = Integer.parseInt(z)
          val pos = parsePos(x, y)
          assert(board != null)
          if (bot == null) {
            bot = new Bot(pos, board, System.out)
          }
          assert(bot.position == pos)
          strategy.play
        }
        
        case RE_INCRFLOOD(z) => {
          strategy.flood += Integer.parseInt(z)
        }
        
        case RE_FLOOD(x, y) => {
          val pos = parsePos(x, y)
          board.flood(pos._1, pos._2)
        }
        
        case RE_END => {
          return
        }
        
//        case _ => {
//          System.err.println("ERR: " + cur)
//        }

      }

    }

  }
}