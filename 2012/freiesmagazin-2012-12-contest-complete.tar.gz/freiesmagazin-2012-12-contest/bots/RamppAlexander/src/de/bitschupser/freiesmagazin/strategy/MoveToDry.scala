/*            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *                   Version 2, December 2004
 *
 * Copyright (C) 2004 Sam Hocevar
 * 14 rue de Plaisance, 75014 Paris, France
 * Everyone is permitted to copy and distribute verbatim or modified
 * copies of this license document, and changing it is allowed as long
 * as the name is changed.
 * 
 *           DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *  TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
 *
 * 0. You just DO WHAT THE FUCK YOU WANT TO.
 */
package de.bitschupser.freiesmagazin.strategy

import de.bitschupser.freiesmagazin.Bot
import de.bitschupser.freiesmagazin.Direction._
import de.bitschupser.freiesmagazin.GameBoard
import de.bitschupser.freiesmagazin.TileState._
import de.bitschupser.freiesmagazin.util.TupleArithmetic
import scala.collection.mutable.Map
import de.bitschupser.freiesmagazin.Direction

/**
 * Tries to move to the position where most fields are dry. If it is there it dries its neighbor fields.
 */
class MoveToDry(val bot: Bot, val board: GameBoard) extends Strategy {

  val direction = Map(
    NORTH -> (-1, 0),
    EAST -> (0, 1),
    SOUTH -> (1, 0),
    WEST -> (0, -1),
    CURRENT -> (0, 0))

  def play(): Unit = {
      for (i <- 0 to 2) {
        playStep
      }
  }

  private def getDryNeighbours(row: Int, col: Int): Int = {
    var dry = 0
    for {
      r <- row - 1 to row + 1
      c <- col - 1 to col + 1
      if r >= 0 && c >= 0
      if r < board.rows && c < board.cols
      if board.tile(r)(c) == DRY
    } {
      dry += 1
    }
    dry
  }

  private def playStep(): Unit = {
    // search for the field with the most dry fields in neighbourhood
    var maxDryField = (CURRENT -> 0)
    
    direction.keys.foreach { dir =>
      val p = TupleArithmetic.add(bot.position, direction.get(dir).get)
      if (p._1 >= 0 && p._2 >= 0 && p._1 < board.rows && p._2 < board.cols) {
        if (board.tile(p._1)(p._2) != LOST) {
          val dryFields = getDryNeighbours(p._1, p._2)
          if (dryFields > maxDryField._2) {
            maxDryField = (dir -> dryFields)
          }
        }
      }
    }
    
    // move to the max dry field
    if (maxDryField._1 != CURRENT) {
      bot go maxDryField._1
    } // if standing on maxDry then try to dry neighbourfields
    else {
      direction.keys.foreach { dir =>
        val p = TupleArithmetic.add(bot.position, direction.get(dir).get)
        if(board.tile(p._1)(p._2) == FLODDED) {
          bot dry dir
          return
        }
      }
      
      // if we land here, there are no flooded fields
      bot go CURRENT
    }
  }

}