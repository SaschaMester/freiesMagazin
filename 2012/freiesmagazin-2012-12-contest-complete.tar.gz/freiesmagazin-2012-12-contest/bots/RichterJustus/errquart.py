#!/usr/bin/env python

'''
Bot for 6th programming competition organized by Freies Magazin
Copyright (C) 2012 Justus Richter

Thanks a lot for the people at:
http://forum.ubuntuusers.de/topic/python-mehrfach-ueber-liste-iterieren/

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys
import re
import numpy
import itertools

def init(felder):
    global zeilen,spalten
    karte = numpy.zeros((spalten, zeilen))
    summe = 0
    for i in range(spalten):
        for j in range(zeilen):
            if felder[j][i] == '.':
                karte[i][j] = 0
            elif felder[j][i] == 'o':
                karte[i][j] = 1
                summe += 1
            elif felder[j][i] == '#':
                karte[i][j] = 2
                summe += 2
            else:
                print 'Fehler bei Feld:', i,j,felder[j][i]
    return karte
    
def spiele(pos_x, pos_y, karte, moeglich):
    maximum = -1.0
    for i in moeglich:
        x1,y1,kopie1,abbruch = simuliere(pos_x, pos_y, karte.copy(), i)
        if abbruch == 1:
            continue
        for j in moeglich:
            x2,y2,kopie2,abbruch = simuliere(x1, y1, kopie1.copy(), j)
            if abbruch == 1:
                continue
            for k in moeglich:
                x3,y3,kopie3,abbruch = simuliere(x2, y2, kopie2.copy(), k)
                if abbruch == 1:
                    continue
                trocknung = 0
                for l in [i,j,k]:
                    if l[0] == 'DRY':
                        trocknung += 1
                wert_feld, wert_trocken = bewerte(x3,y3,kopie3)
                wert = (wert_feld/10 + 3*wert_trocken/3)/4 + trocknung
                if wert > maximum:
                    maximum = wert
                    ziel = [i,j,k]
                    #print >> sys.stderr, wert_feld, wert_trocken, trocknung
    x1,y1,karte,abbruch = simuliere(pos_x,pos_y,karte,ziel[0])
    x2,y2,karte,abbruch = simuliere(x1,y1,karte,ziel[1])
    x3,y3,karte,abbruch = simuliere(x2,y2,karte,ziel[2])
    for i in range(len(ziel)):
        if ziel[i][1] == [0, -1]:
            richtung = 'NORTH'
        elif ziel[i][1] == [0, 1]:
            richtung = 'SOUTH'
        elif ziel[i][1] == [1, 0]:
            richtung = 'EAST'
        elif ziel[i][1] == [-1, 0]:
            richtung = 'WEST'
        elif ziel[i][1] == [0, 0]:
            richtung = 'CURRENT'
        ziel[i] = ziel[i][0] + ' ' + richtung
    return ziel

def simuliere(pos_x, pos_y, karte, spielzug):
    global zeilen,spalten
    x = pos_x + int(spielzug[1][0])
    y = pos_y + int(spielzug[1][1])
    if not(0 <= x < spalten) or not(0 <= y < zeilen) or (karte[x][y] == 0):
        return pos_x,pos_y,karte,1
    if spielzug[0] == 'GO':
        pos_x, pos_y = x,y
    elif spielzug[0] == 'DRY':
        if karte[x][y] == 1:
            karte[x][y] = 2
        else:
            return pos_x,pos_y,karte,1
    return pos_x,pos_y,karte,0
    
def bewerte(pos_x,pos_y,karte):
    global zeilen,spalten
    feld = 0.0
    trocken = 0.0
    for i,j in erreichbar(pos_x,pos_y,karte):
        wert = karte[i][j]
        feld += wert
        if wert == 1:
            trocken += 1
    if karte[pos_x][pos_y] != 2:
        return 0.0, 0.0
    return feld, trocken

def erreichbar(pos_x,pos_y,karte):
    global gehen
    liste = {(pos_x,pos_y)}
    for i in gehen:
        x1,y1,kopie1,abbruch = simuliere(pos_x, pos_y, karte.copy(), i)
        if abbruch == 1:
            continue
        for j in gehen:
            x2,y2,kopie2,abbruch = simuliere(x1, y1, kopie1.copy(), j)
            if abbruch == 1:
                continue
            liste.add((x2,y2))
    return liste

def main():
    global zeilen,spalten, runde, gehen
    readline = sys.stdin.readline
    aktion = ['GO', 'DRY']
    delta_pos = [[ 0,-1], [ 0, 1], [ 1, 0], [-1, 0], [ 0, 0]]
    moeglich = []
    for i,j in itertools.product(aktion, delta_pos):
        moeglich.append([i,j])
    gehen = []
    for i in delta_pos:
        gehen.append(['GO', i])
    flut_steig = 0
    anweisung = readline()
    anweisung = anweisung.split()
    while anweisung[0] != 'END':
        if anweisung[0] == 'GAMEBOARDSTART':
            anweisung[1] = anweisung[1].split(r",")
            spalten = int(anweisung[1][0])
            zeilen = int(anweisung[1][1])
            felder = [0 for i in range(zeilen)]
            for i in range(zeilen):
                felder[i] = readline()
                felder[i] = felder[i].strip()
            if readline() != 'GAMEBOARDEND\n':
                print 'Fehler beim Einlesen der Felder!'
            karte = init(felder)
        elif anweisung[0] == 'ROUND':
            runde = anweisung[1]
            anweisung[2] = anweisung[2].split(r",")
            pos_x = int(anweisung[2][0])-1
            pos_y = int(anweisung[2][1])-1
            ziel = spiele(pos_x,pos_y,karte,moeglich)
            for i in ziel:
                print i 
            sys.stdout.flush()
        elif anweisung[0] == 'FLOOD':
            anweisung[1] = anweisung[1].split(r",")
            flut_x = int(anweisung[1][0])-1
            flut_y = int(anweisung[1][1])-1
            karte[flut_x][flut_y] -= 1
        elif anweisung[0] == 'INCRFLOOD':
            flut_steig += int(anweisung[1])
        else:
            print 'fehlerhafte Eingabe!'
            break
        anweisung = readline()
        anweisung = anweisung.split()

if __name__ == "__main__":
    main()
