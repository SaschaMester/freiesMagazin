/**
 *  (C) Copyright 2012 Dominik Wagenfuehr, Markus Braun
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation; either version 3 of the
 *  License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this program. If not, see
 *  <http://www.gnu.org/licenses/>.
 */
#include <stdlib.h>
#include "Field.hh"

Field::Field (FieldType type) : mType(type)
{
}


Field::~Field ()
{
}


void Field::setLand()
{
  mType = FieldTypeLand;
}


void Field::setFlooded()
{
  mType = FieldTypeFlooded;
}


void Field::setWater()
{
  mType = FieldTypeWater;
}

void Field::flood()
{
  switch (mType) {
    case FieldTypeLand:
      mType = FieldTypeFlooded;
      break;
  
    case FieldTypeFlooded:
      mType = FieldTypeWater;
      break;
  
    case FieldTypeWater:
      mType = FieldTypeUnknown;
#ifdef MBR_DEBUG
      abort();
#endif
      break;
  
    default:
      mType = FieldTypeUnknown;
#ifdef MBR_DEBUG
      abort();
#endif
      break;
  }
}


void Field::drain()
{
  switch (mType) {
    case FieldTypeLand:
      mType = FieldTypeLand;
      break;
  
    case FieldTypeFlooded:
      mType = FieldTypeLand;
      break;
  
    case FieldTypeWater:
      mType = FieldTypeUnknown;
#ifdef MBR_DEBUG
      abort();
#endif
      break;
  
    default:
      mType = FieldTypeUnknown;
#ifdef MBR_DEBUG
      abort();
#endif
      break;
  }
}


bool Field::isLand()
{
  return(mType == FieldTypeLand);
}


bool Field::isFlooded()
{
  return(mType == FieldTypeFlooded);
}


bool Field::isWater()
{
  return(mType == FieldTypeWater);
}


bool Field::isSave()
{
  bool ret;

  if (mType == FieldTypeLand) {
    ret = true;
  }
  else {
    ret = false;
  }

  return(ret);
}
