/**
 *  (C) Copyright 2012 Dominik Wagenfuehr, Markus Braun
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation; either version 3 of the
 *  License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this program. If not, see
 *  <http://www.gnu.org/licenses/>.
 */

#include "CommandChain.hh"

CommandChain::CommandChain()
{
  this->resetScore();
}


CommandChain::~CommandChain()
{
}

#include <iostream>
void CommandChain::setChain(std::vector<Command>& chain)
{
  mChain = chain;
}


void CommandChain::appendCommandToChain(Command command)
{
  mChain.push_back(command);
}


void CommandChain::dropLastCommandInChain()
{
  mChain.resize(mChain.size() - 1);
}


void CommandChain::resetScore()
{
  mValid = false;
  mPlayScore = 0.0;
  mFutureScore = 0.0;
}


void CommandChain::setValid(bool valid)
{
  mValid = valid;
}


void CommandChain::setPlayScore(double score)
{
  mPlayScore = score;
}


void CommandChain::setFutureScore(double score)
{
  mFutureScore = score;
}


void CommandChain::changePlayScore(double score)
{
  mPlayScore += score;
}


void CommandChain::changeFutureScore(double score)
{
  mFutureScore += score;
}


bool operator==(const CommandChain& lhs, const CommandChain& rhs)
{
  return(lhs.getCombineScore() == rhs.getCombineScore());
}


bool operator>(const CommandChain& lhs, const CommandChain& rhs)
{
  return(lhs.getCombineScore() > rhs.getCombineScore());
}

bool operator>=(const CommandChain& lhs, const CommandChain& rhs)
{
  return(lhs.getCombineScore() >= rhs.getCombineScore());
}


bool operator<(const CommandChain& lhs, const CommandChain& rhs)
{
  return(lhs.getCombineScore() < rhs.getCombineScore());
}


bool operator<=(const CommandChain& lhs, const CommandChain& rhs)
{
  return(lhs.getCombineScore() <= rhs.getCombineScore());
}


const std::vector<Command>& CommandChain::getChain() const
{
  return(mChain);
}


bool CommandChain::getValid() const
{
  return(mValid);
}


double CommandChain::getPlayScore() const
{
  return(mPlayScore);
}


double CommandChain::getFutureScore() const
{
  return(mFutureScore);
}


double CommandChain::getCombineScore() const
{
  return(mPlayScore + mFutureScore / 4.0);
}


std::vector<std::string> CommandChain::toString() const
{
  std::vector<std::string> commands;

  for (std::vector<Command>::const_iterator iter = mChain.begin() ; iter != mChain.begin() + 3 && iter != mChain.end() ; iter++) {
    switch (*iter) {
      case CommandDryCurrent:
        commands.push_back("DRY CURRENT");
        break;

      case CommandDryNorth:
        commands.push_back("DRY NORTH");
        break;

      case CommandDrySouth:
        commands.push_back("DRY SOUTH");
        break;

      case CommandDryWest:
        commands.push_back("DRY WEST");
        break;

      case CommandDryEast:
        commands.push_back("DRY EAST");
        break;

      case CommandGoCurrent:
        commands.push_back("GO CURRENT");
        break;

      case CommandGoNorth:
        commands.push_back("GO NORTH");
        break;

      case CommandGoSouth:
        commands.push_back("GO SOUTH");
        break;

      case CommandGoWest:
        commands.push_back("GO WEST");
        break;

      case CommandGoEast:
        commands.push_back("GO EAST");
        break;
    }
  }

  return(commands);
}


