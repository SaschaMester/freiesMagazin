/**
 *  (C) Copyright 2012 Dominik Wagenfuehr, Markus Braun
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation; either version 3 of the
 *  License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this program. If not, see
 *  <http://www.gnu.org/licenses/>.
 */
#include "Board.hh"
#include <iostream>
#include <sstream>


Board::Board()
{
  mWidth = 0;
  mHeight = 0;
  mPlayer.setPosition(0, 0);
}


Board::~Board()
{
}


void Board::setDimension(const Position& dimension)
{
  mWidth = dimension.x();
  mHeight = dimension.y();
  mBoard.resize(mHeight);
  for (std::vector< std::vector<Field> >::iterator iter = mBoard.begin() ; iter != mBoard.end() ; iter++) {
    iter->resize(mWidth);
  }
}


void Board::setLine(const int row, const std::string& line)
{
  std::istringstream text(line);
  int idx = 0;

  while (!text.eof()) {
    switch (text.get()) {
      case '.':
        mBoard[row][idx++].setWater();
        break;

      case 'o':
        mBoard[row][idx++].setFlooded();
        break;

      case '#':
        mBoard[row][idx++].setLand();
        break;
    }
  }
}


void Board::setPosition(const Position& pos)
{
  mPlayer.setPosition(pos.x() - 1, pos.y() - 1);
}


const int Board::getWidth()
{
  return(mWidth);
}


const int Board::getHeight()
{
  return(mHeight);
}


const Position Board::getPosition()
{
  return(Position(mPlayer.x() + 1, mPlayer.y() + 1));
}


void Board::flood(const Position& pos)
{
  mBoard[pos.y() - 1][pos.x() - 1].flood();
}


void Board::play(CommandChain& command)
{
  unsigned int x;
  unsigned int y;
  Field* field;
  command.resetScore();

  // Ursprüngliche Position
  mPlayerRestore = mPlayer;

  // Loeschen der Restore Position
  mFieldRestore.clear();

  // Sequenz spielen uns playScore berechnen
  for (std::vector<Command>::const_iterator iter = command.getChain().begin() ; iter != command.getChain().end() ; iter++) {
    switch (*iter) {
      case CommandDryCurrent:
        x = mPlayer.x();
        y = mPlayer.y();
        field = &mBoard[y][x];

        if (field->isFlooded()) {
          mFieldRestore.push_back(std::make_pair(Position(x, y), *field));
          field->drain();
          command.changePlayScore(1.0);
        }
        break;

      case CommandDryNorth:
        // Schon ganz oben?
        if (mPlayer.y() == 0) {
          return;
        }

        x = mPlayer.x();
        y = mPlayer.y() - 1;
        field = &mBoard[y][x];

        // Ist das Ziel überflutet?
        if (field->isFlooded()) {
          mFieldRestore.push_back(std::make_pair(Position(x, y), *field));
          field->drain();
          command.changePlayScore(1.0);
        }
        else {
          return; // Spielzug macht keinen Sinn
        }
        break;

      case CommandDrySouth:
        // Schon ganz unten?
        if (mPlayer.y() == mHeight - 1) {
          return;
        }

        x = mPlayer.x();
        y = mPlayer.y() + 1;
        field = &mBoard[y][x];

        // Ist das Ziel überflutet?
        if (field->isFlooded()) {
          mFieldRestore.push_back(std::make_pair(Position(x, y), *field));
          field->drain();
          command.changePlayScore(1.0);
        }
        else {
          return; // Spielzug macht keinen Sinn
        }
        break;

      case CommandDryWest:
        // Schon ganz links?
        if (mPlayer.x() == 0) {
          return;
        }

        x = mPlayer.x() - 1;
        y = mPlayer.y();
        field = &mBoard[y][x];

        // Ist das Ziel überflutet?
        if (field->isFlooded()) {
          mFieldRestore.push_back(std::make_pair(Position(x, y), *field));
          field->drain();
          command.changePlayScore(1.0);
        }
        else {
          return; // Spielzug macht keinen Sinn
        }
        break;

      case CommandDryEast:
        // Schon ganz rechts?
        if (mPlayer.x() == mWidth - 1) {
          return;
        }

        x = mPlayer.x() + 1;
        y = mPlayer.y();
        field = &mBoard[y][x];

        // Ist das Ziel überflutet?
        if (field->isFlooded()) {
          mFieldRestore.push_back(std::make_pair(Position(x, y), *field));
          field->drain();
          command.changePlayScore(1.0);
        }
        else {
          return; // Spielzug macht keinen Sinn
        }
        break;

      case CommandGoCurrent:
        // NIX
        break;

      case CommandGoNorth:
        // Schon ganz oben?
        if (mPlayer.y() == 0) {
          return;
        }

        mPlayer.setPosition(mPlayer.x(), mPlayer.y() - 1);

        // Ist das Ziel begehbar?
        if (mBoard[mPlayer.y()][mPlayer.x()].isWater()) {
          return;
        }
        break;

      case CommandGoSouth:
        // Schon ganz unten?
        if (mPlayer.y() == mHeight - 1) {
          return;
        }

        mPlayer.setPosition(mPlayer.x(), mPlayer.y() + 1);

        // Ist das Ziel begehbar?
        if (mBoard[mPlayer.y()][mPlayer.x()].isWater()) {
          return;
        }
        break;

      case CommandGoWest:
        // Schon ganz links?
        if (mPlayer.x() == 0) {
          return;
        }

        mPlayer.setPosition(mPlayer.x() - 1, mPlayer.y());

        // Ist das Ziel begehbar?
        if (mBoard[mPlayer.y()][mPlayer.x()].isWater()) {
          return;
        }
        break;

      case CommandGoEast:
        // Schon ganz rechts?
        if (mPlayer.x() == mWidth - 1) {
          return;
        }

        mPlayer.setPosition(mPlayer.x() + 1, mPlayer.y());

        // Ist das Ziel begehbar?
        if (mBoard[mPlayer.y()][mPlayer.x()].isWater()) {
          return;
        }
        break;
    }
  }

  // Finale Position sicher?
  if (! mBoard[mPlayer.y()][mPlayer.x()].isSave()) {
    return;
  }

  // Wenn die Kette bis hier her kommt ist sie gültig
  command.setValid(true);

  // Berechnen futureScore
  // Nach Norden:
  x = mPlayer.x();
  y = mPlayer.y();
  for (unsigned int i = 1; y >= i; i++) {
    if (mBoard[y - i][x].isWater()) {
      break;
    }
    if (mBoard[y - i][x].isFlooded()) {
      command.changeFutureScore(1.0 / i);
    }
  }

  // Nach Sueden:
  x = mPlayer.x();
  y = mPlayer.y();
  for (int i = 1; y + i < mHeight; i++) {
    if (mBoard[y + i][x].isWater()) {
      break;
    }
    if (mBoard[y + i][x].isFlooded()) {
      command.changeFutureScore(1.0 / i);
    }
  }

  // Nach Westen:
  x = mPlayer.x();
  y = mPlayer.y();
  for (unsigned int i = 1; x >= i; i++) {
    if (mBoard[y][x - i].isWater()) {
      break;
    }
    if (mBoard[y][x - i].isFlooded()) {
      command.changeFutureScore(1.0 / i);
    }
  }

  // Nach Osten:
  x = mPlayer.x();
  y = mPlayer.y();
  for (int i = 1; y + i < mWidth; i++) {
    if (mBoard[y][x + i].isWater()) {
      break;
    }
    if (mBoard[y][x + i].isFlooded()) {
      command.changeFutureScore(1.0 / i);
    }
  }

  return;
}


void Board::revert()
{
  mPlayer = mPlayerRestore;

  for(std::vector< std::pair<Position, Field> >::iterator iter = mFieldRestore.begin() ; iter != mFieldRestore.end() ; iter++) {
    mBoard[iter->first.y()][iter->first.x()] = iter->second;
  }
}


void Board::print()
{
  for (unsigned int h = 0 ; h < mHeight ; h++) {
    std::cerr << "(DD)(MBR) ";
    for (unsigned int w = 0 ; w < mWidth ; w++) {
           if (mPlayer.x() == w && mPlayer.y() == h) std::cerr << "*";
      else if (mBoard[h][w].isWater())               std::cerr << ".";
      else if (mBoard[h][w].isFlooded())             std::cerr << "o";
      else if (mBoard[h][w].isLand())                std::cerr << "#";
      else                                           std::cerr << "X";
    }
    std::cerr << std::endl;
  }
}


