/**
 *  (C) Copyright 2012 Dominik Wagenfuehr, Markus Braun
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation; either version 3 of the
 *  License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this program. If not, see
 *  <http://www.gnu.org/licenses/>.
 */
#ifndef COMMANDCHAIN_HH
#define COMMANDCHAIN_HH

#include <vector>
#include <string>

typedef enum {
  CommandDryCurrent = 0,
  CommandDryNorth   = 1,
  CommandDrySouth   = 2,
  CommandDryWest    = 3,
  CommandDryEast    = 4,
  CommandGoCurrent  = 5,
  CommandGoNorth    = 6,
  CommandGoSouth    = 7,
  CommandGoWest     = 8,
  CommandGoEast     = 9
} Command;

class CommandChain {
  public:
    CommandChain();
    virtual ~CommandChain();

    void setChain(std::vector<Command>& chain);
    void appendCommandToChain(Command command);
    void dropLastCommandInChain();
    void resetScore();
    void setValid(bool valid);
    void setPlayScore(double score);
    void setFutureScore(double score);
    void changePlayScore(double score);
    void changeFutureScore(double score);

    /* TODO (mbr, 2013-01-02): operatoren */
    friend bool operator==(const CommandChain& lhs, const CommandChain& rhs);
    friend bool operator>(const CommandChain& lhs, const CommandChain& rhs);
    friend bool operator>=(const CommandChain& lhs, const CommandChain& rhs);
    friend bool operator<(const CommandChain& lhs, const CommandChain& rhs);
    friend bool operator<=(const CommandChain& lhs, const CommandChain& rhs);

    const std::vector<Command>& getChain() const;
    bool getValid() const;
    double getPlayScore() const;
    double getFutureScore() const;
    double getCombineScore() const;
    std::vector<std::string> toString() const;

  private:
    std::vector<Command> mChain;
    bool mValid;
    double mPlayScore;
    double mFutureScore;
};

#endif /* end of include guard: COMMANDCHAIN_HH */
