/**
 *  (C) Copyright 2012 Dominik Wagenfuehr, Markus Braun
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as
 *  published by the Free Software Foundation; either version 3 of the
 *  License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this program. If not, see
 *  <http://www.gnu.org/licenses/>.
 */
#ifndef BOARD_HH
#define BOARD_HH
#include <string>
#include <vector>
#include <utility>

#include "Position.hh"
#include "Field.hh"
#include "CommandChain.hh"


class Board {
  public:
    Board();
    virtual ~Board();
    void setDimension(const Position& dimension);
    void setLine(const int row, const std::string& line);
    void setPosition(const Position& pos);

    const int getWidth();
    const int getHeight();
    const Position getPosition();

    void flood(const Position& pos);

    void play(CommandChain& command);
    void revert();

    void print();

  private:
    unsigned int mWidth;
    unsigned int mHeight;
    Position mPlayer; // Position beginnend bei (0,0)
    std::vector< std::vector<Field> > mBoard;

    Position mPlayerRestore; // Position beginnend bei (0,0)
    std::vector< std::pair<Position, Field> > mFieldRestore;
};


#endif /* end of include guard: BOARD_HH */
