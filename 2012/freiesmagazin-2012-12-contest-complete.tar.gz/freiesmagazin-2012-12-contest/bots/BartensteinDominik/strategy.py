#!/usr/bin/env python
# 
#    Programming competition.
#    http://www.freiesmagazin.de/sechster_programmierwettbewerb
# 
#    (C) Copyright 2012 Dominik Bartenstein 
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as
#    published by the Free Software Foundation; either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with this program. If not, see
#    <http://www.gnu.org/licenses/>.

import copy
import random
import logging
from base import BaseStrategy, HiddenIsland


class Strategy(BaseStrategy):
	
	def _dry_from_current(self):
		# step 1: dry everything that is around us!
		random.shuffle(self.directions)
		for direction in ['CURRENT'] + self.directions:
			if len(self.commands) == 3:
				break
			if self.island_virtual.get_neighbour_field(direction) == HiddenIsland.FLOODED:
				self.commands.append('DRY %s' %(direction))
				self.island_virtual.dry_field(direction)
			
		
	def next_three_moves(self, round_number):
		'''
		next three moves of this round
		ARGUMENTS:
			round_number	integer		number of current round
		RETURN VALUE:
			commands		list with 3 strings		e.g. ['GO NORTH', 'DRY CURRENT', 'GO EAST']
			
		startegy: 
		always try to dry fields that are very, very close to you			
		'''
		
		self.island_virtual = copy.deepcopy(self.island)
		
		#return ['GO CURRENT', 'GO CURRENT', 'GO CURRENT']
		self.commands = []
		self.directions = ['NORTH', 'EAST', 'SOUTH', 'WEST']
		self._dry_from_current()
					
		# step 2: dry everything that is diagonal of current position
		if len(self.commands) in (0, 1):
			directions_diagonal = ['NORTHEAST', 'SOUTHEAST', 'SOUTHWEST', 'NORTHWEST']
			random.shuffle(directions_diagonal)
			for direction in directions_diagonal:
				if self.island.get_neighbour_field(direction) == HiddenIsland.FLOODED:
					first_direction, second_direction = direction[:5], direction[5:]
					# is there a path to the diagonal field?
					if self.island.get_neighbour_field(first_direction) in HiddenIsland.WALKABLE:
						self.commands.append('GO %s' %first_direction)
						self.island_virtual.move(first_direction)
						self.commands.append('DRY %s' %second_direction)
						self.island_virtual.dry_field(second_direction)
						break
					elif self.island.get_neighbour_field(second_direction) in HiddenIsland.WALKABLE:
						self.commands.append('GO %s' %second_direction)
						self.island_virtual.move(second_direction)
						self.commands.append('DRY %s' %first_direction)
						self.island_virtual.dry_field(first_direction)
						break
		
		self._dry_from_current()
		
		# step 3: dry everything that is within 2 steps range
		if len(self.commands) in (0, 1):
			for direction in self.directions:
				if self.island_virtual.get_neighbour_field(direction, 2) == HiddenIsland.FLOODED:
					if self.island_virtual.get_neighbour_field(direction, 1) in HiddenIsland.WALKABLE:
						self.commands.append('GO %s' %direction)
						self.island_virtual.move(direction)
						self.commands.append('DRY %s' %direction)
						self.island_virtual.dry_field(direction)
						break
		
		self._dry_from_current()
		
		# step 4: walk into the right direction
		if len(self.commands) < 3:
			for direction in self.directions:
				# never ever stop on field that is flooded. probability of sinking is too high. 
				if self.island_virtual.get_neighbour_field(direction, 2) == HiddenIsland.DRY:
					if self.island_virtual.get_neighbour_field(direction, 1) in HiddenIsland.WALKABLE:
						for i in range(2):
							if len(self.commands) >= 3:
								break
							self.commands.append('GO %s' %direction)
							self.island_virtual.move(direction)
							self._dry_from_current()

						break
		
		self._dry_from_current()
		
		# step last: fill up the command list
		for i in range(3 - len(self.commands)):
			self.commands.append('GO CURRENT')
		return self.commands[:3]
