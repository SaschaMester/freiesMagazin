﻿//
//  Copyright 2012  Patrick Uhlmann
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace ArchesBotMono.DataStructure.Graph
{
	public class Dijkstra<T>
	{
		private Node<T> calculatedStart;

		private ReadOnlyCollection<Node<T>> Nodes {
			get ;
			set ;
		}

		private ReadOnlyCollection<Edge<T>> Edges {
			get;
			set;
		}

		private List<Node<T>> NodesToInspect {
			get;
			set ;
		}

		private Dictionary<Node<T>, int> Distance {
			get ;
			set ;
		}

		private Dictionary<Node<T>, Node<T>> PreviousNode {
			get;
			set ;
		}

		public Dijkstra (ReadOnlyCollection<Edge<T>> edges, ReadOnlyCollection<Node<T>> nodes)
		{
			Edges = edges;
			Nodes = nodes;
			NodesToInspect = new List<Node<T>> ();
			Distance = new Dictionary<Node<T>, int> ();
			PreviousNode = new Dictionary<Node<T>, Node<T>> ();

			foreach (Node<T> n in Nodes) {
				PreviousNode.Add (n, null);
				NodesToInspect.Add (n);
				Distance.Add (n, int.MaxValue);
			}
		}

		public LinkedList<T> GetPath (T start, T destination)
		{
			Node<T> startNode = new Node<T> (start);
			Node<T> destinationNode = new Node<T> (destination);

			CalculateAllShortestDistances (startNode);

			// building path going back from the destination to the start always taking the nearest node
			LinkedList<T> path = new LinkedList<T> ();
			path.AddFirst (destinationNode.Value);

			while (PreviousNode[destinationNode] != null) {
				destinationNode = PreviousNode [destinationNode];
				path.AddFirst (destinationNode.Value);
			}

			path.RemoveFirst ();

			return path;
		}

		private void CalculateAllShortestDistances (Node<T> startNode)
		{
			if (startNode.Value.Equals (calculatedStart)) {
				return;
			}

			Distance [startNode] = 0;

			while (NodesToInspect.Count > 0) {
				Node<T> nearestNode = GetNodeWithSmallestDistance ();
				// if we cannot find another node with the function above we can exit the algorithm and clear the
				// nodes to inspect because they would not be reachable from the start or will not be able to shorten the paths...
				// this algorithm does also implicitly kind of calculate the minimum spanning tree...
				if (nearestNode == null) {
					NodesToInspect.Clear ();
				} else {
					foreach (Node<T> neighbour in GetNeighborsFromNodesToInspect(nearestNode)) {
						// calculate distance with the currently inspected neighbour
						int dist = Distance [nearestNode] + GetDirectDistanceBetween (nearestNode, neighbour);

						// set the neighbour as shortest if it is better than the current shortest distance
						if (dist < Distance [neighbour]) {
							Distance [neighbour] = dist;
							PreviousNode [neighbour] = nearestNode;
						}
					}
					NodesToInspect.Remove (nearestNode);
				}
			}

			calculatedStart = startNode;
		}

		private Node<T> GetNodeWithSmallestDistance ()
		{
			int distance = int.MaxValue;
			Node<T> smallest = null;

			foreach (Node<T> inspectedNode in NodesToInspect) {
				if (Distance [inspectedNode] < distance) {
					distance = Distance [inspectedNode];
					smallest = inspectedNode;
				}
			}

			return smallest;
		}

		private List<Node<T>> GetNeighborsFromNodesToInspect (Node<T> n)
		{
			List<Node<T>> neighbors = new List<Node<T>> ();

			foreach (Edge<T> e in Edges) {
				if (e.Start.Equals (n) && NodesToInspect.Contains (n)) {
					neighbors.Add (e.End);
				}
			}

			return neighbors;
		}

		private int GetDirectDistanceBetween (Node<T> startNode, Node<T> endNode)
		{
			foreach (Edge<T> e in Edges) {
				if (e.Start.Equals (startNode) && e.End.Equals (endNode)) {
					return e.Distance;
				}
			}

			return int.MaxValue;
		}
	}
}