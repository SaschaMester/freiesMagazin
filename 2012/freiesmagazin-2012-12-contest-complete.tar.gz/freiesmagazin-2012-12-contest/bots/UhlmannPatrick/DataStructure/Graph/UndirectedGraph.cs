//
//  Copyright 2012  Patrick Uhlmann
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace ArchesBotMono.DataStructure.Graph
{
	/// <summary>
	/// Undirected graph.
	/// Each node and edge can only be added once. 
	/// If it gets added a second time it does just get ignored.
	/// For an edge to be considered the same it must only have the same start and end. The cost doesn't matter
	/// Caution: in the Edges collection and Edges count is twice as high as you would expect from a regular undirected graph.
	///          this is because this implementation does add a edge from start -> end as well as one from end -> start. This
	///          makes the graph kind of undirected
	/// </summary>
	public class UndirectedGraph<T>
	{
		private List<Node<T>> nodes = new List<Node<T>> ();
		private List<Edge<T>> edges = new List<Edge<T>> ();

		public int NodeCount {
			get {
				return nodes.Count;
			}
		}

		/// <summary>
		/// Caution: the count is twice as high as you would expect. There is one edge from start -> end and from end -> start
		///          for each edge you insert
		/// </summary>
		public int EdgesCount {
			get {
				return edges.Count;
			}
		}

		public ReadOnlyCollection<Node<T>> Nodes {
			get {
				return nodes.AsReadOnly ();
			}
		}

		/// <summary>
		/// Caution: there are twice as many edges as you would expect. There is one edge from start -> end and from end -> start
		///          for each edge you insert
		/// </summary>
		public ReadOnlyCollection<Edge<T>> Edges {
			get {
				return edges.AsReadOnly ();
			}
		}

		public void AddNode (T node)
		{
			AddNodeIfNotAlreadyContained (new Node<T> (node));
		}

		private void AddNodeIfNotAlreadyContained (Node<T> node)
		{
			if (!nodes.Contains (node)) {
				nodes.Add (node);
			}
		}

		/// <summary>
		/// If we add an edge the associated nodes are added as well
		/// </summary>
		public void AddEdge (T node1, T node2, int cost)
		{
			var startNode = new Node<T> (node1);
			var endNode = new Node<T> (node2);

			AddNodeIfNotAlreadyContained (startNode);
			AddNodeIfNotAlreadyContained (endNode);

			var edgeStartToEnd = new Edge<T> (startNode, endNode, cost);
			var edgeEndToStart = new Edge<T> (endNode, startNode, cost);

			AddEdgeIfNotAlreadyContained (edgeStartToEnd);
			AddEdgeIfNotAlreadyContained (edgeEndToStart);
		}

		private void AddEdgeIfNotAlreadyContained (Edge<T> edge)
		{
			if (!edges.Contains (edge)) {
				edges.Add (edge);
			}
		}

		public void RemoveEdge (T start, T end)
		{
			var startNode = new Node<T> (start);
			var endNode = new Node<T> (end);

			Edge<T> startToEnd = new Edge<T> (startNode, endNode, 1);
			Edge<T> endToStart = new Edge<T> (endNode, startNode, 1);

			edges.Remove (startToEnd);
			edges.Remove (endToStart);
		}

		/// <summary>
		/// If we remove a node the associated edges are removed as well
		/// </summary>
		public void RemoveNode (T node)
		{
			var nodeToRemvoe = new Node<T> (node);

			nodes.Remove (nodeToRemvoe);

			List<Edge<T>> edgesToRemove = new List<Edge<T>> ();

			var enumerator = edges.GetEnumerator ();
			while (enumerator.MoveNext()) {
				if (enumerator.Current.Start.Equals (nodeToRemvoe) || enumerator.Current.End.Equals (nodeToRemvoe)) {
					edgesToRemove.Add (enumerator.Current);
				}
			}

			foreach (var edge in edgesToRemove) {
				edges.Remove (edge);
			}
		}

		public bool ContainsNode (T node)
		{
			return nodes.Contains (new Node<T> (node));
		}

		public bool AreDirectlyConnected (T node1, T node2)
		{
			var startNode = new Node<T> (node1);
			var endNode = new Node<T> (node2);

			return edges.Contains (new Edge<T> (startNode, endNode, 1));
		}
	}
}

