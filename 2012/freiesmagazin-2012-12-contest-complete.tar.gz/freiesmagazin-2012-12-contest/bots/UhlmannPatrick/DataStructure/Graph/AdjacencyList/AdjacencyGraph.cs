//
//  Copyright 2012  Patrick Uhlmann
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace ArchesBotMono.DataStructure.Graph
{
	/// <summary>
	/// Undirected, unweightened graph.
	/// Each node and edge can only be added once. 
	/// If it gets added a second time it does just get ignored.
	/// </summary>
	public class AdjacencyGraph<T>
	{
		private Dictionary<T, AdjacencyNode<T>> nodes = new Dictionary<T, AdjacencyNode<T>> ();

		public int NodeCount {
			get {
				return nodes.Count;
			}
		}

		public IEnumerable<AdjacencyNode<T>> Nodes {
			get {
				return nodes.Values;
			}
		}

		/// <summary>
		/// If we add an edge it checks if the node as already there, otherwise it adds the node.
		/// </summary>
		public void AddEdge (T node1, T node2)
		{
			var startNode = nodes.ContainsKey(node1) ? nodes[node1] : null;
			if (startNode == null) {
				startNode = new AdjacencyNode<T>(node1);
				AddNodeIfNotAlreadyContained (startNode);
			}

			var endNode = nodes.ContainsKey(node2) ? nodes[node2] : null;
			if (endNode == null) {
				endNode = new AdjacencyNode<T>(node2);
				AddNodeIfNotAlreadyContained(endNode);
			}

			startNode.AddEdgeTo(endNode);
			endNode.AddEdgeTo(startNode);
		}

		private void AddNodeIfNotAlreadyContained (AdjacencyNode<T> node)
		{
			if (!nodes.ContainsKey(node.Value)) {
				nodes.Add (node.Value, node);
			}
		}
				
		/// <summary>
		/// Removes the edge from nodes that are already part of the graph
		/// If the very last edge of a node to another one is removed the node is removed as well
		/// </summary>
		public bool RemoveEdge (T start, T end)
		{
			var startNode = nodes.ContainsKey(start) ? nodes[start] : null;
			var endNode = nodes.ContainsKey(end) ? nodes[end] : null;

			if (startNode == null || endNode == null) {
				return false;
			}

			startNode.RemoveEdgeTo (endNode);

			if (startNode.EdgeCount == 0) {
				nodes.Remove(start);
			}

			endNode.RemoveEdgeTo (startNode);
			if (endNode.EdgeCount == 0) {
				nodes.Remove(end);
			}

			return true;
		}
		
		/// <summary>
		/// If we remove a node the associated edges are removed as well
		/// </summary>
		public bool RemoveNode (T node)
		{
			var nodeToRemove = nodes.ContainsKey(node) ? nodes[node] : null;
			if (nodeToRemove == null) {
				return false;
			}

			foreach (AdjacencyNode<T> n in nodeToRemove.AdjacentNodes) {
				n.RemoveEdgeTo(nodeToRemove);
			}

			nodes.Remove (node);

			return true;
		}
		
		public bool ContainsNode (T node)
		{
			return nodes.ContainsKey(node);
		}
		
		public bool AreDirectlyConnected (T node1, T node2)
		{
			var startNode = nodes.ContainsKey(node1) ? nodes[node1] : null;
			var endNode = nodes.ContainsKey(node2) ? nodes[node2] : null;

			if (startNode == null || endNode == null) {
				return false;
			}

			return startNode.HasEdgeTo(endNode);
		}
	}
}

