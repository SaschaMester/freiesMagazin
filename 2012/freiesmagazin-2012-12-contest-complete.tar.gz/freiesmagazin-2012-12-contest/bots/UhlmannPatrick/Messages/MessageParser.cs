using System;

namespace ArchesBotMono
{
	public class MessageParser
	{
		private IMessageHandler handler;

		public MessageParser (IMessageHandler handler)
		{
			this.handler = handler;
		}


	}
}

