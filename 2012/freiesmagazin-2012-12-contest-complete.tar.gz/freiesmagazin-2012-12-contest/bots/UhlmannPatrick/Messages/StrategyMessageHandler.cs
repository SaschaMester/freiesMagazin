//
//  Copyright 2012  Patrick Uhlmann
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
using System;

namespace ArchesBotMono
{
	public class StrategyMessageHandler : IMessageHandler
	{
		private Gameboard board;
		private IStrategy strategy;
		private ILogger logger = LoggerFactory.Create();
		private ISender Sender = CommunicationFactory.CreateSender ();

		public StrategyMessageHandler ()
		{
			strategy = StrategyFactory.CreateStrategy ();
		}

		public virtual void ParseStringAndHandleMessage (string s)
		{
			if (s.Contains (GameBoardStartMessage.MessageIdentifier)) {
				OnGameBoardStartMessage (new GameBoardStartMessage (s));
			} else if (s.Contains (".") || s.Contains ("#") || s.Contains ("o")) {
				OnGameBoardLineMessage (new GameBoardLineMessage (s));
			} else if (s.Contains (GameBoardEndMessage.MessageIdentifier)) {
				OnGameBoardEndMessage (new GameBoardEndMessage ());
			} else if (s.Contains (RoundStartMessage.MessageIdentifier)) {
				OnRoundStartMessage (new RoundStartMessage (s));
			} else if (s.Contains (IncreaseFloodMessage.MessageIdentifier)) {
				OnIncreaseFloodMessage (new IncreaseFloodMessage (s));
			} else if (s.Contains (FloodMessage.MessageIdentifier)) {
				OnFloodMessage (new FloodMessage (s));
			} else if (s.Contains (EndMessage.MessageIdentifier)) {
				OnEndMessage (new EndMessage ());
			} else {
				OnUnknownMessage (new UnknownMessage (s));
			}
		}

		public virtual void OnEndMessage (EndMessage msg)
		{
			Environment.Exit (0);
		}

		public virtual void OnFloodMessage (FloodMessage msg)
		{
			strategy.OnFieldFlooded (msg.PosX - 1, msg.PosY - 1);				
		}

		public virtual void OnGameBoardEndMessage (GameBoardEndMessage msg)
		{
			strategy.OnNewGameboard (board);
		}

		public virtual void OnGameBoardLineMessage (GameBoardLineMessage msg)
		{
			board.InitializeNextRow (msg.Line);
		}

		public virtual void OnGameBoardStartMessage (GameBoardStartMessage msg)
		{
			board = new Gameboard (msg.Columns, msg.Rows);
		}

		public virtual void OnIncreaseFloodMessage (IncreaseFloodMessage msg)
		{

		}

		public virtual void OnRoundStartMessage (RoundStartMessage msg)
		{
			strategy.OnRoundStartMessage (msg.PosX - 1, msg.PosY - 1, msg.RoundNr);
			Sender.Send (strategy.GetNextActions());
		}

		public virtual void OnUnknownMessage (UnknownMessage msg)
		{
			logger.Warn (msg.ToString());
		}
	}
}

