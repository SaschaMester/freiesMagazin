//
//  Copyright 2012  Patrick Uhlmann
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
using System;
using ArchesBotMono;

namespace ArchesBotMono
{
	public class GoAction : IAction
	{
		public GoAction (Enumerations.Direction moveDirection)
		{
			MoveDirection = moveDirection;
		}

		public Enumerations.Direction MoveDirection {
			get;
			set;
		}

		public override string ToString ()
		{
			switch (MoveDirection) {
			case Enumerations.Direction.North:
				return "GO NORTH";
			case Enumerations.Direction.East:
				return "GO EAST";
			case Enumerations.Direction.South:
				return "GO SOUTH";
			case Enumerations.Direction.West:
				return "GO WEST";
			case Enumerations.Direction.CurrentPosition:
				return "GO CURRENT";
			default:
				return "UNDEFINED";
			}
		}

		public override bool Equals (System.Object obj)
		{
			if (obj == null) {
				return false;
			}

			GoAction f = obj as GoAction;
			if (f == null) {
				return false;
			}

			return Equals (f);
		}

		public bool Equals (GoAction f)
		{
			if (f == null) {
				return false;
			}

			return (MoveDirection == f.MoveDirection);
		}

		public override int GetHashCode ()
		{
			return MoveDirection.GetHashCode ();
		}
	}
}

