//
//  Copyright 2012  Patrick Uhlmann
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
using System;
using System.Collections.Generic;
using ArchesBotMono.DataStructure.Graph;

namespace ArchesBotMono
{
	public class DefaultStrategy : IStrategy
	{
		private ILogger logger = LoggerFactory.Create();

		protected Gameboard Gameboard;
		protected List<IAction> Actions = new List<IAction> ();
		protected int Round;
		protected AdjacencyGraph<Field> GameBoardGraph;

		public void OnNewGameboard (Gameboard board)
		{
			Gameboard = board;

			GameBoardGraph = ArchesBotMono.GameboardGraph.GetGraphFromGameboard(Gameboard);
		}

		public void OnRoundStartMessage (int posx, int posy, int round)
		{
			logger.Info ("Started Round " + round + " CurrentPosition: (" + posx + ", " + posy + ")");

			Gameboard.PosX = posx;
			Gameboard.PosY = posy;
			Round = round;
		}

		public void OnFieldFlooded (int x, int y)
		{
			Gameboard.FloodField (x, y);

			if (Gameboard.GetField (x, y).CurrentState == Field.State.Water) {
				this.GameBoardGraph.RemoveNode (Gameboard.GetField (x, y));
			}

			logger.Info ("Flooded field: " + x + ", " + y);
		}

		public List<IAction> GetNextActions() {
			logger.Info ("NextActions based on Graph Size: " + GameBoardGraph.NodeCount + " nodes");

			Actions.Clear();
			CurrentState = MoveState.Dry;
			CalculateNextActions();
			return Actions;
		}

		private MoveState CurrentState;

		private enum MoveState
		{
			Dry,
			Move,
			Stay
		}

		/// <summary>
		/// Does transform through the states always collecting maximum one action per state until it has three actions
		/// </summary>
		public void CalculateNextActions ()
		{
			if (Actions.Count >= 3) {
				return;
			}

			switch (CurrentState) {
				case MoveState.Dry:
					DryFieldNextToMe();
					break;

				case MoveState.Move:
					MoveTowardsNextFloodedField();
					break;

				case MoveState.Stay:
					StayAction();
					break;
			};

			CalculateNextActions();
		}

		/// <summary>
		/// We try to dry a field next to us. If there is one we stay in the drystate. If all are dry we change to the move state
		/// </summary>
		protected void DryFieldNextToMe ()
		{
			var values = Enum.GetValues (typeof(Enumerations.Direction));
			for (int i=0; i<values.Length; i++) {
				if (DryFieldIfFlooded ((Enumerations.Direction)values.GetValue (i))) {
					return;
				}
			}

			CurrentState = MoveState.Move;
		}

		protected bool DryFieldIfFlooded (Enumerations.Direction dir)
		{
			Field f = Gameboard.GetNeighborField (dir);
			if (f != null && f.CurrentState == Field.State.Flooded) {
				DryAction dry = new DryAction (dir);
				Actions.Add (dry);
				Gameboard.ApplyDry (dry);
				logger.Info ("DryAction");
				return true;
			}

			return false;
		}

		/// <summary>
		/// We search for the next flooded field and navigate one step in its direction. If we find none we switch to the stay state
		/// </summary>
		protected void MoveTowardsNextFloodedField() {
			var GameBoardGraphDistances = new FloodedFieldPathCalc (GameBoardGraph.Nodes);

			var waypoints = GameBoardGraphDistances.GetPathToFirstFloodedField (Gameboard.CurrentField);

			if (waypoints.Count > 0) {
				Field nextField = waypoints.First.Value;
				waypoints.RemoveFirst ();

				GoAction act = null;
				if (nextField.Equals (Gameboard.GetNeighborField (Enumerations.Direction.North))) {
					act = new GoAction (Enumerations.Direction.North);
				} else if (nextField.Equals (Gameboard.GetNeighborField (ArchesBotMono.Enumerations.Direction.South))) {
					act = new GoAction (Enumerations.Direction.South);
				} else if (nextField.Equals (Gameboard.GetNeighborField (ArchesBotMono.Enumerations.Direction.West))) {
					act = new GoAction (Enumerations.Direction.West);
				} else if (nextField.Equals (Gameboard.GetNeighborField (ArchesBotMono.Enumerations.Direction.East))) {
					act = new GoAction (Enumerations.Direction.East);
				} else {
					throw new Exception ("Waypoint not found: " + nextField);
				}

				Gameboard.ApplyAction (act);
				Actions.Add (act);

				CurrentState = MoveState.Dry;
				return;
			} else {
				logger.Warn("no field to navigate to");
			}

			CurrentState = MoveState.Stay;
		}

		/// <summary>
		/// If we are in the stay state we just output one command and stay in that state
		/// </summary>
		private void StayAction() {
			GoAction act = new GoAction (Enumerations.Direction.CurrentPosition);
			Gameboard.ApplyAction (act);
			Actions.Add (act);
			logger.Info ("Stay");
		}
	}
}
