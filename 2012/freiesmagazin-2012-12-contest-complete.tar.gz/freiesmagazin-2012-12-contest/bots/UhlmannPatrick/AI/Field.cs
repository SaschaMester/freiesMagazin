//
//  Copyright 2012  Patrick Uhlmann
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
using System;

namespace ArchesBotMono
{
	public class Field
	{
		public int PosX {
			get;
			set;
		}

		public int PosY {
			get;
			set;
		}

		public State CurrentState {
			get;
			set;
		}

		public enum State
		{
			Undefined = 0,
			Water = 1,
			Flooded = 2,
			Land = 3
		}


		public Field (int x, int y, State currentState)
		{
			CurrentState = currentState;
			PosX = x;
			PosY = y;
		}

		public override bool Equals (System.Object obj)
		{
			if (obj == null) {
				return false;
			}

			Field f = obj as Field;
			if (f == null) {
				return false;
			}

			return Equals (f);
		}

		public bool Equals (Field f)
		{
			if (f == null) {
				return false;
			}

			return (PosY == f.PosY) && (PosX == f.PosX);
		}

		public override int GetHashCode ()
		{
			return PosX ^ PosY;
		}

		public override string ToString ()
		{
			return string.Format ("Field ({0}, {1}) is {2}", PosX, PosY, CurrentState);
		}
	}
}

