//
//  Copyright 2012  Patrick Uhlmann
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
using System;

namespace ArchesBotMono
{
	public class Gameboard
	{
		// access is x, y
		private Field[,] gameboard;
		private int nextRowToInitialize;

		public int Columns {
			get;
			set;
		}

		public int Rows {
			get;
			set;
		}

		public int PosX {
			get;
			set;
		}

		public int PosY {
			get;
			set;
		}

		public Field CurrentField {
			get {
				return GetFieldOrNull (PosX, PosY);
			}
		}

		public Gameboard (int columns, int rows)
		{
			this.Columns = columns;
			this.Rows = rows;
			this.nextRowToInitialize = 0;
			this.gameboard = new Field[columns, rows];
		}

		public Field GetField (int x, int y)
		{
			return gameboard [x, y];
		}

		public void InitializeNextRow (string row)
		{
			if (row.Length < Columns) {
				throw new InvalidOperationException ("The Gameboard Row's length is only " + row.Length + ", it should be: " + Columns);
			}

			for (int i=0; i<row.Length; i++) {
				if (row [i].Equals ('.')) {
					this.gameboard [i, this.nextRowToInitialize] = new Field (i, this.nextRowToInitialize, Field.State.Water);
				} else if (row [i].Equals ('o')) {
					this.gameboard [i, this.nextRowToInitialize] = new Field (i, this.nextRowToInitialize, Field.State.Flooded);
				} else if (row [i].Equals ('#')) {
					this.gameboard [i, this.nextRowToInitialize] = new Field (i, this.nextRowToInitialize, Field.State.Land);
				}
			}

			nextRowToInitialize++;
		}

		public void FloodField (int x, int y)
		{
			if (this.gameboard [x, y].CurrentState == Field.State.Land) {
				this.gameboard [x, y].CurrentState = Field.State.Flooded;
			} else if (this.gameboard [x, y].CurrentState == Field.State.Flooded) {
				this.gameboard [x, y].CurrentState = Field.State.Water;
			}
		}

		public Field GetNeighborField (Enumerations.Direction dir)
		{
			switch (dir) {
			case Enumerations.Direction.North:
				return GetFieldOrNull (PosX, PosY - 1);
			case Enumerations.Direction.East:
				return GetFieldOrNull (PosX + 1, PosY);
			case Enumerations.Direction.South:
				return GetFieldOrNull (PosX, PosY + 1);
			case Enumerations.Direction.West:
				return GetFieldOrNull (PosX - 1, PosY);
			case Enumerations.Direction.CurrentPosition:
				return GetFieldOrNull (PosX, PosY);
			default:
				return null;
			}
		}

		private Field GetFieldOrNull (int x, int y)
		{
			if (y < 0 || y >= Rows || x < 0 || x >= Columns) {
				return null;
			} else {
				return GetField (x, y);
			}
		}

		public void ApplyAction (GoAction go)
		{
			Field nextField = GetNeighborField (go.MoveDirection);
			PosX = nextField.PosX;
			PosY = nextField.PosY;
		}

		public void ApplyDry (DryAction dry)
		{
			Field fieldToDry = GetNeighborField (dry.Direction);
			fieldToDry.CurrentState = Field.State.Land;
		}
	}
}

