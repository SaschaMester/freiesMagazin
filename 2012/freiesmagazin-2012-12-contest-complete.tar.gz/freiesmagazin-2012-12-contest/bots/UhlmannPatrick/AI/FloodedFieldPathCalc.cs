//
//  Copyright 2012  Patrick Uhlmann
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Linq;

namespace ArchesBotMono.DataStructure.Graph
{
	public class FloodedFieldPathCalc
	{
		private AdjacencyNode<Field> calculatedStart;
		private Field calculatedField;
		
		private List<AdjacencyNode<Field>> NodesToInspect {
			get;
			set ;
		}
		
		private Dictionary<AdjacencyNode<Field>, int> Distance {
			get ;
			set ;
		}
		
		private Dictionary<AdjacencyNode<Field>, AdjacencyNode<Field>> PreviousNode {
			get;
			set ;
		}
		
		public FloodedFieldPathCalc (IEnumerable<AdjacencyNode<Field>> nodes)
		{
			NodesToInspect = new List<AdjacencyNode<Field>> ();
			Distance = new Dictionary<AdjacencyNode<Field>, int> ();
			PreviousNode = new Dictionary<AdjacencyNode<Field>, AdjacencyNode<Field>> ();
			
			foreach (AdjacencyNode<Field> n in nodes) {
				PreviousNode.Add (n, null);
				NodesToInspect.Add (n);
				Distance.Add (n, int.MaxValue);
			}
		}
		
		public LinkedList<Field> GetPathToFirstFloodedField (Field start)
		{
			AdjacencyNode<Field> startNode = new AdjacencyNode<Field> (start);

			Field destination = CalculateFirstFloodedField (startNode);

			if (destination == null) {
				return new LinkedList<Field>();
			}

			AdjacencyNode<Field> destinationNode = new AdjacencyNode<Field> (destination);
			
			// building path going back from the destination to the start always taking the nearest node
			LinkedList<Field> path = new LinkedList<Field> ();
			path.AddFirst (destinationNode.Value);
			
			while (PreviousNode[destinationNode] != null) {
				destinationNode = PreviousNode [destinationNode];
				path.AddFirst (destinationNode.Value);
			}
			
			path.RemoveFirst ();
			
			return path;
		}
		
		private Field CalculateFirstFloodedField (AdjacencyNode<Field> startNode)
		{
			if (startNode.Equals (calculatedStart)) {
				return calculatedField;
			}

			calculatedField = null;
			Field nearestField = null;
			
			Distance [startNode] = 0;
			
			while (NodesToInspect.Count > 0) {
				AdjacencyNode<Field> nearestNode = GetNodeWithSmallestDistance ();
				// if we cannot find another node with the function above we can exit the algorithm and clear the
				// nodes to inspect because they would not be reachable from the start or will not be able to shorten the paths...
				// this algorithm does also implicitly kind of calculate the minimum spanning tree...
				if (nearestNode == null) {
					NodesToInspect.Clear ();
				} else {
					foreach (AdjacencyNode<Field> neighbour in GetNeighborsFromNodesToInspect(nearestNode)) {
						// calculate distance with the currently inspected neighbour
						int dist = Distance [nearestNode] + GetDirectDistanceBetween (nearestNode, neighbour);
						
						// set the neighbour as shortest if it is better than the current shortest distance
						if (dist < Distance [neighbour]) {
							Distance [neighbour] = dist;
							PreviousNode [neighbour] = nearestNode;

							// if we find the first flooded field - check if it is worth going there (other flooded fields near it) if yes stop otherwise continue
							if (neighbour.Value.CurrentState != Field.State.Land) {
								if (nearestField == null) {
									nearestField = neighbour.Value;
								}

								if (WorthGoingToField(neighbour)) {
									calculatedField = neighbour.Value;
									NodesToInspect.RemoveAll (p => true);
								}
							}
						}
					}
					NodesToInspect.Remove (nearestNode);
				}
			}
			
			calculatedStart = startNode;

			if (calculatedField == null && nearestField != null) {
				calculatedField = nearestField;
			}

			return calculatedField;
		}

		/// <summary>
		/// It is worth going there if we have at least 9 flooded neighbors that are max one field away
		/// some are counted two times 
		/// </param>
		private bool WorthGoingToField (AdjacencyNode<Field> f)
		{
			// the current field will be counted 4 times -> +4 -> 0
			int floodedCounter = -4;

			foreach (AdjacencyNode<Field> e in f.AdjacentNodes) {
				floodedCounter += NumberOfFloodedNeighbors(e);
			}

			return floodedCounter > 3;
		}

		private int NumberOfFloodedNeighbors (AdjacencyNode<Field> n)
		{
			return n.AdjacentNodes.Where(node => node.Value.CurrentState == Field.State.Flooded).Count();
		}
				
		
		private AdjacencyNode<Field> GetNodeWithSmallestDistance ()
		{
			int distance = int.MaxValue;
			AdjacencyNode<Field> smallest = null;
			
			foreach (AdjacencyNode<Field> inspectedNode in NodesToInspect) {
				if (Distance [inspectedNode] < distance) {
					distance = Distance [inspectedNode];
					smallest = inspectedNode;
				}
			}
			
			return smallest;
		}
		
		private List<AdjacencyNode<Field>> GetNeighborsFromNodesToInspect (AdjacencyNode<Field> n)
		{
			List<AdjacencyNode<Field>> neighbors = new List<AdjacencyNode<Field>> ();
			
			foreach (AdjacencyNode<Field> e in n.AdjacentNodes) {
				if (NodesToInspect.Contains (e)) {
					neighbors.Add (e);
				}
			}
			
			return neighbors;
		}
		
		private int GetDirectDistanceBetween (AdjacencyNode<Field> startNode, AdjacencyNode<Field> endNode)
		{
			if (startNode.HasEdgeTo (endNode)) {
				return 1; 
			} else {
				return int.MaxValue;
			}
		}
	}
}