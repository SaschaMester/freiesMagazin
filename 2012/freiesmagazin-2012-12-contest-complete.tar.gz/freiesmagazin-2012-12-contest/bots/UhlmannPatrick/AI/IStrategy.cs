//
//  Copyright 2012  Patrick Uhlmann
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
using System;
using System.Collections.Generic;

namespace ArchesBotMono
{
	public interface IStrategy
	{
		/// <summary>
		/// Called when we initialize the strategy with a new gameboard. Usually this is like a reset of the strategy.
		/// Important: when the board is passed into the strategy we should not make any changes to the board from the outside.
		/// The board is owned and managed by the strategy only!
		/// </summary>
		void OnNewGameboard (Gameboard board);

		/// <summary>
		/// Starts a new round. Our strategy must then react and send the three actions that it can take in that round
		/// </summary>
		void OnRoundStartMessage (int playerPosX, int PlayerPosY, int round);

		/// <summary>
		/// Notifies the strategy about fields that are flooded
		/// </summary>
		void OnFieldFlooded (int fieldPosX, int fieldPosY);

		List<IAction> GetNextActions();
	}
}

