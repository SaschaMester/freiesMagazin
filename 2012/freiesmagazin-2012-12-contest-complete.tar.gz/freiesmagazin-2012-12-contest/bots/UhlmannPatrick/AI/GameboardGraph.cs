//
//  Copyright 2012  Patrick Uhlmann
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
using System;
using ArchesBotMono.DataStructure.Graph;

namespace ArchesBotMono
{
	public static class GameboardGraph
	{
		public static AdjacencyGraph<Field> GetGraphFromGameboard (Gameboard board)
		{
			var graph = new AdjacencyGraph<Field> ();

			// build all connections (does implicitly add the nodes as well)
			// but do not include water fields as they cannot be navigated on
			for (int x=0; x<board.Columns; x++) {
				for (int y=0; y<board.Rows; y++) {
					if (board.GetField (x, y).CurrentState != Field.State.Water) {
						ConnectToNorth (graph, board, x, y);
						ConnectToSouth (graph, board, x, y);
						ConnectToWest (graph, board, x, y);
						ConnectToEast (graph, board, x, y);
					}
				}
			}

			return graph;
		}

		private static void ConnectToNorth (AdjacencyGraph<Field> graph, Gameboard board, int x, int y)
		{
			int YTo = y - 1;
			int XTo = x;

			if (YTo >= 0 && board.GetField (XTo, YTo).CurrentState != Field.State.Water) {
				graph.AddEdge (board.GetField (x, y), board.GetField (XTo, YTo));
			}
		}

		private static void ConnectToSouth (AdjacencyGraph<Field> graph, Gameboard board, int x, int y)
		{
			int YTo = y + 1;
			int XTo = x;

			if (YTo < board.Rows && board.GetField (XTo, YTo).CurrentState != Field.State.Water) {
				graph.AddEdge (board.GetField (x, y), board.GetField (XTo, YTo));
			}
		}

		private static void ConnectToEast (AdjacencyGraph<Field> graph, Gameboard board, int x, int y)
		{
			int YTo = y;
			int XTo = x + 1;

			if (XTo < board.Columns && board.GetField (XTo, YTo).CurrentState != Field.State.Water) {
				graph.AddEdge (board.GetField (x, y), board.GetField (XTo, YTo));
			}
		}

		private static void ConnectToWest (AdjacencyGraph<Field> graph, Gameboard board, int x, int y)
		{
			int YTo = y;
			int XTo = x - 1;

			if (XTo >= 0 && board.GetField (XTo, YTo).CurrentState != Field.State.Water) {
				graph.AddEdge (board.GetField (x, y), board.GetField (XTo, YTo));
			}
		}
	}
}

