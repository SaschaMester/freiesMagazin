using System;

namespace ArchesBotMono
{
	public class Actions
	{
		public Actions ()
		{
		}
	}
}

