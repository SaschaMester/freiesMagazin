/* Copyright (c) 2013, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */

class Board {
	static def printlnErr = System.err.&println
	static def printErr = System.err.&print
	
	Integer rows
	Integer cols
	def board = []
	def floodlevel = 0
	def floodedSinceInrc = [] as Set
	def floodedSoon = [] as Set
	
	Integer onrow
	Integer oncol
	
	def ontile() {
		board[onrow][oncol]
	}
	
	def onSoonFlooded() {
		floodedSoon.contains([oncol, onrow])
	}
	
	def flood(col, row) {
		def tile = board[row][col]
		if(floodedSinceInrc.contains([col, row])) {
			// cards where shuffled
			floodedSoon += floodedSinceInrc
			floodedSinceInrc = []
		}
		if (tile=='#') {
			board[row][col] = 'o'
			floodedSinceInrc << [col, row]
			floodedSoon.remove([col, row])
		} else if (tile=='o') {
			board[row][col] = '.'
			floodedSoon.remove([col, row])
		} else {
			printlnErr "ERROR flood on $col,$row and field is of type $tile"
		}
	}
	
	def incrflood(level) {
		if(level!=0) {
			floodlevel += level
			floodedSoon += floodedSinceInrc
			floodedSinceInrc = []
		}
	}
	
	def set(col, row, tile) {
		board[row][col] = tile
	}
	
	def dry(col, row) {
		board[row][col] = '#'
		["col": col, "row": row]
	}
	
	def remainingCards() {
		board.sum().join().count('#')+board.sum().join().count('o')-floodedSinceInrc.size()
	}
}
