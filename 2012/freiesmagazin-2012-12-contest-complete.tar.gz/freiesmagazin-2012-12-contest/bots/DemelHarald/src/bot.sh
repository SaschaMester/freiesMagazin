#!/bin/bash
pushd `dirname $0` > /dev/null
groovy Harbot.groovy
popd > /dev/null
