/* Copyright (c) 2013, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */

import javax.swing.Spring.SumSpring;

class Harbot {
	
	static def actions=["DRY","GO"]
	static def directions=["CURRENT","NORTH","EAST","SOUTH","WEST"]
	
	static def drycurrentmove = possibleMoves()[0]
	static def otherdrymoves = possibleMoves()[1..4]
	static def gomoves = possibleMoves()[5..9]
	
	static 	def board
	
	static main(args) {
		
		def gameboardsubmission = false
		
		System.in.eachLine() { line ->
			switch(line) {
				case ~/ROUND \d+ \d+,\d+/:
					def m = line =~ /\d+/
					def round = m[0].toInteger()   // round staring from 1
					def oncol = m[1].toInteger()-1 // col starting from 0 (after correction)
					def onrow = m[2].toInteger()-1 // row starting from 0 (after correction)
					if(round==1) {
						board.onrow = onrow
						board.oncol = oncol
					} else {
						if(board.onrow != onrow || board.oncol != oncol) {
							System.err.println "ERROR on wrong position"
						}
					}
					def bestmoves = getBestMove(round)
					println bestmoves[0] + " " + bestmoves[1]
					doMove([bestmoves[0], bestmoves[1]])
					println bestmoves[2] + " " + bestmoves[3]
					doMove([bestmoves[2], bestmoves[3]])
					println bestmoves[4] + " " + bestmoves[5]
					doMove([bestmoves[4], bestmoves[5]])
					break
				case ~/FLOOD \d+,\d+/:
					def m = line =~ /\d+/
					def floodcol = m[0].toInteger()-1 // col starting from 0 (after correction)
					def floodrow = m[1].toInteger()-1 // row starting from 0 (after correction)
					board.flood(floodcol, floodrow)
					break
				case ~/INCRFLOOD \d+/:
					def m = line =~ /\d+/
					def incrflood = m[0].toInteger()
					board.incrflood(incrflood)
					break
				case ~/GAMEBOARDSTART \d+,\d+/:
					def m = line =~ /\d+/
					board = new Board(cols: m[0].toInteger(), rows: m[1].toInteger())
					gameboardsubmission = true
					break
				case ~/[\.o\#]+/:
					if(!gameboardsubmission) {
						System.err.println "ERROR: line of gamebord outside GAMEBOARDSTART..GAMEBOARDEND"
						System.exit(1)
					}
					board.board << line.collect{it}
					break
				case ~/GAMEBOARDEND/:
					if(! board.board.size() == board.rows) {
						System.err.println "ERROR: wrong number of rows"
						System.exit(1)
					}
					if(! board.board.every{it.size() == board.cols}) {
						System.err.println "ERROR: wrong number of cols in at least one line"
						System.exit(1)
					}
					gameboardsubmission = false
					break
				case ~/END/:
					System.exit(0)
				case ~/TEST/:
					def gotopointsmap = getGotopointsMap()
					def riskmap = getRiskMap()
					def distmap = getDistMap(riskmap)
					
					System.err.println()
					for ( r in 0..<board.rows ) {
						for ( c in 0..<board.cols ) {
							 System.err.print String.format('%1.2f ', distmap[r][c])
						}
						System.err.println()
					}
					break
				default:
					System.err.println "ERROR: WRONG LINE " + line
					System.exit(1)
			}
		}
	}
	
	static printStatus() {		
		System.err.println "----Status---"
		System.err.println "cols " + board.cols
		System.err.println "rows " + board.rows
		System.err.println "board " + board.board
		System.err.println "oncol " + board.oncol
		System.err.println "onrow " + board.onrow
		System.err.println "floodlevel " + board.floodlevel
		System.err.println "floodedSinceInrc " + board.floodedSinceInrc
		System.err.println "floodedSoon " + board.floodedSoon
		System.err.println "---EndStatus--"
	}
	
	static crossProduct(xs,ys)  {
		xs.collect{x-> ys.collect{y-> [x,y]}}.sum()
	}
	
	static benchmark = { closure ->
		def start = System.currentTimeMillis()
		closure.call()
		def now = System.currentTimeMillis()
		now - start
	  }
	
	static possibleMoves() { crossProduct(actions, directions) }
	
	static getGotopointsMap() {
		board.board.collect{it.collect{
			switch(it) {
				case '#': return 1
				case 'o': return 1000
				default: return 0 
			}
		} }
	}
	
	static getDistMap(riskmap) {
		def map = board.board.collect{it.collect{1073741823}}
		def nextup = [] as Set
		def nowup = [] as Set
		map[board.onrow][board.oncol] = 1
		nowup << [board.oncol, board.onrow-1] << [board.oncol, board.onrow+1] << [board.oncol-1, board.onrow] << [board.oncol+1, board.onrow]
		
		while(!nowup.isEmpty()) {
			for (cr in nowup) {
				def (c,r) = cr 
				if(r>=0 && r<board.rows && c>=0 && c<board.cols && board.board[r][c]!='.') {
					def riskcost = 1-riskmap[r][c]
					if(r>0 && map[r-1][c]+riskcost < map[r][c]) {
						map[r][c] = map[r-1][c]+riskcost
						nextup << [c,r-1] << [c,r+1] << [c-1,r] << [c+1,r]
					}
					if(r+1<board.rows && map[r+1][c]+riskcost < map[r][c]) {
						map[r][c] = map[r+1][c]+riskcost
						nextup << [c,r-1] << [c,r+1] << [c-1,r] << [c+1,r]
					}
					if(c>0 && map[r][c-1]+riskcost < map[r][c]) {
						map[r][c] = map[r][c-1]+riskcost
						nextup << [c,r-1] << [c,r+1] << [c-1,r] << [c+1,r]
					}
					if(c+1<board.cols && map[r][c+1]+riskcost < map[r][c]) {
						map[r][c] = map[r][c+1]+riskcost
						nextup << [c,r-1] << [c,r+1] << [c-1,r] << [c+1,r]
					}
				}
			}
			nowup = nextup
			nextup = [] as Set
		}
		
		return map.collect{it.collect{Math.sqrt(1.0d/it)}}
	}
	
	static getRiskMap() {
		def map = board.board.collect{it.collect{it=='.'?0.0f:it=='o'?0.8f:1.0f}}
		4.times{
			def map2 = map.collect{it.collect{0.0f}}
			for (r in 0..<board.rows) {
				for (c in 0..<board.cols) {
					if(board.board[r][c]!='.') {
						def neighbours = 0.0f
						if(r>0) {
							neighbours += map[r-1][c]
						}
						if(r+1<board.rows) {
							neighbours += map[r+1][c]
						}
						if(c>0) {
							neighbours += map[r][c-1]
						}
						if(c+1<board.cols) {
							neighbours += map[r][c+1]
						}
						map2[r][c] = neighbours/4.0f
					}
				}
			}
			map = map2
		}
		return map
		
	}
	
	static getTravelScore() {
		def score = 0.0d		
		def gotopointsmap = getGotopointsMap()
		def riskmap = getRiskMap()
		def distmap = getDistMap(riskmap)
		
		for ( r in 0..<board.rows ) {
			for ( c in 0..<board.cols ) {
				score += gotopointsmap[r][c]*distmap[r][c]
			}
		}
		return score
	}
	
	static getScore() {		
		def drypoints = board.board.sum().join().count('#')*2+board.board.sum().join().count('o')
		def pospoints = 0
		if(board.remainingCards()>=board.floodlevel) {
			switch(board.ontile()){
				case '#':
					pospoints += 11
					break;
				case 'o':
					pospoints += 10
					break;
			}
		} else {
			switch(board.ontile()){
				case '#':
					pospoints += 100 - (board.onSoonFlooded()?10:0)
					break;
				case 'o':
					pospoints += 0 - (board.onSoonFlooded()?100000:0)
					break;
			}
		}
		
		drypoints+pospoints
	}
	
	static def bestscore = 0
	
	static getBestMove(round ) {
		bestscore = 0
		def moves = getBestAfterMoves(round)
		def bestrated = moves.findAll{it[-1]==bestscore}
		if(bestrated.size()==1) {
			return bestrated[0]
		}
		def cache = [:]
		def exactlyreated = bestrated.collect{
			def r1 = doMove([it[0],it[1]])
			def r2 = doMove([it[2],it[3]])
			def r3 = doMove([it[4],it[5]])
			def key = [board.oncol, board.onrow, board.board]
			if(cache[key]==null) {
				cache[key] = getTravelScore()				
			}
			it[-1] = cache[key]
			undoMove(r3)
			undoMove(r2)
			undoMove(r1)
			return it
		}
		return moves.max{it[-1]}
	}
	
	// returns [["GO/DRY", "DIR"]*1..3 + [SCORE]]
	static getBestAfterMoves(round, moves=3) {
		if (moves==0){
			def score = getScore()
			if(score>=bestscore) {
				bestscore=score
				return [score]
			} else {
				return []
			}
		} else {
			def movescores = []
			if(canMove(drycurrentmove)) {
				def revertinfo = doMove(drycurrentmove)
				movescores += getBestAfterMoves(round, moves-1).collect{drycurrentmove+it}
				undoMove(revertinfo)
			}
			if(movescores.isEmpty() || board.remainingCards()<board.floodlevel) {
				otherdrymoves.each{ move ->
					if(canMove(move)) {
						def revertinfo = doMove(move)
						movescores += getBestAfterMoves(round, moves-1).collect{move+it}
						undoMove(revertinfo)
					}
				}
				if(movescores.isEmpty() || board.remainingCards()<board.floodlevel) {
					gomoves.each{ move ->
						if(canMove(move)) {
							def revertinfo = doMove(move)
							movescores += getBestAfterMoves(round, moves-1).collect{move+it}
							undoMove(revertinfo)
						}
					}
				}
			}
			return movescores
		}
	}
	
	static canMove(move) {
		switch(move[0]) {
			case "GO":
				return existstField(move[1]) && typeOfField(move[1], "o#")
			case "DRY":
				return existstField(move[1]) && typeOfField(move[1], "o")
			default:
				System.err.println "ERROR in canMove"
		}
	}
	
	static existstField(direction) {
		switch(direction) {
			case "NORTH":
				return board.onrow>0
			case "EAST":
				return board.oncol+1<board.cols
			case "SOUTH":
				return board.onrow+1<board.rows
			case "WEST":
				return board.oncol>0
			case "CURRENT":
				return true
			default:
				System.err.println "ERROR in doGO"
		}
	}
	
	
	
	static typeOfField(direction, type) {
		def row=board.onrow
		def col=board.oncol
		switch(direction) {
			case "NORTH":
				row-=1
				break
			case "EAST":
				col+=1
				break
			case "SOUTH":
				row+=1
				break
			case "WEST":
				col-=1
				break
			case "CURRENT":
				break
			default:
				System.err.println "ERROR in doGO"
		}
		return type.contains(board.board[row][col])
	}
	
	static doMove(move) {
		switch(move[0]) {
			case "GO":
				return doGO(move[1])
			case "DRY":
				return doDRY(move[1])
			default:
				System.err.println "ERROR in doMOVE"
		}
	}
	
	static doGO(direction) {
		switch(direction) {
			case "NORTH":
				def undoinfo = ["onrow": board.onrow]
				board.onrow -= 1
				return undoinfo
			case "EAST":
				def undoinfo = ["oncol": board.oncol]
				board.oncol += 1
				return undoinfo
			case "SOUTH":
				def undoinfo = ["onrow": board.onrow]
				board.onrow += 1
				return undoinfo
			case "WEST":
				def undoinfo = ["oncol": board.oncol]
				board.oncol -= 1
				return undoinfo
			case "CURRENT":
				return [:]
			default:
				System.err.println "ERROR in doGO"
		}
	}
	
	static doDRY(direction) {
		switch(direction) {
			case "NORTH":
				return board.dry(board.oncol, board.onrow-1)
			case "EAST":
				return board.dry(board.oncol+1, board.onrow)
			case "SOUTH":
				return board.dry(board.oncol, board.onrow+1)
			case "WEST":
				return board.dry(board.oncol-1, board.onrow)
			case "CURRENT":
				return board.dry(board.oncol, board.onrow)
			default:
				System.err.println "ERROR in doDRY"
		}
	}
	
	static undoMove(undoinfo) {
		if(undoinfo.onrow!=null) {
			board.onrow = undoinfo.onrow
		}
		if(undoinfo.oncol!=null) {
			board.oncol = undoinfo.oncol
		}
		if(undoinfo.col!=null) {
			board.set(undoinfo.col, undoinfo.row, "o")
		}
	}
}
