#!/usr/bin/env python3
#===============================================================================
#    (C) Copyright 2012 Christoph Staudinger
#
#    This file is part of Islandbot
# 
#    Islandbot is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
# 
#    Islandbot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
# 
#    You should have received a copy of the GNU General Public License
#    along with Islandbot.  If not, see <http://www.gnu.org/licenses/>.
#===============================================================================

import sys
from iohandler import IOHandler
from island import *
from Player import Player

class Game:
    def __init__(self, sb=3, smv=0.001, lb=1.3, le=3, lmv=0.1, short_border=0.15, short_wet_bonus = 0):
        self.short_basis = sb
        self.short_move_value = smv
        self.long_basis = lb
        self.long_exponent = le
        self.long_move_value = lmv
        self.short_border = short_border
        self.short_wet_bonus = short_wet_bonus
        self.io = IOHandler()
        self.gameboard = None
        self.getGameBoard()
        self.figure = None
        self.player = Player(self)
        self.round = 0
        self.floodlevel = 0
    
    def getFloodProbability(self):
        return self.floodlevel / self.gameboard.getNOFDryFields()
    
    def getGameBoard(self):
        width, height = self.io.getGameboardStart()
        tilestring = self.io.getGameboardTiles(height)
        self.io.getGameboardEnd()
        self.gameboard = Board(self, width, height, tilestring)
        #if width * height <= 250:
        #    self.long_basis -= 0.1
        #elif width * height <= 500:
        #    self.long_basis -= 0.05
    
    def executeAction(self, action):
        self.io.sendAction(action)
    
    def floodTile(self, x, y):
        self.gameboard.flood(x, y)
    
    def run(self):
        while True:
            roundnumber, x, y = self.io.getRound()
            if roundnumber == False and x == False and y == False: # = END of game
                break
            if not self.figure: # first round initialisation
                self.figure = Figure(self.gameboard, x, y)
            self.round = roundnumber
                
            for action in self.player.getActions():
                self.executeAction(action)
            
            flood = self.io.getFlood()
            if flood and self.floodlevel < 7:
                self.floodlevel +=1
            for i in range(self.floodlevel):
                x, y = self.io.getFloodedTile()
                self.floodTile(x, y)

if __name__ == '__main__':
    if len(sys.argv) == 7:
        l = [float(x) for x in sys.argv[1:]]
        game = Game(l[0], l[1], l[2], l[3], l[4], l[5])
    else:
        game = Game()
    game.run()
