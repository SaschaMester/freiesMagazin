#!/usr/bin/env python3
#===============================================================================
#    (C) Copyright 2012 Christoph Staudinger
#
#    This file is part of Islandbot
# 
#    Islandbot is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
# 
#    Islandbot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
# 
#    You should have received a copy of the GNU General Public License
#    along with Islandbot.  If not, see <http://www.gnu.org/licenses/>.
#===============================================================================

class Player:
    def __init__(self, game):
        self.game = game
        self.strategy = DryAsMuchAsPossible(self)
        self.changedToLastStand = False
    
    def getActions(self):
        #self.decideStrategy()
        return self.strategy.run()
    
class DryAsMuchAsPossible:
    def __init__(self, player):
        self.player = player
        self.game = player.game
        self.action_queue = []
        self.exp_basis = None
        self.sb = self.player.game.short_basis
        self.smv = self.player.game.short_move_value
        self.lb = self.player.game.long_basis
        self.le = self.player.game.long_exponent
        self.lmv = self.player.game.long_move_value
        self.swb = self.player.game.short_wet_bonus

    def getBorder(self):
        #return 0.1 + 0.00017 * self.game.gameboard.getNOFAccessAbleFields()
        b = 0.074 + 0.00013 * self.game.gameboard.getNOFAccessAbleFields() + 0.00006 * self.game.gameboard.width * self.game.gameboard.height 
        return max(b, 0.1)

    border = property(getBorder)
    
    def getFigure(self):
        return self.game.figure

    figure = property(getFigure)
    
    def getBoard(self):
        return self.game.gameboard
    
    board = property(getBoard)
    
    def queueMoveAction(self, direction):
        self.figure.move(direction)
        self.action_queue.append(direction)
    
    def queueDryAction(self, direction):
        self.figure.dry(direction)
        self.action_queue.append('d' + direction)
    
    def getQueue(self):
        queue = self.action_queue
        self.action_queue = []
        return queue
    
    def run(self):
        with open('NOFAccess.txt', 'a') as f:
            f.write(str(self.game.gameboard.getNOFAccessAbleFields()) + '\n')
        while len(self.action_queue) < 3:
            while self.dry():
                if len(self.action_queue) > 2:
                    break
            if len(self.action_queue) < 3:
                self.move()
        return self.getQueue()
    
    def dry(self):
        flooded = self.figure.tile.getSurrounding('o')
        if not flooded:
            return False
        if 'C' in flooded:
            self.queueDryAction('C')
        else:
            self.queueDryAction(flooded[0])
        return True
             
    def move(self):
        directions = self.getDirectionByBestPaths()
        self.queueMoveAction(directions[0][0])
    
    def getDirectionByBestPaths(self):
        ms = MasterScout(self.figure.tile)
        ret = ms.run(10)
        dir_points = []
        for d, path in ret:
            points = self.calculatePointsForPath(path)
            dir_points.append((d, points))
        dir_points.sort(key=lambda x: x[1], reverse=True)

        if not dir_points:
            return 'C'

        if dir_points[0][1] < self.border: #self.game.short_border:
            ret = ms.run()
            dir_points = []
            for d, path in ret:
                points = self.calculatePointsForPath(path, longdist=True)
                dir_points.append((d, points))
            dir_points.sort(key=lambda x: x[1], reverse=True)

        return dir_points

    def calculatePointsForPath(self, path, longdist=False):
        points = 0.0
        for t, dist in path:
            if longdist:
                #points += (self.lb ** -dist) * (t.NOFwet ** self.le + self.lmv*t.NOFreach)
                points += (self.lb ** -dist) * (t.getNOFSurrounding('o') ** self.le + self.lmv*(5-t.getNOFSurrounding('.')))
            else:
                #points += (self.sb ** - dist) * ( 1 if t.status == 'o' else 0 + self.smv*t.NOFreach)
                points += (self.sb ** - dist) * ( 1 if t.status == 'o' else 0 + self.smv*(5- t.getNOFSurrounding('.')))
                #points += (self.sb ** - dist) * ( 1 if t.status == 'o' else 0 + self.swb * t.getNOFSurrounding('o') + self.smv*(5- t.getNOFSurrounding('.')))
        return points
        #1.8^d * (1 wenn o + 0.05 * (5- not .)) * 1000 + 1.2^d * (surrounding o ^3 + (5- not .))
    
class MasterScout:
    def __init__(self, tile, max_depth=None):
        self.max_depth = max_depth
        self.tile = tile
        self.active_scouts = []
        self.finished_scouts = []
        self.foundtiles = {}
        self.foundtiles[self.tile] = 0
        for direction in ['N', 'E', 'S', 'W']:
            if tile.directions[direction] and tile.directions[direction].status != '.':
                self.active_scouts.append((direction, Scout(self, tile.directions[direction])))
    
    def run(self, max_depth=None):
        self.max_depth = max_depth
        self.active_scouts.extend(self.finished_scouts)
        self.finished_scouts = []
        while self.active_scouts:
            for d, s in self.active_scouts:
                if not s.step():
                    self.finished_scouts.append((d, s))
                    self.active_scouts.remove((d, s))
        return [(entry[0], entry[1].getResults()) for entry in self.finished_scouts]

class Scout:
    def __init__(self, master, tile):
        self.master = master
        self.tile = tile
        self.distance = 1
        self.active_tiles = [tile]
        self.found_tiles = [(tile, self.distance)]
        self.master.foundtiles[tile] = self.distance
    
    def step(self):
        if self.master.max_depth and self.distance > self.master.max_depth:
            return False
        self.distance += 1
        new_active_tiles = []
        for tile in self.active_tiles:
            for direction in ['N', 'E', 'S', 'W']:
                new_tile = tile.directions[direction]
                if not new_tile or new_tile.status == '.':
                    continue
                try:
                    if self.master.foundtiles[new_tile] < self.distance:
                        continue
                except KeyError:
                    pass
                if new_tile in [tup[0] for tup in self.found_tiles]:
                    continue
                self.found_tiles.append((new_tile, self.distance))
                self.master.foundtiles[new_tile] = self.distance
                new_active_tiles.append(new_tile)
        self.active_tiles = new_active_tiles
        if not self.active_tiles:
            return False
        return True
    
    def getResults(self):
        return self.found_tiles
         
