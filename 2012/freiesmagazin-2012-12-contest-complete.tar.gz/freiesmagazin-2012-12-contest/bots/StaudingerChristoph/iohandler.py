#!/usr/bin/env python3
#===============================================================================
#    (C) Copyright 2012 Christoph Staudinger
#
#    This file is part of Islandbot
# 
#    Islandbot is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
# 
#    Islandbot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
# 
#    You should have received a copy of the GNU General Public License
#    along with Islandbot.  If not, see <http://www.gnu.org/licenses/>.
#===============================================================================

import sys
import re

class IOHandler:
    def __init__(self):
        self.actions = {}
        self.actions['C'] = 'GO CURRENT'
        self.actions['N'] = 'GO NORTH'
        self.actions['E'] = 'GO EAST'
        self.actions['S'] = 'GO SOUTH'
        self.actions['W'] = 'GO WEST'
        self.actions['dC'] = 'DRY CURRENT'
        self.actions['dN'] = 'DRY NORTH'
        self.actions['dE'] = 'DRY EAST'
        self.actions['dS'] = 'DRY SOUTH'
        self.actions['dW'] = 'DRY WEST'
    
    def receive(self):
        string = sys.stdin.readline().strip()
        return string
        
    def send(self, string):
        print(string, file=sys.stdout)
        sys.stdout.flush()
        
    def sendAction(self, action):
        self.send(self.actions[action])
    
    def getGameboardStart(self):
        startstring = self.receive()
        m = re.match(r'GAMEBOARDSTART (\d+),(\d+)', startstring)
        if not m:
            self.hacf("GAMEBOARDSTART not found")
        width = int(m.group(1))
        height = int(m.group(2))
        return width, height
    
    def getGameboardTiles(self, lines):
        tiles = ''
        for line in range(lines):
            tiles += self.receive()
        return tiles
    
    def getGameboardEnd(self):
        endstring = self.receive()
        if not re.match(r'GAMEBOARDEND', endstring):
            self.hacf("GAMEBOARDEND not found")
        return False
    
    def getRound(self):
        string = self.receive()
        if re.match(r'END', string):
            return False, False, False
        match = re.match(r'ROUND (\d+) (\d+),(\d+)', string)
        return int(match.group(1)), int(match.group(2)), int(match.group(3))
    
    def getFlood(self):
        string = self.receive()
        match = re.match(r'INCRFLOOD (\d+)', string)
        return int(match.group(1))
    
    def getFloodedTile(self):
        string = self.receive()
        match = re.match(r'FLOOD (\d+),(\d+)', string)
        if not match:
            if re.match(r'END', string):
                exit(0) # really dirty hack TODO: something better
            self.hacf("could not read floodedtile")
        return int(match.group(1)), int(match.group(2))
    
    def hacf(self, errormessage=""): # halt and catch fire
        print("miep miep miep something went wrong what should not go wrong! miep miep miep", file=sys.stderr)
        print("A maybe helpfull message:", file=sys.stderr)
        print(errormessage, file=sys.stderr)
        print("exiting", file=sys.stderr)
        exit(-1)
 