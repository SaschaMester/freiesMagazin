#!/usr/bin/env python3
#===============================================================================
#    (C) Copyright 2012 Christoph Staudinger
#
#    This file is part of Islandbot
# 
#    Islandbot is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
# 
#    Islandbot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
# 
#    You should have received a copy of the GNU General Public License
#    along with Islandbot.  If not, see <http://www.gnu.org/licenses/>.
#===============================================================================

class Tile:
    def __init__(self, field, x, y, status):
        self.was_flooded = False
        self.field = field
        self.x = x
        self.y = y 
        self.status = status # # dry, o flooded, . water
        self.directions = {}
        self.directions['C'] = self
        self.directions['N'] = None
        self.directions['E'] = None
        self.directions['S'] = None
        self.directions['W'] = None
        self.NOFWetFieldsCache = None
        self.NOFReachableFieldsCache = None
    
    def setNSEW(self):
        if self.y > 1: # get North
            self.directions['N'] = self.field.tiles[self.x][ self.y - 1]
        if self.x > 1: # get West
            self.directions['W'] = self.field.tiles[self.x - 1][ self.y]
        if self.y < self.field.height:
            self.directions['S'] = self.field.tiles[self.x][ self.y + 1]
        if self.x < self.field.width:
            self.directions['E'] = self.field.tiles[self.x + 1][ self.y]
    
    def flood(self):
        if self.status == '#':
            self.status = 'o'
        elif self.status == 'o':
            self.status = '.'
        self.was_flooded = True
        return self.status
        for i in ['C', 'N', 'E', 'S', 'W']:
            if self.directions[i]:
                self.directions[i].NOFWetFieldsCache = None
                self.directions[i].NOFReachableFieldsCache = None
    
    def dry(self):
        self.status = '#'
        for i in ['C', 'N', 'E', 'S', 'W']:
            if self.directions[i]:
                self.directions[i].NOFWetFieldsCache = None
                self.directions[i].NOFReachableFieldsCache = None
    
    def getSurrounding(self, status):
        ret = []
        for i in ['C', 'N', 'E', 'S', 'W']:
            if self.directions[i] and self.directions[i].status == status:
                ret.append(i)
        return ret
    
    def getNOFSurrounding(self, status):
        p = 0
        for i in ['C', 'N', 'E', 'S', 'W']:
            if self.directions[i] and self.directions[i].status == status:
                p += 1
        return p
    
    def getNOFWetSurrounding(self):
        if self.NOFWetFieldsCache:
            return self.NOFWetFieldsCache
        p = 0
        for i in ['C', 'N', 'E', 'S', 'W']:
            if self.directions[i] and self.directions[i].status == 'o':
                p += 1
        self.NOFWetFieldsCache = p
        return p
    NOFwet = property(getNOFWetSurrounding)
    
    def getNOFReachableSurrounding(self):
        if self.NOFReachableFieldsCache:
            return self.NOFReachableFieldsCache
        p = 0
        for i in ['C', 'N', 'E', 'S', 'W']:
            if self.directions[i] and (self.directions[i].status == '#' or self.directions[i].status == 'o'):
                p += 1
        self.NOFReachableFieldsCache = p
        return p
    NOFreach = property(getNOFReachableSurrounding)
            

class Figure:
    def __init__(self, board, x, y):
        self.board = board
        self.x = x
        self.y = y 
        self.tile = board.tiles[x][y]
    
    def move(self, direction):
        if not self.tile.directions[direction]:
            self.board.game.io.hacf("can not move {} to tile!".format(direction))
        self.tile = self.tile.directions[direction]
        self.x = self.tile.x
        self.y = self.tile.y
    
    def dry(self, direction):
        self.tile.directions[direction].dry()
    
    def copy(self):
        return Figure(self.board, self.x, self.y)

class Board:
    def __init__(self, game, width, height, tiles):
        self.game = game
        self.width = width
        self.height = height
        self.tiles = {}
        self.__NOFAccessAbleFields = 0
        for i in range(1, self.width + 1):
            self.tiles[i] = {}
        self.tilelist = []
        x = 0
        y = 1
        for f in tiles:
            x += 1
            if x > self.width:
                x = 1
                y += 1
            self.addTile(f, x, y)
        for tile in self.tilelist:
            tile.setNSEW()
        self.NOFAccessAbleCachedRound = 0
    
    def getNOFDryFields(self):
        n = 0
        for t in self.tilelist:
            if t.status == '#':
                n += 1
        return n
    
    def getNOFAccessAbleFields(self):
        if self.NOFAccessAbleCachedRound != self.game.round or not self.__NOFAccessAbleFields:
            n = 0
            for t in self.tilelist:
                if t.status != '.':
                    n += 1
            self.__NOFAccessAbleFields = n
            self.NOFAccessAbleCachedRound = self.game.round
            return n
        else:
            return self.__NOFAccessAbleFields
    
    def copy(self):
        tiles = ''
        for tile in self.tilelist:
            tiles += tile.status
        return Board(self.game, self.width, self.height, tiles)
    
    def addTile(self, f, x, y):
        tile = Tile(self, x, y, f)
        self.tilelist.append(tile)
        self.tiles[x][y] = tile
        
    def printfield(self):
        for y in range(1, self.height + 1):
            for x in range(1, self.width + 1):
                print(self.tiles[x][y].status, end='')
            print('')
    
    def printconnectors(self):
        for y in range(1, self.height + 1):
            for x in range(1, self.width + 1):
                for i in ['C', 'N', 'E', 'S', 'W']:
                    print(i + '   ' + str(self.tiles[x][y].directions[i]), end='')
                print()
    
    def flood(self, x, y):
        if self.tiles[x][y].status == 'o':
            self.__NOFAccessAbleFields -= 1
        self.tiles[x][y].flood()
    
    def dry(self, x, y):
        self.tiles[x][y].dry()           
        
    
    
        
