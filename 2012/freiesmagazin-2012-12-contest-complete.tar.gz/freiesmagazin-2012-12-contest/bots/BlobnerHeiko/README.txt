Wahnsinnige kurze README mit Anleitung zum Bau und Betrieb.

Genutzt wird gradle in der Version 1.3 als Build System.
Alle benötigten Komponenten zum Übersetzen und Packen des 
jar-Archives werden von gradle 'besorgt'.

Das einzige was benötigt wird ist eine Java-Installation - 
ich habe die Version 1.7-11 genutzt

Zum Bauen den Befehl:
  gradle assemble
eingeben. Das jar-File sollte sich nach dem erfolgreichen Bau in 
  ./build/libs/islander-0.0.17.jar befinden.

Das Spiel habe ich dann mit:
./start_single_contest.sh "java -jar 
/home/hblobner/Work/Projects/Islander/build/libs/islander-0.0.17.jar" mybot 10 --log
gestartet.
Das Scala-Framwork wird in das jar mit eingepackt, so dass keine zusätzlichen 
Pfade angegeben werden müssen.

Viel Spass.
