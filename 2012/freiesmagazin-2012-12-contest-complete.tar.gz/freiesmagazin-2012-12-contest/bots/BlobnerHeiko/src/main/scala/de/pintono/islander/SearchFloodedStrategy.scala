/*
 * A bot coded to win the 6. freiesMagazin-Programmierwettbewerb.
 *
 * Copyright (C) 2013  Heiko Blobner
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.pintono.islander

import collection.mutable.ArrayBuffer
import scala.util.control.Breaks._

/**
 * Created by me.
 * User: Heiko Blobner
 * Mail: heiko.blobner@gmx.de
 *
 * Date: 07.01.13
 * Time: 21:29
 *
 * Strategie:
 * Der Bot legt die angrenzenden Bereiche trocken und schaut im Umlad was denn für ihn ein lohnendes
 * Feld zum Besuchen sein könnte (lohnend = viele Flut-Felder drumherum)
 */
class SearchFloodedStrategy(
  pathRate_len1: Int = 292,
  pathRate_len2: Int = 40,
  pathRate_len3: Int = 1
  )
  extends Strategy {
  /**
   * All deriving classes must define this method, so the exec method can either trim the returned list to 3 commands
   * or fill up to 3 commands
   *
   * @param botRowPos bot row position
   * @param botColumnPos bot column position
   * @return bot commands
   */
  protected def childExec(
    botRowPos: Int,
    botColumnPos: Int) = {
    board.get(botRowPos, botColumnPos) match {
      case Some(x) =>
        val cmds = new ArrayBuffer[String]()

        // 1. dry current
        if (x.state == FieldState.flooded) {
          cmds += Command.DRY_CURRENT
        }
        // 2. dry neighbours
        cmds ++= dryNeighbours(Some(x))
        // 3. update board
        updateCmdsToBoard(botRowPos, botColumnPos, cmds.slice(0, 3).toList)
        // 4. walk
        breakable {
          while (cmds.size < 3) {
            val walkTo = if (cmds.size == 0) {
              (   board.getFields(botRowPos, botColumnPos, FieldState.flooded, andMoves = 1)
               ++ board.getFields(botRowPos, botColumnPos, FieldState.flooded, andMoves = 2)
               ++ board.getFields(botRowPos, botColumnPos, FieldState.land   , andMoves = 3))
            } else if (cmds.size == 1) {
              (   board.getFields(botRowPos, botColumnPos, FieldState.flooded, andMoves = 1)
               ++ board.getFields(botRowPos, botColumnPos, FieldState.land   , andMoves = 2))
            } else if (cmds.size == 2) {
              board.getFields(botRowPos, botColumnPos, FieldState.land, andMoves = 1)
            } else {
              List.empty
            }

            val rated = walkTo.map(f => (f -> rateUmfeldAndDistance(x, f)))
            val ratedSorted = rated.sortBy(_._2)

            if (ratedSorted.size != 0) {
              val goal = ratedSorted.last._1
              cmds ++= moveTo(x, goal)
              if (goal.state == FieldState.flooded)
                cmds += Command.DRY_CURRENT
              cmds ++= dryNeighbours(Some(goal))
              // 4.x update board
              updateCmdsToBoard(botRowPos, botColumnPos, cmds.slice(0, 3).toList)
            } else {
              break()
            }
          }
        }

        cmds.toList

      case None => List.empty
    }
  }

  /**
   * Feld bewerten: Ist es sinnvoll den Bot hierher fahren zu lassen?
   *
   * Feld-Zustände ergeben folgende Wertigkeit:
   * flodded = 200
   * land    = 2
   * watered = 0
   *
   * @param field zu bewertendes Feld
   */
  def rate(field: Field) = field.state match {
    case FieldState.flooded => 200
    case FieldState.land    => 2
    case FieldState.watered => 0
  }

  /**
   * Feld und sein Umfeld bewerten
   *
   * @param field zu bewertendes Feld
   */
  def rateUmfeld(field: Field) = {
    if (field.state == FieldState.watered)
      -1
    else
      List[Option[Field]](
        board.get(field.row-1, field.col  ),
        board.get(field.row  , field.col+1),
        board.get(field.row+1, field.col  ),
        board.get(field.row  , field.col-1)
      ).filter(_ != None)
        .foldLeft(rate(field)){(v,f) =>
        v + (f match {
          case Some(x) => rate(x)
          case None => 0
        })
      }
  }

  /**
   * Feld und sein Umfeld bewerten inkl. der Entfernung von einem Basisfeld.
   *
   * Entfernungs-Multiplikator:
   *   0 Felder: 190
   *   1 Feld:   70
   *   2 Felder: 15
   * >=3 Felder:  1
   *
   * @param startField Bewegung von diesem Feld an berechnen
   * @param checkField zu bewertendes Feld
   */
  def rateUmfeldAndDistance(startField: Field, checkField: Field) = {
    if (checkField.state == FieldState.watered)
      -1
    else {
      val paths = board.calcRoutes(startField, checkField, maxMoves = 5).sortBy(_.size)
      val pathLength = if (paths.size > 0) paths.head.length else 0
      val multi = pathLength - 1 match {
        case 0 => pathRate_len1
        case 1 => pathRate_len2
        case 2 => pathRate_len3
        case _ => 1
      }

      List[Option[Field]](
        board.get(checkField.row-1, checkField.col  ),
        board.get(checkField.row  , checkField.col+1),
        board.get(checkField.row+1, checkField.col  ),
        board.get(checkField.row  , checkField.col-1)
      ).filter(_ != None)
       .foldLeft(rate(checkField)){(v,f) =>
        v + (f match {
          case Some(x) => rate(x)
          case None => 0
        })
      } * multi
    }
  }
}
