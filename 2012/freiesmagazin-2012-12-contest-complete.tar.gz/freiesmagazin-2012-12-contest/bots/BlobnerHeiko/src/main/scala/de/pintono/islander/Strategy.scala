/*
 * A bot coded to win the 6. freiesMagazin-Programmierwettbewerb.
 *
 * Copyright (C) 2013  Heiko Blobner
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.pintono.islander

/**
 * Created by me.
 * User: Heiko Blobner
 * Mail: heiko.blobner@gmx.de
 *
 * Date: 02.01.13
 * Time: 20:23
 */
abstract class Strategy {
  protected var _board: Board = null

  def board = _board
  def board_=(v: Board) { _board = v }

  /**
   * Calc 3 moves and return.
   *
   * @param botRowPos bot row position
   * @param botColumnPos bot column position
   * @return 3 bot commands
   */
  def exec(
    botRowPos: Int,
    botColumnPos: Int
    ): List[String] = {
    val cmds = childExec(botRowPos, botColumnPos)

    val ret = if (cmds.size > 3) {
      cmds.slice(0, 3)
    } else if (cmds.size < 3) {
      cmds ++ (cmds.size to 2).map(i => Command.GO_CURRENT).toList
    } else
      cmds

    updateCmdsToBoard(botRowPos, botColumnPos, ret)
    ret
  }

  def updateCmdsToBoard(
    botRowPos: Int,
    botColumnPos: Int,
    cmds: List[String]
    ) {
    var currentRowPos = botRowPos
    var currentColPos = botColumnPos
    cmds.foreach {c=>
      c match {
        case Command.DRY_CURRENT => board.set(currentRowPos  , currentColPos  , FieldState.land)
        case Command.DRY_NORTH   => board.set(currentRowPos-1, currentColPos  , FieldState.land)
        case Command.DRY_EAST    => board.set(currentRowPos  , currentColPos+1, FieldState.land)
        case Command.DRY_SOUTH   => board.set(currentRowPos+1, currentColPos  , FieldState.land)
        case Command.DRY_WEST    => board.set(currentRowPos  , currentColPos-1, FieldState.land)

        case Command.GO_CURRENT  =>
        case Command.GO_NORTH    => currentRowPos -= 1
        case Command.GO_EAST     => currentColPos += 1
        case Command.GO_SOUTH    => currentRowPos += 1
        case Command.GO_WEST     => currentColPos -= 1

        case _ =>
      }
    }
  }

  /**
   * All deriving classes must define this method, so the exec method can either trim the returned list to 3 commands
   * or fill up to 3 commands
   *
   * @param botRowPos bot row position
   * @param botColumnPos bot column position
   * @return bot commands
   */
  protected def childExec(
    botRowPos: Int,
    botColumnPos: Int
    ): List[String]

  /**
   * Dry all flooded neighbours.
   *
   * @param pos current bot position
   * @return list of dry commands
   */
  def dryNeighbours(
    pos: Option[Field]
    ): List[String] = {
    pos match {
      case Some(x) =>
        val l = board.getFields(x.row, x.col, FieldState.flooded, andMoves = 1)

        l.map{f =>
          if (x.row == f.row) {
            if (x.col == f.col - 1) {
              Command.DRY_EAST
            } else {
              Command.DRY_WEST
            }
          } else {
            if (x.row == f.row - 1) {
              Command.DRY_SOUTH
            } else {
              Command.DRY_NORTH
            }
          }
        }

      case None => List.empty
    }
  }

  /**
   * Calc shortest path an move to.
   *
   * @param pos current bot position
   * @param targetField hier soller hin
   * @return list of move commands
   */
  def moveTo(
    pos: Field,
    targetField: Field,
    andMoves: Int = 3
    ): List[String] = {
    val m = board.moveTo(pos, targetField, andMoves)

    if (m.size <= andMoves)
      m
    else
      List.empty
  }
}
