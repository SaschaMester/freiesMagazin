/*
 * A bot coded to win the 6. freiesMagazin-Programmierwettbewerb.
 *
 * Copyright (C) 2013  Heiko Blobner
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.pintono.islander

import collection.immutable.HashMap

/**
 * Created by me.
 * User: Heiko Blobner
 * Mail: heiko.blobner@gmx.de
 *
 * Date: 03.01.13
 * Time: 21:01
 *
 * Strategie:
 * Der Bot legt alle direkt angrenzenden Bereiche trocken. Falls das aktuelle Feld geflutet werden sollte,
 * bewegt er sich zu einem trockenem und legt wiederum alle angrenzenden Bereiche trocken.
 */
class SimpleDryLandStrategy
  extends Strategy {
  /**
   * All deriving classes must define this method, so the exec method can either trim the returned list to 3 commands
   * or fill up to 3 commands
   *
   * @param botRowPos bot row position
   * @param botColumnPos bot column position
   * @return bot commands
   */
  protected def childExec(
    botRowPos: Int,
    botColumnPos: Int
    ) = {
    board.get(botRowPos, botColumnPos) match {
      case Some(x) =>
        if (x.state == FieldState.land) {
          dryNeighbours(board.get(botRowPos, botColumnPos))
        } else{
          // bot is on flooded field:
          // 1. search dry fields within 1, 2, 3 moves
          val landFields = HashMap(
            1 -> board.getFields(botRowPos, botColumnPos, FieldState.land, andMoves = 1),
            2 -> board.getFields(botRowPos, botColumnPos, FieldState.land, andMoves = 2),
            3 -> board.getFields(botRowPos, botColumnPos, FieldState.land, andMoves = 3)
          )
          // 2. filter dry fields: wasFlooded == false
          val fuckIsThisDryLand = HashMap(
            1 -> landFields(1).filter(!_.wasFlooded),
            2 -> landFields(2).filter(!_.wasFlooded),
            3 -> landFields(3).filter(!_.wasFlooded)
          )
          // 3. merge all
          val merged = fuckIsThisDryLand(1) ++ fuckIsThisDryLand(2) ++ fuckIsThisDryLand(3) ++ landFields(1) ++ landFields(2) ++ landFields(3)

          // 3. go to driest field and dry neighbours
          if (merged.size > 0) {
            moveTo(x, merged(0)) ++ dryNeighbours(board.get(botRowPos, botColumnPos))
          } else {
            // fire in the hole, we are doomed
            List(Command.DRY_CURRENT) ++ dryNeighbours(board.get(botRowPos, botColumnPos))
          }
        }

      case None => List.empty
    }
  }
}
