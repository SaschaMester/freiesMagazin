/*
 * A bot coded to win the 6. freiesMagazin-Programmierwettbewerb.
 *
 * Copyright (C) 2013  Heiko Blobner
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.pintono.islander

import collection.mutable.ArrayBuffer

/**
 * Created by me.
 * User: Heiko Blobner
 * Mail: heiko.blobner@gmx.de
 *
 * Date: 02.01.13
 * Time: 20:20
 */
object Runner {
  val cmdline_arg_r = """--strategy=(.*)""".r
  val cmdline_arg_pathLen_r = """--pathlen=(\d+):(\d+):(\d+)""".r

  val gameBoardStart_r = """GAMEBOARDSTART (\d+),(\d+)""".r
  val gameBoardLine_r = """([\.o#]+)""".r
  val round_r = """ROUND (\d+) (\d+),(\d+)""".r
  val incFlood_r = """INCRFLOOD (\d+)""".r
  val flood_r = """FLOOD (\d+),(\d+)""".r

  /**
   * starter
   *
   * @param args cmd line args
   *             --strategy=DO_NOTHING
   *                        SIMPLE_DRY
   *                        SEARCH_FLOODED
   *                        DRY_NEAREST
   */
  def main(args: Array[String]) {
    var strategy: Option[Strategy] = None

    args.foreach{line=>
      line match {
        case cmdline_arg_r("DO_NOTHING") => strategy = Some(new DoNothingStrategy)
        case cmdline_arg_r("SIMPLE_DRY") => strategy = Some(new SimpleDryLandStrategy)
        case cmdline_arg_r("SEARCH_FLOODED") => strategy = Some(new SearchFloodedStrategy)
        case cmdline_arg_r("DRY_NEAREST") => strategy = Some(new DryNearestStrategy)
        case cmdline_arg_r("BETTER_FLOODED") => strategy = Some(new BetterFloodedStrategy)

        case cmdline_arg_pathLen_r(l1, l2, l3) => strategy = Some(new SearchFloodedStrategy(
          pathRate_len1 = l1.toInt,
          pathRate_len2 = l2.toInt,
          pathRate_len3 = l3.toInt
        ))

        case _ => // ignore
      }
    }

    playGame(strategy)
  }

  def playGame(strategy: Option[Strategy]) {
    var controller: Option[Controller] = None
    var gbRows = 0
    var gbCols = 0
    val gbLines = new ArrayBuffer[String]()

    Iterator
      .continually(Console.readLine())
      .takeWhile(_ != "END")
      .foreach {line=>
        line match {
          case gameBoardStart_r(cols, rows) =>
            gbRows = rows.toInt
            gbCols = cols.toInt

          case gameBoardLine_r(l) => gbLines += l
          case "GAMEBOARDEND" =>
            controller = Some(new Controller(
              columns = gbCols,
              rows = gbRows,
              boardSetup = gbLines.toList,
              botStrategy = strategy match {
                case Some(x) => x
                case None => new BetterFloodedStrategy
              }
            ))

          case round_r(round, botCol, botRow) => controller match {
              case Some(x) => x.round(roundCount = round.toInt, botRowPos = botRow.toInt, botColumnPos = botCol.toInt).foreach(Console.println(_))
              case None =>
            }

          case incFlood_r(count) => controller match {
              case Some(x) => x.incFlood(count.toInt)
              case None =>
            }
          case flood_r(fieldCol, fieldRow) => controller match {
              case Some(x) => x.flood(fieldRow.toInt, fieldCol.toInt)
              case None =>
            }

          case _ =>
        }
    }
  }
}
