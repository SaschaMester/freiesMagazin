/*
 * A bot coded to win the 6. freiesMagazin-Programmierwettbewerb.
 *
 * Copyright (C) 2013  Heiko Blobner
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.pintono.islander

/**
 * Created by me.
 * User: Heiko Blobner
 * Mail: heiko.blobner@gmx.de
 *
 * Date: 02.01.13
 * Time: 20:23
 */
class Controller(
  columns: Int,
  rows: Int,
  boardSetup: List[String],
  botStrategy: Strategy = new DoNothingStrategy
  ) {
  // fields
  private val board = new Board(columns, rows, boardSetup)
  private val bot = new Bot(
    board = board,
    strategy = botStrategy
  )

  /**
   * Flood the given field. If field is already flooded -> now it will be watered.
   *
   * @param row cell row to flood
   * @param column cell column to flood
   */
  def flood(
    row: Int,
    column: Int
    ) {
    if (board.get(row, column).get.state == FieldState.land)
      board.set(row, column, FieldState.flooded)
    else
      board.set(row, column, FieldState.watered)
  }

  /**
   * Server notify - server will flood #count fields per round.
   *
   * @param count number of fields will be flooded
   */
  def incFlood(count: Int) {
    // do nothing
  }

  /**
   * Start a new round.
   *
   * @param roundCount server send round count
   * @param botRowPos bot row position
   * @param botColumnPos bot column position
   * @return 3 bot commands
   */
  def round(
    roundCount: Int,
    botRowPos: Int,
    botColumnPos: Int
    ) = bot.exec(botRowPos, botColumnPos)
}
