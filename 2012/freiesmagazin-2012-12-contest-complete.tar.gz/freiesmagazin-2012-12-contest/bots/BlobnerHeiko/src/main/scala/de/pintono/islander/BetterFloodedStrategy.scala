package de.pintono.islander

import collection.mutable.ArrayBuffer

/**
 * Created by me.
 * User: Heiko Blobner
 * Mail: heiko.blobner@gmx.de
 *
 * Date: 17.01.13
 * Time: 21:32
 */
class BetterFloodedStrategy
  extends Strategy {
  private val lastPositions = new ArrayBuffer[(Int,Int)]()

  /**
   * All deriving classes must define this method, so the exec method can either trim the returned list to 3 commands
   * or fill up to 3 commands
   *
   * @param botRowPos bot row position
   * @param botColumnPos bot column position
   * @return bot commands
   */
  protected def childExec(botRowPos: Int, botColumnPos: Int) = {
    val currentField = board.get(botRowPos, botColumnPos).get

    val targetFields = Map(
      3 -> List(currentField),
      2 -> (board.getFields(botRowPos, botColumnPos, FieldState.land, 1) ++ board.getFields(botRowPos, botColumnPos, FieldState.flooded, 1)),
      1 -> (board.getFields(botRowPos, botColumnPos, FieldState.land, 2) ++ board.getFields(botRowPos, botColumnPos, FieldState.flooded, 2))
    )
    val moves = targetFields
      .flatMap(l => l._2.map(ll => (l._1, ll, getAllFieldsCanBeDried(ll))))
      .filter(!_._3.isEmpty)
      .toList
      .sortBy(t=> math.min(t._1, t._3.size)).reverse
    // 1. leere ausfiltern
    // 2. sortieren

    val cmds = new ArrayBuffer[String]()
    if (!moves.isEmpty) {
      lastPositions.clear()

      val currentMove = moves(0)
      val goal = currentMove._2

      cmds ++= moveTo(currentField, goal)
      if (goal.state == FieldState.flooded) {
        cmds += Command.DRY_CURRENT
      }
      cmds ++= dryNeighbours(Some(goal))
    } else {
      val notNagelZiele = (
            board.getFields(botRowPos, botColumnPos, FieldState.land, 3)
         ++ board.getFields(botRowPos, botColumnPos, FieldState.land, 2)
         ++ board.getFields(botRowPos, botColumnPos, FieldState.land, 1)
      )

      val filtered = notNagelZiele.filter{f=> !isEntgegengesetzt((f.row, f.col), List((botRowPos,botColumnPos)) ++ lastPositions.toList)}

      if (filtered.size > 0) {
        cmds ++= moveTo(currentField, filtered(0))
      }
    }

    lastPositions += ((botRowPos, botColumnPos))
    cmds.toList
  }

  private def getDir(p1: (Int,Int), p2: (Int,Int)) = {
    if (p1._1 < p2._1 && p1._2 < p1._2)
      -1
    else if (p1._1 > p2._1 && p1._2 < p1._2)
      2
    else if (p1._1 > p2._1 && p1._2 > p1._2)
      1
    else
      -2
  }

  private def isEntgegengesetzt(goal: (Int, Int), checkWith: List[(Int, Int)]): Boolean = {
    if (checkWith.isEmpty)
      return false
    if (checkWith.size < 2)
      return false

    val dir = getDir(goal, checkWith(0))

    dir == (-1 * getDir(checkWith(0), checkWith(1)))
  }

  private def getAllFieldsCanBeDried(field: Field): List[Field] = {
    List[Option[Field]](
      Some(field),
      board.get(field.row-1, field.col  ),
      board.get(field.row  , field.col+1),
      board.get(field.row+1, field.col  ),
      board.get(field.row  , field.col-1)
    )
      .filter(_ != None)
      .filter(_.get.state == FieldState.flooded)
      .map(_.get)
      .toList
  }

  private def getFloodedNeighbourCount(field: Field) = {
    List[Option[Field]](
      Some(field),
      board.get(field.row-1, field.col  ),
      board.get(field.row  , field.col+1),
      board.get(field.row+1, field.col  ),
      board.get(field.row  , field.col-1)
    )
      .filter(_ != None)
      .filter(_.get.state == FieldState.flooded)
      .size
  }
}
