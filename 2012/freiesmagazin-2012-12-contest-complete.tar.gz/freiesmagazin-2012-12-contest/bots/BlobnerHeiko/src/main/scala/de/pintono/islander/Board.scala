/*
 * A bot coded to win the 6. freiesMagazin-Programmierwettbewerb.
 *
 * Copyright (C) 2013  Heiko Blobner
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.pintono.islander

import FieldState._

/**
 * Created by me.
 * User: Heiko Blobner
 * Mail: heiko.blobner@gmx.de
 *
 * Date: 02.01.13
 * Time: 20:23
 */
class Board(
  columns: Int,
  rows: Int,
  boardSetup: List[String]
  ) {
  // fields
  private var rowCounter = 0
  private var colCounter = 0
  private val board = boardSetup.map{row =>
    rowCounter += 1
    colCounter = 0
    row.map {char =>
      colCounter += 1
      Field(char, row = rowCounter, col = colCounter)
    }
  }

  // ctor
  require(board.size == rows, "%d rows defined, but boardsetup contains only %d rows".format(rows, boardSetup.size))
  require(
    board.filter(_.size != columns).size == 0,
    "%d cols defined, but boardsetup contains %d rows with wrong col count".format(columns, board.filter(_.size != columns).size))

  /**
   * Get cell at coord.
   *
   * @param row cell row
   * @param column cell column
   * @return cell at row x column
   */
  def get(
    row: Int,
    column: Int
    ) = if (row > 0 && row <= board.size && column > 0 && column <= board(0).size )
      Some(board(row-1)(column-1))
    else
      None

  /**
   * Set new state on given coord.
   *
   * @param row cell row
   * @param column cell column
   * @param state new cell state
   */
  def set(
    row: Int,
    column: Int,
    state: FieldState
    ) {
    get(row, column) match {
      case Some(x) => x.state = state
      case None => // ignore
    }
  }

  /**
   * Return all fields matching the passed conditions.
   *
   * @param row base field to start from
   * @param col base field to start from
   * @param withState matching fields must have this state
   * @param andMoves fields must be reachable within .. moves
   * @return list of fields
   */
  def getFields(
    row: Int,
    col: Int,
    withState: FieldState,
    andMoves: Int
    ): List[Field] = {
    val r1 = row to (row-andMoves) by -1
    val c1 = col-andMoves to col
    val l1 = r1.zip(c1)

    val r2 = row-andMoves+1 to row
    val c2 = col+1 to col+andMoves
    val l2 = r2.zip(c2)

    val r3 = row+1 to row+andMoves
    val c3 = col+andMoves-1 to col by -1
    val l3 = r3.zip(c3)

    val r4 = row+andMoves-1 to row+1 by -1
    val c4 = col-1 to col-andMoves by -1
    val l4 = r4.zip(c4)

    // 1. get fields with calc coords
    // 2. filter out None fields (fields with illegal coords)
    // 3. filter out fields not matching withState
    // 4. map to List[Field]
    (l1 ++ l2 ++ l3 ++ l4)
      .map(t => get(t._1, t._2))
      .filter(_ != None)
      .filter(_.get.state == withState)
      .filter(f => isReachable(get(row, col), f, andMoves))
      .map(_.get).toList
  }

  /**
   * Check if the to field is reachable with the given no of moves.
   *
   * @param fromField start of the journey
   * @param toField end of the journey
   * @param withMoves no of allowed moves
   */
  def isReachable(
    fromField: Option[Field],
    toField: Option[Field],
    withMoves: Int
    ): Boolean = {
    if (fromField == None)
      return false
    if (toField == None)
      return false

    // 1. calc all possible routes
    val rs = calcRoutes(fromField.get, toField.get, withMoves)

    // 2. rate routes
    if (rs.size == 0)
      false
    else
      !rs
        .filter(_.size-1 == withMoves)
        .isEmpty
  }

  /**
   * Calc all possible routes to the toField.
   *
   * @param fromField start of the journey
   * @param toField end of the journey
   * @param maxMoves max route length
   * @return
   */
  def calcRoutes(
    fromField: Field,
    toField: Field,
    maxMoves: Int
    ): List[List[Field]] = {
    calcRoute(List(fromField), toField, move = 0, maxMoves = maxMoves)
  }

  def calcRoute(
    bisheriges: List[Field],
    toField: Field,
    move: Int,
    maxMoves: Int
    ): List[List[Field]] = {
    val fromField = bisheriges.last

    // fertsch?
    if (fromField == toField)
      return List(bisheriges)
    if (move >= maxMoves)
      return List.empty

    // get all neighbours and make a recursive call
    val l = List(
      get(fromField.row-1, fromField.col),
      get(fromField.row, fromField.col+1),
      get(fromField.row+1, fromField.col),
      get(fromField.row, fromField.col-1)
    )
    l
      .filter(_ != None)
      .filter(f => (f.get.state == FieldState.land) || (f.get.state == FieldState.flooded))
      .filter(f => !contains(bisheriges, f.get))
      .flatMap(f => calcRoute(bisheriges ++ List(f.get), toField, move = move + 1, maxMoves = maxMoves))
  }

  def contains(
    list: List[Field],
    search: Field
    ) = list.toSet.contains(search)

  /**
   * Calc move cmds to go to the toField
   *
   * @param fromField start of the journey
   * @param toField end of the journey
   * @return list of move commands (can be more than 3)
   */
  def moveTo(
    fromField: Field,
    toField: Field,
    maxMoves: Int = 3
    ): List[String] = {
    val routes = calcRoutes(fromField, toField, maxMoves).sortBy(_.size)
    if (routes.isEmpty)
      List.empty
    else {
      val path = routes.head

      moveToCommand(List.empty, current = path.head, rest = path.drop(1))
    }
  }

  def moveToCommand(
    cmds: List[String],
    current: Field,
    rest: List[Field]
    ): List[String] = {
    if (rest.isEmpty)
      return cmds

    val next = rest.head

    val my: String = if (current.row == next.row) {
      if (current.col == next.col - 1) {
        Command.GO_EAST
      } else if (current.col == next.col + 1) {
        Command.GO_WEST
      } else {
        // .. not good
        Command.GO_CURRENT
      }
    } else if (current.col == next.col) {
      if (current.row == next.row - 1) {
        Command.GO_SOUTH
      } else if (current.row == next.row + 1) {
        Command.GO_NORTH
      } else {
        // .. not good
        Command.GO_CURRENT
      }
    } else {
      // .. not good
      Command.GO_CURRENT
    }

    moveToCommand(cmds ++ List(my), next, rest.drop(1))
  }
}
