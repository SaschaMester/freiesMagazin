/*
 * A bot coded to win the 6. freiesMagazin-Programmierwettbewerb.
 *
 * Copyright (C) 2013  Heiko Blobner
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.pintono.islander

import FieldState._

/**
 * Created by me.
 * User: Heiko Blobner
 * Mail: heiko.blobner@gmx.de
 *
 * Date: 02.01.13
 * Time: 20:53
 */
case class Field(
  initState: FieldState,
  row: Int = 0,
  col: Int = 0
  ) {
  // fields
  private var _state = initState
  private var _wasFlooded = initState != FieldState.land

  def state = _state
  def state_=(v: FieldState) {
    if (_state == FieldState.watered)
      return
    if (v != FieldState.land)
      _wasFlooded = true

    _state = v
  }

  def wasFlooded = _wasFlooded
}
