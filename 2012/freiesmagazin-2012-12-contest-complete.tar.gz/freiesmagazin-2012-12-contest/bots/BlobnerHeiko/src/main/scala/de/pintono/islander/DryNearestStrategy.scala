/*
 * A bot coded to win the 6. freiesMagazin-Programmierwettbewerb.
 *
 * Copyright (C) 2013  Heiko Blobner
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.pintono.islander

import collection.mutable.ArrayBuffer
import scala.util.control.Breaks._

/**
 * Created by Me.
 * User: Heiko Blobner
 * Date: 09.01.13
 * Time: 09:26
 *
 * Strategie:
 * Alle Felder trocken die irgendwie in der Nähe sind.
 */
class DryNearestStrategy
  extends Strategy {
  /**
   * All deriving classes must define this method, so the exec method can either trim the returned list to 3 commands
   * or fill up to 3 commands
   *
   * @param botRowPos bot row position
   * @param botColumnPos bot column position
   * @return bot commands
   */
  protected def childExec(
    botRowPos: Int,
    botColumnPos: Int) = {
    board.get(botRowPos, botColumnPos) match {
      case Some(x) =>
        val cmds = new ArrayBuffer[String]()
        var currentField = x
        var goalField = x
        var isFirst = true

        breakable {
          while (cmds.size < 3) {
            val newCmds = new ArrayBuffer[String]()

            // 0. check conds
            if (!isFirst && currentField == goalField)
              break()
            isFirst = false

            // 1. neues Feld wurde betreten
            newCmds ++= moveTo(currentField, goalField)

            // 2. Feld plus Nachbarn trockenlegen
            if (x.state == FieldState.flooded) {
              newCmds += Command.DRY_CURRENT
            }

            // 3. Anzahl der neuen Commandos ok?
            //    -> wenn nicht, alternatives, trockenes Feld suchen
            if (newCmds.size + cmds.size <= 3) {
              cmds ++= newCmds
            } else {
              // 3.1 neue Zielfelder suchen
              val walkTo = (0 to 3-cmds.size).flatMap {i =>
                board.getFields(currentField.row, currentField.col, FieldState.land, andMoves = i+1)
              }
              // 3.2 gefundene Felder bewerten
              val rated = walkTo.map(f => (f -> rate(f))).sortBy(_._2)
              val paths = rated.filter(f=> board.isReachable(Some(currentField), Some(f._1), withMoves = 3-cmds.size))

              if (paths.size > 0)
                cmds ++= moveTo(currentField, paths.last._1, andMoves = 3-cmds.size)

              break()
            }

            // 4. dry neighbours
            cmds ++= dryNeighbours(Some(x))

            // 5. update board info
            updateCmdsToBoard(botRowPos, botColumnPos, cmds.slice(0, 3).toList)

            // 6. neues Ziel suchen
            //    -> mit Status 'land' bis zum Erreichen der maximalen Commandos
            //    -> mit Status 'flooded' bis zum Erreichen der maximalen Commandos-1,
            //       da dieses noch trockengelegt werden muss
            val walkTo = (0 to 3-cmds.size-1).flatMap {i =>
              board.getFields(botRowPos, botColumnPos, FieldState.land, andMoves = i+1)
            } ++ (0 to 3-cmds.size-2).flatMap {i =>
              board.getFields(botRowPos, botColumnPos, FieldState.flooded, andMoves = i+1)
            }
            val rated = walkTo.map(f => (f -> rate(f))).sortBy(_._2)

            if (rated.size == 0)
              break()

            // 7. alles fuer erneuten Durchlauf setzen
            currentField = goalField
            goalField = rated.last._1
          }
        }

        cmds.toList

      case None => List.empty
    }
  }

  def rate(field: Field): Int = {
    if (field.state == FieldState.watered)
      -1
    else
      List[Option[Field]](
        board.get(field.row-1, field.col  ),
        board.get(field.row  , field.col+1),
        board.get(field.row+1, field.col  ),
        board.get(field.row  , field.col-1)
      ).filter(_ != None)
       .foldLeft(rateField(field)*2){(v,f) =>
        v + (f match {
          case Some(x) => rateField(x)
          case None => 0
        })
      }
  }

  /**
   * Feld bewerten: Ist es sinnvoll den Bot hierher fahren zu lassen?
   *
   * Feld-Zustände ergeben folgende Wertigkeit:
   * flodded = 1
   * land    = 0
   * watered = -1
   *
   * @param field zu bewertendes Feld
   */
  def rateField(field: Field) = field.state match {
    case FieldState.flooded => 1
    case FieldState.land    => 0
    case FieldState.watered => -1
  }
}