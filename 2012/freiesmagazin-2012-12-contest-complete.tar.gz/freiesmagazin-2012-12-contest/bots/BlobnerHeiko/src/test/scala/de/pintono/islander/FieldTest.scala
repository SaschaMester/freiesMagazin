package de.pintono.islander

import org.scalatest.FlatSpec
import org.scalatest.matchers.ShouldMatchers
import org.scalatest.mock.MockitoSugar

/**
 * Created by me.
 * User: Heiko Blobner
 * Mail: heiko.blobner@gmx.de
 *
 * Date: 03.01.13
 * Time: 21:09
 */
class FieldTest
  extends FlatSpec
  with ShouldMatchers
  with MockitoSugar {
  "The ctor passed init state" should "be copied to state member" in {
    Field(FieldState.watered).state should be (FieldState.watered)
    Field(FieldState.flooded).state should be (FieldState.flooded)
    Field(FieldState.land).state should be (FieldState.land)
  }

  it should "set wasFlooded to false on init state land" in {
    Field(FieldState.land).wasFlooded should be (false)
  }

  it should "set wasFlooded to true on init state watered" in {
    Field(FieldState.watered).wasFlooded should be (true)
  }

  it should "set wasFlooded to true on init state flooded" in {
    Field(FieldState.flooded).wasFlooded should be (true)
  }

  "The setter 'state'" should "set the class member" in {
    val f = Field(FieldState.land)

    f.state = FieldState.flooded
    f.state should be (FieldState.flooded)
  }

  it should "set the a watered field to land again" in {
    val f = Field(FieldState.watered)

    f.state = FieldState.land
    f.state should be (FieldState.watered)
  }

  it should "set the a watered field to flooded again" in {
    val f = Field(FieldState.watered)

    f.state = FieldState.flooded
    f.state should be (FieldState.watered)
  }

  "The method 'wasFlooded'" should "return false if state was never set to floodded/watered" in {
    Field(FieldState.land).wasFlooded should be (false)
  }

  it should "return true if state was set to floodded" in {
    val f = Field(FieldState.land)

    f.state = FieldState.flooded
    f.wasFlooded should be (true)
  }

  it should "return true if state was set to floodded and then to land again" in {
    val f = Field(FieldState.land)

    f.state = FieldState.flooded
    f.state = FieldState.land
    f.wasFlooded should be (true)
  }

  it should "return true if state was set to watered" in {
    val f = Field(FieldState.land)

    f.state = FieldState.watered
    f.wasFlooded should be (true)
  }
}
