package de.pintono.islander

import org.scalatest.FlatSpec
import org.scalatest.matchers.ShouldMatchers
import org.scalatest.mock.MockitoSugar

/**
 * Created by me.
 * User: Heiko Blobner
 * Mail: heiko.blobner@gmx.de
 *
 * Date: 02.01.13
 * Time: 21:04
 */
class BoardTest
  extends FlatSpec
  with ShouldMatchers
  with MockitoSugar {
  "The ctor" should "throw an IllegalArgumentException if not enough rows in boardSetup" in {
    evaluating {
      new Board(
        columns = 2,
        rows = 2,
        boardSetup = List(
          "..")
        )
    } should produce[IllegalArgumentException]
  }

  it should "throw an IllegalArgumentException if not enough columns in boardSetup" in {
    evaluating {
      new Board(
        columns = 2,
        rows = 2,
        boardSetup = List(
          ".",
          "..")
      )
    } should produce[IllegalArgumentException]
  }

  "The method 'get'" should "return the correct cell state" in {
    val b = new Board(
      columns = 3,
      rows = 2,
      boardSetup = List(
        ".o#",
        "#.o")
    )

    b.get(1, 1).get.state should be (FieldState.watered)
    b.get(1, 2).get.state should be (FieldState.flooded)
    b.get(1, 3).get.state should be (FieldState.land)

    b.get(2, 1).get.state should be (FieldState.land)
    b.get(2, 2).get.state should be (FieldState.watered)
    b.get(2, 3).get.state should be (FieldState.flooded)
  }

  it should "return None on incorrect row and col" in {
    val b = new Board(
      columns = 3,
      rows = 2,
      boardSetup = List(
        ".o#",
        "#.o")
    )

    b.get(0, 1) should be (None)
    b.get(1, 0) should be (None)
    b.get(0, 0) should be (None)

    b.get(3, 1) should be (None)
    b.get(2, 4) should be (None)
    b.get(3, 4) should be (None)
  }

  "The method 'set'" should "set the correct cell state" in {
    val b = new Board(
      columns = 3,
      rows = 2,
      boardSetup = List(
        ".o#",
        "#.o")
    )

    b.set(1, 1, FieldState.flooded)
    b.get(1, 1).get.state should be (FieldState.watered)
    b.set(1, 2, FieldState.watered)
    b.get(1, 2).get.state should be (FieldState.watered)
    b.set(1, 3, FieldState.flooded)
    b.get(1, 3).get.state should be (FieldState.flooded)

    b.set(2, 1, FieldState.flooded)
    b.get(2, 1).get.state should be (FieldState.flooded)
    b.set(2, 2, FieldState.flooded)
    b.get(2, 2).get.state should be (FieldState.watered)
    b.set(2, 3, FieldState.land)
    b.get(2, 3).get.state should be (FieldState.land)
  }

  "The method 'getFields(.)'" should "return all fields reachable with 1 move and state land" in {
    val b = new Board(
      columns = 7,
      rows = 7,
      boardSetup = List(
        ".......",
        ".......",
        ".......",
        ".##.##.",
        "..o#...",
        "...##..",
        ".......")
    )

    val r = b.getFields(row = 5, col = 4, withState = FieldState.land, andMoves = 1)
    r.size should be (1)
    r.contains(b.get(6, 4).get) should  be (true)
  }

  it should "return all fields reachable with 1 move and state flooded" in {
    val b = new Board(
      columns = 7,
      rows = 7,
      boardSetup = List(
        ".......",
        ".......",
        ".......",
        ".##.##.",
        "..o#...",
        "...##..",
        ".......")
    )

    val r = b.getFields(row = 5, col = 4, withState = FieldState.flooded, andMoves = 1)
    r.size should be (1)
    r.contains(b.get(5, 3).get) should  be (true)
  }

  it should "return all fields reachable with 1 move and state watered" in {
    val b = new Board(
      columns = 7,
      rows = 7,
      boardSetup = List(
        ".......",
        ".......",
        ".......",
        ".##.##.",
        "..o#...",
        "...##..",
        ".......")
    )

    val r = b.getFields(row = 5, col = 4, withState = FieldState.watered, andMoves = 1)
    r.size should be (0)
  }

  it should "return all fields reachable with 2 move and state land" in {
    val b = new Board(
      columns = 7,
      rows = 7,
      boardSetup = List(
        ".......",
        ".......",
        ".......",
        ".##.##.",
        "..o#...",
        "...##..",
        ".......")
    )

    val r = b.getFields(row = 5, col = 4, withState = FieldState.land, andMoves = 2)
    r.size should be (2)
    r.contains(b.get(4, 3).get) should  be (true)
    r.contains(b.get(6, 5).get) should  be (true)
  }

  it should "return all fields within 2 move and state flooded" in {
    val b = new Board(
      columns = 7,
      rows = 7,
      boardSetup = List(
        ".......",
        ".......",
        ".......",
        ".##.##.",
        "..o#...",
        "...##..",
        ".......")
    )

    val r = b.getFields(row = 5, col = 4, withState = FieldState.flooded, andMoves = 2)
    r.size should be (0)
  }

  it should "return all fields within 2 move and state watered" in {
    val b = new Board(
      columns = 7,
      rows = 7,
      boardSetup = List(
        ".......",
        ".......",
        ".......",
        ".##.##.",
        "..o#...",
        "...##..",
        ".......")
    )

    val r = b.getFields(row = 5, col = 4, withState = FieldState.watered, andMoves = 2)
    r.size should be (0)
  }

  "The method 'isReachable(.)'" should "return true on direct neighbour north" in {
    val b = new Board(
      columns = 3,
      rows = 3,
      boardSetup = List(
        ".#.",
        "###",
        ".#.")
    )

    b.isReachable(b.get(2, 2), b.get(1, 2), withMoves = 1) should be (true)
  }

  it should "return true on direct neighbour east" in {
    val b = new Board(
      columns = 3,
      rows = 3,
      boardSetup = List(
        ".#.",
        "###",
        ".#.")
    )

    b.isReachable(b.get(2, 2), b.get(2, 3), withMoves = 1) should be (true)
  }

  it should "return true on direct neighbour south" in {
    val b = new Board(
      columns = 3,
      rows = 3,
      boardSetup = List(
        ".#.",
        "###",
        ".#.")
    )

    b.isReachable(b.get(2, 2), b.get(3, 2), withMoves = 1) should be (true)
  }

  it should "return true on direct neighbour west" in {
    val b = new Board(
      columns = 3,
      rows = 3,
      boardSetup = List(
        ".#.",
        "###",
        ".#.")
    )

    b.isReachable(b.get(2, 2), b.get(2, 1), withMoves = 1) should be (true)
  }

  it should "return false on north" in {
    val b = new Board(
      columns = 3,
      rows = 3,
      boardSetup = List(
        "...",
        ".#.",
        "...")
    )

    b.isReachable(b.get(2, 2), b.get(1, 2), withMoves = 1) should be (false)
  }

  it should "return false on east" in {
    val b = new Board(
      columns = 3,
      rows = 3,
      boardSetup = List(
        "...",
        ".#.",
        "...")
    )

    b.isReachable(b.get(2, 2), b.get(2, 3), withMoves = 1) should be (false)
  }

  it should "return false on south" in {
    val b = new Board(
      columns = 3,
      rows = 3,
      boardSetup = List(
        "...",
        ".#.",
        "...")
    )

    b.isReachable(b.get(2, 2), b.get(3, 2), withMoves = 1) should be (false)
  }

  it should "return false on west" in {
    val b = new Board(
      columns = 3,
      rows = 3,
      boardSetup = List(
        "...",
        ".#.",
        "...")
    )

    b.isReachable(b.get(2, 2), b.get(2, 1), withMoves = 1) should be (false)
  }

  "The method 'moveTo(.)'" should "1 cmd on neighbour north" in {
    val b = makeBoard(List(
      "#####",
      "#####",
      "#####",
      "#####",
      "#####")
    )

    val c = b.moveTo(b.get(3,3).get, b.get(2,3).get)
    c.size should be (1)
    c(0) should be (Command.GO_NORTH)
  }

  private def makeBoard(boardDef: List[String]) = {
    new Board(
      columns = boardDef(0).length,
      rows = boardDef.size,
      boardSetup = boardDef
    )
  }
}
