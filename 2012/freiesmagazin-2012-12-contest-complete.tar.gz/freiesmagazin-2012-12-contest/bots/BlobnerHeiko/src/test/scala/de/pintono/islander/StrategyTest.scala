package de.pintono.islander

import org.scalatest.FlatSpec
import org.scalatest.matchers.ShouldMatchers
import org.scalatest.mock.MockitoSugar

/**
 * Created by me.
 * User: Heiko Blobner
 * Mail: heiko.blobner@gmx.de
 *
 * Date: 05.01.13
 * Time: 20:34
 */
class StrategyTest
  extends FlatSpec
  with ShouldMatchers
  with MockitoSugar {
  "The method 'dryNeighbours'" should "dry one flooded neighbour (north)" in {
    val b = makeBoard(List(
      ".o.",
      "###",
      ".#."
    ))
    val c = new MockStrategy(b).dryNeighbours(b.get(2, 2))

    c.size should be (1)
    c(0) should be (Command.DRY_NORTH)
  }

  it should "dry one flooded neighbour (east)" in {
    val b = makeBoard(List(
      ".#.",
      "##o",
      ".#."
    ))
    val c = new MockStrategy(b).dryNeighbours(b.get(2, 2))

    c.size should be (1)
    c(0) should be (Command.DRY_EAST)
  }

  it should "dry one flooded neighbour (south)" in {
    val b = makeBoard(List(
      ".#.",
      "###",
      ".o."
    ))
    val c = new MockStrategy(b).dryNeighbours(b.get(2, 2))

    c.size should be (1)
    c(0) should be (Command.DRY_SOUTH)
  }

  it should "dry one flooded neighbour (west)" in {
    val b = makeBoard(List(
      ".#.",
      "o##",
      ".#."
    ))
    val c = new MockStrategy(b).dryNeighbours(b.get(2, 2))

    c.size should be (1)
    c(0) should be (Command.DRY_WEST)
  }

  it should "dry two flooded neighbours (ne)" in {
    val b = makeBoard(List(
      ".o.",
      "##o",
      ".#."
    ))
    val c = new MockStrategy(b).dryNeighbours(b.get(2, 2))

    c.size should be (2)
    c(0) should be (Command.DRY_NORTH)
    c(1) should be (Command.DRY_EAST)
  }

  it should "dry two flooded neighbours (ns)" in {
    val b = makeBoard(List(
      ".o.",
      "###",
      ".o."
    ))
    val c = new MockStrategy(b).dryNeighbours(b.get(2, 2))

    c.size should be (2)
    c(0) should be (Command.DRY_NORTH)
    c(1) should be (Command.DRY_SOUTH)
  }

  it should "dry two flooded neighbours (nw)" in {
    val b = makeBoard(List(
      ".o.",
      "o##",
      ".#."
    ))
    val c = new MockStrategy(b).dryNeighbours(b.get(2, 2))

    c.size should be (2)
    c(0) should be (Command.DRY_WEST)
    c(1) should be (Command.DRY_NORTH)
  }

  it should "dry three flooded neighbours (nes) (game-dbg)" in {
    val b = makeBoard(List(
      ".o.",
      "##o",
      ".o."
    ))
    val c = new MockStrategy(b).dryNeighbours(b.get(2, 2))

    c.size should be (3)
    c(0) should be (Command.DRY_NORTH)
    c(1) should be (Command.DRY_EAST)
    c(2) should be (Command.DRY_SOUTH)
  }

  private class MockStrategy(b: Board) extends Strategy {
    board = b

    /**
     * All deriving classes must define this method, so the exec method can either trim the returned list to 3 commands
     * or fill up to 3 commands
     *
     * @param botRowPos bot row position
     * @param botColumnPos bot column position
     * @return bot commands
     */
    protected def childExec(botRowPos: Int, botColumnPos: Int) = List.empty
  }
  private def makeBoard(boardDef: List[String]) = {
    new Board(
      columns = boardDef(0).length,
      rows = boardDef.size,
      boardSetup = boardDef
    )
  }
}
