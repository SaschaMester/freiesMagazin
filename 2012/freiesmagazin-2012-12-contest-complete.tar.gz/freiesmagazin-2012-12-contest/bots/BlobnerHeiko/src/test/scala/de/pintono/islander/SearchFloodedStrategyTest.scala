package de.pintono.islander

import org.scalatest.FlatSpec
import org.scalatest.matchers.ShouldMatchers
import org.scalatest.mock.MockitoSugar

/**
 * Created by Me.
 * User: Heiko Blobner
 * Date: 08.01.13
 * Time: 13:58
 */
class SearchFloodedStrategyTest
  extends FlatSpec
  with ShouldMatchers
  with MockitoSugar {
  "The method 'rate'" should "work correct :)" in {
    val b = makeBoard(List(
      ".#o"
    ))
    val s = new SearchFloodedStrategy
    s.board = b

    s.rate(b.get(1,1).get) should be ( 0)
    s.rate(b.get(1,2).get) should be ( 2)
    s.rate(b.get(1,3).get) should be (200)
  }

  "The method 'rateUmfeld'" should "work correct :)" in {
    val b = makeBoard(List(
      ".#.",
      "##o",
      "oo."
    ))
    val s = new SearchFloodedStrategy
    s.board = b

    s.rateUmfeld(b.get(1,1).get) should be ( -1)
    s.rateUmfeld(b.get(1,2).get) should be (  4)
    s.rateUmfeld(b.get(1,3).get) should be ( -1)
    s.rateUmfeld(b.get(2,1).get) should be (204)
    s.rateUmfeld(b.get(2,2).get) should be (406)
    s.rateUmfeld(b.get(2,3).get) should be (202)
    s.rateUmfeld(b.get(3,1).get) should be (402)
    s.rateUmfeld(b.get(3,2).get) should be (402)
    s.rateUmfeld(b.get(3,3).get) should be ( -1)
  }

  "The method 'rateUmfeldAndDistance'" should "work correct :)" in {
    val b = makeBoard(List(
      ".#.",
      "##o",
      "oo.",
      "ooo"
    ))
    val s = new SearchFloodedStrategy
    s.board = b

    s.rateUmfeldAndDistance(b.get(1,2).get, b.get(1,1).get) should be (      -1)
    s.rateUmfeldAndDistance(b.get(1,2).get, b.get(1,2).get) should be (  4 * 90)
    s.rateUmfeldAndDistance(b.get(1,2).get, b.get(1,3).get) should be (      -1)
    s.rateUmfeldAndDistance(b.get(1,2).get, b.get(2,1).get) should be (204 * 15)
    s.rateUmfeldAndDistance(b.get(1,2).get, b.get(2,2).get) should be (406 * 70)
    s.rateUmfeldAndDistance(b.get(1,2).get, b.get(2,3).get) should be (202 * 15)
    s.rateUmfeldAndDistance(b.get(1,2).get, b.get(3,1).get) should be (602 *  1)
    s.rateUmfeldAndDistance(b.get(1,2).get, b.get(3,2).get) should be (602 * 15)
    s.rateUmfeldAndDistance(b.get(1,2).get, b.get(3,3).get) should be (      -1)

    s.rateUmfeldAndDistance(b.get(1,2).get, b.get(4,1).get) should be (600 *  1)
    s.rateUmfeldAndDistance(b.get(1,2).get, b.get(4,2).get) should be (800 *  1)
    s.rateUmfeldAndDistance(b.get(1,2).get, b.get(4,3).get) should be (400 *  1)
  }

  private def makeBoard(boardDef: List[String]) = {
    new Board(
      columns = boardDef(0).length,
      rows = boardDef.size,
      boardSetup = boardDef
    )
  }
}
