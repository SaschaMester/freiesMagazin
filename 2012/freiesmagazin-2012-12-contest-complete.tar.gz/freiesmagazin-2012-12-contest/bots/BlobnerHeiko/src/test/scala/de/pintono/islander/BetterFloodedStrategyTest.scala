package de.pintono.islander

import org.scalatest.FlatSpec
import org.scalatest.matchers.ShouldMatchers
import org.scalatest.mock.MockitoSugar

/**
 * Created by me.
 * User: Heiko Blobner
 * Mail: heiko.blobner@gmx.de
 *
 * Date: 21.01.13
 * Time: 14:08
 */
class BetterFloodedStrategyTest
  extends FlatSpec
  with ShouldMatchers
  with MockitoSugar {
  "The method 'rate'" should "work correct :)" in {
    val b = makeBoard(List(
      "o...oo#",
      "ooo...#",
      "#oo#ooo",
      "#####oo",
      "ooo#ooo",
      "o....oo",
      "oo..ooo"
    ))
    val s = new BetterFloodedStrategy
    s.board = b

    val res = s.exec(4, 4)

    res(0) should be(Command.GO_EAST)
    res(1) should be(Command.DRY_NORTH)
    res(2) should be(Command.DRY_EAST)
  }

  private def makeBoard(boardDef: List[String]) = {
    new Board(
      columns = boardDef(0).length,
      rows = boardDef.size,
      boardSetup = boardDef
    )
  }
}
