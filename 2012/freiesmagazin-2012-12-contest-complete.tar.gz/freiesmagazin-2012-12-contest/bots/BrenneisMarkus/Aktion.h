/*
Bot für den sechsten Programmierwettbewerb von freiesMagazin Copyright (C) 2013 Markus Brenneis
This program comes with ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute it under certain conditions.
See main.cpp for details. */

#ifndef _Aktion_
#define _Aktion_

class Aktion {
	public:
		const short dX, dY;
		const std::string aktion;
		
		Aktion(short dX, short dY, std::string aktion) : dX(dX), dY(dY), aktion(aktion) {}
};

#endif // _Aktion_
