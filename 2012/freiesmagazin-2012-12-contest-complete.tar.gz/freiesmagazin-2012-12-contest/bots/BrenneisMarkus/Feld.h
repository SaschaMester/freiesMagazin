/*
Bot für den sechsten Programmierwettbewerb von freiesMagazin Copyright (C) 2013 Markus Brenneis
This program comes with ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute it under certain conditions.
See main.cpp for details. */

#ifndef _Feld_
#define _Feld_

#include <QList>

class Feld {
	private:
		//! 0: trocken, 1: geflutet, 2: untergegangen;
		short status_;
		bool schonmalGeflutet_;
		
	public:
		//! erstellt eine neue Insel
		Feld(char status);
		void fluten();
		void trockenlegen();
		short gibStatus() const;
		bool warSchonmalGeflutet() const;
};

#endif // _Feld_
