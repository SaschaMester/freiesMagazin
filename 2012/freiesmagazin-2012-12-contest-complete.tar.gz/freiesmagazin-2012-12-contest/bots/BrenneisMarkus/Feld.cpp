/*
Bot für den sechsten Programmierwettbewerb von freiesMagazin Copyright (C) 2013 Markus Brenneis
This program comes with ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute it under certain conditions.
See main.cpp for details. */

#include "Feld.h"

#include <QDebug>

Feld::Feld(char status) {
	if(status=='#') {
		status_=0;
	} else if(status=='o') {
		status_=1;
	} else if(status=='.') {
		status_=2;
	} else {
		qDebug() << "(DD) WARNUNG: Feldstatus" << status << "unbekannt.";
	}
// 	qDebug() << status_;
	schonmalGeflutet_=false;
}

void Feld::fluten() {
	status_++;
	schonmalGeflutet_=true;
	if(status_>2) qDebug() << "(DD) WARNUNG: Feldstatus" << status_ << "größer 2.";
}

void Feld::trockenlegen() {
	if(status_!=1) qDebug() << "(DD) WARNUNG: Feldstatus" << status_ << "ist nicht 1.";
	status_=0;
}

short Feld::gibStatus() const {
	return status_;
}

bool Feld::warSchonmalGeflutet() const {
	return schonmalGeflutet_;
}
