#!/bin/sh

# Achtung: Das Skript funktioniert nur, wenn es aus dem Hauptverzeichnis des 
# Wettbewerbs aufgerufen wurde, da der Pfad zum Bot fest angegeben ist.

cd bots/StaudingerPhilipp/
java src/Main
