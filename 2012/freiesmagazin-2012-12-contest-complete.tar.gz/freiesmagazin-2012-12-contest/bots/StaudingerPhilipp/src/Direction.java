/**
    (C) Copyright 2012 Philipp Staudinger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

package src;

// represents the 5 directions
public enum Direction {
	CURRENT, NORTH, SOUTH, WEST, EAST;
	
	// return all directions
	public static Direction[] all() {
		Direction[] ret = {CURRENT, NORTH, SOUTH, WEST, EAST};
		return ret;
	}
	
	// return all directions without current
	public static Direction[] allWithoutCurrent() {
		Direction[] ret = {NORTH, SOUTH, WEST, EAST};
		return ret;
	}
	
	// returns the opposite direction of this direction
	public Direction opposite() {
		switch(this) {
			case NORTH: 	return SOUTH;
			case SOUTH:     return NORTH;
			case WEST:      return EAST;
			case EAST:      return WEST;
			default:	  	return CURRENT;
		}
	}
	
	// returns the left direction of this direction
	public Direction left() {
		switch(this) {
			case NORTH: 	return WEST;
			case SOUTH:     return EAST;
			case WEST:      return SOUTH;
			case EAST:      return NORTH;
			default:	  	return CURRENT;
		}
	}
	
	// returns the right direction of this direction
	public Direction right() {
		return left().opposite();
	}
	
	// return all other directions, opposite prefered
	public Direction[] others() {
		if(this == CURRENT) {
			return allWithoutCurrent();
		}

		Direction[] ret = new Direction[3];
		ret[0] = opposite();
		ret[1] = left();
		ret[2] = right();
		
		return ret;
	}
	
	@Override
	public String toString() {
		switch(this) {
			case CURRENT:	return "CURRENT";
			case NORTH: 	return "NORTH";
			case SOUTH:     return "SOUTH";
			case WEST:      return "WEST";
			case EAST:      return "EAST";
			default:	  	return "";
		}
	}
}
