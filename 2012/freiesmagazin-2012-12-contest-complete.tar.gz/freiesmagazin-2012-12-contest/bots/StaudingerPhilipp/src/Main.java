/**
    (C) Copyright 2012 Philipp Staudinger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

package src;

import java.io.*;
import java.util.regex.*;

public class Main {
	private Gameboard board;
	private Strategy strategy;
	int round, flood;
	
	public static void main(String[] args) {
		Main main = new Main();
		
		try {
			main.start();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void start() throws IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		String in = input.readLine();
		
		while(!in.equals("END")) {	// until END
			
			// GAMEBORDSTART -> initialize game 
			if(in.startsWith("GAMEBOARDSTART")) {
				int[] dim = parseInt(in, 2);
				in = input.readLine();
				for(int i=0; i < dim[1]-1; i++) {
					in += input.readLine();
				}
				board = new Gameboard(dim[0], dim[1], in);
				flood = 0;
				strategy = new Strategy(board);
				input.readLine();
				
			// ROUND -> update game and tell strategy to move
			} else if(in.startsWith("ROUND") || in.startsWith("R")) {
				int[] rnd = parseInt(in, 3);
				round = rnd[0];
				board.setPos(new Position(rnd[1], rnd[2]));
				strategy.act(flood);
				
			// INCRFLOOD
			} else if(in.startsWith("INCRFLOOD")) {
				flood += parseInt(in, 1)[0];
				if(parseInt(in, 1)[0] > 0) {
					board.refreshStack();
				}
				
			// FLOOD
			} else if(in.startsWith("FLOOD")) {
				int[] pos = parseInt(in, 2);
				board.flood(new Position(pos[0], pos[1]));
			}
			
			in = input.readLine();
		}
		
		input.close();
	}
	
	// returns nmb integers out of str
	private int[] parseInt(String str, int nmb) {
		Matcher m = Pattern.compile("[0-9]+").matcher(str);
		int out[] = new int[nmb];
		int i=0;

		while(m.find() && i < nmb) {
			out[i] = Integer.parseInt(str.substring(m.start(), m.end()));
			i++;
		}
		
		return out;
	}
}
