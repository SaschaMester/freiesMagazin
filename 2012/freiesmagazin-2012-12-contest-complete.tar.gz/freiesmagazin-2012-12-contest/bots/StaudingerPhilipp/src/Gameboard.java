/**
    (C) Copyright 2012 Philipp Staudinger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

package src;

// represents the board of the game.
// holds important methods for my strategy
public class Gameboard {
	private int width, height;					// dimensions of the board
	private Field[][] board;					// states of the fields
	private Directions[][] dirsFrom;			// directions to go for shortest way to pos
	private int[][] stepsTo;					// steps needed to go to pos, -1 if impossible
	private boolean[][] onStack;				// if this position is on the stack
	private boolean[][] passed;					// array needed for some methods
	private Position pos = new Position(0,0);	// position of the player

	public Gameboard(int width, int height, String str) {
		
		this.width = width;
		this.height = height;
		board = new Field[height][width];
		dirsFrom = new Directions[height][width];
		stepsTo = new int[height][width];
		onStack = new boolean[height][width];

		int s=0;
		for(Position pos: getAllPositions()) {
			switch(str.charAt(s)) {
				case '.': 	setField(pos, Field.LOST);
						  	break;
				case 'o': 	setField(pos, Field.FLOODED);
						  	break;
				case '#': 	setField(pos, Field.DRY);
				  		  	break;
			}
			s++;
		}
		
		refreshStack();
	}
	
	// returns all Positions
	public Position[] getAllPositions() {
		Position[] retArr = new Position[getSize()];
		for(int i=0; i < height; i++) {
			for(int j=0; j < width; j++) {
				retArr[i*width+j] = new Position(j+1, i+1);
			}
		}

		return retArr;
	}
	
	// flood field on given position
	public void flood(Position pos) {
		if(getField(pos) == Field.FLOODED) {
			setField(pos, Field.LOST);
		} else if(getField(pos) == Field.DRY) {
			setField(pos, Field.FLOODED);
		}
		
		setOnStack(pos, false);
		if(getNumStack() == 0) {
			refreshStack();
		}
	}
	
	// goes in direction
	public void go(Direction dir) {
		pos = pos.neighbor(dir);
	}
	
	// dry field by given direction
	public void dry(Direction dir) {
		dry(pos.neighbor(dir));
	}
	
	// dry field by given position
	public void dry(Position pos) {
		if(getField(pos) == Field.FLOODED) {
			setField(pos, Field.DRY);
		}
	}
	
	// returns a direction from pos which is flooded. current prefered. null if no such direction
	public Direction floodedAround(Position pos) {
		for(Direction dir: Direction.all()) {
			if(isValid(pos.neighbor(dir)) && getField(pos.neighbor(dir)) == Field.FLOODED) {
				return dir;
			}
		}
		return null;
	}
	
	// returns the number of fields which are flooded around pos
	public int numFloodedAround(Position pos) {
		int ret = 0;
		
		for(Direction dir: Direction.all()) {
			if(isValid(pos.neighbor(dir)) && getField(pos.neighbor(dir)) == Field.FLOODED) {
				ret++;
			}
		}
		return ret;
	}
	
	// puts all fields on the stack which are not lost
	public void refreshStack() {
		for(Position pos: getAllPositions()) {
			setOnStack(pos, false);
			if(getField(pos) != Field.LOST) {
				setOnStack(pos, true);
			}
		}
	}
	
	// returns the directions to go to given position !! call calcDirectionsSteps() first !!
	public Directions getDirections(Position pos) {
		passed = new boolean[height][width];
		return getDirectionsRec(pos);
	}
	
	// recursive method to find the directions to go
	private Directions getDirectionsRec(Position pos) {
		// return when position already passed
		if(getPassed(pos)) {
			return new Directions();
		}
		
		// return when 1 step before current position
		if(getSteps(pos) <= 1) {
			return getDirs(pos).opposite();
		}

		// set that position has been passed
		setPassed(pos, true);
		
		// recursively find the directions
		Directions ret = new Directions();
		for(Direction dir: Direction.all()) {
			if(getDirs(pos).contains(dir)) {
				ret.add(getDirectionsRec(pos.neighbor(dir)));
			}
		}
		
		return ret;
	}
	
	// calculates the dirsFrom and stepsTo arrays by using a recursive method
	public void calcDirectionsSteps() {
		// initialize dirsFrom and stepsTo -> unreachable positions = -1
		for(Position pos: getAllPositions()) {
			setSteps(pos, -1);
			setDirs(pos, new Directions());
		}
		
		calcDirectionsStepsRec(Direction.CURRENT, pos, 0);
	}
	
	// recursive method to calculate dirsFrom and stepsTo
	private void calcDirectionsStepsRec(Direction last, Position pos, int steps) {
		// returns if position is invalid
		if(!isValid(pos) || getField(pos) == Field.LOST) {
			return;
		}
		
		// returns if position has already been reached in shorter distance
		if(steps > stepsTo[pos.y-1][pos.x-1] && stepsTo[pos.y-1][pos.x-1] >= 0) {
			return;
		}

		// position has already been reached in equal distance -> add direction and return
		if(steps == stepsTo[pos.y-1][pos.x-1]) {
			dirsFrom[pos.y-1][pos.x-1].add(last.opposite());
			return;
		}
		
		// actualize stepsTo an dirsFrom
		stepsTo[pos.y-1][pos.x-1] = steps;
		dirsFrom[pos.y-1][pos.x-1].clear();
		dirsFrom[pos.y-1][pos.x-1].add(last.opposite());
	
		// go threw directions
		for(Direction dir: last.opposite().others()) {
			calcDirectionsStepsRec(dir, pos.neighbor(dir), steps+1);
		}
		
		return;
	}
	
	// returns true if pos is valid
	public Boolean isValid(Position pos) {
		if(pos.x < 1 || pos.x > width || pos.y < 1 || pos.y > height) {
			return false;
		}
		
		return true;
	}
	
	// returns the number of positions on the stack
	public int getNumStack() {
		int num = 0;
		
		for(Position pos: getAllPositions()) {
			if(getOnStack(pos) && getField(pos) != Field.LOST) {
				num++;
			}
		}
		
		return num;
	}
	
	// some getters and setters
	public Field getField(Position pos) {
		return board[pos.y-1][pos.x-1];
	}
	
	public void setField(Position pos, Field f) {
		board[pos.y-1][pos.x-1] = f;
	}
	
	public Position getPos() {
		return pos;
	}
	
	public void setPos(Position pos) {
		this.pos = pos;
	}

	public boolean getOnStack(Position pos) {
		return onStack[pos.y-1][pos.x-1];
	}
	
	public void setOnStack(Position pos, boolean bool) {
		onStack[pos.y-1][pos.x-1] = bool;
	}
	
	public int getSize() {
		return width * height;
	}
	
	// returns the steps needed to go to given position !! call calcDirectionsSteps() first !!
	public int getSteps(Position pos) {
		return stepsTo[pos.y-1][pos.x-1];
	}
	
	public void setSteps(Position pos, int steps) {
		stepsTo[pos.y-1][pos.x-1] = steps;
	}
	
	// returns the directions needed to go to given position !! call calcDirectionsSteps() first !!
	public Directions getDirs(Position pos) {
		return dirsFrom[pos.y-1][pos.x-1];
	}
	
	public void setDirs(Position pos, Directions dirs) {
		dirsFrom[pos.y-1][pos.x-1] = dirs;
	}
	
	// returns the value in the array passed
	public boolean getPassed(Position pos) {
		return passed[pos.y-1][pos.x-1];
	}
	
	// sets the value in the array passed
	public void setPassed(Position pos, boolean pas) {
		passed[pos.y-1][pos.x-1] = pas;
	}
}

