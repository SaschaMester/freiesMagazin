/**
    (C) Copyright 2012 Philipp Staudinger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

package src;

public class Strategy {
	
	private Gameboard board;
	
	public Strategy(Gameboard board) {
		super();
		this.board = board;
	}

	public void act(int flood) {

		Direction tmp;
		int steps;															// steps to go to current field
		int flooded;														// number of flooded fields around current
		Directions dirs;													// the directions which leads to current
		Directions saveDirs;												// the save directions
		double rate, rateNor, rateSou, rateWes, rateEas, bestRate;			// rates for the directions
		double exp1 = 0.55+board.getSize()/1000.0;							// needed for my calculation
		double exp2 = 2.4-board.getSize()/(2000.0+flood/0.007)-flood/70.0;	// needed for my calculation
		
		// 3 actions per round
		for(int turn=1; turn<=3; turn++) {

			// dry if possible
			if(board.numFloodedAround(board.getPos()) > 0) {	
				tmp = board.floodedAround(board.getPos());
				System.out.println("DRY " + tmp.toString());
				board.dry(tmp);
				
			// no flooded position reachable -> go in best direction
			} else {
				
				// reset rates
				rateNor = 0.0; rateSou = 0.0; rateWes = 0.0; rateEas = 0.0; bestRate = -1.0;

				tmp = Direction.CURRENT;
				saveDirs = new Directions();
				
				board.calcDirectionsSteps();
				
				// for all positions
				for(Position pos: board.getAllPositions()) {
					
					steps = board.getSteps(pos);

					// if position is reachable
					if(steps >= 0) {
						
						dirs = board.getDirections(pos);
						flooded =  board.numFloodedAround(pos);
						
						// calculate rate
						rate = Math.pow(Math.pow(flooded, exp1) / steps, exp2);
						
						// add rate to the directions
						if(dirs.contains(Direction.NORTH))
							rateNor += rate;
						if(dirs.contains(Direction.SOUTH))
							rateSou += rate;
						if(dirs.contains(Direction.WEST)) 
							rateWes += rate;
						if(dirs.contains(Direction.EAST))
							rateEas += rate;
						
						// add the save directions
						if(steps <= 4-turn && !board.getOnStack(pos)) {
							saveDirs.add(dirs);
						}
					}
				}

				// if in no risk or no direction is save -> add all directions
				if(board.getNumStack() >= flood || saveDirs.isEmpty()) {
					saveDirs.fill();
				}
				
				// find save direction with highest rating
				if(saveDirs.contains(Direction.CURRENT)) {
					bestRate = 0.0;
					tmp = Direction.CURRENT;
				}
				if(rateNor > bestRate && saveDirs.contains(Direction.NORTH)) {
					bestRate = rateNor;
					tmp = Direction.NORTH;
				}
				if(rateSou > bestRate && saveDirs.contains(Direction.SOUTH)) {
					bestRate = rateSou;
					tmp = Direction.SOUTH;
				}
				if(rateWes > bestRate && saveDirs.contains(Direction.WEST)) {
					bestRate = rateWes;
					tmp = Direction.WEST;
				}
				if(rateEas > bestRate && saveDirs.contains(Direction.EAST)) {
					bestRate = rateEas;
					tmp = Direction.EAST;
				}
				
				// go in that direction
				System.out.println("GO " + tmp.toString());
				board.go(tmp);
			}
		}
	}
}