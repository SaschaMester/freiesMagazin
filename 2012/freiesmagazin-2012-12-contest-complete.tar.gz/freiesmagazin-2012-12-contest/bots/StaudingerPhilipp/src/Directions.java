/**
    (C) Copyright 2012 Philipp Staudinger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

package src;

public class Directions {
	private boolean dirCur, dirNor, dirSou, dirWes, dirEas;
	
	public void add(Direction dir) {
		switch(dir) {
			case CURRENT:	dirCur = true;
							break;
			case NORTH: 	dirNor = true;
							break;
			case SOUTH:     dirSou = true;
							break;
			case WEST:      dirWes = true;
							break;
			case EAST:      dirEas = true;
							break;
		}
	}
	
	public void add(Directions dirs) {
		for(Direction dir: Direction.all()) {
			if(dirs.contains(dir)) {
				add(dir);
			}
		}
	}
	
	public void remove(Direction dir) {
		switch(dir) {
			case CURRENT:	dirCur = false;
							break;
			case NORTH: 	dirNor = false;
							break;
			case SOUTH:     dirSou = false;
							break;
			case WEST:      dirWes = false;
							break;
			case EAST:      dirEas = false;
							break;
		}
	}
	
	public void clear() {
		dirCur = false;
		dirNor = false;
		dirSou = false;
		dirWes = false;
		dirEas = false;
	}
	
	public void fill() {
		dirCur = true;
		dirNor = true;
		dirSou = true;
		dirWes = true;
		dirEas = true;
	}
	
	public boolean isEmpty() {
		return !(dirCur || dirNor || dirSou || dirWes || dirEas);
	}
	
	public Directions opposite() {
		Directions ret = new Directions();
		for(Direction dir: Direction.all()) {
			if(contains(dir)) {
				ret.add(dir.opposite());
			}
		}
		return ret;
	}
	
	public boolean contains(Direction dir) {
		switch(dir) {
			case CURRENT:	return dirCur;
			case NORTH: 	return dirNor;
			case SOUTH:     return dirSou;
			case WEST:      return dirWes;
			case EAST:      return dirEas;
		}
		return false;
	}
}
