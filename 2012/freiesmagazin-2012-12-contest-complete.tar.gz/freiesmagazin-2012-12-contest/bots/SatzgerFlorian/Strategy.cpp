/**
	(C) Copyright 2013 Dominik Wagenfuehr, Florian Satzger

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as
	published by the Free Software Foundation; either version 3 of the
	License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public
	License along with this program. If not, see
	<http://www.gnu.org/licenses/>.
*/

#include "Strategy.hh"

#include "EndMessage.hh"
#include "FloodMessage.hh"
#include "GameboardEndMessage.hh"
#include "GameboardLineMessage.hh"
#include "GameboardStartMessage.hh"
#include "IncrFloodMessage.hh"
#include "StartMessage.hh"
#include "TextMessage.hh"

#include <iostream>
#include <sstream>
#include <queue>
#include <cfloat>
#include <cmath>

// Konstruktor.
Strategy::Strategy()
  : mData(), mIsFinished(false), mGameboardStarted(false)
{ }

// Destruktor.
Strategy::~Strategy()
{ }

// Werte zuruecksetzen.
void Strategy::reset()
{
}

// Behandelt eine Start-Nachricht.
bool Strategy::operate( const StartMessage& message )
{
	mData.numRound = message.getNumRound();
	mData.position = message.getPosition();
	mData.position.setPosition(mData.position.x()-1,mData.position.y()-1);
	// Hier muss nun die Berechnung der Befehle, die an
	// den Server gesendet werden sollen, starten.
	return calcCommands();
}

// Behandelt eine Flut-Nachricht.
bool Strategy::operate( const FloodMessage& message )
{
	mData.floodedField = message.getPosition();
	unsigned int &field=mData.board[mData.floodedField.x()-1][mData.floodedField.y()-1];
	if(field==mData.dryval){
		field=mData.waterval;
	}else{
		field=0;
	}
	if(mData.floodCounter<7)
		mData.bonus[mData.floodedField.x()-1][mData.floodedField.y()-1]*=mData.bonusval;
	else{
		mData.bonus[mData.floodedField.x()-1][mData.floodedField.y()-1]=1/mData.bonusval;
	}
	mData.numFlooded++;
	unsigned int avail=0;
	for(unsigned int i=0;i<mData.bsize.x;i++)
		for(unsigned int i2=0;i2<mData.bsize.y;i2++)
			if(mData.board[i][i2])avail++;
	if(mData.numFlooded==avail){
		mData.numFlooded=0;
		for(unsigned int i=0;i<mData.bsize.x;i++)
			for(unsigned int i2=0;i2<mData.bsize.y;i2++)
				mData.bonus[i][i2]=1;
	}
	//std::cerr<<mData.numFlooded<<" ";
	return true;
}

// Behandelt eine Steigende-Flut-Nachricht.
bool Strategy::operate( const IncrFloodMessage& message )
{
	mData.floodCounter += message.getNumIncrFlood();
	if(message.getNumIncrFlood()){
		mData.numFlooded=0;
	}
	return true;
}

// Behandelt eine Ende-Nachricht.
bool Strategy::operate( const EndMessage& /* message */ )
{
	mIsFinished = true;
	return true;
}

// Behandelt eine Spielbrett-Start-Nachricht.
bool Strategy::operate( const GameboardStartMessage& message )
{

	mGameboardStarted = true;
	row=0;
	mData.floodCounter=0;
	mData.numFlooded=0;
	mData.distpenalty1=mData.distpenalty1_init;
	mData.distpenalty2=mData.distpenalty2_init;
	return mData.initBoards(message.getSize());
}

// Behandelt eine Spielbrett-Zeile-Nachricht.
bool Strategy::operate( const GameboardLineMessage&  message  )
{
	bool retValue = false;
	if ( mGameboardStarted)
	{
		if (row==mData.bsize.y){
			retValue=false;
			std::cerr<<"(EE) Spielbrett zu gross!"<<std::endl;
		}else{
			for (unsigned int i=0;i<mData.bsize.x;i++){
				switch(message.getLine()[i]){
					case '.':
						mData.board[i][row]=0;
						break;
					case 'o':
						mData.board[i][row]=mData.waterval;
						break;
					case '#':
						mData.board[i][row]=mData.dryval;
				}
			}
			row++;
			retValue = true;
		}
	}
	else
	{
		std::ostringstream out;
		out << "(EE) Strategy::operate GameboardLineMessage"
			<< std::hex << this << std::dec
			<< " Gameboard transfer has not been started yet!"
			<< std::endl;
		std::cerr << out.str();
		retValue = false;
	}

	return retValue;
}

// Behandelt eine Spielbrett-Ende-Nachricht.
bool Strategy::operate( const GameboardEndMessage& message )
{
	mGameboardStarted = false;
	return true;
}

// Behandelt eine Textnachricht.
bool Strategy::operate( const TextMessage& message  )
{
	std::ostringstream out;
	out << "(EE) " << "Strategy::operate TextMessage "
		<< std::hex << this << std::dec
		<< "'" << message.getText() << "'."
		<< " Cannot operate on text messages!"
		<< std::endl;
	std::cerr << out.str();

	return false;
}

// Fragt ab, ob Kommandos zur Verfuegung stehen.
bool Strategy::isCommandsAvailable( std::vector<std::string>& cmdList )
{
	bool isAvail = false;

	cmdList.clear();
	if ( 3 == mCommandList.size() )
	{
		// Nur, wenn exakt drei Kommandos anstehen, werden diese
		// uebermittelt.
		cmdList = mCommandList;
		isAvail = true;

		// Nach dem Kopieren sollte man die Kommandos unbedingt
		// loeschen, damit bei der naechsten Abfrage nicht aus
		// Versehen noch Kommandos anstehen.
		mCommandList.clear();
	}

	return isAvail;
}

// Gibt zurueck, ob das Spiel zu Ende sein soll.
bool Strategy::isEnd() const
{
	return mIsFinished;
}

// Berechne die drei Aktionen, die spaeter ausgegeben werden sollen.
bool Strategy::calcCommands()
{
	unsigned int verfuegbareFelder;
	Size tmp;
	Direction dir;
	mCommandList.resize(3);
	//Standardbefüllung
	mCommandList[0] = "GO CURRENT";
	mCommandList[1] = "GO CURRENT";
	mCommandList[2] = "GO CURRENT";
	for(int i=0;i<3;i++){
		for(int i2=0;i2<5;i2++){
			tmp=getPos((Direction)i2);
			if(!exists(tmp))continue;
			if(mData.board[tmp.x][tmp.y]==mData.waterval){
				mCommandList[i]= "DRY "+mData.richtung[i2];
				mData.board[tmp.x][tmp.y]=mData.dryval;
				break;
			}
		}

		if(mCommandList[i]=="GO CURRENT"){
			/*verfuegbareFelder=0;
			for(unsigned int i2=0;i2<mData.bsize.x;i2++)
				for(unsigned int i3=0;i3<mData.bsize.y;i3++)
					if(mData.board[i2][i3]>0)verfuegbareFelder++;

			//Spielabhängige Anpassung der Pfadstrafe:
			mData.distpenalty2=mData.distpenalty2_init*8*verfuegbareFelder/(mData.bsize.x*mData.bsize.y);
			if(mData.distpenalty2>mData.distpenalty2_init)mData.distpenalty2=mData.distpenalty2_init;
			if(mData.distpenalty2<1)mData.distpenalty2=1;
			*/
			dir=shortestWay(calcRating());
			mCommandList[i]="GO "+mData.richtung[dir];
			mData.position.setPosition(getPos(dir).x,getPos(dir).y);
		}
	}
	return true;
}


//Bewertet das Spielfeld
Size Strategy::calcRating(){
	/*
	timeval start, end;
	gettimeofday(&start, 0);
	*/
	double ** (&rating)=mData.rating;
	double temp[mData.bsize.x][mData.bsize.y];
	double env;

	//Strafe für Ablagestapel auf Basisboard aufmultiplizieren
	for(unsigned int x=0;x<mData.bsize.x;x++)
		for(unsigned int y=0;y<mData.bsize.y;y++){
			temp[x][y]=mData.board[x][y]*mData.bonus[x][y];
		}

	//Umgebungsrating Einfach: wert*summe(umgebungswerten)
	for(unsigned int x=0;x<mData.bsize.x;x++)
		for(unsigned int y=0;y<mData.bsize.y;y++){
			env=0;
			if(x>0) env+=temp[x-1][y];
			if(y>0) env+=temp[x][y-1];
			if(x<mData.bsize.x-1) env+=temp[x+1][y];
			if(y<mData.bsize.y-1) env+=temp[x][y+1];
			rating[x][y]=temp[x][y]*env;
		}


	for(unsigned int x=0;x<mData.bsize.x;x++)
		for(unsigned int y=0;y<mData.bsize.y;y++)
			temp[x][y]=rating[x][y];


	//Umgebungsrating Rekursionsschritt: basiswert*summe(umgebungswerten aus einfach-rating)
	for(unsigned int x=0;x<mData.bsize.x;x++){
		for(unsigned int y=0;y<mData.bsize.y;y++){
			env=0;
			if(x>0) env+=temp[x-1][y];
			if(y>0) env+=temp[x][y-1];
			if(x<mData.bsize.x-1) env+=temp[x+1][y];
			if(y<mData.bsize.y-1) env+=temp[x][y+1];
			rating[x][y]=mData.board[x][y]*env;
		}
	}


	//Entfernungsbewertung
	return calcDistance();

	//Ausgabe
	static int r=0;
	if(r++==50){
		std::cerr<<mData.position.x()<<" "<<mData.position.y()<<"\n";
		for(unsigned int y=0;y<mData.bsize.y;y++){
			for(unsigned int x=0;x<mData.bsize.x;x++){
				std::cerr<<mData.rating[x][y]<< " ";
			}
			std::cerr<<"\n";
		}
		throw 1;
	}
}

Size Strategy::calcDistance(){
	std::queue<Size> todo;
	Size tmp;
	unsigned int ** (&board)=mData.board;
	unsigned int &x=mData.bsize.x;
	unsigned int &y=mData.bsize.y;
	double max=0;
	Size maxPos={1,1};

	double dist[x][y];

	for(unsigned int i=0;i<x;i++){
		for(unsigned int i2=0;i2<y;i2++)
			dist[i][i2]=DBL_MAX;
	}

	tmp.x=mData.position.x();
	tmp.y=mData.position.y();
	todo.push(tmp);
	dist[tmp.x][tmp.y]=0.0;

	while(!todo.empty()){
		tmp=todo.front();
		todo.pop();
		if(tmp.x>0 && board[tmp.x-1][tmp.y]>0 && dist[tmp.x-1][tmp.y]>(dist[tmp.x][tmp.y]+1)){
			dist[tmp.x-1][tmp.y]=dist[tmp.x][tmp.y]+1;
			tmp.x--;
			todo.push(tmp);
			tmp.x++;
		}
		if(tmp.y>0 && board[tmp.x][tmp.y-1]>0 && dist[tmp.x][tmp.y-1]>(dist[tmp.x][tmp.y]+1)){
			dist[tmp.x][tmp.y-1]=dist[tmp.x][tmp.y]+1;
			tmp.y--;
			todo.push(tmp);
			tmp.y++;
		}
		if(tmp.x<x-1 && board[tmp.x+1][tmp.y]>0 && dist[tmp.x+1][tmp.y]>(dist[tmp.x][tmp.y]+1)){
			dist[tmp.x+1][tmp.y]=dist[tmp.x][tmp.y]+1;
			tmp.x++;
			todo.push(tmp);
			tmp.x--;
		}
		if(tmp.y<y-1 && board[tmp.x][tmp.y+1]>0 && dist[tmp.x][tmp.y+1]>(dist[tmp.x][tmp.y]+1)){
			dist[tmp.x][tmp.y+1]=dist[tmp.x][tmp.y]+1;
			tmp.y++;
			todo.push(tmp);
			tmp.y--;
		}
	}

	double pen;
	for(unsigned int i2=0;i2<y;i2++){
		for(unsigned int i=0;i<x;i++){
			pen=(dist[i][i2]<DBL_MAX)?(1-mData.distpenalty1*pow(dist[i][i2],mData.distpenalty2)):0;
			mData.rating[i][i2] *=pen>mData.maxdistpenalty?pen:mData.maxdistpenalty;
			if(mData.rating[i][i2]>max){
				max=mData.rating[i][i2];
				maxPos.x=i;
				maxPos.y=i2;
			}
		}
	}
	return maxPos;
}

Direction Strategy::shortestWay(Size ziel){
	std::queue<Size> todo;
	Size tmp;
	unsigned int ** (&board)=mData.board;
	unsigned int &x=mData.bsize.x;
	unsigned int &y=mData.bsize.y;


	double path[x][y];

	for(unsigned int i=0;i<x;i++){
		for(unsigned int i2=0;i2<y;i2++)
			path[i][i2]=DBL_MAX;
	}


	tmp.x=ziel.x;
	tmp.y=ziel.y;
	todo.push(tmp);
	path[tmp.x][tmp.y]=0.0;

	while(!todo.empty()){
		tmp=todo.front();
		todo.pop();
		if(tmp.x>0 && board[tmp.x-1][tmp.y]>0 && path[tmp.x-1][tmp.y]>(path[tmp.x][tmp.y]+1)*
									(board[tmp.x-1][tmp.y]==mData.dryval?mData.pathdrypenalty:1)){
			path[tmp.x-1][tmp.y]=(path[tmp.x][tmp.y]+1)*
								 (board[tmp.x-1][tmp.y]==mData.dryval?mData.pathdrypenalty:1);
			tmp.x--;
			todo.push(tmp);
			tmp.x++;
		}
		if(tmp.y>0 && board[tmp.x][tmp.y-1]>0 && path[tmp.x][tmp.y-1]>(path[tmp.x][tmp.y]+1)*
									(board[tmp.x][tmp.y-1]==mData.dryval?mData.pathdrypenalty:1)){
			path[tmp.x][tmp.y-1]=(path[tmp.x][tmp.y]+1)*
								 (board[tmp.x][tmp.y-1]==mData.dryval?mData.pathdrypenalty:1);
			tmp.y--;
			todo.push(tmp);
			tmp.y++;
		}
		if(tmp.x<x-1 && board[tmp.x+1][tmp.y]>0 && path[tmp.x+1][tmp.y]>(path[tmp.x][tmp.y]+1)*
									(board[tmp.x+1][tmp.y]==mData.dryval?mData.pathdrypenalty:1)){
			path[tmp.x+1][tmp.y]=(path[tmp.x][tmp.y]+1)*
								 (board[tmp.x+1][tmp.y]==mData.dryval?mData.pathdrypenalty:1);
			tmp.x++;
			todo.push(tmp);
			tmp.x--;
		}
		if(tmp.y<y-1 && board[tmp.x][tmp.y+1]>0 && path[tmp.x][tmp.y+1]>(path[tmp.x][tmp.y]+1)*
									(board[tmp.x][tmp.y+1]==mData.dryval?mData.pathdrypenalty:1)){
			path[tmp.x][tmp.y+1]=(path[tmp.x][tmp.y]+1)*
								 (board[tmp.x][tmp.y+1]==mData.dryval?mData.pathdrypenalty:1);
			tmp.y++;
			todo.push(tmp);
			tmp.y--;
		}
	}

	Size w;
	w=mData.position;
	double min=path[w.x][w.y];
	Direction weg=CURRENT;
	w.x--;
	if(exists(w) && path[w.x][w.y]<min){
		min=path[w.x][w.y];
		weg=WEST;
	}
	w.x++;
	w.y--;
	if(exists(w) && path[w.x][w.y]<min){
		min=path[w.x][w.y];
		weg=NORTH;
	}
	w.y++;
	w.x++;
	if(exists(w) && path[w.x][w.y]<min){
		min=path[w.x][w.y];
		weg=EAST;
	}
	w.x--;
	w.y++;
	if(exists(w) && path[w.x][w.y]<min){
		min=path[w.x][w.y];
		weg=SOUTH;
	}
	w.y--;
	return weg;
}

bool Strategy::exists(unsigned int x, unsigned int y){
	return x>=0 && y>=0 && x< mData.bsize.x && y< mData.bsize.y;
}

bool Strategy::exists(Size pos){
	return exists(pos.x,pos.y);
}

Size Strategy::getPos(Direction dir){
	Size result;
	result=mData.position;
	switch (dir){
		case CURRENT:
			break;
		case WEST:
			result.x--;
			break;
		case EAST:
			result.x++;
			break;
		case NORTH:
			result.y--;
			break;
		case SOUTH:
			result.y++;
			break;
	}
	return result;
}
