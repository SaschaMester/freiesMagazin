/**
	(C) Copyright 2013 Dominik Wagenfuehr, Florian Satzger

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as
	published by the Free Software Foundation; either version 3 of the
	License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public
	License along with this program. If not, see
	<http://www.gnu.org/licenses/>.
*/

#include "StrategyData.hh"

// Konstruktor.
StrategyData::StrategyData()
	: numRound(0), position(0,0), floodedField(0,0), floodCounter(0),numFlooded(0),
//Applikationswerte:
	  bonusval(1.5), dryval(1), waterval(3), distpenalty1_init(4.23e-3),
	  distpenalty2_init(2.25),maxdistpenalty(0),pathdrypenalty(1.5)
{
	bsize.y=0;
	bsize.x=0;
	board=0;
	rating=0;
	bonus=0;
	richtung[CURRENT]="CURRENT";
	richtung[WEST]="WEST";
	richtung[NORTH]="NORTH";
	richtung[SOUTH]="SOUTH";
	richtung[EAST]="EAST";
}


bool StrategyData::initBoards(Position s){
	deleteAll();
	bsize=s;
	board=new unsigned int*[bsize.x];
	rating=new double*[bsize.x];
	bonus=new double*[bsize.x];
	if(!board || !rating || !bonus){
		return false;
	}
	for(unsigned int i=0;i<bsize.x;i++){
		board[i]=new unsigned int[bsize.y];
		rating[i]=new double[bsize.y];
		bonus[i]=new double[bsize.y];

		if(!board[i] || !rating[i] || !bonus[i]){
			return false;
		}
		for(unsigned int i2=0;i2<bsize.y;i2++)
			bonus[i][i2]=1;
	}
	return true;
}

StrategyData::~StrategyData(){
	deleteAll();
}

void StrategyData::deleteAll(){
	for (unsigned int i=0;i<bsize.x;i++){
		delete[] board[i];
		delete[] rating[i];
		delete[] bonus[i];
	}
	delete[] board;
	delete[] rating;
	delete[] bonus;
}
