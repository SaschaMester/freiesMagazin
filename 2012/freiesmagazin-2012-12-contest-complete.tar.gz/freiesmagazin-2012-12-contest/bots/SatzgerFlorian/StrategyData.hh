/**
	(C) Copyright 2013 Dominik Wagenfuehr, Florian Satzger

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as
	published by the Free Software Foundation; either version 3 of the
	License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public
	License along with this program. If not, see
	<http://www.gnu.org/licenses/>.
*/

#ifndef STRATEGYDATA_HH
#define STRATEGYDATA_HH

#include "Position.hh"
#include "size.h"
#include <string>

/// Daten fuer eine konkrete Strategie
/**
 * Die Klasse haelt alle Daten, die der Strategie wichtig sind
 * (Datenkapselung). Der Einfachheit halber koennen die Attribute
 * direkt von der Strategie verwendet werden.
 */

//! Enthält alle Richtungen
enum Direction {CURRENT, WEST, NORTH, EAST, SOUTH};

class StrategyData
{
  public:
	/// Konstruktor. Legt die Strategiekonstanten fest!
	StrategyData();

	//Destruktor
	~StrategyData();

	// Destruktor-Hilfsfunktion
	void deleteAll();

	/// Aktuelle Runde.
	unsigned int numRound;

	/// Position des Bots.
	Position position;

	/// Zuletzt ueberflutetes Feld.
	Position floodedField;

	/// Flutzaehler.
	unsigned int floodCounter;

	/// Anzahl gefluteter Felder
	unsigned int numFlooded;

	/*! Allokiert Speicher für alle verwendeten Matrizen
	 * \param s Größe des Spielbretts
	 */
	bool initBoards(Position s);

	//! Spielbrett
	unsigned int ** board;
	//! Spielbrettbewertungsmatrix
	double ** rating;
	//! Ablagestapelwertung
	double ** bonus;
	//! Spielbrettgröße
	Size bsize;


	//Strategiekonstanten
	//! Bonus für Ablagestapel (>1)
	const double bonusval;
	//! Basiswert trockenes Feld (<überschwemmtes Feld)
	const unsigned int dryval;
	//! Basiswert überschwemmtes Feld (>trockenes Feld)
	const unsigned int waterval;
	//Überflutet ist immer 0



	/*! Entfernungsstrafe1
	 * \see distpenalty2
	 * Die multiplikative Strafe für das Rating berechnet sich aus folgender Formel:
	 * \f$pen=1-distpenalty1 \cdot dist ^ {distpenalty2}\f$
	 */
	double distpenalty1;
	//! \see distpenalty1
	const double distpenalty1_init;
	/*! Entfernungsstrafe2
	 * \see distpenalty1
	 */
	double distpenalty2;
	//! \see distpenalty2
	const double distpenalty2_init;

	//! Maximale Entfernungsstrafe
	const double maxdistpenalty;

	//! Strafe für das Überlaufen eines trockenen Felds (>1)
	const double pathdrypenalty;

	//! \see Direction
	std::string richtung[5];
};



#endif // STRATEGYDATA_HH
