/**
    (C) Copyright 2012 Dominik Wagenfuehr
    (C) Copyright 2012 Momme Maraun

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "Strategy.hh"

#include "EndMessage.hh"
#include "FloodMessage.hh"
#include "GameboardEndMessage.hh"
#include "GameboardLineMessage.hh"
#include "GameboardStartMessage.hh"
#include "IncrFloodMessage.hh"
#include "StartMessage.hh"
#include "TextMessage.hh"

#include <iostream>
#include <sstream>

// Konstruktor.
Strategy::Strategy()
  : mData(), mIsFinished(false), mGameboardStarted(false)
{ 
        flutLevel=0;
}

// Destruktor.
Strategy::~Strategy()
{ }

// Werte zuruecksetzen.
void Strategy::reset()
{
}
    
// Behandelt eine Start-Nachricht.
bool Strategy::operate( const StartMessage& message )
{
    mData.numRound = message.getNumRound();
    mData.position = message.getPosition();

    // Hier muss nun die Berechnung der Befehle, die an
    // den Server gesendet werden sollen, starten.
    return calcCommands();
}

// Behandelt eine Flut-Nachricht.
bool Strategy::operate( const FloodMessage& message )
{
    mData.floodedField = message.getPosition();
    char x = feldzeilen[message.getPosition().y()-1][message.getPosition().x()-1];
    // Ueberflutete Felder sind weg, egal was vorher war
    if ( x == 'o' || x == 'O') { x = '.'; countNass--;}
    // Feld als neu ueberflutet markieren, bitte schneller trocknen.
    if ( x == '#' ) { x = 'O'; countTrocken--; countNass++; }
    feldzeilen[message.getPosition().y()-1][message.getPosition().x()-1] = x;
    return true;
}

// Behandelt eine Steigende-Flut-Nachricht.
bool Strategy::operate( const IncrFloodMessage& message )
{
    mData.floodCounter += message.getNumIncrFlood();
    if (message.getNumIncrFlood() > 0 ) {
        mData.vorletzteFlut = mData.letzteFlut;
        mData.letzteFlut = mData.numRound;
        flutLevel++;    // Aktuellen Flutlevel erhoehen
    }
    return true;
}

// Behandelt eine Ende-Nachricht.
bool Strategy::operate( const EndMessage& /* message */ )
{
    mIsFinished = true;
    return true;
}
    
// Behandelt eine Spielbrett-Start-Nachricht.
bool Strategy::operate( const GameboardStartMessage& message )
{
    mGameboardStarted = true;
    felddimension = message.getSize();
    aktzeile = 0;
    countTrocken = 0;
    countNass = 0;
    feldzeilen.resize(message.getSize().y());
    feldsuche.resize(message.getSize().y());
    bereiche.resize(message.getSize().y());
    return true;
}

// Behandelt eine Spielbrett-Zeile-Nachricht.
bool Strategy::operate( const GameboardLineMessage& message )
{
    bool retValue = false;

    if ( mGameboardStarted )
    {
        // Zeile interpretieren ...
        feldzeilen[aktzeile] = message.getLine();
        for (unsigned int x1=0; x1 < felddimension.x(); x1++) {
            if (getFeld(x1,aktzeile) == '#') countTrocken++;
            if (getFeld(x1,aktzeile) == 'o') countNass++;
        }
        aktzeile++;
//        std::cerr <<     "Zeile: " << message.getLine() << "\n";
        retValue = true;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate GameboardLineMessage"
            << std::hex << this << std::dec
            << " Gameboard transfer has not been started yet!"
            << std::endl;
        std::cerr << out.str();
        retValue = false;
    }
    
    return retValue;
}
int Strategy::suchNachbar(char aktzeichen, unsigned int x,unsigned  int y) {
    int mehr = 1;
    bereiche[y][x]  = aktzeichen;
    if ((getFeld(x,y+1) == 'O' || (getFeld(x,y+1) == 'o')) &&  bereiche[y+1][x] == ' ') { mehr += suchNachbar(aktzeichen, x,y+1); }
    if ((getFeld(x,y-1) == 'O' || (getFeld(x,y-1) == 'o')) &&  bereiche[y-1][x] == ' ') { mehr += suchNachbar(aktzeichen, x,y-1); }
    if ((getFeld(x+1,y) == 'O' || (getFeld(x+1,y) == 'o')) &&  bereiche[y][x+1] == ' ') { mehr += suchNachbar(aktzeichen, x+1,y); }
    if ((getFeld(x-1,y) == 'O' || (getFeld(x-1,y) == 'o')) &&  bereiche[y][x-1] == ' ') { mehr += suchNachbar(aktzeichen, x-1,y); }
    return mehr;
}

// Behandelt eine Spielbrett-Ende-Nachricht.
bool Strategy::operate( const GameboardEndMessage& message )
{
    mGameboardStarted = false;
    // TODO schnelle analyse wegen Bereichen und Engpäßen :-)
    std::string xx = "                                                                             ";
    for (unsigned int y1=0; y1 < felddimension.y(); y1++) {
        bereiche[y1] = xx.substr(0,feldzeilen[0].length());
    }
    char bereich = 'A'; // Wert 41
    int found = 1;
    while ( found > 0 ) {
        found = 0;
        for (unsigned int x1=0; x1 < felddimension.x(); x1++) {
            for (unsigned int y1=0; y1 < felddimension.y(); y1++) {
                 // Suche ueberflutte Felder welche keinem Bereich angehören.
                int groesse = 0;
                if ((getFeld(x1,y1) == 'o' || getFeld(x1,y1) == 'O') && bereiche[y1][x1] == ' ') {
                    groesse += suchNachbar(bereich, x1, y1);
                    // Kleine Felder ignorieren
                    if (groesse == 1) {
                        bereiche[y1][x1] = ' ';
                    } else {
//                        std::cerr << "Bereich " << bereich << " " << groesse << "\n";
                        bereich++;
                    }
                }

            }
        }
    }    
//    for (unsigned int y1=0; y1 < felddimension.y(); y1++) {
//        std::cerr << bereiche[y1] << "|\n";
//    }
    return true;
}

// Behandelt eine Textnachricht.
bool Strategy::operate( const TextMessage& message  )
{
    std::ostringstream out;
    out << "(EE) " << "Strategy::operate TextMessage "
        << std::hex << this << std::dec
        << "'" << message.getText() << "'."
        << " Cannot operate on text messages!"
        << std::endl;
    std::cerr << out.str();
    
    return false;
}

// Fragt ab, ob Kommandos zur Verfuegung stehen.
bool Strategy::isCommandsAvailable( std::vector<std::string>& cmdList )
{
    bool isAvail = false;

    cmdList.clear();
    if ( 3 == mCommandList.size() )
    {
        // Nur, wenn exakt drei Kommandos anstehen, werden diese
        // uebermittelt.
        cmdList = mCommandList;
        isAvail = true;

        // Nach dem Kopieren sollte man die Kommandos unbedingt
        // loeschen, damit bei der naechsten Abfrage nicht aus
        // Versehen noch Kommandos anstehen.
        mCommandList.clear();
    }

    return isAvail;
}

// Gibt zurueck, ob das Spiel zu Ende sein soll.
bool Strategy::isEnd() const
{
    return mIsFinished;
}

// Berechne die drei Aktionen, die spaeter ausgegeben werden sollen.
bool Strategy::calcCommands()
{
//    std::cerr << "Status Trocken:" << countTrocken << " Nass:" << countNass << " Flutlevel: " << flutLevel << "\n";
    mCommandList.resize(3);
    int index=0;
    int x = mData.position.x()-1;  // die Arrays fangen bei 0 an
    int y = mData.position.y()-1;
    index = trockneNachbarn(x,y,index);
    if (index == 3) return true;

int index2;
do  {
    index2 = index;
    // Suche das naechste Feld
    int f = 'a';
    std::string xx = "                                                                             ";
    for (unsigned int y1=0; y1 < felddimension.y(); y1++) {
        feldsuche[y1] = xx.substr(0,feldzeilen[0].length());
    }
    feldsuche[y][x] = f;
    
    int found;
    int wegx = -1;
    int wegy = -1;
    int punkte = 0;
    do {    
        found = 0;
        for (unsigned int x1=0; x1 < felddimension.x(); x1++) {
            for (unsigned int y1=0; y1 < felddimension.y(); y1++) {
//        std::cerr << "::Feld " << f << " : " << x1 << "," << y1 << "\n";
                if ( feldsuche[y1][x1] == f ) {
                    if (y1 > 0 && feldsuche[y1-1][x1] == ' ' && feldzeilen[y1-1][x1] != '.') {
                        feldsuche[y1-1][x1] = f+1;
                        if (punkte < calcUeberlaufen(x1,y1-1)){ 
                                wegx = x1;
                                wegy = y1-1;
                                punkte = calcUeberlaufen(wegx,wegy);
            }
                        if ( feldzeilen[y1-1][x1] == 'o' || feldzeilen[y1-1][x1] == 'O') {
                                found++;
                        }
                    }
            std::cerr << "::North " << punkte << " : " << wegx << "," << wegy << "\n";
                    if (x1 > 0 && feldsuche[y1][x1-1] == ' ' && feldzeilen[y1][x1-1] != '.') {
                        feldsuche[y1][x1-1] = f+1;
                            if (punkte < calcUeberlaufen(x1-1,y1)){ 
                                wegx = x1-1;
                                wegy = y1;
                                punkte = calcUeberlaufen(wegx,wegy);
                            }
                        if ( feldzeilen[y1][x1-1] == 'o' || feldzeilen[y1][x1-1] == 'O') {
                                found++;
                        }
                        found++;
                    }
            std::cerr << "::West " << punkte << " : " << wegx << "," << wegy << "\n";
                    if ((y1+1) < felddimension.y() && feldsuche[y1+1][x1] == ' ' && feldzeilen[y1+1][x1] != '.') {
                        feldsuche[y1+1][x1] = f+1;
                            if (punkte < calcUeberlaufen(x1,y1+1)){ 
                                wegx = x1;
                                wegy = y1+1;
                                punkte = calcUeberlaufen(wegx,wegy);
                            }
                        if ( feldzeilen[y1+1][x1] == 'o' || feldzeilen[y1+1][x1] == 'O') {
                                found++;
                        }
                        found++;
                    }
            std::cerr << "::South " << punkte << " : " << wegx << "," << wegy << "\n";
                    if ((x1+1) < felddimension.x() && feldsuche[y1][x1+1] == ' ' && feldzeilen[y1][x1+1] != '.') {
                        feldsuche[y1][x1+1] = f+1;
                            if (punkte < calcUeberlaufen(x1+1,y1)){ 
                                wegx = x1+1;
                                wegy = y1;
                                punkte = calcUeberlaufen(wegx,wegy);
                            }
                        if ( feldzeilen[y1][x1+1] == 'o' || feldzeilen[y1][x1+1] == 'O') {
                            found++;
                        }
                        found++;
                    }
            std::cerr << "::East " << punkte << " : " << wegx << "," << wegy << "\n";
                }
            }
        }
        // Falls ein naher Punkte gefunden wurde heißt es rennen :)
        if (punkte >20 && (wegx >= 0 || wegy >= 0)) {
            mCommandList[index++] = richtung('a', wegx, wegy);
            if (mCommandList[index-1] == "GO NORTH") { y--; }
            if (mCommandList[index-1] == "GO SOUTH") { y++; }
            if (mCommandList[index-1] == "GO EAST") { x++; }
            if (mCommandList[index-1] == "GO WEST") { x--; }
            index = trockneNachbarn(x,y,index);
            if (index < 3 && f > 'b') {
                mCommandList[index++] = richtung('b', wegx, wegy);
                if (mCommandList[index-1] == "GO NORTH") { y--; }
                if (mCommandList[index-1] == "GO SOUTH") { y++; }
                if (mCommandList[index-1] == "GO EAST") { x++; }
                if (mCommandList[index-1] == "GO WEST") { x--; }
            }
            if (index == 3) return true;

            index = trockneNachbarn(x,y,index);
            if (index == 3) return true;

            if (index < 3 && f > 'c') {
                mCommandList[index++] = richtung('c', wegx, wegy);
            }
            found = 0;    //Raus aus der Schleife
        } else if (found > 0) {
            f++;
        }
    for (unsigned int y1=0; y1 < felddimension.y(); y1++) {
        std::cerr << ":: " << feldsuche[y1] << "|\n";
    }
    } while ( found > 0);
//    for (unsigned int y1=0; y1 < felddimension.y(); y1++) {
//        std::cerr << feldzeilen[y1] << "|\n";
//    }
//    std::cerr << "GO-Current " << index << "\n";
    if (index == 3) return true;
} while (index2 != index);
    // Zur Not auffüllen, TODO waere noch sich mittig zu positionieren.
    int aktwege = flucht(x,y);
    int nord = flucht(x,y-1);
    int sued = flucht(x,y+1);
    int ost = flucht(x+1,y);
    int west = flucht(x-1,y);
    int xxx = aktwege;
    if (nord > xxx) xxx = nord;
    if (sued > xxx) xxx = sued;
    if (ost > xxx) xxx = ost;
    if (west > xxx) xxx = west;
    if (xxx > aktwege) {
    std::cerr << ":: FLUCHTX:" << aktwege << "," << nord << "," << sued << "," << ost << "," << west << "\n";
        if (xxx == nord) { mCommandList[index++] = "GO NORTH"; y--; }
        else if (xxx == sued) { mCommandList[index++] = "GO SOUTH"; y++; }
        else if (xxx == ost) { mCommandList[index++] = "GO EAST"; x++; }
        else if (xxx == west) { mCommandList[index++] = "GO WEST"; x--; }
        if (index == 3) return true;
    aktwege = xxx;
        nord = flucht(x,y-1);
        sued = flucht(x,y+1);
        ost = flucht(x+1,y);
        west = flucht(x-1,y);
        if (nord > xxx) xxx = nord;
        if (sued > xxx) xxx = sued;
        if (ost > xxx) xxx = ost;
        if (west > xxx) xxx = west;
        if (xxx > aktwege) {
        std::cerr << ":: FLUCHTX:" << aktwege << "," << nord << "," << sued << "," << ost << "," << west << "\n";
            if (xxx == nord) { mCommandList[index++] = "GO NORTH"; y--; }
            else if (xxx == sued) { mCommandList[index++] = "GO SOUTH"; y++; }
            else if (xxx == ost) { mCommandList[index++] = "GO EAST"; x++; }
            else if (xxx == west) { mCommandList[index++] = "GO WEST"; x--; }
        }
    }
    if (index == 3) return true;
    mCommandList[index++] = "GO CURRENT";
    if (index == 3) return true;
    mCommandList[index++] = "GO CURRENT";
    if (index == 3) return true;
    mCommandList[index++] = "GO CURRENT";

    return true;
}
/*
        if (wegy > 0 && feldsuche[wegy-1][wegx] == previous) { tempo = 2 + flucht(wegx,wegy-1); if ( tempo > max) tempo = max; }
        else if (wegx > 0 && feldsuche[wegy][wegx-1] == previous) { tempo = 1 + flucht(wegx-1,wegy); if (tempo > max) tempo = max;}
        else if ((wegy+1) < felddimension.y() && feldsuche[wegy+1][wegx] == previous) { tempo = 0 + flucht(wegx,wegy+1); if (tempo > max) tempo = max; }
        else if ((wegx+1) < felddimension.x() && feldsuche[wegy][wegx+1] == previous){ tempo = 3 + flucht(wegx+1,wegy); if (tempo > max) tempo = max; }
    if (( max & 3) == 2 ) { richtung = "GO SOUTH"; neuy--; }
    if (( max & 3) == 1 ) { richtung = "GO EAST"; neux--;}
    if (( max & 3) == 0 ) { richtung = "GO NORTH"; neuy++; }
    if (( max & 3) == 3 ) { richtung = "GO WEST"; neux++; }
        wegx = neux;
        wegy = neuy;
        previous--;
    }
    return richtung;
}
*/


std::string Strategy::richtung(char ziel, unsigned int wegx, unsigned int wegy) {
    char previous = feldsuche[wegy][wegx];
    unsigned int neux = wegx;
    unsigned int neuy = wegy;
    std::string richtung = "GO CURRENT";
    previous--;
    while (ziel <= previous) {
//        std::cerr << "Richtung:" << previous << " x=" << wegx << " y=" << wegy << "\n";
        int tempo = 0;
        int max = 0;
        if (wegy > 0 && feldsuche[wegy-1][wegx] == previous) { tempo = 2 + flucht(wegx,wegy-1); if ( tempo > max) max = tempo; }
        else if (wegx > 0 && feldsuche[wegy][wegx-1] == previous) { tempo = 1 + flucht(wegx-1,wegy); if (tempo > max) max = tempo;}
        else if ((wegy+1) < felddimension.y() && feldsuche[wegy+1][wegx] == previous) { tempo = 0 + flucht(wegx,wegy+1); if (tempo > max) max = tempo; }
        else if ((wegx+1) < felddimension.x() && feldsuche[wegy][wegx+1] == previous){ tempo = 3 + flucht(wegx+1,wegy); if (tempo > max) max = tempo; }
    if (( max & 3) == 2 ) { richtung = "GO SOUTH"; neuy--; }
    if (( max & 3) == 1 ) { richtung = "GO EAST"; neux--;}
    if (( max & 3) == 0 ) { richtung = "GO NORTH"; neuy++; }
    if (( max & 3) == 3 ) { richtung = "GO WEST"; neux++; }
         wegx = neux;
         wegy = neuy;
         previous--;
     }
     return richtung;
 }



int Strategy::flucht(unsigned int x, unsigned int y) {
    int mx = 0;
    if (getFeld(x,y) == '.') return 0;
    if (getFeld(x,y-1) != '.') mx++;
    if (getFeld(x,y+1) != '.') mx++;
    if (getFeld(x-1,y) != '.') mx++;
    if (getFeld(x+1,y) != '.') mx++;
    return mx*8;
}

char Strategy::getFeld(unsigned int x, unsigned int y) {
    if (y >= 0 && y < felddimension.y()  && x >= 0  && x < felddimension.x() ) 
        return feldzeilen[y][x];
    return '.'; 
}

// Zaehle wie gut ein Feld ist, 20 je ueberflutete Nachbarfeld + 1 je Fluchtfeld
int Strategy::calcUeberlaufen(unsigned int x, unsigned int y) {
    int count = 0;
    if (y >= felddimension.y() || x >= felddimension.x() ) return count;
    if (feldzeilen [y][x] == '.') return count;    // Wasserfelder ignorieren

    if (getFeld(x,y+1) != '.') count++;
    if (getFeld(x,y-1) != '.') count++;
    if (getFeld(x-1,y) != '.') count++;
    if (getFeld(x+1,y) != '.') count++;

    if (y > 0                       && (feldzeilen[y-1][x] == 'o' || feldzeilen[y-1][x] == 'O')) { 
        count += 20;
        if (getFeld(x,y-2) == 'o' || getFeld(x,y-2) == 'O') count +=20;
        if (getFeld(x-1,y-1) == 'o' || getFeld(x-1,y-1) == 'O') count +=20;
        if (getFeld(x+1,y-1) == 'o' || getFeld(x+1,y-1) == 'O') count +=20;
        }
    if (y < (felddimension.y() - 1) && (feldzeilen[y+1][x] == 'o' || feldzeilen[y+1][x] == 'O')) { 
        count += 20;
        if (getFeld(x,y+2) == 'o' || getFeld(x,y+2) == 'O') count +=20;
        if (getFeld(x-1,y+1) == 'o' || getFeld(x-1,y+1) == 'O') count +=20;
        if (getFeld(x+1,y+1) == 'o' || getFeld(x+1,y+1) == 'O') count +=20;
        }
    if (x > 0                       && (feldzeilen[y][x-1] == 'o' || feldzeilen[y][x-1] == 'O')) { 
        count += 20;
        if (getFeld(x-2,y) == 'o' || getFeld(x-2,y) == 'O') count +=20;
        if (getFeld(x-1,y+1) == 'o' || getFeld(x-1,y+1) == 'O') count +=20;
        if (getFeld(x-1,y-1) == 'o' || getFeld(x-1,y-1) == 'O') count +=20;
        }
    if (x < (felddimension.x() - 1) && (feldzeilen[y][x+1] == 'o' || feldzeilen[y][x+1] == 'O')) { 
        if (getFeld(x+2,y) == 'o' || getFeld(x+2,y) == 'O') count +=20;
        if (getFeld(x+1,y+1) == 'o' || getFeld(x+1,y+1) == 'O') count +=20;
        if (getFeld(x+1,y-1) == 'o' || getFeld(x+1,y-1) == 'O') count +=20;
        count += 20;
        }
    std::cerr << "::Calc " << x << "," << y << "=" << count << "\n";
    return count;
}


int Strategy::trockneNachbarn(unsigned int x,unsigned  int y, int index){
    char c = getFeld(x,y);
    // Feld unter mir wenn moeglich IMMER trocknen.
    if (c == 'o' || c == 'O') {
        mCommandList[index++] = "DRY CURRENT";
        feldzeilen[y][x] = '#';
        countNass--; countTrocken++;
    }
    if (index == 3) return index;

    // Bei den anderen Felder kontrollieren welches schon mal ueberflutet war.

    c = getFeld(x,y-1); if (c == 'O' || c == 'o') { mCommandList[index++] = "DRY NORTH"; feldzeilen[y-1][x] = '#'; countNass--; countTrocken++; }
    if (index == 3) return index;

    c = getFeld(x,y+1); if (c == 'O' || c == 'o') { mCommandList[index++] = "DRY SOUTH"; feldzeilen[y+1][x] = '#'; countNass--; countTrocken++; }
    if (index == 3) return index;

    c = getFeld(x+1,y); if (c == 'O' || c == 'o') { mCommandList[index++] = "DRY EAST"; feldzeilen[y][x+1] = '#'; countNass--; countTrocken++; }
    if (index == 3) return index;

    c = getFeld(x-1,y); if (c == 'O' || c == 'o') { mCommandList[index++] = "DRY WEST"; feldzeilen[y][x-1] = '#'; countNass--; countTrocken++; } 
    if (index == 3) return index;

    c = getFeld(x,y-1); if (c == 'o') { mCommandList[index++] = "DRY NORTH"; feldzeilen[y-1][x] = '#'; countNass--; countTrocken++; }
    if (index == 3) return index;

    c = getFeld(x,y+1); if (c == 'o') { mCommandList[index++] = "DRY SOUTH"; feldzeilen[y+1][x] = '#'; countNass--; countTrocken++; }
    if (index == 3) return index;

    c = getFeld(x+1,y); if (c == 'o') { mCommandList[index++] = "DRY EAST"; feldzeilen[y][x+1] = '#'; countNass--; countTrocken++; }
    if (index == 3) return index;

    c = getFeld(x-1,y); if (c == 'o') { mCommandList[index++] = "DRY WEST"; feldzeilen[y][x-1] = '#'; countNass--; countTrocken++; } 

    return index;
}
