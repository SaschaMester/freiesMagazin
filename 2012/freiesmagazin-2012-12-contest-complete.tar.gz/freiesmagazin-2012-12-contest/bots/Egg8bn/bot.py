#!/usr/bin/env python
# 
#    Programming competition.
#    http://www.freiesmagazin.de/sechster_programmierwettbewerb
# 
#    (C) Copyright 2012 Dominik Bartenstein
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as
#    published by the Free Software Foundation; either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with this program. If not, see
#    <http://www.gnu.org/licenses/>.

import sys
from base import HiddenIsland
from strategy import Strategy
# logfile to the outer world
logfile = open('/tmp/bot.log', 'w')

fin = sys.stdin
running = True
flood = 0
island_structure = []

while running:
	line = fin.readline().strip()
	if not len(line):
		continue
	logfile.flush()
	parts = line.split(' ')
	command = parts[0].strip()
	logfile.write('  ==> %s\n' %(command,))
	logfile.flush()
	
	# sending gameboard info
	if command == 'GAMEBOARDSTART':
		dimensionlist = parts[1].split(',')
		dimension = (int(dimensionlist[0]), int(dimensionlist[1]))
		island = HiddenIsland(dimension)
		strategy = Strategy(island)
		logfile.write('create new board object\n')
		
	elif '.' in command or '#' in command or 'o' in command:
		logfile.write('setting fields of game board\n')
		island_structure.append(command)
		logfile.write(command + '\n')
	elif command == 'GAMEBOARDEND':
		logfile.write(str(dir(island)))
		island._set_islandstructure(island_structure)
		logfile.write('let the games commence\n')
	# next round starts
	elif command == 'ROUND':
		logfile.write('inside round\n')
		round_number = int(parts[1])
		positionlist = parts[2].split(',')
		position = (int(positionlist[0]), int(positionlist[1]))
		# telling game board at which coordinates the guy currently stands
		logfile.write('starting round %d at position %s\n' %(round_number, str(position)))
		logfile.flush()
		# action is required now!
		# ask the object for the next three moves
		island._set_round(round_number)
		island._set_position(position)
		
		# update island object for strategy 
		strategy.reset_island(island)
		for move in strategy.next_three_moves(round_number):
			action, direction = move.split(' ')
			if action.strip() == 'GO':
				island.move(direction.strip())
			elif action.strip() == 'DRY':
				island.dry_field(direction.strip())
			else:
				logfile.write('unknown command: %s' %(action, ))
				logfile.flush()
			sys.stdout.write('%s\n' %move)
			sys.stdout.flush()
			logfile.flush()
			logfile.write('%s\n' %move)
	elif command == 'INCRFLOOD':
		flood_increase = int(parts[1])
		island._increase_flood(flood_increase)
		flood += flood_increase
		logfile.write('flood increased by %d, now at level %d\n' %(flood_increase, flood))
		logfile.flush()
		
	elif command == 'FLOOD':
		coordinates = parts[1].split(',')
		floodpos = (int(coordinates[0]), int(coordinates[1]))
		island._flood_field(floodpos)
		logfile.write('flood happens at %s\n' %(str(floodpos)))
	
	elif command == 'END':
		running = False
		
	else:
		logfile.write('unknown command\n')
		logfile.write(command)
		runnig = False

logfile.close()
