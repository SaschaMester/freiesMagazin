#!/usr/bin/env python
# 
#    Programming competition.
#    http://www.freiesmagazin.de/sechster_programmierwettbewerb
# 
#    (C) Copyright 2012 <Maximilian Ruescher, Julian Sutterluetty> Borg Egg
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as
#    published by the Free Software Foundation; either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with this program. If not, see
#    <http://www.gnu.org/licenses/>.

from base import BaseStrategy, HiddenIsland

class Strategy(BaseStrategy):
	'''
	this is your strategy.
	the only thing you have to do is make the method next_three_moves more
	intelligent. 
	
	you have access to the attribute island which is an object of class HiddenIsland!
	e.g. to have a look at the field in the NORTH you can call:
		field = self.island.get_neighbour_field('NORTH')
	to check the status of this field you could do:
		field == HiddenIsland.FLOODED # is the field flooded
	'''
	
	def next_three_moves(self, round_number):
		'''
		next three moves of this round. this method is automatically called by the bot.
		ARGUMENTS:
			round_number	integer		number of current round
		RETURN VALUE:
			commands	list with exactly 3 strings		e.g. ['GO NORTH', 'DRY CURRENT', 'GO EAST']
		'''
		
		field = self.island.get_field(1, 1)
		EASTINVALID = False
		moves = []
		directions = ["CURRENT", "NORTH", "SOUTH", "EAST", "WEST"]
		
		def dry_around_us():
			# dry everything around us.
			for direction in directions:
				check_field = self.island.get_neighbour_field(direction)
				if check_field == HiddenIsland.FLOODED:
					if len(moves) < 3:
						self.island.dry_field(direction)
						moves.append('DRY ' + direction)
		
		dry_around_us()
		# try to dry all corners.
		for direction in ['NORTHEAST', 'SOUTHEAST', 'NORTHWEST', 'SOUTHWEST']:
			if self.island.get_neighbour_field(direction) == HiddenIsland.FLOODED:
				if len(moves) < 2:
					direction1, direction2 = direction[:5], direction[5:]
					if self.island.get_neighbour_field(direction1) in HiddenIsland.WALKABLE:
						self.island.move(direction1)
						moves.append('GO ' + direction1)
						self.island.dry_field(direction2)
						moves.append('DRY ' + direction2)
					elif self.island.get_neighbour_field(direction2) in HiddenIsland.WALKABLE:
						self.island.move(direction2)
						moves.append('GO ' + direction2)
						self.island.dry_field(direction1)
						moves.append('DRY ' + direction1)
						
		dry_around_us()
		
		if len(moves) < 3:
			position = self.island.get_position()
			if position[0] == 1:
				if self.island.get_neighbour_field('SOUTH') in HiddenIsland.WALKABLE:
					self.island.move('SOUTH')
					moves.append('GO SOUTH')
			elif position[1] == 1:
				if self.island.get_neighbour_field('EAST') in HiddenIsland.WALKABLE:
					self.island.move('EAST')
					moves.append('GO EAST')
					
		if len(moves) < 2:
			for direction in directions:	
				if self.island.get_neighbour_field(direction) in HiddenIsland.WALKABLE:
					if self.island.get_neighbour_field(direction, 2) == HiddenIsland.FLOODED:
						self.island.move(direction)
						moves.append('GO ' + direction)
						self.island.dry_field(direction)
						moves.append('DRY ' + direction)
						
		if len(moves) < 1:
			for direction in directions:
				if self.island.get_neighbour_field(direction, 3) == HiddenIsland.FLOODED:
					if self.island.get_neighbour_field(direction, 2) == HiddenIsland.DRY:
						if self.island.get_neighbour_field(direction) == HiddenIsland.DRY:
							self.island.move(direction)
							moves.append('GO ' + direction)
							self.island.dry_field(direction)
							moves.append('GO ' + direction)
							self.island.dry_field(direction)
							moves.append('DRY ' + direction)
							
															
		while len(moves) < 3:
			moves.append('GO CURRENT')
		return moves[:3]

