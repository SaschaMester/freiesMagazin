#!/usr/bin/env python
# 
#    Programming competition.
#    http://www.freiesmagazin.de/sechster_programmierwettbewerb
# 
#    (C) Copyright 2012 Dominik Bartenstein
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as
#    published by the Free Software Foundation; either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with this program. If not, see
#    <http://www.gnu.org/licenses/>.

import logging
import random
import copy

handler = logging.FileHandler('/tmp/hiddenisland.log', 'w+')
frm = logging.Formatter("%(asctime)s %(levelname)s: %(message)s", 
                              "%d.%m.%Y %H:%M:%S") 
handler.setFormatter(frm)
logger = logging.getLogger()
logger.addHandler(handler)
logger.setLevel(logging.DEBUG)

class HiddenIsland(object):
	'''
	forbidden island!
	'''
	
	INVALID = -1
	WATER = 0
	FLOODED = 1
	DRY = 2
	
	FIELD_LOOKUP = {'.': WATER, 'o': FLOODED, '#': DRY}
	TRANSITIONS = {DRY: FLOODED, FLOODED: WATER}
	DIRECTIONS = {'NORTH': (0, -1), 'EAST': (1, 0), 'SOUTH': (0, 1), 'WEST': (-1, 0), 'CURRENT': (0, 0),
	              'NORTHEAST': (1, -1), 'SOUTHEAST': (1, 1), 'SOUTHWEST': (-1, 1), 'NORTHWEST': (-1, -1)}
	WALKABLE = (DRY, FLOODED)
	
	def __init__(self, dimension):
		'''
		constructor
		ARGUMENTS:
			dimension	2-tuple with integers	e.g. (6, 8)
		RETURN VALUE:
		    -
		'''
		
		self.size_x = dimension[0]
		self.size_y = dimension[1]
		
		self.floodlevel = 0
		self.position = None
		self.round_number = 0
	
	def get_position(self):
		'''
		return position of human on island.
		ARGUMENTS:
			-
		RETURN VALUE:
			position of human on island 	2-tuple with integers		e.g. (2,2)
		'''
		
		return self.position
	
	def get_floodlevel(self):
		'''
		return current flood level. 
		the flood level determines how many fields will be flooded in the next round.
		
		ARGUMENTS:
			-
		RETURN VALUE:
			current floodlevel		integer
		'''
		
		return self.floodlevel
		
	
	def get_field(self, x, y):
		'''
		    1 2 3 
		  -------- 
		1 | W F W
		2 | W D D
		3 | W D W
		
		find out the state of the field at
		the given position
		
		ARGUMENTS:
			x			integer		x-position starting with 1
			y			integer		y-position starting with 1
		RETURN VALUE:
			fieldstat	integer
		'''
		
		if x in range(1, self.size_x +1) and y in range(1, self.size_y + 1):
			return self.fields[y-1][x-1]
		
		# out of bounds
		return self.INVALID
	
	def get_neighbour_field(self, direction, factor=1):
		'''
		what field state does the neighbour field have?
		NORTH EAST SOUTH WEST CURRENT
		
		ARGUMENTS:
			direction	string		NORTH | EAST | SOUTH | WEST | CURRENT
			factor		integer		multiply distance with factor, e.g. NORTH 2 = NORTH-NORTH
		RETURN VALUE:
			fieldstat	integer		HiddenIsland.DRY | HiddenIsland.WATER | HiddenIsland.FLOODED | HiddenIsland.INVALID
		'''
		
		x_current, y_current = self.position
		x_offset, y_offset = self.DIRECTIONS[direction]
		x, y = x_current + factor * x_offset, y_current + factor * y_offset
		#logger.error('field %s (x%d) %d, %d: %d' %(direction, factor, y-1, x-1, self.get_field(x, y)))
		return self.get_field(x, y)
	
	def get_round(self):
		'''
		number of round
		
		ARGUMENTS:
			-
		RETURN VALUE:
			round		integer		1 ... n
		'''
		
		return self.round_number
	
	def dry_field(self, direction):
		'''
		try to dry the given field
		'''
		
		x_current, y_current = self.position
		x_offset, y_offset = self.DIRECTIONS[direction]
		x, y = x_current + x_offset, y_current + y_offset
		state = self.get_field(x, y)
		if state != self.FLOODED:
			logger.error('field (%d, %d) is not flooded and cannot be dried!' %(x, y))
		self._set_field(x, y, self.DRY)
		
	def move(self, direction):
		'''
		move position of human to the given direction:
		NORTH EAST SOUTH WEST CURRENT
		'''
		
		x, y = self.position
		x_offset, y_offset = self.DIRECTIONS[direction]
		self.position = (x + x_offset, y + y_offset)
	
	def _set_field(self, x, y, state):
		'''
		set new state to field
		'''
		
		if state not in self.FIELD_LOOKUP.values():
			logger.error('state %d for field (%d, %d) not valid!' %(state, x, y))
		self.fields[y-1][x-1] = state
	
	def _set_round(self, round_number):
		self.round_number = round_number
		
	def _set_position(self, position):
		'''
		position is set by server. if new position
		and old position do not match, there is 
		something wrong!
		'''
		
		if self.position and self.position != position:
			logger.error('positions do not match! %s vs. %s' %(str(self.position), str(position)))
		
		self.position = position
		
	def _set_islandstructure(self, structure):
		'''
		setting the structure of the island.
		.	water/lost land
		o	flooded land
		#	dry land
		
		ARGUMENTS:
			structure	list of strings 
		RETURN VALUE:
			-
		'''

		self.fields = []
		for linestring in structure:
			line = []
			for element in linestring:
				line.append(self.FIELD_LOOKUP[element])
			self.fields.append(line)
					
	
	def _increase_flood(self, increase):
		'''
		increase the current flood level by increase
		ARGUMENTS:
			increase	integer	level by which flood increases
		RETURN VALUE:
			-
		'''
		
		self.floodlevel += increase
		
	
	def _flood_field(self, position):
		'''
		flood the field at the given position!
		x and y start at 1 (not 0)
		
		important! each field has three states. 
			dry land ---FLOOD---> flooded land
			flooded land ---FLOOD---> water/lost land
		
		ARGUMENTS:
			position	2-tuple with integers	e.g. (5, 5)
		RETURN VALUE:
			-
		'''
		
		x, y = position[0], position[1]
		self.fields[y-1][x-1] = self.TRANSITIONS[self.fields[y-1][x-1]]

class BaseStrategy:

	def __init__(self, island):
		'''
		set the island.
		ARGUMENTS:
			island	island object
		RETURN VALUE:
			-
		'''
		
		self._island = island
		self.island = copy.deepcopy(self._island)
	
	def reset_island(self, island):
		'''
		set island to the current state after communication with server
		'''
		
		self.island = copy.deepcopy(island)
	
	def next_three_moves(self, round_number):
		'''
		next three moves of this round
		ARGUMENTS:
			round_number	integer		number of current round
		RETURN VALUE:
			list with 3 strings		e.g. ['GO NORTH', 'DRY CURRENT', 'GO EAST']
		'''
		
		moves = ['GO CURRENT', 'GO CURRENT', 'GO CURRENT']
		return moves
