/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef GRAPH_HH
#define GRAPH_HH

#include "Direction.hh"
#include "Node.hh"
#include "Position.hh"

#include <string>
#include <deque>

// Vorwaertsdeklarationen.
class GameboardIF;

// Kurzschreibweise fuer ein Deque mit Zeigern auf Knoten.
typedef std::deque<Node*> NodePointerDeque;

/// Graph eines Spielbretts.
/**
 * Der Graph erzeugt aus einem Spielbrett Knoten und Kanten und kann
 * dann mit verschiedenen Algorithmen darueber leicht iterieren, um
 * die kuerzeste Verbindung zu finden.
 */
class Graph
{
  public:
    /// Default-Konstruktor.
    /**
     * Es wird ein "leerer" Graph erzeugt.
     */
    Graph();

    /// Destruktor.
    ~Graph();

    /// Gibt Breite des Graphen/des Spielbretts zurueck.
    unsigned int getWidth() const;

    /// Gibt Hoehe des Graphen/des Spielbretts zurueck.
    unsigned int getHeight() const;

    /// Ist der erstellte Graph valide.
    /**
     * Valide bedeutet, dass alle Knoten und Kanten korrekt
     * initialisiert wurden.
     */
    bool isValid() const;

    /// Zugriff auf ein Knoten-Element.
    /**
     * @param pos Position auf dem Original-Spielbrett
     * @return Zeiger auf den zugehoerigen Knoten, oder 0, falls der Knoten
     * nicht existiert.
     */
    Node* operator[]( const Position& pos ) const;

    /// Initialisiert den Graphen mit einem Spielbrett.
    /**
     * @param originalBoard Originales Spielbrett, aus dem ein Graph erstellt
     * werden soll.
     * @return true, wenn der Graph korrekt erstellt wurde.
     */
    bool init( const GameboardIF& originalBoard );

    /// Setzt alle dynamisch berechneten Werte zurueck.
    /**
     * Darunter fallen Start- udn Zielknoten, der Abstand zum Start,
     * der Kanten-Status, und der kuerzeste Pfad.
     */
    void resetAlgorithmData();
    
    /// Speichert den Graph als Datei im dot-Format.
    /**
     * Die Ausgabe erfolgt als dot-Datei von Graphviz.
     * @param filename Dateiname zum Schreiben.
     * @return true, wenn der Graph geschrieben werden konnte.
     */
    bool saveGraphviz( const std::string& filename ) const;

  private:
    /// Loesche den Graph.
    void clear();

    /// Verbindet die jeweiligen Nachbarknoten im Graph.
    /**
     * @return true, wenn alles okay ist, sonst false
     */
    bool initNeighbors();

    /// Verbindet zwei Knoten auf bestimmten Positionen.
    /**
     * @param originPos Ausgangsknoten.
     * @param targetPos Zielknoten
     * @param dir Richtung, wie die Knoten verbunden sind.
     * @return true, wenn die Knoten verbunden werden konnten, sonst false.
     */
    bool initNeighbors( const Position& originPos,
                        const Position& targetPos,
                        const Direction dir );

    /// Speichert einzelnen Knoten im dot-Format.
    void saveGraphvizNode( std::ofstream& outFile,
                           const unsigned int x, const unsigned int y,
                           const int dist,
                           const std::string& color,
                           const bool isEndNode ) const;

    /// Speichert einzelne Kante im dot-Format.
    void saveGraphvizEdge( std::ofstream& outFile,
                           const unsigned int x1, const unsigned int y1,
                           const unsigned int x2, const unsigned int y2,
                           const int distance,
                           const std::string& color ) const;

    /// Umrechnung von Position in interne Position im Deque.
    unsigned int aPos( const Position& pos ) const;

    /// Umrechnung von Position in interne Position im Deque.
    unsigned int aPos( const unsigned int x, const unsigned int y ) const;

    /// Prueft, ob die Position fuer das Spielbrett valide ist.
    bool isValidPosNoCheck( const Position& pos ) const;

  private:
    // Pointer to all tiles in the game board with neighbors etc.
    NodePointerDeque mNodePtrs;
    
    // Size of gameboard.
    Position mSize;
    
    // Flag if constructed astar board is valid.
    bool mValid;
};

// Gibt Breite des Graphen/des Spielbretts zurueck.
inline
unsigned int Graph::getWidth() const
{
    return mSize.x();
}

// Gibt Hoehe des Graphen/des Spielbretts zurueck.
inline
unsigned int Graph::getHeight() const
{
    return mSize.y();
}
    
// Ist der erstellte Graph valide.
inline
bool Graph::isValid() const
{
    return mValid;
}

// Umrechnung von Position in interne Position im Deque.
inline
unsigned int Graph::aPos( const Position& pos ) const
{
    // Achtung: Position faengt bei (1,1) an.
    return aPos( pos.x(), pos.y() );
}

// Umrechnung von Position in interne Position im Deque.
inline
unsigned int Graph::aPos( const unsigned int x, const unsigned int y ) const
{
    // Achtung: Position faengt bei (1,1) an.
    return (x-1)+(y-1)*getWidth();
}

// Prueft, ob die Position fuer das Spielbrett valide ist.
inline
bool Graph::isValidPosNoCheck( const Position& pos ) const
{
    return ( pos.isValid() && ( pos <= mSize ) );
}

#endif // GRAPH_HH
