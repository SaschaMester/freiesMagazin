/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "Graph.hh"

#include "GameboardIF.hh"

#include <fstream>
#include <iostream>
#include <sstream>

// Default-Konstruktor.
Graph::Graph()
  : mNodePtrs(), mSize(), mValid(false)
{
    // Leere Graph.
}

// Destruktor.
Graph::~Graph()
{
    clear();
}

// Loesche den Graph.
void Graph::clear()
{
    // Loesche alle Knoten
    for ( size_t ii = 0; ii < mNodePtrs.size(); ii++ )
    {
        delete mNodePtrs[ii];
        mNodePtrs[ii] = 0;
    }

    mSize.setPosition(0,0);
    mValid = false;
}

// Setzt alle dynamisch berechneten Werte zurueck.
void Graph::resetAlgorithmData()
{
    for ( size_t ii = 0; ii < mNodePtrs.size(); ii++ )
    {
        if ( mNodePtrs[ii] )
        {
            mNodePtrs[ii]->resetAlgorithmData();
        }
    }
}

// Zugriff auf ein Knoten-Element.
Node* Graph::operator[] ( const Position& pos ) const
{
    Node* nodePtr = 0;
    
    if ( isValidPosNoCheck( pos ) )
    {
        nodePtr = mNodePtrs[aPos(pos)];
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Graph::operator[] "
            << std::hex << this << std::dec
            << " Position " << pos
            << " is not valid for size" << mSize
            << "."
            << std::endl;
        std::cerr << out.str();
    }

    return nodePtr;
}

// Initialisiert den Graphen mit einem Spielbrett.
bool Graph::init( const GameboardIF& originalBoard )
{
    bool retVal = false;
    
    // Alten Graph vorsorglich loeschen.
    clear();
    
    if ( originalBoard.getSize().isValid() )
    {
        // Das uebergebene Spielbrett ist valide.
        
        // Speichere Spielbrettgroese und lege reserviere Platz
        // fuer die Zeiger.
        
        mSize = originalBoard.getSize();
        mNodePtrs.resize( getWidth()*getHeight() );

#ifdef DEBUG
        {
            std::ostringstream out;
            out << "(DD) Graph::init "
                << std::hex << this << std::dec
                << " Pointer memory in deque allocated."
                << std::endl;
            std::clog << out.str();
        }
#endif

        Position pos;
        bool someError = false;
        
        // Allokiere Speicher fuer Knoten.
        for ( unsigned int jj = 1; jj <= getHeight(); jj++ )
        {
            for ( unsigned int ii = 1; ii <= getWidth(); ii++ )
            {
                pos.setPosition(ii,jj);
                
                TileType type = TILETYPE_LOST;
                
                if ( originalBoard.isDry(pos) )
                    type = TILETYPE_DRY;
                else if ( originalBoard.isFlooded(pos) )
                    type = TILETYPE_FLOODED;
                else if ( originalBoard.isLost(pos) )
                    type = TILETYPE_LOST;
                else
                {
                    // Kein bekannter Zustand.
                    std::ostringstream out;
                    out << "(WW) Graph::init "
                        << std::hex << this << std::dec
                        << " Unknown tile state for tile "
                        << pos << "."
                        << std::endl;
                    std::cerr << out.str();
                    someError = true;
                    break;
                }
                
                // Speicher allokieren.
                Node* nodePtr = new Node( pos, type );

                if ( nodePtr )
                {
                    mNodePtrs[aPos(ii,jj)] = nodePtr;
                }
                else
                {
                    // Speicher konnte nicht allokiert werden.
                    std::ostringstream out;
                    out << "(WW) Graph::init "
                        << std::hex << this << std::dec
                        << " Could not allocate memory for "
                        << pos << "."
                        << std::endl;
                    std::cerr << out.str();
                    someError = true;
                    break;
                }
            }
            
            if ( someError )
            {
                break;
            }
        }

#ifdef DEBUG
        {
            std::ostringstream out;
            out << "(DD) Graph::init "
                << std::hex << this << std::dec
                << " Node memory allocated with status "
                << !someError
                << std::endl;
            std::clog << out.str();
        }
#endif
        
        if ( !someError )
        {
            // Wenn es zu keinem Fehler kam, initialiseren wir die Nachbarn.
            retVal = initNeighbors();
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Graph::init "
            << std::hex << this << std::dec
            << " Gameboard size " << originalBoard.getSize()
            << " is not valid."
            << std::endl;
        std::cerr << out.str();
    }
    
    // Setze Validitaetsstatus.
    mValid = retVal;
    
    return retVal;
}

// Verbindet die jeweiligen Nachbarknoten im Graph.
bool Graph::initNeighbors()
{
    bool retVal = true;
    Position originPos, targetPos;
    
    // Iteriere ueber alle Knoten 
    for ( unsigned int jj = 1; jj <= getHeight(); jj++ )
    {
        for ( unsigned int ii = 1; ii <= getWidth(); ii++ )
        {
            originPos.setPosition(ii,jj);

            Node* originNodePtr = mNodePtrs[aPos(originPos)];
            
            if ( originNodePtr )
            {
                // Wenn das Feld untergegangen ist, muessen wir es nicht
                // verbinden.
                if ( TILETYPE_LOST != originNodePtr->getTileType() )
                {
#ifdef DEBUG
                    std::ostringstream out;
                    out << "(DD) Graph::initNeighbors "
                        << std::hex << this << std::dec
                        << " Init node " << originPos << ": "
                        << std::endl;
                    std::clog << out.str();
#endif

                    // Achtung: Es wird hier von einem rechteckigen Spielbrett
                    // ausgegangen mit den vier Himmelsrichtungen.
                    targetPos.setPosition( ii-1, jj );
                    if ( !initNeighbors( originPos, targetPos, DIRECTION_WEST ) )
                    {
                        retVal = false;
                    }

                    targetPos.setPosition( ii+1, jj );
                    if ( !initNeighbors( originPos, targetPos, DIRECTION_EAST ) )
                    {
                        retVal = false;
                    }
                    
                    targetPos.setPosition( ii, jj-1 );
                    if ( !initNeighbors( originPos, targetPos, DIRECTION_NORTH ) )
                    {
                        retVal = false;
                    }

                    targetPos.setPosition( ii, jj+1 );
                    if ( !initNeighbors( originPos, targetPos, DIRECTION_SOUTH ) )
                    {
                        retVal = false;
                    }

                    if ( !retVal )
                    {
                        break;
                    }
                }
#ifdef DEBUG
                else
                {
                    std::ostringstream out;
                    out << "(DD) Graph::initNeighbors "
                        << std::hex << this << std::dec
                        << " Init node " << originPos << " NO!"
                        << std::endl;
                    std::clog << out.str();
                }
#endif
            }
            else
            {
                std::ostringstream out;
                out << "(EE) Graph::initNeighbors "
                    << std::hex << this << std::dec
                    << "Origin "
                    << std::hex << originNodePtr << std::dec
                    << " is 0."
                    << std::endl;
                std::cerr << out.str();                
                retVal = false;
                break;
            }
        }

        if ( !retVal )
        {
            break;
        }
    }

    return retVal;
}

// Verbindet zwei Knoten auf bestimmten Positionen.
bool Graph::initNeighbors( const Position& originPos,
                           const Position& targetPos,
                           const Direction dir )
{
    bool retVal = false;
    
    // check if tiles exists on board
    if ( isValidPosNoCheck(originPos) )
    {
        if ( isValidPosNoCheck(targetPos) )
        {
            Node* originNodePtr = mNodePtrs[aPos(originPos)];
            Node* targetNodePtr = mNodePtrs[aPos(targetPos)];
            
            if ( originNodePtr && targetNodePtr )
            {
                // Wenn eines der beiden Felder untergangen ist,
                // verbinden wir sie nicht.
                if ( TILETYPE_LOST != originNodePtr->getTileType() &&
                     TILETYPE_LOST != targetNodePtr->getTileType() )
                {
#ifdef DEBUG
                    std::ostringstream out;
                    out << "(DD) Graph::initNeighbors "
                        << std::hex << this << std::dec
                        << " Connect " << originPos
                        << " with "    << targetPos
                        << " in dir "  << dir
                        << std::endl;
                    std::clog << out.str();
#endif
                    int distance = 1;
                    
                    /*
                     * TODO: Erstmal auskommentiert. Wer weiß, ob das was bringt.
                    // Der Abstand zwischen zwei benachbarten Knoten richtet
                    // sich nach dem Typ des Zielfeldes. Es soll vermieden
                    // werden, dass man ueber ueberfluetete Felder und
                    // lieber "aussen rum" laeuft.
                    if ( TILETYPE_FLOODED == targetNodePtr->getTileType() )
                    {
                        distance = 4;
                    }
                    */
                    
                    // Verbinde Knoten mit berechnetem Abstand.
                    if ( originNodePtr->setNeighborAndDistance(
                            dir, targetNodePtr, distance ) )
                    {
                        retVal = true;
                    }
                }
                else
                {
                    // Es ist okay, wenn eines der Felder ueberflutet ist.
                    retVal = true;
                }
            }
            else
            {
                std::ostringstream out;
                out << "(EE) Graph::initNeighbors "
                    << std::hex << this << std::dec
                    << "Origin "
                    << std::hex << originNodePtr << std::dec
                    << "or target "
                    << std::hex << originNodePtr << std::dec
                    << " is 0."
                    << std::endl;
                std::cerr << out.str();
            }
        }
        else
        {
            // Der Zielknoten ist nicht valide. Das ist okay, weil wir
            // vom Ursprungsknoten in alle vier Richtungen schauen und
            // dabei auch ausserhalb des Spielbretts landen.
            retVal = true;
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Graph::initNeighbors "
            << std::hex << this << std::dec
            << " Position " << originPos
            << " is not valid for size" << mSize
            << "."
            << std::endl;
        std::cerr << out.str();
    }
    
    return retVal;
}

// Speichert den Graph als Datei im dot-Format.
bool Graph::saveGraphviz( const std::string& filename ) const
{
    static const std::string shortestPathColor = "orange";
    
    bool retVal = false;

    if ( !filename.empty() )
    {
        std::ofstream outFile;

        outFile.open( filename.c_str(), std::ios::out );
        
        const Node* endNode = 0;

        if ( outFile.good() )
        {
            // in the first lines we store width and height
            outFile << "digraph G {" << std::endl;
            outFile << "  overlap=scalexy" << std::endl;

            for ( unsigned int jj = 1; jj <= getHeight(); jj++ )
            {
                for ( unsigned int ii = 1; ii <= getWidth(); ii++ )
                {
                    const Node* node = mNodePtrs[aPos(ii,jj)];
                    
                    if ( 0 != node )
                    {
                        // Verlorene Felder nicht ausgeben.
                        if ( TILETYPE_LOST != node->getTileType() )
                        {
                            std::string color = "blue";

                            if ( TILETYPE_DRY == node->getTileType() )
                                color = "brown";
                            if ( TILETYPE_FLOODED == node->getTileType() )
                                color = "cyan";
                            
                            // print single node first
                            const bool isStartOrEnd = node->isStartNode() ||
                                                      node->isEndNode();

                            // save end node for later
                            if ( node->isEndNode() )
                            {
                                endNode = node;
                            }

                            std::string tempColor = color;
                            if ( isStartOrEnd )
                            {
                                color = shortestPathColor;
                            }
                            saveGraphvizNode( outFile, ii, jj, node->getDistanceFromStart(),
                                              color, isStartOrEnd );
                            color = tempColor;
                            
                            for ( int kk = 0; kk < DIRECTION_MAX; kk++ )
                            {
                                Node *neighbor = node->getNeighbor( (Direction)kk );
                                
                                if ( 0 != neighbor )
                                {
                                    tempColor = color;
                                    // if this is the shortes path mark it as shortestPathColor
                                    if ( EDGE_STATE_SHORTEST == node->getEdgeState( (Direction)kk ) )
                                    {
                                        color = shortestPathColor;
                                    }
                                    
                                    // get position of neighbor node
                                    const Position pos = neighbor->getPosition();
                                    saveGraphvizEdge( outFile, ii, jj, pos.x(), pos.y(),
                                                      node->getDistance( (Direction)kk ), color );
                                    color = tempColor;
                                }
                            }
                        }
                    }
                    else
                    {
                        std::ostringstream out;
                        out << "(EE) Graph::saveGraphviz "
                            << std::hex << this << std::dec
                            << " Node at position " << Position(ii,jj)
                            << " is 0."
                            << std::endl;
                        std::cerr << out.str();
                        return retVal;
                    }
                }
            }

            // write shortest path separately
            // We must go from end to start to get the shortest path.
            // const Node *lastNode = 0;
            while ( 0 != endNode )
            {
                const Position pos = endNode->getPosition();

                // mark start node
                if ( endNode->isStartNode() )
                {
                    outFile << "  S [ label=\"\",shape=plaintext ]"
                            << std::endl;
                    outFile << "  S ->"
                            << "  \"" << pos.x() << "_" << pos.y() << "\" "
                            << "[ color="
                            << shortestPathColor.c_str()
                            << " ]"
                            << std::endl;
                }

                // mark end node
                if ( endNode->isEndNode() )
                {
                    outFile << "  E [ label=\"\",shape=plaintext ]"
                            << std::endl;
                    outFile << "  \"" << pos.x() << "_" << pos.y() << "\" "
                            << " -> E"
                            << "[ color="
                            << shortestPathColor.c_str()
                            << " ]"
                            << std::endl;
                }

                // only reprint the nodes between start and end
                if ( !endNode->isStartNode() && !endNode->isEndNode() )
                {
                    saveGraphvizNode( outFile, pos.x(), pos.y(),
                                      endNode->getDistanceFromStart(),
                                      shortestPathColor, true );
                }
                // lastNode = endNode;
                endNode = endNode->getShortestPathPredecessor();
            }

            outFile << "}" << std::endl;
            outFile.close();

            retVal = true;
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Graph::saveGraphviz "
                << std::hex << this << std::dec
                << " File "
                << filename
                << " could not be opened for writing."
                << std::endl;
            std::cerr << out.str();
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Graph::saveGraphviz "
            << std::hex << this << std::dec
            << " Filename is empty."
            << std::endl;
        std::cerr << out.str();
    }

    return retVal;
}

// Speichert einzelnen Knoten im dot-Format.
void Graph::saveGraphvizNode( std::ofstream& outFile,
                              const unsigned int x, const unsigned int y,
                              const int dist,
                              const std::string& color,
                              const bool isEndNode ) const
{
    if ( outFile.good() )
    {
        outFile << "  \"" << x << "_" << y << "\""
                << " [ "
                << " label=\"(" << x << "," << y << ") " << dist << "\","
                << "color=" << color.c_str() << ",";
        
        // fill end node with color to see it better
        if ( !isEndNode )
        {
            outFile << "fontcolor=" << color.c_str();
        }
        else
        {
            outFile << "fontcolor=white,style=filled";
        }
                
        outFile << " ]"
                << std::endl;
    }
}

// Speichert einzelne Kante im dot-Format.
void Graph::saveGraphvizEdge( std::ofstream& outFile,
                              const unsigned int x1, const unsigned int y1,
                              const unsigned int x2, const unsigned int y2,
                              const int dist,
                              const std::string& color ) const
{
    if ( outFile.good() )
    {
        outFile << "  \"" << x1 << "_" << y1 << "\" "
                << "->"
                << "  \"" << x2 << "_" << y2 << "\" "
                << "[ "
                << "label=\"" << dist << "\","
                << "color=" << color.c_str() << ","
                << "fontcolor=" << color.c_str() << ","
                << "fontsize=10"
                << " ]"
                << std::endl;
    }
}
