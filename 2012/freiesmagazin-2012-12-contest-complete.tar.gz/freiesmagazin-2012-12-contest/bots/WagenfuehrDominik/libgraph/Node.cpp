/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "Node.hh"

#include <iostream>
#include <sstream>

#define MAX(a,b) ( ( (a)>(b) ) ? (a) : (b) )

// Standard-Konstruktor.
Node::Node( const Position& pos, const TileType type )
  : mPosition(pos), mTileType(type),
    mStartNode(false), mEndNode(false),
    mDistanceFromStart(0), mShortestPathPredecessorPtr(0)
{
}

// Destruktor.
Node::~Node()
{
    // do not destruct anything, because we only have pointers
    // to real existing objects
    mShortestPathPredecessorPtr = 0;
}

// Setzt den Nachbar-Knoten in eine bestimmte Richtung.
bool Node::setNeighborAndDistance( const Direction dir,
                                   Node* neighborPtr,
                                   const int distance )
{
#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) Node::setNeighborAndDistance "
        << std::hex << this << std::dec
        << " neighbor: "
        << std::hex << neighborPtr << std::dec
        << " dir: "      << dir
        << " dist: "     << distance
        << std::endl;
    std::clog << out.str();
#endif

    bool retVal = false;

    if ( 0 <= dir && dir < DIRECTION_MAX )
    {
        // Setze Werte fuer eine bestimmte Kante.
        mEdges[dir].setNeighborAndDistance( neighborPtr, distance );
        retVal = true;
    }
    return retVal;    
}

// Gibt den Nachbar in eine bestimmte Richtung zurueck.
Node* Node::getNeighbor( const Direction dir ) const
{
    Node *neighborPtr = 0;

    if ( 0 <= dir && dir < DIRECTION_MAX )
    {
        neighborPtr = mEdges[dir].getNeighbor();
    }

    return neighborPtr;    
}

// Gibt den Abstand zum Nachbarn in eine bestimmte Richtung zurueck.
int Node::getDistance( const Direction dir ) const
{
    unsigned int distance = 0;

    if ( 0 <= dir && dir < DIRECTION_MAX )
    {
        distance = mEdges[dir].getDistance();
    }

    return distance;    
}

// Prueft, ob ein Knoten einen Nachbarn hat.
Direction Node::hasNeighbor( const Node* nodePtr ) const
{
    Direction dir = DIRECTION_NONE;

    if ( nodePtr )
    {
        for ( int ii = 0; ii < DIRECTION_MAX; ii++ )
        {
            if ( nodePtr == mEdges[ii].getNeighbor() )
            {
                dir = (Direction)ii;
                break;
            }
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Node::hasNeighbor "
            << std::hex << this << std::dec
            << " Node is 0!"
            << std::endl;
        std::cerr << out.str();
    }

    return dir;
}

// Setzt alle dynamisch berechneten Werte zurueck.
void Node::resetAlgorithmData()
{
    mStartNode = false;
    mEndNode = false;
    mDistanceFromStart = 0;
    mShortestPathPredecessorPtr = 0;
    
    for ( int ii = 0; ii < DIRECTION_MAX; ii++ )
    {
        // Abstand und Nachbar bleiben erhalten.
        // Nur der Kantenstatus wird zurueckgesetzt.
        mEdges[ii].setState( EDGE_STATE_NONE );
    }
}

// Setzt den Kantenstatus in eine bestimmte Richtung.
bool Node::setEdgeState( const Direction dir,
                         const EdgeState state )
{
    bool retVal = false;

    if ( 0 <= dir && dir < DIRECTION_MAX )
    {
#ifdef DEBUG
        std::ostringstream out;
        out << "(DD) Node::setEdgeState "
            << std::hex << this << std::dec
            << " dir: "   << dir
            << " state: " << mEdges[dir].getState()
            << " -> "     << state
            << " neighbor: "
            << std::hex << mEdges[dir].getNeighbor() << std::dec
            << std::endl;
        std::clog << out.str();
#endif 

        mEdges[dir].setState(state);
        
        // Wenn diese Kante die kuerzeste ist, dann setzen wir
        // diesen Knoten als Vorgaenger zum Nachbarknoten.
        if ( EDGE_STATE_SHORTEST == state )
        {
            Node *neighborPtr = mEdges[dir].getNeighbor();
            if ( neighborPtr )
            {
                if ( neighborPtr->setShortestPathPredecessor(this) )
                {
                    retVal = true;
                }
                else
                {
                    std::ostringstream out;
                    out << "(EE) Node::setEdgeState "
                        << std::hex << this << std::dec
                        << " Predecessor for neighbor "
                        << std::hex << neighborPtr << std::dec
                        << " could not be set."
                        << std::endl;
                    std::cerr << out.str();
                }
            }
            else
            {
                std::ostringstream out;
                out << "(EE) Node::setEdgeState "
                    << std::hex << this << std::dec
                    << " Neighbor node is 0!"
                    << std::endl;
                std::cerr << out.str();
            }
        }
        else
        {
            // Wenn es nicht der kuerzeste Weg ist, ist das auch okay.
            retVal = true;
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Node::setEdgeState "
            << std::hex << this << std::dec
            << " Direction " << dir
            << " is invalid!"
            << std::endl;
        std::cerr << out.str();
    }
    
    return retVal;
}

// Gibt den Kantenstatus in eine bestimmte Richtung zurueck.
EdgeState Node::getEdgeState( const Direction dir ) const
{
    EdgeState state = EDGE_STATE_NONE;

    if ( 0 <= dir && dir < DIRECTION_MAX )
    {
        state = mEdges[dir].getState();
    }

    return state; 
}

// Setzt den Vorgaengerknoten im kuerzesten Pfad zum Startknoten.
bool Node::setShortestPathPredecessor( Node* nodePtr )
{
    if ( !nodePtr )
    {
        std::ostringstream out;
        out << "(EE) Node::setShortestPathPredecessor "
            << std::hex << this << std::dec
            << " Predecessor node is 0!"
            << std::endl;
        std::cerr << out.str();
    }
    mShortestPathPredecessorPtr = nodePtr;
    
    return ( 0 != mShortestPathPredecessorPtr );
}

