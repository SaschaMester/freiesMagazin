/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef NEARESTFLOODALGORITHM_HH
#define NEARESTFLOODALGORITHM_HH

#include "NodePointerDeque.hh"

// Vorwartsdeklarationen
class Graph;
class Node;
class Position;

/// Algorithmus zum Suchen des naechstgelegenen Flut-Feldes.
/**
 * Der Algorithmus sucht in einem vom Graph von der Startposition aus
 * das naechstgelegene ueberfluetete Feld. Als Annahme gilt, dass zwei
 * benachbarte Felder genau ein Schritt voneinander entfernt liegen.
 */
class NearestFloodAlgorithm
{
  public:
    /// Konstruktor.
    /**
     * @param graph Der Grapg, auf dem operiert wird.
     * @param startPos Die Start-Position im Graph.
     */
    NearestFloodAlgorithm( const Graph& graph,
                           const Position& startPos );
  
    /// Suche des naechstgelegenes Flut-Feldes.
    /**
     * @param floodPos Position des ueberflueteten Feldes
     * @param distance Abstand zum naechstgelegenen Flutfeld
     * @return true, falls ein Flutfeld gefunden wurde, sonst false
    */
    bool search( Position& floodPos, int& distance );

  private:
    /// Rueckgabewert bei Suchergebnissen
    enum NodeSearchResult
    {
        RESULT_ERROR,       // Es kam irgendwo zu einem Fehler
        RESULT_FOUND,       // Element gefunden
        RESULT_NOT_FOUND    // Kein Element gefunden.
    };

    /// Suche naechstgelegenen Flutknoten in den Nachbarn eines Knotens.
    NodeSearchResult searchInNeighbors( const Node* nodePtr );
    
  private:
    
    /// Liste der Knoten, die bei einem Durchlauf noch durchsucht werden muessen.
    NodePointerDeque mToVisitNodesPtr;
    
    /// Startknoten fuer die Suche.
    Node* mStartNodePtr;
};

#endif // NEARESTFLOODALGORITHM_HH
