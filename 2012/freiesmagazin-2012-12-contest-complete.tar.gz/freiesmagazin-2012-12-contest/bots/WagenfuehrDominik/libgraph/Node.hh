/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef NODE_HH
#define NODE_HH

#include "Direction.hh"
#include "Edge.hh"
#include "Position.hh"
#include "TileType.hh"

/// Knoten im Graph.
/**
 * Der Knoten haelt eine Position und ist ueber Kanten mit seinen Nachbarn
 * verbunden. Der Dijsktra-Algorithmus setzt bei einer Berechnung den
 * Abstand zum Startknoten und berechnet so den kuerzesten Weg.
 */
class Node 
{
  public:
    /// Standard-Konstruktor.
    /**
     * Die Ziele der Kanten (Nachbarn) werden mit 0 initialisiert,
     * sprich der Knoten hat am Anfang keine Nachbarn.
     * Der Abstand zum Startknoten wird mit 0 initialisiert.
     * @param pos Position auf dem Original-Spielbrett.
     * @param type Feldtyp im Spielbrett.
     */
    Node( const Position& pos, const TileType type );
    
    /// Destruktor.
    ~Node();
    
    /// Gibt die Position des Knotens auf dem Original-Spielbrett zurueck.
    const Position& getPosition() const;

    /// Gibt den Feldtyp zurueck.
    TileType getTileType() const;
    
    /// Setzt den Nachbar-Knoten in eine bestimmte Richtung.
    /**
     * @param dir Richtung, wo der Nachbarknoten liegt.
     * @param neighborPtr Zeiger auf den Nachbarknoten.
     * @param distance Abstand zum Nachbarknoten.
     * @return true, wenn alles okay ist, sonst false.
     */
    bool setNeighborAndDistance( const Direction dir,
                                 Node* neighborPtr,
                                 const int distance );

    /// Gibt den Nachbar in eine bestimmte Richtung zurueck.
    /**
     * @param dir Richtung, dessen Nachbar man haben will.
     * @return Zeiger auf den Nachbar oder 0, falls in diese Richtung
     * kein Nachbar existiert.
     */
    Node* getNeighbor( const Direction dir ) const;

    /// Gibt den Abstand zum Nachbarn in eine bestimmte Richtung zurueck.
    /**
     * @param dir Richtung, dessen Nachbar man haben will.
     * @return Abstand zum Nachbarknoten oder 0, falls in diese Richtung
     * kein Nachbar existiert.
     */
    int getDistance( const Direction view ) const;

    /// Prueft, ob ein Knoten einen Nachbarn hat.
    /**
     * @param nodePtr Zeiger auf den Nachbar-Knoten, den man suchen will.
     * @return Richtung, wo dieser Nachbar liegt, oder NONE, falls die 
     * Knoten nicht benachbart sind.
     */
    Direction hasNeighbor( const Node* nodePtr ) const;

  public:
    // Ab hier folgen die Werte, die sich mit dem Dijsktra-Algorithmus aendern.
    
    /// Setzt alle dynamisch berechneten Werte zurueck.
    /**
     * Darunter faellt die Eigenschaft, ob es ein Start- oder Zielknoten
     * ist, der Abstand zum Start, der Kanten-Status, und der kuerzeste
     * Pfad. Diese Werte benoetigt man alle fuer eine Berechnung im
     * Dijsktra-Algorithmus.
     */
    void resetAlgorithmData();

    /// Markiert diesen Knoten als Start-Knoten.
    void setStartNode();
    
    /// Ist dieser Knoten der Start-Knoten?
    bool isStartNode() const;

    /// Markiert diesen Knoten als End-Knoten.
    void setEndNode();
    
    /// Ist dieser Knoten der End-Knoten.
    bool isEndNode() const;

    /// Setzt den Abstand des Knotens zum Startknoten.
    void setDistanceFromStart( const int dist );
    
    /// Gibt den Abstand zum Startknoten zurueck.
    int getDistanceFromStart() const;

    /// Setzt den Kantenstatus in eine bestimmte Richtung.
    /**
     * @param dir Richtung der Kante.
     * @param state neuer Kantenstatus
     * @return true, wenn alles okay ist, sonst false
     */
    bool setEdgeState( const Direction dir, const EdgeState state );

    /// Gibt den Kantenstatus in eine bestimmte Richtung zurueck.
    /**
     * @param dir Richtung, dessen Kantenstatus man haben will.
     * @return Kantenstatus in diese Richtung, oder NONE, falls in dieser
     * Richtung kein Nachbar existiert.
     */ 
    EdgeState getEdgeState( const Direction dir ) const;

    /// Setzt den Vorgaengerknoten im kuerzesten Pfad zum Startknoten.
    /**
     * @param nodePtr Zeiger auf den Vorgaengerknoten, darf nicht 0 sein!
     * @return true, wenn der Vorgaenger gesetzt werden konnte, sonst false.
     */
    bool setShortestPathPredecessor( Node* nodePtr );

    /// Gibt den Vorgaengerknoten im kuerzesten Pfad zum Startknoten zurueck.
    Node* getShortestPathPredecessor() const;
    
    /// Prueft, ob der Knoten der Vorgaengerknoten im kuerzesten Pfad ist.
    bool isShortestPathPredecessor( const Node* nodePtr ) const;

  private:
  
    /// Kanten, die zu den Nachbarknoten in alle Richtungen fuehren.
    Edge mEdges[DIRECTION_MAX];

    /// Position des Knotens auf dem Original-Spielbrett.
    Position mPosition;

    /// Typ des Feldes, welches der Knoten referenziert.
    TileType mTileType;

    /// Start-Knoten im Graph, von dem eine Suche aus startet.
    bool mStartNode;

    /// End-Knoten im Graph, zu dem die Suche finden soll.
    bool mEndNode;

    /// Abstand dieses Knotens vom Start-Knoten aus.
    /**
     * Initialisiert wird der Wert 0. Der Start-Knoten selbst hat
     * einen Abstand 0.
     */
    int mDistanceFromStart;

    /// Zeiger auf den Vorgaenger-Knoten nach Berechnung des kuerzesten Weges.
    /**
     * Ueber diesen Zeiger kann man sich von einem Knoten bis zum Start
     * vorhangeln und so den Pfad beschreiben.
     */
    Node* mShortestPathPredecessorPtr;
};

// Gibt die Position des Knotens auf dem Original-Spielbrett zurueck.
inline
const Position& Node::getPosition() const
{
    return mPosition;
}

// Gibt den Feldtyp zurueck.
inline
TileType Node::getTileType() const
{
    return mTileType;
}

// Markiert diesen Knoten als Start-Knoten.
inline
void Node::setStartNode()
{
    mStartNode = true;
}

// Ist dieser Knoten der Start-Knoten?
inline
bool Node::isStartNode() const
{
    return mStartNode;
}

// Markiert diesen Knoten als End-Knoten.
inline
void Node::setEndNode()
{
    mEndNode = true;
}

// Ist dieser Knoten der End-Knoten.
inline
bool Node::isEndNode() const
{
    return mEndNode;
}

// Setzt den Abstand des Knotens zum Startknoten.
inline
void Node::setDistanceFromStart( const int dist )
{
    mDistanceFromStart = dist;
}

// Gibt den Abstand zum Startknoten zurueck.
inline
int Node::getDistanceFromStart() const
{
    return mDistanceFromStart;
}

// Gibt den Vorgaengerknoten im kuerzesten Pfad zum Startknoten zurueck.
inline
Node* Node::getShortestPathPredecessor() const
{
    return mShortestPathPredecessorPtr;
}

// Prueft, ob der Knoten der Vorgaengerknoten im kuerzesten Pfad ist.
inline
bool Node::isShortestPathPredecessor( const Node* nodePtr ) const
{
    return ( nodePtr == mShortestPathPredecessorPtr );
}

#endif // NODE_HH
