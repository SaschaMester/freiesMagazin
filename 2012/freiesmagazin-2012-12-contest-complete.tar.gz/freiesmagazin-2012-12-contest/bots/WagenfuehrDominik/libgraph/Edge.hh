/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef EDGE_HH
#define EDGE_HH

#include "EdgeState.hh"

// Vorwaertsdeklaration.
class Node;

/// Kante zwischen zwei Knoten.
/**
 * Zusaetzlich wird gespeichert, um was fuer eine Art von Kante es sich
 * handelt. Die Kante ist entweder normal oder die kuerzeste bei einer
 * Berechnung des kuerzesten Weges.
 */
class Edge
{
  public:
    /// Standard-Konstruktor.
    Edge();
    
    /// Destruktor.
    ~Edge();

    /// Setzt neuen Nachbarknoten und Abstand.
    /**
     * Es findet keine Pruefung statt, ob er Knoten nicht 0 ist.
     * @param neighborPtr Zeiger auf den Nachbarknoten.
     * @param distance Abstand zum Nachbarknoten.
     */
    void setNeighborAndDistance( Node* neighborPtr,
                                 const int distance );

    /// Gibt Nachbarknoten zurueck.
    /**
     * @return Zeiger auf den Nachbarknoten oder 0, falls keiner existiert.
     */
    Node* getNeighbor() const;
    
    /// Gibt Abstand zum Nachbarknoten zurueck.
    /**
     * @return Abstand zum Nachbarknoten oder 0, falls keiner existiert.
     */
    int getDistance() const;

    /// Setzt den neuen Kantenstatus.
    void setState( const EdgeState state );

    /// Gibt Kantenstatus zurueck.
    EdgeState getState() const;
    
protected:
    /// Zeiger auf den Nachbarknoten.
    Node* mNeighborPtr;
    
    /// Abstand zum Nachbarknoten.
    int mDistance;

    /// Kantenstatus im Dijkstra-Algorithmus.
    EdgeState mState;
};

// Setzt neuen Nachbarknoten und Abstand.
inline
void Edge::setNeighborAndDistance( Node* neighborPtr, const int distance )
{
    mNeighborPtr = neighborPtr;
    mDistance = distance;
}

// Gibt Nachbarknoten zurueck.
inline
Node* Edge::getNeighbor() const
{
    return mNeighborPtr;
}

// Gibt Abstand zum Nachbarknoten zurueck.
inline
int Edge::getDistance() const
{
    return mDistance;
}

// Setzt den neuen Kantenstatus.
inline
void Edge::setState( const EdgeState state )
{
    mState = state;
}

// Setzt den neuen Kantenstatus.
inline
EdgeState Edge::getState() const
{
    return mState;
}

#endif // EDGE_HH
