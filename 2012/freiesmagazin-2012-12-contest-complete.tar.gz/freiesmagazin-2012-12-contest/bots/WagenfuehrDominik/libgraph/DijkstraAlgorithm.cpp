/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "DijkstraAlgorithm.hh"

#include "Graph.hh"
#include "Node.hh"
#include "Position.hh"

#include <iostream>
#include <sstream>

// Konstruktor.
DijkstraAlgorithm::DijkstraAlgorithm( const Graph& graph,
                                      const Position& startPos,
                                      const Position& endPos )
  : mEndPosReachable(false), mStartNodePtr(0), mEndNodePtr(0)
{
    if ( init( graph, startPos, endPos ) )
    {
        mEndPosReachable = searchShortestPath();
    }
    else
    {
        // Es kam zu einem Fehler bei der Initialisierung.
        mEndPosReachable = false;
    }
}

// Destruktor.
DijkstraAlgorithm::~DijkstraAlgorithm()
{
    // Zeiger nicht loeschen, da aussen referenziert.
    mStartNodePtr = 0;
    mEndNodePtr = 0;
}

// Initialisiert den Algorithmus mit Graph und Positionen.
bool DijkstraAlgorithm::init( const Graph& graph,
                              const Position& startPos,
                              const Position& endPos )
{
    bool retVal = false;
    
    if ( graph.isValid() )
    {
        mStartNodePtr = graph[startPos];
        mEndNodePtr = graph[endPos];

        if ( mStartNodePtr && mEndNodePtr )
        {
            // Markiere Start und Endknoten entsprechend
            // und fuege den Startknoten in die Liste der zu besuchenden
            // Knoten hinzu.
            mStartNodePtr->setStartNode();
            mEndNodePtr->setEndNode();
            mUnknownNodeNeighborPtrs.push_back( mStartNodePtr );

            // Der Abstand des Start-Knotens zu sich selbst ist 0.
            mStartNodePtr->setDistanceFromStart( 0 );
            retVal = true;
        }
        else
        {
            std::ostringstream out;
            out << "(EE) DijkstraAlgorithm::init "
                << std::hex << this << std::dec
                << " Start pos " << startPos
                << " or end pos " << endPos
                << " not found in graph."
                << std::endl;
            std::cerr << out.str();
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) DijkstraAlgorithm::init "
            << std::hex << this << std::dec
            << " Graph is not valid."
            << std::endl;
        std::cerr << out.str();
    }
    
    return retVal;
}

// Sucht den kuerzesten Weg vom Start zum Ziel.
bool DijkstraAlgorithm::searchShortestPath()
{
    bool retVal = false;

    // iterate over all elements in list
    while ( !mUnknownNodeNeighborPtrs.empty() )
    {
        Node* nodePtr = searchAndRemoveNearestNodeFromStart();

        if ( nodePtr )
        {
            // Wenn dies der Endknoten ist, ist die Suche auf alle
            // Faelle erfolgreich gewesen. Dennoch suchen wir weiter, weil
            // es ja vielleicht einen kuerzeren Weg zum Ziel geben koennte.
            if ( nodePtr->isEndNode() )
            {
                retVal = true;
            }

            // Knoten als besucht markieren.
            mKnownNodeNeighborPtrs.push_back( nodePtr );

            // Jetzt alle Nachbarknoten pruefen.
            if ( !checkAndAddNeighbors( nodePtr ) )
            {
                // Es kam zu einem Fehler.
                retVal = false;
                break;
            }
        }
        else
        {
            // Liste ist nicht leer, aber dennoch kam ein Nullzeiger zurueck.
            std::ostringstream out;
            out << "(EE) DijkstraAlgorithm::searchShortestPath "
                << std::hex << this << std::dec
                << " Node pointer is 0."
                << std::endl;
            std::cerr << out.str();
            retVal = false;
            break;
        }
    }

    return retVal;
}

// Sucht in der Liste der noch nicht besuchten Knoten nach dem zum Start naechstgelegenem.
Node* DijkstraAlgorithm::searchAndRemoveNearestNodeFromStart()
{
    NodePointerDeque::iterator it;
    NodePointerDeque::iterator nearestIt;
    Node *nearestNodePtr = 0;

    bool first = true;

    // Wir iterieren ueber die ganze Liste und suchen den vom Start aus
    // naechstegelegenen Knoten.
    for ( it = mUnknownNodeNeighborPtrs.begin(); it < mUnknownNodeNeighborPtrs.end(); it++ )
    {
        // Das erste Element in der Liste gilt als Referenz fuer den
        // naechstgelegenen Knoten. Ansonsten pruefen wir den echten Abstand
        // zum Start.
        if ( first ||
             (*it)->getDistanceFromStart() < (*nearestIt)->getDistanceFromStart() )
        {
            nearestIt = it;
            first = false;
        }
    }
    
    // Wenn wir ein Element gefunden haben, das am naechsten am Startknoten
    // liegt, liefern wir das zurueck und entfernen es aus der Liste, damit
    // wir es nicht noch einmal besuchen.
    if ( !first )
    {
        nearestNodePtr = (*nearestIt);
        mUnknownNodeNeighborPtrs.erase( nearestIt );
    }
    
    return nearestNodePtr;
}

// Prueft die Existenz der Nachbarn eines Knotens und fuegt sie in Liste hinzu.
bool DijkstraAlgorithm::checkAndAddNeighbors( Node* nodePtr )
{
    bool retVal = false;
    
    if ( nodePtr )
    {
        // Wir nehmen an, dass alles okay ist.
        retVal = true;

        // Wir kontrollieren alle Nachbarknoten.
        for ( int ii = 0; ii < DIRECTION_MAX; ii++ )
        {
            const Direction dir = (Direction)ii;
            Node *neighborPtr = nodePtr->getNeighbor( dir );

            if ( neighborPtr )
            {
                // Pruefe, in welche Liste der Nachbarknoten bereits enthalten
                // ist.
                const bool neighborInKnownList =
                               find( mKnownNodeNeighborPtrs, neighborPtr );
                const bool neighborInUnknownList = 
                               find( mUnknownNodeNeighborPtrs, neighborPtr );

                if ( !neighborInKnownList && !neighborInUnknownList )
                {
                    // Der Nachbarknoten ist in keiner Liste, also fuegen
                    // wir ihn hinzu und markieren die Kante entsprechend.
                    if ( !addNeighborAndMarkEdge( nodePtr, neighborPtr, dir ) )
                    {
                        retVal = false;
                        break;
                    }
                }
                else if ( neighborInUnknownList )
                {
                    // Der Nachbarknoten ist bekannt, aber noch nicht besucht.
                    // Daher markieren wir seine Kanten und pruefen die
                    // Entfernung.
                    if ( !markEdgesToNeighbor( nodePtr, neighborPtr, dir ) )
                    {
                        // There was an error so break here.
                        retVal = false;
                        break;
                    }
                }
                else
                {
                    // Der Nachbar ist in der Liste der besuchten Knoten.
                    // Damit kann die Kante zu diesem Nachbarknoten
                    // nicht mehr die kuerzeste sein.
                    if ( !nodePtr->setEdgeState( dir, EDGE_STATE_NORMAL ) )
                    {
                        retVal = false;
                        break;
                    }
                }
            }
            // else: Der Nachbar ist 0, existiert also nicht, was vollkommen
            // okay ist.
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) DijkstraAlgorithm::checkAndAddNeighbors "
            << std::hex << this << std::dec
            << " Node pointer is 0."
            << std::endl;
        std::cerr << out.str();
    }
    
    return retVal;
}

// Fuegt einen Nachbarknoten in die Liste der noch nicht besuchten Knoten hinzu.
bool DijkstraAlgorithm::addNeighborAndMarkEdge( Node* nodePtr,
                                                Node *neighborPtr,
                                                const Direction dir )
{
    bool retVal = false;
    
    if ( nodePtr && neighborPtr )
    {
        // Nachbar in die Liste der noch nicht besuchten Knoten hinzufuegen.
        mUnknownNodeNeighborPtrs.push_back( neighborPtr );

        // Die Kante vom Knoten zum Nachbar wird als derzeit kuerzeste
        // markiert.
        if ( nodePtr->setEdgeState( dir, EDGE_STATE_SHORTEST ) )
        {
            // Jetzt den neuen Abstand bestimmen, der sich ja ggf. verringert
            // hat.
            neighborPtr->setDistanceFromStart( nodePtr->getDistanceFromStart() +
                                               nodePtr->getDistance( dir ) );
            retVal = true;
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) DijkstraAlgorithm::addNeighborAndMarkEdge "
            << std::hex << this << std::dec
            << " Node pointer "
            << std::hex << nodePtr << std::dec
            << " or neighbor node pointer "
            << std::hex << neighborPtr << std::dec
            << " is 0."
            << std::endl;
        std::cerr << out.str();
    }
    
    return retVal;
}

// Markiert alle Kanten eines Nachbarn entsprechend der Entfernung.
bool DijkstraAlgorithm::markEdgesToNeighbor( Node* nodePtr,
                                             Node *neighborPtr,
                                             const Direction dir )
{
    bool retVal = false;
    
    if ( nodePtr && neighborPtr )
    {
        // Berechne neuen Abstand vom Start zum Nachbarknoten.
        const int newDist = nodePtr->getDistanceFromStart() +
                            nodePtr->getDistance( dir );

        if ( newDist < neighborPtr->getDistanceFromStart() )
        {
            // Der neue Abstand ist geringer als der bisherige.
            // Daher muessen wir die bisherige kuerzeste Kante als normal
            // kennzeichnen und die neue kuerzeste setzen.
            if ( setShortestPathPredecessorNeighbor( nodePtr, dir ) )
            {
                // Neuen Abstand des Nachbarknoten setzen.
                neighborPtr->setDistanceFromStart( newDist );
                retVal = true;
            }
        }
        else
        {
            // Der Abstand ist groesser, damit ist diese Kante nicht
            // die kuerzeste und wird entsprechend markiert.
            if ( nodePtr->setEdgeState( dir, EDGE_STATE_NORMAL ) )
            {
                retVal = true;
            }
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) DijkstraAlgorithm::markEdgesToNeighbor "
            << std::hex << this << std::dec
            << " Node pointer "
            << std::hex << nodePtr << std::dec
            << " or neighbor node pointer "
            << std::hex << neighborPtr << std::dec
            << " is 0."
            << std::endl;
        std::cerr << out.str();
    }
    
    return retVal;
}

// Setzt den Knoten als Vorgaenger im kuerzesten Pfad zum Startknoten.
bool DijkstraAlgorithm::setShortestPathPredecessorNeighbor( Node* nodePtr,
                                                            const Direction dir )
{
    bool retVal = false;
    
    if ( nodePtr )
    {
        // Nachbar in diese Richtung besorgen
        Node *neighborPtr = nodePtr->getNeighbor(dir);

#ifdef DEBUG
        {
            std::ostringstream out;
            out << "(DD) DijkstraAlgorithm::setShortestPathPredecessorNeighbor "
                << std::hex << this << std::dec
                << " dir: "   << dir
                << " neighbor: "
                << std::hex << neighborPtr << std::dec
                << std::endl;
            std::clog << out.str();
        }
#endif 
        
        if ( neighborPtr )
        {
            // Der Nachbar-Knoten existiert schon einmal.
            // Wir holen uns den aktuellen Vorgaengerknoten des Nachbarn.
            Node *neighborPredPtr = neighborPtr->getShortestPathPredecessor();
            if ( neighborPredPtr )
            {
                // Hole Richtung, in die der Vorgaengerknoten vom Nachbar aus liegt.
                const Direction dir2 = neighborPredPtr->hasNeighbor( neighborPtr );

                if ( DIRECTION_NONE != dir2 )
                {
                    // Markiere diese Kante wieder als normale Kante und nicht als
                    // Kuerzeste.
                    if ( !neighborPredPtr->setEdgeState( dir2, EDGE_STATE_NORMAL ) )
                    {
                        retVal = false;
                    }
                }
                else
                {
                    std::ostringstream out;
                    out << "(EE) DijkstraAlgorithm::setShortestPathPredecessorNeighbor "
                        << std::hex << this << std::dec
                        << " Predecessor node "
                        << std::hex << neighborPredPtr << std::dec
                        << " is not connected to neighbor node "
                        << std::hex << neighborPtr << std::dec
                        << "."
                        << std::endl;
                    std::cerr << out.str();
                    retVal = false;
                }
            }
            else
            {
                // Ansonsten existiert kein Vorgaenger. Das kann gut sein, wenn
                // der Nachbar noch nie besucht wurde.
                retVal = true;
            }
            
            if ( retVal )
            {
                retVal = false;

                // Jetzt den aktuellen Knoten als Vorgaenger des Nachbarn
                // im kuerzesten Pfad setzen und die Kante zum Nachbarn
                // entsprechend als kuerzeste markieren.
                if ( neighborPtr->setShortestPathPredecessor( nodePtr ) )
                {
                    if ( nodePtr->setEdgeState( dir, EDGE_STATE_SHORTEST ) )
                    {
                        retVal = true;
                    }
                }
            }
        }
        else
        {
            std::ostringstream out;
            out << "(EE) DijkstraAlgorithm::setShortestPathPredecessorNeighbor "
                << std::hex << this << std::dec
                << " Neighbor node for node pointer "
                << std::hex << nodePtr << std::dec
                << " in direction " << dir
                << " is 0."
                << std::endl;
            std::cerr << out.str();
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) DijkstraAlgorithm::setShortestPathPredecessorNeighbor "
            << std::hex << this << std::dec
            << " Node pointer is 0."
            << std::endl;
        std::cerr << out.str();
    }
    
    return retVal;
}

// Liefert den kuerzestens Weg vom Start zum Ziel.
bool DijkstraAlgorithm::getShortestPath( DirectionVector& path )
{
    bool retVal = false;

    path.clear();

    if ( mStartNodePtr && mEndNodePtr )
    {
        if ( mEndPosReachable )
        {
            // Das Ende ist erreichbar. Wir muessen uns vom Endknoten zum
            // Startknoten durchhangeln.
            // Achtung: Dadurch muessen wir den Pfad auch rueckwaerts
            // aufbauen.
            Node *nodePtr = mEndNodePtr;
            Node *prevNodePtr = 0;

            // Wir iterieren, bis wir keinen Vorgaenger mehr haben.
            while ( nodePtr )
            {
                prevNodePtr = nodePtr;
                nodePtr = nodePtr->getShortestPathPredecessor();

                if ( nodePtr )
                {
                    const Direction dir = nodePtr->hasNeighbor(prevNodePtr);
                    path.push_front( dir );
                    
                    // std::clog << " " << dir;
                }
            }

            // std::clog << " " << std::endl;

            // Wenn der letzte Knoten nicht dem Start entspricht, ist
            // irgendwas im Algorithmus schief gelaufen-
            if ( prevNodePtr == mStartNodePtr )
            {
                retVal = true;
            }
            else
            {
                std::ostringstream out;
                out << "(EE) DijkstraAlgorithm::getShortestPath "
                    << std::hex << this << std::dec
                    << " Last node "
                    << std::hex << prevNodePtr << std::dec
                    << " does not equal start node "
                    << std::hex << mStartNodePtr << std::dec
                    << std::endl;
                std::cerr << out.str();
            }
        }
        else
        {
            std::ostringstream out;
            out << "(EE) DijkstraAlgorithm::getShortestPath "
                << std::hex << this << std::dec
                << " No possible way found from start " << mStartNodePtr->getPosition()
                << " to end " << mEndNodePtr->getPosition()
                << std::endl;
            std::cerr << out.str();
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) DijkstraAlgorithm::getShortestPath "
            << std::hex << this << std::dec
            << " Start node pointer "
            << std::hex << mStartNodePtr << std::dec
            << " or end node pointer "
            << std::hex << mEndNodePtr << std::dec
            << " is 0."
            << std::endl;
        std::cerr << out.str();
    }
    
    return retVal;
}

// Suche in einer Knotenliste nach einem bestimmten Knoten.
bool DijkstraAlgorithm::find( const NodePointerDeque& list, const Node* nodePtr )
{
    NodePointerDeque::const_iterator it;
    bool found = false;

    for ( it = list.begin(); it < list.end(); it++ )
    {
        if ( (*it) == nodePtr )
        {
            found = true;
            break;
        }
    }
    return found;
}
