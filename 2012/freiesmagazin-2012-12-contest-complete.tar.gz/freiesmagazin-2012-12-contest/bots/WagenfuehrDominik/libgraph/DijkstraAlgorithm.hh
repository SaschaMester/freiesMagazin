/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef DIJKSTRAALGORITHM_HH
#define DIJKSTRAALGORITHM_HH

#include "Direction.hh"
#include "NodePointerDeque.hh"

// Vorwaertsdeklarationen
class Graph;
class Node;
class Position;

/// Klasse, um kuerzesten Weg in einem Graph zu finden.
/**
 * Fuer die Berechnung von Start zum Ziel wird der
 * Dijkstra-Algorithmus verwendet.
 */
class DijkstraAlgorithm
{
  public:
    /// Konstruktor.
    /**
     * Nach dem Initialisieren aller Werte wird automatisch nach dem kuerzestem
     * Weg vom Start zum Ziel gesucht.
     * @param graph Der assozierte Graph, in dem der Weg gesucht werden soll.
     * @param startPos Die Startposition fuer den Weg.
     * @param endPos Die Zielposition fuer den Weg.
     */
    DijkstraAlgorithm( const Graph& graph,
                       const Position& startPos,
                       const Position& endPos );

    /// Destruktor.
    ~DijkstraAlgorithm();

    /// Liefert den kuerzestens Weg vom Start zum Ziel.
    /**
     * @param path Vektor mit den verschiedenen Richtungen fuer die
     * Wegbeschreibung um vom Start zum Ziel zu kommen.
     * @return true, falls der Weg berechnet werden konnte, sonst false
     */
    bool getShortestPath( DirectionVector& path );

  private:
    /// Initialisiert den Algorithmus mit Graph und Positionen.
    /**
     * @param graph Der assozierte Graph, in dem der Weg gesucht werden soll.
     * @param startPos Die Startposition fuer den Weg.
     * @param endPos Die Zielposition fuer den Weg.
     * @return true, wenn die Initialisierung geklappt hat.
     */
    bool init( const Graph& graph,
               const Position& startPos,
               const Position& endPos );

    /// Sucht den kuerzesten Weg vom Start zum Ziel.
    /**
     * @return true, wenn der Weg gefunden wurde, sonst false
     */
    bool searchShortestPath();

    /// Sucht in der Liste der noch nicht besuchten Knoten nach dem zum Start naechstgelegenem.
    /**
     * Die Methode entfernt den naechstgelegene Knoten auch aus der Liste
     * @return Zeiger auf den Knoten oder 0, falls kein Knoten gefunden wurde.
     */
    Node* searchAndRemoveNearestNodeFromStart();
    
    /// Prueft die Existenz der Nachbarn eines Knotens und fuegt sie in Liste hinzu.
    /**
     * Die Methode prueft die Existenz aller Nachbarn und schaut, ob dieser
     * schon besucht wurde oder nicht. Entsprechend wird der Nachbarknoten
     * in die richtige Liste eingetragen und spaeter besucht oder ggf. auch
     * gleich der Abstand zum Startknoten geprueft.
     * @param nodePtr Zeiger auf den Knoten, dessen Nachbarn geprueft werden
     * sollen (darf nicht 0 sein).
     * @return bool, wenn alles okay ist, sonst false
     */
    bool checkAndAddNeighbors( Node* nodePtr );
    
    /// Fuegt einen Nachbarknoten in die Liste der noch nicht besuchten Knoten hinzu.
    /**
     * Daneben wird auch die Kante zwischen Knoten und Nachbarknoten markiert.
     * @param nodePtr Zeiger auf den Original-Knoten (darf nicht 0 sein).
     * @param neighborPtr Zeiger auf den Nachbarknoten (darf nicht 0 sein).
     * @param dir Richtung, wie man vom Original-Knoten zum Nachbar kommt
     * @return bool, wenn alles okay ist, sonst false
     */
    bool addNeighborAndMarkEdge( Node* nodePtr, Node *neighborPtr,
                                 const Direction dir );

    /// Markiert alle Kanten eines Nachbarn entsprechend der Entfernung.
    /**
     * @param nodePtr Zeiger auf den Original-Knoten (darf nicht 0 sein).
     * @param neighborPtr Zeiger auf den Nachbarknoten (darf nicht 0 sein).
     * @param dir Richtung, wie man vom Original-Knoten zum Nachbar kommt
     * @return bool, wenn alles okay ist, sonst false
     */
    bool markEdgesToNeighbor( Node* nodePtr, Node* neighborPtr,
                              const Direction dir );
    
    /// Setzt den Knoten als Vorgaenger im kuerzesten Pfad zum Startknoten.
    /**
     * Konkrekt bedeutet das, dass ein vorheriger Vorgaenger geloescht
     * und der Kantenstatus aktualisiert wird.
     * @param nodePtr Knoten, von dem die Berechnung ausgeht.
     * @param dir Richtung zum Nachbarn
     * @return true, wenn alles okay ist, sonst false
     */
    bool setShortestPathPredecessorNeighbor( Node* nodePtr, const Direction dir );

    /// Suche in einer Knotenliste nach einem bestimmten Knoten.
    /**
     * @param list Liste mit Zeigern auf Knoten
     * @param nodePtr Zeiger auf den suchenden Knoten
     * @return true, wenn der Knoten in der Liste vorkommt, sonst false
     */
    static bool find( const NodePointerDeque& list, const Node* nodePtr );

  private:    
    /// Liste der Knoten, deren Nachbarn man kennt.
    NodePointerDeque mKnownNodeNeighborPtrs;
    
    /// Liste der Knoten, deren Nachbarn noch nicht kennt.
    NodePointerDeque mUnknownNodeNeighborPtrs;

    /// Flag, ob die Endposition vom Start aus erreichbar ist.
    /**
     * Das Flag wird im Konstruktor nach dem Suchen des kuerzesten Pfades
     * entsprechend gesetzt.
     */
    bool mEndPosReachable;

    /// Zeiger auf den Start-Knoten.
    Node* mStartNodePtr;

    /// Zeiger auf den End-Knoten.
    Node* mEndNodePtr;
};

#endif // DIJKSTRAALGORITHM_HH
