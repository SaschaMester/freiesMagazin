/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef GAMEBOARDIF_HH
#define GAMEBOARDIF_HH

// Vorwaertsdeklarationen
class Position;

/// Interface fuer ein Spielbrett.
/**
 * Interface fuer den Aufbau des Graphen.
 * Die linke obere Ecke liegt bei (1,1).
 */
class GameboardIF
{
  public:
    /// Destructor.
    virtual ~GameboardIF() { }
    
    /// Gibt die Groesse des Spielbretts zurueck.
    virtual const Position& getSize() const = 0;

    /// Prueft, ob das Feld noch trocken ist.
    virtual bool isDry( const Position& pos ) const = 0;

    /// Prueft, ob das Feld ueberflutet wurde.
    virtual bool isFlooded( const Position& pos ) const = 0;

    /// Prueft, ob das Feld schon untergegangen ist.
    virtual bool isLost( const Position& pos ) const = 0;

    /// Prueft, ob die Position fuer das Spielbrett valide ist.
    /**
     * Valide bedeutet, dass die Position innerhalb der
     * Spielbrettgrenzen liegt.
     * @param pos Zu pruefende Position
     * @param noError Wenn false, wird bei fehlerhafter Position ein
     * Fehlermeldung auf ausgegeben. Wenn true, wird diese Meldung
     * unterdrueckt. (Standard: false).
     * @return true, wenn die Position valide fuer das Spielbrett ist.
     */
    virtual bool isValidPos( const Position& pos,
                             const bool noError = false ) const = 0;
};

#endif // GAMEBOARDIF_HH
