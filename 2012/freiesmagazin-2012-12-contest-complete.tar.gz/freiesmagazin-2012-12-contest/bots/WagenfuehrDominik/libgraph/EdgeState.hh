/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef EDGESTATE_HH
#define EDGESTATE_HH

#include <ostream>

/// Kantenstatus im Dijkstra-Algorithmus.
enum EdgeState
{
    // Status nicht definiert.
    EDGE_STATE_NONE,
    
    // Normale Kanten.
    EDGE_STATE_NORMAL,

    // Kuerzeste Kante, um zu dem Knoten zu kommen.
    EDGE_STATE_SHORTEST
};
    
/// Wandlungsroutine Enums -> String.
/**
 * @param type Enum
 * @return String
 */
char const * changeEnumToString( const EdgeState type );

/// Methode zur Ausgabe der Enums.
/**
 * @param stream Stream, indem geschrieben wird.
 * @param type Auszugebendes Enum
 * @return Ausgabestream.
 */
std::ostream& operator<<( std::ostream& stream, const EdgeState type );

#endif // EDGESTATE_HH
