/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "NearestFloodAlgorithm.hh"

#include "Graph.hh"
#include "Node.hh"
#include "Position.hh"

#include <iostream>
#include <sstream>

// Konstruktor.
NearestFloodAlgorithm::NearestFloodAlgorithm( const Graph& graph,
                                              const Position& startPos )
  : mStartNodePtr(0)
{
    // check if graph is okay
    if ( graph.isValid() )
    {
        mStartNodePtr = graph[startPos];

        if ( mStartNodePtr )
        {
            // Markiere Start-Knoten.
            mStartNodePtr->setStartNode();
        
            // Fuege Startknoten in Liste hinzu.
            mToVisitNodesPtr.push_back( mStartNodePtr );
            
            // Der Startknoten hat zu sich selbst den Abstand 0.
            mStartNodePtr->setDistanceFromStart( 0 );
        }
        else
        {
            std::ostringstream out;
            out << "(EE) NearestFloodAlgorithm::NearestFloodAlgorithm "
                << std::hex << this << std::dec
                << " Start position " << startPos
                << " not found in graph."
                << std::endl;
            std::cerr << out.str();
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) NearestFloodAlgorithm::NearestFloodAlgorithm "
            << std::hex << this << std::dec
            << " Graph is not valid!"
            << std::endl;
        std::cerr << out.str();
    }
}

// Suche des naechstgelegenes Flut-Feldes.
bool NearestFloodAlgorithm::search( Position& floodPos, int& distance )
{
    bool retVal = false;
    distance = 0;
    
    // Wir iterieren so lange durch die Liste der zu besuchenden
    // Knoten bis die Liste leer ist oder wir einen Flut-Knoten gefunden
    // haben.
    // Wichtig: Die Liste ist aufsteigend sortiert, sodass man die Knoten
    // mit dem geringsten Abstand vorne stehen und von dort auch
    // abgearbeitet werden muessen.
    while ( !mToVisitNodesPtr.empty() )
    {
        // Ersten Knoten holen.
        Node* nodePtr = mToVisitNodesPtr.front();
        mToVisitNodesPtr.pop_front();
        
        if ( nodePtr )
        {
            const NodeSearchResult found = searchInNeighbors(nodePtr);

            if ( RESULT_FOUND == found )
            {
                // Flut-Knoten mit geringstem Abstand gefunden.
                floodPos = nodePtr->getPosition();
                distance = nodePtr->getDistanceFromStart();
                retVal = true;
                break;
            }
            else if ( RESULT_ERROR == found )
            {
                // Es gab einen Fehler, wir brechen hier ab.
                retVal = false;
                break;
            }
            
            // Ansonsten ist es okay, wenn wir nichts gefunden haben.
            retVal = true;
        }
        else
        {
            std::ostringstream out;
            out << "(EE) NearestFloodAlgorithm::search "
                << std::hex << this << std::dec
                << " Node pointer is 0."
                << std::endl;
            std::cerr << out.str();
            retVal = false;
            break;
        }
    }
    
    return retVal;
}

// Suche naechstgelegenen Flutknoten in den Nachbarn eines Knotens.
NearestFloodAlgorithm::NodeSearchResult NearestFloodAlgorithm::searchInNeighbors( const Node* nodePtr )
{
    NodeSearchResult retValue = RESULT_ERROR;
    
    if ( nodePtr )
    {
#ifdef DEBUG
        std::ostringstream out;
        out << "(DD) NearestFloodAlgorithm::searchInNeighbors "
            << std::hex << this << std::dec
            << " pos: "  << nodePtr->getPosition()
            << " dist: " << nodePtr->getDistanceFromStart()
            << " type: " << nodePtr->getTileType()
            << std::endl;
        std::clog << out.str();
#endif

        if ( TILETYPE_FLOODED == nodePtr->getTileType() )
        {
            // Der Algorithmus ist so gestrickt, dass das erste Tile,
            // was ueberflutet ist, auch das mit dem geringsten Abstand
            // ist. Es koennte ggf. noch mehrere geben, aber wir begnuegen
            // uns mit dem erstbesten.
            retValue = RESULT_FOUND;
        }
        else
        {
            for ( int ii = 0; ii < DIRECTION_MAX; ii++ )
            {
                const Direction dir = (Direction)ii;
                Node* neighborPtr = nodePtr->getNeighbor(dir);

                if ( neighborPtr ) 
                {
                    if ( 0 == neighborPtr->getDistanceFromStart() )
                    {
                        // Knotenabstand zum Startpunkt wurde noch nicht festgelegt.
                        // Diesen daher festlegen und Knoten in die "Zu besuchen"-Liste
                        // eintragen.
                        neighborPtr->setDistanceFromStart(nodePtr->getDistanceFromStart() + 1);
                        mToVisitNodesPtr.push_back( neighborPtr );
                    }
                }
                else
                {
                    // Es ist okay, wenn ein Nachbarknoten 0 ist.
                }
            }
            retValue = RESULT_NOT_FOUND;
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) NearestFloodAlgorithm::searchInNeighbors "
            << std::hex << this << std::dec
            << " Node pointer is 0."
            << std::endl;
        std::cerr << out.str();
    }
    
    return retValue;
}
