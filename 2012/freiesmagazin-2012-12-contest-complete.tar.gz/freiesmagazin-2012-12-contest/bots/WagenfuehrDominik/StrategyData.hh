/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef STRATEGYDATA_HH
#define STRATEGYDATA_HH

#include "SimpleStrategyData.hh"

#include <vector>

/// Daten fuer eine konkrete Strategie
/**
 * Die Klasse haelt alle Daten, die der Strategie wichtig sind
 * (Datenkapselung). Der Einfachheit halber koennen die Attribute
 * direkt von der Strategie verwendet werden.
 */
class StrategyData : public SimpleStrategyData
{
  public:
    /// Konstruktor.
    StrategyData()
    : SimpleStrategyData(), floodedFieldsFlags(), isFinished(false)
    {
        floodedFieldsFlagsP = &floodedFieldsFlags;
    }
    
    /// Flag, welches Feld des Spielbretts ueberfluetet wurde.
    /**
     * Der Vektor wird dabei nach dem Einlesen des Spielbretts so
     * initialisiert, dass jedes Feld einen Platz hat und sehr schnell
     * gesetzt werden kann.
     */
    std::vector<bool> floodedFieldsFlags;
    
    /// Flag, dass das Spiel zu Ende ist.
    bool isFinished;    
};

#endif // STRATEGYDATA_HH
