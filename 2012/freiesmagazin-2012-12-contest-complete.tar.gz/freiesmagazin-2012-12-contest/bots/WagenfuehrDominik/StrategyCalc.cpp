/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "StrategyCalc.hh"

#include "DijkstraAlgorithm.hh"
#include "GameboardChoice.hh"
#include "GameValueCalc.hh"
#include "Graph.hh"
#include "NearestFloodAlgorithm.hh"
#include "StrategyCommander.hh"
#include "SimpleStrategyData.hh"

#include <iostream>
#include <sstream>

std::string StrategyCalc::sDiffCommands[] = {
    "GO EAST",
    "GO NORTH",
    "GO WEST",
    "GO SOUTH",
    "DRY EAST",
    "DRY NORTH",
    "DRY WEST",
    "DRY SOUTH",
    "DRY CURRENT",
    "GO CURRENT"
};

// Berechnet die drei Aktionen, die spaeter ausgegeben werden sollen.
bool StrategyCalc::calcCommands( std::vector<std::string>& commandList,
                                 const SimpleStrategyData& orgData,
                                 const unsigned int numDepth )
{
    bool retValue = false;

    if ( numDepth >= 3 )
    {
        // Spezialfall: Wenn innerhalb der naechsten numDepth Felder
        // (so viele Felder koennen wir bei der Berechnung erreichen)
        // kein ueberflutetes Feld zum Trockenlegen dabei ist, dann
        // weiss der Bot nicht so recht, was zu tun ist und läuft nur
        // stupide rum. In dem Fall schauen wir, wo das naechstgelegene
        // ueberflutete Feld liegt und steuern dies mit der Bewegung an.

        Graph graph;
        if ( graph.init( orgData.gameboard ) )
        {
            // graph.saveGraphviz( "/tmp/island_1.dot" );
            
            // Erstelle Algoritmus, um das naechstgelegen Flutfeld zu finden.
            NearestFloodAlgorithm floodAlgo( graph, orgData.position );

            Position nearestFloodField;
            int distance = 0;
            
            if ( floodAlgo.search( nearestFloodField, distance ) &&
                 (int)numDepth < distance )
            {
                // Das naechstgelegene geflutete Feld ist weiter entfernt
                // als unsere Berechnungsgalgorithmus erreichen koennte.
                // Wir wuerden also bei einer Berechnung nur ohne Ziel
                // umherlaufen. Daher laufen wir lieber zu dem geflutetem Feld.

#ifdef DEBUG
                {
                    std::ostringstream out;
                    out << "(DD) StrategyCalc::calcCommands "
                        << " Start: " << orgData.position
                        << " End: "   << nearestFloodField
                        << std::endl;
                    std::clog << out.str();
                }
#endif
                
                // Achtung: Vorherige Pfad-Berechnung loeschen.
                graph.resetAlgorithmData();

                DijkstraAlgorithm dijkstra( graph, orgData.position, nearestFloodField );

                // graph.saveGraphviz( "/tmp/island_2.dot" );

                DirectionVector directions;
                if ( dijkstra.getShortestPath( directions ) )
                {
                    // Pfad konnte berechnet werden.
#ifdef DEBUG
                    {
                        std::ostringstream out;
                        out << "(DD) StrategyCalc::calcCommands "
                            << " Path: ";
                            
                        for ( size_t ii = 0; ii < directions.size(); ii++ )
                        {
                            out << directions[ii] << " ";
                        }
                        out << std::endl;
                        std::clog << out.str();
                    }
#endif
                    // Wandlung der Richtungen in drei Befehle.
                    retValue = convertDirectionsToCommands( commandList, directions );
                }
                else
                {
                    std::ostringstream out;
                    out << "(EE) StrategyCalc::calcCommands "
                        << " Path in graph not found."
                        << std::endl;
                    std::cerr << out.str();
                }
            }
            else
            {
                // Das naechstgelegene geflutete Feld ist mit einer Berechnung
                // erreichbar. Wir starten also die normale Berechnung.

                // Aktuelle Entscheidung. Die Entscheidung wird sukzessive mit
                // neuen Befehlen befuellt und am Ende nach der Anwendung auf das
                // Spielbrett werden die Daten ausgewertet.
                GameboardChoice curChoice;
                curChoice.reset(numDepth);

                // Vektor mit den verschiedenen Datenzustaenden der verschiedenen
                // Ebenen. Achtung: Das erste Datum ist das Originaldatum. Daher
                // ist der Speicher um eines groesser.
                std::vector<SimpleStrategyData> datas(numDepth+1);
                datas[0] = orgData;

                // Beste Entscheidung
                GameboardChoice bestChoice;

                if ( calcCommandsRecursive( curChoice, bestChoice,
                                            datas, 0, numDepth ) )
                {
    #ifdef DEBUG
                    {
                        std::ostringstream out;
                        out << "(DD) Best choice: ";
                        for ( unsigned int ii = 0; ii < bestChoice.commandList.size(); ii++ )
                        {
                            if ( ii > 0 )
                            {
                                out << " | ";
                            }
                            out << bestChoice.commandList[ii];
                        }
                        out << " => " << bestChoice.value << std::endl;
                        std::clog << out.str();
                    }
    #endif // DEBUG

                    // Waehle die ersten drei Kommandos des besten Ergebnisses.
                    commandList.resize(3);
                    for ( unsigned int ii = 0; ii < 3; ii++ )
                    {
                        commandList[ii] = bestChoice.commandList[ii];
                    }
                    retValue = true;
                }
                else
                {
                    std::ostringstream out;
                    out << "(EE) StrategyCalc::calcCommands "
                        << " Commands could not be calculated."
                        << std::endl;
                    std::cerr << out.str();
                }
            }
        }
        else
        {
            std::ostringstream out;
            out << "(EE) StrategyCalc::calcCommands "
                << " Graph could not be initialized."
                << std::endl;
            std::cerr << out.str();
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) StrategyCalc::calcCommands "
            << " Depth " << numDepth
            << " must be 3 at least!"
            << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

// War einer der Befehle zuvor ein unnoetiges GO CURRENT?
bool StrategyCalc::checkGoCurrent( const GameboardChoice& curChoice,
                                   const unsigned int curDepth )
{
    int goCurrentFound = 0;
    for ( unsigned int ii = 0; ii <= curDepth; ii++ )
    {
        if ( curChoice.commandList[ii].compare( "GO CURRENT") == 0 )
        {
            goCurrentFound = 1;
        }
        else if ( 1 == goCurrentFound )
        {
            // Wir haben ein GO CURRENT gefunden und danach einen
            // "richtigen" Befehl. Dies ist unsinnig weiter zu verfolgen.
            goCurrentFound = 2;
            break;
        }
    }
            
    return ( 2 == goCurrentFound );
}

// Pruefe,ob der Bot sich durch GO-Befehle nicht bewegt hat.
bool StrategyCalc::checkNotMoved( const GameboardChoice& curChoice,
                                  const std::vector<SimpleStrategyData>& datas,
                                  const unsigned int curDepth )
{
    // Wir pruefen, ob zwischen je zwei Position, die identisch sind,
    // nur Bewegungsbefehle stehen, die nicht "GO CURRENT" sind
    // Falls ja, dann ist die Bewegung unnoetig gewesen (wir laufen im
    // Kreis) und wir koennten auch "GO CURRENT" nutzen.
    
    for ( unsigned int ii = 0; ii <= curDepth; ii++ )
    {
        if ( datas[ii].position == datas[curDepth+1].position )
        {
            // Jetzt pruefen, ob Befehle ii+1, ..., curDepth
            // nur Bewegungen waren. (Ausnahme: Alle sind
            // GO CURRENT!)
            unsigned int numGoCurrent = 0;
            unsigned int numGo = 0;
            
            for ( unsigned int kk = ii; kk < curDepth+1; kk++ )
            {
                if ( curChoice.commandList[kk].compare( 0, 2, "GO" ) == 0 )
                {
                    numGo++;
                    
                    if ( curChoice.commandList[kk].compare( "GO CURRENT" ) == 0 )
                    {
                        // Es handelt sich um einen GO CURRENT-Befehl.
                        numGoCurrent++;
                    }
                }
                else
                {
                    // Hier steht ein anderer Befehl als GO.
                    // Also koennen wir die Suche abbrechen
                    // und mit der naechsten Position weiter machen.
                    break;
                }
            }
            
            // Wenn jetzt die Anzahl der GOs gleich der Anzahl
            // der echten Befehle ist, aber nicht alle GO CURRENT
            // sind, dann haben wir einen Zyklus, wo der Bot sich bewegt
            // hat ohne sich echt zu bewegen.
            if ( numGo == ( curDepth + 1 - ii ) )
            {
                if ( numGoCurrent != numGo )
                {
/*
#ifdef DEBUG
                    std::ostringstream out;
                    out << "(DD) " << datas[ii].position << " => ";
                    for ( unsigned int kk = ii; kk < curDepth+1; kk++ )
                    {
                        if ( kk > ii )
                        {
                            out << " | ";
                        }
                        out << curChoice.commandList[kk];
                    }
                    out << " => " << datas[curDepth+1].position << std::endl;
                    std::clog << out.str();
#endif // DEBUG
*/
                    return true;
                }
            }
        }
    }
    
    return false;
}

// Berechnet die drei Aktionen, die spaeter ausgegeben werden sollen, rekursiv.
bool StrategyCalc::calcCommandsRecursive( GameboardChoice& curChoice,
                                          GameboardChoice& bestChoice,
                                          std::vector<SimpleStrategyData>& datas,
                                          const unsigned int curDepth,
                                          const unsigned int numDepth )
{
    bool retValue = false;

#ifdef DEBUG
    // Statischer Zaehler fuer die Anzahl der geprueften Kommandos.
    static unsigned int numCommandCounter;
    if ( 0 == curDepth )
    {
        numCommandCounter = 0;
    }
#endif // DEBUG

    if ( curDepth < numDepth )
    {
        // Wir sind noch nicht am Ziel angekommen und muessen noch
        // mindestens einen Befehl mehr anwenden vor der Bewertung der
        // Spielstellung.
        // SimpleStrategyData localData;
        bool commandApplied = false;

        // Wir iterieren ueber alle moeglichen Befehle und wenden diese nach
        // und nach an.
        for ( int ii = 0; ii < sNumCommands; ii++ )
        {
            // Kommando abspeichern.
            curChoice.commandList[curDepth] = sDiffCommands[ii];

            // Wir pruefen nach, ob einer der vorherigen Befehle.
            // "GO CURRENT" war. Falls ja, koennen wir diese Befehlsfolge
            // ignorieren, da GO CURRENT nur sinnvoll am Ende eingesetzt
            // werden kann.
            if ( checkGoCurrent( curChoice, curDepth ) )
            {
                continue;
            }
            
            // Kopiere originale Daten.
            datas[curDepth+1] = datas[curDepth];
            
            commandApplied =  StrategyCommander::applySingleCommand(
                                         datas[curDepth+1],
                                         sDiffCommands[ii],
                                         true );

            // Wenn durch die Anwendung des Kommandos der Bot sich
            // nur bewegt hat, dabei aber nicht von der Stelle gekommen
            // ist, dann ist die Bewegung absolut unnoetig.
            if ( checkNotMoved( curChoice, datas, curDepth ) )
            {
                continue;
            } 

/*
#ifdef DEBUG
            {
                std::ostringstream out;
                out << "(DD) StrategyCalc::calcCommandsRec "
                    << " Command valid: " << commandApplied
                    << " Old Pos: " << datas[curDepth].position
                    << " Cmd: "     << sDiffCommands[ii]
                    << " New Pos: " << datas[curDepth+1].position
                    << std::endl;
                std::clog << out.str();
            }
#endif // DEBUG
*/

            if ( commandApplied )
            {
                // Naechste Iterationstiefe gehen.
                retValue = calcCommandsRecursive( curChoice, bestChoice,
                                                  datas,
                                                  curDepth+1, numDepth );
            }
            else
            {
                // Kommando konnte nicht angewendet werden,
                // wir gehen automatisch zum naechsten Befehl ueber.
                retValue = true;
            }
            
            if ( !retValue )
            {
                // Es kam wohl zu einem Fehler, wir brechen dann mal ab.
                break;
            }
        }
    }
    else
    {
        curChoice.value = GameValueCalc::calculateGameValue( datas[curDepth] );

        // Wenn die aktuelle Entscheidung besser ist als die aktuell
        // beste, tauschen wir.
        if ( curChoice >= bestChoice )
        {
            bestChoice = curChoice;
        }
        
#ifdef DEBUG
        {
            numCommandCounter++;
            std::ostringstream out;
            out << "(DD) " << numCommandCounter << " ";
            for ( unsigned int ii = 0; ii < curChoice.commandList.size(); ii++ )
            {
                if ( ii > 0 )
                {
                    out << " | ";
                }
                out << curChoice.commandList[ii];
            }
            out << " => " << curChoice.value << std::endl;
            std::clog << out.str();
        }
#endif // DEBUG
        
        retValue = true;
    }
    
    return retValue;
}

// Wandlung der Richtungen in drei Befehle.
bool StrategyCalc::convertDirectionsToCommands( std::vector<std::string>& commandList,
                                                const DirectionVector& directions )
{
    bool retVal = true;
    commandList.clear();
    
    for ( size_t ii = 0; ii < 3; ii++ )
    {
        // Es sollte nicht vorkommen, aber wenn wir weniger als drei
        // Richtungen haben, fuellen wir den Rest mit GO CURRENT auf.
        if ( ii < directions.size() )
        {
            switch ( directions[ii] )
            {
                case DIRECTION_WEST:
                {
                    commandList.push_back( "GO WEST" );
                    break;
                }
                case DIRECTION_EAST:
                {
                    commandList.push_back( "GO EAST" );
                    break;
                }
                case DIRECTION_NORTH:
                {
                    commandList.push_back( "GO NORTH" );
                    break;
                }
                case DIRECTION_SOUTH:
                {
                    commandList.push_back( "GO SOUTH" );
                    break;
                }
                default:
                {
                    // Das sollte eigentlich nicht vorkommen!
                    std::ostringstream out;
                    out << "(WW) StrategyCalc::convertDirectionsToCommands "
                        << " Direction "
                        << (int)directions[ii]
                        << " is unknown."
                        << std::endl;
                    std::cerr << out.str();
                            
                    commandList.push_back( "GO CURRENT" );
                    break;
                }
            }
        }
        else
        {
            std::ostringstream out;
            out << "(WW) StrategyCalc::convertDirectionsToCommands "
                << " Less than 3 directions in list: " << directions.size()
                << std::endl;
            std::cerr << out.str();

            commandList.push_back( "GO CURRENT" );
        }
    }
    
    return retVal;
}


