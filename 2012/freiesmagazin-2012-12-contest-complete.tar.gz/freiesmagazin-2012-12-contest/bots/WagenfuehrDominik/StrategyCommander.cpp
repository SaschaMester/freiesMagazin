/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "StrategyCommander.hh"
#include "Position.hh"
#include "SimpleStrategyData.hh"

#include <iostream>
#include <sstream>

// Berechne "interne Position" aus einer normalen Position.
unsigned int StrategyCommander::getIntPos( const SimpleStrategyData& data,
                                           const Position& pos )
{
    return (pos.y()-1)*( data.gameboard.getSize().x() ) + (pos.x()-1);
}

// Wendet Kommandos testweise auf ein Spielbrett an.
int StrategyCommander::applyCommands( SimpleStrategyData& data,
                                      const std::vector<std::string>& commandList,
                                      const bool noCheck )
{
    int retValue = 0;

/*
#ifdef DEBUG
        {
            std::ostringstream out;
            out << "(DD) StrategyCommander::applyCommands "
                << " Num: " << commandList.size()
                << " Check: " << !noCheck
                << std::endl;
            std::cerr << out.str();
        }
#endif // DEBUG
*/
    
    for ( unsigned int ii = 0; ii < commandList.size(); ii++ )
    {
        if ( !applySingleCommand( data, commandList[ii], noCheck ) )
        {
            // Es kam zu einem Fehler.
            retValue = (int)(commandList.size()-ii);
            break;
        }
    }

    return retValue;
}

// Wendet ein einzelnes Kommando testweise auf ein Spielbrett an.
bool StrategyCommander::applySingleCommand( SimpleStrategyData& data,
                                            const std::string& cmdString,
                                            const bool noCheck )
{
/*
#ifdef DEBUG
        {
            std::ostringstream out;
            out << "(DD) StrategyCommander::applyCommands "
                << " Command: " << cmdString
                << " Check: " << !noCheck
                << std::endl;
            std::cerr << out.str();
        }
#endif // DEBUG
*/

    bool retValue = false;

    size_t pos = cmdString.find(' ');

    if ( ( std::string::npos != pos ) &&
         ( 0 != pos ) &&
         ( cmdString.length()-1 != pos ) )
    {
        const std::string firstCmd = cmdString.substr( 0, pos );
        const std::string secondCmd = cmdString.substr( pos+1 );

        if ( 0 == firstCmd.compare( "GO" ) )
        {
            retValue = operateGo( data, secondCmd, noCheck );
        }
        else if ( 0 == firstCmd.compare( "DRY" ) )
        {
            retValue = operateDry( data, secondCmd, noCheck );
        }
        else
        {
            std::ostringstream out;
            out << "(EE) StrategyCommander::applySingleCommand "
                << " Unknown command '"
                << firstCmd
                << "' from command string '"
                << cmdString
                << "'."
                << std::endl;
            std::cerr << out.str();
        }
    }
    else 
    {
        std::ostringstream out;
        out << "(EE) StrategyCommander::applySingleCommand "
            << " '" << cmdString<< "'."
            << " Cannot applay command!"
            << std::endl;
        std::cerr << out.str();
    }

    // Es kam vielleicht zu keinem Fehler, aber wir sind
    // sind unter Umstaenden gerade in die Fluten gelaufen
    // und gestorben.
    if ( data.gameboard.isLost( data.position ) )
    {
        retValue = false;
    }

    return retValue;
}

// Behandle eine Bewegung.
bool StrategyCommander::operateGo( SimpleStrategyData& data,
                                   const std::string& direction,
                                   const bool noCheck )
{
    bool retValue = false;

    if ( 0 == direction.compare( "NORTH" ) )
    {
        retValue = movePlayerNorth( data, noCheck );
    }
    else if ( 0 == direction.compare( "SOUTH" ) )
    {
        retValue = movePlayerSouth( data, noCheck );
    }
    else if ( 0 == direction.compare( "EAST" ) )
    {
        retValue = movePlayerEast( data, noCheck );
    }
    else if ( 0 == direction.compare( "WEST" ) )
    {
        retValue = movePlayerWest( data, noCheck );
    }
    else if ( 0 == direction.compare( "CURRENT" ) )
    {
        // Spieler bleibt stehen.
        retValue = true;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) StrategyCommander::operateGo "
            << " Unknown direction '"
            << direction
            << "'."
            << std::endl;
        std::cerr << out.str();
    }
    
    return retValue;
}

// Behandle eine Trockenlege-Aktion.
bool StrategyCommander::operateDry( SimpleStrategyData& data,
                                    const std::string& direction,
                                    const bool noCheck )
{
    bool retValue = false;

    if ( 0 == direction.compare( "NORTH" ) )
    {
        retValue = drainTileNorth( data, noCheck );
    }
    else if ( 0 == direction.compare( "SOUTH" ) )
    {
        retValue = drainTileSouth( data, noCheck );
    }
    else if ( 0 == direction.compare( "EAST" ) )
    {
        retValue = drainTileEast( data, noCheck );
    }
    else if ( 0 == direction.compare( "WEST" ) )
    {
        retValue = drainTileWest( data, noCheck );
    }
    else if ( 0 == direction.compare( "CURRENT" ) )
    {
        retValue = drainTileCurrent( data, noCheck );
    }
    else
    {
        std::ostringstream out;
        out << "(EE) StrategyCommander::operateDry "
            << " Unknown direction '"
            << direction
            << "'."
            << std::endl;
        std::cerr << out.str();
    }
    
    return retValue;
}
    
// Bewegt den Spieler ein Feld nach rechts.
bool StrategyCommander::movePlayerEast( SimpleStrategyData& data,
                                        const bool noCheck )
{
    bool retValue = false;

    static Position newPos;
    newPos.setPosition( data.position.x()+1, data.position.y() );

    if ( data.gameboard.isValidPosNoCheck( newPos ) )
    {
        data.position = newPos;
        retValue = true;
    }
    else if ( !noCheck )
    {
        std::ostringstream out;
        out << "(WW) StrategyCommander::movePlayerEast "
            << " Player is moving outside of board "
            << " from " << data.position << " to " << newPos << "."
            << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

// Bewegt den Spieler ein Feld nach oben.
bool StrategyCommander::movePlayerNorth( SimpleStrategyData& data,
                                         const bool noCheck )
{
    bool retValue = false;

    static Position newPos;
    newPos.setPosition( data.position.x(), data.position.y()-1 );

    if ( data.gameboard.isValidPosNoCheck( newPos ) )
    {
        data.position = newPos;
        retValue = true;
    }
    else if ( !noCheck )
    {
        std::ostringstream out;
        out << "(WW) StrategyCommander::movePlayerNorth "
            << " Player is moving outside of board "
            << " from " << data.position << " to " << newPos << "."
            << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

// Bewegt den Spieler ein Feld nach unten.
bool StrategyCommander::movePlayerSouth( SimpleStrategyData& data,
                                         const bool noCheck )
{
    bool retValue = false;

    static Position newPos;
    newPos.setPosition( data.position.x(), data.position.y()+1 );

    if ( data.gameboard.isValidPosNoCheck( newPos ) )
    {
        data.position = newPos;
        retValue = true;
    }
    else if ( !noCheck )
    {
        std::ostringstream out;
        out << "(WW) StrategyCommander::movePlayerSouth "
            << " Player is moving outside of board "
            << " from " << data.position << " to " << newPos << "."
            << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

// Bewegt den Spieler ein Feld nach links.
bool StrategyCommander::movePlayerWest( SimpleStrategyData& data,
                                        const bool noCheck )
{
    bool retValue = false;

    static Position newPos;
    newPos.setPosition( data.position.x()-1, data.position.y() );

    if ( data.gameboard.isValidPosNoCheck( newPos ) )
    {
        data.position = newPos;
        retValue = true;
    }
    else if ( !noCheck )
    {
        std::ostringstream out;
        out << "(WW) StrategyCommander::movePlayerWest "
            << " Player is moving outside of board "
            << " from " << data.position << " to " << newPos << "."
            << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

// Lege das Feld, auf dem der Spieler steht, trocken.
bool StrategyCommander::drainTileCurrent( SimpleStrategyData& data,
                                          const bool noCheck )
{
    bool retValue = false;

    static Position newPos;
    newPos.setPosition( data.position.x(), data.position.y() );

    if ( data.gameboard.isValidPosNoCheck( newPos ) )
    {
        // Nur, wenn auf dem Feld mit dem Trockenlegen etwas bewirkt
        // werden kann (ueberflutetes Feld), ist die Aktion valide.
        if ( data.gameboard.isFlooded( newPos ) )
        {
            retValue = data.gameboard.drain( newPos );
        }
    }
    else if ( !noCheck )
    {
        std::ostringstream out;
        out << "(WW) StrategyCommander::drainTileCurrent "
            << " Field is not valid at position "
            << newPos << "."
            << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

// Lege das Feld rechts vom Spieler trocken.
bool StrategyCommander::drainTileEast( SimpleStrategyData& data,
                                       const bool noCheck )
{
    bool retValue = false;

    static Position newPos;
    newPos.setPosition( data.position.x()+1, data.position.y() );

    if ( data.gameboard.isValidPosNoCheck( newPos ) )
    {
        // Nur, wenn auf dem Feld mit dem Trockenlegen etwas bewirkt
        // werden kann (ueberflutetes Feld), ist die Aktion valide.
        if ( data.gameboard.isFlooded( newPos ) )
        {
            retValue = data.gameboard.drain( newPos );
        }
    }
    else if ( !noCheck )
    {
        std::ostringstream out;
        out << "(WW) StrategyCommander::drainTileCurrent "
            << " Field is not valid at position "
            << newPos << "."
            << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

// Lege das Feld unterhalb vom Spieler trocken.
bool StrategyCommander::drainTileNorth( SimpleStrategyData& data,
                                        const bool noCheck )
{
    bool retValue = false;

    static Position newPos;
    newPos.setPosition( data.position.x(), data.position.y()-1 );

    if ( data.gameboard.isValidPosNoCheck( newPos ) )
    {
        // Nur, wenn auf dem Feld mit dem Trockenlegen etwas bewirkt
        // werden kann (ueberflutetes Feld), ist die Aktion valide.
        if ( data.gameboard.isFlooded( newPos ) )
        {
            retValue = data.gameboard.drain( newPos );
        }
    }
    else if ( !noCheck )
    {
        std::ostringstream out;
        out << "(WW) StrategyCommander::drainTileNorth "
            << " Field is not valid at position "
            << newPos << "."
            << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

// Lege das Feld ueberhalb vom Spieler trocken.
bool StrategyCommander::drainTileSouth( SimpleStrategyData& data,
                                        const bool noCheck )
{
    bool retValue = false;

    static Position newPos;
    newPos.setPosition( data.position.x(), data.position.y()+1 );

    if ( data.gameboard.isValidPosNoCheck( newPos ) )
    {
        // Nur, wenn auf dem Feld mit dem Trockenlegen etwas bewirkt
        // werden kann (ueberflutetes Feld), ist die Aktion valide.
        if ( data.gameboard.isFlooded( newPos ) )
        {
            retValue = data.gameboard.drain( newPos );
        }
    }
    else if ( !noCheck )
    {
        std::ostringstream out;
        out << "(WW) StrategyCommander::drainTileSouth "
            << " Field is not valid at position "
            << newPos << "."
            << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

// Lege das Feld links vom Spieler trocken.
bool StrategyCommander::drainTileWest( SimpleStrategyData& data,
                                       const bool noCheck )
{
    bool retValue = false;

    static Position newPos;
    newPos.setPosition( data.position.x()-1, data.position.y() );

    if ( data.gameboard.isValidPosNoCheck( newPos ) )
    {
        // Nur, wenn auf dem Feld mit dem Trockenlegen etwas bewirkt
        // werden kann (ueberflutetes Feld), ist die Aktion valide.
        if ( data.gameboard.isFlooded( newPos ) )
        {
            retValue = data.gameboard.drain( newPos );
        }
    }
    else if ( !noCheck )
    {
        std::ostringstream out;
        out << "(WW) StrategyCommander::drainTileWest "
            << " Field is not valid at position "
            << newPos << "."
            << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}
