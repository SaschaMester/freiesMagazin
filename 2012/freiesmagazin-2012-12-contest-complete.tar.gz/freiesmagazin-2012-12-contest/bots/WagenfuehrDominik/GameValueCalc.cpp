/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "GameValueCalc.hh"

#include "Position.hh"
#include "SimpleStrategyData.hh"
#include "StrategyCommander.hh"

#include <iostream>
#include <sstream>

// Bewertungsmöglichkeiten:
// Gesamtwert des Spielbretts =
//     Summe aller Gesamtwerte aller Felder
// Gesamtwert eines Feldes = 
//     (   Summe der vier Einzelwerte um dieses Feld
//       + Wert des aktuellen Feldes )
//   * Multiplikator des aktuellen Feldes
//   * Multiplikator fuer aktuellen Position
// Einzelwert eines Feldes =
//   Dry     = 1.0
//   Flooded = 0.4
//   Lost    = 0.4
// Multiplikator eines Feldes =
//   Dry     = 1.0
//   Flooded = 0.7
//   Lost    = 0.0
// Multiplikator aktuelle Position =
//   Dry     = 2.0
//   Flooded = 0.4
//   Lost    = NAN
// Sonderfall: Bot steht auf ueberflutetem Feld => Wert 0

// Berechne einen Wert der Spielstellung.
double GameValueCalc::calculateGameValue( const SimpleStrategyData& data )
{
    double value = 0.0;
    
    bool fieldFlooded = false;

    // Wenn das hinaus das Feld, auf dem der Bot steht,
    // ueberflutet ist, dann ist die ganze Spielsituation eher gefaehrlich.
    // Das ganze aber nur, wenn das Flutlevel nicht sein Maximallevel
    // erreicht hat. Danach werden naemlich Felder eine lange Zeit nicht
    // mehr ueberflutet und nur noch die noch nicht gefluteten gezogen.
    if ( data.gameboard.isFlooded( data.position ) )
    {
        const unsigned int intPos = StrategyCommander::getIntPos( data, data.position );
        if ( data.floodCounter < 7 )
        {
            // Maximum noch nicht erreicht, d.h. es ist gefaehrlich, wenn der Bot
            // auf einem bereits ueberflutetem Feld steht, da es mit dem naechsten
            // "INCRFLOOD 1" wieder kommt.
            
            // Achtung: Wir wissen, dass pro 10 Runden nur maximal 2 "INCRFLOOD 1"
            // kommen. Wenn diese also schon gekommen sind, steigt die Flut nicht
            // und es ist im Gegenteil sogar sicher auf dem Feld zu stehen.
            // Hinweis: Man koennte noch Wahrscheinlichkeiten ausrechnen, aber
            // das wird mir zu umstaendlich.
            if ( ( data.floodCounter%2 == 0 ) &&
                 ( data.numRound <= 5*data.floodCounter ) )
            {
                // Die Flut ist fuer diese Runden schon maximal gestiegen.
                // Meide die nicht trockengelegten Felder, die noch nicht vom
                // Spiel ueberflutet wurden, da sie wahrscheinlich jetzt
                // gezogen werden.
                if ( !data.floodedFieldsFlagsP->at( intPos ) )
                {
#ifdef DEBUG
                    std::clog << "(DD) Flutlevel/Runde = MAX; Feld " << data.position
                              << " unsicher, da noch nicht ueberflutet."
                              << std::endl;
#endif
                    fieldFlooded = true;
                }
            }
            else
            {
                // Das maximale Flutlevel fuer diese Runden ist noch nicht
                // erreicht. Alle ueberfluteten Felder sind unsicher.
#ifdef DEBUG
                std::clog << "(DD) Flutlevel/Runde < MAX; Feld " << data.position
                          << " unsicher, da ueberflutet."
                          << std::endl;
#endif
                fieldFlooded = true;
            }
        }
        else
        {
            // Maximallevel erreicht, d.h. die bereits ueberfluteten Felder
            // kommen erst wieder, wenn der Nachziehstapel leer ist. Das dauert
            // eine Weile. Daher ist das Feld genauso sicher wie die nicht
            // ueberfluteten Felder.
            // Meide die nicht trockengelegten Felder, die noch nicht vom
            // Spiel ueberflutet wurden, da sie wahrscheinlich jetzt
            // gezogen werden.
            // Hinweis: Man koennte noch zaehlen, welche Felder auf dem Ablage-
            // und Nachziehstapel liegen. Dann weiß man genau, welche Felder
            // besser gemieden werden sollten.
            if ( !data.floodedFieldsFlagsP->at( intPos ) )
            {
#ifdef DEBUG
                std::clog << "(DD) Flutlevel = MAX; Feld " << data.position
                          << " unsicher, da noch nicht ueberflutet."
                          << std::endl;
#endif
                fieldFlooded = true;
            }
        }
    }

    if ( !fieldFlooded )
    {
        // Uns interessiert nicht das ganze Spielfeld, sondern nur der Teil,
        // der vom Bot begehbar ist. Alle anderen Felder ignorieren wir.
        // Je mehr begehbarer Felder, desto hoeher der Spielbrettwert. Dies sorgt
        // also auch dafuer, dass der Bot sich anstrengt, das begehbarer Gebiet
        // moeglichst gross zu halten. Zusaetzlich bekommen wir eine Laufzeit-
        // optimierung, weil nur im Worst-Case das ganze Spielfeld geprueft werden
        // muss. Fuer die Pruefung nutzen wir einen rekursiven Algorithmus
        // ausgehend von der aktuellen Bot-Position.

        // Liste der Felder, die noch "besucht" werden muessen.
        static std::vector<Position> toVisitFields;
        
        // Flag fuer jedes Feld, das bereits besucht wurde.
        static std::vector<int> visitedFieldsFlags;

        // Initialisierung der Daten.
        toVisitFields.clear();
        toVisitFields.push_back( data.position );
        visitedFieldsFlags.assign( data.floodedFieldsFlagsP->size(), 0 );

        // Berechne den Spielwert ausgehend vom aktuellen Feld.
        value = calculateGameValueRecursive( data, toVisitFields, visitedFieldsFlags );
    }

/*
#ifdef DEBUG
    {
        std::ostringstream out;
        out << "(DD) GameValueCalc::calculateGameValue "
            << " " << value
            << std::endl;
        std::clog << out.str();
    }
#endif // DEBUG
*/

    return value;
}

// Berechnet einen Einzelwert fuer ein einzelnes Feld.
double GameValueCalc::calculateSimpleFieldValue( const SimpleStrategyData& data,
                                                 const Position& pos,
                                                 std::vector<Position>& toVisit,
                                                 std::vector<int>& visited )
{
    double value = 0.0;
    bool notLost = false;

    if ( data.gameboard.isValidPosNoCheck(pos) )
    {
        if ( data.gameboard.isDry(pos) )
        {
            value = 1.0;
            notLost = true;
        }
        else if ( data.gameboard.isFlooded(pos) )
        {
            // Versuch: Wert 1.5 (mehr Wert als Dry)
            //   => bedeutende Verringerung der Lebenszeit 69 => 46
            // Versuch: Wert 0.5
            //   => erster Standard, Referenz-Lebenszeit 69
            // Versuch: Wert 0.4
            //   => Lebenszeit 69 => 70 (neuer Standard)
            // Versuch: Wert 0.0 
            //   => Lebenszeit 69 => 70
            value = 0.4;
            notLost = true;
        }
        else // isLost
        {
            // Versuch: Wert 0.0
            //   => erster Standard, Referenz-Lebenszeit 70
            // Versuch: Wert 0.25
            //   => Lebenszeit 70 => 70
            // Versuch: Wert 0.4 (gleich wie Flooded)
            //   => Lebenszeit 70 => 71
            value = 0.4;
            // Feld ist untergegangen und nicht betretbar.
            notLost = false;
        }

        if ( notLost )
        {
            // Das Feld ist begehbar von der aktuellen Position aus.
            if ( 0 == visited[ StrategyCommander::getIntPos( data, pos ) ] )
            {
                // Das Feld wurde aber noch nicht untersucht.
                toVisit.push_back( pos );
                
                // Markiere Feld als demnaechst zu behandeln.
                visited[ StrategyCommander::getIntPos( data, pos) ] = 1;
            }
        }
    }

/*
#ifdef DEBUG
    {
        std::ostringstream out;
        out << "(DD) GameValueCalc::calculateFieldValue "
            << " Pos: " << pos
            << " => " << value
            << std::endl;
        std::clog << out.str();
    }
#endif // DEBUG
*/

    return value;
}

// Berechnet einen Wert fuer ein einzelnes Feld (basierend auf Umgebung).
double GameValueCalc::calculateFieldValue( const SimpleStrategyData& data,
                                           const Position& pos,
                                           std::vector<Position>& toVisit,
                                           std::vector<int>& visited )
{
    double value = 0.0;
    
    // Fuer das aktuelle Feld den Wert berechnen.
    // value += calculateFieldValue( data, pos );
    static Position newPos;

    newPos.setPosition(pos.x(),pos.y());
    value += calculateSimpleFieldValue( data, newPos, toVisit, visited );

    newPos.setPosition(pos.x()-1,pos.y());
    value += calculateSimpleFieldValue( data, newPos, toVisit, visited );

    newPos.setPosition(pos.x(),pos.y()-1);
    value += calculateSimpleFieldValue( data, newPos, toVisit, visited );
    
    newPos.setPosition(pos.x()+1,pos.y());
    value += calculateSimpleFieldValue( data, newPos, toVisit, visited );

    newPos.setPosition(pos.x(),pos.y()+1);
    value += calculateSimpleFieldValue( data, newPos, toVisit, visited );

    double multiplicator = 0.0;
    if ( data.gameboard.isDry(pos) )
    {
        multiplicator = 1.0;
    }
    else if ( data.gameboard.isFlooded(pos) )
    {
        // Default: 0.7
        // Wert 0.3 zeigt kleine Verbesserung, aber nicht viel.
        multiplicator = 0.3;
    }
    else // isLost
    {
        // Den Wert zu erhoehen ist Unsinn, es verschlechtert nur
        // das Ergebnis.
        multiplicator = 0.0;
    }
    value *= multiplicator;

    // Aktuelle Bot-Position einmalig bewerten.
    if ( pos == data.position )
    {
        if ( data.gameboard.isDry(pos) )
        {
            // Wenn der Spieler auf einem trockenem Feld steht
            // ist dies doppelt so viel wert.
            value *= 2.0;
        }
        else if ( data.gameboard.isFlooded(pos) )
        {
            // Wenn der Spieler auf einem ueberflutetem Feld steht
            // ist dies nur wenig wert, weil das Feld mit einer
            // einzigen Ueberflutung sofort weg ist.
            value *= 0.4;
        }
        else // isLost
        {
            // Auf einem untergegangenem Feld sollten wir nicht stehen.
            std::ostringstream out;
            out << "(EE) GameValueCalc::calculateFieldValue "
                << " Player position "
                << pos
                << " is lost field. That should not happen!"
                << std::endl;
            std::cerr << out.str();
        }
    }

    return value;
}

// Berechnet rekursiv vom ausgehenden Feld den Spielfeldwert.
double GameValueCalc::calculateGameValueRecursive( const SimpleStrategyData& data,
                                                   std::vector<Position>& toVisit,
                                                   std::vector<int>& visited )
{
    double value = 0.0;

/*
#ifdef DEBUG
    {
        std::ostringstream out;
        out << "(DD) GameValueCalc::calculateGameValueRecursive Begin "
            << " toVisit: " << toVisit.size()
            << std::endl;
        std::clog << out.str();
    }
#endif // DEBUG
*/

    // Wir gehen wie folgt vor. Von der aktuellen Position aus fuegen wir
    // alle begehbaren Felder zu einer Liste hinzu, die noch nicht untersucht
    // wurden. Dann arbeiten wir einfach nur diese Liste nach und nach ab,
    // bis sie leer ist. Dadurch sollte kein Feld mehrfach geprueft werden
    // und die Rekursion hat einen Anker.
    static Position pos;
    pos = toVisit.back();
    toVisit.pop_back();
    // 2 bedeutet, dass hierfuer der echte Wert schon berechnet wurde.
    visited[ StrategyCommander::getIntPos( data, pos ) ] = 2;

    if ( data.gameboard.isValidPos(pos) )
    {
        value += calculateFieldValue( data, pos, toVisit, visited );
    }
    else
    {
        std::ostringstream out;
        out << "(EE) GameValueCalc::calculateGameValueRecursive "
            << " Position "
            << pos
            << " is not valid."
            << std::endl;
        std::cerr << out.str();
    }

    // Und nun rekursiv alles abhandeln, wenn ueberhaupt noch was zu tun ist.
    if ( !toVisit.empty() )
    {
        value += calculateGameValueRecursive( data, toVisit, visited );
    }

/*
#ifdef DEBUG
    {
        std::ostringstream out;
        out << "(DD) GameValueCalc::calculateGameValueRecursive End "
            << " " << value
            << std::endl;
        std::clog << out.str();
    }
#endif // DEBUG
*/

    return value;
}
