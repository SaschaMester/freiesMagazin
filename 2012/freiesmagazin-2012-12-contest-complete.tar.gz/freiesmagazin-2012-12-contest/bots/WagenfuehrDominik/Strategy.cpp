/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "Strategy.hh"
#include "StrategyCalc.hh"
#include "StrategyCommander.hh"

#include "EndMessage.hh"
#include "FloodMessage.hh"
#include "GameboardEndMessage.hh"
#include "GameboardLineMessage.hh"
#include "GameboardStartMessage.hh"
#include "IncrFloodMessage.hh"
#include "StartMessage.hh"
#include "TextMessage.hh"

#include <iostream>
#include <sstream>
#include <cstdlib>

// Konstruktor.
Strategy::Strategy()
  : mData(), mGameboardStarted(false), mGameboardSize(0,0)
{ }

// Destruktor.
Strategy::~Strategy()
{ }

// Werte zuruecksetzen.
void Strategy::reset()
{
    mGameboardStarted = false;
    mGameboardSize.setPosition(0,0);
    mGameboardStrings.clear();
}

// Behandelt eine Start-Nachricht.
bool Strategy::operate( const StartMessage& message )
{
    bool retValue = false;

    mData.numRound = message.getNumRound();

    // Ab der ersten Runde muss die berechnete Position mit
    // der vom Server uebereinstimmen.
    if ( ( 1 == mData.numRound ) ||
         ( message.getPosition() == mData.position ) )
    {
        mData.position = message.getPosition();
        if ( StrategyCalc::calcCommands( mCommandList, mData, 6 ) )
        {
            // Wende berechnete Kommandos an.
            retValue = ( StrategyCommander::applyCommands( mData, mCommandList ) == 0 );
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate StartMessage "
            << std::hex << this << std::dec
            << " Position of bot "
            << mData.position
            << " is not the same as the message "
            << message.getPosition() << "."
            << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

// Behandelt eine Flut-Nachricht.
bool Strategy::operate( const FloodMessage& message )
{
    bool retValue = false;

    if ( mData.gameboard.isValidPos( message.getPosition() ) )
    {
        // Setze Flag, dass das Feld ueberflutet wurde.
        const unsigned int intPos = StrategyCommander::getIntPos( mData, message.getPosition() );
        mData.floodedFieldsFlags[intPos] = true;

        // Feld auf dem Spielbrett ueberfluten.
        mData.gameboard.flood( message.getPosition() );
        retValue = true;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate FloodMessage "
            << std::hex << this << std::dec
            << " Flooding outside gameboard on position "
            << message.getPosition() << "."
            << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

// Behandelt eine Steigende-Flut-Nachricht.
bool Strategy::operate( const IncrFloodMessage& message )
{
    // Flutzaehler speichern.
    mData.floodCounter += message.getNumIncrFlood();

    // Wir loeschen die Liste der ueberfluteten Felder nicht,
    // weil wir wissen wollen, welche Felder ggf. gleich wieder
    // ueberflutet werden. Jedes bereits gezogene Feld sollte
    // gemieden werden.
    
    return true;
}

// Behandelt eine Ende-Nachricht.
bool Strategy::operate( const EndMessage& /* message */ )
{
    mData.isFinished = true;
    return true;
}
    
// Behandelt eine Spielbrett-Start-Nachricht.
bool Strategy::operate( const GameboardStartMessage& message )
{
    mGameboardStarted = true;
    mGameboardStrings.clear();
    mGameboardSize = message.getSize();
    return true;
}

// Behandelt eine Spielbrett-Zeile-Nachricht.
bool Strategy::operate( const GameboardLineMessage& message )
{
    bool retValue = false;

    if ( mGameboardStarted )
    {
        mGameboardStrings.push_back( message.getLine() );
        retValue = true;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate GameboardLineMessage"
            << std::hex << this << std::dec
            << " Gameboard transfer has not been started yet!"
            << std::endl;
        std::cerr << out.str();
        retValue = false;
    }
    
    return retValue;
}

// Behandelt eine Spielbrett-Ende-Nachricht.
bool Strategy::operate( const GameboardEndMessage& message )
{
    bool retValue = false;
    
    if ( mGameboardStarted )
    {
        if ( mData.gameboard.create( mGameboardSize, mGameboardStrings ) )
        {
            // Fuer jedes Feld auf dem Spielbrett ein Flag reservieren.
            mData.floodedFieldsFlags.assign( mGameboardSize.x()*mGameboardSize.y(), false );
            retValue = true;
        }
        mGameboardStarted = false;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate GameboardEndMessage"
            << std::hex << this << std::dec
            << " Gameboard transfer has not been started yet!"
            << std::endl;
        std::cerr << out.str();
    }
    
    return retValue;
}

// Behandelt eine Textnachricht.
bool Strategy::operate( const TextMessage& message  )
{
    std::ostringstream out;
    out << "(EE) " << "Strategy::operate TextMessage "
        << std::hex << this << std::dec
        << "'" << message.getText() << "'."
        << " Cannot operate on text messages!"
        << std::endl;
    std::cerr << out.str();
    
    return false;
}

// Fragt ab, ob Kommandos zur Verfuegung stehen.
bool Strategy::isCommandsAvailable( std::vector<std::string>& cmdList )
{
    bool isAvail = false;

    cmdList.clear();
    if ( 3 == mCommandList.size() )
    {
        // Nur, wenn exakt drei Kommandos anstehen, werden diese
        // uebermittelt.
        cmdList = mCommandList;
        isAvail = true;

        // Nach dem Kopieren sollte man die Kommandos unbedingt
        // loeschen, damit bei der naechsten Abfrage nicht aus
        // Versehen noch Kommandos anstehen.
        mCommandList.clear();
    }

    return isAvail;
}

// Gibt zurueck, ob das Spiel zu Ende sein soll.
bool Strategy::isEnd() const
{
    return mData.isFinished;
}
