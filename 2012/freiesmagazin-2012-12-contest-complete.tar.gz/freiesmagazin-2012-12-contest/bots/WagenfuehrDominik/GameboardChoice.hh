/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef GAMEBOARDCHOICE_HH
#define GAMEBOARDCHOICE_HH

#include <string>
#include <vector>

/// Auswahl fuer ein Spielbrett.
/**
 * Dies enthaelt die Befehle, die zu einem Spielbrett fuehrten,
 * die Punktezahl, die das Spielbrett erreichte und die Anzahl
 * an redundanten (unwirksamen) Kommandos.
 */
class GameboardChoice
{
  public:
    /// Konstruktor.
    GameboardChoice();

    /// Setzt alle Werte zurueck auf den Ursprungszustand.
    void reset( const unsigned int numCommands );

    /// Vergleichsoperator.
    bool operator>=( const GameboardChoice& comp ) const;
    
  public:
    std::vector<std::string> commandList;
    double value;
    int numRedundantCommands;
};

#endif /* GAMEBOARDCHOICE_HH */
