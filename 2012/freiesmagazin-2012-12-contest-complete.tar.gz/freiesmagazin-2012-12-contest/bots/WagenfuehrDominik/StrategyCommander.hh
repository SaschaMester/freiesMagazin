/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef STRATEGYCOMMANDER_HH
#define STRATEGYCOMMANDER_HH

#include <string>
#include <vector>

// Vorwaertsdeklarationen.
class Position;
class SimpleStrategyData;

/// Anwendungen von Kommandos auf Daten.
/**
 * Die Klasse wendet ein oder mehrere Kommandos auf
 * Strategie-Daten an.
 */
class StrategyCommander
{
  public:
    /// Berechne "interne Position" aus einer normalen Position.
    /**
     * Mit "interner Position" ist eine eindeutige Ganzzahl gemeint, die
     * die Position genau beschreibt. Die Zahl wird in Abhaengigkeit von
     * der Spielfeldgroesse berechnet.
     * @param data Strategie-Daten, welche das Spielbrett halten.
     * @param pos Position, die umgerechnet werden soll.
     * @return Interne Position als Ganzzahl.
     */
    static unsigned int getIntPos( const SimpleStrategyData& data,
                                   const Position& pos );

    /// Wendet Kommandos testweise auf ein Spielbrett an.
    /**
     * Der Rueckgabewert gibt an, wo es zu einem Fehler kam:
     *   0   => Alles okay.
     *   1   => Fehler bei Kommando n.
     *   2   => Fehler bei Kommando n-1.
     *   ... => ...
     *   n-1 => Fehler bei Kommando 2.
     *   n   => Fehler bei Kommando 1.
     * @param data Zu veraenderte Spieldaten.
     * @param commandList Liste der anzuwendenden Kommandos.
     * @param noCheck Wenn true und es trat ein Fehler bei der Anwendung
     * der Kommandos auf, wird keine extra Fehlermeldung ausgegeben.
     * Dies ist notwendig, wenn man Kommandos nur pruefen will, ob diese
     * ueberhaupt moeglich sind.
     * @return <= 0, wenn alles gut ging, oder > 0 bei einem Fehler
    */
    static int applyCommands( SimpleStrategyData& data,
                              const std::vector<std::string>& commandList,
                              const bool noCheck = false );

    /// Wendet ein einzelnes Kommando testweise auf ein Spielbrett an.
    /**
     * @param data Zu veraenderte Spieldaten.
     * @param cmdString Anzuwendendes Kommandos.
     * @param noCheck Wenn true und es trat ein Fehler bei der Anwendung
     * des Kommando auf, wird keine extra Fehlermeldung ausgegeben.
     * (siehe applyCommands).
     * @return true, wenn das Kommando korrekt verarbeitet wurde
    */
    static bool applySingleCommand( SimpleStrategyData& data,
                                    const std::string& cmdString,
                                    const bool noCheck = false );

  private:
    /// Behandle eine Bewegung.
    /**
     * @param data Zu veraenderte Spieldaten.
     * @param direction Richtung, in die man sich bewegt.
     * @param noCheck Wenn true und es trat ein Fehler bei der Anwendung
     * des Kommando auf, wird keine extra Fehlermeldung ausgegeben.
     * (siehe applyCommands).
     * @return true, wenn die Nachricht korrekt verarbeitet wurde
     */
    static bool operateGo( SimpleStrategyData& data,
                           const std::string& direction,
                           const bool noCheck = false );

    /// Behandle eine Trockenlege-Aktion.
    /**
     * @param data Zu veraenderte Spieldaten.
     * @param direction Richtung, wo man trockenlegen will.
     * @param noCheck Wenn true und es trat ein Fehler bei der Anwendung
     * des Kommando auf, wird keine extra Fehlermeldung ausgegeben.
     * (siehe applyCommands).
     * @return true, wenn die Nachricht korrekt verarbeitet wurde
     */
    static bool operateDry( SimpleStrategyData& data,
                            const std::string& direction,
                            const bool noCheck = false );

    /// Bewegt den Spieler ein Feld nach rechts.
    static bool movePlayerEast( SimpleStrategyData& data,
                                const bool noCheck = false );

    /// Bewegt den Spieler ein Feld nach oben.
    static bool movePlayerNorth( SimpleStrategyData& data,
                                 const bool noCheck = false );

    /// Bewegt den Spieler ein Feld nach unten.
    static bool movePlayerSouth( SimpleStrategyData& data,
                                 const bool noCheck = false );

    /// Bewegt den Spieler ein Feld nach links.
    static bool movePlayerWest( SimpleStrategyData& data,
                                const bool noCheck = false );

    /// Lege das Feld, auf dem der Spieler steht, trocken.
    static bool drainTileCurrent( SimpleStrategyData& data,
                                  const bool noCheck = false );

    /// Lege das Feld rechts vom Spieler trocken.
    static bool drainTileEast( SimpleStrategyData& data,
                               const bool noCheck = false );

    /// Lege das Feld unterhalb vom Spieler trocken.
    static bool drainTileNorth( SimpleStrategyData& data,
                                const bool noCheck = false );

    /// Lege das Feld ueberhalb vom Spieler trocken.
    static bool drainTileSouth( SimpleStrategyData& data,
                                const bool noCheck = false );

    /// Lege das Feld links vom Spieler trocken.
    static bool drainTileWest( SimpleStrategyData& data,
                               const bool noCheck = false );
};

#endif // STRATEGYCOMMANDER_HH
