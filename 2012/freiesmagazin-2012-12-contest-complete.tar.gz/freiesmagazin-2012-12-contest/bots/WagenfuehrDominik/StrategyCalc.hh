/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef STRATEGYCALC_HH
#define STRATEGYCALC_HH

#include "Direction.hh"

#include <string>
#include <vector>

// Vorwaertsdeklarationen.
class GameboardChoice;
class Position;
class SimpleStrategyData;

/// Strategie-Berechnung.
/**
 * Die Klasse berechnet anhand der gesetzten Daten den naechsten
 * Zug.
 */
class StrategyCalc
{
  public:
    /// Berechne die drei Aktionen, die spaeter ausgegeben werden sollen.
    /**
     * @param[out] commandList Liste mit berechneten Kommandos.
     * @param orgData Originale Strategy-Daten als Basis der Berechnung.
     * @param numDepth Tiefe der Kommandos, die fuer eine Entscheidung
     * geprueft werden soll. Die Zahl sollte mindestens 3 sein.
     * Achtung: Mit jedem hoeheren Wert steigt die Berechnungszeit
     * exponentiell, d.h. bei Tiefe 3 muessen schon 10^3 = 1000 Kommandos
     * getestet werden.
     * @return true, wenn die Berechnung korrekt verlief.
     */
    static bool calcCommands( std::vector<std::string>& commandList,
                              const SimpleStrategyData& orgData,
                              const unsigned int numDepth = 3 );

  private:
    /// Berechnet die drei Aktionen, die spaeter ausgegeben werden sollen, rekursiv.
    /**
     * @param curChoice Aktuelle Entscheidung an Kommandos.
     * @param bestChoice Beste Entscheidung an Kommandos, d.h. die mit dem
     * hoechsten Spielwert. 
     * @param datas Die Strategy-Daten aller Ebenen.
     * @param curDepth Aktuelle Tiefe zur Berechnung. Sobald diese
     * Tiefe der zu berechneten Tiefe numDepth entspricht, ist der
     * Rekursionanker erreicht und die Spielstellung wird bewertet und mit
     * aktuell besten Entscheidung vergleichen.
     * @param numDepth Tiefe der Kommandos, die fuer eine Entscheidung
     * geprueft werden soll.
     * @return true, wenn die Berechnung korrekt verlief.
     */
    static bool calcCommandsRecursive( GameboardChoice& choices,
                                       GameboardChoice& bestChoice,
                                       std::vector<SimpleStrategyData>& datas,
                                       const unsigned int curDepth,
                                       const unsigned int numDepth );

    /// War einer der Befehle zuvor ein unnoetiges GO CURRENT?
    static bool checkGoCurrent( const GameboardChoice& curChoice,
                                const unsigned int curDepth );

    /// Pruefe,ob der Bot sich durch GO-Befehle nicht bewegt hat.
    static bool checkNotMoved( const GameboardChoice& curChoice,
                               const std::vector<SimpleStrategyData>& datas,
                               const unsigned int curDepth );

    /// Wandlung der Richtungen in drei Befehle.
    static bool convertDirectionsToCommands( std::vector<std::string>& commandList,
                                             const DirectionVector& directions );

  private:
    /// Anzahl unterschiedlicher Bot-Kommandos.
    const static int sNumCommands = 10;

    /// Die 10 verschiedenen Kommandos des Bots.
    static std::string sDiffCommands[sNumCommands];
};

#endif // STRATEGYCALC_HH
