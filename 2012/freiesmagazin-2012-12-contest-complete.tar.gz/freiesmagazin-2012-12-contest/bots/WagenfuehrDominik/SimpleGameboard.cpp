/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "SimpleGameboard.hh"

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>

// Konstruktor.
SimpleGameboard::SimpleGameboard()
  : mSize(0,0)
{
}

// Destructor.
SimpleGameboard::~SimpleGameboard()
{
}

// Laedt ein Spielbrett aus einer Datei.
bool SimpleGameboard::load( const std::string& filename, Position& startPos )
{
    bool retValue = false;

    bool gameBoardEnd = false;
    startPos.setPosition(0,0);

    // Datei oeffnen
    std::ifstream infile;

    infile.open( filename.c_str() );
    if ( infile.is_open() )
    {
        char charLine[1000];
        std::string line;
        unsigned int lineCounter = 0;

        retValue = true;

        while( infile.good() )
        {
            infile.getline(charLine, 1000);
            line = charLine;

            if ( line.compare(0, 14, "GAMEBOARDSTART") == 0 )
            {
#ifdef DEBUG
                {
                    std::ostringstream out;
                    out << "(DD) SimpleGameboard::load "
                        << std::hex << this << std::dec
                        << " GAMEBOARDSTARTED "
                        << " Size: " << line.substr(15)
                        << std::endl;
                    std::cerr << out.str();
                }
#endif
                Position newSize;
                if ( !extractSize( newSize, line.substr(15) ) )
                {
                    retValue = false;
                    break;
                }
                if ( !setSize( newSize ) )
                {
                    retValue = false;
                    break;
                }
            }
            else if ( line.compare(0, 12, "GAMEBOARDEND") == 0 )
            {
#ifdef DEBUG
                {
                    std::ostringstream out;
                    out << "(DD) SimpleGameboard::load "
                        << std::hex << this << std::dec
                        << " GAMEBOARDEND "
                        << " Size: " << mSize
                        << " Lines: " << lineCounter
                        << std::endl;
                    std::cerr << out.str();
                }
#endif
                // Spielbrett ist zu Ende.
                // Der Zeilencounter muss am Ende der Spielbrettgroesse
                // plus 1 entsprechend.
                if ( mSize.y() != lineCounter )
                {
                    std::ostringstream out;
                    out << "(EE) SimpleGameboard::load "
                        << std::hex << this << std::dec
                        << " Number of read lines "
                        << lineCounter
                        << " does not equal value y = "
                        << mSize
                        << "."
                        << std::endl;
                    std::cerr << out.str();
                    retValue = false;
                }
                
                // Alles, was ab jetzt kommt darf nur noch die Start-Position sein.
                gameBoardEnd = true;
            }
            else if ( !gameBoardEnd )
            {
                lineCounter++;
                if ( !extractAndSetTiles( lineCounter, line ) )
                {
                    retValue = false;
                    break;
                }
            }
            else
            {
                if ( line.compare(0, 5, "ROUND") == 0 )
                {
                    // Start-Position
                    // Muss sein "ROUND 1 8,6". Wir entfernen das "ROUND 1 "
                    // automatisch.
                    retValue = extractSize( startPos, line.substr( 8 ) );
                    if ( !retValue )
                    {
                        // Es kam zu einem Fehler.
                        break;
                    }
                }
                else if ( line.empty() )
                {
                    // Leere Zeile ignorieren
                }
                else
                {
                    std::ostringstream out;
                    out << "(EE) SimpleGameboard::load "
                        << std::hex << this << std::dec
                        << " Do not understand line "
                        << line
                        << "."
                        << std::endl;
                    std::cerr << out.str();
                    retValue = false;
                    break;
                }
            }
        }

        // Datei schließen.
        infile.close();
    }
    else
    {
        std::ostringstream out;
        out << "(EE) SimpleGameboard::load "
            << std::hex << this << std::dec
            << " Could not open file "
            << filename
            << "."
            << std::endl;
        std::cerr << out.str();
    }
    
    return retValue;
}

// Erzeugt ein Spielbrett aus einer Stringliste.
bool SimpleGameboard::create( const Position& size,
                        const std::vector<std::string>& lines )
{
    bool retValue = false;

#ifdef DEBUG
    {
        std::ostringstream out;
        out << "(DD) SimpleGameboard::create "
            << std::hex << this << std::dec
            << " Size: "
            << size
            << std::endl;
        std::cerr << out.str();
     }
#endif

    if ( lines.size() == size.y() )
    {
        if ( setSize( size ) )
        {
            retValue = true;
            for ( unsigned int jj = 0; jj < size.y(); jj++ )
            {
                if ( lines[jj].length() == size.x() )
                {
                    if ( !extractAndSetTiles( jj+1, lines[jj] ) )
                    {
                        retValue = false;
                        break;
                    }
                }
                else
                {
                    std::ostringstream out;
                    out << "(EE) SimpleGameboard::create "
                        << std::hex << this << std::dec
                        << " Line "
                        << jj
                        << " has length "
                        << lines[jj].length()
                        << "; differs from board with "
                        << size.x()
                        << "."
                        << std::endl;
                    std::cerr << out.str();
                    retValue = false;
                    break;
                }
            } // for jj
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) SimpleGameboard::create "
            << std::hex << this << std::dec
            << " Height of game board "
            << size.y()
            << " does not equal number of lines "
            << lines.size()
            << "."
            << std::endl;
        std::cerr << out.str();
    }

#ifdef DEBUG
    std::ostringstream out2;
    out2 << "(DD) SimpleGameboard::create "
         << std::hex << this << std::dec
         << " Return: "
         << retValue
         << std::endl;
    std::cerr << out2.str();
#endif
    
    return retValue;
}

// Prueft, ob die Position fuer das Spielbrett valide ist.
bool SimpleGameboard::isValidPos( const Position& pos, const bool noError ) const
{
    bool valid = false;

    // Achtung: Position faengt bei (1,1) an.
    if ( pos.isValid() && pos <= mSize )
    {
        valid = true;
    }
    else if ( !noError )
    {
        std::ostringstream out;
        out << "(EE) SimpleGameboard::isValidPos "
            << std::hex << this << std::dec
            << " Invalid position "
            << pos
            << " for boardsize "
            << mSize
            << "."
            << std::endl;
        std::cerr << out.str();
    }
    
    return valid;
}

// Setzt neue Spielbrettgroesse und allokiert Speicher dafuer.
bool SimpleGameboard::setSize( const Position& newSize )
{
    bool valid = false;

    if ( newSize.isValid() )
    {
        // Neue Groesse setzen.
        mSize = newSize;
        mTiles.resize( mSize.x() * mSize.y() );

        for ( unsigned int ii = 0; ii < mSize.x() * mSize.y(); ii++ )
        {
            mTiles[ii] = TILETYPE_LOST;
        }

        valid = true;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) SimpleGameboard::setSize "
            << std::hex << this << std::dec
            << " Invalid size "
            << newSize
            << "."
            << std::endl;
        std::cerr << out.str();        
    }

    return valid;
}

// Extrahiert eine zweidimensionale Groesse aus der Zeile.
bool SimpleGameboard::extractSize( Position& size, const std::string& line ) const
{
    bool valid = false;
    
    size.setPosition(0,0);

    // Feld-Position.
    unsigned int x = 0, y = 0;

    size_t pos = line.find(',');

    if ( ( std::string::npos != pos ) &&
         ( 0 != pos ) &&
         ( line.length()-1 != pos ) )
    {
        // Danach folgen x- und y-Position eines Feldes.
        std::istringstream in2( line.substr( 0, pos ) );
        in2 >> x;

        std::istringstream in3( line.substr( pos+1 ) );
        in3 >> y;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) SimpleGameboard::extractSize "
            << std::hex << this << std::dec
            << " Cannot interpret line '"
            << line
            << "'. Should be in format '3,5'."
            << std::endl;
        std::cerr << out.str();
    }

#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) SimpleGameboard::extractSize "
        << std::hex << this << std::dec
        << " Size: "
        << "(" << x << "," << y << ")"
        << "."
        << std::endl;
    std::clog << out.str();        
#endif // DEBUG

    if ( ( x > 0 ) && ( y > 0 )  )
    {
        size.setPosition( (unsigned int)x, (unsigned int)y );
        valid = true;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) SimpleGameboard::extractSize "
            << std::hex << this << std::dec
            << " Size: "
            << "(" << x << "," << y << ")"
            << " must be positive."
            << " From line: '"
            << line
            << "'."
            << std::endl;
        std::cerr << out.str();
        valid = false;
    }

    return valid;
}

// Extrahiere Felder aus einer Zeiler.
bool SimpleGameboard::extractAndSetTiles( const unsigned int lineCounter,
                                          const std::string& line )
{
    bool valid = false;

    if ( ( 1 <= lineCounter ) && ( lineCounter <= mSize.y() ) )
    {
        if ( line.length() == mSize.x() )
        {
            valid = true;
            Position pos;
            
            for ( size_t ii = 0; ii < line.length(); ii++ )
            {
                pos.setPosition( ii+1, lineCounter );
                if ( isValidPos(pos) )
                {
                    const unsigned int tPos = getIntPos(pos);

                    switch ( line[ii] )
                    {
                        case '#':
                            mTiles[tPos] = TILETYPE_DRY;
                            break;
                        case 'o':
                            mTiles[tPos] = TILETYPE_FLOODED;
                            break;
                        case '.':
                            mTiles[tPos] = TILETYPE_LOST;
                            break;
                        default:
                            std::ostringstream out;
                            out << "(EE) SimpleGameboard::extractAndSetTiles "
                                << " Unknown field type '"
                                << line[ii]
                                << "'."
                                << std::endl;
                            std::cerr << out.str();
                            valid = false;
                            break;
                    }
                    
                    if ( !valid )
                    {
                        break;
                    }
                }
                else
                {
                    valid = false;
                    break;
                }
            }
        }
        else
        {
            std::ostringstream out;
            out << "(EE) SimpleGameboard::extractAndSetTiles "
                << std::hex << this << std::dec
                << " Line length "
                << line.length()
                << " does not equal board with "
                << mSize.x()
                << " in line "
                << lineCounter+1
                << ": '"
                << line
                << "'."
                << std::endl;
            std::cerr << out.str();
            valid = false;
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) SimpleGameboard::extractAndSetTiles "
            << std::hex << this << std::dec
            << " Invalid line counter "
            << lineCounter
            << " for board height "
            << mSize.y()
            << "."
            << std::endl;
        std::cerr << out.str();
        valid = false;
    }

    return valid;
}

// Gibt das Spielbrett in Stringliste aus.
void SimpleGameboard::print( std::vector<std::string>& stringVector ) const
{
    stringVector.resize(0);

    if ( mSize.isValid() )
    {
        stringVector.resize( mSize.y() );
        for ( unsigned int jj = 1; jj <= mSize.y(); jj++ )
        {
            std::ostringstream out;
            for ( unsigned int ii = 1; ii <= mSize.x(); ii++ )
            {
                const unsigned int tPos = getIntPos(ii,jj);
                switch ( mTiles[tPos] )
                {
                    case TILETYPE_DRY:
                        out << "#";
                        break;
                    case TILETYPE_FLOODED:
                        out << "o";
                        break;
                    case TILETYPE_LOST:
                        out << ".";
                        break;
                    default:
                        out << " ";
                        break;
                }
            }
            stringVector[jj-1] = out.str();
        }
    }
}

// Gibt das Spielbrett auf stdlog aus.
void SimpleGameboard::print() const
{
    if ( mSize.isValid() )
    {
        for ( unsigned int jj = 1; jj <= mSize.y(); jj++ )
        {
            std::ostringstream out;
            out << "(II) ";
            for ( unsigned int ii = 1; ii <= mSize.x(); ii++ )
            {
                const unsigned int tPos = getIntPos(ii,jj);
                switch ( mTiles[tPos] )
                {
                    case TILETYPE_DRY:
                        out << "#";
                        break;
                    case TILETYPE_FLOODED:
                        out << "o";
                        break;
                    case TILETYPE_LOST:
                        out << ".";
                        break;
                    default:
                        out << " ";
                        break;
                }
            }
            std::clog << out.str() << std::endl;
        }
    }
}

// Lege ein Feld trocken.
bool SimpleGameboard::drain( const Position& pos )
{
    bool retValue = false;
    const unsigned int tPos = getIntPos(pos);
    switch ( mTiles[tPos] )
    {
        case TILETYPE_DRY:
            // Das Feld ist bereits trocken, daher aendert sich nichts.
            retValue = true;
            break;
        case TILETYPE_FLOODED:
            // Das Feld wird trocken gelegt.
            mTiles[tPos] = TILETYPE_DRY;
            retValue = true;
            break;
        case TILETYPE_LOST:
        {
            // Das Feld ist untergegangen, es kann nicht mehr trockengelegt werden.
            retValue = true;
            break;
        }
        default:
        {
            // Das Feld ist untergegangen, es kann nicht mehr trockengelegt werden.
            std::ostringstream out;
            out << "(EE) SimpleGameboard::drain "
                << std::hex << this << std::dec
                << " Unknown Tile type: "
                << mTiles[tPos]
                << "."
                << std::endl;
            std::cerr << out.str();
            retValue = false;
            break;
        }
    }
    return retValue;
}

// Ueberflute ein Feld.
bool SimpleGameboard::flood( const Position& pos )
{
    bool retValue = false;
    const unsigned int tPos = getIntPos(pos);
    switch ( mTiles[tPos] )
    {
        case TILETYPE_DRY:
            // Das Feld wird ueberflutet.
            mTiles[tPos] = TILETYPE_FLOODED;
            retValue = true;
            break;
        case TILETYPE_FLOODED:
            // Das Feld geht unter.
            mTiles[tPos] = TILETYPE_LOST;
            retValue = true;
            break;
        case TILETYPE_LOST:
            // Das Feld ist bereits untergegangen, es aendert sich nichts.
            retValue = true;
            break;
        default:
        {
            // Das Feld ist untergegangen, es kann nicht mehr trockengelegt werden.
            std::ostringstream out;
            out << "(EE) SimpleGameboard::flood "
                << std::hex << this << std::dec
                << " Unknown Tile type: "
                << mTiles[tPos]
                << "."
                << std::endl;
            std::cerr << out.str();
            retValue = false;
            break;
        }
    }
    return retValue;
}
