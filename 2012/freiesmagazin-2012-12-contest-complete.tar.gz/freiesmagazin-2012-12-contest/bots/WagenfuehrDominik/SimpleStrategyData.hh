/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef SIMPLESTRATEGYDATA_HH
#define SIMPLESTRATEGYDATA_HH

#include "SimpleGameboard.hh"
#include "Position.hh"

/// Abgespeckte Daten fuer eine konkrete Strategie
/**
 * Die Klasse haelt alle Daten, die der Strategie wichtig sind
 * (Datenkapselung). Der Einfachheit halber koennen die Attribute
 * direkt von der Strategie verwendet werden.
 * Dies ist eine abgespeckte Datenklasse, die nur die Daten haelt,
 * die zur Berechnung der Befehle veraendert werden muesse.
 */
class SimpleStrategyData
{
  public:
    /// Konstruktor.
    SimpleStrategyData()
    : numRound(0), position(0,0), gameboard(), floodCounter(0), floodedFieldsFlagsP(0)
    { }

    /// Aktuelle Runde.
    unsigned int numRound;

    /// Position des Bots.
    Position position;

    /// Spielbrett.
    SimpleGameboard gameboard;

    /// Flutzaehler.
    unsigned int floodCounter;

    /// Zeiger auf die gefluteten Felder.
    const std::vector<bool>* floodedFieldsFlagsP;
};

#endif // SIMPLESTRATEGYDATA_HH
