/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "GameboardChoice.hh"

// Konstruktor.
GameboardChoice::GameboardChoice()
: commandList(3), value(-10000.0), numRedundantCommands(3)
{
    // Wir initialisieren mit so "seltsamen" Werten, weil dies
    // die Initialentscheidung ist, falls sonst kein besseres Ergebnis
    // berechnet werden kann.
    commandList[0] = "GO CURRENT";
    commandList[1] = "GO CURRENT";
    commandList[2] = "GO CURRENT";
}

// Setzt alle Werte zurueck auf den Ursprungszustand.
void GameboardChoice::reset( const unsigned int numCommands )
{
    commandList.resize( numCommands );
    for ( unsigned int ii = 0; ii < numCommands; ii++ )
    {
        commandList[ii] = "GO CURRENT";
    }
    value = 0.0;
    numRedundantCommands = numCommands;
}

// Vergleichsoperator.
bool GameboardChoice::operator>=( const GameboardChoice& comp ) const
{
    bool greaterEqual = false;
    
    if ( value > comp.value )
    {
        // Der Spielbrettwert ist echt groesser.
        greaterEqual = true;
    }
    else if ( value == comp.value )
    {
        if ( numRedundantCommands <= comp.numRedundantCommands )
        {
            // Die Anzahl der redundanten Kommandos ist kleiner oder gleich.
            // Dies ist besser und damit groesser als der Vergleichspartner.
            greaterEqual = true;
        }
    }
    return greaterEqual;
}
