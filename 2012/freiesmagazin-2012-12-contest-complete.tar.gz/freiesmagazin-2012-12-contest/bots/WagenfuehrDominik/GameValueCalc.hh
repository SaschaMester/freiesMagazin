/**
    (C) Copyright 2012-2013 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef GAMEVALUECALC_HH
#define GAMEVALUECALC_HH

#include <vector>

// Vorwaertsdeklarationen.
class Position;
class SimpleStrategyData;

/// Bewertung einer Spielstellung.
/**
 * Die Klasse berechnet eine Spielstellung (Spielbrett und Spielerposition).
 */
class GameValueCalc
{
  public:
    /// Berechne einen Wert der Spielstellung
    static double calculateGameValue( const SimpleStrategyData& data );

  private:
    /// Berechnet rekursiv vom ausgehenden Feld den Spielfeldwert.
    static double calculateGameValueRecursive( const SimpleStrategyData& data,
                                               std::vector<Position>& toVisit,
                                               std::vector<int>& visited );

    /// Berechnet einen Wert fuer ein einzelnes Feld (basierend auf Umgebung).
    static double calculateFieldValue( const SimpleStrategyData& data,
                                       const Position& pos,
                                       std::vector<Position>& toVisit,
                                       std::vector<int>& visited );

    /// Berechnet einen Einzelwert fuer ein einzelnes Feld.
    static double calculateSimpleFieldValue( const SimpleStrategyData& data,
                                             const Position& pos,
                                             std::vector<Position>& toVisit,
                                             std::vector<int>& visited );
};

#endif // GAMEVALUECALC_HH
