#! /usr/bin/env ruby
# -*- coding: utf-8 -*-

# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://sam.zoy.org/wtfpl/COPYING for more details.

class Game
  DIRS = {
    :CURRENT => [0, 0],
    :NORTH   => [0, -1],
    :WEST    => [-1, 0],
    :SOUTH   => [0, 1],
    :EAST    => [1, 0]
  }

  MOVES = [:NORTH, :WEST, :SOUTH, :EAST]

  def initialize
    @rate = 0
    @l = File.open("/tmp/rubot.txt", "w")
  end

  def run
    $stdin.sync = true
    $stdout.sync = true
    $stderr.sync = true
    while line = $stdin.gets
      @l.puts line
      case line
      when /^GAMEBOARDSTART (\d+),(\d+)/
        x = $1.to_i
        y = $2.to_i
        @board = []

        y.times do
          gl = $stdin.gets
          if gl !~ /^[.o#]{#{x}}$/
            exit 1
          end
          @board << gl.chomp.scan(/./)
        end

        if $stdin.gets !~ /^GAMEBOARDEND$/
          exit 2
        end
        @board = @board.transpose
        @dimx = x
        @dimy = y
      when /^ROUND (\d+) (\d+),(\d+)$/
        @round = $1.to_i
        @posx = $2.to_i - 1
        @posy = $3.to_i - 1
        @l.puts @board.transpose.map{|i| i.join}.join("\n")
        act
      when /^INCRFLOOD ([01])$/
        fi = $1.to_i
        @rate += fi
      when /^FLOOD (\d+),(\d+)$/
        x = $1.to_i - 1 
        y = $2.to_i - 1 
        if @board[x][y] == '#'
          @board[x][y] = 'o'
        elsif @board[x][y] == 'o'
          @board[x][y] = '.'
        end
      when /^END$/
        exit 3
      else
        $stderr.puts "invalid line '#{line.chomp}'"
        exit 4
      end
    end
    @l.close
  end

  def act
    v1_act
  end

  def say(s)
    $stdout.puts s
    @l.puts s
  end

  def dry(d)
    say "DRY #{d}"
    x = @posx + DIRS[d][0]
    y = @posy + DIRS[d][1]
    if @board[x][y] == 'o'
      @board[x][y] = '#'
    end
  end

  def go(d)
    say "GO #{d}"
    @posx += DIRS[d][0]
    @posy += DIRS[d][1]
  end

  def check_dry(d)
    m = DIRS[d]
    x = @posx + m[0]
    y = @posy + m[1]
    if x >= @dimx || x < 0 || y >= @dimy || y < 0
      return 0
    end

    if @board[x][y] == 'o'
      dry d
      return 1
    end
    return 0
  end

  def v1_act
    c = 0
    w = nil

    while c < 3
      if w.nil?
        w = find_next_dry_field(@posx, @posy)
        if w.nil?
          (3-c).times{go :CURRENT}
          break
        end
      end

      wi = w.shift

      if wi.nil?
        dry :CURRENT
        w = nil
      elsif w.length == 0
        dry wi
        w = nil
      else
        go wi
      end
      c += 1
    end
  end

  def dp(w)
    dx = dy = 0
    w.each do |m|
      dx += DIRS[m][0]
      dy += DIRS[m][1]
    end
    [dx, dy]
  end

  def find_next_dry_field(x, y, c = 0, b = 11, ps = [])
    if c >= b
      return nil
    elsif @board[x][y] == '.'
      return nil
    elsif @board[x][y] == 'o'
      return []
    end

    ws = MOVES.map do |m|
      nx = x + DIRS[m][0]
      ny = y + DIRS[m][1]
      if nx >= 0 && nx < @dimx && ny >= 0 && ny < @dimy && !ps.include?([nx, ny])
        nps = ps + [[nx, ny]]
        nw = find_next_dry_field(nx, ny, c + 1, b, nps)
        if nw
          nw = [m] + nw
          if nw.length < b
            b = nw.length
          end
          nw
        end
      end
    end.compact
    if c == 0
      @l.puts "find_next_dry_field(#{x}, #{y}, #{c})"
      @l.puts ws.inspect
    end

    ws.min{|a, b| a.length <=> b.length}
  end
end

if __FILE__ == $0
  begin
    Game.new.run
  end
end
