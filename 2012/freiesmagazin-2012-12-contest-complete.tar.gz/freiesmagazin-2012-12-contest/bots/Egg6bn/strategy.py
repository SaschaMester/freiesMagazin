#!/usr/bin/env python
# 
#    Programming competition.
#    http://www.freiesmagazin.de/sechster_programmierwettbewerb
# 
#    (C) Copyright 2012 <Nikolas Pacik und Martin Ritter und Jan Fertschnig> Borg Egg
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as
#    published by the Free Software Foundation; either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with this program. If not, see
#    <http://www.gnu.org/licenses/>.

from base import BaseStrategy, HiddenIsland
import random

class Strategy(BaseStrategy):
	'''
	this is your strategy.
	the only thing you have to do is make the method next_three_moves more
	intelligent. 
	
	you have access to the attribute island which is an object of class HiddenIsland!
	e.g. to have a look at the field in the NORTH you can call:
		field = self.island.get_neighbour_field('NORTH')
	to check the status of this field you could do:
		field == HiddenIsland.FLOODED # is the field flooded
	'''
	
	def next_three_moves(self, round_number):
		'''
		next three moves of this round. this method is automatically called by the bot.
		ARGUMENTS:
			round_number	integer		number of current round
		RETURN VALUE:
			commands	list with exactly 3 strings		e.g. ['GO NORTH', 'DRY CURRENT', 'GO EAST']
		'''
		
		moves = []

		
		# our strategy:
		
		flooded_list = [0,0,0,0]
		check_direction = [0,0,0,0]
		
		direction_to_go = [0,0,0,0]
		

	
		
			# felder rundum trocknen
		
		def dry_arround():
			if self.island.get_neighbour_field('CURRENT') == HiddenIsland.FLOODED:
				if len(moves) < 3:
					moves.append('DRY CURRENT')
					self.island.dry_field('CURRENT')

					
			
			next_directions = ['NORTH','EAST','SOUTH','WEST']	
			random.shuffle(next_directions)
			for direction in next_directions:
		
				if self.island.get_neighbour_field(direction) == HiddenIsland.FLOODED:
					if len(moves) < 3:
						moves.append('DRY %s' %direction)
						self.island.dry_field(direction)

						
				
						
		dry_arround()

		def dry_corners():
			next_directions = ['NORTHWEST', 'SOUTHWEST', 'SOUTHEAST', 'NORTHEAST']
			random.shuffle(next_directions)
			for direction in next_directions:
				if self.island.get_neighbour_field(direction) == HiddenIsland.FLOODED:
					direction1, direction2 = direction[:5], direction[5:]
					corner_directions = [direction1, direction2]
					random.shuffle(corner_directions)
					direction1 = corner_directions[0]
					direction2 = corner_directions[1]
					
					if self.island.get_neighbour_field(direction1) in HiddenIsland.WALKABLE:
						if len(moves) < 3:
							moves.append('GO %s' %direction1)
							self.island.move(direction1)

							if len(moves) < 3:
								moves.append('DRY %s' %direction2)
								self.island.dry_field(direction2)

						dry_arround()
		
		dry_corners()


		if len(moves) == 0:
			for i in range(10):
				move1 = random.choice(['NORTH','EAST','SOUTH','WEST'])
				
				if self.island.get_neighbour_field(move1) in HiddenIsland.WALKABLE:

					moves.append('GO %s' %move1)
					self.island.move(move1)
					break
					
					
		dry_arround()
		dry_corners()
					
			
		
		while len(moves) < 3:
			moves.append('GO CURRENT')
		#moves = [move_1, 'GO CURRENT', 'GO CURRENT']
		return moves[:3]
