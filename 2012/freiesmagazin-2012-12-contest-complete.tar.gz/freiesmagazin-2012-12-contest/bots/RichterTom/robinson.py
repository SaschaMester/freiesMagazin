#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Einsendung für den Programmierwettbewerb von freiesmagazin 12/2012.

Der Bot Robinson probiert alle möglichen Aktionen bis zu einer bestimmten
Abbruchbedingung durch.
Dabei werden aber Aktionen, die zu einem bereits untersuchten Spielzustand
führen, ignoriert. Anschließend wird für alle möglichen Endzustände eine
Brauchbarkeit (utility) berechnet. Die Aktionen, die zu dem Zustand
mit der höchsten Brauchbarkeit führen, werden als beste Aktionen angesehen
und ausgegeben.

Die benutzte Brauchbarkeitsfunktion versucht die Anzahl der Trockenlegungs-
aktionen zu maximieren wobei der Bot am Ende der Runde möglichst nie auf
einem bereits gefluteten Feld  stehen sollte. Unter bestimmten Bedingungen
versucht sich der Bot in die Mitte der Insel zu begeben.

Für Situation, die mit einer größeren Wahrscheinlichkeit als 0.2% vorkommen,
werden die ausgewählten Aktionen in einer temporären Datei gespeichert und bei
einem erneuten Durchlauf geladen falls dieselbe Situation wieder auftritt.

Die Abbruchbedingungen für die Berechnung sind:
  * Anzahl der Aktionen größer als 100
  * Anzahl der möglichen Pfade größer als 200000
  * Alle möglichen Endzustände erforscht
  * Zeit überschritten. Für den Fall, dass die Aktionen abgespeichert werden,
    kann diese um den Faktor 100 überschritten werden

Hilfe zu den Kommandozeileparametern gibt es bei einem Aufruf mit der Option
'-h'.

Copyright: Tom Richter (tomi.xy@gmx.de), 2012 

License: GNU General Public License, Version 3
         (http://www.gnu.org/licenses/gpl.html)
"""

from collections import deque
import logging
import os
import pickle
import sys
import tempfile
try:
    from time import perf_counter as clock
except ImportError:
#    import warnings
#    warnings.warn('Import of time.perf_counter failed. Use time.clock instead.')
    from time import clock

log_game = logging.getLogger('game')
log = logging.getLogger('bot')

CURRENT, NORTH, EAST, SOUTH, WEST = (0, 0), (0, -1), (1, 0), (0, 1), (-1, 0)
GO, DRAIN = True, False
DIRECTIONS = {CURRENT:'CURRENT', NORTH:'NORTH', EAST:'EAST', SOUTH:'SOUTH',
              WEST:'WEST'}
ACTIVITIES = {GO:'GO', DRAIN:'DRY'}
ACTIONS = tuple((ac, dir) for ac in ACTIVITIES for dir in DIRECTIONS)
WATER, FLOOD, DRY = '.', True, False
FIELDS = {'o':FLOOD, '#':DRY}

TEMPDIR = os.path.join(tempfile.gettempdir(), 'robinson')
TEMPFILE = os.path.join(TEMPDIR, '%s.pkl')

VERSION = 3
MIN_PROB = 0.002
NUM_ROUNDS = 1000
MAX_DEPTH = 100
MAX_DEPTH_MOVE = 200
MAX_LEN = 200000


def convert(board):
    """
    Convert board to dictionary.
    
    Dictionary has entries (x, y):field. field can be FLOOD or DRY.
    """
    return {(x + 1, y + 1):FIELDS[field]
            for y, row in enumerate(board.strip().split())
            for x, field in enumerate(row) if field != WATER}

def add(t1, t2):
    """Add direction or position tuple to position tuple"""
    return (t1[0] + t2[0], t1[1] + t2[1])

def dist(t1, t2):
    """Direct distance between two position tuples"""
    return abs(t1[0] - t2[0]) + abs(t1[1] - t2[1])

def average(positions):
    """Average of multiple position tuples"""
    result = (0., 0.)
    for pos in positions:
        result = add(result, pos)
    return (result[0] / len(positions), result[1] / len(positions))

def flood(board, pos):
    """Flood one field on board"""
    if board[pos] == FLOOD:
        del board[pos]
    else:
        board[pos] = FLOOD

def drain(board, pos):
    """Drain one field on board"""
    assert board[pos] == FLOOD
    board[pos] = DRY

def floods_in_dist(board, bot_pos, max_dist):
    """Number of flooded fields at a distance smaller than max_dist"""
    return sum(dist(pos, bot_pos) <= max_dist for pos, field in board.items()
               if field == FLOOD)

def succ_state(board, state, action):
    """
    Determine new state, when action is given.

    state is defined as (pos, dry).
    pos is position of bot.
    dry is frozenset of position tuples with fields drained by bot.
    action is defined as tuple of GO or DRAIN and direction tuple.
    Return None if action is not a valid action (move into water, drain
    field which is not flooded).
    """
    pos, dry = state
    if action[0] == GO:
        pos = add(pos, action[1])
        if pos not in board:
            return
        return (pos, dry)
    else:
        pos_dry = add(pos, action[1])
        if pos_dry not in board or board[pos_dry] == DRY or pos_dry in dry:
            return
        return (pos, dry | {pos_dry})

def rdepth(path):
    """Number of actions in path"""
    return len(path) // 2

def rsuccessors(board, state):
    """Possible actions and resulting states for a given state"""
    results = {}
    for action in ACTIONS:
        new_state = succ_state(board, state, action)
        if new_state:
            results[new_state] = action
    return results

def rfrontier(start, successors, max_time, max_depth=MAX_DEPTH):
    """
    Find possible paths.
    
    For every state only one path to the state is explored. This is the
    path with lowest number of actions. The bot will move
    around and only in the case of a very small island the bot will stay at
    the current position.
    path is a list [state, action, state, ..., state].
    frontier is a list of paths.
    Break conditions:
       * maximum depth reached
       * maximum number of different paths reached
       * all possible states explored
       * enough time spent
    """
    frontier = deque([[start]])
    explored = {start}
    num_explored = 0
    depth = 0
    while (len(frontier[0]) != len(frontier[-1]) or
           depth < 3 or (
                    depth < max_depth and
                    len(frontier) < MAX_LEN and
                    len(explored) != num_explored and
                    clock() < max_time)):
        if len(frontier[0]) == len(frontier[-1]):
            num_explored = len(explored)
        path = frontier.popleft()
        s = path[-1]
        go_current = True
        for (state, action) in successors(s).items():
            if state not in explored:
                go_current = False
                explored.add(state)
                path2 = path + [action, state]
                frontier.append(path2)
        if go_current:
            # all 4 directions are occupied by water or
            # by states already visited
            frontier.append(path + [(GO, CURRENT), s])
        depth = rdepth(frontier[0])
    return frontier

_facs = (10, 3, 3, 3, 1, 1, 1) + tuple(0.1 - 0.1 * i / MAX_DEPTH_MOVE
                                       for i in range(MAX_DEPTH_MOVE))
def rutility(board, path, *args):
    """Number of drained fields and bot at the end of turn on dry field and
    possibility to drain more fields in subsequent turns"""
    state = path[6]
    N = rdepth(path) - 2
    df = [len(path[2 * i + 6][1]) for i in range(N)]
    df[1:] = [df[i + 1] - df[i] for i in range(N - 1)]
    penalty = 100 * (board[state[0]] != DRY  and state[0] not in state[1])
    return sum(df[i] * _facs[i] for i in range(N)) - penalty

def rutility_move(path, pos):
    """Move fast to pos"""
    dists = [dist(path[2 * i][0], pos) for i in range(rdepth(path))]
    return -min(dists) - 1.*dists.index(min(dists)) / MAX_DEPTH_MOVE

def rdistance(path, pos):
    """Distance between start position and state which is nearest to pos"""
    dists = [dist(path[2 * i][0], pos) for i in range(rdepth(path))]
    min_ = min(dists)
    return dists.index(min_) + (min_ > 2) * 6 + (min_ > 5) * 10

def rdrained(path):
    """Number of drained fields at end state"""
    return len(path[-1][1])

def hash_(board, pos):
    """Hash of board and bot position"""
    return str(hash((frozenset(board.items()), pos, VERSION)))

def prob_board(prob_last_round, board, round, num_floods, increased):
    """Probability of board setting"""
    if round == 1:
        return 1.
    if num_floods >= 2 or round > 10:
        return 0.
    cards_left = 12 - round
    floods_left = 2 - num_floods + increased
    assert 1 <= cards_left <= 10
    assert 1 <= floods_left <= 2
    prob_flood = 1. * floods_left / cards_left
    prob_field = 1. / len(board)
    return (prob_flood * prob_field if increased else
            (1 - prob_flood) * prob_field if num_floods >= 1 else
            1 - prob_flood) * prob_last_round

class RobinsonBot(object):
    """
    Robinson bot for Island game of the freiesmagazin contest 2012/12
    
    Method move returns the calculated best actions.
    The result is dumped to files in a tempdir if the possibility of the board
    setting is bigger than MIN_PROB. The files are loaded in later runs if
    the same setting occurs again.
    The depth of calculation depends on available time. For moves which will be
    dumped to to a file the time is allowed to be up to 100 times higher.
    The best actions are determined the following way:
    First all possible bot paths are calculated. Paths
    which lead to an already visited state are not considered. Then the
    utility for all resulting end states is calculated. The actions which lead
    to the state with highest utility are considered as the best actions. 
    """
    def __init__(self, board, pos, cache=True, available_time=0.1):
        self.board = board
        self.pos = pos
        self.cache = cache
        self.available_time = available_time
        self.max_time = 0.
        self.drained = 0
        self.num_floods = 0
        self.prob = 1.
        self.middle = None

    def _set_running_time(self, t0):
        if self.cache and self.prob >= MIN_PROB:
            fac = 1 + min(0.2 * NUM_ROUNDS * self.prob, 99)
        elif self.drained >= 2 or floods_in_dist(self.board, self.pos, 3) > 4:
            fac = 0.2
        else:
            fac = 0.5
        self.max_time = t0 + self.available_time * fac

    def _calculate_best_path(self):
        board = self.board
        pos = self.pos
        state0 = (pos, frozenset())
        successors = lambda state: rsuccessors(board, state)
        max_depth = (MAX_DEPTH if (self.middle or self.round > 5) else
                     MAX_DEPTH_MOVE)
        utility = lambda path: rutility(board, path)
        frontier = rfrontier(state0, successors, self.max_time, max_depth)
        depth = rdepth(frontier[0])
        best_path = max(frontier, key=utility)
        if utility(best_path) <= 3:
            # maybe it is better to move to the middle of island
            if not self.middle or self.middle[1] < depth or self.round > 50:
                positions = set([path[2 * i][0] for path in frontier
                                 for i in range(rdepth(path))])
                middle = average(positions)
                utility_move = lambda path: rutility_move(path, middle)
                best_path_move = max(frontier, key=utility_move)
                # save the determined middle of island for later rounds
                self.middle = (self.round, depth, middle, best_path_move)
            else:
                # use values from earlier turns
                round, _unused, middle, best_path_move2 = self.middle
                utility_move = lambda path: rutility_move(path, middle)
                best_path_move = max(frontier, key=utility_move)
                if (self.round <= 50 and rdepth(best_path_move2) - depth >=
                      3 * (self.round - round)):
                    best_path_move2 = best_path_move2[6 * (self.round - round):]
                    if (rutility_move(best_path_move2, middle) >
                          rutility_move(best_path_move, middle) and
                          rdepth(best_path_move2) >= 3 and
                          best_path_move2[:2 * depth + 1] in frontier):
                        log.debug('Take best_path_move from earlier turn')
                        best_path_move = best_path_move2
            distance = rdistance(best_path_move, middle)
            log.info('Middle position is (%.1f, %.1f), distance: %d' %
                     (middle + (distance,)))
            if (utility(best_path) <= 0 or distance > 15 or
                (utility(best_path) < 0.1 and distance > 8)):
                best_path = best_path_move
                utility = utility_move
        log.info('Best path of %d pathes at depth %d has utility %s' %
                  (len(frontier), depth, utility(best_path)))
        return best_path[:7]

    def move(self, round, num_floods):
        t0 = clock()
        self.round = round
        board = self.board
        cache_file = TEMPFILE % hash_(board, self.pos)
        self.prob = prob_board(self.prob, board, round, num_floods,
                               num_floods != self.num_floods)
        self.num_floods = num_floods
        log.info('Probability of this board is ca. %.1f%%' % (100 * self.prob))
        if self.cache and os.path.exists(cache_file):
            log.debug('Load best path from file %s' % cache_file)
            with open(cache_file, 'rb') as f:
                best_path, self.middle = pickle.load(f)
        else:
            self._set_running_time(t0)
            best_path = self._calculate_best_path()
            if self.cache and self.prob >= MIN_PROB:
                log.debug('Dump best path to file %s' % cache_file)
                with open(cache_file, 'wb') as f:
                    pickle.dump((best_path, self.middle), f, -1)
            log.debug('Spent %.2fs of %.2fs for move' % (clock() - t0,
                                                         self.max_time - t0))
        # apply new state
        self.pos, drained = best_path[-1]
        for pos_dry in drained:
            drain(board, pos_dry)
        self.drained = len(drained)
        return best_path[1::2]

def run(Bot, **bot_kwargs):
    """Init Bot instance and communicate with game script"""
    while(True):
        current_line = input()
        log_game.info('receive: %s' % current_line)
        parts = current_line.split()
        com = parts[0]
        if ',' in parts[-1]:
            pos = tuple(int(val) for val in parts[-1].split(','))
        if com == 'GAMEBOARDSTART':
            board = ''
            transfer_board = True
        elif com == 'GAMEBOARDEND':
            transfer_board = False
            board = convert(board)
        elif transfer_board:
            board += com + ' '
        elif com == 'ROUND':
            round = int(parts[1])
            if round == 1:
                t0 = clock()
                num_floods = 0
                bot = Bot(board, pos, **bot_kwargs)
            assert bot.pos == pos
            for command in bot.move(round, num_floods):
                send = ACTIVITIES[command[0]] + ' ' + DIRECTIONS[command[1]]
                log_game.info('send: %s' % send)
                print(send)
            sys.stdout.flush()
        elif com == 'INCRFLOOD':
            if parts[1] == '1':
                num_floods += 1
        elif com == 'FLOOD':
            flood(board, pos)
        elif com == 'END':
            t = clock() - t0
            log_game.info('Bot used %.2fs per move -> %.1fs for %d rounds' %
                          (t / round, t, round))
            break
        else:
            assert False

if __name__ == '__main__':
    import argparse
    import glob
    parser = argparse.ArgumentParser(description=
                                     RobinsonBot.__doc__.split('\n')[1])
    parser.add_argument('-l', '--log', help='log to file, default file: '
                        'robinson.log', nargs='?', const='robinson.log')
    parser.add_argument('-n', '--no-cache', help='disable caching to %s' %
                        TEMPDIR, action='store_true')
    parser.add_argument('-d', '--delete-cache', help='delete temp files and '
                        'exit', action='store_true')
    parser.add_argument('-t', '--time', help='available time per round',
                        type=float, default=0.1)
    args = parser.parse_args()
    if args.delete_cache:
        for fname in glob.glob(TEMPFILE % '*'):
            os.remove(fname)
        if args.no_cache and os.path.exists(TEMPDIR):
            os.rmdir(TEMPDIR)
        print('Deleted %s' % TEMPDIR)
    else:
        if not args.no_cache and not os.path.exists(TEMPDIR):
            os.mkdir(TEMPDIR)
        if args.log:
            logging.basicConfig(filename=args.log, filemode='w',
                                level=logging.DEBUG)
        run(RobinsonBot, cache=not args.no_cache, available_time=args.time)
