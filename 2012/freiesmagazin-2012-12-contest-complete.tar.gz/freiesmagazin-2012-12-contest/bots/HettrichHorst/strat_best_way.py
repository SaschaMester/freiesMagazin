#!/usr/bin/python
"""
Bot for 6th contest of freiesmagazin http://freiesmagazin.de/sechster_programmierwettbewerb
Copyright (C) 2013 Horst Hettrich <horst_hettrich@gmx.de>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import numpy as np
import numpy.ma as ma
import sys

use_fast = True
try:
    from fast import neighbours_fast
except ImportError:
    print >> sys.stderr, """Warning: The cython version of some functions is not
    available. -> This affects exec time!"""
    use_fast = False

class strategy(object):
    r"""this strategy evaluates possible ways the bot could use to reach certain
    targets."""
    def __init__(self, gameboard, bot):
        self.gameboard = gameboard
        self.bot = bot

        #initialize distance matrix of current strategy
        #distance matrix gives number of moves which bot needs in order to
        #reach the related field on the gameboard
        self.distance = -np.ones(
            (self.gameboard.X, self.gameboard.Y), 
            dtype=np.int)
        self.dry_from_field = np.zeros(
            (self.gameboard.X, self.gameboard.Y), 
            dtype=np.int)
        self.create_dry_from_field()
        self.ways = dict()
        self.commands = list()
        self.border_distance = np.ones(
            (self.gameboard.X, self.gameboard.Y), 
            dtype=np.bool)
        self.distance_at_border = ma.MaskedArray(self.distance, 
                                                 self.border_distance)
        return

    def todo(self):
        r"""function finds commands for commands list"""
        self.commands = list()
        for field in self.gameboard.flooded_last_round:
            self.create_dry_from_field_around(field)
        self.go_best_way()
        return '\n'.join(self.commands[0:3])

    def go_best_way(self):
        r"""function finds commands which are necessary for this strategy."""
        self.dry_around()

        if (len(self.commands) < 3):
            self.distance = -np.ones(
                (self.gameboard.X, self.gameboard.Y), 
                dtype=np.float)
            self.distance[self.bot.position[0], self.bot.position[1]] = 0
            self.border_distance = np.ones(
                (self.gameboard.X, self.gameboard.Y), 
                dtype=np.bool)
            self.border_distance[tuple(self.bot.position)] = False
            self.distance_at_border = ma.MaskedArray(self.distance, 
                                                     self.border_distance)
            self.distance = self.distance_at_border.data

            waypoints = self.find_best_target()
            
            waypoints.pop()

        while (len(self.commands) < 3):
            self.goto_target(waypoints.pop())
            self.dry_around()

        #while (len(self.commands) < 3):
            #self.go_current()
        
        return
    
    def find_best_target(self):
        r"""This function finds the best target for the bot to reach and
        returns the waypoints to this target.
        OUTPUTS:
        - waypoints: list of waypoints to target

        option MIN_TARGETS can be used to choose the best trade-off between
        runtime and success of the bot.
        MIN_TARGETS is the minimum number of targets the bot tries to reach.
        The bot chooses the targets by fields which can be dried from the
        target field (max. 5 fields, the target field and 4 neighbours)
        """
        MIN_TARGETS = 50
        cond = np.max(self.dry_from_field)

        candidates = np.array(np.where(self.dry_from_field >= cond)).T
        while (len(candidates) < MIN_TARGETS and cond > 1):
            cond -= 1
            candidates = np.array(np.where(self.dry_from_field >= cond)).T

        self.ways = {tuple(self.bot.position): [None, 0, 0]}
        # dict, position -> [next_position, fields_to_dry (=points), distance]
        judgements = list()
        for candidate in candidates:
            pts = self.judge(candidate)
            judgements.append(pts)
        #import pdb; pdb.set_trace()
        if (np.max(judgements) > 0):
            return self.waypoints(candidates[np.argmax(judgements)])
        else:
            return [self.bot.position]*4

    def waypoints(self, pos):
        r"""Function returns the waypoints from position <pos> to current
        position of the bot.
        INPUTS:
        - pos: target position
        OUTPUTS:
        - wps: waypoints from target to current position of the bot
        """
        pos = tuple(pos)
        wps = list()
        while pos is not None:
            wps.append(pos)
            pos = self.ways[pos][0]
        return wps

    def dry_around(self):
        r"""
        Function appends commands to command list which are necessary for
        drying the current field itself and all fields which are direct
        neighbours.
        """
        if ((self.gameboard.brd[tuple(self.bot.position)] == 1) and
            (len(self.commands) < 3)):
            self.dry_current()
        for neighbour in self.neighbours(self.bot.position):
            if ((self.gameboard.brd[tuple(neighbour)] == 1) and
                    (len(self.commands) < 3)):
                self.dry_target(neighbour)
        return

    def judge(self, candidate):
        r"""Function calculates value of field <candidate>
        INPUTS:
        - candidate: field of which to calculate the value
        OUTPUTS:
        - value of field <candidate>
        """
        candidate = tuple(candidate)
        if (self.distance[candidate] < 0):
            self.extend_distance(candidate)
        if (self.distance[candidate] < 0):
            return 0
        self.find_way_back(candidate)
        if (self.ways[candidate][2] > 0):
            return float(self.ways[candidate][1])/self.ways[candidate][2]
        return 0

    def extend_distance(self, pos):
        r"""function extends distance matrix up to field <pos>
        INPUTS:
        - <pos>: position which has to be reached by distance matrix
        """
        while (self.distance[pos] < 0):
            if np.all(self.distance_at_border.mask):
                return
            la = np.unravel_index(ma.argmin(self.distance_at_border), self.distance_at_border.shape)
            self.distance_at_border.mask[tuple(la)] = True
            self.look_around(la)

    def look_around(self, pos):
        r"""function looks around field <pos>
        function writes distance <dist> to current position into neighbour fields
        dist depends on fields which can be dried from the corresponding field
        INPUTS:
        - pos: position around which we look for flooded field
        """
        pos = tuple(pos)
        for neighbour in self.neighbours(pos):
            neighbour = tuple(neighbour)
            if ((self.distance[neighbour] < 0) and
                    (self.gameboard.brd[neighbour] > 0)):
                self.distance[neighbour] = (self.distance[pos]
                                           + 1
                                           - .95*(float(self.dry_from_field[neighbour])/5))
                self.distance_at_border.mask[neighbour] = False
        return

    def neighbours(self, pos):
        r"""function returns neighbours of position <pos> on gameboard (respecting
        the borders of the gameboard)
        """
        if use_fast:
            return neighbours_fast(pos[0], pos[1], self.gameboard.X, self.gameboard.Y)
        else:
            pos = np.array(pos)
            retval = list()
            if (pos[1] < self.gameboard.Y - 1 ):
                retval.append(pos+[0, 1])
            if (pos[0] < self.gameboard.X - 1 ):
                retval.append(pos+[1, 0])
            if (pos[1] > 0):
                retval.append(pos+[0, -1])
            if (pos[0] > 0):
                retval.append(pos+[-1, 0])
            return retval

    def find_way_back(self, pos):
        r"""Function finds the way to the target <pos> by going backwards
        through the distance matrix.
        """
        if tuple(pos) not in self.ways:
            neighbours = self.neighbours(pos)
            dist = list()
            for neighbour in neighbours:
                if (self.distance[tuple(neighbour)] > -1): 
                    dist.append(self.distance[tuple(neighbour)])
                else:
                    dist.append(np.Inf)
            next_pos = tuple(neighbours[np.argmin(dist)])
            self.find_way_back(next_pos)
            pts = self.ways[next_pos][1]
            pts += self.dry_from_field[tuple(next_pos)]
            distance = self.ways[next_pos][2] + 1
            self.ways[pos] = [next_pos, pts, distance]
            return

    def goto_target(self, target):
        r"""Function which decide which go_* function to call in order to go to
        target. Target has to be a neighbour of current position.
        INPUTS:
        - target: target field
        """
        if target[0] == self.bot.position[0]:
            if target[1] == self.bot.position[1]:
                return self.go_current()
            elif target[1] < self.bot.position[1]:
                return self.go_north()
            elif target[1] > self.bot.position[1]:
                return self.go_south()
        elif target[0] < self.bot.position[0]:
            return self.go_west()
        elif target[0] > self.bot.position[0]:
            return self.go_east()

    def dry_target(self, target):
        r"""Function which decide which dry_* function to call in order to dry
        target. Target has to be a neighbour of current position.
        INPUTS:
        - target: target field
        """
        if target[0] == self.bot.position[0]:
            if target[1] == self.bot.position[1]:
                return self.dry_current()
            elif target[1] < self.bot.position[1]:
                return self.dry_north()
            elif target[1] > self.bot.position[1]:
                return self.dry_south()
        elif target[0] < self.bot.position[0]:
            return self.dry_west()
        elif target[0] > self.bot.position[0]:
            return self.dry_east()

    def dry_current(self):
        self.dry_field(tuple(np.array(self.bot.position)))
        self.commands.append('DRY CURRENT')
        return
    def dry_north(self):
        self.dry_field(tuple(np.array(self.bot.position) + [0, -1]))
        self.commands.append('DRY NORTH')
        return
    def dry_south(self):
        self.dry_field(tuple(np.array(self.bot.position) + [0, 1]))
        self.commands.append('DRY SOUTH')
        return
    def dry_west(self):
        self.dry_field(tuple(np.array(self.bot.position) + [-1, 0]))
        self.commands.append('DRY WEST')
        return
    def dry_east(self):
        self.dry_field(tuple(np.array(self.bot.position) + [1, 0]))
        self.commands.append('DRY EAST')
        return

    def dry_field(self, field):
        if (self.gameboard.brd[field] == 1):
            self.gameboard.brd[field] = 2
            self.create_dry_from_field_around(field)
        return
    
    def go_current(self):
        self.commands.append('GO CURRENT')
    def go_north(self):
        if self.gameboard.brd[self.bot.position[0], self.bot.position[1]-1] > 0:
            self.bot.position[1] -= 1
            self.commands.append('GO NORTH')
        else: self.commands.append('GO CURRENT')
    def go_south(self):
        if self.gameboard.brd[self.bot.position[0], self.bot.position[1]+1] > 0:
            self.bot.position[1] += 1
            self.commands.append('GO SOUTH')
        else: self.commands.append('GO CURRENT')
    def go_west(self):
        if self.gameboard.brd[self.bot.position[0]-1, self.bot.position[1]] > 0:
            self.bot.position[0] -= 1
            self.commands.append('GO WEST')
        else: self.commands.append('GO CURRENT')
    def go_east(self):
        if self.gameboard.brd[self.bot.position[0]+1, self.bot.position[1]] > 0:
            self.bot.position[0] += 1
            self.commands.append('GO EAST')
        else: self.commands.append('GO CURRENT')
    
    def estimate_remaining_rounds(self):
        r"""Function estimates how many rounds are remaining until bot dies.
        OUTPUTS:
        - rnd_cnt: number of remaining rounds.
        """
        field_cnt = np.sum(self.gameboard.brd)
        rnd_cnt = 0
        flood_per_round = self.gameboard.flood_cnt + 1
        while (field_cnt > 0):
            rnd_cnt += 1
            field_cnt -= flood_per_round
            if (rnd_cnt%10 == 0):
                flood_per_round += 2
                if (flood_per_round > 7):
                    flood_per_round = 7
        return rnd_cnt

    def create_dry_from_field(self):
        r"""Function creates dry_from_field matrix by calling dry_from_field_single
        for each field.
        """
        for index, val in np.ndenumerate(self.dry_from_field):
            self.create_dry_from_field_single(index)
        return
    
    def create_dry_from_field_around(self, index):
        r"""Function recreates dry_from_field matrix around field <index>.
        INPUTS:
        index: field around which the dry_from_field matrix has to be
        recreated.
        """
        mask = [index]
        mask += self.neighbours(index)
        for ind in mask:
            self.create_dry_from_field_single(ind)
        return

    def create_dry_from_field_single(self, index):
        r"""Function creates dry_from_field matrix around field <index>.
        Counts fields which can be dried from field index and writes value into
        matrx.
        INPUTS:
        - index: index of field which is treated.
        """
        self.dry_from_field[tuple(index)] = 0
        if (self.gameboard.brd[tuple(index)] > 0):
            mask = [index]
            mask += self.neighbours(index)
            for ind in mask:
                if (self.gameboard.brd[tuple(ind)] == 1):
                    self.dry_from_field[tuple(index)] += 1
        return
