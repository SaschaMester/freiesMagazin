#!/usr/bin/python
"""
Bot for 6th contest of freiesmagazin http://freiesmagazin.de/sechster_programmierwettbewerb
Copyright (C) 2013 Horst Hettrich <horst_hettrich@gmx.de>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import sys
import re
import numpy as np
from gameboard import gameboard
#from strat_shortest import strategy
from strat_best_way import strategy

def read_cmd():
    return sys.stdin.readline()

def write_cmd(cmd = ''):
    if not cmd.endswith('\n'):
        cmd += '\n'
    sys.stdout.write(cmd)
    sys.stdout.flush()

class bot(object):
    "bot class"
    def __init__(self):
        self.alive = True
        self.gameboard = None
        self.strategy = None
        self.position = None
    
    def loop(self):
        while(self.alive):
            self.do_cmd(read_cmd())

    def do_cmd(self, cmd):
        if cmd.startswith('GAMEBOARDSTART'):
            gameboard_def = list()
            while not cmd.startswith('GAMEBOARDEND'):
                gameboard_def.append(cmd)
                cmd = read_cmd()
            gameboard_def.append(cmd)
            self.gameboard = gameboard(gameboard_def)
            self.strategy = strategy(self.gameboard, self)
            return
        elif cmd.startswith('ROUND'):
            m = re.match('ROUND\s*(?P<round>\d*)\s*(?P<X>\d*),(?P<Y>\d*)\s*', cmd, re.I)
            X = int(m.group(2))
            Y = int(m.group(3))
            self.position = [X-1, Y-1]
            if self.strategy is not None:
                write_cmd(self.strategy.todo())
            else:
                raise RuntimeWarning('No strategy defined!')
            self.gameboard.end_round()
            return
        elif cmd.startswith('INCRFLOOD'):
            self.gameboard.inc_flood(cmd)
            return
        elif cmd.startswith('FLOOD'):
            self.gameboard.flood(cmd)
            return
        elif cmd.startswith('END'):
            self.alive = False
            return
        else:
            raise RuntimeWarning('Command %s not implemented yet.' % cmd)
