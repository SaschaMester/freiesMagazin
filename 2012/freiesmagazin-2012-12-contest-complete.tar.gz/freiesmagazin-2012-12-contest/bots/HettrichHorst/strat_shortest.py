#!/usr/bin/python
"""
Bot for 6th contest of freiesmagazin http://freiesmagazin.de/sechster_programmierwettbewerb
Copyright (C) 2013 Horst Hettrich <horst_hettrich@gmx.de>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import numpy as np
import random

class strategy(object):
    "this strategy only dries next (direct distance) flooded field"
    def __init__(self, gameboard, bot):
        self.gameboard = gameboard
        self.bot = bot

        #initialisiere distance matrix of current strategy
        #distance matrix gives number of moves which bot needs in order to reach the related field on the gameboard
        self.distance = -np.ones((self.gameboard.X, self.gameboard.Y), dtype=np.int)
        return

    def todo(self):
        "function returns commands"
        commands = list()
        while (len(commands) < 3):
            commands += self.dry_nearest_flooded(cmds = len(commands))
        return '\n'.join(commands[0:3])

    def dry_nearest_flooded(self, cmds):
        r"""function returns commands which are necessary to dry the nearest flooded field.
        INPUTS:
        - cmds: number of commands which are already in todo list"""
        commands = list()
        if self.gameboard.brd[tuple(self.bot.position)] < 2:
            commands.append(self.dry_current())
        target = self.find_nearest_flooded()
        waypoints = self.find_way_back(target)
        
        waypoints.pop(0)
        while (len(commands) < 3 - cmds):
            if (len(waypoints) < 2):
                commands.append(self.dry_target(target))
                return commands
            else:
                commands.append(self.goto_target(waypoints.pop(0)))
        return commands

    def find_nearest_flooded(self):
        "function returns the nearest flooded field"
        if (self.gameboard.brd[self.bot.position[0], self.bot.position[1]] < 2):
            return self.bot.position

        self.distance = -np.ones((self.gameboard.X, self.gameboard.Y), dtype=np.int)
        self.distance[self.bot.position[0], self.bot.position[1]] = 0
        
        #breadth-first search for flooded field
        dist = 0
        new_last_found = [self.bot.position]
        search = True
        while search:
            dist += 1
            last_found = new_last_found
            new_last_found = list()
            for pos in last_found:
                search, lf = self.look_around(pos, dist)
                if not search:
                    return lf[0]
                new_last_found += lf
            if (len(new_last_found) < 1):
                return self.bot.position

    def look_around(self, pos, dist):
        r"""function looks around field <pos>
        function writes distance <dist> to current position into neighbour fields
        INPUTS:
        - pos: position around which we look for flooded field
        - dist: current distance from bot + 1
        OUTPUTS:
        - search: returns False if flooded field was found
        - last_found: returns list of fields to search next (if flooded field was found, the list only contains the flooded field)"""
        search = True
        neighbours = self.neighbours(pos)
        last_found = list()
        flooded_found = list()
        for neighbour in neighbours:
            if (self.distance[tuple(neighbour)] == -1):
                if (self.gameboard.brd[tuple(neighbour)] > 0):
                    self.distance[tuple(neighbour)] = dist
                    last_found.append(neighbour)
                if (self.gameboard.brd[tuple(neighbour)] == 1):
                    search = False
                    flooded_found.append(neighbour)
        if search:
            return (search, last_found)
        else:
            if len(flooded_found) == 1:
                return (search, flooded_found)
            else:
                return (search, [random.choice(flooded_found)])

    def neighbours(self, pos):
        "function returns neighbours of position <pos> on gameboard (respecting the borders of the gameboard)"
        pos = np.array(pos)
        retval = list()
        if (pos[1] < self.gameboard.Y - 1 ):
            retval.append(pos+[0, 1])
        if (pos[0] < self.gameboard.X - 1 ):
            retval.append(pos+[1, 0])
        if (pos[1] > 0):
            retval.append(pos+[0, -1])
        if (pos[0] > 0):
            retval.append(pos+[-1, 0])
        return retval

    def find_way_back(self, pos):
        "function finds the way to the target <pos> by going backwards through the distance matrix"
        if (self.distance[tuple(pos)] == 0):
            return [pos]
        else:
            for neighbour in self.neighbours(pos):
                if self.distance[tuple(neighbour)] > -1 and \
                    self.distance[tuple(pos)] > self.distance[tuple(neighbour)]:
                    next_pos = neighbour
                    waypoints = self.find_way_back(next_pos)
                    waypoints.append(pos)
                    return waypoints

    def goto_target(self, target):
        if target[0] == self.bot.position[0]:
            if target[1] == self.bot.position[1]:
                return 'GO CURRENT'
            elif target[1] < self.bot.position[1]:
                return self.go_north()
            elif target[1] > self.bot.position[1]:
                return self.go_south()
        elif target[0] < self.bot.position[0]:
            return self.go_west()
        elif target[0] > self.bot.position[0]:
            return self.go_east()

    def dry_target(self, target):
        if target[0] == self.bot.position[0]:
            if target[1] == self.bot.position[1]:
                return self.dry_current()
            elif target[1] < self.bot.position[1]:
                return self.dry_north()
            elif target[1] > self.bot.position[1]:
                return self.dry_south()
        elif target[0] < self.bot.position[0]:
            return self.dry_west()
        elif target[0] > self.bot.position[0]:
            return self.dry_east()

    def dry_current(self):
        self.gameboard.brd[self.bot.position[0], self.bot.position[1]] = 2
        return 'DRY CURRENT'
    def dry_north(self):
        self.gameboard.brd[self.bot.position[0], self.bot.position[1]-1] = 2
        return 'DRY NORTH'
    def dry_south(self):
        self.gameboard.brd[self.bot.position[0], self.bot.position[1]+1] = 2
        return 'DRY SOUTH'
    def dry_west(self):
        self.gameboard.brd[self.bot.position[0]-1, self.bot.position[1]] = 2
        return 'DRY WEST'
    def dry_east(self):
        self.gameboard.brd[self.bot.position[0]+1, self.bot.position[1]] = 2
        return 'DRY EAST'
    
    def go_current(self):
        return 'GO CURRENT'
    def go_north(self):
        if self.gameboard.brd[self.bot.position[0], self.bot.position[1]-1] > 0:
            self.bot.position[1] -= 1
            return 'GO NORTH'
        else: return 'GO CURRENT'
    def go_south(self):
        if self.gameboard.brd[self.bot.position[0], self.bot.position[1]+1] > 0:
            self.bot.position[1] += 1
            return 'GO SOUTH'
        else: return 'GO CURRENT'
    def go_west(self):
        if self.gameboard.brd[self.bot.position[0]-1, self.bot.position[1]] > 0:
            self.bot.position[0] -= 1
            return 'GO WEST'
        else: return 'GO CURRENT'
    def go_east(self):
        if self.gameboard.brd[self.bot.position[0]+1, self.bot.position[1]] > 0:
            self.bot.position[0] += 1
            return 'GO EAST'
        else: return 'GO CURRENT'
    
