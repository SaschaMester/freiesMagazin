#!/usr/bin/python
"""
Bot for 6th contest of freiesmagazin http://freiesmagazin.de/sechster_programmierwettbewerb
Copyright (C) 2013 Horst Hettrich <horst_hettrich@gmx.de>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from scipy.spatial.distance import cityblock
import numpy as np
import numpy.ma as ma

class strategy(object):
    "this strategy only dries next (direct distance) flooded field"
    def __init__(self, gameboard, bot):
        self.gameboard = gameboard
        self.bot = bot
        return

    def todo(self):
        commands = list()
        while len(commands) < 3:
            commands += self.dry_next_flooded()
        return '\n'.join(commands[0:3])

    def dry_next_flooded(self):
        target, distance = self.find_next_flooded()
        commands = list()
        if distance < 2:
            commands.append(self.dry_target(target))
        else:
            commands.append(self.goto_target(target))
        return commands

    def find_next_flooded(self):
        distance = self.distance()
        mask = (self.gameboard.brd != 1)
        distance_flooded = ma.masked_array(distance, mask)
        dist = distance_flooded.min()
        ind = distance_flooded.argmin()
        ind = np.unravel_index(ind, (self.gameboard.X, self.gameboard.Y))
        return (ind, dist)

    def distance(self):
        dist = np.zeros((self.gameboard.X, self.gameboard.Y), dtype=int)
        for i in range(self.gameboard.X):
            for j in range(self.gameboard.Y):
                dist[i, j] = cityblock(np.array(self.bot.position), np.array([i, j]))
        return dist
    
    def goto_target(self, target):
        if target[0] == self.bot.position[0]:
            if target[1] == self.bot.position[1]:
                return 'GO CURRENT'
            elif target[1] < self.bot.position[1]:
                return self.go_north()
            elif target[1] > self.bot.position[1]:
                return self.go_south()
        elif target[0] < self.bot.position[0]:
            return self.go_west()
        elif target[0] > self.bot.position[0]:
            return self.go_east()

    def dry_target(self, target):
        if target[0] == self.bot.position[0]:
            if target[1] == self.bot.position[1]:
                return self.dry_current()
            elif target[1] < self.bot.position[1]:
                return self.dry_north()
            elif target[1] > self.bot.position[1]:
                return self.dry_south()
        elif target[0] < self.bot.position[0]:
            return self.dry_west()
        elif target[0] > self.bot.position[0]:
            return self.dry_east()

    def dry_current(self):
        self.gameboard.brd[self.bot.position[0], self.bot.position[1]] = 2
        return 'DRY CURRENT'
    def dry_north(self):
        self.gameboard.brd[self.bot.position[0], self.bot.position[1]-1] = 2
        return 'DRY NORTH'
    def dry_south(self):
        self.gameboard.brd[self.bot.position[0], self.bot.position[1]+1] = 2
        return 'DRY SOUTH'
    def dry_west(self):
        self.gameboard.brd[self.bot.position[0]-1, self.bot.position[1]] = 2
        return 'DRY WEST'
    def dry_east(self):
        self.gameboard.brd[self.bot.position[0]+1, self.bot.position[1]] = 2
        return 'DRY EAST'
    
    def go_current(self):
        return 'GO CURRENT'
    def go_north(self):
        if self.gameboard.brd[self.bot.position[0],self.bot.position[1]-1] > 0:
            self.bot.position[1]-=1
            return 'GO NORTH'
        else: return 'GO CURRENT'
    def go_south(self):
        if self.gameboard.brd[self.bot.position[0],self.bot.position[1]+1] > 0:
            self.bot.position[1]+=1
            return 'GO SOUTH'
        else: return 'GO CURRENT'
    def go_west(self):
        if self.gameboard.brd[self.bot.position[0]-1,self.bot.position[1]] > 0:
            self.bot.position[0]-=1
            return 'GO WEST'
        else: return 'GO CURRENT'
    def go_east(self):
        if self.gameboard.brd[self.bot.position[0]+1,self.bot.position[1]] > 0:
            self.bot.position[0]+=1
            return 'GO EAST'
        else: return 'GO CURRENT'

