#!/usr/bin/python
"""
Bot for 6th contest of freiesmagazin http://freiesmagazin.de/sechster_programmierwettbewerb
Copyright (C) 2013 Horst Hettrich <horst_hettrich@gmx.de>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
import numpy as np
import sys

class gameboard(object):
    def __init__(self, gameboard_def):
        """
        init gameboard
        INPUTS:
        - gameboard_def: list of lines which define gameboard from stdout
        """
        if not gameboard_def[0].startswith('GAMEBOARDSTART') or gameboard_def[-1] == 'GAMEBOARDEND':
                raise RuntimeWarning("Gameboard was not initialized correctly")
        else:
            m = re.match('GAMEBOARDSTART\s*(?P<X>\d*),(?P<Y>\d*)\s*', gameboard_def[0], re.I)
            self.X = int(m.group(1))
            self.Y = int(m.group(2))
            
            self.brd = np.zeros((self.X, self.Y), dtype=np.int8)
            for i in range(self.X):
                for j in range(self.Y):
                    self.brd[i,j] = self.read_value(gameboard_def[j+1][i])

            self.flood_cnt = 0
            self.yet_flooded = np.zeros((self.X, self.Y), dtype=bool)
            self.flooded_last_round = list()

    def read_value(self, gameboard_desc):
        if gameboard_desc == '#': return 2
        if gameboard_desc == 'o': return 1
        if gameboard_desc == '.': return 0

    def inc_flood(self, cmd_line):
        m = re.match('INCRFLOOD\s*(?P<INC>\d*)\s*', cmd_line)
        inc = int(m.group(1))
        self.flood_cnt += inc

    def flood(self, cmd_line):
        m = re.match('FLOOD\s*(?P<X>\d*),(?P<Y>\d*)\s*', cmd_line, re.I)
        X = int(m.group(1))
        Y = int(m.group(2))
        if not (self.brd[X-1, Y-1] == 0):
            self.brd[X-1, Y-1] -= 1
            self.yet_flooded[X-1, Y-1] = True
            self.flooded_last_round.append(tuple([X-1, Y-1]))

    def end_round(self):
        self.flooded_last_round = list()
