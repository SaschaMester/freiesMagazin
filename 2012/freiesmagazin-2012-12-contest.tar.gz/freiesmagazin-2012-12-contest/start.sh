#!/bin/bash

if [ ! $# -eq 2 -a ! $# -eq 3 ]
then
    echo "Fehler: Es werden zwei oder drei Argument erwartet!"
    echo ""
    echo "Aufruf:   $0 FIELDNAME BOT [OPTIONS]"
    echo ""
    echo "Beispiel: $0 fields/simple.txt bots/dummybot/bot"
    echo "          $0 fields/simple.txt bots/dummybot/bot --log"
    echo ""
    echo "Erklaerung: Der Bot wird genau einmal auf dem vorhandene"
    echo "            Inselfeld ausgefuehrt."
    echo "            <BOT> gibt den Pfad zum Bot an bzw. den"
    echo "            Befehl zur Ausfuehrung des Bots."
    echo "            <FIELD> ist der Pfad zum Spielfeld."
    exit 1
fi

FIELDNAME="$1"
BOT="$2"
OPTIONS="$3"

# Loesche alte Pipe (wirklich nur Pipes)
if [ -p pipe1 ]
then
    rm pipe1 || exit $?
fi

# Erstelle neue Pipe
mkfifo pipe1 || exit $?

# Pipe muss nun existieren
if [ ! -p pipe1 ]
then
    echo "Fehler: Pipe 1 existiert nicht!"
    exit 3
fi

# Starte Spiel
./game.bin $OPTIONS $FIELDNAME <(<pipe1 $BOT) pipe1 || exit $?
