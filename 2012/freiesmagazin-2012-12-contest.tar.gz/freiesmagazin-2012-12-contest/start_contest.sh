#!/bin/bash

if [ ! $# -eq 1 -a ! $# -eq 2 ]
then
    echo "Fehler: Es werden ein oder zwei Argument erwartet!"
    echo ""
    echo "Aufruf:   $0 ANZAHL [OPTIONS]"
    echo ""
    echo "Beispiel: $0 100"
    echo "          $0 --log"
    echo ""
    echo "Erklaerung: Alle bekannten Bots (im Skript hinterlegt)"
    echo "            werden auf allen vorhandene Inselfeldern"
    echo "            die gewuenschte <ANZAHL> Mal getestet. Das"
    echo "            Ergebnis wird als Logfile im Ordner 'results'"
    echo "            gespeichert."
    exit 1
fi

NUMITER="$1"
OPTIONS="$2"

BOTS=( \
       "bots/dummybot/bot"   \
      )

BOTNAMES=( \
           "dummybot"   \
          )

if [ ${#BOTS[@]} != ${#BOTNAMES[@]} ]
then
    echo "Error: Size of BOTS and BOTNAMES does not match!"
    exit 1
fi

# Verzeichnis für Ergebnisse ablegen
mkdir -p results || exit 1

for INDEX in "${!BOTS[@]}"
do
    BOT="${BOTS[$INDEX]}"
    BOTNAME="${BOTNAMES[$INDEX]}"
    ./start_single_contest.sh "$BOT" "$BOTNAME" "$NUMITER" "$OPTIONS" || exit 1
done



