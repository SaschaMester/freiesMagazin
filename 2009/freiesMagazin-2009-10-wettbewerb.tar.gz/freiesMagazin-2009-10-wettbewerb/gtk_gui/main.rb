=begin
robots-gui-helper - freiesMagazin Programmierwettbewerb 10/2009
Copyright 2009 Dominik Honnef <dominikho@gmx.net>
Licence: GPLv3


This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, see
<http://www.gnu.org/licenses/>.
=end

require 'rubygems'
require 'gtk2'

class Symbol
  def to_proc
    proc { |obj, *args| obj.send(self, *args) }
  end
end

class MyFileChooserDialog < Gtk::FileChooserDialog
  def initialize(init_file = nil)
    super("Öffne Datei",
          nil,
          Gtk::FileChooser::ACTION_OPEN,
          nil,
          [Gtk::Stock::CANCEL, Gtk::Dialog::RESPONSE_CANCEL],
          [Gtk::Stock::OPEN, Gtk::Dialog::RESPONSE_ACCEPT])
    self.filename = init_file if init_file
  end
end

class MainWindow < Gtk::Window
  DEFAULT_THEME = "new"
  DEFAULT_GAMEFIELD = Dir.pwd + "/gameboards/chop.dat"
  def initialize
    super
    set_title "robots-gui-helper"
    set_default_width 600

    self.signal_connect("destroy") {
      Gtk.main_quit
    }

    @entries = { }

    gvbox = Gtk::VBox.new(false, 20)
    self.add gvbox

    @difficulties = { "leicht" => "easy", "mittel" => "normal", "schwer" => "hard"}

    @entries[:gamefield]      = Gtk::Entry.new
    @entries[:sequence]       = [Gtk::Entry.new, Gtk::Button.new(Gtk::Stock::OPEN)]
    @entries[:replay]         = Gtk::CheckButton.new("Spiel wiederholen (Sequenz abspielen)")
    @entries[:live]           = Gtk::CheckButton.new("Spiel animieren")
    themes = Dir.glob('images/*').map { |t| t.split("/").last}
    @entries[:theme] = Gtk::ComboBox.new
    themes.each do |theme|
      @entries[:theme].append_text(theme)
    end
    @entries[:pause]          = Gtk::CheckButton.new("Im Pausemodus starten")
    @entries[:fullscreen]     = Gtk::CheckButton.new("Vollbildmodus (funktioniert evtl. nicht mit mehreren Monitoren)")
    @entries[:speed_modifier] = Gtk::SpinButton.new(1, 100, 1)
    @entries[:clean]          = Gtk::CheckButton.new("Neues Spiel starten")
    @entries[:output]         = [Gtk::Entry.new, Gtk::Button.new(Gtk::Stock::OPEN)]
    @entries[:deck]           = [Gtk::Entry.new, Gtk::Button.new(Gtk::Stock::OPEN)]

    @entries[:clean].active = true

    @entries[:sequence][1].signal_connect("clicked") do
      load_file_for(@entries[:sequence][0])
    end

    @entries[:output][1].signal_connect("clicked") do
      load_file_for(@entries[:output][0])
    end

    @entries[:deck][1].signal_connect("clicked") do
      load_file_for(@entries[:deck][0])
    end

    @entries[:gamefield].text = DEFAULT_GAMEFIELD

    @entries[:sequence][0].sensitive = false
    @entries[:sequence][1].sensitive = false

    @entries[:difficulty]     = []
    btn1 = Gtk::RadioButton.new("leicht")
    btn2 = Gtk::RadioButton.new(btn1, "mittel")
    btn3 = Gtk::RadioButton.new(btn2, "schwer")
    btn2.active = true
    @entries[:difficulty] << btn1 << btn2 << btn3

    @entries[:output][0].text = Dir.pwd + "/globalseq.txt"

    @entries[:sequence][0].text = Dir.pwd + "/globalseq.txt"

    @entries[:live].active = true

    @entries[:live].signal_connect("clicked") do |widget|
      @entries[:speed_modifier].sensitive = widget.active?
      @entries[:pause].sensitive = widget.active?
    end

    @entries[:replay].signal_connect("clicked") do |widget|
      @entries[:deck][0].sensitive = !widget.active?
      @entries[:deck][1].sensitive = !widget.active?

      @entries[:sequence][0].sensitive = widget.active?
      @entries[:sequence][1].sensitive = widget.active?

      @entries[:output][0].sensitive = !widget.active?
      @entries[:output][1].sensitive = !widget.active?

      @entries[:clean].sensitive = !widget.active?
      # if widget.active? and @entries[:sequence][0].text.empty?
      #  @entries[:sequence][0].text = Dir.pwd + "/globalseq.txt"
      #end
    end

    ### gamefield selection
    vbox = Gtk::VBox.new(false, 5)
    l = Gtk::Label.new
    l.set_markup("<b>Spiel</b>")
    vbox.pack_start l
    l = Gtk::Label.new("Spielfeld:")
    l.set_alignment 0, 0
    vbox.pack_start l
    hbox = Gtk::HBox.new(false, 5)
    hbox.pack_start @entries[:gamefield]

    button = Gtk::Button.new(Gtk::Stock::OPEN)
    button.signal_connect("clicked") do
      load_file_for(@entries[:gamefield])
    end
    hbox.pack_start button, false
    vbox.pack_start hbox
    # gvbox.pack_start vbox


    ### carddeck selection
    # vbox = Gtk::VBox.new(false, 0)
    l = Gtk::Label.new("Kartenstapel (leer lassen, um einen zufälligen zu generieren):")
    l.set_alignment 0, 0
    vbox.pack_start l
    hbox = Gtk::HBox.new(false, 5)
    hbox.pack_start @entries[:deck][0]
    hbox.pack_start @entries[:deck][1], false
    vbox.pack_start hbox
    # gvbox.pack_start vbox


    ### clean selection
    # vbox = Gtk::VBox.new(false, 0)
    vbox.pack_start @entries[:clean]
    # gvbox.pack_start vbox


    ### difficulty selection
    # vbox = Gtk::VBox.new(0)
    hbox = Gtk::HBox.new(false, 5)
    l = Gtk::Label.new("Schwierigkeitsstufe:")
    l.set_alignment 0, 0
    hbox.pack_start l, false
    @entries[:difficulty].each do |e|
      hbox.pack_start e
    end
    vbox.pack_start hbox
    # gvbox.pack_start vbox


    ### output selection
    # vbox = Gtk::VBox.new(false, 0)
    l = Gtk::Label.new("Zu speichernde Sequenzdatei (leer lassen, falls keine geschrieben werden soll):")
    l.set_alignment 0, 0
    vbox.pack_start l
    hbox = Gtk::HBox.new(false, 5)
    hbox.pack_start @entries[:output][0]
    hbox.pack_start @entries[:output][1], false
    vbox.pack_start hbox
    gvbox.pack_start vbox


    ### replay selection
    vbox = Gtk::VBox.new(false, 0)
    l = Gtk::Label.new
    l.set_markup("<b>Wiederholung</b>")
    vbox.pack_start l
    vbox.pack_start @entries[:replay]
    # gvbox.pack_start vbox


    ### sequence selection
    # vbox = Gtk::VBox.new(false, 0)
    l = Gtk::Label.new("Sequenzdatei:")
    l.set_alignment 0, 0
    vbox.pack_start l
    hbox = Gtk::HBox.new(false, 5)
    hbox.pack_start @entries[:sequence][0]
    hbox.pack_start @entries[:sequence][1], false
    vbox.pack_start hbox
    gvbox.pack_start vbox


    ### theme selection
    vbox = Gtk::VBox.new(false, 0)
    l = Gtk::Label.new
    l.set_markup("<b>Optionen</b>")
    vbox.pack_start l
    l = Gtk::Label.new("Thema:")
    l.set_alignment 0, 0
    vbox.pack_start l
    vbox.pack_start @entries[:theme]

    ### live selection
    vbox.pack_start @entries[:live]
    # gvbox.pack_start vbox


    ### speed selection
    # vbox = Gtk::VBox.new(false, 0)
    l = Gtk::Label.new("Animationsgeschwindigkeit:")
    l.set_alignment 0, 0
    vbox.pack_start l
    vbox.pack_start @entries[:speed_modifier]
    # gvbox.pack_start vbox


    ### pause selection
    # vbox = Gtk::VBox.new(false, 0)
    vbox.pack_start @entries[:pause]

    ### fullscreen
    vbox.pack_start @entries[:fullscreen]
    gvbox.pack_start vbox


    ### buttons
    vbox = Gtk::VBox.new(false, 0)
    hbox = Gtk::HBox.new(false, 5)
    b_start = Gtk::Button.new(Gtk::Stock::OK)
    b_start.children[0].children[0].children[1].text = "Spiel starten" # ugliest piece of line in this whole application

    b_start.signal_connect("clicked") do
      build_options
    end
    b_cancel = Gtk::Button.new(Gtk::Stock::CLOSE)
    b_cancel.signal_connect("clicked") do
      Gtk.main_quit
    end

    hbox.pack_start b_start
    hbox.pack_start b_cancel

    vbox.pack_start hbox
    gvbox.pack_start vbox
  end

  def load_file_for(entry)
    init = entry.text.empty? ? nil : entry.text
    dialog = MyFileChooserDialog.new(init)

    if dialog.run == Gtk::Dialog::RESPONSE_ACCEPT
      entry.text = dialog.filename
    end
    dialog.destroy
  end

  def build_options
    options = []
    if @entries[:gamefield].text.empty?
      dialog = Gtk::MessageDialog.new(self,
                                      Gtk::Dialog::DESTROY_WITH_PARENT,
                                      Gtk::MessageDialog::QUESTION,
                                      Gtk::MessageDialog::BUTTONS_CLOSE,
                                      "Die Angabe des Spielfeldes darf nicht leer sein.")
      dialog.run
      dialog.destroy
      return false
    end
    options << "--gamefield \"" + @entries[:gamefield].text + "\""

    if @entries[:replay].active?
      # if a replay, set --replay and --no-clean
      options << "--replay"
      options << "--no-clean"

      # set --sequence (will set to default if --no-replay
      options << "--sequence \"#{@entries[:sequence][0].text}\""
    else
      # otherwise set --no-replay
      options << "--no-replay"

      if @entries[:clean].active?
        # if clean, set --clean
        options << "--clean"
      else
        # otherwise set --no-clean
        options << "--no-clean"

        # set --bot only if not a replay and not clean
        options << "--bot \"#{Dir.pwd + "/bot.txt"}\""
      end

      unless @entries[:deck][0].text.empty?
        # if we also have a deck, set it (won't set it when --replay)
        options << "--cards \"#{@entries[:deck][0].text}\""
      end

      unless @entries[:output][0].text.empty?
        # if we have an output file, set it (won't set it when --replay)
        options << "--output \"#{@entries[:output][0].text}\""
      end
    end

    if @entries[:live].active?
      #if live, set --live
      options << "--live"
      if @entries[:pause].active?
        #if also pause, set --pause (won't set when not live
        options << "--pause"
      end
      # also set animation speed (won't set when not live)
      options << "--speed-modifier " + @entries[:speed_modifier].text
    else
      # if not live, set --no-live
      options << "--no-live"
    end

    if @entries[:fullscreen].active?
      options << "--fullscreen"
    else
      options << "--no-fullscreen"
    end

    # set difficulty
    options << "--difficulty " + @difficulties[@entries[:difficulty].find(&:active?).label]

    # set theme
    theme = @entries[:theme].active_text || DEFAULT_THEME
    options << "--theme " + theme

    puts options.join(" ")
    system "./robots-gui #{options.join(" ")}"
  end
end

window = MainWindow.new
Gtk.init
window.show_all
Gtk.main
