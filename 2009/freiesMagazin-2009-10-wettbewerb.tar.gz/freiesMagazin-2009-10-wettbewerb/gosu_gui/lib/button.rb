=begin
robots-gui - freiesMagazin Programmierwettbewerb 10/2009
Copyright 2009 Dominik Honnef <dominikho@gmx.net>
Licence: GPLv3


This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, see
<http://www.gnu.org/licenses/>.
=end

module Gosu
  module Widgets
    class Button
      TEXTCOLOR   = 0xffffffff
      BGCOLOR = 0xffff6666
      BGCOLOR_HL = 0xff0000ff
      BGCOLOR_ACTIVE = 0xff00ff00
      PADDING = 5
      FONT_HEIGHT = 20 # TODO this should be an option of the button

      attr_accessor :text
      attr_accessor :active
      def initialize(window, x, y, text, &callback)
        @window, @x, @y, @text = window, x, y, text
        @font = Gosu::Font.new(@window, Gosu::default_font_name, FONT_HEIGHT)
        @active = false
        @on_click = callback
      end

      def click
        @on_click.call(self)
      end

      # TODO move to proper namespace
      def point_in_box?(x1, y1, x2, y2, xd, yd)
        xd > x1 and xd < x2 and yd > y1 and yd < y2
      end

      def under_point?(xd, yd)
        point_in_box?(x1, y1, x2, y2, xd, yd)
      end

      def width
        box_width  = @font.text_width(@text) + PADDING*2
      end

      def self.height
        box_height = FONT_HEIGHT + PADDING
      end

      def height
        self.class.height
      end

      def x1
        @x
      end

      def x2
        @x+width
      end

      def y1
        @y
      end

      def y2
        @y+height
      end

      def draw
        if @active
          color = BGCOLOR_ACTIVE
        elsif point_in_box?(x1, y1, x2, y2, @window.mouse_x, @window.mouse_y)
          color = BGCOLOR_HL
        else
          color = BGCOLOR
        end

        @window.draw_quad(
                          x1, y1, color,
                          x2, y1, color,
                          x2, y2, color,
                          x1, y2, color
                          )
        @font.draw(@text, @x+PADDING, @y+PADDING, ZOrder::UI, 1.0, 1.0, 0xffffffff)
      end
    end
  end
end
