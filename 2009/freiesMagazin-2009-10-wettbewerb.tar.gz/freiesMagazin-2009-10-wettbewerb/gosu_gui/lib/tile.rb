=begin
robots-gui - freiesMagazin Programmierwettbewerb 10/2009
Copyright 2009 Dominik Honnef <dominikho@gmx.net>
Licence: GPLv3


This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, see
<http://www.gnu.org/licenses/>.
=end

module RobotArena
  class Tile
    WIDTH = HEIGHT = 64

    @tiles = []
    @symbols = []
    @name = 'Tile'
    @image = nil

    attr_reader :row
    attr_reader :column

    def self.inherited(by)
      @tiles << by
    end

    def self.symbols
      @symbols
    end

    def self.name
      @name
    end

    def self.get_tile(symbol)
      @tiles.select { |tile|
        tile.symbols.include? symbol
      }.first
    end

    def name
      self.class.name
    end

    def self.image
      @image
    end

    def image
      self.class.image
    end

    def gosu_image
      @gosu_image ||= Gosu::Image.new(@window, IMAGE_PATH + image)
    end

    def initialize(window, symbol, row, column)
      @window, @symbol, @row, @column = window, symbol, row, column
    end

    def center
      [(WIDTH*@column)+(WIDTH/2), (HEIGHT*@row)+(HEIGHT/2)]
    end

    def draw
      gosu_image.draw(WIDTH*@column, HEIGHT*@row, ZOrder::Gameboard)
    end
  end

  {
    [' ']           => [:Floor, 'floor.png'],
    ['H']           => [:Hole, 'hole.png'],
    ['O']           => [:Oil, 'oil.png'],
    %w(S T U V)     => [:Start, 'floor.png'],
    ['Z']           => [:End, 'finish.png'],
    %w(L R)         => [:Rotate, nil],
    %w(< > ^ v)     => [:ConveryorBelt, nil],
    %w(C D E F)     => [:Pusher, nil],
    %w(M N)         => [:Squeezer, nil],
    ('a'..'p').to_a => [:Wall, nil],
  }.each do |symbols, tile|
    Class.new(Tile) do
      @symbols = symbols
      @name    = tile[0]
      @image   = tile[1]
    end
  end

  Tile.get_tile('a').instance_exec do
    define_method :image do
      # unten oben rechts links
      # -left right up down

      # get the number of the character, convert it into binary, split it
      fields = ("%04d" % (('a'..'p').to_a.index(@symbol).to_s(2))).split('')
      s = "wall-"
      s << (fields[3] == '1' ? 'left'  : '')
      s << (fields[2] == '1' ? 'right' : '')
      s << (fields[1] == '1' ? 'up'    : '')
      s << (fields[0] == '1' ? 'down'  : '')
      s << '.png'
      return s
    end
  end

  Tile.get_tile('C').instance_exec do
    define_method :image do
      s = "pusher-"
      s << case @symbol
           when 'C'
             'left'
           when 'D'
             'right'
           when 'E'
             'up'
           when 'F'
             'down'
           end
      s << ".png"
    end
  end

  Tile.get_tile('M').instance_exec do
    define_method :image do
      s = "squeezer-"
      s << case @symbol
           when 'M'
             'leftright'
           when 'N'
             'updown'
           end
      s << ".png"
    end
  end

  Tile.get_tile('<').instance_exec do
    define_method :image do
      s = "belt-"
      s << case @symbol
           when '<'
             'left'
           when '>'
             'right'
           when '^'
             'up'
           when 'v'
             'down'
           end
      s << ".png"
    end
  end

  Tile.get_tile('L').instance_exec do
    define_method :image do
      s = "rotate-"
      s << case @symbol
           when 'L'
             'left'
           when 'R'
             'right'
           end
      s << ".png"
    end

    # define_method :draw do
    #   rotation = ((Gosu::milliseconds / 360.0/10) % 1) * 360
    #   rotation = -rotation if @symbol == 'L'

    #   gosu_image.draw_rot(Tile::WIDTH*@column + Tile::WIDTH/2, Tile::HEIGHT*@row + Tile::HEIGHT/2, 0, rotation)
    # end
  end

  Tile.get_tile('S').instance_exec do
    define_method :orientation do
      # S,T,U,V - Startfeld für Roboter mit Richtung links, rechts, unten, oben
      case @symbol
      when 'S'
        :left
      when 'T'
        :right
      when 'U'
        :up
      when 'V'
        :down
      end
    end
  end
end
