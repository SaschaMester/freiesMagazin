=begin
robots-gui - freiesMagazin Programmierwettbewerb 10/2009
Copyright 2009 Dominik Honnef <dominikho@gmx.net>
Licence: GPLv3


This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, see
<http://www.gnu.org/licenses/>.
=end

module Gosu
  class RepeatedKeypress
    INTERVAL = 200
    def initialize(keys, *args, &callback)
      @keys = keys
      @callback = callback
      @args = args
      @action = nil
    end

    def check_keydown(key)
      if @keys.include? key
        @action = RepeatedAction.new(INTERVAL, &@callback)
      end
    end

    def check_keyup(key)
      if @keys.include? key
        @action = nil
      end
    end

    def should_call?
      @action and @action.should_call?
    end

    def call
      @action.call(*@args)
    end
  end
end
