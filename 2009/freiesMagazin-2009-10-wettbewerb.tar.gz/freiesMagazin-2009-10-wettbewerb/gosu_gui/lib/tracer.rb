=begin
robots-gui - freiesMagazin Programmierwettbewerb 10/2009
Copyright 2009 Dominik Honnef <dominikho@gmx.net>
Licence: GPLv3


This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, see
<http://www.gnu.org/licenses/>.
=end

module RobotArena
  class Tracer
    COLOR = 0x4400ff33
    attr_reader :percentage
    def initialize(window, tile, direction=:right, percentage = 100)
      @window, @tile, @direction, @percentage = window, tile, direction, percentage
    end

    def percentage=(val)
      val = 100 if val > 100
      @percentage = val
    end

    def draw
      case @direction
      when :right
        mid_x, mid_y = @tile.center
        min_x = mid_x - Tile::WIDTH - Tile::HEIGHT/8
        max_x = min_x + (Tile::WIDTH/100.0)*@percentage
        min_y = mid_y - Tile::HEIGHT/8
        max_y = ((mid_y + Tile::HEIGHT/8))
      when :down
        mid_x, mid_y = @tile.center
        min_x = mid_x - Tile::WIDTH/8
        max_x = mid_x + Tile::WIDTH/8
        min_y = mid_y - Tile::HEIGHT - Tile::WIDTH/8
        max_y = min_y + (Tile::HEIGHT/100.0)*@percentage
      when :left
        mid_x, mid_y = @tile.center
        min_x = mid_x + Tile::WIDTH + Tile::HEIGHT/8
        max_x = min_x - (Tile::WIDTH/100.0)*@percentage
        min_y = mid_y - Tile::HEIGHT/8
        max_y = ((mid_y + Tile::HEIGHT/8))
      when :up
        mid_x, mid_y = @tile.center
        min_x = mid_x - Tile::WIDTH/8
        max_x = mid_x + Tile::WIDTH/8
        min_y = mid_y + Tile::HEIGHT + Tile::WIDTH/8
        max_y = min_y - (Tile::HEIGHT/100.0)*@percentage
      end


      @window.draw_quad(
                        min_x, min_y, COLOR,
                        max_x, min_y, COLOR,
                        max_x, max_y, COLOR,
                        min_x, max_y, COLOR, ZOrder::Tracers
                        )
    end
  end
end
