=begin
robots-gui - freiesMagazin Programmierwettbewerb 10/2009
Copyright 2009 Dominik Honnef <dominikho@gmx.net>
Licence: GPLv3


This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, see
<http://www.gnu.org/licenses/>.
=end

module RobotArena
  class Board
    attr_reader :n_rows
    attr_reader :n_columns

    def initialize(window, text, difficulty='normal')
      #l_index = row(Y)
      #c_index = column(X)

      @board = [[]]
      @n_rows = 0
      @n_columns = 0
      text.split("\n").each_with_index do |line, l_index|
        line.chomp!
        if l_index == 0
          @n_columns, @n_rows = (line.split(' ').map { |i| i.to_i })
          next
        end
        break if l_index > @n_rows
        l_index -= 1
        line.split('').each_with_index do |char, c_index|
          if difficulty == 'easy' and %w(M O H N).include? char
            char = ' '
          end
          (@board[l_index] ||= [])[c_index] = Tile.get_tile(char).new(window, char, l_index, c_index)
        end
      end
    end

    def rows
      @board
    end

    def each
      @board.each { |r| yield r }
    end

    def each_with_index
      @board.each_with_index { |r,i| yield(r,i)}
    end
    alias_method :each_row, :each
  end
end
