#!/usr/bin/env ruby
# -*- coding: utf-8 -*-

=begin
robots-gui - freiesMagazin Programmierwettbewerb 10/2009
Copyright 2009 Dominik Honnef <dominikho@gmx.net>
Licence: GPLv3


This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, see
<http://www.gnu.org/licenses/>.
=end


require 'rubygems'
require 'pathname'
require 'gosu'

require 'lib/rubyext/symbol'
require 'lib/rubyext/object' unless defined?(instance_exec)

require 'lib/board'
require 'lib/bot'
require 'lib/cursor'
require 'lib/tile'
require 'lib/tracer'
require 'lib/button'
require 'lib/button_list'
require 'lib/repeated_action'
require 'lib/repeated_keypress'
require 'lib/fps'

module Gosu
  module Button
    KbAdd = 43
    KbSubtract = 45
  end
end

module RobotArena
  VERSION = '0.0.1'
  module ZOrder
    Background = 1
    Gameboard  = 2
    Tracers    = 3
    Bot        = 4
    UI         = 5
    Cursor     = 6
  end
  # IMAGE_PATH      = Pathname.new("./images/pen/")
  SPEED_MODIFIER  = 1

  class GameWindow < Gosu::Window
    # TODO move to right namespace
    def draw_text(lines, font, x, y, color)
      lines.each do |line|
        font.draw(line, x, y, ZOrder::UI, 1.0, 1.0, color)
        y += 1.1 * font.height
      end
      y
    end

    def write_output(text)
      return unless @output_file
      begin
        @output ||= File.open(@output_file, 'w')
        @output.puts text
      rescue
        @error = :io_error
      end
    end

    def initialize(args)
      @fps = FPS.new(Gosu.milliseconds)
      @difficulties   = { "easy" => "leicht", "normal" => "mittel", "hard" => "schwer" }
      @difficulty     = args[:difficulty]
      @board_file     = Pathname.new(args[:gamefield]).realpath rescue @error = :invalid_file
      @sequence_file  = Pathname.new(args[:sequence] || 'sequence.txt')
      @ccards_file    = Pathname.new(args[:ccards] || 'ccards.txt')
      if args[:output]
        @output_file    = Pathname.new(args[:output])
      end
      @bot_file       = Pathname.new(args[:bot]) if args[:bot]
      @replay         = args[:replay]
      @live           = args[:live]
      @clean          = args[:clean]
      @paused         = args[:paused]
      @cards_file     = args[:cards]
      @theme          = args[:theme] || 'new'
      RobotArena.const_set(:IMAGE_PATH, Pathname.new("./images/#{@theme}/"))
      @speed_modifier = args[:speed_modifier] || SPEED_MODIFIER

      if @sequence_file == @output_file
        puts "You can't read from the same file you write to."
        exit
      end

      super(1024, 768, args[:fullscreen] || false, @live ? 16.666666 : 0)

      self.caption = "robots-gui"
      @font = Gosu::Font.new(self, Gosu::default_font_name, 20)
      @cursor = Cursor.new(self, IMAGE_PATH + 'cursor.png', true)

      @repeated_actions = []
      @repeated_keypresses = []

      @repeated_keypresses << Gosu::RepeatedKeypress.new([Gosu::Button::KbNumpadAdd, Gosu::Button::KbAdd]) do
        @speed_modifier += 1
      end

      @repeated_keypresses << Gosu::RepeatedKeypress.new([Gosu::Button::KbNumpadSubtract, Gosu::Button::KbSubtract]) do
        @speed_modifier -= 1
        if @speed_modifier < 1
          @speed_modifier = 1
        end
      end

      setup_game

      @buttons = Gosu::Widgets::ButtonList.new(self, 780, 100)

      unless @error
        @buttons.add "Pause" do |button|
          @paused = !@paused
          button.text = @paused ? "Start" : "Pause"
        end

        @buttons.add "Neustart" do
          setup_game(true)
        end
      end

      @buttons.add "Beenden" do
        exit
      end
    end

    def check_error_code(code)
      # //  1 = syntax of program call is wrong
      # //  2 = game (field, deck or bot) is not valid
      # //  3 = card deck could not be stored
      # //  4 = game could not be started
      @error = case code
               when 1
                 :wrong_call
               when 2
                 :invalid_file
               when 3
                 :io_error
               when 4
                 :generic
               when 0
                 nil
               else
                 :wtf
               end
    end

    def setup_game(force_clean = false)
      return if @error
      if (@clean or force_clean) and not @replay
        puts "cleaning up"
        %w(ascii-board.txt board.txt bot.txt cards.txt ccards.txt sequence.txt).each { |f| File.delete(f) rescue nil}

        puts "generating game"
        system("./robots-engine load #{@board_file} #{@cards_file} #{@difficulty}")
        return if check_error_code($?.exitstatus)
      end

      return if @error

      @counters = {
        :steps => 0,
        :moves => 0,
        :rotations => 0,
      }

      @current_card = 0

      @bot = Bot.new(self)
      @board = Board.new(self, open(@board_file).read, @difficulty)
      @sequence = []
      if @replay
        @sequence = File.readlines(@sequence_file).map(&:chomp) rescue @error = :invalid_file
      end

      if @bot_file and (x, y, r = File.read(@bot_file).chomp.split(' ') rescue nil)
        start_tile = @board.rows[y.to_i][x.to_i]
        orientation = case r
                      when 'R'
                        :right
                      when 'L'
                        :left
                      when 'U'
                        :up
                      when 'D'
                        :down
                      end
      else
        start_tile = nil
        @board.rows.each { |column|
          column.each { |tile|
            if tile.is_a? Tile.get_tile('S')
              start_tile = tile
              break
            end
          }
          break if start_tile
        }
        orientation = start_tile.orientation
      end
      @bot.rotation = case orientation
                      when :left
                        180
                      when :right
                        0
                      when :down
                        90
                      when :up
                        270
                      end
      @bot.move_to_tile(start_tile)

      @step = nil
      @rotate_by = 0
      @tracers = []
      @game_ended = false
      @new_tile = nil
    end

    def available_cards
      if @replay
        []
      else
        @available_cards ||= File.readlines(@ccards_file).map(&:chomp) rescue []
      end
    end

    def available_steps
      unless @game_ended
        if @sequence.empty?
          if @replay
            puts "Game ended prematurely."
            @game_ended = :prematurely
            return []
          end
          puts "calling engine"
          @available_cards = nil
          @current_card = 0
          system("./robots-engine start #{@difficulty}")
          return [] if check_error_code($?.exitstatus)
          write_output  "--------" if not @replay
          @sequence = File.readlines(@sequence_file).map(&:chomp)
        end
        return @sequence
      end
      puts "game ended"
      []
    end

    def next_step
      step = available_steps.shift
      unless %w(ML MR MU MD RL RU RR X Y Z ---- --).include? step
        puts "Skipping unknown step #{step}"
        return nil
      end
      puts "got step #{step}"
      return step
    end

    def update
      @fps.tick(Gosu.milliseconds)
      return if @error
      @repeated_actions.select(&:should_call?).each(&:call)
      @repeated_keypresses.select(&:should_call?).each(&:call)

      return if @paused
      if not @step and not @game_ended
        @step = next_step
        return unless @step
        write_output @step if not @replay
        @counters[:steps] += 1 unless @step =~ /^(-+|[XYZ])$/
        cur_tile = @bot.tile
        new_row, new_col = cur_tile.row, cur_tile.column
        tracer_direction = nil

        if (%w(X Y Z).include? @step) or @step.strip.empty?
          @game_ended = case @step
                        when 'X'
                          :died
                        when 'Z'
                          :won
                        when 'Y'
                          :no_cards_left
                        end
          @step = nil
          return nil
        elsif %w(ML MR MU MD).include? @step
          case @step
          when 'ML'
            new_col -= 1
            tracer_direction = :left
          when 'MR'
            new_col += 1
            tracer_direction = :right
          when 'MU'
            new_row -= 1
            tracer_direction = :up
          when 'MD'
            new_row += 1
            tracer_direction = :down
          end

          @counters[:moves] += 1

          unless new_row < 0 or new_row > @board.n_rows-1 or new_col < 0 or new_col > @board.n_columns-1
            @new_tile = @board.rows[new_row][new_col]
            @tracers << Tracer.new(self, @new_tile, tracer_direction, 0)
          else
            @step = nil
          end
        elsif %w(RL RR RU).include? @step
          case @step
          when 'RL'
            @rotate_by = [-90, :-]
          when 'RR'
            @rotate_by  = [90, :+]
          when 'RU'
            @rotate_by  = [180, :+]
          end
          @counters[:rotations] += 1
        elsif @step == '----'
          # moved on a card
          @current_card += 1
          @step = nil
        elsif @step == '--'
          @step = nil
        end
      end

      if @rotate_by[0] != 0
        if not @live
          @bot.rotate @rotate_by[0]
          @rotate_by[0] = 0
        else
          unary_operator = (@rotate_by[1].to_s + "@").to_sym
          rot_amount = 1.send(unary_operator) * @speed_modifier
          if rot_amount > @rotate_by[0].send(unary_operator)
            rot_amount = @rotate_by[0]
            @rotate_by[0] = 0
          else
            other_operator = [:+, :-]
            other_operator.delete @rotate_by[1]
            @rotate_by[0] = @rotate_by[0].send(other_operator.first, @speed_modifier)
          end
          @bot.rotate rot_amount
        end
        if @rotate_by[0] == 0
          @step = nil
        end
      end

      if @new_tile
        if not @live
          @bot.move_to_tile(@new_tile)
          @tracers[-1].percentage = 100
          @new_tile = nil
          @step = nil
        else
          cur_x = @bot.x
          cur_y = @bot.y
          new_x, new_y = @new_tile.center
          off_x = off_y = 0
          distance = Gosu.distance(cur_x, cur_y, new_x, new_y)
          pc = ((Tile::WIDTH-distance) / Tile::WIDTH) * 100
          @tracers[-1].percentage = pc

          if cur_x < new_x
            off_x = 1 * @speed_modifier
            off_x = new_x-cur_x if off_x+cur_x >= new_x
          elsif cur_x > new_x
            off_x = -1 * @speed_modifier
            off_x = -(cur_x-new_x) if off_x+cur_x <= new_x
          end

          if cur_y < new_y
            off_y = 1 * @speed_modifier
            off_y = new_y-cur_y if off_y+cur_y >= new_y
          elsif cur_y > new_y
            off_y = -1 * @speed_modifier
            off_y = -(cur_y-new_y) if off_y+cur_y <= new_y
          end

          @bot.move(cur_x+off_x, cur_y+off_y)

          if off_x == 0 and off_y == 0
            @bot.tile = @new_tile
            @new_tile = nil
            @step     = nil
          end
        end
      end
    end

    def draw
      @cursor.draw
      @buttons.draw
      if @error
        error_text = case @error
                     when :wrong_call
                       "Falscher Programmauf. Das sollte eigentlich nicht passieren!"
                     when :invalid_file
                       "Spielfeld, Kartenstapel oder Bot-Datei sind nicht korrekt."
                     when :io_error
                       "Fehler beim Schreiben. Überprüfe Rechte zum Schreiben und Speicherplatz."
                     when :generic
                       "Spiel konnte nicht gestartet werden."
                     when :wtf
                       "Wie sind wir denn hier gelandet? Böser Fehler, bitte die Entwickler kontaktieren."
                     end
        @font.draw("Fehler: #{error_text}", 200, 400, ZOrder::UI, 1.0, 1.0, 0xffff0000)
        return
      end

      if @live or @game_ended
        @bot.draw

        @board.each do |row|
          row.each do |tile|
            tile.draw
          end
        end

        @tracers.each(&:draw)

        status = ""
        if @paused
          status = "Unterbrochen"
        elsif @new_tile
          status = "Bewegend"
        elsif @rotate_by[0] != 0
          status = "Drehend"
        elsif @game_ended
          status = case @game_ended
                   when :died
                     "Zerstört"
                   when :prematurely
                     "Vorzeitiges Ende"
                   when :won
                     "Gewonnen"
                   when :no_cards_left
                     "Keine Karten übrig"
                   else
                     "Huh?"
                   end
        else
          status = "Wartend"
        end
      else
        @font.draw("Berechnung läuft, bitte warten ...", 400, 400, ZOrder::UI, 1.0, 1.0, 0xffffffff)
      end

      lines = ["Fps: #{@fps.to_i}",
               "",
               "Bewegungen: #{@counters[:moves]}",
               "Drehungen: #{@counters[:rotations]}",
               "Gesamt: #{@counters[:steps]}",
               "",
               "Geschwindigkeit: #{@speed_modifier}",
               "Wiederholung: #{@replay ? "Ja" : "Nein"}",
               "Spielfeld: #{File.basename(@board_file)}",
              ]

      lines << "Karten: #{@cards_file.empty? ? '<Zufall>' : File.basename(@cards_file)}" if not @replay
      lines << "Schwierigkeit: #{@difficulties[@difficulty]}" <<  "" << "Status: #{status}"

      unless @replay
        lines << "Karten:"
        ccards = available_cards.dup
        ccards[@current_card] = ">> " + ccards[@current_card] + " <<" unless ccards.empty?
        lines.concat ccards
      end


      y = draw_text(
                    lines,
                    @font, 780, 200, 0xffffffff
                    )
    end

    def button_down(id)
      @repeated_keypresses.each { |k| k.check_keydown(id)}
      case id
      when Gosu::Button::KbL
        @live = !@live
      when Gosu::Button::KbEscape, Gosu::Button::KbQ
        close
      when Gosu::Button::KbR
        setup_game(true)
      when Gosu::MsLeft
        @button = @buttons.find { |b| b.under_point?(mouse_x, mouse_y)}
        if @button
          @button.active = true
        end
      when Gosu::Button::KbP
        @paused = !@paused
      end
    end

    def button_up(id)
      @repeated_keypresses.each { |k| k.check_keyup(id)}
      case id
      when Gosu::MsLeft
        if @button
          @button.active = false
          if @button.under_point?(mouse_x, mouse_y)
            @button.click
          end
          @button = nil
        end
      end
    end
  end
end

require 'optparse'
include RobotArena

options = {
  :difficulty => 'normal',
  :replay     => false,
  :clean      => false,
  :live       => true,
  :paused     => false,
  :cards      => '',
  :output     => nil,
  :fullscreen => false,
}
opts = OptionParser.new do |opts|
  opts.banner = "Usage: robots-gui --gamefield FILE --sequence-file FILE [options]"

  opts.on("-v", "--version") do
    puts "robots-gui v#{RobotArena::VERSION}"
    exit
  end

  opts.on("-g", "--gamefield FILE", "The gamefield to display.") do |file|
    options[:gamefield] = file
  end

  opts.on("-d", "--difficulty LEVEL", "The difficulty of the game. Only needed with --no-replay. One of ['easy', 'normal', 'hard']") do |level|
    options[:difficulty] = level
  end

  opts.on("-s", "--sequence FILE",
          "The sequence file to interpret. If --no-replay, it will be generated dynamically, otherwise it has to already exist.") do |file|
    options[:sequence] = file
  end

  opts.on("-b", "--bot FILE", "Load the bot position from this file. Only needed for continueing an interrupted game.") do |file|
    options[:bot] = file
  end

  opts.on("-r", "--[no-]replay",
          "Use --replay if the sequence file is one complete game.
If false, the game engine is called repeatedly until the game ends.
") do |r|
    options[:replay] = r
  end

  opts.on("-l", "--[no-]live", "If false, the game won't be animated.") do |l|
    options[:live] = l
  end

  opts.on("-c", "--[no-]clean",
          "If true, the following files will be deleted before the first engine invocation: ascii-board.txt board.txt bot.txt cards.txt ccards.txt sequence.txt") do |c|
    options[:clean] = c
  end

  opts.on("-p", "--[no-]pause", "Start paused.") do |p|
    options[:paused] = p
  end

  opts.on("-m", "--speed-modifier SPEED", "The speed to run with.") do |s|
    options[:speed_modifier] = s.to_i
  end

  opts.on("-a", "--cards FILE", "A carddeck") do |a|
    options[:cards] = a
  end

  opts.on('--A', '--ccards FILE', 'The file containing the chosen cards.') do |file|
    options[:ccards] = file
  end


  opts.on("-o", "--output FILE", "A file to save the complete sequence in. If none specified, none will be written") do |f|
    options[:output] = f
  end

  opts.on("--theme THEME", "The graphics theme to use.") do |t|
    options[:theme] = t
  end

  opts.on_tail("-h", "--help", "Show this message") do
    puts opts
    exit
  end

  opts.on("-f", "--[no-]fullscreen", "Use fullscreen? Doesn't properly work on multihead setups.") do |f|
    options[:fullscreen] = f
  end

  opts.parse(ARGV)
end

if !options[:replay]
  options[:sequence] = nil
end

if options[:gamefield].nil? or (options[:replay] and options[:sequence].nil?)
  p options
  puts opts
  exit
end



window = GameWindow.new(options)
window.show
