// *************************************************************************
// robots-contest - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <string>
#include <cstdlib>

#include "bot.hh"
#include "carddeck.hh"
#include "sequence.hh"
#include "stats.hh"

void printSyntax( const std::string& call )
{
        std::cout << "\nSyntax is: "
                  << call
                  << " BOARDNAME DECKNAME [easy|normal|hard]\n"
                  << "    start complete game until cards are finished"
                  << " bot is dead or has reached finish.\n"
                  << std::endl;
}

void printData()
{
    Bot bot;
    CardDeck deck;
    
    if ( deck.load( "ccards.txt" ) && bot.load( "bot.txt" ) )
    {
        std::cout << "Bot: "
                  << bot.getPos().x() << " "
                  << bot.getPos().y() << " "
                  << (int)bot.getViewDirection() << " ";

        std::cout << "Deck: ";

        for ( unsigned int kk = 0; kk < deck.size(); kk++ )
        {
            std::cout << deck[kk]->print() << " ";
        }

        std::cout << std::endl;
    }
}


int startGame( const std::string& loadCall, const std::string& startCall )
{
    int retValue = 0;

    // load game board and deck one time
    if ( !system( loadCall.c_str() ) )
    {
        // global sequence with all movements
        Sequence globalSeq;
        
        // create new statistics
        // an old file be deleted
        Stats stats( "stats.txt", true );
    
            // flag that game has finished (bot destroyed, has reached end
        // or no cards)
        bool gameFinished = false;

        // start game until finished
        do
        {
            if ( !system( startCall.c_str() ) )
            {
                // print all data from the KI in stdout
                // printData();

                // local sequence with one move only
                Sequence localSeq;

                if ( localSeq.load( "sequence.txt") )
                {
                    // std::cout << "Sequence loaded. Size "
                              // << localSeq.size() << std::endl;
                    
                    if ( 0 < localSeq.size() )
                    {
                        // add sequence to global sequence
                        globalSeq.append( localSeq );

                        // check if last sequence entry is
                        // that the bot is destroyed or has reached the
                        // finish
                        
                        // std::cout << localSeq.back() << std::endl;
                        if ( "Z" == localSeq.back() ||
                             "Y" == localSeq.back() ||
                             "X" == localSeq.back() )
                        {
                            gameFinished = true;
                        }
                        else
                        {
                            // add separator for each round
                            globalSeq.append( "--------" );
                        }
                    }
                }
                else
                {
                    std::cerr << "Error: Loading of "
                              << "sequence.txt"
                              << " failed."
                              << std::endl;
                    retValue = 4;
                }
            }
            else
            {
                std::cerr << "Error: Call of "
                          << loadCall.c_str()
                          << " failed."
                          << std::endl;
                retValue = 3;
            }

        } while ( 0 == retValue && false == gameFinished );

        if ( 0 == retValue && true == gameFinished )
        {
            // load statistics
            stats.load();
            // stats.print();

            std::cout << "Game is finished. "
                      << "Robot ";

            if ( "Z" == globalSeq.back() )
            {
                std::cout << "has reached finish";
            }
            else if ( "X" == globalSeq.back() )
            {
                std::cout << "is destroyed";
            }
            else if ( "Y" == globalSeq.back() )
            {
                std::cout << "is out of order because of no cards";
            }
            
            std::cout << " after "
                      << stats.get( Stats::SE_NUM_ROUNDS )
                      << " round(s), "
                      << stats.get( Stats::SE_NUM_PLAYED_CARDS )
                      << " card(s) and "
                      << stats.get( Stats::SE_NUM_CARD_MOVES )
                      << " + "
                      << stats.get( Stats::SE_NUM_BOARD_MOVES )
                      << " = "
                      << stats.get( Stats::SE_NUM_CARD_MOVES ) +
                         stats.get( Stats::SE_NUM_BOARD_MOVES )
                      << " move(s)."
                      << std::endl;
        }
        
        // add sequence to global sequence
        globalSeq.save( "globalseq.txt" );
    }
    else
    {
        std::cerr << "Error: Call of "
                  << loadCall.c_str()
                  << " failed."
                  << std::endl;
        retValue = 2;
    }

    return retValue;
}

// Error codes:
// 0 = okay
// 1 = wrong syntax
// 2 = load call failed
// 3 = start call failed
// 4 = sequence.txt not loaded

int main( int argc, char *argv[] )
{
    int retValue = 0;
    
    // the contest can only be started by the call:
    // ./robots-contest BOARDNAME DECKNAME [easy|normal|hard]
    
    if ( 3 == argc || 4 == argc )
    {
        // try to extract optional game level
        std::string level( "normal" );
        
        if ( 4 == argc )
        {
            // get last argument
            level = argv[argc-1];
        }
        
        // set game level
        if ( "easy" == level || 
             "normal" == level ||
             "hard" == level )
        {
            std::string loadCall( "./robots-engine load " );
            loadCall += argv[1];
            loadCall += " ";
            loadCall += argv[2];

            std::cout << loadCall << std::endl;
            
            std::string startCall( "./robots-engine start " );
            startCall += level;
                                    
            std::cout << startCall << std::endl;
            
            retValue = startGame( loadCall, startCall );
        }
        else
        {
            printSyntax( argv[0] );
            retValue = 1;
        }
    }
    else
    {
        printSyntax( argv[0] );
        retValue = 1;
    }        

    return retValue;
}
