// *************************************************************************
// robots-ki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <string>

#include "carddeck.hh"
#include "basefunctions.hh"

int main( int argc, char *argv[] )
{
    int retValue = 0;

    if ( 2 == argc )
    {
        // try to extract optional game level
        std::string level( "normal" );
        level = argv[1];
        BaseFunctions::setGameLevel( level );
    }
    // ignore other arguments or when level is incorrect
    
    CardDeck deck;
    
    if ( deck.load( "cards.txt" ) )
    {
        if ( deck.size() == 8 )
        {
            CardDeck newDeck;

            // create new deck with first 5 cards
            if ( deck.getCards( newDeck, 5 ) )
            {
                // save new deck
                if ( newDeck.save( "ccards.txt" ) )
                {
                    retValue = 0;
                }
                else
                {
                    std::cout << "Error: Saving ccard.txt failed."
                              << std::endl;
                    retValue = 4;
                }
            }
            else
            {
                std::cout << "Error: Could not get 5 cards from deck."
                          << std::endl;
                
                retValue = 3;
            }
        }
        else
        {
            std::cout << "Error: Number of cards "
                      << deck.size()
                      << " does not equal 8."
                      << std::endl;
            
            retValue = 2;
        }
    }
    else
    {
        std::cout << "Error: Loading card.txt failed."
                  << std::endl;
        retValue = 1;
    }
    
    return retValue;
}
