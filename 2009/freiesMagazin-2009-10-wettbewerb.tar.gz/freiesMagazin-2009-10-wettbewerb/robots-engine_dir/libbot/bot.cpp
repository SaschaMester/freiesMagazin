// *************************************************************************
// robots-engine / libbot - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <cstdlib>

#include "bot.hh"
#include "botfunctions.hh"

// Default constructor.
Bot::Bot()
: m_pos(0,0), m_view( BE_VIEW_DIRECTION_RIGHT ), m_destroyed(false),
  m_finish(false)
{
    m_lastMove = BE_DIRECTION_NONE;
    m_lastRotation = BE_ROTATION_NONE;
}

// Constructor with given position and view direction
// There is no check for validity!
Bot::Bot( const Position& pos, const BotEnumViewDirection view )
: m_pos(pos), m_view(view), m_destroyed(false),  m_finish(false)
{
    m_lastMove = BE_DIRECTION_NONE;
    m_lastRotation = BE_ROTATION_NONE;
}

// Save tile to stream
// as ascii with several chars.
// The line may be 0-2 and says in which line we are.
// return true if everything is okay
const bool Bot::saveExtendedAscii( std::ofstream& outFile,
                                   const int line ) const

{
    bool ok = false;

    if ( line >= 0 && line < 3 )
    {
        if ( outFile.good() )
        {
            ok = saveExtendedAsciiInternal( outFile, line );
        }
    }

    return ok;
}

// Save tile to stream
const bool Bot::saveExtendedAsciiInternal( std::ofstream& outFile,
                                           const int line ) const
{
    bool ok = true;

    switch ( m_view )
    {
        case BE_VIEW_DIRECTION_LEFT:
            switch ( line )
            {
                case 0:
                    outFile << " /   ";
                    break;
                case 1:
                    outFile << "-----";
                    break;
                case 2:
                    outFile << " \\   ";
                    break;
                default:
                    ok = false;
                    break;
            }
            break;
        case BE_VIEW_DIRECTION_RIGHT:
            switch ( line )
            {
                case 0:
                    outFile << "   \\ ";
                    break;
                case 1:
                    outFile << "-----";
                    break;
                case 2:
                    outFile << "   / ";
                    break;
                default:
                    ok = false;
                    break;
            }
            break;
        case BE_VIEW_DIRECTION_UP:
            switch ( line )
            {
                case 0:
                    outFile << " /|\\ ";
                    break;
                case 1:
                    outFile << "/ | \\";
                    break;
                case 2:
                    outFile << "  |  ";
                    break;
                default:
                    ok = false;
                    break;
            }
            break;
        case BE_VIEW_DIRECTION_DOWN:
            switch ( line )
            {
                case 0:
                    outFile << "  |  ";
                    break;
                case 1:
                    outFile << "\\ | /";
                    break;
                case 2:
                    outFile << " \\|/ ";
                    break;
                default:
                    ok = false;
                    break;
            }
            break;
        default:
            ok = false;
            break;

    }

    return ok;
}

// save bot data to disk
// return true if everything is okay
const bool Bot::saveInternal( std::ofstream& outFile ) const
{
    bool ok = false;

    if ( outFile.good() )
    {
        outFile << getPosAndViewAsString().c_str();
        outFile << std::endl;
        ok = true;
    }

    return ok;
}

// save bot data to disk
// return true if everything is okay
const bool Bot::save( const std::string& filename ) const
{
    bool ok = false;

    if ( !filename.empty() )
    {
        std::ofstream outFile;

        outFile.open( filename.c_str(), std::ios::out );

        if ( outFile.good() )
        {
            ok = saveInternal( outFile );
        }
        else
        {
            std::cerr << "Bot::save(string) "
                      << "Error: File "
                      << filename.c_str()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "Bot::save(string) "
                  << "Error: Filename is empty."
                  << std::endl;
    }

    return ok;
}

// load bot data from disk
// return true if everything is okay
const bool Bot::load( const std::string& filename )
{
    bool ok = false;

    if ( !filename.empty() )
    {
        std::ifstream inFile;

        inFile.open( filename.c_str(), std::ios::in );

        if ( inFile.good() )
        {
            char cstr[10];

            // read line
            inFile.getline( cstr, 10 );

            // create string
            std::string str2(cstr);

            // search two spaces
            const unsigned int pos1 = str2.find ( ' ', 0 );
            const unsigned int pos2 = str2.find ( ' ', pos1+1 );

            if ( std::string::npos != pos1 &&
                 std::string::npos != pos2 )
            {
                // extract positions
                const std::string strX = str2.substr( 0, pos1 );
                const std::string strY = str2.substr( pos1+1, pos2 );

                const int x = atoi( strX.c_str() );
                const int y = atoi( strY.c_str() );

                if ( x >=0 && y>=0 )
                {
                    // extract view direction
                    const std::string strV = str2.substr( pos2+1, str2.length()-pos2 );

                    if ( "L" == strV || "R" == strV ||
                         "U" == strV || "D" == strV )
                    {
                        // store view direction
                        if ( "L" == strV )
                        {
                            m_view = BE_VIEW_DIRECTION_LEFT;
                        }
                        else if ( "R" == strV )
                        {
                            m_view = BE_VIEW_DIRECTION_RIGHT;
                        }
                        else if ( "U" == strV )
                        {
                            m_view = BE_VIEW_DIRECTION_UP;
                        }
                        else if ( "D" == strV )
                        {
                            m_view = BE_VIEW_DIRECTION_DOWN;
                        }

                        // store position
                        m_pos.set( x, y );

                        ok = true;
                    }
                    else
                    {
                        std::cerr << "Bot::load(string) "
                                  << "Error: View direction "
                                  << strV.c_str()
                                  << " is unknown."
                                  << std::endl;
                    }
                }
                else
                {
                    std::cerr << "Bot::load(string) "
                              << "Error: Position ("
                              << x
                              << ", "
                              << y
                              << ") is not valid."
                              << std::endl;
                }
            }
            else
            {
                std::cerr << "Bot::load(string) "
                          << "Error: Syntax of line \""
                          << str2.c_str()
                          << "\" in file "
                          << filename.c_str()
                          << " is not correct."
                          << std::endl;
            }
        }
        else
        {
            std::cerr << "Bot::load(string) "
                      << "Error: File "
                      << filename.c_str()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "Bot::load(string) "
                  << "Error: Filename is empty."
                  << std::endl;
    }

    return ok;
}

// return true if robot would leave board after movement
const bool Bot::wouldLeaveBoard ( const SeqString& move,
                                  const unsigned int width,
                                  const unsigned int height ) const
{
    Position newPos;
    const bool leave = !getNewPos( newPos, move, width, height );
    return leave;
}

// return new position if the bot would move into some direction
const bool Bot::getNewPos( Position& newPos,
                           const SeqString& move,
                           const unsigned int width,
                           const unsigned int height ) const
{
    bool ok = false;

    // set old position
    newPos = m_pos;

    if ( "MF" == move || "MB" == move )
    {
        switch ( m_view )
        {
            case BE_VIEW_DIRECTION_LEFT:
                if ( "MF" == move && m_pos.x()>0 )
                {
                    newPos.set( m_pos.x()-1, m_pos.y() );
                    ok = true;
                }
                else if ( "MB" == move && m_pos.x()<width-1 )
                {
                    newPos.set( m_pos.x()+1, m_pos.y() );
                    ok = true;
                }
                break;
            case BE_VIEW_DIRECTION_RIGHT:
                if ( "MB" == move && m_pos.x()>0 )
                {
                    newPos.set( m_pos.x()-1, m_pos.y() );
                    ok = true;
                }
                else if ( "MF" == move && m_pos.x()<width-1 )
                {
                    newPos.set( m_pos.x()+1, m_pos.y() );
                    ok = true;
                }
                break;
            case BE_VIEW_DIRECTION_UP:
                if ( "MF" == move && m_pos.y()>0 )
                {
                    newPos.set( m_pos.x(), m_pos.y()-1 );
                    ok = true;
                }
                else if ( "MB" == move && m_pos.y()<height-1 )
                {
                    newPos.set( m_pos.x(), m_pos.y()+1 );
                    ok = true;
                }
                break;
            case BE_VIEW_DIRECTION_DOWN:
                if ( "MB" == move && m_pos.y()>0 )
                {
                    newPos.set( m_pos.x(), m_pos.y()-1 );
                    ok = true;
                }
                else if ( "MF" == move && m_pos.y()<height-1 )
                {
                    newPos.set( m_pos.x(), m_pos.y()+1 );
                    ok = true;
                }
                break;
            default:
                break;
        }
    }
    else if ( "ML" == move && m_pos.x() > 0 )
    {
        // move left
        newPos.set( m_pos.x()-1, m_pos.y() );
        ok = true;
    }
    else if ( "MR" == move && m_pos.x() < width-1 )
    {
        // move right
        newPos.set( m_pos.x()+1, m_pos.y() );
        ok = true;
    }
    else if ( "MU" == move && m_pos.y() > 0 )
    {
        // move up
        newPos.set( m_pos.x(), m_pos.y()-1 );
        ok = true;
    }
    else if ( "MD" == move && m_pos.y() < height-1 )
    {
        // move down
        newPos.set( m_pos.x(), m_pos.y()+1 );
        ok = true;
    }

    return ok;
}

// return new view direction if the bot would rotate into some direction
const bool Bot::getNewViewDirection( BotEnumViewDirection& newView,
                                     const SeqString& move) const
{
    bool ok = false;

    if ( "RL" == move )
    {
        // rotate left
        switch ( m_view )
        {
            case BE_VIEW_DIRECTION_LEFT:
                newView = BE_VIEW_DIRECTION_DOWN;
                ok = true;
                break;
            case BE_VIEW_DIRECTION_RIGHT:
                newView = BE_VIEW_DIRECTION_UP;
                ok = true;
                break;
            case BE_VIEW_DIRECTION_UP:
                newView = BE_VIEW_DIRECTION_LEFT;
                ok = true;
                break;
            case BE_VIEW_DIRECTION_DOWN:
                newView = BE_VIEW_DIRECTION_RIGHT;
                ok = true;
                break;
            default:
                break;
        }
    }
    else if ( "RR" == move )
    {
        // rotate right
        switch ( m_view )
        {
            case BE_VIEW_DIRECTION_LEFT:
                newView = BE_VIEW_DIRECTION_UP;
                ok = true;
                break;
            case BE_VIEW_DIRECTION_RIGHT:
                newView = BE_VIEW_DIRECTION_DOWN;
                ok = true;
                break;
            case BE_VIEW_DIRECTION_UP:
                newView = BE_VIEW_DIRECTION_RIGHT;
                ok = true;
                break;
            case BE_VIEW_DIRECTION_DOWN:
                newView = BE_VIEW_DIRECTION_LEFT;
                ok = true;
                break;
            default:
                break;
        }
    }
    else if ( "RU" == move )
    {
        // u-turn
        switch ( m_view )
        {
            case BE_VIEW_DIRECTION_LEFT:
                newView = BE_VIEW_DIRECTION_RIGHT;
                ok = true;
                break;
            case BE_VIEW_DIRECTION_RIGHT:
                newView = BE_VIEW_DIRECTION_LEFT;
                ok = true;
                break;
            case BE_VIEW_DIRECTION_UP:
                newView = BE_VIEW_DIRECTION_DOWN;
                ok = true;
                break;
            case BE_VIEW_DIRECTION_DOWN:
                newView = BE_VIEW_DIRECTION_UP;
                ok = true;
                break;
            default:
                break;
        }
    }

    return ok;
}

// move or rotate robot
void Bot::move( const SeqString& seq,
                const unsigned int width,
                const unsigned int height )
{
    // std::cout << "Move Bot: "; print();
    // std::cout << " Sequence: " << seq.c_str();
    // std::cout << " w: " << width << " h: " << height << std::endl;

    if ( !isDestroyed() )
    {
        if ( "MF" == seq || "MB" == seq || "ML" == seq ||
             "MR" == seq || "MU" == seq || "MD" == seq )
        {
            Position newPos;

            if ( getNewPos( newPos, seq, width, height ) )
            {
                // get moving direction
                m_lastMove = BotFunctions::convertToDirection( seq, m_view );
                m_lastRotation = BotFunctions::convertToRotation ( seq );

                // set new pos
                m_pos = newPos;
            }
            else
            {
                std::cerr << "Bot::move(string,uint,uint) "
                          << "Error: Movement "
                          << seq.c_str()
                          << " is not possible."
                          << std::endl;
            }
        }
        else if ( "RL" == seq || "RR" == seq || "RU" == seq )
        {
            BotEnumViewDirection newView;

            if ( getNewViewDirection( newView, seq ) )
            {
                // get moving direction
                m_lastMove = BotFunctions::convertToDirection( seq, m_view );
                m_lastRotation = BotFunctions::convertToRotation ( seq );

                // set new view
                m_view = newView;
            }
            else
            {
                std::cerr << "Bot::move(string,uint,uint) "
                          << "Error: Rotation "
                          << seq.c_str()
                          << " is not possible."
                          << std::endl;
            }
        }
        else if ( "X" == seq )
        {
            // robot is dead
            m_destroyed = true;
        }
        else if ( "Z" == seq )
        {
            // robot is finished
            m_finish = true;
        }
        else
        {
            std::cerr << "Bot::move(string,uint,uint) "
                      << "Error: Movement "
                      << seq.c_str()
                      << " is unknown."
                      << std::endl;
        }
    }

    // std::cout << "After Move Bot: "; print(); std::cout << std::endl;
}

// move or rotate robot with whole sequence
void Bot::move( const Sequence& seq,
                const unsigned int width,
                const unsigned int height )
{
    for ( unsigned int i = 0; i < seq.size(); i++ )
    {
        move( seq[i], width, height );
    }
}

// store position and view direction
void Bot::getStartSequence( Sequence& seq ) const
{
    SeqString str("S ");
    str += getPosAndViewAsString();
    seq.push_back( str );
}

// store position and view direction
void Bot::getEndSequence( Sequence& seq ) const
{
    SeqString str("E ");
    str += getPosAndViewAsString();
    seq.push_back( str );
}

// get position and view direction as string
const std::string Bot::getPosAndViewAsString() const
{
    std::string str;

    // store position and view
    char cstr[100];

    // convert number to string
    sprintf(cstr, "%d", m_pos.x());
    str += cstr;
    str += " ";

    sprintf(cstr, "%d", m_pos.y());
    str += cstr;
    str += " ";

    switch ( m_view )
    {
        case BE_VIEW_DIRECTION_LEFT:
            str += "L";
            break;
        case BE_VIEW_DIRECTION_RIGHT:
            str += "R";
            break;
        case BE_VIEW_DIRECTION_UP:
            str += "U";
            break;
        case BE_VIEW_DIRECTION_DOWN:
            str += "D";
            break;
        default:
            break;
    }

    return str;
}

// set new bot view direction
void Bot::setView( const BaseEnumDirection view )
{
    switch ( view )
    {
        case BE_DIRECTION_LEFT:
            m_view = BE_VIEW_DIRECTION_LEFT;
            break;
        case BE_DIRECTION_RIGHT:
            m_view = BE_VIEW_DIRECTION_RIGHT;
            break;
        case BE_DIRECTION_UP:
            m_view = BE_VIEW_DIRECTION_UP;
            break;
        case BE_DIRECTION_DOWN:
            m_view = BE_VIEW_DIRECTION_DOWN;
            break;
        default:
            std::cerr << "Bot::setView(view) "
                      << "Error: View "
                      << view
                      << " is unknown."
                      << std::endl;
            break;
    }

}

// print bot data
void Bot::print() const
{
    std::cout << m_pos.x() << " "
              << m_pos.y() << " "
              << (int)m_view;
}
