// *************************************************************************
// robots-engine / libbot - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "botfunctions.hh"
#include "basefunctions.hh"

const BaseEnumDirection BotFunctions::convertToDirection( const std::string& str,
                                                          const BotEnumViewDirection dir )
{
    BaseEnumDirection move = BE_DIRECTION_NONE;

    if ( "ML" == str || "MR" == str || "MU" == str || "MD" == str )
    {
        move = BaseFunctions::convertToDirection( str );
    }
    else if ( "MF" == str )
    {
        move = convertToDirection( dir );
    }
    else if ( "MB" == str )
    {
        move = convertToOppositeDirection( dir );
    }

    return move;
}

const BaseEnumRotation BotFunctions::convertToRotation( const std::string& str )
{
    return BaseFunctions::convertToRotation( str );
}

// convert from bot movement to global movement
const SeqString BotFunctions::convertToSequenceString( const SeqString& str,
                                                       const BotEnumViewDirection dir )
{
    SeqString seqStr;

    if ( "MF" == str )
    {
        switch ( dir )
        {
            case BE_VIEW_DIRECTION_LEFT:
                seqStr = "ML";
                break;
            case BE_VIEW_DIRECTION_RIGHT:
                seqStr = "MR";
                break;
            case BE_VIEW_DIRECTION_UP:
                seqStr = "MU";
                break;
            case BE_VIEW_DIRECTION_DOWN:
                seqStr = "MD";
                break;
            default:
                break;
         }
    }
    else if ( "MB" == str )
    {
        switch ( dir )
        {
            case BE_VIEW_DIRECTION_LEFT:
                seqStr = "MR";
                break;
            case BE_VIEW_DIRECTION_RIGHT:
                seqStr = "ML";
                break;
                break;
            case BE_VIEW_DIRECTION_UP:
                seqStr = "MD";
                break;
            case BE_VIEW_DIRECTION_DOWN:
                seqStr = "MU";
                break;
            default:
                break;
         }
    }
    else
    {
        seqStr = str;
    }

    return seqStr;
}

// convert bot view direction to base direction
const BaseEnumDirection BotFunctions::convertToDirection( const BotEnumViewDirection dir )
{
    BaseEnumDirection move = BE_DIRECTION_NONE;

    switch ( dir )
    {
        case BE_VIEW_DIRECTION_LEFT:
            move = BE_DIRECTION_LEFT;
            break;
        case BE_VIEW_DIRECTION_RIGHT:
            move = BE_DIRECTION_RIGHT;
            break;
        case BE_VIEW_DIRECTION_UP:
            move = BE_DIRECTION_UP;
            break;
        case BE_VIEW_DIRECTION_DOWN:
            move = BE_DIRECTION_DOWN;
            break;
        default:
            break;
    }

    return move;
}


// convert bot view direction to base direction
const BaseEnumDirection BotFunctions::convertToOppositeDirection( const BotEnumViewDirection dir )
{
    BaseEnumDirection move = BE_DIRECTION_NONE;

    switch ( dir )
    {
        case BE_VIEW_DIRECTION_LEFT:
            move = BE_DIRECTION_RIGHT;
            break;
        case BE_VIEW_DIRECTION_RIGHT:
            move = BE_DIRECTION_LEFT;
            break;
        case BE_VIEW_DIRECTION_UP:
            move = BE_DIRECTION_DOWN;
            break;
        case BE_VIEW_DIRECTION_DOWN:
            move = BE_DIRECTION_UP;
            break;
        default:
            break;
    }

    return move;
}
