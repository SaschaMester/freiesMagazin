// *************************************************************************
// robots-engine / libbot - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef BOT_HH
#define BOT_HH

#include <string>
#include <fstream>

#include "baseenums.hh"
#include "position.hh"
#include "sequence.hh"
#include "botenums.hh"

class Bot
{
public:
    // Default constructor.
    Bot();
    
    // Constructor with given position and view direction
    // There is no check for validity!
    Bot( const Position& pos, const BotEnumViewDirection view );

    // Save bot to stream
    // as ascii with several chars.
    // The line may be 0-2 and says in which line we are.
    // return true if everything is okay
    const bool saveExtendedAscii( std::ofstream& outFile,
                                  const int line ) const;

    // save bot data to disk
    // return true if everything is okay
    const bool save( const std::string& filename ) const;

    // load bot data from disk
    // return true if everything is okay
    const bool load( const std::string& filename );

    // return position
    const Position& getPos() const
    {
        return m_pos;
    }

    // return view direction
    const BotEnumViewDirection getViewDirection() const
    {
        return m_view;
    }

    // get last movement of bot
    const BaseEnumDirection getLastMovement() const
    {
        return m_lastMove;
    }

    // get last rotation of bot
    const BaseEnumRotation getLastRotation() const
    {
        return m_lastRotation;
    }

    // return true if last action was a move
    const bool isLastMovement() const
    {
        return ( BE_DIRECTION_NONE != m_lastMove );
    }

    // return true if last action was a rotation
    const bool isLastRotation() const
    {
        return ( BE_ROTATION_NONE != m_lastRotation );
    }

    // return if bot is destroyes
    const bool isDestroyed() const
    {
        return m_destroyed;
    }

    // return if bot has reached the end of the game
    const bool isFinished() const
    {
        return m_finish;
    }

    // set new bot view direction
    void setView( const BaseEnumDirection view );

    // set new bot position
    void setPos( const Position& pos )
    {
        m_pos = pos;
    }

    // return true if robot would leave board after movement
    const bool wouldLeaveBoard ( const SeqString& move,
                                 const unsigned int width,
                                 const unsigned int height ) const;

    // return new position if the bot would move into some direction
    const bool getNewPos( Position& newPos,
                          const SeqString& move,
                          const unsigned int width,
                          const unsigned int height ) const;

    // return new view direction if the bot would rotate into some direction
    const bool getNewViewDirection( BotEnumViewDirection& newView,
                                    const SeqString& move) const;

    // move or rotate robot
    void move( const SeqString& move,
               const unsigned int width,
               const unsigned int height );

    // move or rotate robot with whole sequence
    void move( const Sequence& move,
               const unsigned int width,
               const unsigned int height );

    // store position and view direction
    void getStartSequence( Sequence& seq ) const;

    // store position and view direction
    void getEndSequence( Sequence& seq ) const;

    // print bot data
    void print() const;

protected:
    // get position and view direction as string
    const std::string getPosAndViewAsString() const;

    // save bot data to disk
    // return true if everything is okay
    const bool saveInternal( std::ofstream& outFile ) const;

    // Save tile to stream
    const bool saveExtendedAsciiInternal( std::ofstream& outFile,
                                          const int line ) const;

    // position of bot on game board
    Position m_pos;

    // view direction of bot
    BotEnumViewDirection m_view;

    // flag if bot is destroyed
    bool m_destroyed;

    // flag if finish is reached
    bool m_finish;

    // last movement of the robot
    // either movement or rotation is set, but not both
    BaseEnumDirection m_lastMove;

    // last rotation of the robot
    // either movement or rotation is set, but not both
    BaseEnumRotation m_lastRotation;
};

#endif // BOT_HH
