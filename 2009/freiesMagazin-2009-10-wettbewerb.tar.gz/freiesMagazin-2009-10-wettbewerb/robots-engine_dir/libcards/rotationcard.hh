// *************************************************************************
// robots-engine / libcards - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef ROTATIONCARD_HH
#define ROTATIONCARD_HH

#include "basecard.hh"

class RotationCard : public BaseCard
{
public:
    // Constructor
    RotationCard( const CardEnumRotation rot )
    : BaseCard(), m_rotDirection( rot )
    {
    }        

    // copy card and return pointer to it
    virtual RotationCard* clone() const
    {
        return new RotationCard(*this);
    }

    // return sequence with commands for the robot
    virtual void getSequence( Sequence& list ) const;

    // return card id
    virtual const CardEnumType getId() const;
    
    // return string for printing
    virtual const char* print() const;
    
protected:
    // direction for rotation
    CardEnumRotation m_rotDirection;
    
private:
    // Save card to disc (internal use only).
    // return true if everything is okay
    virtual const bool saveInternal( std::ofstream& outFile ) const;
};

#endif // ROTATIONCARD_HH

