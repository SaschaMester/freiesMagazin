// *************************************************************************
// robots-engine / libcards - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef CARDENUMS_HH
#define CARDENUMS_HH

#include "baseenums.hh"

// enum for two rotating directions
enum CardEnumRotation
{
    CE_ROTATION_NONE   = BE_ROTATION_NONE,
    CE_ROTATION_LEFT   = BE_ROTATION_LEFT,
    CE_ROTATION_RIGHT  = BE_ROTATION_RIGHT,
    CE_ROTATION_UTURN  = BE_ROTATION_LEFT | BE_ROTATION_RIGHT
};

// enum for card types
enum CardEnumType
{
    CE_TYPE_NONE = 0,
    CE_TYPE_MOVE_FORWARD_1,
    CE_TYPE_MOVE_FORWARD_2,
    CE_TYPE_MOVE_FORWARD_3,
    CE_TYPE_MOVE_BACKWARD,
    CE_TYPE_ROTATE_LEFT,
    CE_TYPE_ROTATE_RIGHT,
    CE_TYPE_ROTATE_UTURN
};

#endif //CARDENUMS_HH
