// *************************************************************************
// robots-engine / libcards - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef BASECARD_HH
#define BASECARD_HH

#include <fstream>

#include "cardenums.hh"
#include "sequence.hh"

class BaseCard
{
public:
    // Default constructor.
    BaseCard()
    {
        m_used = false;
    }
    
    // set a card as used or unused
    void setUsed( const bool used )
    {
        m_used = used;
    }

    // return true if card is alrady used.
    const bool isUsed() const
    {
        return m_used;
    }
    
    // copy card and return pointer to it
    virtual BaseCard* clone() const = 0;
    
    // return sequence with commands for the robot
    virtual void getSequence( Sequence& list ) const = 0;
    
    // return card id
    virtual const CardEnumType getId() const = 0;
    
    // Save card to disc.
    // return true if everything is okay
    const bool save( std::ofstream& outFile ) const;

    // return generated card to a special string
    static BaseCard *getCardFromString( const std::string& str );
    
    // return position of given card in deck
    const bool equals( const BaseCard& card ) const
    {
        return ( getId() == card.getId() );
    }
    
    // return string for printing
    virtual const char* print() const = 0;

private:
    // Save card to disc (internal use only).
    // return true if everything is okay
    virtual const bool saveInternal( std::ofstream& outFile ) const = 0;

protected:
    // flag if card is used by player or game
    bool m_used;
    
};

#endif // BASECARD_HH
