// *************************************************************************
// robots-engine / libcards - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <cstdlib>
#include <iostream>

#include "basecard.hh"
#include "movecard.hh"
#include "rotationcard.hh"

// Save card to disc.
// return true if everything is okay
const bool BaseCard::save( std::ofstream& outFile ) const
{
    bool ok = false;

    if ( outFile.good() )
    {
        ok = saveInternal( outFile );
    }

    return ok;
}

// return generated card to a special string
BaseCard *BaseCard::getCardFromString( const std::string& str )
{
    BaseCard *card = NULL;

    if ( 0 == str.compare(0, 3, "MF ") )
    {
        const int length = atoi( str.substr(3, str.length()-3).c_str() );

        card = (BaseCard*)( new MoveCard(length) );
    }
    else if ( "MB" == str )
    {
        card = (BaseCard*)( new MoveCard(-1) );
    }
    else if ( "RL" == str )
    {
        card = (BaseCard*)( new RotationCard( CE_ROTATION_LEFT ) );
    }
    else if ( "RR" == str )
    {
        card = (BaseCard*)( new RotationCard( CE_ROTATION_RIGHT ) );
    }
    else if ( "RU" == str )
    {
        card = (BaseCard*)( new RotationCard( CE_ROTATION_UTURN ) );
    }
    else
    {
        std::cerr << "BaseCard::getCardFromString(string) "
                  << "Error: String "
                  << str.c_str()
                  << " is a unknown card."
                  << std::endl;
    }

    return card;
}
