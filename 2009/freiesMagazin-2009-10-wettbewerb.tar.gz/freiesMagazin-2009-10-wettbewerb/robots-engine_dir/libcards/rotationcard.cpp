// *************************************************************************
// robots-engine / libcards - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "rotationcard.hh"
#include "cardfunctions.hh"

// return sequence with commands for the robot
void RotationCard::getSequence( Sequence& list ) const
{
    list.push_back( CardFunctions::convertToSequenceString( m_rotDirection ) );
}

// Save card to disc (internal use only).
// return true if everything is okay
const bool RotationCard::saveInternal( std::ofstream& outFile ) const
{
    bool ok = true;

    switch ( m_rotDirection )
    {
        case CE_ROTATION_LEFT:
            outFile << "RL" << std::endl;
            break;
        case CE_ROTATION_RIGHT:
            outFile << "RR" << std::endl;
            break;
        case CE_ROTATION_UTURN:
            outFile << "RU" << std::endl;
            break;
        default:
            ok = false;
            break;
    }
    
    return ok;
}

// return card id
const CardEnumType RotationCard::getId() const
{
    CardEnumType type = CE_TYPE_NONE;
    
    switch ( m_rotDirection )
    {
        case CE_ROTATION_LEFT:
            type = CE_TYPE_ROTATE_LEFT;
            break;
        case CE_ROTATION_RIGHT:
            type = CE_TYPE_ROTATE_RIGHT;
            break;
        case CE_ROTATION_UTURN:
            type = CE_TYPE_ROTATE_UTURN;
            break;
        default:
            break;
    }
    
    return type;    
}

// return string for printing
const char* RotationCard::print() const
{
    switch ( m_rotDirection )
    {
        case CE_ROTATION_LEFT:
            return "RL";
            break;
        case CE_ROTATION_RIGHT:
            return "RR";
            break;
        case CE_ROTATION_UTURN:
            return "RU";
            break;
        default:
            break;
    }
    
    return "";
}
