// *************************************************************************
// robots-engine / libcards - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "movecard.hh"

// return sequence with commands for the robot
void MoveCard::getSequence( Sequence& list ) const
{
    // absolute step width
    const int absStepWidth = ( ( m_stepWidth >= 0 ) ? (m_stepWidth) : (-m_stepWidth) );
    
    const SeqString dir =  ( ( m_stepWidth >= 0 ) ? "MF" : "MB" );
    
    for ( int ii = 0; ii < absStepWidth; ii++ )
    {
        list.push_back( dir );    
    }
}

// Save card to disc (internal use only).
// return true if everything is okay
const bool MoveCard::saveInternal( std::ofstream& outFile ) const
{
    const std::string dir =  ( ( m_stepWidth >= 0 ) ? "MF" : "MB" );

    outFile << dir.c_str();
    
    if ( m_stepWidth >= 0 )
    {
        outFile << " " << m_stepWidth;
    }
    
    outFile << std::endl;
    
    return true;
}

// return card id
const CardEnumType MoveCard::getId() const
{
    CardEnumType type = CE_TYPE_NONE;
    
    if ( m_stepWidth >= 0 )
    {
        switch ( m_stepWidth )
        {
            case 1:
                type = CE_TYPE_MOVE_FORWARD_1;
                break;
            case 2:
                type = CE_TYPE_MOVE_FORWARD_2;
                break;
            case 3:
                type = CE_TYPE_MOVE_FORWARD_3;
                break;
            default:
                break;
        }
    }
    else
    {
        type = CE_TYPE_MOVE_BACKWARD;        
    }
    
    return type;    
}

// return string for printing
const char* MoveCard::print() const
{
    if ( m_stepWidth >= 0 )
    {
        switch ( m_stepWidth )
        {
            case 1:
                return "MF 1";
                break;
            case 2:
                return "MF 2";
                break;
            case 3:
                return "MF 3";
                break;
            default:
                break;
        }
    }
    else
    {
        return "MB";
    }
    
    return "";     
}
