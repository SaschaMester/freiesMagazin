// *************************************************************************
// robots-engine / libcards - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>

#include "cardfunctions.hh"

const SeqString CardFunctions::convertToSequenceString( const CardEnumRotation rot )
{
    SeqString str;
    
    switch ( rot )
    {
        case CE_ROTATION_LEFT:
            str = "RL";
            break;
        case CE_ROTATION_RIGHT:
            str = "RR";
            break;
        case CE_ROTATION_UTURN:
            str = "RU";
            break;
        default:
            break;
    }
    
    return str;
}

