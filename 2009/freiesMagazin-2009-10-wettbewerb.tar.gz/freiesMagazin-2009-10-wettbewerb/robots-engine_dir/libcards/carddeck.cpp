// *************************************************************************
// robots-engine / libcards - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <cstdlib>

#include "carddeck.hh"

// Default constructor.
// if init that the standard deck will be created.
CardDeck::CardDeck( const bool initDeck, const bool shadowCopy )
: m_shadowCopy(shadowCopy)
{
    // init random timer
    srand( (unsigned int) time(NULL) ) ;

    if ( initDeck )
    {
        init();
    }
}

// Create empty deck with cards.
CardDeck::CardDeck( const unsigned int newSize, const bool shadowCopy )
: m_shadowCopy(shadowCopy)
{
    // init random timer
    srand( (unsigned int) time(NULL) ) ;

    resize( newSize );
}

// Copy constructor.
CardDeck::CardDeck( const CardDeck& deck )
: m_shadowCopy(false)
{
    operator=(deck);
}

// Destructor.
CardDeck::~CardDeck()
{
    clearAll();
}

// Assigment operator.
const CardDeck& CardDeck::operator=( const CardDeck& deck )
{
    // set correct size
    resize( deck.size() );

    // copy each pointer as deep copy
    for ( unsigned int ii = 0; ii < size(); ii++ )
    {
        if ( !m_shadowCopy )
        {
            if ( NULL != deck[ii] )
            {
                setCard ( ii, deck[ii]->clone() );
            }
        }
        else
        {
            m_deck[ii] = deck[ii];
        }
    }

    return (*this);
}

// access card element
BaseCard* CardDeck::operator[] ( const unsigned int index ) const
{
    return m_deck.at( index );
}

// clear all elements (delete pointers)
// but do not change the size!
void CardDeck::clear()
{
    for ( unsigned int ii = 0; ii < size(); ii++ )
    {
        if ( NULL != m_deck[ii] )
        {
            if ( !m_shadowCopy )
            {
                delete m_deck[ii];
            }
            m_deck[ii] = NULL;
        }
    }
}

// clear all elements (delete pointers)
// and deletes the allocated memory for the deck
// set size to (0,0)
void CardDeck::clearAll()
{
    // first delete the base pointers
    clear();

    // now clear the array
    m_deck.clear();
}

// set new size for game board
// all elements will be deleted!
void CardDeck::resize( const unsigned int newSize )
{
    clearAll();
    m_deck.resize( newSize );
}

// associate pointer with a new card
// Attention: The pointer must not be deleted outside!
const bool CardDeck::setCard( const unsigned int index, BaseCard* card )
{
    bool ok = false;

    if ( index < size() )
    {
        // first delete pointer if necessary
        if ( NULL != m_deck[index] )
        {
            if ( !m_shadowCopy )
            {
                delete m_deck[index];
            }
            m_deck[index] = NULL;
        }

        // set new pointer
        m_deck[index] = card;

        ok = true;
    }
    else
    {
        std::cerr << "CardDeck::setCard(index,card) "
                  << " Access from "
                  << index
                  << " is out of bounds "
                  << size()
                  << "."
                  << std::endl;
    }

    return ok;
}

// Save card deck to disc
// with all information.
// return true if everything is okay
const bool CardDeck::save( const std::string& filename, const bool unusedOnly ) const
{
    bool ok = false;

    if ( !filename.empty() )
    {
        std::ofstream outFile;

        outFile.open( filename.c_str(), std::ios::out );

        if ( outFile.good() )
        {
            // in the first line we store the size
            // const unsigned int size = ( ( unusedOnly ) ? getNumUnusedCards() : size() );
            // outFile << size << std::endl;

            for ( unsigned int ii = 0; ii < size(); ii++ )
            {
                if ( NULL != m_deck[ii] )
                {
                    if ( ( !unusedOnly ) ||
                         ( unusedOnly && !m_deck[ii]->isUsed() ) )
                    {
                        // save tile directly to file
                        if ( !m_deck[ii]->save( outFile ) )
                        {
                            return ok;
                        }
                    }
                }
            }

            outFile.close();

            ok = true;
        }
        else
        {
            std::cerr << "CardDeck::save(string) "
                      << "Error: File "
                      << filename.c_str()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "CardDeck::save(string) "
                  << "Error: Filename is empty."
                  << std::endl;
    }

    return ok;
}

// Load card deck from disc
// with all information.
// return true if everything is okay
const bool CardDeck::load( const std::string& filename )
{
    bool ok = false;

    if ( !filename.empty() )
    {
        std::ifstream inFile;

        inFile.open( filename.c_str(), std::ios::in );

        if ( inFile.good() )
        {
            // count lines
            unsigned int size = 0;
            char str[10];

            while ( inFile.good() )
            {
                inFile.getline( str, 10 );
                if ( !std::string(str).empty() )
                {
                    size++;
                }
            }

            // std::cout << "Size: " << size << std::endl;

            // set new size
            resize( size );

            // we create original content
            m_shadowCopy = false;
        }

        // close and open file
        inFile.close();
        inFile.open( filename.c_str(), std::ios::in );

        if ( inFile.good() )
        {
            BaseCard *card = NULL;
            char str[10];

            for ( unsigned int ii = 0; ii < size(); ii++ )
            {
                inFile.getline( str, 10 );

                if ( !std::string(str).empty() )
                {
                    // depending on the string we must create the card
                    card = BaseCard::getCardFromString( str );

                    // finally set the card
                    if ( NULL == card || !setCard ( ii, card) )
                    {
                        inFile.close();
                        return ok;
                    }

                    // remove pointer again
                    card = NULL;
                }
            }

            inFile.close();
            ok = true;
        }
        else
        {
            std::cerr << "CardDeck::load(string) "
                      << "Error: File "
                      << filename.c_str()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "CardDeck::load(string) "
                  << "Error: Filename is empty."
                  << std::endl;
    }

    return ok;
}

// shuffles the deck
void CardDeck::shuffle()
{
    for ( unsigned int ii = 0; ii < size(); ii++ )
    {
        const unsigned int index = rand() % size();

        // switch pointers
        BaseCard* tempP = m_deck[ii];
        m_deck[ii] = m_deck[index];
        m_deck[index] = tempP;
    }
}

// init the default deck
const bool CardDeck::init()
{
    // set new size
    resize( CDE_NUM_CARDS );

    // we create original content
    m_shadowCopy = false;

    unsigned int index = 0;

    for ( int ii = 0; ii < CDE_NUM_MOVE_CARDS_1; ii++ )
    {
        setCard( index, (BaseCard*)( new MoveCard(1) ) );
        index++;
        setCard( index, (BaseCard*)( new RotationCard( CE_ROTATION_LEFT ) ) );
        index++;
        setCard( index, (BaseCard*)( new RotationCard( CE_ROTATION_RIGHT ) ) );
        index++;
    }

    for ( int ii = 0; ii < CDE_NUM_MOVE_CARDS_2; ii++ )
    {
        setCard( index, (BaseCard*)( new MoveCard(2) ) );
        index++;
    }

    for ( int ii = 0; ii < CDE_NUM_MOVE_CARDS_3; ii++ )
    {
        setCard( index, (BaseCard*)( new MoveCard(3) ) );
        index++;
        setCard( index, (BaseCard*)( new MoveCard( -1 ) ) );
        index++;
        setCard( index, (BaseCard*)( new RotationCard( CE_ROTATION_UTURN ) ) );
        index++;
    }

    bool ok = true;

    if ( index != size() )
    {
        std::cerr << "CardDeck::init() "
                  << " Size "
                  << index
                  << " does not match "
                  << size()
                  << "."
                  << std::endl;
        ok = false;
    }

    // shuffle cards
    shuffle();

    return ok;
}

// get first number cards and store them in the deck
const bool CardDeck::getCards( CardDeck& deck,
                               const unsigned int number )
{
    bool ok = false;

    if ( number <= size() )
    {
        // clear old data and set correct size
        deck.resize( number );

        // copy cards
        for ( unsigned int ii = 0; ii < number; ii++ )
        {
            if ( NULL != m_deck[ii] )
            {
                deck.setCard ( ii, m_deck[ii]->clone() );
                m_deck[ii]->setUsed(true);
            }
        }

        ok = true;
    }
    else
    {
        std::cerr << "CardDeck::getCards(cards,int) "
                  << "Error: Number of cards "
                  << number
                  << " is greater than size "
                  << size()
                  << "."
                  << std::endl;
    }

    return ok;
}

// return position of given card in deck
const unsigned int CardDeck::find( const BaseCard* card, const bool unusedOnly ) const
{
    unsigned int pos = size();

    for ( unsigned int ii = 0; ii < size(); ii++ )
    {
        if ( NULL != m_deck[ii] && NULL != card )
        {
            if ( ( ( !unusedOnly ) || ( unusedOnly && !m_deck[ii]->isUsed() ) ) &&
                 ( m_deck[ii]->equals( *card ) ) )
            {
                pos = ii;
                break;
            }
        }
    }

    return pos;
}

// return true if cards are subset of this deck
const bool CardDeck::hasSubset( CardDeck& deck ) const
{
    for ( unsigned int ii = 0; ii < size(); ii++ )
    {
        if ( NULL != m_deck[ii] )
        {
            const unsigned int pos = deck.find( m_deck[ii] );

            if ( pos < deck.size() )
            {
                if ( NULL != deck[pos] )
                {
                    deck.m_deck[pos]->setUsed( true );
                }
            }
        }
    }

    bool ok = true;

    // check if all cards were used
    for ( unsigned int jj = 0; jj < deck.size(); jj++ )
    {
        if ( NULL != deck[jj] )
        {
            if ( !deck[jj]->isUsed() )
            {
                ok = false;
                break;
            }
        }
    }

    return ok;
}

// get number of unused cards
const unsigned int CardDeck::getNumUnusedCards() const
{
    unsigned int number = 0;

    for ( unsigned int ii = 0; ii < size(); ii++ )
    {
        if ( NULL != m_deck[ii] && !m_deck[ii]->isUsed() )
        {
            number++;
        }
    }

    return number;
}
