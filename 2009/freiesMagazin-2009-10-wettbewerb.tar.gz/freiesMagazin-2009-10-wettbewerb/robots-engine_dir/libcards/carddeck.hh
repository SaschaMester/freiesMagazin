// *************************************************************************
// robots-engine / libcards - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef CARDECK_HH
#define CARDECK_HH

#include <vector>

#include "basecard.hh"
#include "movecard.hh"
#include "rotationcard.hh"

class CardDeck
{
public:
    // Default constructor.
    // if init that the standard deck will be created.
    CardDeck( const bool initDeck = false, const bool shadowCopy = false );

    // Create empty deck with place for number of cards.
    CardDeck( const unsigned int newSize, const bool shadowCopy );

    // Copy constructor.
    CardDeck( const CardDeck& deck );

    // Destructor.
    ~CardDeck();

    // Assigment operator.
    const CardDeck& operator=( const CardDeck& deck );

    // Save card deck to disc
    // with all information.
    // return true if everything is okay
    const bool save( const std::string& filename, const bool unusedOnly = true ) const;

    // Load card deck from disc
    // with all information.
    // return true if everything is okay
    const bool load( const std::string& filename );

    // get first number of cards and store them in the deck
    const bool getCards( CardDeck& deck,
                         const unsigned int number );

    // return number of cards/size of deck
    const unsigned int size() const
    {
        return m_deck.size();
    }

    // return true if cards are subset of this deck
    const bool hasSubset( CardDeck& deck ) const;

    // access card element
    BaseCard* operator[] ( const unsigned int index ) const;

    // associate pointer with a new card
    // Attention: The pointer must not be deleted outside!
    const bool setCard( const unsigned int index, BaseCard* card );

    // init deck with default cards
    const bool init();

    // set new size for game board
    // all elements will be deleted!
    // return true if memory could be allocated
    void resize( const unsigned int newSize );

    // return if deck is just a shadow copy of another one
    const bool isShadowCopy() const
    {
        return m_shadowCopy;
    }

protected:

    // clear all elements (delete pointers)
    // but do not change the size!
    void clear();

    // clear all elements (delete pointers)
    // and deletes the allocated memory for the deck
    // set size to (0,0)
    void clearAll();

    // get number of unused cards
    const unsigned int getNumUnusedCards() const;

    // shuffles the deck
    void shuffle();

    // return position of given card in deck
    const unsigned int find( const BaseCard* card, const bool unusedOnly = true ) const;

    // deck of cards
    std::vector <BaseCard*> m_deck;

    // flag if the cards in this deck are only references to other
    // cards, that means they should not be deleted in the destructor
    bool m_shadowCopy;

    // the number of max iterations is
    // 7 * CDE_BASE_NUM_CARDS / 4
    enum CardDeckEnums
    {
        CDE_BASE_NUM_MOVE_CARDS_1 = 3,
        CDE_BASE_NUM_MOVE_CARDS_2 = 2,
        CDE_BASE_NUM_MOVE_CARDS_3 = 1,
        CDE_BASE_NUM_CARDS = 400,  // should be multiple of 8
        CDE_NUM_MOVE_CARDS_1 = CDE_BASE_NUM_MOVE_CARDS_1 * CDE_BASE_NUM_CARDS,
        CDE_NUM_MOVE_CARDS_2 = CDE_BASE_NUM_MOVE_CARDS_2 * CDE_BASE_NUM_CARDS,
        CDE_NUM_MOVE_CARDS_3 = CDE_BASE_NUM_MOVE_CARDS_3 * CDE_BASE_NUM_CARDS,
        CDE_NUM_CARDS = 3 * CDE_NUM_MOVE_CARDS_1 +
                        1 * CDE_NUM_MOVE_CARDS_2 +
                        3 * CDE_NUM_MOVE_CARDS_3
    };

};

#endif // CARDDECK_HH
