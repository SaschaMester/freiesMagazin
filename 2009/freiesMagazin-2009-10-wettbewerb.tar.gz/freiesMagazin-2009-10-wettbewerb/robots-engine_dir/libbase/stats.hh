// *************************************************************************
// robots-engine - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef STATS_HH
#define STATS_HH

#include <string>


// This class holds some statistics
// like number of played cards and so one.
// It will be read and written after each iteration to have a correct
// statistic at the end of contest.
class Stats
{
public:

    // different enums for statistic
    enum StatsEnum
    {
        // number of played cards
        SE_NUM_PLAYED_CARDS = 0,
        
        // number of rounds
        SE_NUM_ROUNDS,
        
        // number of moves and rotations that came from the bot directly
        SE_NUM_CARD_MOVES,
        
        // number of moves and rotations that came from the gameboard
        SE_NUM_BOARD_MOVES,

        // number of times the bot was destroyed (Y)
        SE_NUM_BOT_DESTROYED,
        
        // number of times the cards gone out
        SE_NUM_CARDS_OUT,

        // number of times the bot has reached the finish (Z)
        SE_NUM_FINISH_REACHED,
        
        // only add new enum before this line
        SE_MAX,
        
        SE_INVALID
    };

    // Default constructor.
    Stats();

    // Constructor that opens the file and read values from it
    // If the files does not exists or resetFile is true
    // it will only set all values to 0.
    Stats( const std::string& filename, const bool resetFile );
    
    // destructor is not necessary

    // set a file, open it and read values from it
    // If the file does not exists or resetFile is true
    // it will only set all values to 0.
    // Return true if everything is okay.
    bool setFile( const std::string& filename, const bool resetFile );
    
    // Load statistic from associated file.
    // Return true if everything is okay.
    bool load();

    // Save statistic into associated  file.
    // Return true if everything is okay.
    bool save();
    
    // remove associated file from disc
    bool removeFile() const;
    
    // increase value
    // return true if everything is okay
    bool increase( const StatsEnum stat, const int value = 1 );

    // get value
    // return -1 if value is unknown
    int get( const StatsEnum stat ) const;
    
    // return if statistics is valid
    bool isValid() const
    {
        return m_valid;
    }
    
    // print values
    void print() const;

private:
    // Load statistic from associated file.
    // Return true if everything is okay.
    bool load( const bool suppressError );

    // static conversion from enum to string
    static std::string convertEnumToString( const StatsEnum stat );

    // static conversion from string to enum
    static StatsEnum convertStringToEnum( const std::string& stat );
    
    // set value
    // return true if everything is okay
    bool set( const StatsEnum stat, const int value );

    // associated file
    std::string m_filename;

    int m_values[SE_MAX];
    
    // flag if there was an error during saving or loading
    bool m_valid;
};

#endif // STATS_HH
