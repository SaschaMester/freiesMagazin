// *************************************************************************
// robots-engine / libbase - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef BASEFUNCTIONS_HH
#define BASEFUNCTIONS_HH

#include <string>

#include "baseenums.hh"

class BaseFunctions
{
public:

    // get opposite direction
    static const BaseEnumDirection getOppositeDirection( const BaseEnumDirection move );
  
    // convert from string
    static const BaseEnumDirection convertToDirection( const std::string& str );
    static const BaseEnumRotation convertToRotation( const std::string& str );

    // set game level
    static void setGameLevel( const BaseEnumGameLevel level )
    {
        m_gameLevel = level;
    }

    // set game level from string
    static bool setGameLevel( const std::string level )
    {
        bool ok = false;
        setGameLevel( level, ok );
        return ok;
    }

    // set game level from string
    static bool setGameLevel( const std::string level, bool& ok )
    {
        m_gameLevel = convertStringToGameLevel( level, ok );
        return ok;
    }
    
    // return game level
    static const BaseEnumGameLevel getGameLevel()
    {
        return m_gameLevel;
    }
    
    // convert the current game level to a string
    static const std::string convertGameLevelToString();

    // convert a game level to a string
    static const std::string convertGameLevelToString( const BaseEnumGameLevel gameLevel );

    // convert a string to a game level
    // return NORMAL in case of error
    static const BaseEnumGameLevel convertStringToGameLevel( const std::string gameLevel, bool& ok );
    
private:
    // game level
    static BaseEnumGameLevel m_gameLevel;
    
};

#endif // BASEFUNCTIONS_HH
