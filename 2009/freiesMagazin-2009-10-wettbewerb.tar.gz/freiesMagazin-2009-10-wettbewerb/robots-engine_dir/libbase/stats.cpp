// *************************************************************************
// robots-engine - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <fstream>

#include "stats.hh"

// Default constructor.
Stats::Stats()
: m_filename ( "" ), m_valid(false)
{
    // set all values to 0
    for ( unsigned int ii = 0; ii < SE_MAX; ii++ )
    {
        m_values[ii] = 0;
    }
}

// Constructor that opens the file and read values from it
// If the files does not exists or resetFile is true
// it will only set all values to 0.
Stats::Stats( const std::string& filename, const bool resetFile )
: m_filename ( "" ), m_valid(false)
{
    // set all values to 0
    for ( unsigned int ii = 0; ii < SE_MAX; ii++ )
    {
        m_values[ii] = 0;
    }
    
    setFile( filename, resetFile );
}

// set a file, open it and read values from it
// If the file does not exists or resetFile is true
// it will only set all values to 0.
// return true if everything is okay
bool Stats::setFile( const std::string& filename, const bool resetFile )
{
    // set filename
    m_filename = filename;

    // load values if possible
    if ( resetFile || !load( true ) )
    {
        // values could not be loaded or should be resetted
        // so create a new file
        save();
    }
    
    return m_valid;
}

// Save statistic into one file.
// Return true if everything is okay.
bool Stats::save()
{
    bool ok = false;

    if ( !m_filename.empty() )
    {
        std::ofstream outFile;

        outFile.open( m_filename.c_str(), std::ios::out );

        if ( outFile.good() )
        {
            for ( unsigned int ii = 0; ii < SE_MAX; ii++ )
            {
                outFile << convertEnumToString((StatsEnum)ii)
                        << ": " << m_values[ii] << std::endl;
            }
            outFile.close();
            ok = true;
        }
        else
        {
            std::cerr << "Stats::save(string) "
                      << "Error: File "
                      << m_filename.c_str()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "Stats::save(string) "
                  << "Error: Filename is empty."
                  << std::endl;
    }

    m_valid = ok;
    
    return ok;
}

// Load statistic from file.
// Return true if everything is okay.
bool Stats::load()
{
    return load( false );
}

// Load statistic from associated file.
// Return true if everything is okay.
bool Stats::load( const bool suppressError )
{
    bool ok = false;

   if ( !m_filename.empty() )
    {
        std::ifstream inFile;

        inFile.open( m_filename.c_str(), std::ios::in );

        if ( inFile.good() )
        {
            char cstr[100];
            bool error = false;

            while ( inFile.good() && !error )
            {
                // read line
                inFile.getline( cstr, 100 );

                // create string
                std::string str2(cstr);

                // search colon
                const size_t pos = str2.find ( ':' );

                if ( std::string::npos != pos )
                {
                    // extract value
                    const std::string valStr = str2.substr( pos+1, str2.length()-1 );
                    const int value = atoi( valStr.c_str() );

                    // std::cout << "Convert \"" << valStr.c_str() << "\""
                    //           << "to " << value << std::endl;

                    if ( value >=0 )
                    {
                        // extract name
                        const std::string name = str2.substr( 0, pos );
                        const StatsEnum stat = convertStringToEnum( name );
                        
                        if ( 0 <= stat && stat < SE_MAX )
                        {
                            set( stat, value );
                        }
                        else
                        {
                            std::cerr << "Stats::load(string) "
                                      << "Error: Enum "
                                      << stat
                                      << " is unknown."
                                      << std::endl;
                            error = true;
                        }
                    }
                    else 
                    {
                        std::cerr << "Stats::load(string) "
                                  << "Error: Value "
                                  << value
                                  << " is negative."
                                  << std::endl;
                        error = true;
                    }
                }
                else if ( !str2.empty() )
                {
                    std::cerr << "Stats::load(string) "
                              << "Error: Syntax of line \""
                              << str2.c_str()
                              << "\" in file "
                              << m_filename.c_str()
                              << " is not correct (colon needed)."
                              << std::endl;
                    error = true;
                }
            } // while
            
            ok = !error;
        }
        else if ( !suppressError )
        {
            std::cerr << "Stats::load(string) "
                      << "Error: File "
                      << m_filename.c_str()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else if ( !suppressError )
    {
        std::cerr << "Stats::load(string) "
                  << "Error: Filename is empty."
                  << std::endl;
    }
 
    m_valid = ok;
    
    return ok;    
}

// remove associated file from disc
bool Stats::removeFile() const
{
    bool ok = false;

    if ( !m_filename.empty() )
    {
        if  ( 0 == remove ( m_filename.c_str() ) )
        {
            ok = true;
        }
    }
    
    return ok;
}
        
// set value
// return true if everything is okay
bool Stats::set( const StatsEnum stat, const int value )
{
    bool ok = false;
    
    if ( 0 <= stat && stat < SE_MAX )
    {
        if ( value >= 0 )
        {
            m_values[stat] = value;
            ok = true;
        }
        else
        {
            std::cerr << "Stats::set(enum,int) "
                      << "Error: Value "
                      << value
                      << " is negative."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "Stats::set(enum,int) "
                  << "Error: Enum "
                  << stat
                  << " is unknown."
                  << std::endl;
    }
    
    return ok;
}

// increase value
// return true if everything is okay
bool Stats::increase( const StatsEnum stat, const int value )
{
    bool ok = false;
    
    if ( 0 <= stat && stat < SE_MAX )
    {
        if ( value >= 0 )
        {
            m_values[stat] += value;
            ok = true;
        }
        else
        {
            std::cerr << "Stats::increase(enum,int) "
                      << "Error: Value "
                      << value
                      << " is negative."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "Stats::increase(enum,int) "
                  << "Error: Enum "
                  << stat
                  << " is unknown."
                  << std::endl;
    }
    
    return ok;
}

// get value
// return -1 if value is unknown
int Stats::get( const StatsEnum stat ) const
{
    int value = -1;
    
    if ( 0 <= stat && stat < SE_MAX )
    {
        value = m_values[stat];
    }
    else
    {
        std::cerr << "Stats::get(enum) "
                  << "Error: Enum "
                  << stat
                  << " is unknown."
                  << std::endl;
    }
    
    return value;
}

// static conversion from enum to string
std::string Stats::convertEnumToString( const StatsEnum stat )
{
    std::string str = "";
    
    switch ( stat )
    {
        case SE_NUM_PLAYED_CARDS:
            str = "Cards";
            break;
        case SE_NUM_ROUNDS:
            str = "Rounds";
            break;
        case SE_NUM_CARD_MOVES:
            str = "Card Moves";
            break;
        case SE_NUM_BOARD_MOVES:
            str = "Board Moves";
            break;
        case SE_NUM_BOT_DESTROYED:
            str = "Destroyed (X)";
            break;
        case SE_NUM_CARDS_OUT:
            str = "Cards Out (Y)";
            break;
       case SE_NUM_FINISH_REACHED:
            str = "Finished (Z)";
            break;
        default:
            std::cerr << "Stats::convertEnumToString(enum) "
                      << "Error: Unknown case "
                      << stat
                      << " for conversion."
                      << std::endl;
        break;
    }
    
    return str;
}

// static conversion from string to enum
Stats::StatsEnum Stats::convertStringToEnum( const std::string& stat )
{
    StatsEnum str = SE_INVALID;
    
    if ( 0 == stat.compare( convertEnumToString( SE_NUM_PLAYED_CARDS ) ) )
    {
        str = SE_NUM_PLAYED_CARDS;
    }
    else if ( 0 == stat.compare( convertEnumToString( SE_NUM_ROUNDS ) ) )
    {
        str = SE_NUM_ROUNDS;
    }
    else if ( 0 == stat.compare( convertEnumToString( SE_NUM_CARD_MOVES ) ) )
    {
        str = SE_NUM_CARD_MOVES;
    }
    else if ( 0 == stat.compare( convertEnumToString( SE_NUM_BOARD_MOVES ) ) )
    {
        str = SE_NUM_BOARD_MOVES;
    }
    else if ( 0 == stat.compare( convertEnumToString( SE_NUM_BOT_DESTROYED ) ) )
    {
        str = SE_NUM_BOT_DESTROYED;
    }
    else if ( 0 == stat.compare( convertEnumToString( SE_NUM_CARDS_OUT ) ) )
    {
        str = SE_NUM_CARDS_OUT;
    }
    else if ( 0 == stat.compare( convertEnumToString( SE_NUM_FINISH_REACHED ) ) )
    {
        str = SE_NUM_FINISH_REACHED;
    }
    else
    {
        std::cerr << "Stats::convertStringToEnum(string) "
                  << "Error: Unknown string \""
                  << stat.c_str()
                  << "\" for conversion."
                  << std::endl;
    }

    // std::cout << "Convert \"" << stat.c_str() << "\"";
    // std::cout << " to " << (int)str << std::endl;

    return str;
}

// print values
void Stats::print() const
{
    // set all values to 0
    for ( unsigned int ii = 0; ii < SE_MAX; ii++ )
    {
        std::cout << convertEnumToString( (StatsEnum)ii )
                  << ": " << m_values[ii] << std::endl;
    }
}
