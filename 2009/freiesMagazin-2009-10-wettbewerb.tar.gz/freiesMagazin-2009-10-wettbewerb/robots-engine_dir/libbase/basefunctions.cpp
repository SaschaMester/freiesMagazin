// *************************************************************************
// robots-engine / libbase - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "basefunctions.hh"

// static members
BaseEnumGameLevel BaseFunctions::m_gameLevel = BE_GAME_LEVEL_NORMAL;

// get opposite direction
const BaseEnumDirection BaseFunctions::getOppositeDirection( const BaseEnumDirection move )
{
    BaseEnumDirection opp = BE_DIRECTION_NONE;
    
    switch ( move )
    {
        case BE_DIRECTION_LEFT:
            opp = BE_DIRECTION_RIGHT;
            break;
        case BE_DIRECTION_RIGHT:
            opp = BE_DIRECTION_LEFT;
            break;
        case BE_DIRECTION_UP:
            opp = BE_DIRECTION_DOWN;
            break;
        case BE_DIRECTION_DOWN:
            opp = BE_DIRECTION_UP;
            break;
        default:
            break; 
    }
    
    return opp;
}

const BaseEnumDirection BaseFunctions::convertToDirection( const std::string& str )
{
    BaseEnumDirection move = BE_DIRECTION_NONE;
     
    if ( "ML" == str )
    {
        move = BE_DIRECTION_LEFT;
    }
    else if ( "MR" == str )
    {
        move = BE_DIRECTION_RIGHT;
    }
    else if ( "MU" == str )
    {
        move = BE_DIRECTION_UP;
    }
    else if ( "MD" == str )
    {
        move = BE_DIRECTION_DOWN;
    }
    
    return move;     
}

const BaseEnumRotation BaseFunctions::convertToRotation( const std::string& str )
{
    BaseEnumRotation rot = BE_ROTATION_NONE;
    
    if ( "RL" == str )
    {
        rot = BE_ROTATION_LEFT;
    }
    else if ( "RR" == str )
    {
        rot = BE_ROTATION_RIGHT;
    }
    else if ( "RU" == str )
    {
        rot = BE_ROTATION_UTURN;
    }
    
    return rot;
}

// convert the current game level to a string
const std::string BaseFunctions::convertGameLevelToString()
{
    return convertGameLevelToString ( m_gameLevel );
}

// convert a game level to a string
const std::string BaseFunctions::convertGameLevelToString( const BaseEnumGameLevel gameLevel )
{
    std::string level;

    switch ( gameLevel )
    {
        case BE_GAME_LEVEL_EASY:
            level = "easy";
            break;
        case BE_GAME_LEVEL_NORMAL:
            level = "normal";
            break;
        case BE_GAME_LEVEL_HARD:
            level = "hard";
            break;
        default:
            level = "error";
            break;
    }
    
    return level;
}

// convert a string to a game level
// return NORMAL in case of error
const BaseEnumGameLevel BaseFunctions::convertStringToGameLevel( const std::string gameLevel, bool& ok )
{
    BaseEnumGameLevel level = BE_GAME_LEVEL_NORMAL;

    ok = false;

    if ( "easy" == gameLevel )
    {
        level = BE_GAME_LEVEL_EASY;
        ok = true;
    }
    else if ( "normal" == gameLevel )
    {
        level = BE_GAME_LEVEL_NORMAL;
        ok = true;
    }
    else if ( "hard" == gameLevel )
    {
        level = BE_GAME_LEVEL_HARD;
        ok = true;
    }
    
    return level;
}
