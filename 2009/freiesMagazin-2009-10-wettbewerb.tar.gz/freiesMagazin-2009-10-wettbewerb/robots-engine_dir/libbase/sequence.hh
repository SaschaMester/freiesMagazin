// *************************************************************************
// robots-engine / libbase - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef SEQUENCE_H
#define SEQUENCE_H

#include <vector>
#include <string>

typedef std::string SeqString;

// the sequence is a list of strings
class Sequence : public std::vector<SeqString>
{
public:
    // append another list
    void append( const Sequence& seq );

    // append a single line
    void append( const std::string& line );

    // print sequence list
    void print( const bool withNumbers ) const;
    
    // Save sequence to disc
    // return true if everything is okay
    const bool save( const std::string& filename ) const;

    // Load sequence from disc
    // return true if everything is okay
    const bool load( const std::string& filename );
    
};

#endif // SEQUENCE_H
