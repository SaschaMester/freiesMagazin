// *************************************************************************
// robots-engine / libbase - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <fstream>

#include "sequence.hh"

// append another list
void Sequence::append( const Sequence& seq )
{
    for ( unsigned int ii = 0; ii < seq.size(); ii++ )
    {
        push_back( seq.at(ii) );
    }
}

// append a single line
void Sequence::append( const std::string& line )
{
    push_back( line );
}

// print sequence list
void Sequence::print( const bool withNumbers ) const
{
    for( unsigned int i = 0; i < size(); i++ )
    {
        if ( withNumbers )
        {
            std::cout << i+1 << ". ";
        }

        if ( "----" == at(i) )
        {
            std::cout << "| ";
        }
        else
        {
            std::cout << at(i).c_str() << " ";
        }

        if ( withNumbers )
        {
            std::cout << std::endl;
        }
    }
}

// Save sequence to disc
// return true if everything is okay
const bool Sequence::save( const std::string& filename ) const
{
    bool ok = false;

    if ( !filename.empty() )
    {
        std::ofstream outFile;

        outFile.open( filename.c_str(), std::ios::out );

        if ( outFile.good() )
        {
            for( unsigned int i = 0; i < size(); i++ )
            {
                outFile << at(i).c_str() << std::endl;
            }

            outFile.close();

            ok = true;
        }
        else
        {
            std::cerr << "Sequence::save(string) "
                      << "Error: File "
                      << filename.c_str()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "Sequence::save(string) "
                  << "Error: Filename is empty."
                  << std::endl;
    }

    return ok;
}

// Load sequence from disc
// return true if everything is okay
const bool Sequence::load( const std::string& filename )
{
    bool ok = false;

    if ( !filename.empty() )
    {
        std::ifstream inFile;

        inFile.open( filename.c_str(), std::ios::in );

        if ( inFile.good() )
        {
            // delete old content
            clear();

            // lines
            char line[100];

            // read each line until end of file
            // and store it
            while ( inFile.good() )
            {
                inFile.getline( line, 100 );

                if ( !std::string( line ).empty() )
                {
                    push_back( line );
                }
            }

            ok = true;

            inFile.close();
        }
        else
        {
            std::cerr << "Sequence::load(string) "
                      << "Error: File "
                      << filename.c_str()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "Sequence::load(string) "
                  << "Error: Filename is empty."
                  << std::endl;
    }

    return ok;
}
