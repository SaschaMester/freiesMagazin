// *************************************************************************
// robots-engine / libbase - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef POSITION_H
#define POSITION_H

// This class holds an integer position as 2d-value.
// There isn't a boundary check in the setting method!
class Position 
{
public:     // methods
 
    // standard constructor
    // -1 means unset
    Position() : m_x(0), m_y(0)
    {}

    // constructor
    Position(const unsigned int x, const unsigned int y) : m_x(x), m_y(y)
    {}
    
    // compare operator
    const bool operator==( const Position pos ) const
    {
        return ( m_x == pos.m_x && m_y == pos.m_y );
    }

    // compare operator
    const bool operator!=( const Position pos ) const
    {
        return !(*this == pos);
    }
    
    // set position
    void set(const unsigned int x, const unsigned int y)
    {
        m_x = x;
        m_y = y;
    }
    
    // unset position (set to 0)
    void unset()
    {
        m_x = 0;
        m_y = 0;
    }
    
    // return position x
    const unsigned int x() const
    {
        return m_x;
    }

    // return position y
    const unsigned int y() const
    {
        return m_y;
    }
   
private:    // members

    // positions
    unsigned int m_x;
    unsigned int m_y;
};

#endif // POSITION_H
