// *************************************************************************
// robots-engine - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <fstream>
#include <string>

#include "gameengine.hh"
#include "basefunctions.hh"

void printSyntax( const std::string& call )
{
        std::cout << "\nSyntax is:\n"
                  << call
                  << " start [easy|normal|hard]                    "
                  << " -- [set game level and] start game\n"
                  << call
                  << " save DECKNAME                               "
                  << " -- store card deck\n"
                  << call
                  << " load BOARDNAME [easy|normal|hard]           "
                  << " -- load game board and create random card deck\n"
                  << call
                  << " load BOARDNAME DECKNAME  [easy|normal|hard] "
                  << " -- load game board and card deck\n"
                  << std::endl;
}

// Error Syntax:
//  0 = okay
//  1 = syntax is wrong
//  2 = game is not valid
//  3 = card deck could not be stored
//  4 = game could not be started

int main( int argc, char *argv[] )
{
    int retValue = 0;

    // extract action ( load, save, start )    
    std::string action;

    if ( argc > 1 )
    {
        action = argv[1];
    }
    
    if ( "start" == action ||
         "load" == action ||
         "save" == action )
    {
        if ( "start" == action && ( 2 == argc || 3 == argc ) )
        {
            // try to extract optional game level
            std::string level( "normal" );
            bool levelCorrect = true;
            
            if ( 3 == argc )
            {
                // get last argument
                level = argv[argc-1];
            }

            // set game level
            BaseFunctions::setGameLevel( level, levelCorrect );
            
            if ( levelCorrect )
            {
                // load data from disk
                GameEngine game;

                // check if game is valid
                // that means if all files could be loaded correctly            
                if ( !game.start() )
                {
                    retValue = 4;
                }
            }
            else
            {
                printSyntax( argv[0] );
                retValue = 1;
            }
        }
        else if ( "load" == action && ( 3 == argc || 4 == argc || 5 == argc ) )
        {
            if ( 3 == argc )
            {
                // create new game from board
                // the deck is random
                GameEngine game( argv[2] );
                
                if ( !game.isValid() )
                {
                    retValue = 2;
                }
            }
            else if ( 4 == argc )
            {
                // it's possible that the last argument is the game level

                // try to extract optional game level
                std::string level( "normal" );
                bool levelCorrect = true;
                
                // get last argument
                level = argv[3];

                // set game level
                BaseFunctions::setGameLevel( level, levelCorrect );

                if ( !levelCorrect )
                {
                    // create new game from board and card deck
                    GameEngine game( argv[2], argv[3] );

                    if ( !game.isValid() )
                    {
                        retValue = 2;
                    }
                }
                else
                {
                    // create new game from board
                    // the deck is random
                    GameEngine game( argv[2] );
                    
                    if ( !game.isValid() )
                    {
                        retValue = 2;
                    }
                }
            }
            else if ( 5 == argc )
            {
                // try to extract optional game level
                std::string level( "normal" );
                bool levelCorrect = true;
                
                // get last argument
                level = argv[4];

                // set game level
                BaseFunctions::setGameLevel( level, levelCorrect );
                
                if ( !levelCorrect )
                {
                    printSyntax( argv[0] );
                    retValue = 1;
                }
                else
                {
                    // create new game from board and card deck
                    GameEngine game( argv[2], argv[3] );

                    if ( !game.isValid() )
                    {
                        retValue = 2;
                    }
                }
            }
        }
        else if ( "save" == action && 3 == argc )
        {
            // we want to create a card deck and save it to disc
            CardDeck cards(true);
            
            if ( !cards.save( argv[2] ) )
            {
                retValue = 3;
            }
        }
        else
        {
            printSyntax( argv[0] );
            retValue = 1;
        }
    }
    else
    {
        printSyntax( argv[0] );
        retValue = 1;
    }
    
    if ( 0 != retValue )
    {
        std::cerr << "Error: Return value is "
                  << retValue 
                  << std::endl;
     }
     
     // std::cout << "return: " << retValue << std::endl;

    return retValue;
}
