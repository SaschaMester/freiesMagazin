// *************************************************************************
// robots-engine - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <cstdlib>

#include "game.hh"
#include "botfunctions.hh"
#include "basefunctions.hh"

const std::string boardname("board.txt");
const std::string deckname("cards.txt");
const std::string botname("bot.txt");

// Default constructor.
// Loads all data from disk.
Game::Game()
: m_valid(false)
{
    if ( m_board.loadAscii( boardname ) )
    {
        if ( m_deck.load( deckname ) )
        {
            if ( m_bot.load( botname ) )
            {
                m_valid = true;
            }
        }
    }

    // save all data
    if ( !saveAll() )
    {
        m_valid = false;
    }
}

// Constructor.
// Only load board from disk.
Game::Game( const std::string& boardname )
: m_valid(false)
{
    if ( m_board.loadAscii( boardname ) )
    {
        if ( m_deck.init() )
        {
            // get start position for bot
            if ( m_board.isValid() )
            {
                m_bot.setPos( m_board.getStartPos() );
                m_bot.setView( m_board.getStartViewDirection() );
                m_valid = true;
            }
        }
    }

    // save all data
    if ( !saveAll() )
    {
        m_valid = false;
    }
}

// Constructor.
// Load board and card deck from disk.
Game::Game( const std::string& boardname, const std::string& deckname )
: m_valid(false)
{
    if ( m_board.loadAscii( boardname ) )
    {
        if ( m_deck.load( deckname ) )
        {
            // get start position for bot
            if ( m_board.isValid() )
            {
                m_bot.setPos( m_board.getStartPos() );
                m_bot.setView( m_board.getStartViewDirection() );
                m_valid = true;
            }
        }
    }

    // save all data
    if ( !saveAll() )
    {
        m_valid = false;
    }
}

// Destructor.
Game::~Game()
{
    // nothing to destruct
}

// return true if bot has reached end position
const bool Game::botHasReachedEndPosition( const Bot& bot ) const
{
    bool reached = false;

    if ( NULL != m_board[ bot.getPos() ] )
    {
        reached = m_board[ bot.getPos() ]->isType( TE_TYPE_END );
    }

    return reached;
}

// Save game board to disc
// as ascii with one char per tile
// including robot
// return true if everything is okay
const bool Game::saveExtendedAscii( const std::string& filename ) const
{
    bool ok = false;

    if ( !filename.empty() )
    {
        std::ofstream outFile;

        outFile.open( filename.c_str(), std::ios::out );

        if ( outFile.good() )
        {
            for ( unsigned int jj = 0; jj < m_board.getHeight(); jj++ )
            {
                for ( unsigned int kk = 0; kk < 3; kk++)
                {
                    for ( unsigned int ii = 0; ii < m_board.getWidth(); ii++ )
                    {
                        const Position pos(ii,jj);

                        if ( m_bot.getPos() == pos )
                        {
                            // save bot directly to file
                            if ( !m_bot.saveExtendedAscii( outFile, kk ) )
                            {
                                return ok;
                            }
                        }
                        else
                        {
                            if ( NULL != m_board[pos] &&
                                 !m_board[pos]->isType( TE_TYPE_START ) )
                            {
                                // save tile directly to file
                                if ( !m_board[pos]->saveExtendedAscii( outFile, kk ) )
                                {
                                    return ok;
                                }
                            }
                            else
                            {
                                // tile is not defined on board
                                // use floor tile
                                outFile << "     ";
                            }
                        }
                    }
                    // after each line we must add a linebreak
                    outFile << std::endl;
                }
            }

            outFile.close();

            ok = true;
        }
        else
        {
            std::cerr << "Game::saveAscii(string) "
                      << "Error: File "
                      << filename.c_str()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "Game::saveAscii(string) "
                  << "Error: Filename is empty."
                  << std::endl;
    }

    return ok;
}

// save all data to disk
const bool Game::saveAll() const
{
    bool ok = false;

    if ( isValid() )
    {
        saveExtendedAscii( "ascii-board.txt" );

        if ( m_board.saveAscii( boardname ) )
        {
            if ( m_deck.save( deckname ) )
            {
                if ( m_bot.save( botname ) )
                {
                    ok = true;
                }
            }
        }
    }
    else
    {
        std::cerr << "Game::saveAll() "
                  << "Error: Game is not valid!"
                  << std::endl;
    }

    return ok;
}

// generate sequence for GUI from cards
// and save it to disk
const bool Game::generateAndStoreSequence( const CardDeck& choosenCards, Bot& bot ) const
{
    bool ok = true;

    for ( unsigned int ii = 0; ii < choosenCards.size(); ii++ )
    {
        if ( NULL != choosenCards[ii] )
        {
            // get movement for this card
            Sequence startSeq;
            choosenCards[ii]->getSequence( startSeq );

            //std::cout << "start seq: ";
            //startSeq.print(false);
            //std::cout << std::endl;

            // now we must transform this movement to the game board
            // and the robot
            Sequence endSeq;
            generateSequenceAndMoveRobot( endSeq, startSeq, bot, false );

            //std::cout << "end seq:   ";
            //endSeq.print(false);
            //std::cout << std::endl;

            // add separator for each card
            // if the game is not finished yet
            if ( endSeq.size() > 0 )
            {
                if ( isEndMove( endSeq.back() ) )
                {
                    // game is finished => stop here
                    break;
                }
            }
        }
        else
        {
            ok = false;
        }
    }

    // std::cout << "ok: " << ok << std::endl;

    return ok;
}

// transform the movement of the start sequence to the game board
// and the robot and generate end sequence for GUI
const bool Game::generateSequenceAndMoveRobot( Sequence& endSeq,
                                               const Sequence& startSeq,
                                               Bot& bot,
                                               Stats& stats,
                                               const bool recursiveCall ) const
{
    bool moved = false;

    for ( unsigned int ii = 0; ii < startSeq.size(); ii++ )
    {
        if ( !bot.isDestroyed() && !bot.isFinished() )
        {
            // check if this movement is valid
            // means if there is a wall that would block the movement
            // or if we would leave the field ( = invisible wall )
            if ( isValidMovement( startSeq.at(ii), bot ) )
            {
                moved = true;

                // only count if no end move
                if ( !isEndMove( startSeq.at(ii) ) )
                {
                    if ( !recursiveCall )
                    {
                        // add own move
                        stats.increase( Stats::SE_NUM_CARD_MOVES );
                    }
                    else
                    {
                        // add board move
                        stats.increase( Stats::SE_NUM_BOARD_MOVES );
                    }
                }

                endSeq.push_back(
                    BotFunctions::convertToSequenceString(
                        startSeq.at(ii), bot.getViewDirection() ) );

                // move robot by itself
                bot.move( startSeq.at(ii),
                          m_board.getWidth(), m_board.getHeight() );

                // std::cout << "end: " << botHasReachedEndPosition(bot) << std::endl;
                
                if ( botHasReachedEndPosition( bot ) )
                {
                    // robot has reched end
                    endSeq.push_back( "Z" );
                    bot.move( "Z", m_board.getWidth(),
                                     m_board.getHeight() );
                }

                // only if the movement is valid we will check the on entry
                const Position pos( bot.getPos() );

                if ( !bot.isDestroyed() && !bot.isFinished() &&
                     NULL != m_board[pos] )
                {
                    Sequence localSeq;

                    if ( bot.isLastMovement() )
                    {
                        // last action of the robot was a move
                        m_board[pos]->getSequenceOnEntry( localSeq,
                                           bot.getLastMovement() );
                    }
                    else if ( bot.isLastRotation() )
                    {
                        // a rotation on entry can only be done one time
                        if ( !recursiveCall )
                        {
                            // last action was a rotation
                            m_board[pos]->getSequenceOnEntry( localSeq,
                                               bot.getLastRotation() );
                        }
                    }
                    else
                    {
                        std::cerr << "Game::generateSequenceAndMoveRobot() "
                                  << "Error: Last action of robot was "
                                  << "neither move nor rotation."
                                  << std::endl;
                    }

                    // move robot recursivly
                    generateSequenceAndMoveRobot( endSeq, localSeq, bot, stats, true );

                    // check if robot is dead
                }
            }
            else if ( BE_GAME_LEVEL_HARD == BaseFunctions::getGameLevel() )
            {
                // game level is HARD, so we must check if the bot move
                // out of game board
                // bot only if there is not wall that stop us falling

                if ( bot.wouldLeaveBoard( startSeq.at(ii),
                                          m_board.getWidth(),
                                          m_board.getHeight() ) )
                {

                    Position pos ( bot.getPos() );
                    const BaseEnumDirection dir = BotFunctions::convertToDirection( startSeq.at(ii),
                                            bot.getViewDirection() );

                    //std::cout << "dir: " << bot.getViewDirection() << " "
                              //<< dir << " "
                              //<< m_board[pos]->canLeave( dir ) << std::endl;

                    // check if field can be left and next entered
                    if (  NULL == m_board[pos] || m_board[pos]->canLeave( dir ) )
                    {
                        moved = true;

                        endSeq.push_back(
                            BotFunctions::convertToSequenceString(
                                startSeq.at(ii), bot.getViewDirection() ) );

                        // robot is dead
                        endSeq.push_back( "X" );
                        bot.move( "X", m_board.getWidth(),
                                         m_board.getHeight() );
                    }
                }
            }
            // else we will ignore the movement
        }

    } // for

    // only in the first call we must check were there robot finally stands
    // and of course if the robot is not destroyed yet
    if ( !recursiveCall )
    {
        // define difference between robot movement and gameboard movement
        endSeq.push_back( "--" );

        bool isPushedByBelt = false;

        Position pos;

        // first phase: TE_PHASE_MOVE
        pos = bot.getPos();
        if ( !bot.isDestroyed() && !bot.isFinished() &&
             NULL != m_board[ pos ] )
        {
            Sequence localSeq;

            // get sequence for this robot when standing on this field
            m_board[pos]->getSequence( localSeq, TE_PHASE_MOVE );

            // move robot recursivly
            if ( generateSequenceAndMoveRobot( endSeq, localSeq, bot, stats, true ) )
            {
                moved = true;
                isPushedByBelt = true;
            }
        }

        // second phase: TE_PHASE_PUSH
        pos = bot.getPos();
        if ( !bot.isDestroyed() && !bot.isFinished() &&
             NULL != m_board[ pos ] )
        {
            Sequence localSeq;

            // get sequence for this robot when standing on this field
            m_board[pos]->getSequence( localSeq, TE_PHASE_PUSH );

            // move robot recursivly
            if ( generateSequenceAndMoveRobot( endSeq, localSeq, bot, stats, true ) )
            {
                moved = true;
                isPushedByBelt = false;
            }
        }

        // third phase: TE_PHASE_ROTATE
        pos = bot.getPos();
        if ( !bot.isDestroyed() && !bot.isFinished() &&
             NULL != m_board[ pos ] )
        {
            Sequence localSeq;

            // get sequence for this robot when standing on this field
            m_board[pos]->getSequence( localSeq, TE_PHASE_ROTATE );

            // move robot recursivly
            if ( generateSequenceAndMoveRobot( endSeq, localSeq, bot, stats, true ) )
            {
                moved = true;
                isPushedByBelt = false;
            }
        }

        // fourth phase: Rotation on conveyor belt
        pos = bot.getPos();
        if ( !bot.isDestroyed() && !bot.isFinished() &&
             NULL != m_board[ pos ] )
        {
            if ( bot.isLastMovement() )
            {
                Sequence localSeq;

                // get sequence for this robot when standing on this field
                m_board[pos]->getSequenceOnEntry( localSeq,
                                                  bot.getLastMovement(),
                                                  isPushedByBelt );

                // move robot recursivly
                if ( generateSequenceAndMoveRobot( endSeq, localSeq, bot, stats, true ) )
                {
                    moved = true;
                }
            }
        }
    }
    
    // delete -- if it's the last term
    if ( endSeq.size() > 0 && endSeq.back() == "--" )
    {
        endSeq.pop_back();
    }
    
    return moved;
}

// check if this movement is valid
const bool Game::isValidMovement( const std::string& move, const Bot& bot ) const
{
    bool valid = false;

    if ( "MF" == move || "MB" == move || "ML" == move ||
         "MR" == move || "MU" == move || "MD" == move )
    {
        // get new position if robot would move this way
        Position pos ( bot.getPos() );
        Position newPos;

        if ( bot.getNewPos( newPos, move,
                            m_board.getWidth(),
                            m_board.getHeight() ) )
        {
            if ( NULL != m_board[pos] && NULL != m_board[newPos] )
            {
                const BaseEnumDirection dir = BotFunctions::convertToDirection( move, bot.getViewDirection() );

                //std::cout << "dir: " << bot.getViewDirection() << " "
                          //<< dir << std::endl;

                // check if field can be left and next entered
                if ( m_board[pos]->canLeave( dir ) &&
                     m_board[newPos]->canEnter( dir ) )
                {
                    valid = true;
                }

                //std::cout << "old: " << pos.x() << " " << pos.y() << " "
                          //<< m_board[pos]->canLeave( dir );
                //m_board[pos]->print();
                //std::cout << "new: " << newPos.x() << " " << newPos.y() << " "
                          //<< m_board[newPos]->canEnter( dir );
                //m_board[newPos]->print();
                //std::cout << "valid: " << valid << std::endl;
            }
        }
    }
    else if ( "RL" == move || "RR" == move || "RU" == move )
    {
        // rotations are okay
        valid = true;
    }
    else if ( "X" == move || "Z" == move )
    {
        // destroying or finish is okay
        valid = true;
    }
    else
    {
        std::cerr << "Game::isValidMovement(string) "
                  << "Error: Movement "
                  << move.c_str()
                  << " not recognized."
                  << std::endl;
    }

    return valid;
}

// return true if string marks the end of the game
bool Game::isEndMove( const std::string& move )
{
    if ( "Z" == move ||
         "Y" == move ||
         "X" == move )
    {
        return true;
    }
    else
    {
        return false;
    }
}

