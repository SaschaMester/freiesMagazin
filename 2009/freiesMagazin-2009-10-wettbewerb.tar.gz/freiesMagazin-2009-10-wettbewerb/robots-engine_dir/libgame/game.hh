// *************************************************************************
// robots-engine - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef GAME_HH
#define GAME_HH

#include <string>

#include "gameboard.hh"
#include "carddeck.hh"
#include "bot.hh"
#include "stats.hh"

class Game
{

public:

    // Default constructor.
    // Loads all data from disk.
    Game();

    // Constructor.
    // Load board from disk.
    Game( const std::string& boardname );

    // Constructor.
    // Load board and card deck from disk.
    Game( const std::string& boardname, const std::string& deckname );

    // Destructor.
    ~Game();
    
    // save all data to disk
    const bool saveAll() const;
    
    // return true if all stored data is valid
    // and a game could be started.
    const bool isValid() const
    {
        return m_valid;
    }

    // return game board
    const GameBoard& getGameBoard() const
    {
        return m_board;
    }
    
    // return card deck
    const CardDeck& getCardDeck() const
    {
        return m_deck;
    }    
    
    // return bot
    const Bot& getBot() const
    {
        return m_bot;
    }

    // return true if string marks the end of the game
    static bool isEndMove( const std::string& move );

protected:

    // generate sequence for GUI from cards
    // and save it to disk
    const bool generateAndStoreSequence( const CardDeck& choosenCards )
    {
        return generateAndStoreSequence( choosenCards, m_bot );
    }

    // Same as before but with another robot.
    const bool generateAndStoreSequence( const CardDeck& choosenCards, Bot& bot ) const;

    // transform the movement of the start sequence to the game board
    // and the robot and generate end sequence for GUI
    // return true if bot was moved somehow
    const bool generateSequenceAndMoveRobot( Sequence& endSeq,
                                             const Sequence& startSeq,
                                             const bool recursiveCall )
    {
        Stats stats;
        return generateSequenceAndMoveRobot( endSeq, startSeq, m_bot, stats, recursiveCall );
    }

    // transform the movement of the start sequence to the game board
    // and the robot and generate end sequence for GUI
    // return true if bot was moved somehow
    const bool generateSequenceAndMoveRobot( Sequence& endSeq,
                                             const Sequence& startSeq,
                                             Stats& stats,
                                             const bool recursiveCall )
    {
        return generateSequenceAndMoveRobot( endSeq, startSeq, m_bot, stats, recursiveCall );
    }

    // Same as before but with another robot.
    const bool generateSequenceAndMoveRobot( Sequence& endSeq,
                                             const Sequence& startSeq,
                                             Bot& bot,
                                             const bool recursiveCall ) const
    {
        Stats stats;
        return generateSequenceAndMoveRobot( endSeq, startSeq, bot, stats, recursiveCall );
    }

    // Same as before but with another robot and stats.
    const bool generateSequenceAndMoveRobot( Sequence& endSeq,
                                             const Sequence& startSeq,
                                             Bot& bot,
                                             Stats& stats,
                                             const bool recursiveCall ) const;

    // check if this movement is valid
    // means if the robot moves against a wall
    const bool isValidMovement( const std::string& move ) const
    {
        return isValidMovement( move, m_bot );
    }

    // Same as before but with another robot.
    const bool isValidMovement( const std::string& move, const Bot& bot ) const;

    // return true if bot has reached end position
    const bool botHasReachedEndPosition() const
    {
        return botHasReachedEndPosition( m_bot );
    }

    // Same as before but with another robot.
    const bool botHasReachedEndPosition( const Bot& bot ) const;

    // Save game board to disc
    // as ascii with one char per tile
    // including robot
    // return true if everything is okay
    const bool saveExtendedAscii( const std::string& filename ) const;

    // game board with tiles
    GameBoard m_board;
    
    // card deck with cards
    CardDeck m_deck;
    
    // Robot to move
    Bot m_bot;
    
    // flag if game can be started
    bool m_valid;
};

#endif // GAME_HH
