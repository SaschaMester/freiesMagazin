// *************************************************************************
// robots-engine / libtiles - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// License: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef GAMEBOARD_H
#define GAMEBOARD_H

#include <string>
#include <vector>

#include "position.hh"
#include "basetile.hh"
#include "holetile.hh"
#include "oiltile.hh"
#include "walltile.hh"
#include "pushtile.hh"
#include "squeezetile.hh"
#include "rotationtile.hh"
#include "movetile.hh"
#include "tileenums.hh"

// The gameboard holds width x height pointers
// to the tiles the robot will later move onto.
class GameBoard
{
public:

    // Default constructor
    GameBoard();

    // Create empty game board with
    // width x height fields.
    GameBoard( const unsigned int width, const unsigned int height );

    // Copy constructor.
    GameBoard( const GameBoard& board );

    // Destructor.
    ~GameBoard();

    // Assigment operator.
    const GameBoard& operator=( const GameBoard& board );

    // Save game board to disc
    // with all information.
    // return true if everything is okay
    const bool save( const std::string& filename ) const;

    // Save game board to disc
    // as ascii with one char per tile
    // return true if everything is okay
    const bool saveAscii( const std::string& filename ) const;

    // Save game board to disc
    // as ascii with several chars per tile
    // return true if everything is okay
    const bool saveExtendedAscii( const std::string& filename ) const;

    // Load game board from disc
    // as ascii with one char per tile
    // return true if everything is okay
    const bool loadAscii( const std::string& filename );

    // return width of game board
    const unsigned int getWidth() const
    {
        return m_width;
    }

    // return height of game board
    const unsigned int getHeight() const
    {
        return m_height;
    }

    // access tile element
    const BaseTile* operator[] ( const Position& pos ) const;

    // check if game board has exactly one start and one end
    const bool isValid() const;

    // return (first) start position
    const Position getStartPos() const;

    // return (first) end position
    const Position getEndPos() const;

    // return (first) start view direction of bot
    const BaseEnumDirection getStartViewDirection() const;
    
    // return position of tile depending on board dimensions
    const TileMaskPosition isBorderTile( const Position& pos ) const;

protected:

    // clear all elements (delete pointers)
    // but do not change the size!
    void clear();

    // clear all elements (delete pointers)
    // and deletes the allocated memory for the board
    // set size to (0,0)
    void clearAll();

    // set new size for game board
    // all elements will be deleted!
    void setSize( const unsigned int width, const unsigned int height );

    // associate pointer with a new tile
    // Attention: The pointer must not be deleted outside!
    const bool setTile( const Position& pos, BaseTile* tile );

    // dynamical array of pointers
    // to the tiles
    std::vector<BaseTile*> m_board;

    // width of game board
    unsigned int m_width;

    // height of game board
    unsigned int m_height;

};
#endif // GAMEBOARD_H
