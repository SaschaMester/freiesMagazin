// *************************************************************************
// robots-engine / libtiles - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// License: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef BASETILE_HH
#define BASETILE_HH

#include <fstream>

#include "sequence.hh"
#include "tileenums.hh"
#include "tilefunctions.hh"

class BaseTile
{
public:
    // Default constructor
    BaseTile()
    {}

    // return sides on which this tile has walls
    virtual const TileMaskWall getWalls() const
    {
        return TM_WALL_NONE;
    }

    // return true if this tile has walls somehow
    const bool hasWalls() const
    {
        return ( TM_WALL_NONE != getWalls() );
    }

    // return direction in which the robot will be moved
    virtual const TileMaskMove getMoveDir() const
    {
        return TM_MOVE_NONE;
    }

    // return direction in which the robot will be pushed
    virtual const TileMaskPush getPushDir() const
    {
        return TM_PUSH_NONE;
    }

    // return the rotation direction
    virtual const TileEnumRotation getRotDirection() const
    {
        return TE_ROTATION_NONE;        
    }

    // copy tile and return pointer to it
    virtual BaseTile* clone() const
    {
        return new BaseTile(*this);
    }
    
    // return true if this is a special tile
    virtual const bool isType( const TileEnumType type ) const
    {
        return ( TE_TYPE_FLOOR == type );
    }
    
    // return start direction of bot
    virtual const TileEnumDirection getStartDirection() const
    {
        return TE_DIRECTION_NONE;
    }
    
    // return sequence with commands for the robot
    // when standing on this tile
    virtual void getSequence( Sequence& list, const TileEnumPhase phase ) const
    {
        // do nothing
    }
    
    // return sequence with commands for the robot
    // when entering this tile after movement
    virtual void getSequenceOnEntry( Sequence& list,
                                     const BaseEnumDirection move ) const
    {
        // do nothing
    }

    // return sequence with commands for the robot
    // when entering this tile after rotation
    virtual void getSequenceOnEntry( Sequence& list,
                                     const BaseEnumRotation rotation ) const
    {
        // do nothing
    }

    // return sequence with commands for the robot
    // when entering this tile
    //  * move - the direction gives the last direction in which the
    //           robot has been moved (by itself or other)
    //  * botIsPushed - is set to true if the bot has been
    //                  pushed on this field by another conveyor belt (only!)
    virtual void getSequenceOnEntry( Sequence& list,
                                     const BaseEnumDirection move,
                                     const bool botIsPushed ) const
    {
        // do nothing
    }

    // return true if this tile can be left in direction of movement
    virtual const bool canLeave( const BaseEnumDirection move ) const
    {
        return true;
    }

    // return true if this tile can be entered from direction of movement
    virtual const bool canEnter( const BaseEnumDirection move ) const
    {
        return true;
    }

    // Save tile to stream
    // with all informations.
    // return true if everything is okay
    const bool save( std::ofstream& outFile ) const;

    // Save tile to stream
    // as ascii with one char
    // return true if everything is okay
    const bool saveAscii( std::ofstream& outFile ) const;

    // Save tile to stream
    // as ascii with several chars.
    // The line may be 0-2 and says in which line we are.
    // return true if everything is okay
    const bool saveExtendedAscii( std::ofstream& outFile,
                                  const int line ) const;

    // return generated tile to a special character
    static BaseTile *getTileFromChar( const char c );

    // print data to stdout
    void print() const;

protected:

    // Save tile to stream
    virtual const bool saveInternal( std::ofstream& outFile ) const;

    // Save tile to stream
    virtual const bool saveAsciiInternal( std::ofstream& outFile ) const;

    // Save tile to stream
    virtual const bool saveExtendedAsciiInternal( std::ofstream& outFile,
                                                  const int line ) const;


};

#endif // BASETILE_HH
