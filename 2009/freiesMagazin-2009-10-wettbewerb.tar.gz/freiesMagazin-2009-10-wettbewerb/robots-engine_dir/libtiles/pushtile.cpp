// *************************************************************************
// robots-engine / libtiles - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// License: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>

#include "pushtile.hh"
#include "basefunctions.hh"

// return sequence with commands for the robot
// when standing on this tile
void PushTile::getSequence( Sequence& list, const TileEnumPhase phase ) const
{
    if ( TE_PHASE_PUSH == phase )
    {
        list.push_back( TileFunctions::convertToSequenceString( m_pushDirection ) );
    }
}

// return true if this tile can be left in direction of movement
const bool PushTile::canLeave( const BaseEnumDirection move ) const
{
    // check if there is a wall in the direction we want to leave
    const TileMaskWall wall = TileFunctions::convertToWall( move );
    
    return ( !( m_walls & wall ) );
}

// return true if this tile can be entered from direction of movement
const bool PushTile::canEnter( const BaseEnumDirection move ) const
{
    // check if there is a wall in the direction we want to enter
    const BaseEnumDirection oppMove = BaseFunctions::getOppositeDirection( move );
    const TileMaskWall wall = TileFunctions::convertToWall( oppMove );
    
    return ( !( m_walls & wall ) );
}
    
// Save tile to stream
const bool PushTile::saveInternal( std::ofstream& outFile ) const
{
    outFile << "PUSHER    "
            << TileFunctions::convertToAsciiString ( m_pushDirection )
            << std::endl;
    return true;
}

// Save tile to stream
const bool PushTile::saveAsciiInternal( std::ofstream& outFile ) const
{
    bool ok = true;
    
    switch ( m_pushDirection )
    {
        case TM_PUSH_LEFT:
            outFile << "C";
            break;
        case TM_PUSH_RIGHT:
            outFile << "D";
            break;
        case TM_PUSH_UP:
            outFile << "E";
            break;
        case TM_PUSH_DOWN:
            outFile << "F";
            break;
        default:
            ok = false;
            break;
    }
    
    return ok;
}

// Save tile to stream
const bool PushTile::saveExtendedAsciiInternal( std::ofstream& outFile,
                                                const int line ) const

{
    bool ok = true;
    
    switch ( m_pushDirection )
    {
        case TM_PUSH_LEFT:
            outFile << "    <";
            break;
        case TM_PUSH_RIGHT:
            outFile << ">    ";
            break;
        case TM_PUSH_UP:
            switch ( line )
            {
                case 0:
                case 1:
                    outFile << "     ";
                    break;
                case 2:
                    outFile << "^^^^^";
                    break;
                default:                    
                    ok = false;
                    break;
            }
            break;
        case TM_PUSH_DOWN:
            switch ( line )
            {
                case 0:
                    outFile << "vvvvv";
                    break;
                case 1:
                case 2:
                    outFile << "     ";
                    break;
                default:                    
                    ok = false;
                    break;
            }
            break;
        default:
            ok = false;
            break;
    }
    
    return ok;
}
