// *************************************************************************
// robots-engine / libtiles - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// License: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>

#include "oiltile.hh"
#include "basefunctions.hh"

// return sequence with commands for the robot
// when entering this tile after movement
void OilTile::getSequenceOnEntry( Sequence& list,
                                  const BaseEnumDirection move ) const
{
    if ( BE_GAME_LEVEL_EASY != BaseFunctions::getGameLevel() )
    {
        // oil will move the robot in the direction
        // is has been moved before
        list.push_back( TileFunctions::convertToSequenceString( move ) );
    }
}

// return sequence with commands for the robot
// when entering this tile after rotation
void OilTile::getSequenceOnEntry( Sequence& list,
                                  const BaseEnumRotation rotation ) const
{
    if ( BE_GAME_LEVEL_EASY != BaseFunctions::getGameLevel() )
    {
        // oil will rotate the robot in the direction
        // is has been rotated before
        list.push_back( TileFunctions::convertToSequenceString( rotation ) );
    }
}
    
// Save tile to stream
const bool OilTile::saveInternal( std::ofstream& outFile ) const
{
    bool ok = false;
    
    if ( BE_GAME_LEVEL_EASY != BaseFunctions::getGameLevel() )
    {
        outFile << "OIL" << std::endl;
        ok = true;
    }
    else
    {
        ok = BaseTile::saveInternal( outFile );
    }
    
    return ok;
}

// Save tile to stream
const bool OilTile::saveAsciiInternal( std::ofstream& outFile ) const
{
    bool ok = false;
    
    if ( BE_GAME_LEVEL_EASY != BaseFunctions::getGameLevel() )
    {
        outFile << "O";
        ok = true;
    }
    else
    {
        ok = BaseTile::saveAsciiInternal( outFile );
    }
    
    return ok;
}

// Save tile to stream
const bool OilTile::saveExtendedAsciiInternal( std::ofstream& outFile,
                                               const int line ) const

{
    bool ok = true;

    if ( BE_GAME_LEVEL_EASY != BaseFunctions::getGameLevel() )
    {
        switch ( line )
        {
            case 0:
                outFile << " ooo ";
                break;
            case 1:
                outFile << "ooooo";
                break;
            case 2:
                outFile << " ooo ";
                break;
            default: 
                ok = false;
                break;
        }
    }
    else
    {
        ok = BaseTile::saveExtendedAsciiInternal( outFile, line );
    }
    
    return ok;
}
