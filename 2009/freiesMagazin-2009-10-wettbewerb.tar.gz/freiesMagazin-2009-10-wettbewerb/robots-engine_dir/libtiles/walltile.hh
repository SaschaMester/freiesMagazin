// *************************************************************************
// robots-engine / libtiles - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// License: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef WALLTILE_H
#define WALLTILE_H

#include "basetile.hh"

class WallTile : public BaseTile
{
public:
    // Constructor
    // create wall tile with some walls
    WallTile( const TileMaskWall walls )
    : m_walls(walls)
    {
    }

    // return sides on which this tile has walls
    virtual const TileMaskWall getWalls() const
    {
        return m_walls;
    }

    // return true if this is a special tile
    virtual const bool isType( const TileEnumType type ) const
    {
        return ( TE_TYPE_WALL == type );
    }

    // copy tile and return pointer to it
    virtual WallTile* clone() const
    {
        return new WallTile(*this);
    }

    // return true if this tile can be left in direction of movement
    virtual const bool canLeave( const BaseEnumDirection move ) const;

    // return true if this tile can be entered from direction of movement
    virtual const bool canEnter( const BaseEnumDirection move ) const;
        
private:

    // Save tile to stream
    virtual const bool saveInternal( std::ofstream& outFile ) const;

    // Save tile to stream
    virtual const bool saveAsciiInternal( std::ofstream& outFile ) const;

    // Save tile to stream
    virtual const bool saveExtendedAsciiInternal( std::ofstream& outFile,
                                                  const int line ) const;

protected:
    // flags which walls are shown
    TileMaskWall m_walls; 

};

#endif // WALLTILE_H
