// *************************************************************************
// robots-engine / libtiles - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// License: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>

#include "tilefunctions.hh"

const SeqString TileFunctions::convertToSequenceString( const BaseEnumRotation rot )
{
    SeqString str;

    switch ( rot )
    {
        case BE_ROTATION_LEFT:
            str = "RL";
            break;
        case BE_ROTATION_RIGHT:
            str = "RR";
            break;
        case BE_ROTATION_UTURN:
            str = "RU";
            break;
        default:
            break;
    }

    return str;
}

const SeqString TileFunctions::convertToSequenceString( const BaseEnumDirection move )
{
    SeqString str;

    switch ( move )
    {
        case BE_DIRECTION_LEFT:
            str = "ML";
            break;
        case BE_DIRECTION_RIGHT:
            str = "MR";
            break;
        case BE_DIRECTION_UP:
            str = "MU";
            break;
        case BE_DIRECTION_DOWN:
            str = "MD";
            break;
        default:
            break;
    }

    return str;
}

const SeqString TileFunctions::convertToSequenceString( const TileEnumRotation rot )
{
    SeqString str;

    switch ( rot )
    {
        case TE_ROTATION_LEFT:
            str = "RL";
            break;
        case TE_ROTATION_RIGHT:
            str = "RR";
            break;
        default:
            break;
    }

    return str;
}

const SeqString TileFunctions::convertToSequenceString( const TileEnumDirection move )
{
    SeqString str;

    switch ( move )
    {
        case TE_DIRECTION_LEFT:
            str = "ML";
            break;
        case TE_DIRECTION_RIGHT:
            str = "MR";
            break;
        case TE_DIRECTION_UP:
            str = "MU";
            break;
        case TE_DIRECTION_DOWN:
            str = "MD";
            break;
        default:
            break;
    }

    return str;
}

const SeqString TileFunctions::convertToSequenceString( const TileMaskPush move )
{
    SeqString str;

    switch ( move )
    {
        case TM_PUSH_LEFT:
            str = "ML";
            break;
        case TM_PUSH_RIGHT:
            str = "MR";
            break;
        case TM_PUSH_UP:
            str = "MU";
            break;
        case TM_PUSH_DOWN:
            str = "MD";
            break;
        default:
            break;
    }

    return str;
}

const SeqString TileFunctions::convertToSequenceString( const TileMaskMove move )
{
    SeqString str;

    switch ( move )
    {
        case TM_MOVE_LEFT:
            str = "ML";
            break;
        case TM_MOVE_RIGHT:
            str = "MR";
            break;
        case TM_MOVE_UP:
            str = "MU";
            break;
        case TM_MOVE_DOWN:
            str = "MD";
            break;
        default:
            break;
    }

    return str;
}

const std::string TileFunctions::convertToAsciiString( const TileEnumRotation rot )
{
    std::string str;

    switch ( rot )
    {
        case TE_ROTATION_LEFT:
            str = "LEFT";
            break;
        case TE_ROTATION_RIGHT:
            str = "RIGHT";
            break;
        default:
            break;
    }

    return str;
}

const std::string TileFunctions::convertToAsciiString( const TileEnumDirection move )
{
    std::string str;

    switch ( move )
    {
        case TE_DIRECTION_LEFT:
            str = "LEFT";
            break;
        case TE_DIRECTION_RIGHT:
            str = "RIGHT";
            break;
        case TE_DIRECTION_UP:
            str = "UP";
            break;
        case TE_DIRECTION_DOWN:
            str = "DOWN";
            break;
        default:
            break;
    }

    return str;
}

const std::string TileFunctions::convertToAsciiString( const TileMaskPush move )
{
    std::string str;

    switch ( move )
    {
        case TM_PUSH_LEFT:
            str = "LEFT";
            break;
        case TM_PUSH_RIGHT:
            str = "RIGHT";
            break;
        case TM_PUSH_UP:
            str = "UP";
            break;
        case TM_PUSH_DOWN:
            str = "DOWN";
            break;
        default:
            break;
    }

    return str;
}

const std::string TileFunctions::convertToAsciiString( const TileMaskMove move )
{
    std::string str;

    switch ( move )
    {
        case TM_MOVE_LEFT:
            str = "LEFT";
            break;
        case TM_MOVE_RIGHT:
            str = "RIGHT";
            break;
        case TM_MOVE_UP:
            str = "UP";
            break;
        case TM_MOVE_DOWN:
            str = "DOWN";
            break;
        default:
            break;
    }

    return str;
}

const std::string TileFunctions::convertToAsciiString( const TileMaskSqueeze move )
{
    std::string str;

    switch ( move )
    {
        case TM_SQUEEZE_LEFTRIGHT:
            str = "LEFTRIGHT";
            break;
        case TM_SQUEEZE_UPDOWN:
            str = "UPDOWN";
            break;
        default:
            break;
    }

    return str;
}

// set wall as opposite of direction
const TileMaskWall TileFunctions::convertToWall( const TileMaskPush dir )
{
    TileMaskWall wall = TM_WALL_NONE;

    switch ( dir )
    {
        case TM_PUSH_LEFT:
            wall = TM_WALL_RIGHT;
            break;
        case TM_PUSH_RIGHT:
            wall = TM_WALL_LEFT;
            break;
        case TM_PUSH_UP:
            wall = TM_WALL_DOWN;
            break;
        case TM_PUSH_DOWN:
            wall = TM_WALL_UP;
            break;
        default:
            std::cerr << "convertToWall(dir) "
                      << "Error: Direction "
                      << dir
                      << " must be one of "
                      << TM_PUSH_LEFT      << ", "
                      << TM_PUSH_RIGHT     << ", "
                      << TM_PUSH_UP        << ", "
                      << TM_PUSH_DOWN      << "."
                      << std::endl;
            break;
    }

    return wall;
}

// set wall as opposite of direction
const TileMaskWall TileFunctions::convertToWall( const TileMaskSqueeze dir )
{
    TileMaskWall wall = TM_WALL_NONE;

    switch ( dir )
    {
        case TM_SQUEEZE_LEFTRIGHT:
            wall = TM_WALL_LEFTRIGHT;
            break;
        case TM_SQUEEZE_UPDOWN:
            wall = TM_WALL_UPDOWN;
            break;
        default:
            std::cerr << "convertToWall(dir) "
                      << "Error: Direction "
                      << dir
                      << " must be "
                      << TM_SQUEEZE_LEFTRIGHT << " or "
                      << TM_SQUEEZE_UPDOWN    << "."
                      << std::endl;
            break;
    }

    return wall;
}


// set wall as opposite of direction
const TileMaskWall TileFunctions::convertToWall( const BaseEnumDirection dir )
{
    TileMaskWall wall = TM_WALL_NONE;

    switch ( dir )
    {
        case BE_DIRECTION_LEFT:
            wall = TM_WALL_LEFT;
            break;
        case BE_DIRECTION_RIGHT:
            wall = TM_WALL_RIGHT;
            break;
        case BE_DIRECTION_UP:
            wall = TM_WALL_UP;
            break;
        case BE_DIRECTION_DOWN:
            wall = TM_WALL_DOWN;
            break;
        default:
            std::cerr << "convertToWall(dir) "
                      << "Error: Direction "
                      << dir
                      << " must be one of "
                      << BE_DIRECTION_LEFT      << ", "
                      << BE_DIRECTION_RIGHT     << ", "
                      << BE_DIRECTION_UP        << ", "
                      << BE_DIRECTION_DOWN      << "."
                      << std::endl;
            break;
    }

    return wall;
}

// convert tile direction to base direction
const BaseEnumDirection TileFunctions::convertTileToBaseDirection( const TileEnumDirection dir )
{
    return ( (BaseEnumDirection)dir );
}
