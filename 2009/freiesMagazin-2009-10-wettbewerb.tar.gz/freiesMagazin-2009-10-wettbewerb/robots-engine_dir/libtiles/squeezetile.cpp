// *************************************************************************
// robots-engine / libtiles - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// License: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>

#include "squeezetile.hh"
#include "basefunctions.hh"

// return sequence with commands for the robot
// when standing on this tile
void SqueezeTile::getSequence( Sequence& list, const TileEnumPhase phase ) const
{
    if ( BE_GAME_LEVEL_EASY != BaseFunctions::getGameLevel() )
    {
        // robot is dead
        if ( TE_PHASE_PUSH == phase )
        {
            list.push_back( "X" );
        }
    }
}

// return true if this tile can be left in direction of movement
const bool SqueezeTile::canLeave( const BaseEnumDirection move ) const
{
    if ( BE_GAME_LEVEL_EASY != BaseFunctions::getGameLevel() )
    {
        // check if there is a wall in the direction we want to leave
        const TileMaskWall wall = TileFunctions::convertToWall( move );
        
        return ( !( m_walls & wall ) );
    }
    else
    {
        return BaseTile::canLeave( move );
    }
}

// return true if this tile can be entered from direction of movement
const bool SqueezeTile::canEnter( const BaseEnumDirection move ) const
{
    if ( BE_GAME_LEVEL_EASY != BaseFunctions::getGameLevel() )
    {
        // check if there is a wall in the direction we want to enter
        const BaseEnumDirection oppMove = BaseFunctions::getOppositeDirection( move );
        const TileMaskWall wall = TileFunctions::convertToWall( oppMove );
        
        return ( !( m_walls & wall ) );
    }
    else
    {
        return BaseTile::canEnter( move );
    }
}

// Save tile to stream
const bool SqueezeTile::saveInternal( std::ofstream& outFile ) const
{
    bool ok = true;
    
    if ( BE_GAME_LEVEL_EASY != BaseFunctions::getGameLevel() )
    {
        outFile << "SQUEEZER  "
                << TileFunctions::convertToAsciiString ( m_squeezeDirection )
                << std::endl;
        ok = true;
    }
    else
    {
        ok = BaseTile::saveInternal( outFile );
    }
        
    return ok;
}

// Save tile to stream
const bool SqueezeTile::saveAsciiInternal( std::ofstream& outFile ) const
{
    bool ok = true;
    
    if ( BE_GAME_LEVEL_EASY != BaseFunctions::getGameLevel() )
    {
        switch ( m_squeezeDirection )
        {
            case TM_SQUEEZE_LEFTRIGHT:
                outFile << "M";
                break;
            case TM_SQUEEZE_UPDOWN:
                outFile << "N";
                break;
            default:
                ok = false;
                break;
        }
    }
    else
    {
        ok = BaseTile::saveAsciiInternal( outFile );
    }

    return ok;
}

// Save tile to stream
const bool SqueezeTile::saveExtendedAsciiInternal( std::ofstream& outFile,
                                                   const int line ) const

{
    bool ok = true;
    
    if ( BE_GAME_LEVEL_EASY != BaseFunctions::getGameLevel() )
    {
        switch ( m_squeezeDirection )
        {
            case TM_SQUEEZE_LEFTRIGHT:
                outFile << ">   <";
                break;
            case TM_SQUEEZE_UPDOWN:
                switch ( line )
                {
                    case 0:
                        outFile << "vvvvv";
                        break;
                    case 1:
                        outFile << "     ";
                        break;
                    case 2:
                        outFile << "^^^^^";
                        break;
                    default:                    
                        ok = false;
                        break;
                }
                break;
            default:
                ok = false;
                break;
        }
    }
    else
    {
        ok = BaseTile::saveExtendedAsciiInternal( outFile, line );
    }

    return ok;
}
