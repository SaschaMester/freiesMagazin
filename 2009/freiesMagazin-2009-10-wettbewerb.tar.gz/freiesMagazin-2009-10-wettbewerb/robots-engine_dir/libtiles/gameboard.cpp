// *************************************************************************
// robots-engine / libtiles - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// License: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>

#include "gameboard.hh"

// Default constructor
GameBoard::GameBoard()
: m_width(0), m_height(0)
{
}

// Create empty game board with
// width x height fields.
GameBoard::GameBoard( const unsigned int width, const unsigned int height )
: m_width(0), m_height(0)
{
    setSize( width, height );
}

// Copy constructor.
GameBoard::GameBoard( const GameBoard& board )
{
    operator=(board);
}

// Destructor.
GameBoard::~GameBoard()
{
    clearAll();
}

// Assigment operator.
const GameBoard& GameBoard::operator=( const GameBoard& board )
{
    // delete old pointers
    clear();

    // set correct size
    setSize( board.getWidth(), board.getHeight() );

    // copy each pointer as deep copy
    for ( unsigned int jj = 0; jj < getHeight(); jj++ )
    {
        for ( unsigned int ii = 0; ii < getWidth(); ii++ )
        {
            const Position pos( ii, jj );

            if ( NULL != board[pos] )
            {
                setTile ( pos, board[pos]->clone() );
            }
        }
    }

    return (*this);
}

// access tile element
// boundary check only in debug version
const BaseTile* GameBoard::operator[] ( const Position& pos ) const
{
    if ( pos.x() < getWidth() &&
         pos.y() < getHeight() )
    {
        return m_board.at(pos.x()+pos.y()*getWidth());
    }

    std::cerr << "GameBoard::operator[] "
              << " Access from ("
              << pos.x() << "," << pos.y()
              << ") is out of bounds ("
              << getWidth()-1 << "," << getHeight()-1
              << ")."
              << std::endl;

    return NULL;
}

// clear all elements (delete pointers)
// but do not change the size!
void GameBoard::clear()
{
    for ( unsigned int jj = 0; jj < getHeight(); jj++ )
    {
        for ( unsigned int ii = 0; ii < getWidth(); ii++ )
        {
            const unsigned int pos = ii+jj*getWidth();

            if ( NULL != m_board[pos] )
            {
                delete m_board[pos];
                m_board[pos] = NULL;
            }
        }
    }
}

// clear all elements (delete pointers)
// and deletes the allocated memory for the board
// set size to (0,0)
void GameBoard::clearAll()
{
    // first delete the BaseTile pointers
    clear();

    // delete game board
    m_board.clear();

    m_height = 0;
    m_width = 0;
}

// set new size for game board
// all elements will be deleted!
void GameBoard::setSize( const unsigned int width, const unsigned int height )
{
    // store old size
    const unsigned int oldWidth = getWidth();
    const unsigned int oldHeight = getHeight();

    m_board.resize( width*height );

    // set new pointers to NULL
    for ( unsigned int jj = 0; jj < getHeight(); jj++ )
    {
        for ( unsigned int ii = oldWidth; ii < getWidth(); ii++ )
        {
            m_board[ii+jj*getWidth()] = NULL;
        }
    }

    for ( unsigned int jj = oldHeight; jj < getHeight(); jj++ )
    {
        for ( unsigned int ii = 0; ii < getWidth(); ii++ )
        {
            m_board[ii+jj*getWidth()] = NULL;
        }
    }

    // memory could be allocated
    m_width = width;
    m_height = height;
}

// associate pointer with a new tile
// Attention: The pointer must not be deleted outside!
const bool GameBoard::setTile( const Position& pos, BaseTile* tile )
{
    bool ok = false;

    if ( 0 <= pos.x() && pos.x() < getWidth() &&
         0 <= pos.y() && pos.y() < getHeight() )
    {
        const unsigned pos2 = pos.x()+pos.y()*m_width;

        // delete this tile
        if ( NULL != m_board[pos2] )
        {
            delete m_board[pos2];
            m_board[pos2] = NULL;
        }

        // set new pointer
        m_board[pos2] = tile;

        ok = true;
    }
    else
    {
        std::cerr << "GameBoard::setTile(pos,tile) "
                  << " Error: Access from ("
                  << pos.x() << "," << pos.y()
                  << ") is out of bounds ("
                  << getWidth()-1 << "," << getHeight()-1
                  << ")."
                  << std::endl;
    }

    return ok;
}

// Save game board to disc
// with all information.
// return true if everything is okay
const bool GameBoard::save( const std::string& filename ) const
{
    bool ok = false;

    if ( !filename.empty() )
    {
        std::ofstream outFile;

        outFile.open( filename.c_str(), std::ios::out );

        if ( outFile.good() )
        {
            // in the first lines we store width and height
            outFile << getWidth() << " "
                    << getHeight() << std::endl;

            for ( unsigned int jj = 0; jj < getHeight(); jj++ )
            {
                for ( unsigned int ii = 0; ii < getWidth(); ii++ )
                {
                    if ( NULL != m_board[ii+jj*getWidth()] )
                    {
                        // save tile directly to file
                        if ( !m_board[ii+jj*getWidth()]->save( outFile ) )
                        {
                            return ok;
                        }
                    }
                    else
                    {
                        // tile is not defined on board
                        outFile << "NULL" << std::endl;
                    }
                }
            }

            outFile.close();

            ok = true;
        }
        else
        {
            std::cerr << "GameBoard::save(string) "
                      << "Error: File "
                      << filename.c_str()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "GameBoard::save(string) "
                  << "Error: Filename is empty."
                  << std::endl;
    }

    return ok;
}

// Save game board to disc
// as ascii with one char per tile
// return true if everything is okay
const bool GameBoard::saveAscii( const std::string& filename ) const
{
    bool ok = false;

    if ( !filename.empty() )
    {
        std::ofstream outFile;

        outFile.open( filename.c_str(), std::ios::out );

        if ( outFile.good() )
        {
            // in the first lines we store width and height
            outFile << m_width << " "
                    << m_height << std::endl;

            for ( unsigned int jj = 0; jj < getHeight(); jj++ )
            {
                for ( unsigned int ii = 0; ii < getWidth(); ii++ )
                {
                    if ( NULL != m_board[ii+jj*getWidth()] )
                    {
                        // save tile directly to file
                        if ( !m_board[ii+jj*getWidth()]->saveAscii( outFile ) )
                        {
                            return ok;
                        }
                    }
                    else
                    {
                        // tile is not defined on board
                        // use floor tile
                        outFile << " ";
                    }
                }
                // after each line we must add a linebreak
                outFile << std::endl;
            }

            outFile.close();

            ok = true;
        }
        else
        {
            std::cerr << "GameBoard::saveAscii(string) "
                      << "Error: File "
                      << filename.c_str()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "GameBoard::saveAscii(string) "
                  << "Error: Filename is empty."
                  << std::endl;
    }

    return ok;
}

// Save game board to disc
// as ascii with one char per tile
// return true if everything is okay
const bool GameBoard::saveExtendedAscii( const std::string& filename ) const
{
    bool ok = false;

    if ( !filename.empty() )
    {
        std::ofstream outFile;

        outFile.open( filename.c_str(), std::ios::out );

        if ( outFile.good() )
        {
            // in the first lines we store width and height
            // outFile << m_width  << " "
            //         << m_height << std::endl;

            for ( unsigned int jj = 0; jj < getHeight(); jj++ )
            {
                for ( unsigned int kk = 0; kk < 3; kk++)
                {
                    for ( unsigned int ii = 0; ii < getWidth(); ii++ )
                    {
                        if ( NULL != m_board[ii+jj*getWidth()] )
                        {
                            // save tile directly to file
                            if ( !m_board[ii+jj*getWidth()]->saveExtendedAscii( outFile, kk ) )
                            {
                                return ok;
                            }
                        }
                        else
                        {
                            // tile is not defined on board
                            // use floor tile
                            outFile << "     ";
                        }
                    }
                    // after each line we must add a linebreak
                    outFile << std::endl;
                }
            }

            outFile.close();

            ok = true;
        }
        else
        {
            std::cerr << "GameBoard::saveAscii(string) "
                      << "Error: File "
                      << filename.c_str()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "GameBoard::saveAscii(string) "
                  << "Error: Filename is empty."
                  << std::endl;
    }

    return ok;
}

// Load game board from disc
// as ascii with one char per tile
// return true if everything is okay
const bool GameBoard::loadAscii( const std::string& filename )
{
    bool ok = false;

    if ( !filename.empty() )
    {
        std::ifstream inFile;

        inFile.open( filename.c_str(), std::ios::in );

        if ( inFile.good() )
        {
            // in the first lines we have stored width and height
            int width = -1;
            int height = -1;
            char c = 0;
            BaseTile *tile = NULL;

            inFile >> width;
            // at the end of the line there is a line break
            // c = (char)inFile.get();

            if ( !inFile.good() )
            {
                std::cerr << "GameBoard::loadAscii(string) "
                          << "Error: Width is missing."
                          << std::endl;
                inFile.close();
                return ok;
            }
            
            inFile >> height;

            // at the end of the line there is a line break
            //c = (char)inFile.get();
            
            if ( !inFile.good() )
            {
                std::cerr << "GameBoard::loadAscii(string) "
                          << "Error: Height is missing."
                          << std::endl;
                inFile.close();
                return ok;
            }
            
            if ( width < 0 || height < 0 )
            {
                std::cerr << "GameBoard::loadAscii(string) "
                          << "Error: Width "
                          << width
                          << " or height "
                          << height
                          << " would be negative."
                          << std::endl;
                inFile.close();
                return ok;
            }

            // set new size
            setSize( width, height );

            // next there should be a line break
            c = (char)inFile.get();
            
            if ( '\n' != c )
            {
                std::cerr << "GameBoard::loadAscii(string) "
                          << "Error: Linebreak expected after width and height."
                          << std::endl;
                inFile.close();
                return ok;
            }

            // read line char by char
            for ( unsigned int jj = 0; jj < getHeight(); jj++ )
            {
                unsigned int ii = 0;
                for ( ii = 0; ii < getWidth(); ii++ )
                {
                    c = (char)inFile.get();
                    // std::cout << ii << "," << jj << ": " << (int)c << std::endl;
                    
                    // depending on the character we must create the tile
                    tile = BaseTile::getTileFromChar( c );
                    
                    if ( tile )
                    {
                        // finally set the tile
                        if ( !setTile ( Position(ii, jj), tile) )
                        {
                            inFile.close();
                            return ok;
                        }

                        // remove pointer again
                        tile = NULL;
                    }
                    else
                    {
                        // no tile given => character not recognized
                        if ( '\n' == c )
                        {
                            // this is a linebreak and means that there
                            // are not enough characters in this line
                            std::cerr << "GameBoard::loadAscii(string) "
                                      << "Error: Linebreak found but character expected "
                                      << "at line number "
                                      << jj
                                      << ", position "
                                      << ii
                                      << " (starts at [0,0])."
                                      << std::endl;
                        }
                        else if ( -1 == (int)c )
                        {
                            // end of file
                            std::cerr << "GameBoard::loadAscii(string) "
                                      << "Error: End of file reached too early "
                                      << "at line number "
                                      << jj
                                      << ", position "
                                      << ii
                                      << " (starts at [0,0])."
                                      << std::endl;
                        }
                        inFile.close();
                        return ok;
                    }
                }
                
                // at the end of the line there is a line break
                c = (char)inFile.get();
                
                if ( '\n' != c )
                {
                    std::cerr << "GameBoard::loadAscii(string) "
                              << "Error: Linebreak expected at end of"
                              << " line number "
                              << jj
                              << " position "
                              << ii
                              << ", (starts at [0,0]) but got "
                              << (int)c
                              << "."
                              << std::endl;
                    inFile.close();
                    return ok;
                }                
            }

            inFile.close();

            ok = true;
            
        }
        else
        {
            std::cerr << "GameBoard::loadAscii(string) "
                      << "Error: File "
                      << filename.c_str()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "GameBoard::loadAscii(string) "
                  << "Error: Filename is empty."
                  << std::endl;
    }

    return ok;
}

// check if game board has exactly one start and one end
const bool GameBoard::isValid() const
{
    bool startFound = false;
    bool endFound = false;

    bool valid = true;

    for ( unsigned int jj = 0; jj < getHeight(); jj++ )
    {
        for ( unsigned int ii = 0; ii < getWidth(); ii++ )
        {
            if ( NULL != m_board[ii+jj*getWidth()] )
            {
                //std::cout << ii << " " << jj << ": "
                          //<< m_board[ii+jj*getWidth()]->isType( TE_TYPE_START )
                          //<< " "
                          //<< m_board[ii+jj*getWidth()]->isType( TE_TYPE_END )
                          //<< std::endl;
                
                if ( m_board[ii+jj*getWidth()]->isType( TE_TYPE_START ) )
                {
                    if ( startFound )
                    {
                        valid = false;
                    }
                    else
                    {
                        startFound = true;
                    }
                }

                if ( m_board[ii+jj*getWidth()]->isType( TE_TYPE_END ) )
                {
                    if ( endFound )
                    {
                        valid = false;
                    }
                    else
                    {
                        endFound = true;
                    }
                }
            }
        }
    }

    if ( !startFound || !endFound )
    {
        valid = false;
    }

    if ( !valid )
    {
        std::cout << "GameBoard::isValid() "
                  << "Error: Game board is not valid."
                  << " Start: " << startFound
                  << " End: " << endFound
                  << std::endl;
    }

    return valid;
}

// return (first) start position
const Position GameBoard::getStartPos() const
{
    Position pos;

    for ( unsigned int jj = 0; jj < getHeight(); jj++ )
    {
        for ( unsigned int ii = 0; ii < getWidth(); ii++ )
        {
            if ( NULL != m_board[ii+jj*getWidth()] )
            {
                if ( m_board[ii+jj*getWidth()]->isType( TE_TYPE_START ) )
                {
                    pos.set(ii,jj);
                    return pos;
                }
            }
        }
    }

    return pos;
}

// return (first) end position
const Position GameBoard::getEndPos() const
{
    Position pos;

    for ( unsigned int jj = 0; jj < getHeight(); jj++ )
    {
        for ( unsigned int ii = 0; ii < getWidth(); ii++ )
        {
            if ( NULL != m_board[ii+jj*getWidth()] )
            {
                if ( m_board[ii+jj*getWidth()]->isType( TE_TYPE_END ) )
                {
                    pos.set(ii,jj);
                    return pos;
                }
            }
        }
    }

    return pos;
}

// return (first) start view direction of bot
const BaseEnumDirection GameBoard::getStartViewDirection() const
{
    BaseEnumDirection view = BE_DIRECTION_NONE;

    for ( unsigned int jj = 0; jj < getHeight(); jj++ )
    {
        for ( unsigned int ii = 0; ii < getWidth(); ii++ )
        {
            if ( NULL != m_board[ii+jj*getWidth()] )
            {
                if ( m_board[ii+jj*getWidth()]->isType( TE_TYPE_START ) )
                {
                    const TileEnumDirection temp = m_board[ii+jj*getWidth()]->getStartDirection();
                    view = TileFunctions::convertTileToBaseDirection( temp );
                    return view;
                }
            }
        }
    }

    return view;
}

// return position of tile depending on board dimensions
const TileMaskPosition GameBoard::isBorderTile( const Position& pos ) const
{
    TileMaskPosition posMask = TM_POSITION_NONE;

    if ( pos.x() == 0 )
    {
        posMask = (TileMaskPosition)(posMask | TM_POSITION_LEFT);
    }
    else if ( pos.x() == getWidth()-1 )
    {
        posMask = (TileMaskPosition)(posMask | TM_POSITION_RIGHT);
    }
    
    if ( pos.y() == 0 )
    {
        posMask = (TileMaskPosition)(posMask | TM_POSITION_UP);
    }
    else if ( pos.y() == getHeight()-1 )
    {
        posMask = (TileMaskPosition)(posMask | TM_POSITION_DOWN);
    }
    
    return posMask;
}
