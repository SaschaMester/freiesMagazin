// *************************************************************************
// robots-engine / libtiles - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// License: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>

#include "endtile.hh"

// return sequence with commands for the robot
// when entering this tile after movement
void EndTile::getSequence( Sequence& list, const TileEnumPhase phase ) const
{
    // robot has finished
    list.push_back( "Z" );
}
    
// Save tile to stream
const bool EndTile::saveInternal( std::ofstream& outFile ) const
{
    outFile << "END" << std::endl;
    return true;
}

// Save tile to stream
const bool EndTile::saveAsciiInternal( std::ofstream& outFile ) const
{
    outFile << "Z";
    return true;
}

// Save tile to stream
const bool EndTile::saveExtendedAsciiInternal( std::ofstream& outFile,
                                                const int line ) const
{
    bool ok = true;
    
    switch ( line )
    {
        case 0:
        case 2:
            outFile << " X X ";
            break;
        case 1:
            outFile << "  X  ";
            break;
        default:                    
            ok = false;
            break;
    }

    return ok;
}
