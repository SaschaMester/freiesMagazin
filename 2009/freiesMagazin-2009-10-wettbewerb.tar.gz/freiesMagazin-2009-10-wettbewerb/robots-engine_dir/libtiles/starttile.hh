// *************************************************************************
// robots-engine / libtiles - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// License: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef STARTTILE_HH
#define STARTTILE_HH

#include "basetile.hh"

class StartTile : public BaseTile
{
public:
    StartTile( const TileEnumDirection view )
    : m_view(view)
    {
    }

    // copy tile and return pointer to it
    virtual StartTile* clone() const
    {
        return new StartTile(*this);
    }

    // return true if this is a special tile
    virtual const bool isType( const TileEnumType type ) const
    {
        return ( TE_TYPE_START == type );
    }
    
    // return start direction of bot
    virtual const TileEnumDirection getStartDirection() const
    {
        return m_view;
    }
    
private:

    // Save tile to stream
    virtual const bool saveInternal( std::ofstream& outFile ) const;

    // Save tile to stream
    virtual const bool saveAsciiInternal( std::ofstream& outFile ) const;

    // Save tile to stream
    virtual const bool saveExtendedAsciiInternal( std::ofstream& outFile,
                                                  const int line ) const;

    // start view direction of bot
    TileEnumDirection m_view;

};

#endif // STARTTILE_HH
