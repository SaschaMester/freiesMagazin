// *************************************************************************
// robots-engine / libtiles - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// License: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>

#include "rotationtile.hh"
#include "tilefunctions.hh"

// return sequence with commands for the robot
// when standing on this tile
void RotationTile::getSequence( Sequence& list, const TileEnumPhase phase ) const
{
    if ( TE_PHASE_ROTATE == phase )
    {
        // rotate the robot
        list.push_back( TileFunctions::convertToSequenceString( m_rotDirection ) );
    }
}

// Save tile to stream
const bool RotationTile::saveInternal( std::ofstream& outFile ) const
{
    outFile << "ROTWHEEL  "
            << TileFunctions::convertToAsciiString ( m_rotDirection )
            << std::endl;
    return true;
}

// Save tile to stream
const bool RotationTile::saveAsciiInternal( std::ofstream& outFile ) const
{
    bool ok = true;
    
    switch ( m_rotDirection )
    {
        case TE_ROTATION_LEFT:
            outFile << "L";
            break;
        case TE_ROTATION_RIGHT:
            outFile << "R";
            break;
        default:
            ok = false;
            break;
    }
    
    return ok;
}

// Save tile to stream
const bool RotationTile::saveExtendedAsciiInternal( std::ofstream& outFile,
                                                    const int line ) const

{
    bool ok = true;
    
    switch ( m_rotDirection )
    {
        case TE_ROTATION_LEFT:
            switch ( line )
            {
                case 0:
                    outFile << "v<<<^";
                    break;
                case 1:
                    outFile << "v o ^";
                    break;
                case 2:
                    outFile << "v>>>^";
                    break;
                default:                    
                    ok = false;
                    break;
            }
            break;
        case TE_ROTATION_RIGHT:
            switch ( line )
            {
                case 0:
                    outFile << "^>>>v";
                    break;
                case 1:
                    outFile << "^ o v";
                    break;
                case 2:
                    outFile << "^<<<v";
                    break;
                default:                    
                    ok = false;
                    break;
            }
            break;
        default:
            ok = false;
            break;
    }
    
    return ok;
}

