// *************************************************************************
// robots-engine / libtiles - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// License: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef TILEENUMS_HH
#define TILEENUMS_HH

#include "baseenums.hh"

// enum for four moving directions
enum TileEnumDirection
{
    TE_DIRECTION_NONE      = BE_DIRECTION_NONE,
    TE_DIRECTION_LEFT      = BE_DIRECTION_LEFT,
    TE_DIRECTION_RIGHT     = BE_DIRECTION_RIGHT,
    TE_DIRECTION_UP        = BE_DIRECTION_UP,
    TE_DIRECTION_DOWN      = BE_DIRECTION_DOWN
};

// enum for two rotating directions
enum TileEnumRotation
{
    TE_ROTATION_NONE   = BE_ROTATION_NONE,
    TE_ROTATION_LEFT   = BE_ROTATION_LEFT,
    TE_ROTATION_RIGHT  = BE_ROTATION_RIGHT
};

// mask for different wall types
// (wall on each side of tile)
enum TileMaskWall
{
    TM_WALL_NONE          = TE_DIRECTION_NONE,
    TM_WALL_LEFT          = TE_DIRECTION_LEFT,
    TM_WALL_RIGHT         = TE_DIRECTION_RIGHT,
    TM_WALL_UP            = TE_DIRECTION_UP,
    TM_WALL_DOWN          = TE_DIRECTION_DOWN,
    TM_WALL_LEFTRIGHT     = TM_WALL_LEFT |
                            TM_WALL_RIGHT,
    TM_WALL_LEFTUP        = TM_WALL_LEFT |
                            TM_WALL_UP,
    TM_WALL_LEFTDOWN      = TM_WALL_LEFT |
                            TM_WALL_DOWN,
    TM_WALL_RIGHTUP       = TM_WALL_RIGHT |
                            TM_WALL_UP,
    TM_WALL_RIGHTDOWN     = TM_WALL_RIGHT |
                            TM_WALL_DOWN,
    TM_WALL_UPDOWN        = TM_WALL_UP |
                            TM_WALL_DOWN,
    TM_WALL_LEFTRIGHTUP   = TM_WALL_LEFT |
                            TM_WALL_RIGHT |
                            TM_WALL_UP,
    TM_WALL_LEFTRIGHTDOWN = TM_WALL_LEFT |
                            TM_WALL_RIGHT |
                            TM_WALL_DOWN,
    TM_WALL_LEFTUPDOWN    = TM_WALL_LEFT |
                            TM_WALL_UP |
                            TM_WALL_DOWN,
    TM_WALL_RIGHTUPDOWN   = TM_WALL_RIGHT |
                            TM_WALL_UP |
                            TM_WALL_DOWN,
    TM_WALL_ALL           = TM_WALL_LEFT |
                              TM_WALL_RIGHT |
                              TM_WALL_UP |
                              TM_WALL_DOWN
};

// mask for different directions of moving
enum TileMaskMove
{
    TM_MOVE_NONE      = TE_DIRECTION_NONE,
    TM_MOVE_LEFT      = TE_DIRECTION_LEFT,
    TM_MOVE_RIGHT     = TE_DIRECTION_RIGHT,
    TM_MOVE_UP        = TE_DIRECTION_UP,
    TM_MOVE_DOWN      = TE_DIRECTION_DOWN
};

// mask for different directions of pushing
enum TileMaskPush
{
    TM_PUSH_NONE      = TE_DIRECTION_NONE,
    TM_PUSH_LEFT      = TE_DIRECTION_LEFT,
    TM_PUSH_RIGHT     = TE_DIRECTION_RIGHT,
    TM_PUSH_UP        = TE_DIRECTION_UP,
    TM_PUSH_DOWN      = TE_DIRECTION_DOWN
};

// mask for different directions of pushing
enum TileMaskSqueeze
{
    TM_SQUEEZE_LEFTRIGHT = TE_DIRECTION_LEFT |
                           TE_DIRECTION_RIGHT,
    TM_SQUEEZE_UPDOWN    = TE_DIRECTION_UP |
                           TE_DIRECTION_DOWN
};

// different phases
enum TileEnumPhase
{
    TE_PHASE_MOVE   = 0,
    TE_PHASE_PUSH,
    TE_PHASE_ROTATE
};

// mask for different positions of tiles on game board
enum TileMaskPosition
{
    TM_POSITION_NONE      = TE_DIRECTION_NONE,
    TM_POSITION_LEFT      = TE_DIRECTION_LEFT,
    TM_POSITION_RIGHT     = TE_DIRECTION_RIGHT,
    TM_POSITION_UP        = TE_DIRECTION_UP,
    TM_POSITION_DOWN      = TE_DIRECTION_DOWN,
    TM_POSITION_LEFTUP    = TE_DIRECTION_LEFT | TE_DIRECTION_UP,
    TM_POSITION_LEFTDOWN  = TE_DIRECTION_LEFT | TE_DIRECTION_DOWN,
    TM_POSITION_RIGHTUP   = TE_DIRECTION_RIGHT | TE_DIRECTION_UP,
    TM_POSITION_RIGHTDOWN = TE_DIRECTION_RIGHT | TE_DIRECTION_DOWN
};

// enum for tile types
enum TileEnumType
{
    TE_TYPE_FLOOR = 0,
    TE_TYPE_START,
    TE_TYPE_END,
    TE_TYPE_HOLE,
    TE_TYPE_OIL,
    TE_TYPE_WALL,
    TE_TYPE_CONVEYOR_BELT,
    TE_TYPE_ROTATION,
    TE_TYPE_PUSHER,
    TE_TYPE_SQUEEZER
};


#endif // TILEENUMS_HH
