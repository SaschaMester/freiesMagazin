// *************************************************************************
// robots-engine / libtiles - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// License: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef TILEFUNCTIONS_HH
#define TILEFUNCTIONS_HH

#include <string>

#include "baseenums.hh"
#include "tileenums.hh"
#include "sequence.hh"

class TileFunctions
{
public:

    // convert to sequence string
    static const SeqString convertToSequenceString( const BaseEnumRotation rot );
    static const SeqString convertToSequenceString( const BaseEnumDirection move );
    static const SeqString convertToSequenceString( const TileEnumRotation rot );
    static const SeqString convertToSequenceString( const TileEnumDirection move );
    static const SeqString convertToSequenceString( const TileMaskPush move );
    static const SeqString convertToSequenceString( const TileMaskMove move );

    // convert to ascii string
    static const std::string convertToAsciiString( const TileEnumRotation rot );
    static const std::string convertToAsciiString( const TileEnumDirection move );
    static const std::string convertToAsciiString( const TileMaskPush move );
    static const std::string convertToAsciiString( const TileMaskMove move );
    static const std::string convertToAsciiString( const TileMaskSqueeze move );

    // set wall as opposite of direction
    static const TileMaskWall convertToWall( const TileMaskPush dir );
    static const TileMaskWall convertToWall( const TileMaskSqueeze dir );
    static const TileMaskWall convertToWall( const BaseEnumDirection dir );

    // convert tile direction to base direction
    static const BaseEnumDirection convertTileToBaseDirection( const TileEnumDirection dir );
    
};

#endif // TILEFUNCTIONS_HH
