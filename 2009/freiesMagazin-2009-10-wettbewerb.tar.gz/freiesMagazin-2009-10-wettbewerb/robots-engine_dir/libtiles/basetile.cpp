// *************************************************************************
// robots-engine / libtiles - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// License: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>

#include "basetile.hh"
#include "starttile.hh"
#include "endtile.hh"
#include "holetile.hh"
#include "oiltile.hh"
#include "walltile.hh"
#include "pushtile.hh"
#include "squeezetile.hh"
#include "rotationtile.hh"
#include "movetile.hh"

// Save tile to stream
// with all informations.
// return true if everything is okay
const bool BaseTile::save( std::ofstream& outFile ) const
{
    bool ok = false;

    if ( outFile.good() )
    {
        ok = saveInternal( outFile );
    }

    return ok;
}

// Save tile to stream
// as ascii with one char
// return true if everything is okay
const bool BaseTile::saveAscii( std::ofstream& outFile ) const
{
    bool ok = false;

    if ( outFile.good() )
    {
        ok = saveAsciiInternal( outFile );
    }

    return ok;
}

// Save tile to stream
// as ascii with several chars.
// The line may be 0-2 and says in which line we are.
// return true if everything is okay
const bool BaseTile::saveExtendedAscii( std::ofstream& outFile,
                                        const int line ) const

{
    bool ok = false;

    if ( line >= 0 && line < 3 )
    {
        if ( outFile.good() )
        {
            ok = saveExtendedAsciiInternal( outFile, line );
        }
    }

    return ok;
}

// Save tile to stream
const bool BaseTile::saveInternal( std::ofstream& outFile ) const
{
    outFile << "FLOOR" << std::endl;
    return true;
}

// Save tile to stream
const bool BaseTile::saveAsciiInternal( std::ofstream& outFile ) const
{
    outFile << " ";
    return true;
}


// Save tile to stream
const bool BaseTile::saveExtendedAsciiInternal( std::ofstream& outFile,
                                                const int line ) const
{
    outFile << "     ";
    return true;
}

// return file type to a special character
BaseTile *BaseTile::getTileFromChar( const char c )
{
    BaseTile *tile = NULL;

    // create tile depending on character
    switch ( c )
    {
        case ' ':
            tile = (BaseTile*)( new BaseTile() );
            break;
        case 'S':
            tile = (BaseTile*)( new StartTile( TE_DIRECTION_LEFT ) );
            break;
        case 'T':
            tile = (BaseTile*)( new StartTile( TE_DIRECTION_RIGHT ) );
            break;
        case 'U':
            tile = (BaseTile*)( new StartTile( TE_DIRECTION_UP ) );
            break;
        case 'V':
            tile = (BaseTile*)( new StartTile( TE_DIRECTION_DOWN ) );
            break;
        case 'Z':
            tile = (BaseTile*)( new EndTile() );
            break;
        case 'H':
            tile = (BaseTile*)( new HoleTile() );
            break;
        case 'O':
            tile = (BaseTile*)( new OilTile() );
            break;
        case '<':
            tile = (BaseTile*)( new MoveTile( TM_MOVE_LEFT ) );
            break;
        case '>':
            tile = (BaseTile*)( new MoveTile( TM_MOVE_RIGHT ) );
            break;
        case '^':
            tile = (BaseTile*)( new MoveTile( TM_MOVE_UP ) );
            break;
        case 'v':
            tile = (BaseTile*)( new MoveTile( TM_MOVE_DOWN ) );
            break;
        case 'L':
            tile = (BaseTile*)( new RotationTile( TE_ROTATION_LEFT ) );
            break;
        case 'R':
            tile = (BaseTile*)( new RotationTile( TE_ROTATION_RIGHT ) );
            break;
        case 'C':
            tile = (BaseTile*)( new PushTile( TM_PUSH_LEFT ) );
            break;
        case 'D':
            tile = (BaseTile*)( new PushTile( TM_PUSH_RIGHT ) );
            break;
        case 'E':
            tile = (BaseTile*)( new PushTile( TM_PUSH_UP ) );
            break;
        case 'F':
            tile = (BaseTile*)( new PushTile( TM_PUSH_DOWN ) );
            break;
        case 'M':
            tile = (BaseTile*)( new SqueezeTile( TM_SQUEEZE_LEFTRIGHT ) );
            break;
        case 'N':
            tile = (BaseTile*)( new SqueezeTile( TM_SQUEEZE_UPDOWN ) );
            break;
        case 'a':
        case 'b':
        case 'c':
        case 'd':
        case 'e':
        case 'f':
        case 'g':
        case 'h':
        case 'i':
        case 'j':
        case 'k':
        case 'l':
        case 'm':
        case 'n':
        case 'o':
        case 'p':
            {
                // calculate bit mask from character
                TileMaskWall walls = (TileMaskWall)(c-'a');
                tile = (BaseTile*)( new WallTile( walls ) );
            }
            break;
        default:
            std::cerr << "BaseTile::getTileFromChar(char) "
                      << "Error: Character "
                      << (int)c
                      << " does not match any tile type."
                      << std::endl;
        break;
    }

    return tile;
}

// print data to stdout
void BaseTile::print() const
{
    std::cout // << "Id:    " << getId()           << "\n"
              << " Walls: " << getWalls()        << ""
              << " Move:  " << getMoveDir()      << ""
              << " Push:  " << getPushDir()      << ""
              << " Rot:   " << getRotDirection()
              << std::endl;
}
