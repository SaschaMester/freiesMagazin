// *************************************************************************
// robots-engine / libtiles - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// License: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef PUSHTILE_HH
#define PUSHTILE_HH

#include "basetile.hh"

class PushTile : public BaseTile
{
public:
    // Constructor
    // create pusher/squeezer tile with directions to push to
    // if the type does not match this class
    // the default type is used
    PushTile( const TileMaskPush direction )
    : m_pushDirection( direction )
    {
        m_walls = TileFunctions::convertToWall ( m_pushDirection );
    }

    // return sides on which this tile has walls
    virtual const TileMaskWall getWalls() const
    {
        return m_walls;
    }
    
    // return direction in which the robot will be pushed
    virtual const TileMaskPush getPushDir() const
    {
        return m_pushDirection;
    }

    // return true if this is a special tile
    virtual const bool isType( const TileEnumType type ) const
    {
        return ( TE_TYPE_PUSHER == type );
    }

    // copy tile and return pointer to it
    virtual PushTile* clone() const
    {
        return new PushTile(*this);
    }

    // return sequence with commands for the robot
    // when standing on this tile
    virtual void getSequence( Sequence& list, const TileEnumPhase phase ) const;

    // return true if this tile can be left in direction of movement
    virtual const bool canLeave( const BaseEnumDirection move ) const;

    // return true if this tile can be entered from direction of movement
    virtual const bool canEnter( const BaseEnumDirection move ) const;
        
private:

    // Save tile to stream
    virtual const bool saveInternal( std::ofstream& outFile ) const;

    // Save tile to stream
    virtual const bool saveAsciiInternal( std::ofstream& outFile ) const;

    // Save tile to stream
    virtual const bool saveExtendedAsciiInternal( std::ofstream& outFile,
                                                  const int line ) const;

protected:
    // flags in which direction/s a pusher pushes
    TileMaskPush m_pushDirection;
    
    // flags which walls are shown
    TileMaskWall m_walls; 

};

#endif // PUSHTILE_HH
