// *************************************************************************
// robots-engine / libtiles - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// License: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>

#include "holetile.hh"
#include "basefunctions.hh"

// return sequence with commands for the robot
// when entering this tile after movement
void HoleTile::getSequenceOnEntry( Sequence& list,
                                   const BaseEnumDirection move ) const
{
    if ( BE_GAME_LEVEL_EASY != BaseFunctions::getGameLevel() )
    {
        // robot is dead
        list.push_back( "X" );
    }
}
    
// Save tile to stream
const bool HoleTile::saveInternal( std::ofstream& outFile ) const
{
    bool ok = false;
    
    if ( BE_GAME_LEVEL_EASY != BaseFunctions::getGameLevel() )
    {
        outFile << "HOLE" << std::endl;
        ok = true;
    }
    else
    {
        ok = BaseTile::saveInternal( outFile );
    }
    
    return ok;
}

// Save tile to stream
const bool HoleTile::saveAsciiInternal( std::ofstream& outFile ) const
{
    bool ok = false;
    
    if ( BE_GAME_LEVEL_EASY != BaseFunctions::getGameLevel() )
    {
        outFile << "H";
        ok = true;
    }
    else
    {
        ok = BaseTile::saveAsciiInternal( outFile );
    }
    
    return ok;
}

// Save tile to stream
const bool HoleTile::saveExtendedAsciiInternal( std::ofstream& outFile,
                                                const int line ) const
{
    bool ok = false;
    
    if ( BE_GAME_LEVEL_EASY != BaseFunctions::getGameLevel() )
    {
        outFile << "#####";
        ok = true;
    }
    else
    {
        ok = BaseTile::saveExtendedAsciiInternal( outFile, line );
    }
    
    return ok;
}
