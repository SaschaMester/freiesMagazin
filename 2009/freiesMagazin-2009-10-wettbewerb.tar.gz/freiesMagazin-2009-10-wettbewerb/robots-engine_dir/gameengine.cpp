// *************************************************************************
// robots-engine - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <cstdlib>

#include "gameengine.hh"
#include "botfunctions.hh"
#include "basefunctions.hh"

const std::string choosendeckname("ccards.txt");
const std::string sequencename("sequence.txt");
const std::string kiname("./bot-ki");
const std::string statsname("stats.txt");
const std::string deckname("cards.txt");

// Constructor.
// Load board, card deck and bot from disk.
GameEngine::GameEngine()
: Game()
{
    // open statistics
    m_stats.setFile( statsname, false );  
}

// Constructor.
// Load board from disk.
GameEngine::GameEngine( const std::string& boardname )
: Game( boardname )
{
    // open statistics
    m_stats.setFile( statsname, false );  
}

// Constructor.
// Load board and card deck from disk.
GameEngine::GameEngine( const std::string& boardname, const std::string& deckname )
: Game( boardname, deckname )
{
    // open statistics
    m_stats.setFile( statsname, false );  
}

// Destructor.
GameEngine::~GameEngine()
{
    // save statistics if valid
    if ( m_stats.isValid() )
    {
        m_stats.save();
        // m_stats.print();
    }
    
    if ( !m_stats.isValid() )
    {
        std::cerr << "GameEngine() "
                  << "Error: Statistics could not be saved."
                  << std::endl;
    }
    
}

// start game (one KI step)
const bool GameEngine::start()
{
    bool ok = false;

    if ( isValid() )
    {
        // all files has been loaded correctly

        // "delete" old sequence.txt
        Sequence tempSeq;
        tempSeq.save( sequencename );

        // We must remove the statistics so that the KI cannot access it.
        m_stats.removeFile();

        // check if bot position is end position
        // so we should not move the bot
        if ( !botHasReachedEndPosition() )
        {
            // now get 8 cards from the deck
            CardDeck newCards;
            if ( m_deck.getCards( newCards, 8 ) )
            {
                // call KI
                // load choosen cards and check if valid
                CardDeck choosenCards;

                if ( callKI( choosenCards, newCards ) )
                {
                    // generate sequence for GUI from cards
                    if ( generateAndStoreSequence( choosenCards ) )
                    {
                        ok = true;
                    }
                }

                // save final data again on disk
                if ( !saveAll() )
                {
                    ok = false;
                }
            }
            else
            {
                // there are no more cards
                // store this in the sequence
                tempSeq.push_back( "Y" );
                tempSeq.save( sequencename );

                std::cout << "Sequence: ";
                tempSeq.print(false);
                std::cout << std::endl;

                m_stats.increase( Stats::SE_NUM_CARDS_OUT );

                ok = true;
            }
        }
        else
        {
            ok = true;
        }
    }
    else
    {
        std::cerr << "GameEngine::start() "
                  << "Error: Game is not valid!"
                  << std::endl;
    }

    // std::cout << "start ok: " << ok << std::endl;

    return ok;
}

// call KI and check if the choosen cards are valid
const bool GameEngine::callKI( CardDeck& choosenCards, const CardDeck& newCards ) const
{
    bool ok = false;

    // overwrite deck
    if ( newCards.save( deckname ) )
    {
        const std::string kicall = kiname + " " + BaseFunctions::convertGameLevelToString();

        if ( !system ( kicall.c_str() ) )
        {
            // load choosen cards from disk
            if ( choosenCards.load( choosendeckname ) )
            {
                if ( 5 == choosenCards.size() )
                {
                    // check if choosen cards are subset of all cards
                    if ( newCards.hasSubset( choosenCards ) )
                    {
                        std::cout << "Bot: ";
                        m_bot.print();
                        std::cout << " ";

                        std::cout << "Deck: ";

                        for ( unsigned int kk = 0; kk < newCards.size(); kk++ )
                        {
                            std::cout << newCards[kk]->print() << " ";
                        }

                        std::cout << "Choosen: ";

                        for ( unsigned int kk = 0; kk < choosenCards.size(); kk++ )
                        {
                            std::cout << choosenCards[kk]->print() << " ";
                        }

                        std::cout << std::endl;

                        ok = true;
                    }
                    else
                    {
                        std::cerr << "GameEngine::callKI(cards,cards) "
                                  << "Error: Choosen cards are not a subset "
                                  << "of given cards."
                                  << std::endl;
                    }
                }
                else
                {
                    std::cerr << "GameEngine::callKI(cards,cards) "
                              << "Error: Number of choosen cards "
                              << choosenCards.size()
                              << " does not equal 5."
                              << std::endl;
                }
            }
        }
        else
        {
            std::cerr << "GameEngine::callKI(cards,cards) "
                      << "Error: Calling "
                      << kiname.c_str()
                      << " failed."
                      << std::endl;
        }
    }

    return ok;
}

// generate sequence for GUI from cards
// and save it to disk
const bool GameEngine::generateAndStoreSequence( const CardDeck& choosenCards )
{
    bool ok = true;

    // global sequence with complete movement of all five cards
    Sequence globalSeq;

    // add new round
    m_stats.increase( Stats::SE_NUM_ROUNDS);

    for ( unsigned int ii = 0; ii < choosenCards.size(); ii++ )
    {
        if ( NULL != choosenCards[ii] )
        {
            // add new card
            m_stats.increase( Stats::SE_NUM_PLAYED_CARDS );
            
            // get movement for this card
            Sequence startSeq;
            choosenCards[ii]->getSequence( startSeq );

            //std::cout << "start seq: ";
            //startSeq.print(false);
            //std::cout << std::endl;

            // now we must transform this movement to the game board
            // and the robot
            Sequence endSeq;
            generateSequenceAndMoveRobot( endSeq, startSeq, m_bot, m_stats, false );

            //std::cout << "end seq:   ";
            //endSeq.print(false);
            //std::cout << std::endl;

            globalSeq.append( endSeq );

            // add separator for each card
            // if the game is not finished yet
            if ( endSeq.size() > 0 )
            {
                if ( !isEndMove( endSeq.back() ) )
                {
                    if ( ii < choosenCards.size()-1 )
                    {
                        globalSeq.append("----");
                    }
                }
                else
                {
                    if ( "Z" == endSeq.back() )
                    {
                        m_stats.increase( Stats::SE_NUM_FINISH_REACHED );
                    }
                    else if ( "Y" == endSeq.back() )
                    {
                        // we should never land here
                        m_stats.increase( Stats::SE_NUM_CARDS_OUT );
                    }
                    else if ( "X" == endSeq.back() )
                    {
                        m_stats.increase( Stats::SE_NUM_BOT_DESTROYED );
                    }

                    // game is finished => stop here
                    break;
                }
            }
            else
            {
                // even if there is no element, we must write a separator line
                if ( ii < choosenCards.size()-1 )
                {
                    globalSeq.append("----");
                }
            }
        }
        else
        {
            ok = false;
        }
    }

    // save sequence to disk
    globalSeq.save( sequencename );

    std::cout << "Sequence: ";
    globalSeq.print(false);
    std::cout << std::endl;

    // std::cout << "ok: " << ok << std::endl;

    return ok;
}

