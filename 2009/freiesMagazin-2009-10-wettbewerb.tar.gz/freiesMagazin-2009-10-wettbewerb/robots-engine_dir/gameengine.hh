// *************************************************************************
// robots-engine - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef GAMEENGINE_HH
#define GAMEENGINE_HH

#include "game.hh"
#include "stats.hh"

class GameEngine : public Game
{

public:
    // Constructor.
    // Load board, card deck and bot from disk.
    GameEngine();

    // Constructor.
    // Load board from disk.
    GameEngine( const std::string& boardname );

    // Constructor.
    // Load board and card deck from disk.
    GameEngine( const std::string& boardname, const std::string& deckname );

    // Destructor.
    ~GameEngine();

    // start game (one KI step)
    const bool start();

protected:
    // call KI and check if the choosen cards are valid
    const bool callKI( CardDeck& choosenCards, const CardDeck& newCards ) const;

    // generate sequence for GUI from cards
    // and save it to disk
    const bool generateAndStoreSequence( const CardDeck& choosenCards );

    // Statistic that will be loaded at the start of each game
    Stats m_stats;
};

#endif // GAMEENGINE_HH
