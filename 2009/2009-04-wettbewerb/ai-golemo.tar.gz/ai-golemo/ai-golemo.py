#! /usr/bin/env python
# -*- coding: utf-8 -*-

#    Copyright 2009 by Florian Golemo <fgolemo@g-services.net>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Lesser General Public License for more details.
#    You should have received a copy of the GNU Lesser General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys,re
class Player:
  ownStats = ""
  enemyStats = ""
  field = [[0,0,0,0,0,0,0,0,0,0]]*10
  fieldLine = 9
  line = [0,0,0,0,0,0,0,0,0,0]
  attack = []
  defense = []
  collect = []
  rerun = []
  possibs = []
  
  def writeOutput(self, output):
	f = open ("./result.dat", "w")
	f.write(output)
	f.close

  def readOwnStats(self):
	f = open ("./player.dat", "r")
	#global ownStats
	self.ownStats= f.read()
	self.ownStats = self.ownStats.split("\n")
	f.close

  def readEnemyStats(self):
	f = open ("./opponent.dat", "r")
	#global ownStats
	self.enemyStats= f.read()
	self.enemyStats = self.enemyStats.split("\n")
	f.close

  def parseLine(self, line):
	#pass
	#print line + "-Miff"
	for i in range(20):
	  if (line[i] != " "):
		#print line[i] + "miff"
		#print self.fieldLine
		cell = -1
		if line[i] == "B":
		  cell = 0
		elif line[i] == "L":
		  cell = 1
		elif line[i] == "G":
		  cell = 2
		elif line[i] == "Y":
		  cell = 3
		elif line[i] == "R":
		  cell = 4
		else:
		  cell = int(line[i]) + 4
		self.line[i/2] = cell

  def readField(self):
	f = open ("./gamefield.dat", "r")
	field = f.read()
	#print field
	field = field.split("\n")
	#print field
	self.fieldLine = 0
	for line in field:
	  if (line != ""):
		#print "LINE:  " + line
		self.line = self.line[:]
		self.parseLine(line)
		self.field[self.fieldLine] = self.line
		self.fieldLine += 1

  def searchGroups(self, method):
	#pass
	#print method
	for row in range(10):
	  line = ""
	  for col in range(10):
		line += str(self.field[row][col])
	  #print line
	  self.searchLine(method, line)
	for col in range(10):
	  line = ""
	  for row in range(10):
		line += str(self.field[row][col])
	  #print line
	  self.searchLine(method, line)
	  
  def searchLine(self, method, line):
	search = re.findall(r'0{3,5}', line)
	if len(search) > 0:
	  #print str(search) + ", method: " + method
	  self.possibs.append( [len(search[0]) * 1,"defense",method] )
	search = re.findall(r'1{3,5}', line)
	if len(search) > 0:
	  #print str(search) + ", method: " + method
	  self.possibs.append( [len(search[0]) * 2,"collect",method] )
	search = re.findall(r'2{3,5}', line)
	if len(search) > 0:
	  #print str(search) + ", method: " + method
	  self.possibs.append( [len(search[0]) * 3,"collect",method] )
	search = re.findall(r'3{3,5}', line)
	if len(search) > 0:
	  #print str(search) + ", method: " + method
	  self.possibs.append( [len(search[0]) * 4,"collect",method] )
	search = re.findall(r'4{3,5}', line)
	if len(search) > 0:
	  #print str(search) + ", method: " + method
	  self.possibs.append( [len(search[0]) * 5,"collect",method] )
	search = re.findall(r'[56789]{3,5}', line)
	if len(search) > 0:
	  #print str(search) + ", method: " + method
	  self.possibs.append( [len(search[0]) * 6,"attack",method] )

  def readPossibilities(self):
	#pass
	for row in range(9):
	  for col in range (10):
		self.field[row][col], self.field[row + 1][col] = self.field[row + 1][col], self.field[row][col]
		self.searchGroups(str(col) + " " + str(int(9-row)) + " " + str(col) + " " +  str(int(8-row)))
		self.field[row][col], self.field[row + 1][col] = self.field[row + 1][col], self.field[row][col]
	for col in range(9):
	  for row in range (10):
		self.field[row][col], self.field[row][col + 1] = self.field[row][col + 1], self.field[row][col]
		self.searchGroups(str(col) + " " + str(int(9-row)) + " " + str(int(col+1)) + " " +  str(int(9-row)))
		self.field[row][col], self.field[row][col + 1] = self.field[row][col + 1], self.field[row][col]
		
p = Player()
#p.ownStats = "Miff"
#print p.ownStats
p.readOwnStats()
p.readEnemyStats()
p.readField()
p.readPossibilities()
#print "own: " + p.ownStats[0]
#print "enemy: " + p.enemyStats[1]
#print p.possibs
p.possibs.sort()
p.possibs.reverse()
#print p.possibs
#print p.field
#p.field[0][0], p.field[0][1] = p.field[0][1], p.field[0][0]
#print p.field
p.writeOutput(p.possibs[0][2])
#print ("0")

sys.exit()