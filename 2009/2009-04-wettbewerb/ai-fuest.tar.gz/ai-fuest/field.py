#! /bin/env python
# -*- coding: UTF-8 -*-
#
# field.py
#       
# Copyright 2009 Mario "Keba" Fuest <keba@yalmagazine.org>
#       
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#       
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#       
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301, USA.

import sys
import copy
import time ## just for testing/optimating

class Field(object):
    tiles = {"G":"green",
             "Y":"yellow",
             "R":"red",
             "L":"lilac",
             "B":"blue",
             "1":"bomb",
             "2":"bomb",
             "3":"bomb",
             "4":"bomb",
             "5":"bomb",
             "?":"unknown",
             " ":"empty"
    }
    
    colors = ["red", "green", "yellow", "blue", "lilac"]
    tilekinds = colors + ["bomb"]
    unknown = False    
    
    def __init__(self, field):
        ## create useable self.field, x5 y2 is now self.field[2][5]
        self.field = []
        for i in range(10):
            self.field.append([x for x in list(field[i]) if " " != x != "\n"])
            
        self.field.reverse()
                
        ## change rows and cols
        self.field = [[row[col] for row in self.field] for col in range(10)]

    def actualiseField(self, x1, y1, x2, y2):
        """swap x1|y1 with x2|y2"""
        
        self.field[x1][y1], self.field[x2][y2] = \
        self.field[x2][y2], self.field[x1][y1]
            
    def ask(self, x, y):
        """return the tile of the pos x|y, see self.tiles"""

        return self.tiles[self.field[x][y]]
            
    def checkbombvalues(self, move, changedfield, positions):
        """returns the value of all bombs in positions
        positions does not have to be a row or a col
        """
        
        if not changedfield:
            self.actualiseField(*move)

        value = 0
        for pos in positions:
            if self.ask(pos[0], pos[1]) == "bomb":
                value += int(self.field[pos[0]][pos[1]])
                
        if not changedfield:
            self.actualiseField(*move)
            
        return value
        
    def checkneighbours(self, conditions, x, y, old_x=None, old_y=None):
        """if the "neighbours" of a positions have the same tile, 
        return a list containg a set of the tiles 
        and a set of the positions
        else return False
    
        if old_x and old_y are given, the pos-set will contain these
        instead of x|y (usefull after running self.actuliseField())
        
        do NOT check the length and unknown tiles ("?")
        """
        
        def addpos(pos):
            map(pos.add, [condition[1], condition[2]])
            if old_x:
                pos.add((old_x, old_y))
            else:
                pos.add((x, y)) 
        
            return pos
            
        if 0 <= x < 10 and 0 <= y < 10:
            middle = self.ask(x, y)
            
            pos = set([])
                
            for condition in conditions:
                #if middle == "unknown" and not self.unknown:
                 #   if condition[0] and self.ask(*condition[1]) \
                 #                    == self.ask(*condition[2]):
                 #       pos = addpos(pos)
                 #       self.unknown = True
                        
                if middle != "unknown":
                    if condition[0] and middle == self.ask(*condition[1]) \
                                               == self.ask(*condition[2]):
                                                  
                        pos = addpos(pos)
            
            if pos:
                #if middle == "unknown":
                #    return [set([middle]), pos, "checked"]
                return [set([middle]), pos,]
                
            else: return False
                    
        else:
            return False

    def check(self, move):
        """apply the move simply, (just swap x1|y1 with x2|y2), and
        run self.checkneighbours()
        
        return what self.checkneigbours() has returned
        """
        
        x1, y1, x2, y2 = move[0], move[1], move[2], move[3]
        
        conditions = (
            ((0 < x2 < 9), (x2 - 1, y2), (x2 + 1, y2)),
            ((x2 > 1), (x2 - 1, y2), (x2 - 2, y2)),
            ((x2 < 8), (x2 + 1, y2), (x2 + 2, y2)),
                   
            ((0 < y2 < 9), (x2, y2 - 1), (x2, y2 + 1)),
            ((y2 > 1), (x2, y2 - 1), (x2, y2 - 2)),
            ((y2 < 8), (x2, y2 + 1), (x2, y2 + 2))
            )
        
        if 0 <= x1 < 10 and 0 <= y1 < 10 and 0 <= x2 < 10 and 0 <= y2 < 10:
            self.actualiseField(*move)
            
            change = self.checkneighbours(conditions, x2, y2, x1, y1)
            
            ## it was just hypothetical
            self.actualiseField(*move)
            
            return change
        else:
            return False

    def checkcountermove(self):
        """ if the countermove x2|y2 - x1|y1 is a move, too,
        concate tiles and positions of both moves 
        and remove the countermove
        """
        
        remove = []

        for move1 in self.moves:
            move2 = (move1[2], move1[3], move1[0], move1[1])
                                                  
            if move2 in self.moves:
                self.moves[move1]["tiles"] |= self.moves[move2]["tiles"]
                self.moves[move1]["pos"] |= self.moves[move2]["pos"]
                
                for tile in self.tilekinds:
                    self.moves[move1][tile] += self.moves[move2][tile]
                
                if move1 not in remove:
                    remove.append(move2)
                
        ## unfortunately cannot delete directly because of an error
        for move in remove:
            del self.moves[move]
            
    def checkvalue(self, move, positions, changedfield):
        """set the value of a move:
        bombvalues + len of tile`s fields
        """
        
        for pos in positions:
            if "bomb" in pos[0]:
                self.moves[move]["bomb"] += self.checkbombvalues(move, \
                                           changedfield, pos[1])
            
            for tile in self.colors:
                if tile in pos[0]:
                    self.moves[move][tile] += len(pos[1])
                    
    def checkfalldown(self,positions):
        """apply the move and change self.field
        let other tiles "fall down" and set unknown tiles with "?"
        """
        
        #self.actualiseField(*move)
        
        #print "BEFORE"
        #for i in self.field: print i
        
        for pos in positions:
            self.field[pos[0]][pos[1]] = " "
       
        for x, col in enumerate(self.field):
            emptys = 0
            for y in range(10):
                if col[y] == " ":
                    empty = True
                else:
                    empty = False
                    
                if emptys:
                    self.field[x][y - emptys] = self.field[x][y]
                    self.field[x][y] = " "
                    
                if empty:
                    emptys += 1
                            
            for y in range(10):
                if col[y] == " ":
                    self.field[x][y] = "?"
                    
        #print "NOW"
        #for i in self.field: print i
        #print
    
    def checkcascade(self):
        """check whether there are other rows/cols (cascade...)
        just usefull after changing self.field
        """
    
        #for i in self.field: print i
              
        positions = []

        for x in range(0, 10):
            for y in range(0, 10):
                
                ## we just need to check, whether there is the same tile
                ## left and right, otherwise we would get duplicates
                conditions = (
                    ((0 < x < 9), (x - 1, y), (x + 1, y)),
                    ((0 < y < 9), (x, y - 1), (x, y + 1)),
                    )
                    
                new = (self.checkneighbours(conditions, x, y))
                if new:
                    #print "unkown?", new
                    if new not in positions: ## mabye delete this later
                        positions.append(new)
                        
        #print "POSITIONS", positions

        #for i in positions:
        #    if "unknown" in i[0]: print; print; print "WTF"; print
            
    
        ## check length        
        for i, pos1 in enumerate(positions):
            for j, pos2 in enumerate(positions):
                if i != j and pos1[0] == pos2[0] \
                and len(pos1[1] & pos2[1]) >= 2:
                    pos1[1] |= pos2[1]
                    del positions[j]
        
        #print "POSITIONS", positions
                                                      
        return positions
            
    def findmoves(self):
        """set self.moves
        self.moves = {move1:{...}, move2:{...}, a.s.o}
        """

        self.moves = {}

         
        for x in range(10):
            for y in range(10):
                moves = [(x, y, x + 1, y), (x, y, x - 1, y), \
                         (x, y, x, y + 1), (x, y, x, y - 1)]
                
                for move in moves:
                    checked = self.check(move)
                    if checked:
                        self.moves[move] = {}
                        self.moves[move]["tiles"] = checked[0]
                        self.moves[move]["pos"] = checked[1]
                        self.moves[move]["value"] = 0
                        
                        for tile in self.tilekinds:
                            self.moves[move][tile] = 0
                                                    
                        self.checkvalue(move, [(self.moves[move]["tiles"], \
                                        self.moves[move]["pos"])], False,)
        
        ## check countermove
        self.checkcountermove()    
        
        for move in self.moves:
            #print "move:", move, "-", self.moves[move]
            ## apply move and check whether other tiles "explode", too   
            self.unknown = False
            for _ in range(20):
                backup = copy.deepcopy(self.field)
                self.checkfalldown(self.moves[move]["pos"])
                news = self.checkcascade()
                self.checkvalue(move, news, True)
                
                ## to make it easier to apply a move
                self.moves[move]["field"] = self.field
                
                ## we dont want to apply the move really, do we?    
                self.field = backup
                
                #uprint "NEWS", news
                
                newtiles = set([])
                newpos = set([])
                
                if not news:
                    break
           
                for new in news:
                    self.moves[move]["tiles"] |= new[0]
                    self.moves[move]["pos"] |= new[1]
               
            ## now: value = length
            value = 0
            for tile in self.tilekinds:
                self.moves[move]["value"] += self.moves[move][tile]
        
        return self.moves
        
    def sorttypes(self, type):
        types = []
        for move in self.moves:
            if type in self.moves[move]["tiles"]:
                types.append(move)
                
        return types
        
    def __str__(self):
        """make the class (and self.moves) printable
        we dont need this really, its just for testing
        """
        
        string = ""
        for i, move in enumerate(self.moves):                            
            string += "\n"
            string += "        Move #%2i: %s \n" % (i, str(move))
            
            tiles = ""
            for tile in self.moves[move]["tiles"]:
                tiles += tile
                tiles += " "
            string += "    Tiles: %s \n" % tiles
                
            positions = ""
            for pos in self.moves[move]["pos"]:
                positions += str(pos)
                positions += " "
            string += "Positions: %s \n" % positions
            
            string += "   Values: "
            for tile in self.tilekinds:
                if self.moves[move][tile]:
                    string += "%i %ss  " % (self.moves[move][tile], tile)

            string += "-> %s\n" % self.moves[move]["value"]
            
        return string
        
## testing
if __name__ == '__main__':
    f = file("gamefield.dat", "r")
    fieeeld = f.readlines()
    f.close()
    
    field = Field(fieeeld)

    
    print field.checkfalldown(((3, 6), (3, 5)))
    
    for i in field.field: print i
    
    print "z 5|2 is",
    print field.ask(5, 2)
    
    print field.check((3, 7, 3, 6))
    print field.check((8, 5, 9, 5))
    print
    print
    
    starttime = time.time()
    for _ in range(1):
        field.findmoves()
    
    endtime = time.time()
    
    print field    
   
    print
    print "bombs:", field.sorttypes("bomb")
    print "lilacs", field.sorttypes("lilac")
    
    print
    print "Time: %fs" % (endtime - starttime) 
