#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
# ai.py
#       
# Copyright 2009 Mario "Keba" Fuest <keba@yalmagazine.org>
#       
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#       
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#       
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301, USA.

from player import Player
from field import Field
import random, sys

class AI(object):
            
    def __init__(self, field, player, opponent):
                    
        ## load field
        self.field = Field(field)

        ## load player
        self.player = player

        ## load opponent
        self.opponent = opponent
                
        ## load self.moves
        ## remember: if we change this dict,
        ## self.field.moves will not change, too
        self.moves = self.field.findmoves()

    
    def addpoints(self, move):
        fulls = []
        player = self.player
        
        for tile in [("red", player.red), ("yellow", player.yellow), \
                    ("green", player.green), ("lilac", player.lilac)]:
            
            move[tile[0]] += tile[1]
            
            if move[tile[0]] >= 15:
                move[tile[0]] = move[tile[0]] - 15
                fulls.append(tile[0])
                
        return fulls

    def checkdamage(self, fulls, move, player):
        damage = 0
                 
        damage += move["bomb"]
        
        for tile in fulls:
            if tile == "red":
                damage += 10
            elif tile == "yellow":
                damage += 6
                
            elif tile == "green":
                damage += 3
                  
        return damage
        
    def applydamage(self, damage, player):
        shielddamage = player.shield - damage
        if shielddamage >= 0:
            player.shield = shielddamage
        else:
            player.shield = 0
            player.life = player.life - ( 0 - shielddamage )
                
                      
    def getinfos(self):
        for m in self.moves:
            move = self.moves[m]
            
            fulls = self.addpoints(move)
            
            damage = self.checkdamage(fulls, move, self.player)
            
            move["fulls"] = fulls
            
            move["damage"] = damage
            move["player"] = self.player
            move["opponent"] = self.opponent
            
            self.applydamage(damage, self.opponent)
        
        return self.moves
## testing
if __name__ == '__main__':
    f = file("gamefield.dat", "r")
    field = f.readlines()
    f.close()
    
    player = Player("player.dat")
    
    opponent = Player("opponent.dat")
    
    ai = AI(field, player, opponent)
        
    ai.getinfos()

    print "moves:\n"
    
    for move in ai.moves: print move, "-", ai.moves[move]
