#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
# main.py
#       
# Copyright 2009 Mario "Keba" Fuest <keba@yalmagazine.org>
#       
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#       
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#      
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301, USA.

## imports
from player import Player
from field import Field
from ai import AI

import copy
import time

class Strategy(object):
    """hardcoded -> unnice code, no time left for a nice docstring"""
    
    def __init__(self,
                myturn = True,
    
                field = None,
                player = None,
                opponent = None,
                #second = False,
                
                opponent_shield = 100000,
                opponent_life = 1000000,
                
                player_reds = 800,
                player_yellows = 600,
                player_greens = 400,
                player_shield = 200, ## blues
                player_lilacs = 1,
                
                shield_safety = 1000,
                fear = 200):
        
        self.myturn = myturn
                
        if not field:
            f = file("gamefield.dat", "r")
            self.field = f.readlines()
            f.close()
        else:
            self.field = field
        
        if not player:
            self.player = Player("player.dat")
        else:
            self.player = player
        
        
        if not opponent:
            self.opponent = Player("opponent.dat")
        else:
            self.opponent = opponent
        
        #self.second = second       
        
        ## factors
        self.opponent_shield = opponent_shield
        self.opponent_life = opponent_life
        self.player_reds = player_reds
        self.player_yellows = player_yellows
        self.player_greens = player_greens
        self.player_shield = player_shield
        self.player_lilacs = player_lilacs                
        
        self.shield_safety = shield_safety
        self.fear = fear
    
    def checkfear(self, tile, factor):
        """hardcoded -> unnice code, no time left for a nice docstring"""
        if tile > 12:
            factor += self.fear * 1.5
        elif tile > 10:
            factor += self.fear
    
    def checkvalue(self, moves, myturn):
        """hardcoded -> unnice code, no time left for a nice docstring"""
        for m in moves:
            
            move = moves[m]
            
            if myturn:
                player = move["player"]    
                opponent = move["opponent"]
            
            else:
                player = move["opponent"]    
                opponent = move["player"]
            
            ## checkagain
            #self.again = False
            
            #if not self.second:
            #    for tile in move["fulls"]:
            #        if tile == "lilac":
            #            self.again = False
            
            if opponent.lp < 6:
                self.player_yellows = self.player_reds
            
            if opponent.lp < 3:
                self.player_greens = self.player_yellows
            
            if player.shield < 5:
                move["value"] - self.shield_safety 
            
            ## do not let opponent get 15 of a tile (tile != lilac)
            if self.fear:
                self.checkfear(opponent.red, self.player_reds)
                self.checkfear(opponent.yellow, self.player_yellows)
                self.checkfear(opponent.green, self.player_greens)
            
            ## caused damage
            move["value"] += ( 15 - opponent.shield ) * self.opponent_shield
            move["value"] += ( 30 - opponent.life ) * self.opponent_life
                
            move["value"] += player.red * self.player_reds
            move["value"] += player.yellow * self.player_yellows
            move["value"] += player.green * self.player_greens
            move["value"] += player.shield * self.player_shield
            move["value"] += player.lilac * self.player_lilacs
        
        return moves
    
    def sort(self):
        """hardcoded -> unnice code, no time left for a nice docstring"""
        self.ai = AI(self.field, self.player, self.opponent)
        moves = self.ai.getinfos()
        valuedmoves = self.checkvalue(moves, self.myturn)            
                    
              
        sortedmoves = [({"move":k, "value":v["value"], "field":v["field"], \
                        "player":v["player"], "opponent":v["opponent"]}) \
                        #"again":self.again}) \
                        for k, v in sorted(valuedmoves.iteritems(), \
                        key=lambda x: x[1]["value"], reverse=True)]
        
        return sortedmoves
        
class Main(object):
    """hardcoded -> unnice code, no time left for a nice docstring"""
    
    def __init__(self, resultfile="result.dat", otherfactor = 1.2):
        self.resultfile = resultfile
        self.otherfactor = otherfactor
        
    def findbestmove(self):
        """hardcoded -> unnice code, no time left for a nice docstring"""
    
        kk = Strategy()
        
        moves = kk.sort()

        ## just care for the best 5 moves
        moves = moves[:5]

        ## check whether its again players turn
        ## doing this is mabye just wasting of time...

        for move in moves:
            #if move["again"]:
            #    new = Strategy(move["field"], move["player"], \
            #                   move["opponent"], second=True)
            #    bestmove_again = new.sort()[0]
            #    move["value"] += bestmove_again["value"]
            
            
            other = Strategy(False, move["field"], move["opponent"], \
                            move["player"], fear=0)
            
        
            otherbest = other.sort()[0]
            move["value"] += -otherbest["value"] * self.otherfactor
                
        sortedmoves = sorted(moves, key=lambda x: x["value"], reverse=True)
              
        self.best = sortedmoves[0]["move"]
                
    def write(self):
        """ print bestmove on screen and write it to resultfile"""
                
        ## print on screen
        print "KK: swap (%i|%i) with (%i|%i)" % (self.best[0], \
                        self.best[1], self.best[2], self.best[3])
        
        ## create string for resultfile
        move = ""      
        for c in self.best: ## "best move"
            move += str(c)
        move = ' '.join(move)

        ##  write to resultfile
        try:
            result = file(self.resultfile, "w")
            result.write(move)
            result.close()
        except:
            print "KK: Error: Could not write results to %s - quit" \
                                                        % self.resultfile    
            sys.exit(1)
        
## program
main = Main()
main.findbestmove()
main.write()
