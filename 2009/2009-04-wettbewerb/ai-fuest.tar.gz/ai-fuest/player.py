 #!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
# player.py
#       
# Copyright 2009 Mario "Keba" Fuest <keba@yalmagazine.org>
#       
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#       
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#       
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301, USA.

class Player(object):
    def __init__(self, player_file):
        try:
            playerfile = file(player_file, "r")
            player = playerfile.readlines()
            playerfile.close()
        except:
            print "KK: Warning: Could not load file %s, take dafault values." %player_file
            player = [30, 15, 0, 0, 0, 0] ## default, mostly for testing
        
        self.life = int(player[0])
        self.shield = int(player[1])
        self.red = int(player[2])
        self.yellow = int(player[3])
        self.green = int(player[4])
        self.lilac = int(player[5])
        
        self.lp = self.life + self.shield
        self.alive = self.life > 0
        
    def __str__(self):
        """make the class printable
        yes: we dont need that really
        """
        
        string = "Life:   %s\n" %self.life
        string += "Shield: %s\n" %self.shield
        string += "Red:    %s\n" %self.red
        string += "Green:  %s\n" %self.green
        string += "Yellow: %s\n" %self.yellow
        string += "Lilac:  %s\n" %self.lilac  
        
        return string
        
## testing
if __name__ == '__main__':
    a = Player("player.dat")
    print a
