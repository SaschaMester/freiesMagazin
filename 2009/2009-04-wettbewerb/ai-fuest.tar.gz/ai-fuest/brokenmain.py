#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
# brokenmain.py
#       
# Copyright 2009 Mario "Keba" Fuest <keba@yalmagazine.org>
#       
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#       
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#      
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301, USA.

## imports


## The time is a thief: this file is really broken :( The sun is shining and this
## ~zensiert~ file does not want to work. Damnit

from player import Player
from field import Field
from ai import AI

import sys
import copy
import simplejson as json
import time

class Strategy(object):
    """"""
    
    def __init__(self,
                name,
                field = None,
                player = None,
                opponent = None,
                
                opponent_shield = 100000,
                opponent_life = 1000000,
        
                player_reds = 800,
                player_yellows = 600,
                player_greens = 400,
                player_shield = 200, ## blues
                player_lilacs = 1,
                
                tree = True):
        
        if not field:
            f = file("gamefield.dat", "r")
            self.field = f.readlines()
            f.close()
        
        if not player:
            self.player = Player("player.dat")
        
        if not opponent:
            self.opponent = Player("opponent.dat")
        
        self.name = name
        self.tree = tree
        
        ## factors
        self.opponent_shield = opponent_shield
        self.opponent_life = opponent_life
        self.player_reds = player_reds
        self.player_yellows = player_yellows
        self.player_greens = player_greens
        self.player_shield = player_shield
        self.player_lilacs = player_lilacs                
        
    def actualisefiles(self, field, player, opponent):
        self.field = field
        self.player = player
        self.opponent = opponent
        
    def sort(self):
        for i in self.field: print i
        print self.player
        print self.opponent
        
        self.ai = AI(self.field, self.player, self.opponent)
        print "a"
        moves = self.ai.getinfos()
        print "b"
        #print "foo", moves
        player = self.ai.player
        print "c"
        opponent = self.ai.opponent
        print "d"
        
        for m in moves:
           
            move = moves[m]
            move["value"] += ( 15 - opponent.shield ) * self.opponent_shield
            move["value"] += ( 30 - opponent.life ) * self.opponent_life
            
            move["value"] += player.red * self.player_reds
            move["value"] += player.yellow * self.player_yellows
            move["value"] += player.green * self.player_greens
            move["value"] += player.shield * self.player_shield
            move["value"] += player.lilac * self.player_lilacs
            
            
            move["value"] += -( 15 - opponent.shield ) * self.opponent_shield
            move["value"] += -( 30 - opponent.life ) * self.opponent_life
            
            move["value"] += -player.red * self.player_reds
            move["value"] += -player.yellow * self.player_yellows
            move["value"] += -player.green * self.player_greens
            move["value"] += -player.shield * self.player_shield
            move["value"] += -player.lilac * self.player_lilacs
        
        print "e"
        sortedmoves = [({"move":k, "value":v["value"], "field":v["field"], \
                        "player":v["player"], "opponent":v["opponent"]}) \
                        for k, v in sorted(moves.iteritems(), \
                        key=lambda x: x[1]["value"], reverse=True)]
        
        return sortedmoves
 


class Main(object):
    """"""
    
    def __init__(self, jsonfile="infos", resultfile="result.dat"):
        
        self.resultfile = resultfile
        self.jsonfile = jsonfile
        
        self.default = Strategy("default")
        
        self.myai = self.default
        self.otherai = self.default
         
    def referenceai(self, moves):
        bestmove = (10, 10, 10, 10)
  
        for move in moves:
            if move[2] < move[0] or move[2] == move[0] and move[3] < move[1]:
                sortedmove = move[2], move[3], move[0], move[1]
            else:
                sortedmove = move
                
            if sortedmove < bestmove:
                bestmove = sortedmove
            
        return bestmove
        
    def opponent_strategy(self):
        try:
            infofile = file(self.jsonfile, "r")
            info = json.load(infofile)
        except:
            self.round = 0
        else:
            self.round = info["round"]
            infofile.close()       
            
    def myturn(self, depth, alpha, beta, move):
        if depth == 0:
            return move["value"], move
        
        print "foo"
        moves = self.myai.sort()    
        print "bar"
        
        
        for m in moves:
            print 1
            field_backup = copy.deepcopy(self.otherai.field)
            player_backup = copy.deepcopy(self.otherai.player)
            opponent_backup = copy.deepcopy(self.otherai.opponent)
            
            self.otherai.actualisefiles(m["field"], m["player"], m["opponent"])
            print 3
            value, move = self.yourturn(depth - 1, alpha, beta, m)
            
            self.otherai.actualisefiles(field_backup, player_backup, opponent_backup)
            
            print 4                
            if value >= beta:
                return beta, move
                
            if value > alpha:
                 alpha = value
                 
        return alpha, move
 
    def yourturn(self, depth, alpha, beta, move):
        if depth == 0:
            return move["value"], move
            
        print "foo"   
        moves = self.otherai.sort()
        print "bar"
                 
        for m in moves:
            print 2
            
            field_backup = copy.deepcopy(self.myai.field)
            player_backup = copy.deepcopy(self.myai.player)
            opponent_backup = copy.deepcopy(self.myai.opponent)
            
            self.myai.actualisefiles(m["field"], m["player"], m["opponent"])
            
            value, move = self.myturn(depth - 1, alpha, beta, m)
            
            self.myai.actualisefiles(field_backup, player_backup, opponent_backup)

            
            if value <= alpha:
                return alpha, move
                
            if value < beta:
                beta = value

        return beta, move
    
    def searchtree(self, depth, alpha, beta, myturn=True, move=()):
        if depth == 0:
            bestmove = self.sortmoves()[0]
            return bestmove["move"], bestmove["value"]
            
        moves = self.sortmoves()
        
        for movedict in moves:
            move = movedict["move"]
            
            backup = copy.deepcopy(field.field)
            self.applymove(movedict)
            
            print move
            value = movedict["value"]
            
            value = -self.searchtree(depth - 1, -beta, -alpha, False, move)[1]
            
            field.field = backup
            
            if value >= beta:
                return move, beta
            if value > alpha:
                alpha = value
        
        return move, alpha
    
    def giveup(self):
        
        print
        print "KK has kill himself now, but he has left a 'letter':"
        print 
        print "\t'A good warrior should know, when he has lost.'"
        print "\tYou will never reach the goal to kill me with"
        print "\tyour sword. And you were never able to do it."
        print "\tI will kill myself now, to die in honor."
        print "\tTo die for my kingdom, the kingdom of Keba,"
        print "\twhich will and can never fall." 
        print "\tYeah, you won this fight, but you wont win the war."
        print "\tNoone is able to do it. This is really simple!"
        print "\tYou are right: I am dead now."
        print "\tBut imagine: You have won the fight, but you were not"
        print "\table to kill me. So: You are not the winner."
        print "\tI am, because I have not fight for myself,"
        print "\tI have always fight for my kingdom."
        print "\tYou are only a mercenary, but I, I am a warrior."
        print "\tSo I am proud to kill myself now. I am proud that"
        print "\tI could fight for this kingdom."
        print
        print "\tKind regards from the haeven, KK."
        print
        print "\tPS: I am sorry for this not that good English"
        print "\t    and mabye it seems to be pure nonsense,"
        print "\t    but I just wanted to let you know the facts above."
        print "\t    So I did not care for the language. And of course"
        print "\t    I have not written this to became popular,"
        print "\t    I have written this, because it is true."
        sys.exit(0)
        
    def writeinfos(self):
        ## write to jsonfile
        infofile = file(self.jsonfile, "w")
        data = {}
        data["round"] = self.round + 1
        for move in moves:
            data[move["move"]] = move["field"]
             
        json.dump(data, infofile)
        
        infofile.close()
        
    def write(self):
                
        ## print on screen
        print "KK: swap (%i|%i) with (%i|%i)" % (self.best[0], \
                        self.best[1], self.best[2], self.best[3])
            
            
        ## create string for resultfile
        move = ""      
        for c in self.best: ## "best move"
            move += str(c)
        move = ' '.join(move)

        ##  write to resultfile
        try:
            result = file(self.resultfile, "w")
            result.write(move)
            result.close()
        except:
            print "KK: Error: Could not write results to %s - quit" \
                                                        % self.resultfile    
            sys.exit(1)
        
## program
#print default.sort()[0]

main = Main()

print main.myturn(2, -1000000000, 1000000000, ())
print 2532
#print main.sortmoves()
#main.giveup()
#print "nun", main.searchtree(10, -1000000000, 1000000000)
#main.opponent_strategy()
#main.write()


#starttime = time.time()
#for _ in range(1):
#    default.sort()
#    
#endtime = time.time()
#print "Time: %fs" % (endtime - starttime) 

#print main.sortmoves()
