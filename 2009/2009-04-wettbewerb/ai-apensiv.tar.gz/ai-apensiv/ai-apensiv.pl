#!/usr/bin/perl
# KI von apensiv (apensiv@spongedpaste.com) --24.05.2009
# Diese Software steht unter der Namensnennung-Weitergabe unter 
# gleichen Bedingungen 3.0 Deutschland Lizenz (CC-by-sa)
# Weitere Informationen zu dieser Lizenzierung:
# http://creativecommons.org/licenses/by-sa/3.0/de/

use strict;

# config
my $r_file = 'result.dat';
my $p_file = 'player.dat';
my $f_file = 'gamefield.dat';

# stats
my @ld=();
my @md=();
my @bd=();
my @repeat=();
my @shield=();
my @bomb=();
my $pos=();
my $top=();
my $down=();
my $right=();
my $left=();
my $temp=();
my $foo=();
my $tmp_shield=();
my $tmp_red=();
my $tmp_yellow=();
my $tmp_green=();
my $tmp_purple=();

# functions
sub return_profile {
  my ($file, $foo) = @_;
  open(FILE, "<$file") || die "Fehler: $!";
    my @array = <FILE>;
  close FILE;    
  return $array[$foo]; } # end sub return_profile
sub return_field {
  my @lines=();
  open(FILE, "<$f_file") || die "Fehler: $!";
    while(my $line = <FILE>){
        push @lines, [ split /\s+/, $line ];
        last if $. == 10; } # end while        
  close FILE;    
  return @lines; }
my @array = return_field;

sub check_right {
  my ($position, $x, $y) = @_;
  if($position =~ /^\d+$/ && $bomb[0] == "") {
      if($y < '8') {
      if($array[$x][$y+2] =~ /^\d+$/ && $array[$x][$y+3] =~ /^\d+$/) {
        @bomb = ($x, $y, $x, $y+1); 
        return 1; } }
    if($x < '8') {
      if($array[$x+1][$y+1] =~ /^\d+$/ && $array[$x+2][$y+1] =~ /^\d+$/) { 
        @bomb = ($x, $y, $x, $y+1);     
        return 1; } } 
    if($x > '1') {
      if($array[$x-1][$y+1] =~ /^\d+$/ && $array[$x-2][$y+1] =~ /^\d+$/) { 
        @bomb = ($x, $y, $x, $y+1);     
        return 1; } } 
    if($x > '0' && $x < '9') {
      if($array[$x-1][$y+1] =~ /^\d+$/ && $array[$x+1][$y+1] =~ /^\d+$/) { 
        @bomb = ($x, $y, $x, $y+1);     
        return 1; } } }
  if($y < '8') {      
    if($position eq $array[$x][$y+2] && $position eq $array[$x][$y+3]) {
      if($position eq 'R') {
          @bd = ($x, $y, $x, $y++);
          return 1; }
        if($position eq 'B') {
          @shield = ($x, $y, $x, $y++);
          return 1; }
        if($position eq 'G') {
          @ld = ($x, $y, $x, $y++);
          return 1; } 
        if($position eq 'Y') {
          @md = ($x, $y, $x, $y++);
          return 1; }          
        if($position eq 'L') {
          @repeat = ($x, $y, $x, $y++);
          return 1; } } }
      if($x < '8') {
      if($position eq $array[$x+1][$y+1] && $position eq $array[$x+2][$y+1]) {      
        if($position eq 'R') {
            @bd = ($x, $y, $x, $y++);
            return 1; }
          if($position eq 'B') {
            @shield = ($x, $y, $x, $y++);
            return 1; }
          if($position eq 'G') {
            @ld = ($x, $y, $x, $y++);
            return 1; } 
          if($position eq 'Y') {
            @md = ($x, $y, $x, $y++);
            return 1; }          
          if($position eq 'L') {
            @repeat = ($x, $y, $x, $y++);
            return 1; } } }
      if($x > '1') {  
        if($position eq $array[$x-1][$y+1] && $position eq $array[$x-2][$y+1]) {      
        if($position eq 'R') {
            @bd = ($x, $y, $x, $y++);
            return 1; }
          if($position eq 'B') {
            @shield = ($x, $y, $x, $y++);
            return 1; }
          if($position eq 'G') {
            @ld = ($x, $y, $x, $y++);
            return 1; } 
          if($position eq 'Y') {
            @md = ($x, $y, $x, $y++);
            return 1; }          
          if($position eq 'L') {
            @repeat = ($x, $y, $x, $y++);
            return 1; } } }
        if($x > '0' && $x < '9') {
          if($position eq $array[$x-1][$y+1] && $position eq $array[$x+1][$y+1]) {
        if($position eq 'R') {
            @bd = ($x, $y, $x, $y++);
            return 1; }
          if($position eq 'B') {
            @shield = ($x, $y, $x, $y++);
            return 1; }
          if($position eq 'G') {
            @ld = ($x, $y, $x, $y++);
            return 1; } 
          if($position eq 'Y') {
            @md = ($x, $y, $x, $y++);
            return 1; }          
          if($position eq 'L') {
            @repeat = ($x, $y, $x, $y++);
            return 1; } } }
    return 0; }      
    
sub check_left {
  my ($position, $x, $y) = @_;
  if($position =~ /^\d+$/ && $bomb[0] == "") {
      if($y > '2') {
      if($array[$x][$y-2] =~ /^\d+$/ && $array[$x][$y-3] =~ /^\d+$/) {
        @bomb = ($x, $y, $x, $y--); 
        return 1; } }
    if($x > '1') {
      if($array[$x-1][$y-1] =~ /^\d+$/ && $array[$x-2][$y-1] =~ /^\d+$/) { 
        @bomb = ($x, $y, $x, $y--);     
        return 1; } } 
    if($x < '8') {
      if($array[$x+1][$y-1] =~ /^\d+$/ && $array[$x+2][$y-1] =~ /^\d+$/) { 
        @bomb = ($x, $y, $x, $y--);     
        return 1; } }
    if($x > '0' && $x < '9') {
      if($array[$x-1][$y-1] =~ /^\d+$/ && $array[$x+1][$y-1] =~ /^\d+$/) { 
        @bomb = ($x, $y, $x, $y--);     
        return 1; } } }        
  if($y > '2') {      
    if($position eq $array[$x][$y-2] && $position eq $array[$x][$y-3]) {
      if($position eq 'R') {
          @bd = ($x, $y, $x, $y--);
          return 1; }
        if($position eq 'B') {
          @shield = ($x, $y, $x, $y--);
          return 1; }
        if($position eq 'G') {
          @ld = ($x, $y, $x, $y--);
          return 1; } 
        if($position eq 'Y') {
          @md = ($x, $y, $x, $y--);
          return 1; }          
        if($position eq 'L') {
          @repeat = ($x, $y, $x, $y--);
          return 1; } } }
  if($x > '1') {
    if($position eq $array[$x-1][$y-1] && $position eq $array[$x-2][$y-1]) {  
      if($position eq 'R') {
          @bd = ($x, $y, $x, $y--);
          return 1; }
        if($position eq 'B') {
          @shield = ($x, $y, $x, $y--);
          return 1; }
        if($position eq 'G') {
          @ld = ($x, $y, $x, $y--);
          return 1; } 
        if($position eq 'Y') {
          @md = ($x, $y, $x, $y--);
          return 1; }          
        if($position eq 'L') {
          @repeat = ($x, $y, $x, $y--);
          return 1; } } }             
        if($x > '0' && $x < '9') {
          if($position eq $array[$x-1][$y-1] && $position eq $array[$x+1][$y-1]) {
        if($position eq 'R') {
            @bd = ($x, $y, $x, $y--);
            return 1; }
          if($position eq 'B') {
            @shield = ($x, $y, $x, $y--);
            return 1; }
          if($position eq 'G') {
            @ld = ($x, $y, $x, $y--);
            return 1; } 
          if($position eq 'Y') {
            @md = ($x, $y, $x, $y--);
            return 1; }          
          if($position eq 'L') {
            @repeat = ($x, $y, $x, $y--);
            return 1; } } }
    return 0; }    

sub check_top {
  my ($position, $x, $y) = @_;
  if($position =~ /^\d+$/ && $bomb[0] == "") {
      if($x > '2') {
      if($array[$x-2][$y] =~ /^\d+$/ && $array[$x-3][$y] =~ /^\d+$/) {
        @bomb = ($x, $y, $x--, $y); 
        return 1; } }
    if($y > '1') {
      if($array[$x-1][$y-1] =~ /^\d+$/ && $array[$x-1][$y-2] =~ /^\d+$/) { 
        @bomb = ($x, $y, $x--, $y);     
        return 1; } }
    if($x < '8') {
      if($array[$x-1][$y+1] =~ /^\d+$/ && $array[$x-1][$y+2] =~ /^\d+$/) { 
        @bomb = ($x, $y, $x--, $y);     
        return 1; } }
    if($y > '0' && $y < '9') {
      if($array[$x-1][$y+1] =~ /^\d+$/ && $array[$x-1][$y-1] =~ /^\d+$/) { 
        @bomb = ($x, $y, $x--, $y);     
        return 1; } } }           
  if($x > '2') {      
    if($position eq $array[$x-2][$y] && $position eq $array[$x-3][$y]) {
      if($position eq 'R') {
          @bd = ($x, $y, $x--, $y);
          return 1; }
        if($position eq 'B') {
          @shield = ($x, $y, $x--, $y);
          return 1; }
        if($position eq 'G') {
          @ld = ($x, $y, $x--, $y);
          return 1; } 
        if($position eq 'Y') {
          @md = ($x, $y, $x--, $y);
          return 1; }          
        if($position eq 'L') {
          @repeat = ($x, $y, $x--, $y);
          return 1; } } }
      if($y > '1') {
      if($position eq $array[$x-1][$y-1] && $position eq $array[$x-1][$y-2]) {  
        if($position eq 'R') {
            @bd = ($x, $y, $x--, $y);
            return 1; }
          if($position eq 'B') {
            @shield = ($x, $y, $x--, $y);
            return 1; }
          if($position eq 'G') {
            @ld = ($x, $y, $x--, $y);
            return 1; } 
          if($position eq 'Y') {
            @md = ($x, $y, $x--, $y);
            return 1; }          
          if($position eq 'L') {
            @repeat = ($x, $y, $x--, $y);
            return 1; } } }
      if($y > '0' && $y < '9') {  
      if($position eq $array[$x-1][$y+1] && $position eq $array[$x-1][$y-1]) {  
        if($position eq 'R') {
            @bd = ($x, $y, $x--, $y);
            return 1; }
          if($position eq 'B') {
            @shield = ($x, $y, $x--, $y);
            return 1; }
          if($position eq 'G') {
            @ld = ($x, $y, $x--, $y);
            return 1; } 
          if($position eq 'Y') {
            @md = ($x, $y, $x--, $y);
            return 1; }          
          if($position eq 'L') {
            @repeat = ($x, $y, $x--, $y);
            return 1; } } }                                  
    return 0; }  

sub check_down {
  my ($position, $x, $y) = @_;
  if($position =~ /^\d+$/ && $bomb[0] == "") {
      if($x < '7') {
      if($array[$x+2][$y] =~ /^\d+$/ && $array[$x+3][$y] =~ /^\d+$/) {
        @bomb = ($x, $y, $x++, $y); 
        return 1; } }
    if($y > '1') {
      if($array[$x+1][$y-1] =~ /^\d+$/ && $array[$x+1][$y-2] =~ /^\d+$/) { 
        @bomb = ($x, $y, $x++, $y);     
        return 1; } }
    if($y < '8') {
      if($array[$x+1][$y+1] =~ /^\d+$/ && $array[$x+1][$y+2] =~ /^\d+$/) { 
        @bomb = ($x, $y, $x++, $y);     
        return 1; } }
    if($y > '0' && $y < '9') {
      if($array[$x+1][$y+1] =~ /^\d+$/ && $array[$x+1][$y-1] =~ /^\d+$/) { 
        @bomb = ($x, $y, $x++, $y);     
        return 1; } } }          
  if($x < '7') {      
    if($position eq $array[$x+2][$y] && $position eq $array[$x+3][$y]) {
      if($position eq 'R') {
          @bd = ($x, $y, $x++, $y);
          return 1; }
        if($position eq 'B') {
          @shield = ($x, $y, $x++, $y);
          return 1; }
        if($position eq 'G') {
          @ld = ($x, $y, $x++, $y);
          return 1; } 
        if($position eq 'Y') {
          @md = ($x, $y, $x++, $y);
          return 1; }          
        if($position eq 'L') {
          @repeat = ($x, $y, $x++, $y);
          return 1; } } }
  if($y > '1') {
    if($position eq $array[$x+1][$y-1] && $position eq $array[$x+1][$y-2]) {  
        if($position eq 'R') {
            @bd = ($x, $y, $x++, $y);
            return 1; }
          if($position eq 'B') {
            @shield = ($x, $y, $x++, $y);
            return 1; }
          if($position eq 'G') {
            @ld = ($x, $y, $x++, $y);
            return 1; } 
          if($position eq 'Y') {
            @md = ($x, $y, $x++, $y);
            return 1; }          
          if($position eq 'L') {
            @repeat = ($x, $y, $x++, $y);
            return 1; } } }  
  if($y < '8') {
    if($position eq $array[$x+1][$y+1] && $position eq $array[$x+1][$y+2]) {  
        if($position eq 'R') {
            @bd = ($x, $y, $x++, $y);
            return 1; }
          if($position eq 'B') {
            @shield = ($x, $y, $x++, $y);
            return 1; }
          if($position eq 'G') {
            @ld = ($x, $y, $x++, $y);
            return 1; } 
          if($position eq 'Y') {
            @md = ($x, $y, $x++, $y);
            return 1; }          
          if($position eq 'L') {
            @repeat = ($x, $y, $x++, $y);
            return 1; } } }                          
  if($y > '0' && $y < '9') {  
    if($position eq $array[$x+1][$y+1] && $position eq $array[$x+1][$y-1]) {  
        if($position eq 'R') {
            @bd = ($x, $y, $x++, $y);
            return 1; }
          if($position eq 'B') {
            @shield = ($x, $y, $x++, $y);
            return 1; }
          if($position eq 'G') {
            @ld = ($x, $y, $x++, $y);
            return 1; } 
          if($position eq 'Y') {
            @md = ($x, $y, $x++, $y);
            return 1; }          
          if($position eq 'L') {
            @repeat = ($x, $y, $x++, $y);
            return 1; } } }                                  
    return 0; }   

sub changecord {
  my (@array) = @_;    
  if(@array) {
  if($array[0] == 0) { $array[0] = 9; }
    elsif($array[0] == 1) { $array[0] = 8; }
    elsif($array[0] == 2) { $array[0] = 7; }
    elsif($array[0] == 3) { $array[0] = 6; }
    elsif($array[0] == 4) { $array[0] = 5; }
    elsif($array[0] == 5) { $array[0] = 4; }
    elsif($array[0] == 6) { $array[0] = 3; }
    elsif($array[0] == 7) { $array[0] = 2; }
    elsif($array[0] == 8) { $array[0] = 1; }
    elsif($array[0] == 9) { $array[0] = 0; }      
  if($array[2] == 0) { $array[2] = 9; }
    elsif($array[2] == 1) { $array[2] = 8; }
    elsif($array[2] == 2) { $array[2] = 7; }
    elsif($array[2] == 3) { $array[2] = 6; }
    elsif($array[2] == 4) { $array[2] = 5; }
    elsif($array[2] == 5) { $array[2] = 4; }
    elsif($array[2] == 6) { $array[2] = 3; }
    elsif($array[2] == 7) { $array[2] = 2; }
    elsif($array[2] == 8) { $array[2] = 1; }
    elsif($array[2] == 9) { $array[2] = 0; } }
  return @array; }
  
# main-content
for(my $x=0;$x<=10;$x++) {
  for(my $y=0;$y<=10;$y++) {
      $pos = $array[$x][$y];
    if($y < '9') { $right = check_right($pos, $x, $y); }
    if($y > '0') { $left = check_left($pos, $x, $y); } 
    if($x > '0') { $top = check_top($pos, $x, $y); } 
    if($x < '9') { $down = check_down($pos, $x, $y); } } }

@ld = changecord(@ld);
@md = changecord(@md);
@bd = changecord(@bd);
@repeat = changecord(@repeat);
@shield = changecord(@shield);
@bomb = changecord(@bomb);

$tmp_shield = return_profile($p_file, 1);
$tmp_red = return_profile($p_file, 2);
$tmp_yellow = return_profile($p_file, 3);
$tmp_green = return_profile($p_file, 4);
$tmp_purple = return_profile($p_file, 5);

if($bomb[3]) { $foo = $bomb[1] . " " . $bomb[0] . " " . $bomb[3] . " " . $bomb[2]; }
  elsif($shield[3] && $tmp_shield < '13') { $foo = $shield[1] . " " . $shield[0] . " " . $shield[3] . " " . $shield[2]; }    
  elsif($bd[3] && $tmp_red > '10')  { $foo = $bd[1] . " " . $bd[0] . " " . $bd[3] . " " . $bd[2]; }
  elsif($md[3] && $tmp_yellow > '10') { $foo = $md[1] . " " . $md[0] . " " . $md[3] . " " . $md[2]; }
  elsif($ld[3] && $tmp_green > '10') { $foo = $ld[1] . " " . $ld[0] . " " . $ld[3] . " " . $ld[2]; }
  elsif($bd[3])  { $foo = $bd[1] . " " . $bd[0] . " " . $bd[3] . " " . $bd[2]; }
  elsif($md[3] && $tmp_yellow > '10') { $foo = $md[1] . " " . $md[0] . " " . $md[3] . " " . $md[2]; }
  elsif($ld[3] && $tmp_green > '10') { $foo = $ld[1] . " " . $ld[0] . " " . $ld[3] . " " . $ld[2]; }  
  elsif($repeat[3]) { $foo = $repeat[1] . " " . $repeat[0] . " " . $repeat[3] . " " . $repeat[2]; } 
  elsif($shield[3]) { $foo = $shield[1] . " " . $shield[0] . " " . $shield[3] . " " . $shield[2]; }                            

open(FILE, ">$r_file") || die "Fehler: $!";
  print FILE $foo;
close FILE; 
