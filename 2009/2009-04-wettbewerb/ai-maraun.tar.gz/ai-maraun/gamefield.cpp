// *************************************************************************
// freiesMagazin-Programmierwettbewerb (ai)
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Copyright 2009 Erweitert von Momme Maraun <maraun@web.de>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

// System
///////////
#include <iostream>
#include <fstream>
#include <vector>

// Own
//////////////
#include "zug.cpp"
#include "gamefield.h"
#include "fieldpos.h"

Zug * neuerZug(int x1, int y1, int x2, int y2, char cc, Zug * altzug) {
	Zug* z = new Zug();
	z->set(x1, y1, x2, y2, cc, altzug);
	printf("\t--- %c %i %i %i %i\n",cc,x1,y1,x2,y2);
 	return z;
} 
bool checkTyp(char qq,Zug * zugx,FieldPos& pos1,FieldPos& pos2) {
	Zug * nn = zugx;
	while(nn->nextzug != 0) {
    if (nn->cc == qq) {
			pos1.set(nn->x1,nn->y1);
			pos2.set(nn->x2,nn->y2);
			return true;
		 }
		nn = nn->nextzug;
	}
return false;
}
// standard constructor
// initialize game field
GameField::GameField(void)
{
    // nothing to do
}

// Copy constructor
GameField::GameField(const GameField& field)
{
    for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
    {
        for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
        {
            m_field[i][j] = field.m_field[i][j];
        }
    }
}
      
// destructor
GameField::~GameField(void)
{
    // nothing to do
}

// copy game field
void GameField::set(const GameField& field)
{
    for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
    {
        for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
        {
            m_field[i][j] = field.m_field[i][j];
        }
    }  
}

// opens file and reads the first 100 relevant characters
// newline, cr, spaces and tabs will be ignored
// return true if everything is ok
const bool GameField::read(const std::string& filename)
{
    bool ok = false;

    if ( !filename.empty() )
    {
        // open file for writing
        std::ifstream infile( filename.c_str() );
        
        if ( NULL != infile )
        {
            unsigned int i = 0;
            unsigned int j = 0;
            
            while ( infile.good() && j < FIELD_HEIGHT )
            {
                if ( i >= FIELD_WIDTH )
                {
                    i = 0;
                    j++;
                }
                
                // read character
                char c = 0;
                infile.get(c);
                // std::cout << c;
                
                switch ( (Tile::TileType)c )
                {
                    case Tile::TILE_RED:
                    case Tile::TILE_GREEN:
                    case Tile::TILE_YELLOW:
                    case Tile::TILE_SHIELD:
                    case Tile::TILE_LILAC:
                    case Tile::TILE_BOMB_1:
                    case Tile::TILE_BOMB_2:
                    case Tile::TILE_BOMB_3:
                    case Tile::TILE_BOMB_4:
                    case Tile::TILE_BOMB_5:
                        // store tile
                        m_field[i][FIELD_HEIGHT-j-1].set( (Tile::TileType)c );
                        i++;
                        break;
                    default:
                      // ignore everything else
                      break;
                }
            }
            
            // check if whole field was loaded
            if ( ( 0 != i ) || ( FIELD_HEIGHT != j ) )
            {
                std::cout << "GameField::read() error: game field was not loaded completely" << std::endl;
            }
            else
            {
                ok = true;
            }

            // close file
            infile.close();
        }
        else
        {
            std::cout << "GameField::read() error: file could not be opened" << std::endl;
        }
    }
    else
    {
        std::cout << "GameField::read() error: string is empty" << std::endl;
    }
    
    if (ok)
    {
        // print();
    }

    return ok;
}

// prints the game field on screen
void GameField::print(void) const
{
    for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
    {
        for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
        {
            // initialize with zeros
            std::cout << (char)m_field[i][FIELD_HEIGHT-j-1].getType() << " ";
        }
        std::cout << std::endl;
    }        
    std::cout << std::endl;
}

// calculate next move for this player
// and write result to file
const bool GameField::calculate(const Player& player, const Player& opponent, const std::string& filename) const
{
    bool ok = false;
    
    // search "good" tile on game field
    // This KI is really dumb! It just searches the first possible
    // positions to swap. It does not take the player or opponent
    // settings into account.
    // THIS IS YOUR TASK! ;)
    
    // tile positions on game field to swap
    FieldPos pos1, pos2;

    if ( findSwapPositions(pos1, pos2) )
    {
        // std::cout << "GameField::calculate() swap "
        //           << pos1.x() << " " << pos1.y() << " with "
        //           << pos2.x() << " " << pos2.y() << std::endl;

        // store positions
        if ( writePositions(pos1, pos2, filename) )
        {
            ok = true;
        }
    }
    
    return ok;
}

// search "good" tile on game field that should be swapped
// return true if position could be found
const bool GameField::findSwapPositions(FieldPos& pos1, FieldPos& pos2) const
{
    // we go through each column and row and swap single elements
    Zug *zugx = new Zug();
    zugx->set(0,0,0,0,'-',0);
    for ( unsigned int y = 0; y < FIELD_WIDTH-1; y++ )
    {
        for ( unsigned int x = 0; x < FIELD_HEIGHT-1; x++ )
        {
            zugx = checkSwapPosition(x,y,zugx);
 
        }
    } 

    // X steht als Synonym für eine Bombe
    if (checkTyp('X',zugx,pos1,pos2)) { return true; } 
    if (checkTyp('B',zugx,pos1,pos2)) { return true; } 
    if (checkTyp('R',zugx,pos1,pos2)) { return true; } 
    if (checkTyp('Y',zugx,pos1,pos2)) { return true; } 
    if (checkTyp('L',zugx,pos1,pos2)) { return true; } 
    if (checkTyp('G',zugx,pos1,pos2)) { return true; } 
    
    return false;
}

// Kontrolle was möglich ist an diester Position
Zug *  GameField::checkSwapPosition(int x, int y, Zug * kette) const
{
Zug *zug = kette;
    // Horizontal checken ob zwei gleiche nebeneinander
    if (x<8) {
	    const Tile* t1 = &m_field[x][y];
       char c1 = t1->getTxpe();
	    const Tile* t2 = &m_field[x+1][y];
		 char c2 = t2->getTxpe();
		 if (c1 == c2) {
	   	 //printf(".. %i,%i =%c%c\n", x,y,c1,c2);
	    	const Tile* t3;
		 	char c3;
			if (x>1) {
		  	  	t3 = &m_field[x-2][y];
			 	c3 = t3->getTxpe();
			 	if (c1 == c3) {
					zug = neuerZug(x-1,y,x-2,y,c1,zug);
				}
			}
			if (x>0) {
				if (y<9) {
			    	t3 = &m_field[x-1][y+1];
				 	c3 = t3->getTxpe();
				 	if (c1 == c3) {
						zug = neuerZug(x-1,y,x-1,y+1,c1,zug);
					
					}
				}
				if (y>0){
			    	t3 = &m_field[x-1][y-1];
				 	c3 = t3->getTxpe();
				 	if (c1 == c3) {
						zug = neuerZug(x-1,y,x-1,y-1,c1,zug);
					}
				}
			}
			if (x<6) {
		  	  	t3 = &m_field[x+3][y];
			 	c3 = t3->getTxpe();
			 	if (c1 == c3) {
					zug = neuerZug(x+2,y,x+3,y,c1,zug);
				}
			}
			if (x<7) {
				if (y<9) {
			    	t3 = &m_field[x+2][y+1];
				 	c3 = t3->getTxpe();
				 	if (c1 == c3) {
						zug = neuerZug(x+2,y,x+2,y+1,c1,zug);
					
					}
				}
				if (y>0){
			    	t3 = &m_field[x+2][y-1];
				 	c3 = t3->getTxpe();
				 	if (c1 == c3) {
						zug = neuerZug(x+2,y,x+2,y-1,c1,zug);
					}
				}
			}

		 }
       if (x<7) {
	    	const Tile* t3 = &m_field[x+2][y];
		 	char c3 = t3->getTxpe();
		 	if (c1 == c3) {
				 if (y>0) {
	    			const Tile* t3a = &m_field[x+1][y-1];
		 			char c3a = t3a->getTxpe();
				   if (c1==c3a) {
						zug = neuerZug(x+1,y,x+1,y-1,c1,zug);
					}
				 }
				 if (y<9) {
	    			const Tile* t3a = &m_field[x+1][y+1];
		 			char c3a = t3a->getTxpe();
				   if (c1==c3a) {
						zug = neuerZug(x+1,y,x+1,y+1,c1,zug);
					}
				 }
			 }
		 }
    }	




    if (y<8) {
	    const Tile* t1 = &m_field[x][y];
       char c1 = t1->getTxpe();
	    const Tile* t2 = &m_field[x][y+1];
		 char c2 = t2->getTxpe();
		 if (c1 == c2) {
	   	 //printf(".. %i,%i =%c%c\n", x,y,c1,c2);
	    	const Tile* t3;
		 	char c3;
			if (y>1) {
		  	  	t3 = &m_field[x][y-2];
			 	c3 = t3->getTxpe();
			 	if (c1 == c3) {
						zug = neuerZug(x,y-1,x,y-2,c1,zug);
				}
			}
			if (y>0) {
				if (x<9) {
			    	t3 = &m_field[x+1][y-1];
				 	c3 = t3->getTxpe();
				 	if (c1 == c3) {
						zug = neuerZug(x,y-1,x+1,y-1,c1,zug);
					
					}
				}
				if (x>0){
			    	t3 = &m_field[x-1][y-1];
				 	c3 = t3->getTxpe();
				 	if (c1 == c3) {
						zug = neuerZug(x,y-1,x-1,y-1,c1,zug);
					}
				}
			}
			if (y<6) {
		  	  	t3 = &m_field[x][y+3];
			 	c3 = t3->getTxpe();
			 	if (c1 == c3) {
						zug = neuerZug(x,y+2,x,y+3,c1,zug);
				}
			}
			if (y<7) {
				if (x<9) {
			    	t3 = &m_field[x+1][y+2];
				 	c3 = t3->getTxpe();
				 	if (c1 == c3) {
						zug = neuerZug(x,y+2,x+1,y+2,c1,zug);
					}
				}
				if (x>0){
			    	t3 = &m_field[x-1][y+2];
				 	c3 = t3->getTxpe();
				 	if (c1 == c3) {
						zug = neuerZug(x,y+2,x-1,y+2,c1,zug);
					}
				}
			}

		 }
       if (y<7) {
	    	const Tile* t3 = &m_field[x][y+2];
		 	char c3 = t3->getTxpe();
		 	if (c1 == c3) {
				 if (x>0) {
	    			const Tile* t3a = &m_field[x-1][y+1];
		 			char c3a = t3a->getTxpe();
				   if (c1==c3a) {
						zug = neuerZug(x,y+1,x-1,y+1,c1,zug);
					}
				 }
				 if (x<9) {
	    			const Tile* t3a = &m_field[x+1][y+1];
		 			char c3a = t3a->getTxpe();
				   if (c1==c3a) {
						zug = neuerZug(x,y+1,x+1,y+1,c1,zug);
					}
				 }
			 }
		 }
    }	


    return zug;
}

// return const reference for tile    
const Tile& GameField::getTile(const FieldPos& pos) const
{
    if ( ( pos.x() >= FIELD_WIDTH ) || ( pos.y() >= FIELD_HEIGHT ) )
    {
        std::cout << "GameField::getTile() access out of boundaries" << std::endl;
        return m_dummyTile;
    }
    else
    {
        return m_field[pos.x()][pos.y()];
    }
}

// return reference for tile    
Tile& GameField::getTile(const FieldPos& pos)
{
    if ( ( pos.x() >= FIELD_WIDTH ) || ( pos.y() >= FIELD_HEIGHT ) )
    {
        std::cout << "GameField::getTile() access out of boundaries" << std::endl;
        return m_dummyTile;
    }
    else
    {
        return m_field[pos.x()][pos.y()];
    }
}

// store positions in file
// return true if everything is ok
const bool GameField::writePositions(const FieldPos& pos1, const FieldPos&pos2, const std::string filename) const
{
    bool ok = false;

    if ( !filename.empty() )
    {
        // open file for writing
        std::ofstream outfile( filename.c_str() );
        
        if ( outfile.good() )
        {
            // write positions into file
            outfile << pos1.x() << " "
                    << pos1.y() << " "
                    << pos2.x() << " "
                    << pos2.y() << std::endl;
            
            // close file
            outfile.close();
            
            ok = true;
        }
        else
        {
            std::cout << "GameField::writePositions() error: file could not be opened" << std::endl;
        }
    }
    else
    {
        std::cout << "GameField::writePositions() error: string is empty" << std::endl;
    }
    
    return ok;
}
