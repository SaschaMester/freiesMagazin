// *************************************************************************
// freiesMagazin-Programmierwettbewerb (ai)
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Copyright 2009 Erweitert von Momme Maraun <maraun@web.de>
// Licence: GPLv3
// *************************************************************************
#ifndef ZUGH
#define ZUGH

#include <iostream>
#include <fstream>
#include <vector>
 

class Zug
{
public:

	int x1;
	int y1;
	int x2;
	int y2;
	char cc;	
	Zug *nextzug;

public:
	void set(int _x1, int _y1, int _x2, int _y2, char _cc, Zug *_altzug)
	{
		// nothing here
		x1 = _x1;
		y1 = _y1;
		x2 = _x2;
		y2 = _y2;
		cc = _cc;
		nextzug = _altzug;
	}

};

#endif // ZUGH
