#!/usr/bin/env python
#
# logic.py
#

# Copyright (c) 2009, Florian Reichel
# All rights reserved.

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#   * Redistributions of source code must retain the above copyright notice,
#		this list of conditions and the following disclaimer.
#   * Redistributions in binary form must reproduce the above copyright
#		notice, this list of conditions and the following disclaimer in the
#		documentation and/or other materials provided with the distribution.
#   * Neither the name of the Copyright-holder nor the names of its
#		contributors may be used to endorse or promote products derived from
#		this software without specific prior written permission.

#THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
#ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
#
#FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
#DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
#SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
#CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
#LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
#OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
#SUCH DAMAGE.

#pairs:
# 1. blue
# 2. green
# 3. red
# 4. lilac
# 5. blue/green
# 6. blue/red
# 7. blue/lilac
# 8. green/red
# 9. green/lilac
# 10. red/lilac
# 11. bomb

from parsing import *
import sys


class Logic(object):

	def __init__(self,pairs,player,opponent):
		self.pairs = pairs
		self.need_objects = [
			"15_", "14_", "13_", "12_", "11_", "10_", "9_", "8_",
			"7_", "6_", "5B", "5_", "4_", "4B", "3_",
			"3R/3B", "3L/3B", "3Y/3B", "3G/3B", "3B",	# blue
			"5R", "2_", "1_", "4R", 
			"3R/3L", "3R/3Y", "3R/3G", "3R", #red
			"5L", "4L", "5Y", "4Y",
			"3Y/3L", "3Y/3G", "3Y",	# yellow
			"3L/3G", "3L",	# lilac
			"5G", "4G",
			"3G" #green
		]
		self.player = player
		self.opponent = opponent
		
	def __del__(self):
		pass
		
	def priority(self):
		"""calculating need_list"""
		print "priority: "
		
	# * nice lilac-move
	#
	#	if self.player["lilac"] >= 10 and ('5L' in self.pairs) or  
	#		self.player["lilac"] >= 11 and ('4L' in self.pairs) or
	#		self.player["lilac"] >= 12 and ('3L' in self.pairs):
			
			# self.next_move()
			# calculate next-move, is good enough ... FIXME
	
	
	# * not needing shield
	# 			- sort the Blue-Stones out, when not needed
	
		if self.player["shield"] > 12:
			if self.opponent["shield"] > 12:		
	 			# sort the blue stones to end of the list
				for position in range(0,len(self.need_objects)):
					if self.need_objects[position] == "3B" or \
						self.need_objects[position] == "4B" or \
						self.need_objects[position] == "5B":
						tmp = self.need_objects[position][:]
						del self.need_objects[position]
						self.need_objects.append(tmp)
	#
	# * opponent nearly dead ?
	#
	#	if (self.opponent["hp"] + self.opponent["shield"]) <= 10:
	#		if zahl >= 10 vorhanden						#FIXME, red >= 11 gg fall.
	#		elif red >= 12 vorhand
	#	elif (self.opponent["hp"] + self.opponent["shield"]) <= 6:
	#		red()
	#		yellow()
	
	#	elif self.opponent["hp"] + self.opponent["shield"] <= 3 and
	#		  self.player["green"] >= 12 and '3G' in self.pairs:
	#		green()
			
	#		red()
	#		yellow()
	#		green()
	#
	# * player nearly dead ?
	#
	# 	stones which can be gathered to read 15
	#
		print "end priority"
		
		
	def solution(self):
		"""give solution"""
		self.priority()
		i=0
		while True:
			try:	
				tmp = self.pairs[self.need_objects[i]]	# FIXME
				print self.need_objects[i]
				break
			except:
				i+=1
				if i > len(self.need_objects):
					return -1
		move = " ".join(["%s" % el for el in tmp])
		return move
		
		
	def next_move(self):
		"""
		calculating next move, to find out
		whether the next-move is 'helpfull'
		"""
		parser = Parser("n_move.dat")
		n_field = data.field()
		#FIXME
