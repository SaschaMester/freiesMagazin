#!/usr/bin/env python
#
# find.py
#

# Copyright (c) 2009, Florian Reichel
# All rights reserved.

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#   * Redistributions of source code must retain the above copyright notice,
#		this list of conditions and the following disclaimer.
#   * Redistributions in binary form must reproduce the above copyright
#		notice, this list of conditions and the following disclaimer in the
#		documentation and/or other materials provided with the distribution.
#   * Neither the name of the Copyright-holder nor the names of its
#		contributors may be used to endorse or promote products derived from
#		this software without specific prior written permission.

#THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
#ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
#
#FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
#DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
#SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
#CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
#LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
#OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
#SUCH DAMAGE.

import sys

class Find(object):

	def __init__(self, field):
		self.list1 = []
		self.list2 = []
		self.column = 9
		self.string1 = ""
		self.string2 = ""
		self.pairs = {}
		self.field = field
		self.search_objects = [	
			"555", "554", "553", "552", "551", "545", "544", 
			"542", "541", "535", "534", "533", "532", "531", 
			"525", "524", "523", "522", "521", "515", "514", 
			"513", "512", "511", "455", "454", "453", "452", 
			"451", "445", "444", "443", "442", "441", "435", 
			"434", "433", "432", "431", "425", "424", "423", 
			"422", "421", "415", "414", "413", "412", "411", 
			"355", "354", "353", "352", "351", "345", "344", 
			"343", "342", "341", "335", "334", "333", "332", 
			"331", "325", "324", "323", "322", "321", "315", 
			"314", "313", "312", "311", "255", "254", "253", 
			"252", "251", "245", "244", "243", "242", "241", 
			"235", "234", "233", "232", "231", "225", "224", 
			"223", "222", "221", "215", "214", "213", "212", 
			"211", "155", "154", "153", "152", "151", "145", 
			"144", "143", "142", "141", "135", "134", "133", 
			"132", "131", "125", "124", "123", "122", "121", 
			"115", "114", "113", "112", "543", "111",
			"BBBBB", "BBBB", "BBB", "RRRRR", "RRRR", "RRR", 
			"YYYYY", "YYYY", "YYY", "LLLLL", "LLLL", "LLL",
			"GGGGG", "GGGG", "GGG",		 			
		]
		
		
	def __del__(self):
		pass
	
	def result(self):
		self.find_pairs()
		self.find_equal()
		return self.pairs
		
	def find_pairs(self):
		
		# turning the matrix
		turn_field = [ [],[],[],[],[],[],[],[],[],[], ]
		new_row = []
		
		i=0
		for number in range(0,10,1):
			for x in self.field:
				 new_row += x[number][:]
			turn_field[i][:] = new_row
			new_row = []
			i+=1
	
	# comparing single column/row
	
		for self.column in range(0, 10):
		
			for number in range(0, 9):
				
				# comparing rows
				
				self.list1 = self.field[self.column][:]
				
				tmp = self.list1[number]
				self.list1[number] = self.list1[number+1]
				self.list1[number+1] = tmp
				
				self.string1 = ''.join(self.list1)
				
				self.append_pairs(number,self.column,number+1,self.column) 
		
				# comparing columns
				
				self.list1 = turn_field[self.column][:]
		
				tmp = self.list1[number]
				self.list1[number] = self.list1[number+1]
				self.list1[number+1] = tmp
				
				self.string1 = ''.join(self.list1)
		
				self.append_pairs(self.column,number,self.column,number+1)
		
	# comparing between rows
	
		for self.column in range(0, 9):
	
			for number in range(0,10):
			
				# finding column-values (compare to rows)
			
				self.list1 = self.field[self.column][:]
				self.list2 = self.field[self.column+1][:]
				
				tmp = self.list1[number][:]
				self.list1[number] = self.list2[number]
				self.list2[number] = tmp

				self.string1 = ''.join(self.list1)
				self.string2 = ''.join(self.list2)
				self.append_pairs(number,self.column,number,self.column+1)
				
				# finding row-values
			
				self.list1 = turn_field[self.column][:]
				self.list2 = turn_field[self.column+1][:]
				
				tmp = self.list1[number][:]
				self.list1[number] = self.list2[number]
				self.list2[number] = tmp

				self.string1 = ''.join(self.list1)
				self.string2 = ''.join(self.list2)
				self.append_pairs(self.column,number,self.column+1,number)
	
	
	def append_pairs(self,x1,y1,x2,y2):
		for obj in self.search_objects:
			status = self.string1.find(obj)
			if status > -1:
				status+=1
				
					# convert pair like BBB into 3B or 356 into 3+5+6 = 14
				
				try:
					int(obj[0])
					value = 0
					for i in range(0,len(obj)):
						value += int(obj[i])
					self.append_to_dict(str(value)+"_",[x1,y1,x2,y2])
				except ValueError:
					self.append_to_dict(str(len(obj))+obj[0],[x1,y1,x2,y2])
					
			status = self.string2.find(obj)
			if status > -1:
				status+=1
				try:
					int(obj[0])
					value = 0
					for i in range(0,len(obj)):
						value += int(obj[i])
					self.append_to_dict(str(value)+"_",[x1,y1,x2,y2])
				except ValueError:
					self.append_to_dict(str(len(obj))+obj[0],[x1,y1,x2,y2])
					
					
	def append_to_dict(self,name,value):
		i = 1
		tmp = name
		while True:
			try:
				self.pairs[name]
				name = tmp
				i += 1
				name = name + "%s" %i
			except:
				break
		self.pairs[name] = value
		
		
	def find_equal(self):
		"""
		if one move actuallay hit 2 pairs,
		rename this pairs to one and write the
		new value into the dict
		"""
		new_list = self.pairs.keys()
		newdict = self.pairs.copy()
		y=0
		
		for x in range(0,len(self.pairs),1):
		
			for value in self.pairs:
		
				if self.pairs[new_list[x-y]] == self.pairs[value]:
				
					if new_list[x-y] != value:	# if the names are similar, pass
				
						# if this and that already in dict, than not
						key = "%s/%s" % ( new_list[x-y] , value )
						newdict.update({key : self.pairs[value]})
						

		find_objects = [ "3R/3G", "3R/3L", "3R/3Y", "3R/3B", "3L/3G", "3L/3Y",
							  "3L/3B", "3Y/3G", "3Y/3B", "3B/3G",
							  "3B/3B", "3R/3R", "3Y/3Y", "3G/3G" ]

		for pair in newdict:

			for t in range(0,len(find_objects),1):
	
				if len(pair) > 5:

					if pair.find(find_objects[t][0:2]) > -1 and \
						pair.find(find_objects[t][3:5]) > -1 :
						
						# FIXME: seems a little bit overloaded,
						# [...] missing numbers			
						if pair.find("//") > 0:
							s1, s2 = pair.split("//")
						else:
			#				print pair
							s1, s2 = pair.split("/")
						s = s1[:2]+"/"+s2[:2]	#FIXME:cutting out identifier 3B(2)!
						
						self.pairs.update({s:newdict[pair]})
