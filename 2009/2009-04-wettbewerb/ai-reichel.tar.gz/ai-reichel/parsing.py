#!/usr/bin/env python
#
# parsing.py
#

# Copyright (c) 2009, Florian Reichel
# All rights reserved.

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#   * Redistributions of source code must retain the above copyright notice,
#		this list of conditions and the following disclaimer.
#   * Redistributions in binary form must reproduce the above copyright
#		notice, this list of conditions and the following disclaimer in the
#		documentation and/or other materials provided with the distribution.
#   * Neither the name of the Copyright-holder nor the names of its
#		contributors may be used to endorse or promote products derived from
#		this software without specific prior written permission.

#THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
#ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
#
#FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
#DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
#SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
#CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
#LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
#OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
#SUCH DAMAGE.

class Parser(object):

	def __init__(self,sfield="gamefield.dat"):
		self.ffield = open(sfield, "r")
		self.fplayer = open("player.dat", "r")
		self.fopponent = open("opponent.dat", "r")
	
	
	def __del__(self):
		self.ffield.close()
		self.fplayer.close()
		self.fopponent.close()
	
	
	def field(self):
		fields = [ [],[],[],[],[],[],[],[],[],[], ]
		#print fields
		y = 10
		
		for line in self.ffield:
			# only reading the first 10 lines, (currently)
			if y > 0:
				y -= 1
				line = line.strip()
				for c in line.split(" "):
					fields[y] += c
		
		return fields
	
	
	def player(self, which):
		if which:
			ftypePlayer = self.fplayer.readlines()
			ftypeOpponent = self.fopponent.readlines()
		else:
			ftypePlayer = self.fopponent.readlines()
			ftypeOpponent = self.fplayer.readlines()
		
		dplayer = {
						"hp"		:	int(ftypePlayer[0]),
						"shield"	:	int(ftypePlayer[1]),
						"red"		:	int(ftypePlayer[2]),
						"green"	:	int(ftypePlayer[3]),
						"yellow"	:	int(ftypePlayer[4]),
						"lilac"	:	int(ftypePlayer[5]),
					 }
		
		dopponent = {
						"hp"		:	int(ftypeOpponent[0]),
						"shield"	:	int(ftypeOpponent[1]),
						"red"		:	int(ftypeOpponent[2]),
						"green"	:	int(ftypeOpponent[3]),
						"yellow"	:	int(ftypeOpponent[4]),
						"lilac"	:	int(ftypeOpponent[5]),
					 }
		
		return dplayer, dopponent
