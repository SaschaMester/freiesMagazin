// *************************************************************************
// freiesMagazin-Programmierwettbewerb (ai)
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Erweitert von Werner Ziegelwanger <werner@ziaglw.at>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

// System
///////////
#include <iostream>
#include <fstream>
#include <vector>

// Own
//////////////
#include "gamefield.h"
#include "fieldpos.h"

// standard constructor
// initialize game field
GameField::GameField(void)
{
    // nothing to do
}

// Copy constructor
GameField::GameField(const GameField& field)
{
    for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
    {
        for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
        {
            m_field[i][j] = field.m_field[i][j];
        }
    }
}

// destructor
GameField::~GameField(void)
{
    // nothing to do
}

// copy game field
void GameField::set(const GameField& field)
{
    for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
    {
        for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
        {
            m_field[i][j] = field.m_field[i][j];
        }
    }
}

// opens file and reads the first 100 relevant characters
// newline, cr, spaces and tabs will be ignored
// return true if everything is ok
const bool GameField::read(const std::string& filename)
{
    bool ok = false;

    if ( !filename.empty() )
    {
        // open file for writing
        std::ifstream infile( filename.c_str() );

        if ( NULL != infile )
        {
            unsigned int i = 0;
            unsigned int j = 0;

            while ( infile.good() && j < FIELD_HEIGHT )
            {
                if ( i >= FIELD_WIDTH )
                {
                    i = 0;
                    j++;
                }

                // read character
                char c = 0;
                infile.get(c);
                // std::cout << c;

                switch ( (Tile::TileType)c )
                {
                    case Tile::TILE_RED:
                    case Tile::TILE_GREEN:
                    case Tile::TILE_YELLOW:
                    case Tile::TILE_SHIELD:
                    case Tile::TILE_LILAC:
                    case Tile::TILE_BOMB_1:
                    case Tile::TILE_BOMB_2:
                    case Tile::TILE_BOMB_3:
                    case Tile::TILE_BOMB_4:
                    case Tile::TILE_BOMB_5:
                        // store tile
                        m_field[i][FIELD_HEIGHT-j-1].set( (Tile::TileType)c );
                        i++;
                        break;
                    default:
                      // ignore everything else
                      break;
                }
            }

            // check if whole field was loaded
            if ( ( 0 != i ) || ( FIELD_HEIGHT != j ) )
            {
                std::cout << "GameField::read() error: game field was not loaded completely" << std::endl;
            }
            else
            {
                ok = true;
            }

            // close file
            infile.close();
        }
        else
        {
            std::cout << "GameField::read() error: file could not be opened" << std::endl;
        }
    }
    else
    {
        std::cout << "GameField::read() error: string is empty" << std::endl;
    }

    if (ok)
    {
        // print();
    }

    return ok;
}

// prints the game field on screen
void GameField::print(void) const
{
    for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
    {
        for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
        {
            // initialize with zeros
            std::cout << (char)m_field[i][FIELD_HEIGHT-j-1].getType() << " ";
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;
}

// calculate next move for this player
// and write result to file
const bool GameField::calculate(const Player& player, const Player& opponent, const std::string& filename) const
{
	bool ok = false;

	int array[20][5]={0};	//speichert bis zu 20 Z�ge (Pos1, Pos2, Schaden f�r Gegner)
	int count=0;		//anzahl der gespeicherten Z�ge

	//errechne alle m�glichen Z�ge
	for ( unsigned int i = 0; i < FIELD_WIDTH-1; i++ )
    	{
       		for ( unsigned int j = 0; j < FIELD_HEIGHT-1; j++ )
        	{
			FieldPos tempPos1(i,j);
            FieldPos tempPos2(i,j+1);

			if(checkSwapPosition(tempPos1,tempPos2))
			{
				if(count<20){
					array[count][0]=i;
					array[count][1]=j;
					array[count][2]=i;
					array[count][3]=j+1;
					array[count][4]=getDamage(tempPos1,tempPos2);
					count++;
				}
			}

			tempPos1.set(i,j);
            tempPos2.set(i+1,j);

			if(checkSwapPosition(tempPos1,tempPos2))
			{
				if(count<20){
					array[count][0]=i;
					array[count][1]=j;
					array[count][2]=i+1;
					array[count][3]=j;
					array[count][4]=getDamage(tempPos1,tempPos2);
					count++;
				}
			}
		}
	}

	//bewerte die Z�ge und f�hre den besten aus
	//mit Bubblesort sortieren!
	for(int i=1; i<20; i++)
	{
		for(int j=0; j<20-i; j++)
		{
			if(array[j][4]<array[j+1][4])
			{
				int temp=0;

                for(int k=0; k<5; k++)
                {
                    temp=array[j][k];
                    array[j][k]=array[j+1][k];
                    array[j+1][k]=temp;
                }
			}
		}
	}

	//tauschen
	FieldPos pos1(array[0][0], array[0][1]);
	FieldPos pos2(array[0][2], array[0][3]);

	if( writePositions(pos1, pos2, filename))
	{
		ok = true;
	}

	return ok;
}

//Berechnet einen Wert der angiebt, wie sinnvoll der Zug war
//Berechnet den Wert auch von der 2. Instanz
const int GameField::getDamage(FieldPos pos1, FieldPos pos2) const
{
	int ret=0;

	GameField tempField(*this);

	if(tempField.swapTiles(pos1, pos2))
	{
        //berechnet der Schaden der entfallenen Reihe
		ret=tempField.findSameTilesDamage();
	}

    //F�hrt die �nderung am Feld vor
    //addiert den Schaden der in 2., 3., 4... Instanz hinzukommt
	ret+=tempField.findSameTiles1();

	return ret;
}

const int GameField::findSameTilesDamage(void) const
{
    int ret = 0;

    ret += findSameTilesDamageInColumns();
    ret += findSameTilesDamageInRows();

    return ret;
}

const int GameField::findSameTilesDamageInRows(void) const
{
    int ret = 0;

    // now go through each row
    for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
    {
        // reset length
        unsigned int length = 0;
	int damage = 0;

        for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
        {
	    damage+=getDamageOfTile(m_field[i][j]);

            if ( 0 == i || m_field[i][j] == m_field[i-1][j] )
            {
                // same tile as before or new start tile
                length++;

                // if the last tile in this column
                // we must check the length
                if ( ( FIELD_WIDTH-1 == i ) && ( length >= 3 ) )
                {
                    ret += damage;
                }
            }
            else
            {
                // new tile here
                if ( length >= 3 )
                {
                    ret += damage;
                }

                // set new length
                length = 1;
		damage=0;
            }
        }
    }

    return ret;
}

// search for equal tiles in columns
// return true if something has been found
const int GameField::findSameTilesDamageInColumns(void) const
{
    int ret = 0;

    // we will go through each column
    for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
    {
        // reset length
        unsigned int length = 0;
	int damage=0;

        for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
        {
	    damage+=getDamageOfTile(m_field[i][j]);

            if ( 0 == j || m_field[i][j] == m_field[i][j-1] )
            {
                // same tile as before or new start tile
                length++;

                // if the last tile in this column
                // we must check the length
                if ( ( FIELD_HEIGHT-1 == j ) && ( length >= 3 ) )
                {
                    ret+=damage;
                }
            }
            else
            {
                // new tile here
                if ( length >= 3 )
                {
                    ret+=damage;
                }

                // set new length
                length = 1;
		damage=0;
            }
        }
    }

    return ret;
}

const int GameField::getDamageOfTile(Tile t) const
{
	Tile::TileType typ=t.getType();

	if(typ==Tile::TILE_BOMB_1)	return 11;
	if(typ==Tile::TILE_BOMB_2)	return 12;
	if(typ==Tile::TILE_BOMB_3)	return 13;
	if(typ==Tile::TILE_BOMB_4)	return 14;
	if(typ==Tile::TILE_BOMB_5)	return 15;
	if(typ==Tile::TILE_RED)		return 5;
	if(typ==Tile::TILE_SHIELD) 	return 4;
	if(typ==Tile::TILE_YELLOW)	return 3;
	if(typ==Tile::TILE_GREEN)	return 2;
	if(typ==Tile::TILE_LILAC)	return 1;

	return 0;
}

// search "good" tile on game field that should be swapped
// return true if position could be found
const bool GameField::findSwapPositions(FieldPos& pos1, FieldPos& pos2) const
{
    bool found = false;

    // we go through each column and row and swap single elements
    for ( unsigned int i = 0; i < FIELD_WIDTH-1; i++ )
    {
        for ( unsigned int j = 0; j < FIELD_HEIGHT-1; j++ )
        {
            // set positions for swapping
            FieldPos tempPos1(i,j);
            FieldPos tempPos2(i,j+1);

            // swap tiles at positions and check if there
            // are same tiles connected
            if ( checkSwapPosition(tempPos1,tempPos2) )
            {
                found = true;

                // copy swap position
                pos1 = tempPos1;
                pos2 = tempPos2;

                // leave for-loop
                break;
            }

            // set positions for swapping
            tempPos1.set(i,j);
            tempPos2.set(i+1,j);

            // swap tiles at positions and check if there
            // are same tiles connected now
            if ( checkSwapPosition(tempPos1,tempPos2) )
            {
                found = true;

                // copy swap position
                pos1 = tempPos1;
                pos2 = tempPos2;

                // leave for-loop
                break;
            }
        }

        if (found)
        {
            // leave for-loop
            break;
        }
    }

    return found;
}

// swap tiles at positions and check if there are same tiles connected
// return true if position could be found
const bool GameField::checkSwapPosition(FieldPos& pos1, FieldPos& pos2) const
{
    bool found = false;

    // copy game field
    GameField tempField(*this);

    // swap tiles
    if ( tempField.swapTiles(pos1,pos2) )
    {
        // check if there are some same tiles
        if ( tempField.findSameTiles() )
        {
            found = true;
        }
    }

    return found;
}

// return const reference for tile
const Tile& GameField::getTile(const FieldPos& pos) const
{
    if ( ( pos.x() >= FIELD_WIDTH ) || ( pos.y() >= FIELD_HEIGHT ) )
    {
        std::cout << "GameField::getTile() access out of boundaries" << std::endl;
        return m_dummyTile;
    }
    else
    {
        return m_field[pos.x()][pos.y()];
    }
}

// return reference for tile
Tile& GameField::getTile(const FieldPos& pos)
{
    if ( ( pos.x() >= FIELD_WIDTH ) || ( pos.y() >= FIELD_HEIGHT ) )
    {
        std::cout << "GameField::getTile() access out of boundaries" << std::endl;
        return m_dummyTile;
    }
    else
    {
        return m_field[pos.x()][pos.y()];
    }
}

// tries to swap two tiles
// return true if possible
const bool GameField::swapTiles(const FieldPos& pos1, const FieldPos& pos2)
{
    bool possible = false;

    // check if two fields are inside array boundaries
    if ( pos1.x() < FIELD_WIDTH && pos1.y() < FIELD_HEIGHT &&
         pos2.x() < FIELD_WIDTH && pos2.y() < FIELD_HEIGHT )
    {
        // check if next to each other
        if ( ( (pos1.x() == pos2.x()) && ((pos1.y() == pos2.y()+1 || pos1.y()+1 == pos2.y())) ) ||
             ( (pos1.y() == pos2.y()) && ((pos1.x() == pos2.x()+1 || pos1.x()+1 == pos2.x())) ) )
        {
            // swap tiles
            getTile(pos1).swap( getTile(pos2) );
            possible = true;
        }
        else
        {
            std::cout << "GameField::swapTiles() error: tiles not next to each other"
                      << std::endl;
        }
    }
    else
    {
        std::cout << "GameField::swapTiles() error: pos out of boundaries"
                  << std::endl;
    }

    return possible;
}

// search for equal tiles
// return true if something has been found
const bool GameField::findSameTiles(void) const
{
    bool found = false;

    if ( findSameTilesInColumns() )
    {
        found = true;
    }

    if ( findSameTilesInRows() )
    {
        found = true;
    }

    return found;
}

// search for equal tiles in rows
// return true if something has been found
const bool GameField::findSameTilesInRows(void) const
{
    bool found = false;

    // now go through each row
    for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
    {
        // reset length
        unsigned int length = 0;

        for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
        {
            if ( 0 == i || m_field[i][j] == m_field[i-1][j] )
            {
                // same tile as before or new start tile
                length++;

                // if the last tile in this column
                // we must check the length
                if ( ( FIELD_WIDTH-1 == i ) && ( length >= 3 ) )
                {
                    found = true;
                }
            }
            else
            {
                // new tile here
                if ( length >= 3 )
                {
                    found = true;
                }

                // set new length
                length = 1;
            }
        }
    }

    return found;
}

// search for equal tiles in columns
// return true if something has been found
const bool GameField::findSameTilesInColumns(void) const
{
    bool found = false;

    // we will go through each column
    for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
    {
        // reset length
        unsigned int length = 0;

        for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
        {
            if ( 0 == j || m_field[i][j] == m_field[i][j-1] )
            {
                // same tile as before or new start tile
                length++;

                // if the last tile in this column
                // we must check the length
                if ( ( FIELD_HEIGHT-1 == j ) && ( length >= 3 ) )
                {
                    found = true;
                }
            }
            else
            {
                // new tile here
                if ( length >= 3 )
                {
                    found = true;
                }

                // set new length
                length = 1;
            }
        }
    }

    return found;
}

// store positions in file
// return true if everything is ok
const bool GameField::writePositions(const FieldPos& pos1, const FieldPos&pos2, const std::string filename) const
{
    bool ok = false;

    if ( !filename.empty() )
    {
        // open file for writing
        std::ofstream outfile( filename.c_str() );

        if ( outfile.good() )
        {
            // write positions into file
            outfile << pos1.x() << " "
                    << pos1.y() << " "
                    << pos2.x() << " "
                    << pos2.y() << std::endl;

            // close file
            outfile.close();

            ok = true;
        }
        else
        {
            std::cout << "GameField::writePositions() error: file could not be opened" << std::endl;
        }
    }
    else
    {
        std::cout << "GameField::writePositions() error: string is empty" << std::endl;
    }

    return ok;
}

// search for equal tiles
// return true if something has been found
const int GameField::findSameTiles1() const
{
    int damage = 0;

    damage+=findSameTilesInColumns1();
    damage+=findSameTilesInRows1();

    return damage;
}

// search for equal tiles in rows
// return true if something has been found
const int GameField::findSameTilesInRows1() const
{
    int ret = 0;

    // now go through each row
    for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
    {
        // reset length
        unsigned int length = 0;
        int damage=0;

        for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
        {
            damage+=getDamageOfTile(m_field[i][j]);

            if ( 0 == i || m_field[i][j] == m_field[i-1][j] )
            {
                // same tile as before or new start tile
                length++;

                // if the last tile in this column
                // we must check the length
                if ( FIELD_WIDTH-1 == i && length >= 3 )
                {
                    // only store tiles if length is >= 3
                    ret+=damage;
                }
            }
            else
            {
                // new tile here
                if ( length >= 3 )
                {
                    ret+=damage;
                }

                // set new length
                length = 1;
                damage=0;
            }
        }
    } // for FIELD_HEIGHT

    return ret;
}

// search for equal tiles in columns
// return true if something has been found
const int GameField::findSameTilesInColumns1() const
{
    int ret = 0;

    // we will go through each column
    for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
    {
        // reset length
        unsigned int length = 0;
        int damage = 0;

        for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
        {
            damage += getDamageOfTile(m_field[i][j]);

            if ( 0 == j || m_field[i][j] == m_field[i][j-1] )
            {
                // same tile as before or new start tile
                length++;
                // if the last tile in this column
                // we must check the length
                if ( FIELD_HEIGHT-1 == j && length >= 3 )
                {

                    ret+=damage;
                }
            }
            else
            {
                // new tile here
                if ( length >= 3 )
                {
                    ret+=damage;
                }

                // set new length
                length = 1;
                damage=0;
            }
        }
    }

    return ret;
}


// let all existing tiles fall to the ground
const bool GameField::fallTilesToGround(const bool contest)
{
    bool ok = true;

    // user special height in contest
    const unsigned int height = (contest) ? FIELD_EXTRA_HEIGHT : FIELD_HEIGHT;

    // let all existing tiles fall to the ground
    for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
    {
        // position in each column of tile to fill
        unsigned int fill = 0;

        for ( unsigned int j = 0; j < height; j++ )
        {
            if ( !m_field[i][j].isEmpty() )
            {
                if ( fill != j )
                {
                    m_field[i][fill] = m_field[i][j];
                }
                fill++;
            }
        }

        // no more tiles available for contest
        if ( contest && ( fill < 10 ) )
        {
            std::cout << "GameField::fallTilesToGround() error: no more tiles for contest"
                      << " in column " << i << std::endl;

            ok = false;
            // getchar();
        }

        // fill rest of column with zeros
        for ( unsigned int j = fill; j < height; j++ )
        {
            m_field[i][j].setEmpty();
        }
    }

    return ok;
}
