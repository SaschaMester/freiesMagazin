'''
Copyright 2009, Marcus Kroschinsky.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY MARCUS KROSCHINSKY "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL MARCUS KROSCHINSKY OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Marcus Kroschinsky.
'''


from PlayerStats import *
import copy
import math

#
# Value Calculator is used to determine how much a given set of color fields
# is worth, validating against opponents and players given statistics
#
class ValueCalculator():
  __Cnt={}

  def __init__(self, p, o):
    self.p = PlayerStats()
    self.o = PlayerStats()

    self.p = copy.deepcopy(p)
    self.o = copy.deepcopy(o)

    self.__resetInternals()

  # get sum value of colors given in List
  def getValue(self, colorList):
    self.__resetInternals()

    # count all our colors
    for color in colorList:
      if ( color == '1'
        or color == '2'
        or color == '3'
        or color == '4'
        or color == '5'
      ):
        # bombs are special
        self.__Cnt['*'] += int(color)
      else:
        if self.__Cnt.has_key(color):
          self.__Cnt[color] += 1
        else:
          print "Error in ValueCalculator(getValue) - Unknown color '%s'" % (color)

    # fetch value for each color count
    value = 0
    for key in self.__Cnt:
      value += self.__getValue(key, self.__Cnt[key])


    # maybe this move is a killing stroke
    # ( -> Increase value )
    if self.__isKill( self.__DmgDealt ):
      self.OppKilled = True
      value += 100000
    else:
      # for each damage done, add 1 bonus points to move
      # TWEAK POINT - DAMAGE
      value += self.__DmgDealt

      # for each direct damage done, add additional 1 bonus points to move
      # TWEAK POINT - DIRECT DAMAGE
      value += (self.__DmgDealt-self.o.getShield())

    return value


  # fetch player stats modified by previous inputs
  def getModifiedPlayer(self):
    # create new object to omit reference
    p = PlayerStats()
    p = copy.deepcopy( self.p )

    p.addShield( self.__Cnt['B'] )
    p.addRed(    self.__Cnt['R'] )
    p.addYellow( self.__Cnt['Y'] )
    p.addGreen(  self.__Cnt['G'] )
    p.addLilac(  self.__Cnt['L'] )

    return p

  # fetch opponent stats modified by previous inputs
  def getModifiedOpponent(self):
    # create new object to omit reference
    o = PlayerStats()
    o = copy.deepcopy( self.o )

    o.addDamage(self.__DmgDealt)

    return o



  # for value calculation of lists, we need counters for each color and flags
  # saving special conditions achieved
  def __resetInternals(self):
    self.__Cnt['L'] = 0
    self.__Cnt['B'] = 0
    self.__Cnt['R'] = 0
    self.__Cnt['Y'] = 0
    self.__Cnt['G'] = 0
    self.__Cnt['*'] = 0
    self.__Cnt['?'] = 0
    self.__Cnt['-'] = 0

    self.__DmgDealt = 0
    self.ExtraTurn = False
    self.OppKilled = False


  # get value of each color against count
  def __getValue(self, color, cnt=1):
    value = 0
    
    if   color == 'B':  value = self.__blue(cnt)
    elif color == 'G':  value = self.__green(cnt)
    elif color == 'Y':  value = self.__yellow(cnt)
    elif color == 'R':  value = self.__red(cnt)
    elif color == 'L':  value = self.__lilac(cnt)
    elif color == '*':  value = self.__bombs(cnt)
    elif color == '?':
      # unknown (new grid generated)
      value = 0
    elif color == '-':
      # outOfBounds grid
      value = 0
    else:
      print "Error in ValueCalculator(__getValue) - Unknown color '%s'" % (color)

    return value


  def __bombs(self, cnt):
    self.__DmgDealt += cnt
    return cnt * 15


  def __green(self, cnt=1):
    depot=0
    # 15 accumulated points result in damage
    if (self.p.getGreen() + cnt) >= 15:
      # using accumulated points means a slight malus
      depot=-6
      # It's not likely, but maybe we get a count of 30 within ONE turn !!!
      # E.g. possible by having 14 accumulated points and a cascade of 16
      # Imagine this grid:
      #                    . . G . .
      #                    . . G . .
      #                    . . . . .
      #                    . . G . .
      #                    G G x G .
      #                    . G x G G
      #                    . . . x .
      #                    G G x G G
      #
      # THAT's INCREDIBLE 14 G AND 4 X JUST BY MOVING ONE TILE !!!
      # AND IT'S ROOM FOR MORE !!!
      # Yeah, I know, not very likely... But this BOT should analyze as many
      # moves as possible. So a count of more than 30 is recognized.
      # (NOTE: actually, all fields used crosswise will count twice, creating
      # a whoping 17 G and 4 X in the example above. This is due to the game
      # framework of FreiesMagazin.de )
      #
      # How many times do we achieve 15 colors of one type?
      n = math.floor( (self.p.getGreen()+cnt)/15 )
      if n > 1:
        print "MEGA-MOVE G DETECTED!" # this does not mean we take a bad choice!
      
      self.__DmgDealt += n*3

    return cnt * 3 + depot


  def __yellow(self, cnt=1):
    depot=0
    if (self.p.getYellow() + cnt) >= 15:
      # using accumulated points means a slight malus
      depot=-12
      # How many times do we achieve 15 colors? ...for more docu see @ __green()
      n = math.floor( (self.p.getYellow()+cnt)/15 )
      if n > 1:
        print "MEGA-MOVE Y DETECTED!" # won't take it, if still a bad choice

      self.__DmgDealt += n*6

    return cnt * 6 + depot


  def __red(self, cnt=1):
    depot=0
    if (self.p.getRed() + cnt) >= 15:
      # using accumulated points means a slight malus
      depot=-20
      # How many times do we achieve 15 colors? ...for more docu see @ __green()
      n = math.floor( (self.p.getRed()+cnt)/15 )
      if n > 1:
        print "MEGA-MOVE R DETECTED!" # won't take it, if still a bad choice

      self.__DmgDealt += n*10

    return cnt * 10 + depot


  def __lilac(self, cnt=1):
    lilac = self.p.getLilac()

    if lilac + cnt >= 15:
      self.ExtraTurn = True

    # TWEAK POINT - EXTRATURN
    # TWEAK POINT - MEGA MOVE implementation? (see description green)
    value = 0
    if   lilac < 6:  value = 2
    elif lilac < 9:  value = 4
    else:            value = 6

    return cnt * value


  def __blue(self, cnt=1):
    # TWEAK POINT - SHIELDS
    p = self.p.getShield()
    o = self.o.getShield()

    value=(45-(o + 3*p))
    if value < 0:  value = 0
    if value > 20: value = 20

    # Set a cap for max shield strength
    if cnt > 15-p:
      cnt = 15-p

    return cnt * value


  # used to increase value of attack if it's a death blow
  def __isKill(self, dmg):
    health = self.o.getHealth()
    shield = self.o.getShield()

    if dmg >= (health + shield):
      return True
    else:
      return False


