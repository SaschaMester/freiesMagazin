'''
Copyright 2009, Marcus Kroschinsky.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY MARCUS KROSCHINSKY "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL MARCUS KROSCHINSKY OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Marcus Kroschinsky.
'''

from os import path

class PlayerStats():
  stats = { 'health':0,
            'shield':0,
            'red':0,
            'yellow':0,
            'green':0,
            'lilac':0
          }


  def __init__(self, file=""):
    if file != "":
      self.readFile(file)

  # load a file
  def readFile(self, file):
    if path.isfile(file):
      f = open(file, "r")
      content = f.read().strip()
      f.close()

      content = content.split('\n')
      if len(content) == 6:
        self.stats={ 'health' : int(content[0]),
                     'shield' : int(content[1]),
                     'red'    : int(content[2]),
                     'yellow' : int(content[3]),
                     'green'  : int(content[4]),
                     'lilac'  : int(content[5])
                   }
      else:
        print "Player file '%s' corrupt!"%(file)
    else:
      print "Player file '%s' not found!"%(file)

  # echo a short overview for your player stats
  def printStats(self):
    for key in self.stats:
      print "%10s: %d" % (key, self.stats[key])

  # well, the usual Getters
  def getHealth(self):      return self.stats['health']
  def getShield(self):      return self.stats['shield']
  def getGreen(self):       return self.stats['green']
  def getYellow(self):      return self.stats['yellow']
  def getRed(self):         return self.stats['red']
  def getLilac(self):       return self.stats['lilac']

  # shields are capped
  def setShield(self,value):
    if   value > 15:  self.stats['shield'] = 15
    elif value < 0:   self.stats['shield'] = 0
    else:             self.stats['shield'] = value

  # health is also capped, but should only drop down to zero
  def setHealth(self,value):
    if   value > 30:  self.stats['health'] = 30
    elif value < 0:   self.stats['health'] = 0
    else:             self.stats['health'] = value

  # except 'Blue' all other colors go up to 14 and then restart at 0
  def setGreen(self,value):   self.stats['green']  = value % 15
  def setYellow(self,value):  self.stats['yellow'] = value % 15
  def setRed(self,value):     self.stats['red']    = value % 15
  def setLilac(self,value):   self.stats['lilac']  = value % 15

  # recalculate damage related player stats
  def addDamage(self,dmg):
    s = self.getShield()
    h = self.getHealth()

    self.setShield(s-dmg)
    self.setHealth((h+s)-dmg)

  # after get, set, now some adds:
  # $ LOOKING FOR A GOOD ANIME, LOOK FOR GitS or Death Note! $
  # (well, if you don't get this last two comment lines you won't like my humor)
  def addShield(self,shield):  self.setShield( self.getShield() + shield )
  def addGreen( self, value):  self.setGreen(  self.getGreen()  + value )
  def addYellow(self, value):  self.setYellow( self.getYellow() + value )
  def addRed(   self, value):  self.setRed(    self.getRed()    + value )
  def addLilac( self, value):  self.setLilac(  self.getLilac()  + value )
