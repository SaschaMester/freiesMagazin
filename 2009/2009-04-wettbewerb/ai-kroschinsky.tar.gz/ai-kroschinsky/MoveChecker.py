'''
Copyright 2009, Marcus Kroschinsky.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY MARCUS KROSCHINSKY "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL MARCUS KROSCHINSKY OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Marcus Kroschinsky.
'''

from Point import *
from GameZone import *
from Move import *


class MoveChecker():
  gz  = []  # gamezone
  Moves  = []  # list of all viable move actions

  # cyclic moves performed with each field of gamezone
  cMoves  = [ (1,0),(0,1),(-1,0),(0,-1) ]
  
  # checks to perform after a cyclic move
  # Check 1 looks at the remaining 3 directions to form a line
  # (cloverleaf like)
  check01 = {
              (1,0 ) : ( (2,0),  (1,1),  (1,-1)),
              (-1,0) : ((-2,0), (-1,1), (-1,-1)),
              (0,1 ) : ( (1,1), (0, 2), (-1, 1)),
              (0,-1) : ( (1,-1),(0,-2), (-1,-1))
            }
  # check 2 looks for continuation of previous started line
  check02 = {
             (1,0,2, 0) : (3, 0),
             (1,0,1, 1) : (1, 2),
             (1,0,1,-1) : (1,-2),

             (-1,0,-2, 0) : (-3, 0),
             (-1,0,-1, 1) : (-1, 2),
             (-1,0,-1,-1) : (-1,-2),

             (0,1, 1,1) : ( 2,1),
             (0,1, 0,2) : ( 0,3),
             (0,1,-1,1) : (-2,1),

             (0,-1, 1,-1) : ( 2,-1),
             (0,-1, 0,-2) : ( 0,-3),
             (0,-1,-1,-1) : (-2,-1)
            }



  def __init__(self,gz):
    self.gz = gz
    self.analyze()

  def analyze(self):
    self.Moves=[]

    xCnt = self.gz.getWidth()
    yCnt = self.gz.getHeight()


    for x in range(xCnt):
      for y in range(yCnt):
          color = self.gz.getColor(x,y)
          pFrom = Point(x,y)

          for dx, dy in self.cMoves:
            mx = x+dx
            my = y+dy

            mColor = self.gz.getColor(mx,my)
            pTo = Point(mx,my)

            if not mColor == '-':
              #don't check if both grids have the same color
              if not color == mColor:
                self.addMove(pFrom,pTo)


    # remove mirrored moves ( from->to  vs.  to->from )
    # This will reduce multiple analysis of the same move later on
    for m1 in self.Moves:
      for m2 in self.Moves:
        if m1.isOppositeMove(m2):
          m1.mergeMove(m2)
          self.Moves.remove(m2)


  # check that move creates one (or more) lines with three or more points
  # append each valid move to attribute self.Moves (give insert position if you
  # want to add after analyse was made)
  def addMove(self,pFrom,pTo,pos=-1):
    coords = []

    x = pFrom.X
    y = pFrom.Y
    xTo= pTo.X
    yTo= pTo.Y

    dx = xTo-x
    dy = yTo-y

    col = self.gz.getColor(x,y)
    if col != '?':
      coords.append((xTo,yTo))
      for x01,y01 in self.check01[(dx,dy)]:
        col01 = self.gz.getColor(x+x01,y+y01)
        if col == col01 and col01 != '?':
          coords.append((x+x01,y+y01))

          x02,y02 = self.check02[(dx,dy,x01,y01)]
          col02 = self.gz.getColor(x+x02,y+y02)
          if col == col02 and col02 != '?':
            coords.append((x+x02,y+y02))

    # now check how many coords have the same x or same y as our moved field
    if not coords == []:
      if len(coords) >2:
        xList = []
        yList = []
        total=[]
        for e1,e2 in coords:
          if xTo == e1:
            xList.append((e1,e2))
          if yTo == e2:
            yList.append((e1,e2))

        # all lines longer than 2 entries should be kept
        #
        # Note: This extend keeps double entries of cross positioned fields
        #       That's how the game framework implements it!
        #       We don't complain about this bonus field count.
        if len(xList) > 2:
          total.extend( set(xList) )
        if len(yList) > 2:
          total.extend( set(yList) )

        if not total == []:
          #print "%d,%d -> %d,%d: %s - %s"%(x,y,xTo,yTo,col,coords)
          self.Moves.insert(pos, Move(pFrom,pTo,total))
