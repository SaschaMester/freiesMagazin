'''
Copyright 2009, Marcus Kroschinsky.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY MARCUS KROSCHINSKY "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL MARCUS KROSCHINSKY OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Marcus Kroschinsky.
'''

from GameZone import *
from Move import *
from Point import *

class GameZoneChecker():
  deleted = []
  zone = []

  # move grid calculating list of resolved triplets and new gamezone
  def move(self, m, zone):
    gz = GameZone("")
    gz.setGameZone(zone)

    fromG = gz.zone[m.pFrom.X][m.pFrom.Y]
    toG   = gz.zone[m.pTo.X][m.pTo.Y]

    gz.zone[m.pFrom.X][m.pFrom.Y] = toG
    gz.zone[m.pTo.X][m.pTo.Y] = fromG

    #self.checkWithWildcards(gz, m.pList)
    self.check(gz, m.pList)



  # analyze given gamezone, remove grid triplets (or longer) until no triplets
  # exist. A list of all gridColors removed this way will be created, as well
  # as the resulting zone. A predefined gridList can be given to be removed
  # first (e.g. MoveChecker creates a list with affected/deleteable grids for
  # all plausible moves)
  def check(self, gz, gList=[] ):
    gC = [] # grid color list

    # first clear gamezone of known grids
    if gList != []:
      for x, y in gList:
        gC.append(gz.zone[x][y])

      gz.removeGrids(gList)

    # now search for new grid triplets and clear them until no further triplet
    # exists
    while True:
      grids = []
      for entry in self.checkRows(gz):
        grids.append( entry )
      for entry in self.checkCols(gz):
        grids.append( entry )

      # no further triplet grids were created through dropdown (=> stop)
      if grids == []:
        break

      for x, y in grids:
        gC.append( gz.zone[x][y] )    # get direct values of gamefield

      gz.removeGrids(grids)

    # save color list of deletes as well as resulting gamezone
    self.deleted = gC
    self.zone = gz



  # search through each column and return grid coordinates to delete
  def checkCols(self, gz):
    grids = []

    for x in range( gz.getWidth() ):
      color = '-'
      idx = -1
      for y in range( gz.getHeight() ):
        if color != gz.getColor(x, y):
          color = gz.getColor(x, y)
          idx = y
        else:
          if color != '?':
            if (y-idx) > 1:
              for n in range(y-idx + 1):
                grids.append((x, idx + n))

    return set(grids)

  # search through each row and return grid coordinates to delete
  def checkRows(self, gz):
    grids = []

    for y in range( gz.getHeight() ):
      color = '-'
      idx = -1
      for x in range( gz.getWidth() ):
        if color != gz.getColor(x, y):
          color = gz.getColor(x, y)
          idx = x
        else:
          if color != '?':
            if (x-idx) > 1:
              for n in range(x-idx + 1):
                grids.append((idx + n, y))

    return set(grids)


  # fetch list of all colors deleted by last move action
  def LastDeleted(self):
    return self.deleted

  # fetch gamezone created through last move action (may contain '?' fields!)
  def LastGameZone(self):
    return self.zone

