'''
Copyright 2009, Marcus Kroschinsky.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY MARCUS KROSCHINSKY "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL MARCUS KROSCHINSKY OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Marcus Kroschinsky.
'''

from Point import *


# Stores Information about a single moving action, including all affected grids
class Move():
  pFrom = Point()
  pTo = Point()
  pList = []
  value = -999999
  avg   = -999999
  max   = -999999
  avgNext = -999999
  maxNext = -999999

  #   p1    : position to come from
  #   p2    : position to go
  #   val   : associated value of moving action
  #   pList : list of all directly affected positions
  #   value : this moves caculated worth
  def __init__(self, p1=Point(-1, -1), p2=Point(-1, -1), pList=[], value=-999999):
    self.pFrom = p1
    self.pTo   = p2
    self.pList = pList
    self.value = value


  def printMove(self, str=""):
    if str != "":
      print str

    # print all, but don't bother about defaults
    if self.avgNext != -999999 and self.maxNext != -999999:
      # so this move already got information about next move(s)
      print "%d,%d->%d,%d: VAL=%5d NEXT(avg=%5d max=%5d)" % (
        self.pFrom.X,
        self.pFrom.Y,
        self.pTo.X,
        self.pTo.Y,
        self.value,
        self.avgNext,
        self.maxNext
      )
    else:
      # here we go with a move which don't know about following turns
      print "%d,%d->%d,%d: VAL=%5d" % (
        self.pFrom.X,
        self.pFrom.Y,
        self.pTo.X,
        self.pTo.Y,
        self.value
      )


  # check that move m is inverted move action
  def isOppositeMove(self, m):
    if ( self.pFrom.isEqual(m.pTo)
      and self.pTo.isEqual(m.pFrom)
    ):
      return True
    else:
      return False


  # It's possible that one moving action affects two colors, so we merge those
  # actions
  def mergeMove(self, m):
    if self.isOppositeMove(m):
      for entry in m.pList:
        self.pList.append(entry)
      return True
    else:
      return False

  # check move(self) value is greater than other move(m)
  def isBetter(self, m):
    result = False
    if self.value > m.value:
      result = True
    elif self.value == m.value:
      # Same, so compare their following turns average
      # (must be lower, since this turn is for your opponent)
      if self.avgNext < m.avgNext:
        result = True
      elif self.avgNext == m.avgNext:
        # Same too, then compare max values of next turn
        # (again, since this is your opponnents turn, compare to lower)
        if self.maxNext < m.maxNext:
          result = True

    return result

  # Submit move to game controller (write it into file)
  def saveMove(self, file="./result.dat"):
    # prepare move format
    str = "%d %d %d %d" % ( self.pFrom.X,
      self.pFrom.Y,
      self.pTo.X,
      self.pTo.Y
    )

    f = open(file, "w+")
    f.write(str)
    f.close()
