'''
Copyright 2009, Marcus Kroschinsky.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY MARCUS KROSCHINSKY "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL MARCUS KROSCHINSKY OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Marcus Kroschinsky.
'''

import time
import copy

from GameZoneChecker import *
from MoveChecker import *
from GameZone import *
from PlayerStats import *
from ValueCalculator import *

DEBUG = False

def main():
  startTime = time.time()
  BotName = "FINIS"

  # TODO: accept directory as parameter... but this will do until then
  dir = "./"
  fplayer = dir + "/player.dat"
  fopp    = dir + "/opponent.dat"
  fgz     = dir + "/gamefield.dat"
  fresult = dir + "/result.dat"

  # read player/opponent data and gamefield
  player = PlayerStats(fplayer)
  opp    = PlayerStats(fopp)
  gz     = GameZone(fgz)

  # start evaluation of given files data
  bestMove = getBestMove(gz,player,opp)
  bestMove.saveMove(fresult)

  if DEBUG:
    bestMove.printMove("BEST MOVE")
    if bestMove.value < -90000:
      print "PANIC!"

  endTime = time.time()
  if DEBUG:
    print "%s - Execution Time: %lf" %(BotName, endTime-startTime)


#
# Get highest valued tile swap
#
# Parameters:
#   gz       - GameZone object, holding a gamefield matrix
#   player   - PlayerStats object for this bots information
#   Opponent - PlayerStats object for this bots opponent
#
# Returns:
#   bestMove - a Move object, holding coordinates, values and affected tiles
#
# Description:
#   Determine all possible moves in given gamefield. Calculate values for each
#   move depending on actual player and opponent settings. Finally, return a
#   move object with greatest calculated value.
#
#   Basically, each single move value is based on player's turn MINUS BEST
#   opponents follow up turn, so that's a lot to calculate! Some skipping logic
#   and special conditions (e.g. player has ExtraTurn) are checked, but these
#   are either too numerous or constantly changing in the current state of work.
#   So please look them up directly in the following function.
#
def getBestMove(gz, player, opp):
  jumpMoves = []                     # list to remember moves, which already
                                     # skipped one deep analysis
  vcp = ValueCalculator(player, opp) # value calculator for player
  gc = GameZoneChecker()             # used to generate/validate gamezones
  bestMove = Move()                  # at this moment, that is our best Move

  # get all possible, successful moves for player
  playerMoves = MoveChecker(gz).Moves

  # Loop through all given Moves, calculating their value
  for m in playerMoves:
    #
    # Simply make each move and generate new gemfield and player stats
    #
    gc.move(m,gz)

    #
    # calculate value of players move by getting all dissolved tiles
    #
    delColors  = gc.LastDeleted()
    m.value = vcp.getValue( delColors )

    # First turn killing the opponent is considered "Best Move"
    if vcp.OppKilled:
      if DEBUG:
        print "Death Stroke!"
      bestMove = m
      break
    else:
      #
      # get modified player/opponent stats for next turn
      #
      gz2 = gc.LastGameZone()

      p2 = PlayerStats()
      o2 = PlayerStats()

      p2 = copy.deepcopy( vcp.getModifiedPlayer() )
      o2 = copy.deepcopy( vcp.getModifiedOpponent() )

      # calculate value(s) of following Move
      mc = MoveChecker(gz2)

      # insert "shortcuts" at beginning of checklist
      for j in jumpMoves:
        mc.addMove(j.pFrom,j.pTo,0)

      nextMoves = mc.Moves
      for n in nextMoves:
        gc.move(n,gz2)

        remColors  = gc.LastDeleted()
        gz3        = gc.LastGameZone()

        # calculate value of next move
        # distinguish between players (extra turn) and opponents turn

        # initialize new value Calculator
        if vcp.ExtraTurn:
          vcn = ValueCalculator( p2, o2 )
        else:
          vcn = ValueCalculator( o2, p2 )

        n.value = vcn.getValue(remColors)

        # Improve computation time
        if not vcp.ExtraTurn:
          if (m.value - n.value) < bestMove.value:
            # Don't bother about analysing further moves of this opponent
            # szenario. We already got a better result waiting outside.
            if n not in jumpMoves:
              # Remember this move, so we can validate follow up turns earlier!
              jumpMoves.append(n)
            break
        


      # cycle through next moves, get max valued and mean value of all
      maxNextValue = 0
      meanNextValue = 0
      for n in nextMoves:
        if n.value > maxNextValue:
          maxNextValue = n.value
        meanNextValue += n.value
      if len(nextMoves) != 0:
        meanNextValue /= len(nextMoves)

      if vcp.ExtraTurn:
        # extra turns only get the mean value of next turn added
        m.value += meanNextValue
        # save avg and max value of next Move, but invert values to show
        # routine bestMove the next "opponent" move is really really bad
        m.avgNext = -1 * meanNextValue
        m.maxNext = -1 * maxNextValue
      else:
        # Opponent is always worst case, so reduce value of playerMove
        # with the best value of next Move
        m.value -= maxNextValue
        # save avg and max value of next Move
        m.avgNext = meanNextValue
        m.maxNext = maxNextValue

    # search for best Move
    if not vcp.OppKilled:
      if DEBUG:
        m.printMove()
      if m.isBetter(bestMove):
        bestMove = m

  return bestMove


# just the start condition of this skript
if __name__ == "__main__":
  main()