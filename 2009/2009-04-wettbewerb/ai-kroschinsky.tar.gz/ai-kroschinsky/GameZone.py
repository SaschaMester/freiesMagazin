'''
Copyright 2009, Marcus Kroschinsky.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY MARCUS KROSCHINSKY "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL MARCUS KROSCHINSKY OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Marcus Kroschinsky.
'''

from os import path


# stores information about gamefield
class GameZone():
  # initialize gamezone with data file
  def __init__(self, file="./gamefield.dat"):
    if path.isfile(file):
      f = open(file, "r")
      content = f.read().strip()
      f.close()
      content = content.split('\n')

      # reformat file to matrix with indexes exactly like our coordinate system
      for i in range( len(content) ):
        content[i] = (content[i]).strip().split(' ')

      self.zone = []
      length = len(content)
      for i in range( length ):
        row = []
        for j in range( length ):
          row.append(content[length-j-1][i])
        self.zone.append(row)

    elif file == "":
      # gamezone is not based on file input
      # (mostly used to create temp. alternative gamezones for analysis)
      self.zone = []

    else:
      print "gameZone '" + file + "' couldn't be found!"


  # fill a new gamezone
  def setGameZone(self, gz):
    self.zone = []
    for row in gz.zone:
      z = []
      for col in row:
        z.append(col)
      self.zone.append(z)

  # x count of gamefield
  def getWidth(self):
    return len(self.zone[0])

  # y count of gamefield
  def getHeight(self):
    return len(self.zone)

  # check for gamefield violations
  def outOfBounds(self, x, y):
    if   x < 0:                  return True
    elif y < 0:                  return True
    elif x >= self.getWidth():   return True
    elif y >= self.getHeight():  return True
    else:                        return False

  # get color key of grid x,y
  def getColor(self, x, y):
    if self.outOfBounds(x, y):
      return '-'

    type = self.zone[x][y]

    if not(
         type == 'B'
      or type == 'G'
      or type == 'Y'
      or type == 'R'
      or type == 'L'
      or type == '?'
      or type == ' '
    ):
      #it's a bomb
      type = '*'
  
    return type


  # delete given grids, refill with grids located above erased ones
  def removeGrids(self, grids):

    # delete given grids
    for x,y in grids:
      self.zone[x][y] = ' '

    width  = self.getWidth()
    height = self.getHeight()
    
    # copy entries of each gamerow, except deleted ones
    for x in range( width ):
      row = []
      cnt = 0
      for y in range( height ):
        if self.zone[x][y] != ' ':
          row.append(self.zone[x][y])
        else:
          cnt+=1

      # fill up with unknown fields ('?')
      for i in range(cnt):
        row.append('?')

      # reset row in existing gamezone
      self.zone[x]= row


