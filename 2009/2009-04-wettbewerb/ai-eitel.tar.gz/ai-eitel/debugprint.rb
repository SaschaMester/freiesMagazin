=begin
rb-ai - KI for http://www.freiesmagazin.de/programmierwettbewerb

Copyright (C) 2009 Florian Eitel

This program is free software; you can redistribute it and/or modify it under the terms of the
GNU General Public License as published by the Free Software Foundation; either version 3 of
the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See
the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program;
if not, see <http://www.gnu.org/licenses/>.
=end

class DebugPrint
  # method is a symbol which represent a methodcall on all objects
  # possible values: :to_s or :to_html or :none
  def initialize method
    @method = method
  end

  # Called at start of programm
  def start
    return "" if @method == :none
    return "" if @method == :to_s
    if @method == :to_html
      return <<DOC 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <style type="text/css">
      .border { color: grey; }
      .important { color: red; }
      table { float: left; margin: 10px; }
      h2 { clear: both; }
    </style>
    <title>Turn</title>
  </head>
  <body>
DOC
    end
  end

  # Called at end of programm
  def stop
    return "" if @method == :none
    return "" if @method == :to_s
    if @method == :to_html
      return <<DOC
  </body>
</html>
DOC
    end
  end

  # returns the representation of the playervalues
  def player player, opponent
    return "" if @method == :none
    return "#{player.send @method}\n#{opponent.send @method}\n"
  end

  # returns the representation of the turn
  def turn turn
    return "" if @method == :none
    return turn.send @method
  end
end

