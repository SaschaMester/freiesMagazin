#!/usr/bin/env ruby 
=begin
rb-ai - KI for http://www.freiesmagazin.de/programmierwettbewerb

Copyright (C) 2009 Florian Eitel

This program is free software; you can redistribute it and/or modify it under the terms of the
GNU General Public License as published by the Free Software Foundation; either version 3 of
the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See
the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program;
if not, see <http://www.gnu.org/licenses/>.
=end

$LOAD_PATH << File.dirname(__FILE__)
require 'rubygems'
require 'player.rb'
require 'field.rb'
require 'turn.rb'
require 'rules.rb'
require 'debugprint.rb'

# loads all data from files
opponent = Player.new(File.open("../../opponent.dat").to_a)
player = Player.new(File.open("../../player.dat").to_a)
field = GameField.new(File.open("../../gamefield.dat").to_a)

# first argument contains debug output
# possible values:
# * to_s => String output
# * to_html => html output
if ARGV[0].nil?
  debug = DebugPrint.new :none
else
  debug = DebugPrint.new ARGV[0].to_sym
end

print debug.start
print debug.player player, opponent

possibilities = field.search_combos


# find best turn
bestTurn = possibilities.first
possibilities.each do |poss|
  poss.rate player, opponent
  print debug.turn poss 
  bestTurn = poss if poss.rating > bestTurn.rating
end

# write coordinates do file
File.open("../../result.dat",'w').puts "#{field.convert(bestTurn.stone).join " " } #{field.convert(bestTurn.stone + bestTurn.direction).join " " }" 

debug.stop

exit 0

