=begin
rb-ai - KI for http://www.freiesmagazin.de/programmierwettbewerb

Copyright (C) 2009 Florian Eitel

This program is free software; you can redistribute it and/or modify it under the terms of the
GNU General Public License as published by the Free Software Foundation; either version 3 of
the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See
the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program;
if not, see <http://www.gnu.org/licenses/>.
=end

# DataClass for both Players
class Player
  attr_reader :live, :shield, :red, :yellow, :green, :lila
  # initialize whith array of values from file
  def initialize values
    # remove whitespaces and newlines 
    @live, @shield, @red, @yellow, @green, @lila = values.map {|item| item.strip.to_i }
  end
  # returns respresentation as string
  def to_s
    result = ""
    # iterate over all instancevariables
    instance_variables.each do |var|
      result += "#{var}: #{instance_variable_get var}"
    end
    result
  end
  # returns respresentation as html
  def to_html
    result = "<table>"
    # iterate over all instancevariables
    instance_variables.each do |var|
      result += "<tr><td>#{var}</td><td>#{instance_variable_get var}</td>"
    end
    result += "</table>"
  end
end

