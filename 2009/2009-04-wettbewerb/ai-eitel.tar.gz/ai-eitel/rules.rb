=begin
rb-ai - KI for http://www.freiesmagazin.de/programmierwettbewerb

Copyright (C) 2009 Florian Eitel

This program is free software; you can redistribute it and/or modify it under the terms of the
GNU General Public License as published by the Free Software Foundation; either version 3 of
the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See
the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program;
if not, see <http://www.gnu.org/licenses/>.
=end

require File.expand_path(File.dirname(__FILE__) + '/' + 'rater.rb')

# define rules:
# Rules.define :description_of_rule do |player,opponent,stones| 
#   return a_number
# end
#
# All return values are summarized. The turn with the highest 
# score will be accepted.

Rule.define :blue_if_shield_is_low do |player, opponent, stones|
  return 0 unless stones[:blue] >= 3 and player.shield <= 12
  return 15/0.1 - 1 * (stones[:blue] -2) if player.shield == 0
  return 15/player.shield - 1 * (stones[:blue] - 2) 
end

# If its possible to kill then enenmy do it!

Rule.define :use_bombs_and_kill_opponent do |player, opponent, stones|
  return 1000 if (opponent.shield + opponent.live) < stones[:bombs]
end

Rule.define :use_red_and_kill_opponent do |player, opponent, stones|
  return 1000 if (stones[:red] + player.red >= 15) && (opponent.shield + opponent.live) < 10
end

Rule.define :use_yellow_and_kill_opponent do |player, opponent, stones|
  return 1000 if (stones[:yellow] + player.yellow >= 15) && (opponent.shield + opponent.live) < 6 
end

Rule.define :use_green_and_kill_opponent do |player, opponent, stones|
  return 1000 if (stones[:green] + player.green >= 15) && (opponent.shield + opponent.live) < 3
end

# Rate each stone. 
# If player has many red stones, then the score for red will be highter. 

Rule.define :rate_bombs do |player, opponent, stones|
  return stones[:bombs] * 5
end

Rule.define :rate_red do |player, opponent, stones|
  return stones[:red] * 4 * (0.01*player.red**2+1)
end

Rule.define :rate_yellow do |player, opponent, stones|
  return stones[:yellow] * 3 * (0.01*player.yellow**2+1)
end

Rule.define :rate_green do |player, opponent, stones|
  return stones[:green] * 2 * (0.01*player.green**2+1)
end

Rule.define :rate_lila do |player, opponent, stones|
  return stones[:lila] * (0.01*player.lila**2+1)
end

