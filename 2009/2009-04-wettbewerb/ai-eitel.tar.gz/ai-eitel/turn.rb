=begin
rb-ai - KI for http://www.freiesmagazin.de/programmierwettbewerb

Copyright (C) 2009 Florian Eitel

This program is free software; you can redistribute it and/or modify it under the terms of the
GNU General Public License as published by the Free Software Foundation; either version 3 of
the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See
the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program;
if not, see <http://www.gnu.org/licenses/>.
=end

# represent one possible turn.
class Turn
  # stone is the index of the start stone
  attr_reader :stone
  # direction means the direction to swap the stone
  attr_reader :direction
  # complete_stones contains a Hash with all stones deleted in this turn
  attr_reader :complete_stones
  # rater rates this turn
  attr_reader :rater
  # affected is an array:
  # * 0 => orginal iteration (after swap)
  # * 1 => stones deleted after delete of first iteration
  # * ...
  # each item in array contains the stones which will be deleted
  # and the field before the deletion
  attr_reader :affected

  def initialize stone, direction, affected, field
    @affected = Array.new
    @stone, @direction = stone, direction
    @affected[0] = {:stones => Set.new(affected), :field => field.clone.do_shift!(self)}
    @complete_stones = {:red => 0, :blue => 0, :green => 0, :yellow => 0, :lila => 0, :bombs => 0}
    fill_affected
    count_stones
  end

  # rate the turn
  def rate player, opponent
    @rater = Rater.new player, opponent, @complete_stones
    @rater.rate
  end

  # returns the raiting of this turn
  def rating
    @rater.rating
  end

  # => used in sets
  def eql? other_Turn
    stone == other_Turn.stone and direction == other_Turn.direction
  end

  def hash
    "#{stone.hash}99#{direction.hash}".to_i
  end

  # returns respresentation as string
  def to_s
    str = "\nmove #{@stone} in #{@direction}\n"
    @affected.each_index do |index|
      str += " "*index + "-> " +  @affected[index][:stones].inspect + "\n"
    end
    str += "\n" + @rater.to_s
    str
  end

  # returns respresentation as html
  def to_html
    str = "<h2>move #{@stone} in #{@direction}</h2>\n"
    @affected.each_index do |index|
      str += "<table><tr><th colspan=\"#{@affected[index][:field].width}\">#{@affected[index][:stones].sort.to_a.join ","}&nbsp;</th></tr>\n"
      str += @affected[index][:field].to_html @affected[index][:stones] + "\n"
      str += "</table>\n"
    end
    str += @rater.to_html
    str
  end

private
  # finds all deleted stones over all iterations
  def fill_affected
    i = 0
    begin
      field = @affected[i][:field].clone
      field.slide! @affected[i][:stones]
      i += 1
      @affected[i] = {:field => field.clone, :stones => field.search_affected}
    end until @affected[i][:stones].size == 0
  end

  # count all stones in all iterations which will be deleted
  def count_stones
    mapping = { 'R' => :red, 'G' => :green, 'Y' => :yellow, 'B' => :blue, 'L' => :lila}
    @affected.each do |item|
      item[:stones].each do |stone|
        unless item[:field][stone].to_i == 0
          @complete_stones[:bombs] += item[:field][stone].to_i
        else 
          @complete_stones[mapping[item[:field][stone]]] += 1
        end
      end
    end
  end
end

