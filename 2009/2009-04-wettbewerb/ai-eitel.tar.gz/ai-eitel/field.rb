=begin
rb-ai - KI for http://www.freiesmagazin.de/programmierwettbewerb

Copyright (C) 2009 Florian Eitel

This program is free software; you can redistribute it and/or modify it under the terms of the
GNU General Public License as published by the Free Software Foundation; either version 3 of
the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See
the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program;
if not, see <http://www.gnu.org/licenses/>.
=end

require 'term/ansicolor'
require 'set'

# GameField hold the field in an normal Array.
# Borders are marked with an 'N'
# LEFT, RIGHT, UP, DOWN are additions to the current index of the Array
class GameField < Array
  include Term::ANSIColor
  attr_reader :LEFT, :RIGHT, :UP, :DOWN, :START, :STOP
  attr_reader :width, :left_spacer, :up_spacer

  def initialize value
    @left_spacer  = 3
    @up_spacer    = 3
    @width        = value[0].split.length+@left_spacer*2

    field = []
    field += ["N"]*@up_spacer*@width
    field += value.inject([]) {|sum,b| sum + ["N"]*@left_spacer +  b.split + ["N"]*@left_spacer} 
    field += ["N"]*@up_spacer*@width
    super field

    # Constants
    @LEFT   = -1
    @RIGHT  = 1
    @UP     = -@width
    @DOWN   = @width

    @START  = @up_spacer*@width+@left_spacer
    @STOP   = size-3*@width-@left_spacer-1
  end

  # returns respresentation as string
  # parameter is an array of indexes which will be highlighted
  # default empty
  def to_s a=[]
    t = 0
    inject("") do |sum,b| 
      sum += "#{b} " unless a.include? t
      sum += red { b } + " " if a.include? t
      sum += "\n"    if (t += 1) % @width == 0
      sum
    end
  end

  # returns respresentation as html
  # parameter is an array of indexes which will be highlighted
  # default empty
  def to_html a=[]
    t = 0
    str = "<tr>"
    str += inject("") do |sum,b|       
      if b == "N"
        sum += "<td class=\"border\">#{b}</td>"
      elsif a.include? t
        sum += "<td class=\"important\">#{b}</td>"
      else
        sum += "<td>#{b}</td>"
      end
      sum += "</tr><tr>"    if (t += 1) % @width == 0
      sum
    end
    str = str[0..-5]
  end

  # converts an index back to a 2 D coordinate
  def convert a
    [(a % @width) - @left_spacer, @width - 1 - @up_spacer -  (a / @width)]
  end

  # search all possible combinations
  # which needs a swap of two stones
  # returns all found possibilities
  def search_combos
    possibilities = Set.new
    (@START..@STOP).each do |x| # interates over all fields exept borders
      next if self[x] == "N" # don't cross border
      [@RIGHT, @DOWN, @LEFT, @UP].each do |a| # test in each direction
        solution = look_around x, a
        if solution[:complete].size >= 3 # if more then three same stones found 
          possibilities << Turn.new(x, a, solution[:complete], self) # create a new Turn
        end
      end
    end
    possibilities
  end

  # search for three same fields in the field
  # without any swap of stones
  def search_affected
    affected = Set.new
    (@START..@STOP).each do |x|
      next if self[x] == "N"
      solution = look_around x
      if solution[:complete].size >= 3
        affected += solution[:complete]
      end
    end
    affected
  end

  # shifts two stones
  def do_shift! turn
    self[turn.stone+turn.direction], self[turn.stone] = self[turn.stone], self[turn.stone+turn.direction]
    self
  end

  # the next stones slide down. 
  def slide! stones
    stones.sort.each do |x|
      t = x+@UP 
      s = x
      begin
        self[s] = self[t]
        t += @UP 
        s += @UP 
      end while t > 0
    end
  end

private
  # Look around for same stones
  # first parameter is the index of the first stone
  # second parameter is the direction of swapping the stone (0 if no swap)
  def look_around x, a=0
    solution = {:complete => Set.new([x+a]), @RIGHT => Set.new, @DOWN => Set.new, @LEFT => Set.new, @UP => Set.new}
    # search in all direction exept the orginal direction
    ([@RIGHT, @DOWN, @LEFT, @UP]-[-a]).each do |b|
      t = b
      while self[x] == self[x+a+t] or (self[x].to_i != 0 and self[x+a+t].to_i != 0)
        solution[b] << x+a+t
        t += b
      end
      solution[:complete] += solution[b] + solution[-b] if (solution[b].size + solution[-b].size) >= 2
    end
    solution
  end
end 

