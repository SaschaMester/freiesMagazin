=begin
rb-ai - KI for http://www.freiesmagazin.de/programmierwettbewerb

Copyright (C) 2009 Florian Eitel

This program is free software; you can redistribute it and/or modify it under the terms of the
GNU General Public License as published by the Free Software Foundation; either version 3 of
the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See
the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program;
if not, see <http://www.gnu.org/licenses/>.
=end

# executes all defined rules and score the turn
class Rater
  # :raiting contains the complete score
  attr_reader :rating
  # :raintings contains a hash { rule => score }
  attr_reader :ratings
  def initialize player, opponent, stones 
    @player, @opponent, @stones = player, opponent, stones 
    @ratings = Hash.new
    @rating = 0
  end
  # call all rules and summize the results
  def rate 
    Rule.all.each do |rule|
      r = rule.call(@player, @opponent, @stones) || 0
      @ratings[rule] = r
      @rating += r 
    end
    @rating
  end
  # returns respresentation as string
  def to_s
    result = "Rules:\n"
    result += @stones.inspect + "\n"
    @ratings.each_pair do |rule,raiting|
      result += "#{rule.to_s} => #{raiting}\n"
    end
    result += "complete: #{@rating}\n"
  end
  # returns respresentation as html
  def to_html
    result = "<table>"
    result += "<tr><td>stones:</td><td>"
    @stones.each_pair do |key,val|
      result += "#{key}: #{val} "
    end
    result += "</td></tr>"
    @ratings.each_pair do |rule,raiting|
      result += "<tr><td>#{rule.to_s}</td><td>#{raiting}</td></tr>\n"
    end
    result += "<tr><td><strong>complete:</strong></td><td>#{@rating}</td></tr>\n"
    result += "</table>"
  end
end

# Define ohe rule
class Rule
  # contains all defined rules
  @all = Array.new
  attr_reader :block
  class << self
    attr_reader :all
  end
  # create new rule
  def self.define desc, &block
    @all << new(desc, lambda(&block))
  end
  def call *a
    @block.call *a
  end
  def to_s
    @desc.to_s
  end
private
  def initialize desc, block
    @desc, @block = desc, block
  end
end

