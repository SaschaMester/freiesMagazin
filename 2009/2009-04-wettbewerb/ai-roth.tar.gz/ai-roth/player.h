// *************************************************************************
// freiesMagazin-Programmierwettbewerb (ai)
// Draft by Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Copyright 2009 Frank Roth <frank.roth@stud.tu-ilmenau.de>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef PLAYER_H
#define PLAYER_H

// System
//////////////
#include <string>

class Player
{
public:
    // standard constructor
    Player(void);

    // destructor
    ~Player(void);

    // read player data from file
    // return true if everything went fine
    const bool read(const std::string& filename);

    const unsigned int getShieldPoints() const;
    const unsigned int getLifePoints() const;
    const unsigned int getRedPoints() const;
    const unsigned int getGreenPoints() const;
    const unsigned int getYellowPoints() const;
    const unsigned int getLilacPoints() const;

    // float between 0.0 - 1.0
    const float calcVitality() const;

private:
    // print player data on screen
    void print(void) const;

    // life points
    // if 0, the player is dead
    unsigned int m_life;

    // shield that must be first removed
    unsigned int m_shield;

    // different points to collect
    unsigned int m_redPoints;
    unsigned int m_greenPoints;
    unsigned int m_yellowPoints;
    unsigned int m_lilacPoints;
};

#endif // PLAYER_H
