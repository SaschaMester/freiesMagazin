// *************************************************************************
// freiesMagazin-Programmierwettbewerb (ai)
// Copyright 2009 Frank Roth <frank.roth@stud.tu-ilmenau.de>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "besttile.h"
#include "tile.h"
#include "fieldpos.h"

// constructor
BestTile::BestTile()
   :Tile()
{
   m_Counter = 0;
   m_BombDamageCounter = 0;
}

BestTile::BestTile(const BestTile& tile)
    :Tile(tile)
{
   m_Counter = tile.m_Counter;
   m_BombDamageCounter = tile.m_BombDamageCounter;
}


// increases the number of counted Tiles
void BestTile::inc(void)
{
   m_Counter++;
   m_BombDamageCounter += m_BombDamage;
}

void BestTile::inc(const TileType tile)
{
   set(tile);
   inc();
}

void BestTile::inc(const ScoredTile tile)
{
   set(tile.getTile().getType());
   m_Counter += tile.getLength();
   m_BombDamageCounter += tile.getBombValue();

}

// set this tile to the maximum of them
bool BestTile::max(const BestTile& tile)
{
   bool isMax = false;

   if(tile.isBomb())
   {
      // if it's bomb ... compare the bombdamage
      if(m_BombDamageCounter < tile.m_BombDamageCounter)
      {
         m_Counter = tile.m_Counter;
         m_BombDamage = tile.m_BombDamage;
         m_BombDamageCounter = tile.m_BombDamageCounter;

         isMax = true;
      }
   }
   else
   {
      if(m_Counter < tile.m_Counter)  // tile is maximum or equal
      {
         m_Counter = tile.m_Counter;

         isMax = true;
      }
   }

   return isMax;
}

unsigned int BestTile::getCounter(void) const
{
   return m_Counter;
}

unsigned int BestTile::getBombDamageCounter(void) const
{
   return m_BombDamageCounter;
}

TileSwap::TileSwap(void)
{
   m_ScoreYellow = 0;
   m_ScoreGreen = 0;
   m_ScoreRed = 0;
   m_ScoreLilac = 0;
   m_ScoreShield = 0;
   m_ScoreBomb = 0;
   m_ScoreBombDamage = 0;
}

TileSwap::TileSwap(const FieldPos& pos1, const FieldPos& pos2)
{
   m_ScoreYellow = 0;
   m_ScoreGreen = 0;
   m_ScoreRed = 0;
   m_ScoreLilac = 0;
   m_ScoreShield = 0;
   m_ScoreBomb = 0;
   m_ScoreBombDamage = 0;

   m_Pos1 = pos1;
   m_Pos2 = pos2;
}

void TileSwap::setSwapPos(const FieldPos& pos1, const FieldPos& pos2)
{
   m_Pos1 = pos1;
   m_Pos2 = pos2;
}

void TileSwap::getSwapPos(FieldPos& pos1, FieldPos& pos2) const
{
   pos1 = m_Pos1;
   pos2 = m_Pos2;
}

unsigned int TileSwap::getSwapPosMinY(void) const
{
   if(m_Pos1.y() < m_Pos2.y())
   {
      return m_Pos1.y();
   } else
   {
      return m_Pos2.y();
   }
}

// calculates a score for Position
// TODO cascade support ...
void TileSwap::calcScore(const BestTile& row1, const BestTile& col1, const BestTile& row2, const BestTile& col2)
{
   m_ScoreYellow = 0;
   m_ScoreGreen = 0;
   m_ScoreRed = 0;
   m_ScoreLilac = 0;
   m_ScoreShield = 0;
   m_ScoreBombDamage = 0;
   m_ScoreBomb = 0;


   if(row1.getCounter() >= 3)
   {
      switch(row1.getType())
      {
         case Tile::TILE_GREEN:
            m_ScoreGreen += row1.getCounter();
            break;
         case Tile::TILE_YELLOW:
            m_ScoreYellow += row1.getCounter();
            break;
         case Tile::TILE_RED:
            m_ScoreRed += row1.getCounter();
            break;
         case Tile::TILE_LILAC:
            m_ScoreLilac += row1.getCounter();
            break;
         case Tile::TILE_SHIELD:
            m_ScoreShield += row1.getCounter();
            break;
         case Tile::TILE_BOMB_1:
         case Tile::TILE_BOMB_2:
         case Tile::TILE_BOMB_3:
         case Tile::TILE_BOMB_4:
         case Tile::TILE_BOMB_5:
            m_ScoreBomb += row1.getCounter();
            m_ScoreBombDamage += row1.getBombDamageCounter();
            break;
         default:
            //TODO TILE_EMPTY ??
            break;
      }
   }

   if(col1.getCounter() >= 3)
  {
      switch(col1.getType())
      {
         case Tile::TILE_GREEN:
            m_ScoreGreen += col1.getCounter();
            break;
         case Tile::TILE_YELLOW:
            m_ScoreYellow += col1.getCounter();
            break;
         case Tile::TILE_RED:
            m_ScoreRed += col1.getCounter();
            break;
         case Tile::TILE_LILAC:
            m_ScoreLilac += col1.getCounter();
            break;
         case Tile::TILE_SHIELD:
            m_ScoreShield += col1.getCounter();
            break;
         case Tile::TILE_BOMB_1:
         case Tile::TILE_BOMB_2:
         case Tile::TILE_BOMB_3:
         case Tile::TILE_BOMB_4:
         case Tile::TILE_BOMB_5:
            m_ScoreBomb += col1.getCounter();
            m_ScoreBombDamage += col1.getBombDamageCounter();
            break;
         default:
            //TODO TILE_EMPTY ??
            break;
      }

}


  if(row2.getCounter() >= 3)
  {
      switch(row2.getType())
      {
         case Tile::TILE_GREEN:
            m_ScoreGreen += row2.getCounter();
            break;
         case Tile::TILE_YELLOW:
            m_ScoreYellow += row2.getCounter();
            break;
         case Tile::TILE_RED:
            m_ScoreRed += row2.getCounter();
            break;
         case Tile::TILE_LILAC:
            m_ScoreLilac += row2.getCounter();
            break;
         case Tile::TILE_SHIELD:
            m_ScoreShield += row2.getCounter();
            break;
         case Tile::TILE_BOMB_1:
         case Tile::TILE_BOMB_2:
         case Tile::TILE_BOMB_3:
         case Tile::TILE_BOMB_4:
         case Tile::TILE_BOMB_5:
            m_ScoreBomb += row2.getCounter();
            m_ScoreBombDamage += row2.getBombDamageCounter();
            break;
         default:
            //TODO TILE_EMPTY ??
            break;
      }
   }

   if(col2.getCounter() >= 3)
   {
      switch(col2.getType())
      {
         case Tile::TILE_GREEN:
            m_ScoreGreen += col2.getCounter();
            break;
         case Tile::TILE_YELLOW:
            m_ScoreYellow += col2.getCounter();
            break;
         case Tile::TILE_RED:
            m_ScoreRed += col2.getCounter();
            break;
         case Tile::TILE_LILAC:
            m_ScoreLilac += col2.getCounter();
            break;
         case Tile::TILE_SHIELD:
            m_ScoreShield += col2.getCounter();
            break;
         case Tile::TILE_BOMB_1:
         case Tile::TILE_BOMB_2:
         case Tile::TILE_BOMB_3:
         case Tile::TILE_BOMB_4:
         case Tile::TILE_BOMB_5:
            m_ScoreBomb += col2.getCounter();
            m_ScoreBombDamage += col2.getBombDamageCounter();
            break;
         default:
            //TODO TILE_EMPTY ??
            break;
      }
   }

}

// deletes score
void TileSwap::clearScore()
{
   m_ScoreYellow = 0;
   m_ScoreGreen = 0;
   m_ScoreRed = 0;
   m_ScoreLilac = 0;
   m_ScoreShield = 0;
   m_ScoreBombDamage = 0;
   m_ScoreBomb = 0;
}

// adds the line to score
void TileSwap::addScore(const BestTile& line)
{
   // Count it only, if the line is longer as 3 tiles
   if(line.getCounter() >= 3)
   {
      switch(line.getType())
      {
         case Tile::TILE_GREEN:
            m_ScoreGreen += line.getCounter();
            break;
         case Tile::TILE_YELLOW:
            m_ScoreYellow += line.getCounter();
            break;
         case Tile::TILE_RED:
            m_ScoreRed += line.getCounter();
            break;
         case Tile::TILE_LILAC:
            m_ScoreLilac += line.getCounter();
            break;
         case Tile::TILE_SHIELD:
            m_ScoreShield += line.getCounter();
            break;
         case Tile::TILE_BOMB_1:
         case Tile::TILE_BOMB_2:
         case Tile::TILE_BOMB_3:
         case Tile::TILE_BOMB_4:
         case Tile::TILE_BOMB_5:
            m_ScoreBomb += line.getCounter();
            m_ScoreBombDamage += line.getBombDamageCounter();
            break;
         default:
            //TODO TILE_EMPTY ??
            break;
      }
   }
}

unsigned int TileSwap::getScoreYellow(void) const
{
   return m_ScoreYellow;
}

unsigned int TileSwap::getScoreGreen(void) const
{
   return m_ScoreGreen;
}

unsigned int TileSwap::getScoreRed(void) const
{
   return m_ScoreRed;
}

unsigned int TileSwap::getScoreLilac(void) const
{
   return m_ScoreLilac;
}

unsigned int TileSwap::getScoreShield(void) const
{
   return m_ScoreShield;
}

unsigned int TileSwap::getScoreBombDamage(void) const
{
   if(m_ScoreBomb >= 3) return m_ScoreBombDamage;
   else return 0;
}

unsigned int TileSwap::getScoreBomb(void) const
{
   return m_ScoreBomb;
}

float TileSwap::getScoreStoneDamage(void) const
{
   float stoneScore = 0.0;

   if(m_ScoreRed >= 3)     stoneScore += float(m_ScoreRed) / 15.0f * 10.0f;
   if(m_ScoreYellow >= 3)  stoneScore += float(m_ScoreYellow) / 15.0f * 6.0f;
   if(m_ScoreGreen >= 3)   stoneScore += float(m_ScoreGreen) / 15.0f * 3.0f;


   return stoneScore;
}

// set this tile to the maximum of them
bool BestSwaps::max(const TileSwap& tile)
{
   bool isMax = false;

   if((tile.getScoreRed() > m_TileRed.getScoreRed())
      || ((tile.getScoreRed() == m_TileRed.getScoreRed())
      && (tile.getSwapPosMinY() < m_TileRed.getSwapPosMinY())))
   {
       m_TileRed = tile;
       isMax = true;
   }

   if((tile.getScoreYellow() > m_TileYellow.getScoreYellow())
      || ((tile.getScoreYellow() == m_TileYellow.getScoreYellow())
      && (tile.getSwapPosMinY() < m_TileYellow.getSwapPosMinY())))
   {
       m_TileYellow = tile;
       isMax = true;
   }

   if((tile.getScoreGreen() > m_TileGreen.getScoreGreen())
      || ((tile.getScoreGreen() == m_TileGreen.getScoreGreen())
      && (tile.getSwapPosMinY() < m_TileGreen.getSwapPosMinY())))
   {
       m_TileGreen = tile;
       isMax = true;
   }

   if((tile.getScoreShield() > m_TileShield.getScoreShield())
      || ((tile.getScoreShield() == m_TileShield.getScoreShield())
      && (tile.getSwapPosMinY() < m_TileShield.getSwapPosMinY())))
   {
       m_TileShield = tile;
       isMax = true;
   }

   if((tile.getScoreLilac() > m_TileLilac.getScoreLilac())
      || ((tile.getScoreLilac() == m_TileLilac.getScoreLilac())
      && (tile.getSwapPosMinY() < m_TileLilac.getSwapPosMinY())))
   {
       m_TileLilac = tile;
       isMax = true;
   }

   if((tile.getScoreBombDamage() > m_TileBombDamage.getScoreBombDamage())
      || ((tile.getScoreBombDamage() == m_TileBombDamage.getScoreBombDamage())
      && (tile.getSwapPosMinY() < m_TileBombDamage.getSwapPosMinY())))
   {
       m_TileBombDamage = tile;
       isMax = true;
   }

   if((tile.getScoreStoneDamage() > m_TileStoneDamage.getScoreStoneDamage())
      || ((tile.getScoreStoneDamage() == m_TileStoneDamage.getScoreStoneDamage())
      && (tile.getSwapPosMinY() < m_TileStoneDamage.getSwapPosMinY())))
   {
      m_TileStoneDamage = tile;
      isMax = true;
   }

   if((tile.getScoreBomb() > m_TileBomb.getScoreBomb())
      || ((tile.getScoreBomb() == m_TileBomb.getScoreBomb())
      && (tile.getSwapPosMinY() < m_TileBomb.getSwapPosMinY())))
   {
      m_TileBomb = tile;
      isMax = true;
   }

   if(((tile.getScoreShield() >= 3) && (tile.getScoreShield() >= m_TileStoneDamageAndShield.getScoreShield()))
      && ((tile.getScoreStoneDamage() > m_TileStoneDamageAndShield.getScoreStoneDamage())
         || ((tile.getScoreStoneDamage() == m_TileStoneDamageAndShield.getScoreStoneDamage())
            && (tile.getSwapPosMinY() < m_TileStoneDamageAndShield.getSwapPosMinY()))))
   {
      m_TileStoneDamageAndShield = tile;
      isMax = true;
   }

   if(((tile.getScoreLilac() >= 3) && (tile.getScoreLilac() >= m_TileStoneDamageAndLilac.getScoreLilac()))
      && ((tile.getScoreStoneDamage() > m_TileStoneDamageAndLilac.getScoreStoneDamage())
         || ((tile.getScoreStoneDamage() == m_TileStoneDamageAndLilac.getScoreStoneDamage())
            && (tile.getSwapPosMinY() < m_TileStoneDamageAndLilac.getSwapPosMinY()))))
   {
      m_TileStoneDamageAndLilac = tile;
      isMax = true;
   }

   return isMax;
}

TileSwap BestSwaps::getBestYellow(void) const
{
   return m_TileYellow;
}

TileSwap BestSwaps::getBestGreen(void) const
{
   return m_TileGreen;
}

TileSwap BestSwaps::getBestRed(void) const
{
   return m_TileRed;
}

TileSwap BestSwaps::getBestLilac(void) const
{
   return m_TileLilac;
}

TileSwap BestSwaps::getBestShield(void) const
{
   return m_TileShield;
}

TileSwap BestSwaps::getBestBomb(void) const
{
   return m_TileBomb;
}

TileSwap BestSwaps::getBestBombDamage(void) const
{
   return m_TileBombDamage;
}

TileSwap BestSwaps::getBestStoneDamage(void) const
{
   return m_TileStoneDamage;
}

TileSwap BestSwaps::getBestStoneDamageAndShield(void) const
{
   return m_TileStoneDamageAndShield;
}

TileSwap BestSwaps::getBestStoneDamageAndLilac(void) const
{
   return m_TileStoneDamageAndLilac;
}

