// *************************************************************************
// freiesMagazin-Programmierwettbewerb (ai)
// Draft by Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Copyright 2009 Frank Roth <frank.roth@stud.tu-ilmenau.de>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

// System
///////////
#include <iostream>
#include <fstream>
#include <vector>

// Own
//////////////
#include "gamefield.h"
#include "fieldpos.h"
#include "besttile.h"

// standard constructor
// initialize game field
GameField::GameField(void)
{
    // nothing to do
}

// Copy constructor
GameField::GameField(const GameField& field)
{
    for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
    {
        for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
        {
            m_field[i][j] = field.m_field[i][j];
        }
    }
}

// destructor
GameField::~GameField(void)
{
    // nothing to do
}

// copy game field
void GameField::set(const GameField& field)
{
    for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
    {
        for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
        {
            m_field[i][j] = field.m_field[i][j];
        }
    }
}

// opens file and reads the first 100 relevant characters
// newline, cr, spaces and tabs will be ignored
// return true if everything is ok
const bool GameField::read(const std::string& filename)
{
    bool ok = false;

    if ( !filename.empty() )
    {
        // open file for writing
        std::ifstream infile( filename.c_str() );

        if ( NULL != infile )
        {
            unsigned int i = 0;
            unsigned int j = 0;

            while ( infile.good() && j < FIELD_HEIGHT )
            {
                if ( i >= FIELD_WIDTH )
                {
                    i = 0;
                    j++;
                }

                // read character
                char c = 0;
                infile.get(c);
                // std::cout << c;

                switch ( (Tile::TileType)c )
                {
                    case Tile::TILE_RED:
                    case Tile::TILE_GREEN:
                    case Tile::TILE_YELLOW:
                    case Tile::TILE_SHIELD:
                    case Tile::TILE_LILAC:
                    case Tile::TILE_BOMB_1:
                    case Tile::TILE_BOMB_2:
                    case Tile::TILE_BOMB_3:
                    case Tile::TILE_BOMB_4:
                    case Tile::TILE_BOMB_5:
                        // store tile
                        m_field[i][FIELD_HEIGHT-j-1].set( (Tile::TileType)c );
                        i++;
                        break;
                    default:
                      // ignore everything else
                      break;
                }
            }

            // check if whole field was loaded
            if ( ( 0 != i ) || ( FIELD_HEIGHT != j ) )
            {
                std::cout << "GameField::read() error: game field was not loaded completely" << std::endl;
            }
            else
            {
                ok = true;
            }

            // close file
            infile.close();
        }
        else
        {
            std::cout << "GameField::read() error: file could not be opened" << std::endl;
        }
    }
    else
    {
        std::cout << "GameField::read() error: string is empty" << std::endl;
    }

    if (ok)
    {
        // print();
    }

    return ok;
}

// prints the game field on screen
void GameField::print(void) const
{
    for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
    {
        for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
        {
            // initialize with zeros
            std::cout << (char)m_field[i][FIELD_HEIGHT-j-1].getType() << " ";
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;
}

// calculate next move for this player
// and write result to file
const bool GameField::calculate(const Player& player, const Player& opponent, const std::string& filename) const
{
    bool ok = false;

    // search "good" tile on game field
    // This KI is really dumb! It just searches the first possible
    // positions to swap. It does not take the player or opponent
    // settings into account.
    // THIS IS YOUR TASK! ;)

    // tile positions on game field to swap
   BestSwaps bestSwaps;
   TileSwap bestTileSwap;

   std::cout << "GameField::calculate " << std::endl;


   // we go through each column and row and swap single elements
   for ( unsigned int i = 0; i < FIELD_WIDTH-1; i++ )
   {
     for ( unsigned int j = 0; j < FIELD_HEIGHT-1; j++ )
     {

      // set positions for swapping
      FieldPos tempPos1(i,j);
      FieldPos tempPos2(i,j+1);

      // calculats summary Score for this swap position
      TileSwap tileSwap(tempPos1,tempPos2);

      // swap tiles at positions and check if there/home/frank/develop/wettbewerb/fm-game/
      // are same tiles connected

      // copy game field
      GameField tempField(*this);
         tempField.swapTiles(tempPos1,tempPos2);

         tileSwap.clearScore();
         tempField.cascade(tileSwap);
         bestSwaps.max(tileSwap);

      // set positions for swapping
      tempPos1.set(i,j);
      tempPos2.set(i+1,j);

      // swap tiles at positions and check if there
      // are same tiles connected now

      tempField.set(*this);
         tempField.swapTiles(tempPos1,tempPos2);

         tileSwap.setSwapPos(tempPos1,tempPos2);
         tileSwap.clearScore();

         //tempField.findSameTilesInCrux(tempPos1,tempPos2,bestSwaps);
         tempField.cascade(tileSwap);
         bestSwaps.max(tileSwap);
     }

   }

/*
   FieldPos von,zu;

   bestSwaps.getBestRed().getSwapPos(von,zu);
   std::cout << "getBestRed() = " << bestSwaps.getBestRed().getScoreRed() << "\t Swap " << von.x() << " " << von.y() << " " << zu.x() << " " << zu.y() << std::endl;
      bestSwaps.getBestYellow().getSwapPos(von,zu);
   std::cout << "getBestYellow() = " << bestSwaps.getBestYellow().getScoreYellow() << "\t Swap " << von.x() << " " << von.y() << " " << zu.x() << " " << zu.y()<< std::endl;
      bestSwaps.getBestGreen().getSwapPos(von,zu);
   std::cout << "getBestGreen() = " << bestSwaps.getBestGreen().getScoreGreen() << "\t Swap " << von.x() << " " << von.y() << " " << zu.x() << " " << zu.y()<< std::endl;
      bestSwaps.getBestLilac().getSwapPos(von,zu);
   std::cout << "getBestLilac() = " << bestSwaps.getBestLilac().getScoreLilac() << "\t Swap " << von.x() << " " << von.y() << " " << zu.x() << " " << zu.y()<< std::endl;
      bestSwaps.getBestShield().getSwapPos(von,zu);
   std::cout << "getBestShield()) = " << bestSwaps.getBestShield().getScoreShield() << "\t Swap " << von.x() << " " << von.y() << " " << zu.x() << " " << zu.y()<< std::endl;
      bestSwaps.getBestBomb().getSwapPos(von,zu);
   std::cout << "getBestBomb() = " << bestSwaps.getBestBomb().getScoreBomb() << "\t Swap " << von.x() << " " << von.y() << " " << zu.x() << " " << zu.y()<< std::endl;
      bestSwaps.getBestBombDamage().getSwapPos(von,zu);
   std::cout << "getBestBombDamage() = " << bestSwaps.getBestBombDamage().getScoreBombDamage() << "\t Swap " << von.x() << " " << von.y() << " " << zu.x() << " " << zu.y()<< std::endl;
      bestSwaps.getBestStoneDamage().getSwapPos(von,zu);
   std::cout << "getBestStoneDamage() = " << bestSwaps.getBestStoneDamage().getScoreStoneDamage() << "\t Swap " << von.x() << " " << von.y() << " " << zu.x() << " " << zu.y()<< std::endl;
      bestSwaps.getBestStoneDamageAndShield().getSwapPos(von,zu);
   std::cout << "getBestStoneDamageAndShield() = " << bestSwaps.getBestStoneDamageAndShield().getScoreStoneDamage() << "&" << bestSwaps.getBestStoneDamageAndShield().getScoreShield() << "\t Swap " << von.x() << " " << von.y() << " " << zu.x() << " " << zu.y()<< std::endl;
      bestSwaps.getBestStoneDamageAndLilac().getSwapPos(von,zu);
   std::cout << "getBestStoneDamageAndLilac() = " << bestSwaps.getBestStoneDamageAndLilac().getScoreStoneDamage() << "&" << bestSwaps.getBestStoneDamageAndLilac().getScoreLilac() << "\t Swap " << von.x() << " " << von.y() << " " << zu.x() << " " << zu.y()<< std::endl;

*/

   bool validTurn = false;

   // if there is any bombdamage ... select it
   if(bestSwaps.getBestBombDamage().getScoreBombDamage() >= 3.0)
   {
      bestTileSwap = bestSwaps.getBestBombDamage();
      validTurn = true;
   }

   // switch mode depending vitality ratio

   if(player.calcVitality() / opponent.calcVitality() <= 0.66)
   {
  /*       std::cout << "Player: " << player.calcVitality()
                   << " Opponent: " << opponent.calcVitality() << " -> be defensive" << std::endl;
*/
         // if it is passable, do the move with additional shield

        if(!validTurn)
         {
            if((player.getShieldPoints() + bestSwaps.getBestStoneDamageAndShield().getScoreShield() <= 15)
               &&(
                  (bestSwaps.getBestStoneDamageAndShield().getScoreRed() + player.getRedPoints() >= 15)
               || (bestSwaps.getBestStoneDamageAndShield().getScoreYellow() + player.getGreenPoints() >= 15)
               || (bestSwaps.getBestStoneDamageAndShield().getScoreGreen() + player.getGreenPoints() >= 15)))
            {
               bestTileSwap = bestSwaps.getBestStoneDamageAndShield();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            if(   (bestSwaps.getBestStoneDamage().getScoreRed() + player.getRedPoints() >= 15)
               || (bestSwaps.getBestStoneDamage().getScoreYellow() + player.getGreenPoints() >= 15)
               || (bestSwaps.getBestStoneDamage().getScoreGreen() + player.getGreenPoints() >= 15))
            {
               bestTileSwap = bestSwaps.getBestStoneDamage();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            if((bestSwaps.getBestRed().getScoreRed() >= 3)
               && (bestSwaps.getBestRed().getScoreRed() + player.getRedPoints() >= 15))
            {
               bestTileSwap = bestSwaps.getBestRed();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            if((bestSwaps.getBestYellow().getScoreYellow() >= 3)
               && (bestSwaps.getBestYellow().getScoreYellow() + player.getYellowPoints() >= 15))
            {
               bestTileSwap = bestSwaps.getBestYellow();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            if((bestSwaps.getBestGreen().getScoreGreen() >= 3)
               && (bestSwaps.getBestGreen().getScoreGreen() + player.getGreenPoints() >= 15))
            {
               bestTileSwap = bestSwaps.getBestGreen();
               validTurn = true;
            }
         }



         if(!validTurn)
         {
            if((bestSwaps.getBestShield().getScoreShield() >= 4)
               && (player.getShieldPoints() + bestSwaps.getBestShield().getScoreShield() <= 10))
            {
               bestTileSwap = bestSwaps.getBestShield();
               validTurn = true;
            }
         }

         // if it is passable, do the move with additional shield

         if(!validTurn)
         {
            if(   (bestSwaps.getBestStoneDamageAndShield().getScoreShield() >= 3)
               && (player.getShieldPoints() + bestSwaps.getBestStoneDamageAndShield().getScoreShield() <= 15)
               && (bestSwaps.getBestStoneDamageAndShield().getScoreStoneDamage() >= float(bestSwaps.getBestStoneDamage().getScoreStoneDamage())*0.8))
            {
               bestTileSwap = bestSwaps.getBestStoneDamageAndShield();
               validTurn = true;
            }
         }

         if(!validTurn)  // if damage is high enough
         {
            if(bestSwaps.getBestStoneDamage().getScoreStoneDamage() >= 2.0)
            {
               bestTileSwap = bestSwaps.getBestStoneDamage();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            if((bestSwaps.getBestLilac().getScoreLilac() >= 3)
               && (player.getLilacPoints() + bestSwaps.getBestLilac().getScoreLilac() >= 15))
            {
               bestTileSwap = bestSwaps.getBestLilac();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            if((bestSwaps.getBestStoneDamageAndShield().getScoreShield() >= 3)
               && (player.getShieldPoints() + bestSwaps.getBestStoneDamageAndShield().getScoreShield() < 10))
            {
               bestTileSwap = bestSwaps.getBestStoneDamageAndShield();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            if((bestSwaps.getBestShield().getScoreShield() >= 3)
               && (player.getShieldPoints() + bestSwaps.getBestShield().getScoreShield() < 10))
            {
               bestTileSwap = bestSwaps.getBestShield();
               validTurn = true;
            }
         }

         // make sure that there is a move , first come first win

         if(!validTurn)
         {
            if(bestSwaps.getBestStoneDamage().getScoreStoneDamage() > 0.0)
            {
               bestTileSwap = bestSwaps.getBestStoneDamage();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            if(bestSwaps.getBestLilac().getScoreLilac() >= 3)
            {
               bestTileSwap = bestSwaps.getBestLilac();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            bestTileSwap = bestSwaps.getBestShield();
            validTurn = true;
         }

      }

      if(player.calcVitality() / opponent.calcVitality() >= 1.33)
      {
/*
         std::cout << "Player: " << player.calcVitality()
                   << " Opponent: " << opponent.calcVitality() << " -> be extreme agressive" << std::endl;
*/

         if(!validTurn)
         {
            if(   (bestSwaps.getBestStoneDamage().getScoreRed() + player.getRedPoints() >= 15)
               || (bestSwaps.getBestStoneDamage().getScoreYellow() + player.getGreenPoints() >= 15)
               || (bestSwaps.getBestStoneDamage().getScoreGreen() + player.getGreenPoints() >= 15))
            {
               bestTileSwap = bestSwaps.getBestStoneDamage();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            if((bestSwaps.getBestRed().getScoreRed() >= 3)
               && (bestSwaps.getBestRed().getScoreRed() + player.getRedPoints() >= 15))
            {
               bestTileSwap = bestSwaps.getBestRed();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            if((bestSwaps.getBestYellow().getScoreYellow() >= 3)
               && (bestSwaps.getBestYellow().getScoreYellow() + player.getYellowPoints() >= 15))
            {
               bestTileSwap = bestSwaps.getBestYellow();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            if((bestSwaps.getBestGreen().getScoreGreen() >= 3)
               && (bestSwaps.getBestGreen().getScoreGreen() + player.getGreenPoints() >= 15))
            {
               bestTileSwap = bestSwaps.getBestGreen();
               validTurn = true;
            }
         }

         // if it is passable, select the move with additional shield

         if(!validTurn)
         {
            if((bestSwaps.getBestStoneDamage().getScoreStoneDamage() >= 2.0)
               && (bestSwaps.getBestStoneDamageAndShield().getScoreStoneDamage() >= float(bestSwaps.getBestStoneDamage().getScoreStoneDamage())*0.9)
               && (player.getShieldPoints() + bestSwaps.getBestStoneDamageAndShield().getScoreShield() <= 15))
            {
               bestTileSwap = bestSwaps.getBestStoneDamageAndShield();
               validTurn = true;
            }
         }

         // if it is passable, do the move with additional lilac

         if(!validTurn)
         {
            if((bestSwaps.getBestStoneDamage().getScoreStoneDamage() >= 2.0)
               && (bestSwaps.getBestStoneDamageAndLilac().getScoreStoneDamage() >= float(bestSwaps.getBestStoneDamage().getScoreStoneDamage())*0.9)
               && (player.getLilacPoints() + bestSwaps.getBestStoneDamageAndLilac().getScoreLilac() >= 15))
            {
               bestTileSwap = bestSwaps.getBestStoneDamageAndLilac();
               validTurn = true;
            }
         }


         if(!validTurn)  // if damage is high enough
         {
            if(bestSwaps.getBestStoneDamage().getScoreStoneDamage() >= 1.5)
            {
               bestTileSwap = bestSwaps.getBestStoneDamage();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            if((bestSwaps.getBestLilac().getScoreLilac() >= 3)
               && (player.getLilacPoints() + bestSwaps.getBestLilac().getScoreLilac() >= 15))
            {
               bestTileSwap = bestSwaps.getBestLilac();
               validTurn = true;
            }
         }


         // make sure that there is a move , first come first win

         if(!validTurn)
         {
            if(bestSwaps.getBestStoneDamage().getScoreStoneDamage() > 0.0)
            {
               bestTileSwap = bestSwaps.getBestStoneDamage();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            if(bestSwaps.getBestShield().getScoreShield() >= 3)
            {
               bestTileSwap = bestSwaps.getBestShield();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            if(bestSwaps.getBestLilac().getScoreLilac() >= 3)
            {
               bestTileSwap = bestSwaps.getBestLilac();
               validTurn = true;
            }
         }
      }


   if((0.66 <  (player.calcVitality() / opponent.calcVitality()))
      &&((player.calcVitality() / opponent.calcVitality()) < 1.33))
   {
   /*
      std::cout << "Player: " << player.calcVitality()
               << " Opponent: " << opponent.calcVitality() << " -> be agressive" << std::endl;
*/

         // if it is passable, do the move with additional shield

         if(!validTurn)
         {
            if((bestSwaps.getBestStoneDamage().getScoreStoneDamage() >= 2.5)
               && (bestSwaps.getBestStoneDamageAndShield().getScoreStoneDamage() >= float(bestSwaps.getBestStoneDamage().getScoreStoneDamage())*0.8)
               && (player.getShieldPoints() + bestSwaps.getBestStoneDamageAndShield().getScoreShield() <= 15))
            {
               bestTileSwap = bestSwaps.getBestStoneDamageAndShield();
               validTurn = true;
            }
         }

         if(!validTurn)  // if damage is high enough
         {
            if(bestSwaps.getBestStoneDamage().getScoreStoneDamage() >= 2.5)
            {
               bestTileSwap = bestSwaps.getBestStoneDamage();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            if((bestSwaps.getBestLilac().getScoreLilac() >= 3)
               && (player.getLilacPoints() + bestSwaps.getBestLilac().getScoreLilac() >= 15))
            {
               bestTileSwap = bestSwaps.getBestLilac();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            if((bestSwaps.getBestStoneDamage().getScoreStoneDamage() >=1.5)
               && (bestSwaps.getBestStoneDamageAndShield().getScoreStoneDamage() >= float(bestSwaps.getBestStoneDamage().getScoreStoneDamage())*0.8)
               && (player.getShieldPoints() + bestSwaps.getBestStoneDamageAndShield().getScoreShield() <= 15))
            {
               bestTileSwap = bestSwaps.getBestStoneDamageAndShield();
               validTurn = true;
            }
         }


         if(!validTurn)
         {
            if((bestSwaps.getBestShield().getScoreShield() >= 3)
               && (bestSwaps.getBestStoneDamageAndShield().getScoreShield() >= bestSwaps.getBestShield().getScoreShield())
               && (player.getShieldPoints() + bestSwaps.getBestStoneDamageAndShield().getScoreShield() <= 15))
            {
               bestTileSwap = bestSwaps.getBestStoneDamageAndShield();
               validTurn = true;
            }
         }



         if(!validTurn)
         {
            if((bestSwaps.getBestShield().getScoreShield() >= 3)
               && (player.getShieldPoints() < 8)
               && (player.getShieldPoints() + bestSwaps.getBestShield().getScoreShield() <= 15))
            {
               bestTileSwap = bestSwaps.getBestShield();
               validTurn = true;
            }
         }

         if(!validTurn)  // if damage is high enough
         {
            if(bestSwaps.getBestStoneDamage().getScoreStoneDamage() >= 1.5)
            {
               bestTileSwap = bestSwaps.getBestStoneDamage();
               validTurn = true;
            }
         }



         // make sure that there is a move , first comes first wins



         if(!validTurn)
         {
            if((bestSwaps.getBestShield().getScoreShield() >= 3)
               && (player.getShieldPoints() + bestSwaps.getBestShield().getScoreShield() <= 15))
            {
               bestTileSwap = bestSwaps.getBestShield();
               validTurn = true;
            }
         }


         if(!validTurn)
         {
            if(bestSwaps.getBestStoneDamage().getScoreStoneDamage() > 0.0)
            {
               bestTileSwap = bestSwaps.getBestStoneDamage();
               validTurn = true;
            }
         }


         if(!validTurn)
         {
            if(bestSwaps.getBestLilac().getScoreLilac() >= 3)
            {
               bestTileSwap = bestSwaps.getBestLilac();
               validTurn = true;
            }
         }

         if(!validTurn)
         {
            bestTileSwap = bestSwaps.getBestShield();
            validTurn = true;
         }

      }





   FieldPos pos1, pos2;
   bestTileSwap.getSwapPos(pos1,pos2);

        // std::cout << "GameField::calculate() swap "
        //           << pos1.x() << " " << pos1.y() << " with "
        //           << pos2.x() << " " << pos2.y() << std::endl;

   // store positions
   if ( writePositions(pos1, pos2, filename) )
   {
      ok = true;
   }


    return ok;
}



// return const reference for tile
const Tile& GameField::getTile(const FieldPos& pos) const
{
    if ( ( pos.x() >= FIELD_WIDTH ) || ( pos.y() >= FIELD_HEIGHT ) )
    {
        std::cout << "GameField::getTile() access out of boundaries" << std::endl;
        return m_dummyTile;
    }
    else
    {
        return m_field[pos.x()][pos.y()];
    }
}

// return reference for tile
Tile& GameField::getTile(const FieldPos& pos)
{
    if ( ( pos.x() >= FIELD_WIDTH ) || ( pos.y() >= FIELD_HEIGHT ) )
    {
        std::cout << "GameField::getTile() access out of boundaries" << std::endl;
        return m_dummyTile;
    }
    else
    {
        return m_field[pos.x()][pos.y()];
    }
}

// tries to swap two tiles
// return true if possible
const bool GameField::swapTiles(const FieldPos& pos1, const FieldPos& pos2)
{
    bool possible = false;

    // check if two fields are inside array boundaries
    if ( pos1.x() < FIELD_WIDTH && pos1.y() < FIELD_HEIGHT &&
         pos2.x() < FIELD_WIDTH && pos2.y() < FIELD_HEIGHT )
    {
        // check if next to each other
        if ( ( (pos1.x() == pos2.x()) && ((pos1.y() == pos2.y()+1 || pos1.y()+1 == pos2.y())) ) ||
             ( (pos1.y() == pos2.y()) && ((pos1.x() == pos2.x()+1 || pos1.x()+1 == pos2.x())) ) )
        {
            // swap tiles
            getTile(pos1).swap( getTile(pos2) );
            possible = true;
        }
        else
        {
            std::cout << "GameField::swapTiles() error: tiles not next to each other"
                      << std::endl;
        }
    }
    else
    {
        std::cout << "GameField::swapTiles() error: pos out of boundaries"
                  << std::endl;
    }

    return possible;
}



// let all existing tiles fall to the ground
void GameField::fallTilesToGround(void)
{

    // let all existing tiles fall to the ground
    for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
    {
        // position in each column of tile to fill
        unsigned int fill = 0;

        for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
        {
            if ( !m_field[i][j].isEmpty() )
            {
                if ( fill != j )
                {
                    m_field[i][fill] = m_field[i][j];
                }
                fill++;
            }
        }

        // fill rest of column with zeros
        for ( unsigned int j = fill; j < FIELD_HEIGHT; j++ )
        {
            m_field[i][j].setEmpty();
        }
    }
}

// remove tiles and fill the game fields until only maximum
// two same tiles are next to each other
void GameField::cascade(TileSwap& tile)
{
    // print();
    ScoredTileArray tArray;

    while ( findSameTiles(tArray, tile) )
    {
        // remove tiles
        removeTiles(tArray);

        // first let all existing tiles fall to the ground
        fallTilesToGround();

        // and fill with new ones
//        fillEmptyTiles();

        // clear array again
        tArray.clear();
    }
}

// search for equal entries and removes them on the set
// return true if something has been removed
void GameField::removeTiles(const ScoredTileArray& tArray)
{
    // delete the positions stored in the array
    for ( std::vector<ScoredTile>::const_iterator it = tArray.begin(); it < tArray.end(); it++ )
    {
        // std::cout << "GameField::removeTiles() "
        //           << (*it).getPos().x() << " " << (*it).getPos().y() << std::endl;
        removeTiles(*it);
    }
}

// remove all stored tiles
void GameField::removeTiles(const ScoredTile& tile)
{
    // delete in column
    if ( tile.isUp() )
    {
        // std::cout << "GameField::removeTiles() delete col: "
        //           << tile.getPos().x() << " "
        //           << tile.getPos().y() << " till "
        //           << tile.getPos().x() << " "
        //           << tile.getPos().y()+tile.getLength()-1
        //           << std::endl;

        for ( unsigned int j = 0; j < tile.getLength(); j++ )
        {
            m_field[tile.getPos().x()][tile.getPos().y()+j].setEmpty();
        }
    }
    else if ( tile.isRight() )
    {
        // std::cout << "GameField::removeTiles() delete row: "
        //           << tile.getPos().x() << " "
        //           << tile.getPos().y() << " till "
        //           << tile.getPos().x()+tile.getLength()-1 << " "
        //           << tile.getPos().y()
        //           << std::endl;

        for ( unsigned int i = 0; i < tile.getLength(); i++ )
        {
            m_field[tile.getPos().x()+i][tile.getPos().y()].setEmpty();
        }
    }
    else
    {
        std::cout << "GameField::removeSameTiles() error: unknown direction" << std::endl;
    }
}

// search for equal tiles
// return true if something has been found
const bool GameField::findSameTiles(ScoredTileArray& tArray, TileSwap& tile) const
{
    bool found = false;

    if ( findSameTilesInColumns(tArray,tile) )
    {
        found = true;
    }

    if ( findSameTilesInRows(tArray,tile) )
    {
        found = true;
    }

    return found;
}

// search for equal tiles in rows
// return true if something has been found
const bool GameField::findSameTilesInRows(ScoredTileArray& tArray, TileSwap& tile) const
{
    bool found = false;

    // now go through each row
    for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
    {
        // reset length
        unsigned int length = 0;
        unsigned int bombValue = 0;

        for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
        {
            if ( 0 == i || m_field[i][j] == m_field[i-1][j] )
            {
                // same tile as before or new start tile
                length++;

                // check if bomb and add bomb value
                if ( m_field[i][j].isBomb() )
                {
                    bombValue += m_field[i][j].getBombDamage();
                }

                // if the last tile in this column
                // we must check the length
                if ( FIELD_WIDTH-1 == i && length >= 3 )
                {
                     if(!m_field[i][j].isEmpty())
                     {
                    // only store tiles if length is >= 3
                    ScoredTile sTile( FieldPos(i-length+1, j), length,
                                      ScoredTile::FIELDDIRECTION_RIGHT,
                                      m_field[i][j], bombValue );
                    BestTile bTile;
                    bTile.inc(sTile);
                    tile.addScore(bTile);

                    tArray.push_back(sTile);

                    found = true;

                    //std::cout << "GameField::findSameTilesInRows1()    "
                              //<< i-length+1 << " "
                              //<< j << " "
                              //<< length << " "
                              //<< (char)m_field[i][j].getType() << " "
                              //<< bombValue
                              //<< std::endl;
                     }
                }
            }
            else
            {
                // new tile here
                if ( length >= 3 )
                {
                     if(!m_field[i-1][j].isEmpty())
                     {
                    // only store tiles if length is >= 3
                    ScoredTile sTile( FieldPos(i-length, j), length,
                                      ScoredTile::FIELDDIRECTION_RIGHT,
                                      m_field[i-1][j], bombValue );

                    BestTile bTile;
                    bTile.inc(sTile);
                    tile.addScore(bTile);

                    tArray.push_back(sTile);

                    found = true;

                    //std::cout << "GameField::findSameTilesInRows2()    "
                              //<< i-length << " "
                              //<< j << " "
                              //<< length << " "
                              //<< (char)m_field[i-1][j].getType() << " "
                              //<< bombValue
                              //<< std::endl;
                     }
                }

                // set new length
                length = 1;
                bombValue = 0;

                // check if bomb and add bomb value
                if ( m_field[i][j].isBomb() )
                {
                    bombValue += m_field[i][j].getBombDamage();
                }

            }
        }
    } // for FIELD_HEIGHT

    return found;
}

// search for equal tiles in columns
// return true if something has been found
const bool GameField::findSameTilesInColumns(ScoredTileArray& tArray, TileSwap& tile) const
{
    bool found = false;

    // we will go through each column
    for ( unsigned int i = 0; i < FIELD_WIDTH; i++ )
    {
        // reset length
        unsigned int length = 0;
        unsigned int bombValue = 0;

        for ( unsigned int j = 0; j < FIELD_HEIGHT; j++ )
        {
            if ( 0 == j || m_field[i][j] == m_field[i][j-1] )
            {
                // same tile as before or new start tile
                length++;

                // check if bomb and add bomb value
                if ( m_field[i][j].isBomb() )
                {
                    bombValue += m_field[i][j].getBombDamage();
                }

                // if the last tile in this column
                // we must check the length
                if ( FIELD_HEIGHT-1 == j && length >= 3 )
                {
                    if(!m_field[i][j].isEmpty())

                     {
                    // only store tiles if length is >= 3
                    ScoredTile sTile( FieldPos(i, j-length+1), length,
                                      ScoredTile::FIELDDIRECTION_UP,
                                      m_field[i][j], bombValue );

                    BestTile bTile;
                    bTile.inc(sTile);
                    tile.addScore(bTile);

                    tArray.push_back(sTile);

                    found = true;

                    //std::cout << "GameField::findSameTilesInColumns1() "
                              //<< i << " "
                              //<< j-length+1 << " "
                              //<< length << " "
                              //<< (char)m_field[i][j].getType() << " "
                              //<< bombValue
                              //<< std::endl;
                     }
                }
            }
            else
            {
                // new tile here
                if ( length >= 3 )
                {
                     if(!m_field[i][j-1].isEmpty())
                     {
                    // only store tiles if length is >= 3
                    ScoredTile sTile( FieldPos(i, j-length), length,
                                      ScoredTile::FIELDDIRECTION_UP,
                                      m_field[i][j-1], bombValue );

                    BestTile bTile;
                    bTile.inc(sTile);
                    tile.addScore(bTile);

                    tArray.push_back(sTile);

                    found = true;

                    //std::cout << "GameField::findSameTilesInColumns2() "
                              //<< i << " "
                              //<< j-length << " "
                              //<< length << " "
                              //<< (char)m_field[i][j-1].getType() << " "
                              //<< bombValue
                              //<< std::endl;
                     }
                }

                // set new length
                length = 1;
                bombValue = 0;

                // check if bomb and add bomb value
                if ( m_field[i][j].isBomb() )
                {
                    bombValue += m_field[i][j].getBombDamage();
                }
            }
        }
    }

    return found;
}


// store positions in file
// return true if everything is ok
const bool GameField::writePositions(const FieldPos& pos1, const FieldPos&pos2, const std::string filename) const
{
    bool ok = false;

    if ( !filename.empty() )
    {
        // open file for writing
        std::ofstream outfile( filename.c_str() );

        if ( outfile.good() )
        {
            // write positions into file
            outfile << pos1.x() << " "
                    << pos1.y() << " "
                    << pos2.x() << " "
                    << pos2.y() << std::endl;

            // close file
            outfile.close();

            ok = true;
        }
        else
        {
            std::cout << "GameField::writePositions() error: file could not be opened" << std::endl;
        }
    }
    else
    {
        std::cout << "GameField::writePositions() error: string is empty" << std::endl;
    }

    return ok;
}
