// *************************************************************************
// freiesMagazin-Programmierwettbewerb (ai)
// Draft by Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Copyright 2009 Frank Roth <frank.roth@stud.tu-ilmenau.de>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

// System
///////////
#include <iostream>
#include <stdlib.h>

// Own
//////////////
#include "tile.h"

// standard constructor
Tile::Tile(void)
    : m_tile(TILE_EMPTY),m_BombDamage(0)
{
}

// Copy constructor
Tile::Tile(const Tile& tile)
    : m_tile(tile.m_tile), m_BombDamage(tile.m_BombDamage)
{
}

// destructor
Tile::~Tile(void)
{
}

// set tile type
void Tile::set(const TileType tile)
{
    m_tile =  tile;

    switch(tile)
    {
        case TILE_BOMB_1:
            m_BombDamage = 1;
            break;
        case TILE_BOMB_2:
            m_BombDamage = 2;
            break;
        case TILE_BOMB_3:
            m_BombDamage = 3;
            break;
        case TILE_BOMB_4:
            m_BombDamage = 4;
            break;
        case TILE_BOMB_5:
            m_BombDamage = 5;
            break;
        default:
            m_BombDamage = 0;
            break;
    }
}

// set empty tile
void Tile::setEmpty(void)
{
    m_tile = TILE_EMPTY;
    m_BombDamage = 0;
}

// Check if tile is not set yet.
const bool Tile::isEmpty(void) const
{
    bool empty = false;

    if ( TILE_EMPTY == m_tile )
    {
        empty = true;
    }

    return empty;
}

// return type
const Tile::TileType Tile::getType(void) const
{
    return m_tile;
}

// return Bombdamage
const unsigned int Tile::getBombDamage(void) const
{
    return m_BombDamage;
}

// Compare operator
const bool Tile::operator==(const Tile& tile) const
{
    bool same = false;

    if ( ( *this == tile.m_tile ) || ( isBomb() && tile.isBomb() ) )
    {
        same = true;
    }

    return same;
}

// Compare operator
const bool Tile::operator==(const TileType tile) const
{
    bool same = false;

    if ( tile == m_tile )
    {
        same = true;
    }

    return same;
}

// swap two tiles
void Tile::swap(Tile& tile)
{
    TileType tempTile = m_tile;
    m_tile = tile.m_tile;
    tile.m_tile = tempTile;

    unsigned int tempBombDamage = m_BombDamage;
    m_BombDamage = tile.m_BombDamage;
    tile.m_BombDamage = tempBombDamage;
}

// return true if tile is a bomb
const bool Tile::isBomb(void) const
{
    bool bomb = false;

    if ( TILE_BOMB_1 == m_tile
      || TILE_BOMB_2 == m_tile
      || TILE_BOMB_3 == m_tile
      || TILE_BOMB_4 == m_tile
      || TILE_BOMB_5 == m_tile )
    {
        bomb = true;
    }

    return bomb;

}
