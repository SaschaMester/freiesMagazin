// *************************************************************************
// freiesMagazin-Programmierwettbewerb (ai)
// Copyright 2009 Frank Roth <frank.roth@stud.tu-ilmenau.de>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef BESTTILE_H
#define BESTTILE_H

#include "fieldpos.h"
#include "tile.h"
#include "scoredtile.h"

class BestTile: public Tile
{
   public:
      // constructor
      BestTile(void);
      BestTile(const BestTile& tile);

      // increases the number of counted Tiles
      void inc(void);
      void inc(const TileType tile);
      void inc(const ScoredTile tile);

      // set this tile to the maximum of them
      bool max(const BestTile& tile);

      unsigned int getCounter(void) const;
      unsigned int getBombDamageCounter(void) const;


   protected:
      unsigned int m_BombDamageCounter; // if BestTile is a Bomb, gets the Damage of them
      unsigned int m_Counter; // saves the Number of equal Tiles
};

class TileSwap
{
   public:
      // constructor
      TileSwap(void);
      TileSwap(const FieldPos& pos1, const FieldPos& pos2);


      void getSwapPos(FieldPos& pos1, FieldPos& pos2) const;
      void setSwapPos(const FieldPos& pos1, const FieldPos& pos2);
      unsigned int getSwapPosMinY(void) const;

      // calculates a score for Position
      void calcScore(const BestTile& row1, const BestTile& col1, const BestTile& row2, const BestTile& col2);

      // deletes score
      void clearScore();
      // adds the line to score
      void addScore(const BestTile& line);

      unsigned int getScoreYellow(void) const;
      unsigned int getScoreGreen(void) const;
      unsigned int getScoreRed(void) const;
      unsigned int getScoreLilac(void) const;
      unsigned int getScoreShield(void) const;
      unsigned int getScoreBomb(void) const;
      unsigned int getScoreBombDamage(void) const;
      float getScoreStoneDamage(void) const;

   protected:
      FieldPos m_Pos1;
      FieldPos m_Pos2;

      unsigned int m_ScoreYellow;
      unsigned int m_ScoreGreen;
      unsigned int m_ScoreRed;
      unsigned int m_ScoreLilac;
      unsigned int m_ScoreShield;
      unsigned int m_ScoreBombDamage;
      unsigned int m_ScoreBomb;
};

class BestSwaps
{
   public:
      // increases the number of counted Tiles
      // void inc(Tile tile);

      // set this tile to the maximum of them
      bool max(const TileSwap& tile);

      // get Tile of Best swap Position for ..
      TileSwap getBestYellow(void) const;
      TileSwap getBestGreen(void) const;
      TileSwap getBestRed(void) const;
      TileSwap getBestLilac(void) const;
      TileSwap getBestShield(void) const;
      TileSwap getBestBomb(void) const;
      TileSwap getBestBombDamage(void) const;
      TileSwap getBestStoneDamage(void) const;

      // if there is a StoneDamageCombination with Shield oder Lilac
      TileSwap getBestStoneDamageAndShield(void) const;
      TileSwap getBestStoneDamageAndLilac(void) const;

   protected:
      // stores the best known Swappos for Stones...
      TileSwap m_TileGreen;
      TileSwap m_TileYellow;
      TileSwap m_TileRed;
      TileSwap m_TileLilac;
      TileSwap m_TileShield;
      TileSwap m_TileBomb;
      TileSwap m_TileBombDamage;
      TileSwap m_TileStoneDamage;

      TileSwap m_TileStoneDamageAndShield;
      TileSwap m_TileStoneDamageAndLilac;

};

#endif // BESTTILE_H
