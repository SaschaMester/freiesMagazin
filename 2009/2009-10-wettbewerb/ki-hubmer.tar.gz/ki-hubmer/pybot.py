
# PyBot
# Version 1.1

# Copyright (C) 2009 Andreas Hubmer

# This program is free software; you can redistribute it and/or modify it 
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; version 3.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA


import sys
import random


class BotDiedException (Exception):
	"""In case the robot falls into a hole or off the field"""
	pass

MAX_DIST = 10000

WALLS = 'bcdefghijklmnop'
CONVEYORS = '<>^v'
MOVERS = 'CDEF'
PRESSES = 'MN'
ROTATORS = 'LR'
FIELDS = ' '*30 + 'H'*5 + 'O'*10 + CONVEYORS*5 + MOVERS*4 + PRESSES*4 + ROTATORS*5 + WALLS*2
FIELDS_OIL = ' '*30 + 'H'*2 + 'O'*20 + CONVEYORS*2 + MOVERS*2 + PRESSES*2 + ROTATORS*2 + WALLS	# for oil test

cardNames = {1: 'MF 1', 2: 'MF 2', 3: 'MF 3', 4: 'MB', 5: 'RL', 6: 'RR', 7: 'RU'}
cardNumbers = dict([v,k] for k,v in cardNames.iteritems())
directionNames = {0: 'U', 1: 'R', 2: 'D', 3: 'L'}
directionNumbers = dict([v,k] for k,v in directionNames.iteritems())

def loadCards(filename):
	"""load cards from a file. returns a list of card numbers"""
	f = open(filename, 'r')
	lines = f.readlines()
	f.close()
	for line in lines:
		if line[-1] == '\n':
			line = line[:-1]
	return [cardNumbers[x[:-1]] for x in lines]

def saveCards(filename, cards):
	"""saves a list of cards to a file. expects card numbers and writes card names to the file"""
	lines = [cardNames[card] + '\n' for card in cards]
	f = open(filename, 'w')
	f.writelines(lines)
	f.close()

class BotPosition:
	"""the position of a bot and its viewing direction"""
	def __init__(self, x, y, dir):
		self.x = x
		self.y = y
		self.dir = dir
	
	@classmethod
	def load(cls, filename):
		"""loads a bot position from a file"""
		f = open(filename, 'r')
		line = f.readline().split(' ')
		f.close()
		x = int(line[0])
		y = int(line[1])
		dir = line[2][0]
		dir = directionNumbers[dir]
		return cls(x, y, dir)

	def __str__(self):
		return "(%i, %i) looking %s" % (self.x, self.y, directionNames[self.dir])


def replaceAll(s, chars, replacement):
	"""replaces every character of chars in s by replacement"""
	for c in chars:
		s = s.replace(c, replacement)
	return s

def rotate(dir, card):
	"""rotates according to a card and returns the new viewing direction"""
	if card == 5:
		dir += 3
	elif card == 6:
		dir += 1
	elif card == 7:
		dir += 2
	return dir % 4

class Board:
	"""the playing field"""
	def __init__(self, width, height):
		self.width = width
		self.height = height
		self.fields = []
		for i in range(height):
			self.fields.append([])
			for _ in range(width):
				self.fields[i].append(' ')
		self.fields[0][0] = 'S'
		self.fields[width-1][height-1] = 'Z'
		self.goalx, self.goaly = self.goalPos()
		self.distances = DistanceCalculator(self).calcDistances()
	
	@classmethod
	def load(cls, filename):
		"""loads a board from a file"""
		b = cls(1,1)
		f = open(filename, 'r')
		line = f.readline().split(' ')
		b.width = int(line[0])
		b.height = int(line[1])
		b.fields = []
		for line in f.readlines():
			b.fields.append(replaceAll(line[:-1], 'STUVa', ' '))
			if len(b.fields[-1]) != b.width:
				raise Exception('Invalid line length')
		f.close()
		if len(b.fields) != b.height:
				raise Exception('Invalid number of lines')
		b.goalx, b.goaly = b.goalPos()
		b.distances = DistanceCalculator(b).calcDistances()
		return b
	
	def save(self, filename):
		f = open(filename, 'w')
		f.write(str(self.width))
		f.write(' ')
		f.write(str(self.height))
		f.write('\n')
		f.writelines(self.__str__())
		f.close()
	
	@classmethod
	def random(cls):
		"""Creates a random board of size 12x12"""
		b = cls(12,12)
		for y in range(b.height):
			for x in range(b.width):
				b.fields[y][x] = random.choice(FIELDS)
		b.fields[3][3] = 'T'
		b.fields[9][9] = 'Z'
		b.goalx, b.goaly = b.goalPos()
		return b
	
	@classmethod
	def randomOil(cls):
		"""Creates a random board for testing of oil fields of size 12x12"""
		b = cls(12,12)
		for y in range(b.height):
			for x in range(b.width):
				b.fields[y][x] = random.choice(FIELDS)
		b.fields[3][3] = 'T'
		b.fields[11][11] = 'Z'
		b.goalx, b.goaly = b.goalPos()
		return b
	
	def __str__(self):
		s = ''
		for y in range(self.height):
			for x in range(self.width):
				s = s + self.fields[y][x]
			s = s + '\n'
		return s
		
	def goalPos(self):
		"""searches for the goal field ('Z') and returns its coordinates"""
		for y,line in enumerate(self.fields):
			for x,val in enumerate(line):
				if val == 'Z':
					return (x,y)
		raise Exception('Board does not contain a goal.')
	
	def hasWallDown(self, x, y):
		'''returns True if the field x,y can not be entered from below'''
		if x<0 or y<0 or x>=self.width or y>=self.height:
			return False
		val = self.fields[y][x]
		if val == 'E' or val == 'N': return True
		if val >= 'a' and val <= 'p':
			val = ord(val) - ord('a')
			return bool(val & 8)
		return False
	
	def hasWallUp(self, x, y):
		'''returns True if the field x,y can not be entered from above'''
		if x<0 or y<0 or x>=self.width or y>=self.height:
			return False
		val = self.fields[y][x]
		if val == 'F' or val == 'N': return True
		if val >= 'a' and val <= 'p':
			val = ord(val) - ord('a')
			return bool(val & 4)
		return False
	
	def hasWallLeft(self, x, y):
		'''returns True if the field x,y can not be entered from left'''
		if x<0 or y<0 or x>=self.width or y>=self.height:
			return False
		val = self.fields[y][x]
		if val == 'D' or val == 'M': return True
		if val >= 'a' and val <= 'p':
			val = ord(val) - ord('a')
			return bool(val & 1)
		return False
	
	def hasWallRight(self, x, y):
		'''returns True if the field x,y can not be entered from right'''
		if x<0 or y<0 or x>=self.width or y>=self.height:
			return False
		val = self.fields[y][x]
		if val == 'C' or val == 'M': return True
		if val >= 'a' and val <= 'p':
			val = ord(val) - ord('a')
			return bool(val & 2)
		return False
	
	def goalDistance(self, pos):
		return self.distances[pos.y][pos.x][pos.dir]
		
	def playCard(self, pos, card):
		"""Plays a card and returns the new bot position.
		   The member variable passedGoal is set to true if the goal is reached. 
		   A BotDiedException is thrown in case the bot dies."""
		self.passedGoal = False
		if card >= 5:	# a rotation
			x = pos.x
			y = pos.y
			dir = rotate(pos.dir, card)
			if self.fields[y][x] == 'O': # rotate again on an oil field
				dir = rotate(dir, card)
		else:	# a movement
			repeat = 1
			if card >= 2 and card <= 3:
				repeat = card
				card = 1
			x,y,dir = (pos.x, pos.y, pos.dir)
			while repeat > 0:
				x,y = self.moveBot(x, y, dir, card==1)
				repeat -= 1
		
		# conveyors
		field = self.fields[y][x]
		if field == '^':
			x,y = self.moveBot(x, y, 0, True)
			dir = self.conveyorTurn(x, y, dir, 0)
		elif field == '>':
			x,y = self.moveBot(x, y, 1, True)
			dir = self.conveyorTurn(x, y, dir, 1)
		elif field == 'v':
			x,y = self.moveBot(x, y, 2, True)
			dir = self.conveyorTurn(x, y, dir, 2)
		elif field == '<':
			x,y = self.moveBot(x, y, 3, True)
			dir = self.conveyorTurn(x, y, dir, 3)
		
		# movers, press
		field = self.fields[y][x]
		if field == 'C':		# left
			x,y = self.moveBot(x, y, 3, True)
		elif field == 'D':		# right
			x,y = self.moveBot(x, y, 1, True)
		elif field == 'E':		# up
			x,y = self.moveBot(x, y, 0, True)
		elif field == 'F':		# down
			x,y = self.moveBot(x, y, 2, True)
		
		elif field == 'M' or field == 'N':		# press
			raise BotDiedException()
		
		# turning wheels
		field = self.fields[y][x]
		if field == 'L':
			dir = (dir-1) % 4
		elif field == 'R':
			dir = (dir+1) % 4
		
		return BotPosition(x,y,dir)
	
	def conveyorTurn(self, x, y, viewdir, movedir):
		"""turns the bot when it lands on another conveyor"""
		field = self.fields[y][x]
		if field == '^':
			if movedir == 1:
				viewdir = (viewdir+3)%4
			elif movedir == 3:
				viewdir = (viewdir+1)%4
		elif field == 'v':
			if movedir == 1:
				viewdir = (viewdir+1)%4
			elif movedir == 3:
				viewdir = (viewdir+3)%4
		elif field == '>':
			if movedir == 0:
				viewdir = (viewdir+1)%4
			elif movedir == 2:
				viewdir = (viewdir+3)%4
		elif field == '<':
			if movedir == 0:
				viewdir = (viewdir+3)%4
			elif movedir == 2:
				viewdir = (viewdir+1)%4
		return viewdir
	
	def moveBot(self, x,y, dir, forward):
		"""Only moves if possible (no wall) and only 1 step forward/back.
		   A BotDiedException may be thrown."""
		if not forward:
			dir = (dir+2) % 4
		if dir == 0:	# UP
			if self.hasWallUp(x,y) or self.hasWallDown(x,y-1):
				return (x,y)
			if y-1<0:
				#return (x,y)
				raise BotDiedException()
			y -= 1
		elif dir == 1:	# RIGHT
			if self.hasWallRight(x,y) or self.hasWallLeft(x+1,y):
				return (x,y)
			if x+1>=self.width: 
				#return (x,y)
				raise BotDiedException()
			x += 1
		elif dir == 2:	# DOWN
			if self.hasWallDown(x,y) or self.hasWallUp(x,y+1):
				return (x,y)
			if y+1>=self.height: 
				#return (x,y)
				raise BotDiedException()
			y += 1
		elif dir == 3:	# LEFT
			if self.hasWallLeft(x,y) or self.hasWallRight(x-1,y):
				return (x,y)
			if x-1<0: 
				#return (x,y)
				raise BotDiedException()
			x -= 1
		#if x<0 or y<0 or x>=self.width or y>=self.width:	# out of board
		#	raise BotDiedException()
		field = self.fields[y][x]
		if field == 'H':		# hole
			raise BotDiedException()
		elif field == 'Z':
			self.passedGoal = True
		elif field == 'O':
			return self.moveBot(x, y, dir, True)
		return (x,y)
		

CHECK_H = [(1,0),(2,0),(3,0),(1,1),(4,0),(2,1),(5,0),(3,1),(2,2)]
CHECK = []      # which "neighbor" fields are checked when calculating the distances
for x,y in CHECK_H:
	ext = [(x,y),(y,x), (-x,y),(-y,x), (x,-y),(y,-x), (-x,-y),(-y,-x)]
	for e in ext:
		if not e in CHECK:
			CHECK.append(e)

class DistanceCalculator:
	"""Calculates the distances to the target field"""
	def __init__(self, board):
		self.board = board
		
	def rOnly(self):
		"""for testing"""
		dRight = []
		for y in range(self.board.height):
			dRight.append([])
			for x in range(self.board.width):
				dRight[y].append(self.distances[y][x][1])
		return dRight

	def calcDistances(self):
		self.distances = []
		for y in range(self.board.height):
			self.distances.append([])
			for x in range(self.board.width):
				self.distances[y].append([MAX_DIST]*4)
		
		# start by setting distance of goal to 0
		self.distances[self.board.goaly][self.board.goalx] = [0]*4
			
		self.updated = [(self.board.goalx,self.board.goaly)]  # list of field coordinates that have been assigned better distance values
		while len(self.updated) > 0:
			x,y = self.updated.pop(0)
			for dx,dy in CHECK:  # check all neighbor fields again for shorter paths
				self.update(x, y, x+dx, y+dy)
		
		return self.distances
				
	def update(self, x, y, fromx, fromy):
		""""""
		
		if fromx < 0 or fromy < 0 or fromx >= self.board.width or fromy >= self.board.height or min(self.distances[fromy][fromx]) <= max(self.distances[y][x]) + 1:
			return   # we are off the board or cannot get better
		#if fromx == 11 and fromy == 4:
		#	import pdb; pdb.set_trace()
		changed = False
		for dir in range(4):
			for card in range(1,5):
				bot = BotPosition(fromx,fromy,dir)
				try:
					bot = self.board.playCard(bot,card)
					dist = self.distances[bot.y][bot.x][bot.dir]+1
					if dist < self.distances[fromy][fromx][dir]:
						self.distances[fromy][fromx][dir] = dist
						changed = True
				except BotDiedException:
					pass
		
		if changed:
			# update other directions as well
			f = self.board.fields[fromy][fromx]
			# if it is an oil field then we can only turn by 180 degrees
			if f == 'O':
				self.distances[fromy][fromx][0] = min(self.distances[fromy][fromx][0], self.distances[fromy][fromx][2]+1)
				self.distances[fromy][fromx][1] = min(self.distances[fromy][fromx][1], self.distances[fromy][fromx][3]+1)
				self.distances[fromy][fromx][2] = min(self.distances[fromy][fromx][2], self.distances[fromy][fromx][0]+1)
				self.distances[fromy][fromx][3] = min(self.distances[fromy][fromx][3], self.distances[fromy][fromx][1]+1)
			# if it is neither an oilfield nor a conveyor then we can turn to every other direction (given the appropriate card)
			# (ignoring the other special fields, because we cannot stop on them
			elif f not in CONVEYORS:
				mindist = min(self.distances[fromy][fromx])
				self.distances[fromy][fromx] = [min(mindist+1,dist) for dist in self.distances[fromy][fromx]]
			
			# add these coordinates to the list of changed coordinates
			coord = (fromx,fromy)
			if not coord in self.updated:
				self.updated.append(coord)


class CardChooser:
	"""Decides which of the 8 cards should be used.
	   Enumerates all possible card sequences and chooses the best one."""
	def __init__(self, board):
		self.board = board
	
	def findBest(self, cards, pos):
		self.bestdist = MAX_DIST+1
		self.bestpos = (-1,-1) 
		self.bestcards = cards[:5]
		
		self.enum(cards, [], pos)
		print cards, " -> ", self.bestcards
		return self.bestcards
	
	def enum(self, cards, ccards, pos):
		if len(ccards) == 5:		# a possible set of cards
			dist = self.board.goalDistance(pos)
			if dist < self.bestdist:
				self.bestdist = dist
				self.bestpos = pos
				self.bestcards = ccards
		else:	# still less than 5 cards
			for i,c in enumerate(cards):
				try:
					newpos = self.board.playCard(pos, c)
				except BotDiedException:
					continue   # useless sequence
				if self.board.passedGoal:
					dist = -4 + len(ccards)    # base distance on number of needed cards
					if dist < self.bestdist:
						self.bestdist = dist
						self.bestpos = newpos
						newcards = cards[0:i] + cards[i+1:]
						self.bestcards = ccards + [c] + newcards[:4-len(ccards)]
				else:
					newcards = cards[0:i] + cards[i+1:]
					newccards = ccards + [c]
					self.enum(newcards, newccards, newpos)


class Simulator:
	"""used for testing"""
	def __init__(self):
		self.board = Board.load('board.txt')
		self.bot = BotPosition(3,3,2)
		print self.bot
	
	def playBest(self, cards):
		if cards==None or cards==0:
			cards = ["MF 2", "RL", "MF 3", "MF 1", "RR", "MB", "RU", "MF 2"]
		cards = [cardNumbers[c] for c in cards]
		bestcards = CardChooser(self.board).findBest(cards, self.bot)
		print [cardNames[c] for c in bestcards]
	
	def play(self, card):
		try:
			self.bot = self.board.playCard(self.bot, card)
		except BotDiedException:
			print "		I don't want to die!"
		if self.board.passedGoal:
			print "		Passed the Goal!"
		print "positioned at:", self.bot


#CATEGORIES = {'easy':1, 'normal':2, 'hard':3}



def main():
	"""a round of the game"""
#	if len(sys.argv) > 1:
#		categoryName = sys.argv[1]
#		category = CATEGORIES[categoryName]
#	else:
#		category = 3
	
	cards = loadCards('cards.txt')
	if len(cards) != 8:
		raise Exception('Invalid number of cards')
	pos = BotPosition.load('bot.txt')
	print "Bot position: ", pos
	board = Board.load('board.txt')

	enum = CardChooser(board)
	bestcards = enum.findBest(cards, pos)
	#print "Chosen cards:", [cardNames[c] for c in bestcards]
	print "Predicted position:", enum.bestpos
	
	saveCards('ccards.txt', bestcards)


def analyse(filename):
	"""analyzes the distances and prints them - used for testing"""
	d = DistanceCalculator(Board.load(filename))
	dist = d.calcDistances()
	for dir in range(4):
		for row in dist:
			print [col[dir] for col in row]
		print ""

def createRandomBoards():
	"""used for testing"""
	for i in range(100):
		b = Board.randomOil()
		b.save('oilboards/board' + str(i) + '.dat')



if __name__ == '__main__':
	doMain = True
	if len(sys.argv) > 1:
		if sys.argv[1] == '-a':
			analyse(sys.argv[2])
			doMain = False
	
	if doMain:
		main()
