/*!
 * \file BoardBot.cpp
 * \brief Implementation of the BoardBot class.
 * \date 22.11.2009
 * \author Jan Gosmann <jan@hyper-world.de> with code based on code by
 *     Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
 */

/******************************************************************************
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU Lesser General Public License as            *
 *  published by the Free Software Foundation; either version 3 of the        *
 *  License, or (at your option) any later version.                           *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the              *
 *  GNU Lesser General Public License for more details.                       *
 *                                                                            *
 *  You should have received a copy of the GNU Lesser General Public          *
 *  License along with this program. If not, see                              *
 *  <http://www.gnu.org/licenses/>.                                           *
 ******************************************************************************/

#include "BoardBot.h"

#include <iostream>

#include <basefunctions.hh>
#include <botfunctions.hh>

////////////////////////////////////////////////////////////////////////////////
/// Checks whether \a move is a valid movement at the position the bot
/// is currently standing.
/// \author This function is heavily based on the a function in the game class
/// by Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>.
////////////////////////////////////////////////////////////////////////////////
bool BoardBot::isValidMovement( const std::string& move ) const
{
    bool valid = false;

    if ( "MF" == move || "MB" == move || "ML" == move ||
         "MR" == move || "MU" == move || "MD" == move )
    {
        // get new position if robot would move this way
        Position pos ( this->getPos() );
        Position newPos;

        if ( this->getNewPos( newPos, move,
                              this->board.getWidth(),
                              this->board.getHeight() ) )
        {
            if ( NULL != this->board[pos] && NULL != this->board[newPos] )
            {
                const BaseEnumDirection dir = BotFunctions::convertToDirection(
                    move, this->getViewDirection() );

                // check if field can be left and next entered
                if ( this->board[pos]->canLeave( dir ) &&
                     this->board[newPos]->canEnter( dir ) )
                {
                    valid = true;
                }
            }
        }
    }
    else if ( "RL" == move || "RR" == move || "RU" == move )
    {
        // rotations are okay
        valid = true;
    }
    else if ( "X" == move || "Z" == move )
    {
        // destroying or finish is okay
        valid = true;
    }
    else
    {
        std::cerr << "Game::isValidMovement(string) "
                  << "Error: Movement "
                  << move.c_str()
                  << " not recognized."
                  << std::endl;
    }

    return valid;
}

////////////////////////////////////////////////////////////////////////////////
/// Moves the bot at the board and applies all rules like moving tiles or holes.
/// \author This function is heavily based on the a function in the game class
/// by Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>.
////////////////////////////////////////////////////////////////////////////////
bool BoardBot::moveAtBoard( const Sequence& startSeq, const bool recursiveCall )
{
    bool moved = false;

    for( unsigned int i = 0; i < startSeq.size(); ++i )
    {
        // check if this movement is valid
        // means if there is a wall that would block the movement
        // or if we would leave the field ( = invisible wall )
        if( !this->isDestroyed() && !this->isFinished() )
        {
            if( isValidMovement( startSeq.at(i) ) )
            {
                moved = true;

                // move robot by itself
                this->move( startSeq.at(i),
                     this->board.getWidth(), this->board.getHeight() );

                // only if the movement is valid we will check the on entry
                const Position pos( this->getPos() );

                if( !this->isDestroyed() && !this->isFinished() &&
                    NULL != this->board[pos] )
                {
                    Sequence localSeq;

                    if( this->isLastMovement() )
                    {
                        // last action of the robot was a move
                        this->board[pos]->getSequenceOnEntry( localSeq,
                            this->getLastMovement() );
                    }
                    else if( this->isLastRotation() )
                    {
                        // a rotation on entry can only be done one time
                        if( !recursiveCall )
                        {
                            // last action was a rotation
                            this->board[pos]->getSequenceOnEntry( localSeq,
                                this->getLastRotation() );
                        }
                    }
                    else
                    {
                        std::cerr << "Game::generateSequenceAndMoveRobot() "
                                  << "Error: Last action of robot was "
                                  << "neither move nor rotation."
                                  << std::endl;
                    }

                    // move robot recursivly
                    moveAtBoard( localSeq, true );

                    // check if robot is dead
                }
            }
            else if( BE_GAME_LEVEL_HARD == BaseFunctions::getGameLevel() )
            {
                // game level is HARD, so we must check if the bot move
                // out of game board

                if( this->wouldLeaveBoard(
                    startSeq.at(i), this->board.getWidth(),
                    this->board.getHeight() ) )
                {
                    moved = true;
                    // robot is dead
                   this->move( "X", this->board.getWidth(),
                       this->board.getHeight() );
                }
            }
            // else we will ignore the movement
        }

    } // for

    // only in the first call we must check were there robot finally stands
    // and of course if the robot is not destroyed yet
    if( !recursiveCall )
    {
        bool isPushedByBelt = false;

        Position pos;

        // first phase: TE_PHASE_MOVE
        pos = this->getPos();
        if( !this->isDestroyed() && !this->isFinished() &&
            NULL != this->board[ pos ] )
        {
            Sequence localSeq;

            // get sequence for this robot when standing on this field
            this->board[pos]->getSequence( localSeq, TE_PHASE_MOVE );

            // move robot recursivly
            if( moveAtBoard(localSeq, true ) )
            {
                moved = true;
                isPushedByBelt = true;
            }
        }

        // second phase: TE_PHASE_PUSH
        pos = this->getPos();
        if( !this->isDestroyed() && !this->isFinished() &&
            NULL != this->board[ pos ] )
        {
            Sequence localSeq;

            // get sequence for this robot when standing on this field
            this->board[pos]->getSequence( localSeq, TE_PHASE_PUSH );

            // move robot recursivly
            if( moveAtBoard( localSeq, true ) )
            {
                moved = true;
                isPushedByBelt = false;
            }
        }

        // third phase: TE_PHASE_ROTATE
        pos = this->getPos();
        if( !this->isDestroyed() && !this->isFinished() &&
            NULL != this->board[ pos ] )
        {
            Sequence localSeq;

            // get sequence for this robot when standing on this field
            this->board[pos]->getSequence( localSeq, TE_PHASE_ROTATE );

            // move robot recursivly
            if( moveAtBoard( localSeq, true ) )
            {
                moved = true;
                isPushedByBelt = false;
            }
        }

        // fourth phase: Rotation on conveyor belt
        pos = this->getPos();
        if( !this->isDestroyed() && !this->isFinished() &&
            NULL != this->board[ pos ] )
        {
            if( this->isLastMovement() )
            {
                Sequence localSeq;

                // get sequence for this robot when standing on this field
                this->board[pos]->getSequenceOnEntry(
                    localSeq, this->getLastMovement(), isPushedByBelt );

                // move robot recursivly
                if( moveAtBoard( localSeq, true ) )
                {
                    moved = true;
                }
            }
        }
    }

    return moved;
}
