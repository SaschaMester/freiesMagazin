/*!
 * \file PreprocessedBoard.cpp
 * \brief Implementation of the preprocessing for the gameboard.
 * \date 09.10.2009
 * \author Jan Gosmann <jan@hyper-world.de>
 */

/******************************************************************************
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU Lesser General Public License as            *
 *  published by the Free Software Foundation; either version 3 of the        *
 *  License, or (at your option) any later version.                           *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the              *
 *  GNU Lesser General Public License for more details.                       *
 *                                                                            *
 *  You should have received a copy of the GNU Lesser General Public          *
 *  License along with this program. If not, see                              *
 *  <http://www.gnu.org/licenses/>.                                           *
 ******************************************************************************/

#include "PreprocessedBoard.h"

#include <climits>
#include <list>
#include <ostream>

using namespace std;

////////////////////////////////////////////////////////////////////////////////
/// Default constructor.
////////////////////////////////////////////////////////////////////////////////
PreprocessedBoard::PreprocessedBoard() :
    GameBoard(), recalculationNeeded( true )
{
}

////////////////////////////////////////////////////////////////////////////////
/// Create empty game board with \a width x  \a height fields.
////////////////////////////////////////////////////////////////////////////////
PreprocessedBoard::PreprocessedBoard( const unsigned int width,
    const unsigned int height ) :
    GameBoard( width, height ), recalculationNeeded( true )
{
}

////////////////////////////////////////////////////////////////////////////////
/// Copy constructor.
/// \a board Copy source.
////////////////////////////////////////////////////////////////////////////////
PreprocessedBoard::PreprocessedBoard( const GameBoard& board ) :
    GameBoard( board )
{
}

////////////////////////////////////////////////////////////////////////////////
/// Copy constructor. Copies also precalculated distances if still valid.
/// \a board Copy source.
////////////////////////////////////////////////////////////////////////////////
PreprocessedBoard::PreprocessedBoard( const PreprocessedBoard& board ) :
    GameBoard( board )
{
    this->recalculationNeeded = board.recalculationNeeded;
    if( !this->recalculationNeeded )
    {
        this->distance.clear();
        this->distance.insert( this->distance.begin(), board.distance.begin(),
            board.distance.end() );
    }
}

////////////////////////////////////////////////////////////////////////////////
/// Destructor.
////////////////////////////////////////////////////////////////////////////////
PreprocessedBoard::~PreprocessedBoard()
{
}

////////////////////////////////////////////////////////////////////////////////
/// Prints the board to the stream \a out. For a correct display the board
/// should have no more than 99 squares at each side and no field should have
/// a distance greater than 99.
////////////////////////////////////////////////////////////////////////////////
void PreprocessedBoard::printBoard( ostream &out )
{
    recalculateDistances();
    for( unsigned int i = 0; i < distance.size(); ++i )
    {
        if( i % getWidth() == 0 )
                        out << endl;
        if( distance[i] < 10 )
            out << " ";
        out << distance[i] << " ";
    }
}

////////////////////////////////////////////////////////////////////////////////
/// Recalculates the distances to the finish.
////////////////////////////////////////////////////////////////////////////////
void PreprocessedBoard::recalculateDistances()
{
    this->distance.clear();
    for( unsigned int i = 0; i < getWidth() * getHeight(); ++i )
        this->distance.push_back( UINT_MAX );

    list<Position> queue;
    this->distance[getEndPos().x() + getEndPos().y() * getWidth()] = 0;
    queue.push_back( getEndPos() );

    /* Breadth search */
    while( !queue.empty() )
    {
        const Position pos = queue.front();
        const Position left ( pos.x() - 1, pos.y() );
        const Position right( pos.x() + 1, pos.y() );
        const Position up   ( pos.x(),     pos.y() - 1 );
        const Position down ( pos.x(),     pos.y() + 1 );

        const unsigned int posIdx   = pos.x()   + pos.y()   * getWidth();
        const unsigned int leftIdx  = left.x()  + left.y()  * getWidth();
        const unsigned int rightIdx = right.x() + right.y() * getWidth();
        const unsigned int upIdx    = up.x()    + up.y()    * getWidth();
        const unsigned int downIdx  = down.x()  + down.y()  * getWidth();

        const unsigned int newDist = this->distance[posIdx] + 1;

        queue.pop_front();

        if( pos.x() > 0 && (*this)[pos]->canLeave( BE_DIRECTION_LEFT )
            && (*this)[left]->canEnter( BE_DIRECTION_LEFT )
            && newDist < this->distance[leftIdx] )
        {
            this->distance[leftIdx] = this->distance[posIdx] + 1;
            queue.push_back( left );
        }
        if( pos.x() < getWidth() - 1
            && (*this)[pos]->canLeave( BE_DIRECTION_RIGHT )
            && (*this)[right]->canEnter( BE_DIRECTION_RIGHT )
            && newDist < this->distance[rightIdx] )
        {
            this->distance[rightIdx] = this->distance[posIdx] + 1;
            queue.push_back( right );
        }
        if( pos.y() > 0 && (*this)[pos]->canLeave( BE_DIRECTION_UP )
            && (*this)[up]->canEnter( BE_DIRECTION_UP )
            && newDist < this->distance[upIdx] )
        {
            this->distance[upIdx] = this->distance[posIdx] + 1;
            queue.push_back( up );
        }
        if( pos.y() < getHeight() - 1
            && (*this)[pos]->canLeave( BE_DIRECTION_DOWN )
            && (*this)[down]->canEnter( BE_DIRECTION_DOWN )
            && newDist < this->distance[downIdx] )
        {
            this->distance[downIdx] = this->distance[posIdx] + 1;
            queue.push_back( down );
        }
    }
}
