/*!
 * \file main.cpp
 * \brief Program entry point, main control flow.
 * \date 08.10.2009
 * \author Jan Gosmann <jan@hyper-world.de>
 */

/*! \mainpage
 * AI for the game Robo-Rally for the programming competition by freiesMagazin
 * in fall 2009.
 */

/******************************************************************************
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU Lesser General Public License as            *
 *  published by the Free Software Foundation; either version 3 of the        *
 *  License, or (at your option) any later version.                           *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the              *
 *  GNU Lesser General Public License for more details.                       *
 *                                                                            *
 *  You should have received a copy of the GNU Lesser General Public          *
 *  License along with this program. If not, see                              *
 *  <http://www.gnu.org/licenses/>.                                           *
 ******************************************************************************/

#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <vector>

#include <limits.h>

#include <basefunctions.hh>
#include <botfunctions.hh>
#include <carddeck.hh>
#include <sequence.hh>

#include "BoardBot.h"
#include "PreprocessedBoard.h"

using namespace std;

////////////////////////////////////////////////////////////////////////////////
/// \return true if the ID of \a c1 is lower than the one of \a c2.
////////////////////////////////////////////////////////////////////////////////
bool compCardId( BaseCard *c1, BaseCard *c2 )
{
    return (c1->getId() < c2->getId());
}

////////////////////////////////////////////////////////////////////////////////
/// Function for rating the position of a \a bot at the board. The lower the
/// return value, the better. The rating depends mainly on the precalculated
/// distances of the board, but also on the facing of the bot.
/// The bot may get moved by this function.
////////////////////////////////////////////////////////////////////////////////
unsigned int rate( BoardBot &bot )
{
    if( bot.isFinished() )
        return 0;
    if( bot.isDestroyed() )
        return UINT_MAX;

    PreprocessedBoard &board = bot.getBoard();

    /* Distance */
    unsigned int rating = 10 * board.getDistance( bot.getPos() );

    /* Facing */
    if( bot.isValidMovement( "MF" ) )
    {
        Position newPos;
        if( bot.getNewPos( newPos, "MF", board.getWidth(), board.getHeight() ) )
        {
            rating += 5 * (board.getDistance( newPos )
                           - board.getDistance( bot.getPos() ));
        }
    }

    return rating;
}

////////////////////////////////////////////////////////////////////////////////
/// Program entry point. Main AI algorithm: Generate all permutations of cards,
/// move the bot and rate the position of the bot.
////////////////////////////////////////////////////////////////////////////////
int main( int argc, char *argv[] )
{
    if( argc < 2 )
        BaseFunctions::setGameLevel( BE_GAME_LEVEL_HARD );
    else if( argc == 2 )
        BaseFunctions::setGameLevel( argv[1] );
    else
    {
        cerr << "Usage: blubb-ai [game-level]" << endl;
        return EXIT_FAILURE;
    }

    PreprocessedBoard board;
    board.loadAscii( "board.txt" );

    CardDeck deck;
    deck.load( "cards.txt" );

    /* Prepare the permutation generation */
    vector<BaseCard *> cards;
    for( unsigned int i = 0; i < 8; ++i )
        cards.push_back( deck[i] );
    sort( cards.begin(), cards.end(), compCardId );

    unsigned int min = UINT_MAX;
    bool cardsChosen = false;
    CardDeck bestMoves( (const unsigned int) 5, true );
    do
    {
        BoardBot bot( board );
        bot.load( "bot.txt" );

        for( unsigned int i = 0; i < 5; ++i )
        {
            Sequence seq;
            cards[i]->getSequence( seq );
            bot.moveAtBoard( seq );
        }

        const unsigned int rating = rate( bot );
        if( rating < min || !cardsChosen )
        {
            cardsChosen = true;
            min = rating;
            for( unsigned int i = 0; i < 5; ++i )
                bestMoves.setCard( i, cards[i] );
        }
    } while( next_permutation( cards.begin(), cards.end(), compCardId ) );

    bestMoves.save( "ccards.txt", false );

    return EXIT_SUCCESS;
}
