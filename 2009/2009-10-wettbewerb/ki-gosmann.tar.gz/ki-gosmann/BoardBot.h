/*!
 * \file BoardBot.h
 * \brief Declaration of class for a bot moving on a certain board for blubb-ai.
 * \date 22.11.2009
 * \author Jan Gosmann <jan@hyper-world.de>
 */

/******************************************************************************
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU Lesser General Public License as            *
 *  published by the Free Software Foundation; either version 3 of the        *
 *  License, or (at your option) any later version.                           *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the              *
 *  GNU Lesser General Public License for more details.                       *
 *                                                                            *
 *  You should have received a copy of the GNU Lesser General Public          *
 *  License along with this program. If not, see                              *
 *  <http://www.gnu.org/licenses/>.                                           *
 ******************************************************************************/

#ifndef BOARDBOT_H_
#define BOARDBOT_H_

#include <bot.hh>

#include "PreprocessedBoard.h"

////////////////////////////////////////////////////////////////////////////////
/// Bot moving on a certain board, for blubb-ai.
////////////////////////////////////////////////////////////////////////////////
class BoardBot :
    public Bot
{
public:
    BoardBot( PreprocessedBoard &board ) : board( board ) { };
    virtual ~BoardBot() { };

    bool isValidMovement( const std::string& move ) const;

    /// Just a wrapper for
    /// moveAtBoard(const Sequence &startSeq, const bool recursiveCall) adding
    /// the recursive Call argument.
    inline bool moveAtBoard( const Sequence& startSeq )
    {
        return moveAtBoard( startSeq, false );
    }

    inline PreprocessedBoard &getBoard() const
    {
        return this->board;
    }

protected:
    bool moveAtBoard( const Sequence& startSeq, const bool recursiveCall );

private:
    PreprocessedBoard &board;
};

#endif /* BOARDBOT_H_ */
