/*!
 * \file PreprocessedBoard.h
 * \brief GameBoard class with preprocessing for blubb-ai
 * \date 09.10.2009
 * \author Jan Gosmann >jan@hyper-world.de>
 */

/******************************************************************************
 *  This program is free software; you can redistribute it and/or modify      *
 *  it under the terms of the GNU Lesser General Public License as            *
 *  published by the Free Software Foundation; either version 3 of the        *
 *  License, or (at your option) any later version.                           *
 *                                                                            *
 *  This program is distributed in the hope that it will be useful,           *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the              *
 *  GNU Lesser General Public License for more details.                       *
 *                                                                            *
 *  You should have received a copy of the GNU Lesser General Public          *
 *  License along with this program. If not, see                              *
 *  <http://www.gnu.org/licenses/>.                                           *
 ******************************************************************************/

#ifndef PREPROCESSEDBOARD_H_
#define PREPROCESSEDBOARD_H_

#include "gameboard.hh"

#include <ostream>
#include <vector>

////////////////////////////////////////////////////////////////////////////////
/// Derived of GameBoard and allows to access precalculated distance values
/// (relative to the finish). Precalculation will be done when the \ref distance
/// vector is accessed the first time after a change of the board.
////////////////////////////////////////////////////////////////////////////////
class PreprocessedBoard :
    public GameBoard
{
public:
    PreprocessedBoard();
    PreprocessedBoard( const unsigned int width, const unsigned int height );
    PreprocessedBoard( const GameBoard& board );
    PreprocessedBoard( const PreprocessedBoard& board );
    virtual ~PreprocessedBoard();

    inline unsigned int getDistance( const Position &p )
    {
        if( recalculationNeeded )
            recalculateDistances();
        return this->distance.at(p.x()+p.y()*getWidth());
    }

    void printBoard( std::ostream &out );


protected:
    void recalculateDistances();

private:
    /** Distances in fields still to move to reach the finish. */
    std::vector<unsigned int> distance;
    /** Has \ref distance to be recalculated before the next access? */
    bool recalculationNeeded;
};

#endif /* PREPROCESSEDBOARD_H_ */
