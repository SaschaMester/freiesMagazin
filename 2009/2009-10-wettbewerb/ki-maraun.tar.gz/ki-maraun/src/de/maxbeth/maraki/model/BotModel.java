/*
 * Copyright (c) 2009 by M. Maraun.
 *
 *     This file is part of Maraki.
 *
 *     Maraki is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     Maraki is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with Maraki.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.maxbeth.maraki.model;

import com.sun.xml.internal.messaging.saaj.packaging.mime.util.LineInputStream;
import de.maxbeth.maraki.tools.Converter;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.StringTokenizer;

public class BotModel {
    private int x;
    private int y;
    private String richtung = "";

    public BotModel(int x, int y, String richtung) {
        this.x = x;
        this.y = y;
        this.richtung = richtung;
    }

    public BotModel(String s) {
        InputStream is = null;
        try {
            is = new FileInputStream(s);
            LineInputStream lis = new LineInputStream(is);
            String inputx = lis.readLine();
            StringTokenizer st = new StringTokenizer(inputx, " ");
            x = Integer.parseInt(st.nextToken());
            y = Integer.parseInt(st.nextToken());
            richtung = st.nextToken();
//            System.out.println("bot.txt:" + inputx);
            lis.close();
            is.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public String getRichtung() {
        return richtung;
    }

    public void drehe(int rotiere, char feld) {
        // Auf dem Öl dreht es sich gleich doppelt so gut
        if (feld == FieldModel.OEL) {
            rotiere = (rotiere + rotiere) & 3;
        }
        int sollint = (Converter.convertRichtung(richtung) + rotiere) & 3;
        richtung = Converter.convertRichtungString(sollint);
    }

    public static BotModel clone(BotModel botx) {
        BotModel bm = new BotModel(botx.getX(), botx.getY(), botx.getRichtung());
        return bm;
    }

    public void move(int anzahl, String richtung) {
        if (richtung.equals("D")) y += anzahl;
        if (richtung.equals("U")) y -= anzahl;
        if (richtung.equals("L")) x -= anzahl;
        if (richtung.equals("R")) x += anzahl;
    }
}
