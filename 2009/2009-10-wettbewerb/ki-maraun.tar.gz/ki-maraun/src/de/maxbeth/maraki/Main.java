/*
 * Copyright (c) 2009 by M. Maraun.
 *
 *     This file is part of Maraki.
 *
 *     Maraki is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     Maraki is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with Maraki.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.maxbeth.maraki;

import de.maxbeth.maraki.ki.PacManXXL;
import de.maxbeth.maraki.model.*;

import java.io.File;
import java.util.Date;

public class Main {

    public static void main(String[] args) {

//        Date startx = new Date();
//        System.out.println("" + startx);
        long startx = new Date().getTime();
//            System.out.println("0:" + startx);
        BotModel bm = new BotModel("bot.txt");
        MapModel mm = new MapModel("board.txt");
//            System.out.println(" 1:" + (new Date().getTime() - startx));
        KartenModel km = new KartenModel("cards.txt");

        EntfernungsSchichtModel esm = new EntfernungsSchichtModel(mm.getX(), mm.getY());
        File file2 = new File("entfernung" + mm.getChecksum() + ".bin");
        // Entfernungsfile nur nehmen falls maximal 90 Sekunden alt ;-)
        if (file2.exists() && (new Date().getTime() - file2.lastModified())  < 90000){
            esm.loadFile(file2, mm);
        } else {
            esm.leseMap(mm);
            esm.writeFile(file2);
        }

//            System.out.println(" 2:" + (new Date().getTime() - startx));
        PacManXXL ki = new PacManXXL(bm, km, mm, esm);

//            System.out.println(" 3:" + (new Date().getTime()- startx));
        AktionenModel am = new AktionenModel();
        am.setAktionen(ki.berechne());

//            System.out.println(" 4:" + (new Date().getTime()-startx));
        am.sichern();

//        esm.writeFile(file2);
//        System.out.println("Dauer:" + (new Date().getTime() - startx.getTime()));

        System.exit(0);
    }
}
