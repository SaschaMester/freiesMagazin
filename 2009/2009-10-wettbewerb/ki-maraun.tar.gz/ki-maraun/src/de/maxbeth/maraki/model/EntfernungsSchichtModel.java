/*
 * Copyright (c) 2009 by M. Maraun.
 *
 *     This file is part of Maraki.
 *
 *     Maraki is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     Maraki is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with Maraki.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.maxbeth.maraki.model;

import de.maxbeth.maraki.constants.Richtungen;

import java.awt.*;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Hier wird zu einer Karte an jedem Punkt die Entfernung zum Ziel abgelegt.
 */
public class EntfernungsSchichtModel {
    Integer[][] anzahl;
    private int feldx;
    private int feldy;

    public EntfernungsSchichtModel(int feldx, int feldy) {
        this.feldx = feldx;
        this.feldy = feldy;
        anzahl = new Integer[feldx][feldy];
        for (int x = 0; x < feldx; x++) {
            for (int y = 0; y < feldy; y++) {
                anzahl[x][y] = -1;
            }
        }
    }

    public void leseMap(MapModel map) {

        // TODO Unmöglichkeiten blockieren
        for (int x1=0; x1<map.getX(); x1++) {
            for (int y1=0; y1<map.getY(); y1++) {
                char field = map.getField(x1, y1);
                if (field == FieldModel.SCHIEBLINKS) {
                    if (x1 > 0) {
                        map.setBlock(x1-1,y1,FieldModel.WAND_RECHTS);
                    }
                } else if (field == FieldModel.SCHIEBRECHTS) {
                    if (x1 +1 < map.getX())
                        map.setBlock(x1+1,y1,FieldModel.WAND_LINKS);
                } else if (field == FieldModel.SCHIEBOBEN) {
                    if (y1 > 0)
                        map.setBlock(x1,y1-1,FieldModel.WAND_UNTEN);
                } else if (field == FieldModel.SCHIEBUNTEN) {
                    if (y1 +1 < map.getY())
                        map.setBlock(x1,y1+1,FieldModel.WAND_OBEN);
                } else if (field == FieldModel.BANDLINKS) {
//                    if (x1 > 0 && map.gehtes(Richtungen.RIGHT, x1, y1, true) != 1) {
//                        map.setBlock(x1-1,y1,FieldModel.WAND_RECHTS);
//                    }
                } else if (field == FieldModel.BANDRECHTS) {
                } else if (field == FieldModel.BANDHOCH) {
                    if (y1 > 0 && map.gehtes(Richtungen.DOWN, x1, y1, true) != 1) {
                        map.setBlock(x1,y1-1,FieldModel.WAND_UNTEN);
                    }
                } else if (field == FieldModel.BANDRUNTER) {

                }
            }
        }

        Point px = new Point(map.getZielx(), map.getZiely());
        int entfernung = 0;
        anzahl[map.getZielx()][map.getZiely()] = entfernung;
        List<Point> checkthis = new ArrayList<Point>();
        checkthis.add(px);
        while (checkthis.size() > 0) {
            List<Point> newpoints = new ArrayList<Point>();
            for (Point punkt : checkthis) {
                // Nur unbenutzte Punkte nehmen
                Point np = null;
                if (entfernung == anzahl[punkt.x][punkt.y]) {
                    if (map.gehtes(Richtungen.UP, punkt.x, punkt.y, false) == 1) {
                        char f_up = map.getField(punkt.x, punkt.y - 1);
                        if (f_up == FieldModel.BANDRUNTER) {
                            np = setEntfernung(punkt.x, punkt.y - 1, entfernung + 1);
                        } else if (f_up == FieldModel.BANDHOCH) {
                            np = setEntfernung(punkt.x, punkt.y - 1, entfernung + 5);
                        } else {
                            if (f_up == FieldModel.OEL) {
                                np = setEntfernung(punkt.x, punkt.y - 1, entfernung + 100);
                            } else {
                                np = setEntfernung(punkt.x, punkt.y - 1, entfernung + 3);
                            }
                        }

                        if (np != null) newpoints.add(np);
                        checkOil(Richtungen.UP,0,-1, punkt.x,punkt.y, newpoints,map, entfernung + 1);
                    }
                    if (map.gehtes(Richtungen.DOWN, punkt.x, punkt.y, false) == 1) {
                        char f_down = map.getField(punkt.x, punkt.y + 1);
                        if (f_down == FieldModel.BANDHOCH) {
                            np = setEntfernung(punkt.x, punkt.y + 1, entfernung + 1);
                        } else if (f_down == FieldModel.BANDRUNTER) {
                            np = setEntfernung(punkt.x, punkt.y + 1, entfernung + 5);
                        } else {
                            if (f_down == FieldModel.OEL) {
                                np = setEntfernung(punkt.x, punkt.y + 1, entfernung + 100);
                            } else {
                                np = setEntfernung(punkt.x, punkt.y + 1, entfernung + 3);
                            }
                        }
                        if (np != null) newpoints.add(np);
                        checkOil(Richtungen.DOWN,0,1, punkt.x,punkt.y, newpoints,map, entfernung + 1);
                    }
                    if (map.gehtes(Richtungen.LEFT, punkt.x, punkt.y, false) == 1) {
                        char f_left = map.getField(punkt.x - 1, punkt.y);
                        if (f_left == FieldModel.BANDRECHTS) {
                            np = setEntfernung(punkt.x - 1, punkt.y, entfernung + 1);
                        } else if (f_left == FieldModel.BANDLINKS) {
                            np = setEntfernung(punkt.x - 1, punkt.y, entfernung + 5);
                        } else {
                            if (f_left == FieldModel.OEL) {
                                np = setEntfernung(punkt.x - 1, punkt.y, entfernung + 100);
                            } else {
                                np = setEntfernung(punkt.x - 1, punkt.y, entfernung + 3);
                            }
                        }
                        if (np != null) newpoints.add(np);
                        checkOil(Richtungen.LEFT,-1,0, punkt.x,punkt.y, newpoints,map,entfernung + 1);
                    }
                    if (map.gehtes(Richtungen.RIGHT, punkt.x, punkt.y, false) == 1) {
                        char f_right = map.getField(punkt.x + 1, punkt.y);
                        if (f_right == FieldModel.BANDLINKS) {
                            np = setEntfernung(punkt.x + 1, punkt.y, entfernung + 1);
                        } else if (f_right == FieldModel.BANDRECHTS) {
                            np = setEntfernung(punkt.x + 1, punkt.y, entfernung + 5);
                        } else {
                            if (f_right == FieldModel.OEL) {
                                np = setEntfernung(punkt.x + 1, punkt.y, entfernung + 100);
                            } else {
                                np = setEntfernung(punkt.x + 1, punkt.y, entfernung + 3);
                            }
                        }
                        if (np != null) newpoints.add(np);
                        checkOil(Richtungen.RIGHT,1,0, punkt.x,punkt.y, newpoints,map, entfernung + 1);
                    }
                } else {
                    newpoints.add(punkt);   // Warteschlange erweitern, da Entfernung zu hoch.
                }
            }
            checkthis = newpoints;
            entfernung++;
//            System.out.println("Punkt:" + newpoints.size() + " entfernung:" + entfernung);
//            showEntfernung(map);
        }

        // Förderbänder neben Abgründen usw schlechter bewerten.
        for (int x1=0; x1<map.getX(); x1++) {
            for (int y1=0; y1<map.getY(); y1++) {
                if (map.getField(x1, y1) == FieldModel.BANDLINKS) {
                    if (x1 == 0) {
                        anzahl[x1][y1] += 5;
                    } else if (x1+1<map.getX() && map.getField(x1+1, y1) == FieldModel.BANDLINKS) {
                        anzahl[x1+1][y1] += 3;
                    }
                } else if (map.getField(x1, y1) == FieldModel.BANDRECHTS) {
                    if ((x1+1) == map.getX()) {
                        anzahl[x1][y1] += 5;
                    } else if (x1>0 && map.getField(x1-1, y1) == FieldModel.BANDRECHTS) {
                        anzahl[x1-1][y1] += 3;
                    }
                } else if (map.getField(x1, y1) == FieldModel.BANDRUNTER) {
                    if ((y1+1) == map.getY()) {
                        anzahl[x1][y1] += 5;
                    } else if (y1+1<map.getY() && map.getField(x1, y1+1) == FieldModel.BANDRUNTER) {
                        anzahl[x1][y1+1] += 3;
                    }
                } else if (map.getField(x1, y1) == FieldModel.BANDHOCH) {
                    if (y1 == 0) {
                        anzahl[x1][y1] += 5;
                    } else if (y1+1<map.getY() && map.getField(x1, y1+1) == FieldModel.BANDHOCH) {
                        anzahl[x1][y1+1] += 3;
                    }
                }
            }
        }
//        showEntfernung(map);
    }

    private void checkOil(String richtung, int xd, int yd, int aktx, int akty, List<Point> newpoints, MapModel map, int entfernung) {
        int maxx = map.getX()-1;
        int maxy = map.getY()-1;

        if (map.gehtes(richtung, aktx, akty, false) != 1) {
            return;
        }
        aktx += xd;
        akty += yd;
        if (!(aktx >= 0 && akty >= 0 && aktx <= maxx && akty <= maxy))
            return;
        char nextfeld = map.getField(aktx, akty);
        if (nextfeld != FieldModel.OEL)
            return;
        aktx -= xd;
        akty -= yd;

        while (true) {
            aktx += xd;
            akty += yd;
            if (aktx >= 0 && akty >= 0 && aktx <= maxx && akty <= maxy) {
                nextfeld = map.getField(aktx, akty);
                if (nextfeld == FieldModel.OEL) {
                    if (map.gehtes(richtung, aktx, akty, false) == 1) {
                        continue;   // Ölrutsche
                    } else {
                        return; // Letztes Feld ist ein Ölfeld, blöd
                    }
                } else if (nextfeld == FieldModel.FREI || nextfeld == FieldModel.LINKSDREH
                        || nextfeld == FieldModel.RECHTSDREH || nextfeld == FieldModel.ZIEL || (nextfeld >= 'a' && nextfeld <= 'p')
                        || nextfeld == FieldModel.BANDHOCH || nextfeld == FieldModel.BANDRUNTER
                        || nextfeld == FieldModel.BANDLINKS || nextfeld == FieldModel.BANDRECHTS
                        || nextfeld == FieldModel.PRESSELINKSRECHTS || nextfeld == FieldModel.PRESSEOBENUNTEN) {
                    Point np = setEntfernung(aktx, akty, entfernung);
                    if (np != null)
                        newpoints.add(np);
                    break;
                } else {
                    Point np = setEntfernung(aktx, akty, entfernung+5);
                    if (np != null)
                        newpoints.add(np);
                    break;
                }
            } else {
                break;  //Spielfeldgrenze
            }
        }
    }

    private Point setEntfernung(int x, int y, int entfernung) {
        if (anzahl[x][y] > entfernung || anzahl[x][y] == -1) {
            anzahl[x][y] = entfernung;
            return new Point(x, y);
        }
        return null;
    }

    private void showEntfernung(MapModel map) {
        for (int y = 0; y < feldy; y++) {
            for (int x = 0; x < feldx; x++) {
                Integer cx = anzahl[x][y];
                if (cx >99) System.out.print(" " + cx);
                else if (cx >9 || cx <0) System.out.print("  " + cx);
                else System.out.print("   " + cx);
                System.out.print("-" + map.getBlock(x,y));
            }
            System.out.println();
        }
    }

    public int get(int x, int y) {
        return anzahl[x][y];
    }

    public void writeFile(File file2) {
        try {
            FileWriter fw = new FileWriter(file2);
            for (int x = 0; x < feldx; x++) {
                for (int y = 0; y < feldy; y++) {
                    fw.write(anzahl[x][y]);
                }
            }
            fw.close();
            System.out.println(">>> Schreibe Datei...");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void loadFile(File file2, MapModel map) {
        try {
            FileReader fr = new FileReader(file2);
            for (int x = 0; x < feldx; x++) {
                for (int y = 0; y < feldy; y++) {
                    anzahl[x][y] = fr.read();
                }
            }
            fr.close();
        } catch (IOException e) {
            e.printStackTrace();
            leseMap(map);
        }
    }

    public void increase(int x, int y) {
        anzahl[x][y]++;
    }
}
