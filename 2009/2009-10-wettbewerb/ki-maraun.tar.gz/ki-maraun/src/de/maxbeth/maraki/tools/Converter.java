/*
 * Copyright (c) 2009 by M. Maraun.
 *
 *     This file is part of Maraki.
 *
 *     Maraki is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     Maraki is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with Maraki.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.maxbeth.maraki.tools;

import de.maxbeth.maraki.constants.Richtungen;
import de.maxbeth.maraki.model.FieldModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Nützliche Routinen
 */
public class Converter {

    static public int convertRichtung(String richtung) {
        if (richtung.equals(Richtungen.UP)) {
            return 0;
        } else if (richtung.equals(Richtungen.DOWN)) {
            return 2;
        } else if (richtung.equals(Richtungen.RIGHT)) {
            return 1;
        } else if (richtung.equals(Richtungen.LEFT)) {
            return 3;
        }
        throw new IllegalArgumentException("Unbekannte Richtung: " + richtung);
    }

    static public String convertRichtungString(int richtung) {
        if (richtung == 0) return Richtungen.UP;
        if (richtung == 1) return Richtungen.RIGHT;
        if (richtung == 2) return Richtungen.DOWN;
        if (richtung == 3) return Richtungen.LEFT;
        throw new IllegalArgumentException("Unbekannte Richtung: " + richtung);
    }

    static public int convertKarte(String karte) {
        if (karte.equals("MF 1")) {
            return 1;
        } else if (karte.equals("MF 2")) {
            return 2;
        } else if (karte.equals("MF 3")) {
            return 3;
        } else if (karte.equals("MB")) {
            return 4;
        } else if (karte.equals("RL")) {
            return 5;
        } else if (karte.equals("RR")) {
            return 6;
        } else if (karte.equals("RU")) {
            return 7;
        }
        throw new IllegalArgumentException("Unbekannte Karte: " + karte);
    }

    static public String outputKarte(int karte) {
//        return Integer.toString(karte);
        if (karte == 1) {
            return "MF 1";
        }
        if (karte == 2) {
            return "MF 2";
        }
        if (karte == 3) {
            return "MF 3";
        }
        if (karte == 4) {
            return "MB";
        }
        if (karte == 5) {
            return "RL";
        }
        if (karte == 6) {
            return "RR";
        }
        if (karte == 7) {
            return "RU";
        }
        throw new IllegalArgumentException("Unbekannte Karte: " + karte);
    }

    public static List<String> intToMove(Integer[] movements) {
        List<String> lx = new ArrayList<String>();
        for (Integer ix : movements) {
            lx.add(0, outputKarte(ix));
        }
        return lx;
    }

    public static String schieberichtung(char charx) {
        if (charx == FieldModel.BANDHOCH || charx == FieldModel.SCHIEBOBEN) return "U";
        if (charx == FieldModel.BANDLINKS || charx == FieldModel.SCHIEBLINKS) return "L";
        if (charx == FieldModel.BANDRECHTS || charx == FieldModel.SCHIEBRECHTS) return "R";
        if (charx == FieldModel.BANDRUNTER || charx == FieldModel.SCHIEBUNTEN) return "D";
        return "";
    }
}
