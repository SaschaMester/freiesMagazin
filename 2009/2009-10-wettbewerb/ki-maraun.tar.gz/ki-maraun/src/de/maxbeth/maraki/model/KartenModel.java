/*
 * Copyright (c) 2009 by M. Maraun.
 *
 *     This file is part of Maraki.
 *
 *     Maraki is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     Maraki is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with Maraki.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.maxbeth.maraki.model;

import com.sun.xml.internal.messaging.saaj.packaging.mime.util.LineInputStream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class KartenModel {
    private List<String> karten;

    public KartenModel(String s) {
        InputStream is = null;
        karten = new ArrayList<String>();
        try {
            is = new FileInputStream(s);
            LineInputStream lis = new LineInputStream(is);
            String lx;
            while ((lx = lis.readLine()) != null) {
                karten.add(lx);
                if (karten.size() > 8) {
                    break;
                }
            }
            lis.close();
            is.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public List<String> getKarten() {
        return karten;
    }
}
 