/*
 * Copyright (c) 2009 by M. Maraun.
 *
 *     This file is part of Maraki.
 *
 *     Maraki is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     Maraki is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with Maraki.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.maxbeth.maraki;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;


public class ServerMain {
    private final ServerSocket server;

    public ServerMain(int port) throws IOException {
        server = new ServerSocket(port);
    }

    private void startServing() {
        while (true) {
            Socket client = null;
            try {
                client = server.accept();
                handleConnection(client);
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            finally {
                if (client != null)
                    try {
                        client.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
            }
        }
    }

    private void handleConnection(Socket client) throws IOException {
        InputStream in = client.getInputStream();
        OutputStream out = client.getOutputStream();
        int factor1 = in.read();
        int factor2 = in.read();
        out.write(factor1 * factor2);
    }

    public static void main(String[] args) throws IOException {
        ServerMain server = new ServerMain(3141);
        server.startServing();
    }

}
