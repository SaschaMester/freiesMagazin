/*
 * Copyright (c) 2009 by M. Maraun.
 *
 *     This file is part of Maraki.
 *
 *     Maraki is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     Maraki is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with Maraki.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.maxbeth.maraki.model;

/**
 * Created by IntelliJ IDEA.
 * User: momme
 * Date: 07.10.2009
 * Time: 20:13:00
 * To change this template use File | Settings | File Templates.
 */
public class FieldModel {
    static public char FREI = ' ';
    static public char LOCH = 'H';
    static public char OEL = 'O';
    static public char LINKSDREH = 'L';
    static public char RECHTSDREH = 'R';
    static public char BANDLINKS = '<';
    static public char BANDRECHTS = '>';
    static public char BANDHOCH = '^';
    static public char BANDRUNTER = 'v';
    static public char SCHIEBLINKS = 'C';
    static public char SCHIEBRECHTS = 'D';
    static public char SCHIEBOBEN = 'E';
    static public char SCHIEBUNTEN = 'F';
    static public char PRESSELINKSRECHTS = 'M';
    static public char PRESSEOBENUNTEN = 'N';
    static public char ROBOT1 = 'S';
    static public char ROBOT2 = 'T';
    static public char ROBOT3 = 'U';
    static public char ROBOT4 = 'V';
    static public char ZIEL = 'Z';

    static public char WANDL = 'a';
    static public char WANDR = 'b';
    static public char WANDLR = 'c';
    static public char WANDO = 'd';
    static public char WANDLO = 'e';
    static public char WANDRO = 'f';
    static public char WANDLRO = 'g';
    static public char WANDU = 'h';
    static public char WANDLU = 'i';
    static public char WANDRU = 'j';
    static public char WANDLRU = 'k';
    static public char WANDOU = 'l';
    static public char WANDLOU = 'm';
    static public char WANDROU = 'n';
    static public char WANDLROU = 'o';

    static public int WAND_LINKS = 1;
    static public int WAND_RECHTS = 2;
    static public int WAND_OBEN = 4;
    static public int WAND_UNTEN = 8;

}

/**
 Leerzeichen 	leerer Boden
 H 	Loch
 O 	Öl
 S, T, U, V 	Startfeld des Roboters (für die KI irrelevant, als leeres Bodenfeld behandeln)
 Z 	Zielfeld für den Roboter

 L 	dreht den Roboter 90° gegen den Uhrzeigersinn
 R 	dreht den Roboter 90° im Uhrzeigersinn

 < 	Förderband nach links
 > 	Förderband nach rechts
 ^ 	Förderband nach oben
 v 	Förderband nach unten

 C 	schiebt den Roboter ein Feld nach links
 D 	schiebt den Roboter ein Feld nach rechts
 E 	schiebt den Roboter ein Feld nach oben
 F 	schiebt den Roboter ein Feld nach unten
 M 	Links/Rechts-Schrottpresse
 N 	Oben/Unten Schrottpresse

 a-p 	definiert eine Wand/mehrere Wände pro Feld

 Die Definition der Wände ist binärkodiert, dass heißt:

 * Wand links = 1
 * Wand rechts = 2
 * Wand oben = 4
 * Wand unten = 8
 **/