/*
 * Copyright (c) 2009 by M. Maraun.
 *
 *     This file is part of Maraki.
 *
 *     Maraki is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     Maraki is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with Maraki.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.maxbeth.maraki.ki;

import de.maxbeth.maraki.model.BotModel;
import de.maxbeth.maraki.model.KartenModel;
import de.maxbeth.maraki.model.MapModel;
import de.maxbeth.maraki.tools.Converter;

import java.util.ArrayList;
import java.util.List;

public class PacManLight {

    BotModel botx;
    KartenModel karten;
    MapModel landkarte;

    public PacManLight(BotModel botx, KartenModel karten, MapModel landkarte) {
        this.botx = botx;
        this.karten = karten;
        this.landkarte = landkarte;

    }

    public List<String> berechne() {


        List<String> reststapel = karten.getKarten().subList(0, 8);

        List<String> aktionen = new ArrayList<String>();

        // Flagge ist bei 11,11

        int flagx = 11;
        int flagy = 11;

        //  X ist größer, daher versuchen nach rechts zu drehem und laufen
        boolean firstx = (flagx - botx.getX()) > ((flagy - botx.getY()));
        String botdir = botx.getRichtung();
        if (firstx) {
            botdir = drehundrenne(botdir, "R", reststapel, aktionen);
        }
        if (aktionen.size() == 0) {     // Ansonsten nach unten drehen und laufen
            botdir = drehundrenne(botdir, "D", reststapel, aktionen);
        }
        if (!firstx && aktionen.size() == 0) {
            botdir = drehundrenne(botdir, "R", reststapel, aktionen);
        }
        // Aktionen bis auf 5 auffüllen
        int vorhanden = aktionen.size();
        if (vorhanden == 0) {
            System.out.println("ZUFALL !!!");
        }
        aktionen.addAll(reststapel.subList(0, 5 - aktionen.size()));

        return aktionen;
    }

    private String drehundrenne(String botdir, String xxx, List<String> reststapel, List<String> aktionen) {
        if (!botdir.equals(xxx)) {
            String drehung = rotiereauf(xxx, botx.getRichtung(), reststapel);
            if (drehung != null) {
                aktionen.add(drehung);
                reststapel.remove(drehung);
            } else {
                return botdir;
            }
        }
        while (aktionen.size() < 5) {
            String bewegung = renne(reststapel);
            if (bewegung != null) {
                aktionen.add(bewegung);
                reststapel.remove(bewegung);
            } else {
                return xxx;
            }
        }
        return xxx;
    }

    private String rotiereauf(String soll, String ist, List<String> reststapel) {
        int sollint = Converter.convertRichtung(soll);
        int istint = Converter.convertRichtung(ist);

        if (sollint == istint) {
            return null;
        }

        int diff = (sollint - istint) & 3;

        // RR +1,  RL +3, RU +2
        List<Integer> drehlst = new ArrayList<Integer>();
        for (String dreh : reststapel) {
            if (dreh.equals("RR")) {
                if (diff == 1) {
                    return dreh;
                }
                drehlst.add(1);
            } else if (dreh.equals("RU")) {
                if (diff == 2) {
                    return dreh;
                }
                drehlst.add(2);
            } else if (dreh.equals("RL")) {
                if (diff == 3) {
                    return dreh;
                }
                drehlst.add(3);
            }
        }
        // TODO eventuell müssen zwei Karten kombiniert werden !!!

        return null;
    }

    private String renne(List<String> reststapel) {
        for (String akt : reststapel) {
            if (akt.startsWith("MF 3")) {
                return akt;
            }
            if (akt.startsWith("MF 2")) {
                return akt;
            }
            if (akt.startsWith("MF 1")) {
                return akt;
            }
        }
        return null;
    }
}
