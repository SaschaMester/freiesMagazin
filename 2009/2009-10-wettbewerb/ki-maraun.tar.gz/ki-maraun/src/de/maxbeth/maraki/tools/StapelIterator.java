/*
 * Copyright (c) 2009 by M. Maraun.
 *
 *     This file is part of Maraki.
 *
 *     Maraki is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     Maraki is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with Maraki.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.maxbeth.maraki.tools;

import java.util.List;

/**
 */
public class StapelIterator {

    private int[] stapel = new int[MAXIMALE_TYPEN]; // Anzahl der verschiedenen Karten
    private int[] lastcard = new int[ANZAHL_AUSGABE];
    private static final int MAXIMALE_TYPEN = 7;
    private static final int ANZAHL_AUSGABE = 5;
    private boolean finish = false;

    public StapelIterator(List<String> karten) {
        int max = 8;
        for (String kx : karten) {
            int karte = Converter.convertKarte(kx) - 1;
            stapel[karte]++;
            max--;
            if (max == 0) {
                break;
            }
        }
        for (int i = ANZAHL_AUSGABE - 1; i >= 0; i--) {
            for (int j = 0; j < MAXIMALE_TYPEN; j++) {
                if (stapel[j] > 0) {
                    lastcard[i] = j;
                    stapel[j]--;
                    break;
                }
            }
        }
    }


    public String getAblaufString() {
        if (finish) {
            return null;
        }
        String outx = "";
        for (int i = 0; i < ANZAHL_AUSGABE; i++) {
            outx += " " + Converter.outputKarte(lastcard[i] + 1);
        }
        if (!next(0)) {
            finish = true;
        }
        return outx;
    }

    public Integer[] getAblaufInt() {
        if (finish) {
            return null;
        }
        Integer[] outx = new Integer[ANZAHL_AUSGABE];
        for (int i = 0; i < ANZAHL_AUSGABE; i++) {
            outx[i] = lastcard[i] + 1;
        }
        if (!next(0)) {
            finish = true;
        }
        return outx;
    }

    private boolean next(int position) {
        if (position >= ANZAHL_AUSGABE) {
            return false;
        }

        // Karte zurück legen
        int lastme = lastcard[position];
        stapel[lastme]++;

        // Nächste freie Karte suchen
        for (int xx = lastme + 1; xx < MAXIMALE_TYPEN; xx++) {
            if (stapel[xx] > 0) {
                lastcard[position] = xx;
                stapel[xx]--;
                return true;
            }
        }
        if (next(position + 1)) {
            // Wieder von vorne im Stapel suchen
            for (int xx = 0; xx < MAXIMALE_TYPEN; xx++) {
                if (stapel[xx] > 0) {
                    lastcard[position] = xx;
                    stapel[xx]--;
                    return true;
                }
            }

        }
        return false;
    }

}
