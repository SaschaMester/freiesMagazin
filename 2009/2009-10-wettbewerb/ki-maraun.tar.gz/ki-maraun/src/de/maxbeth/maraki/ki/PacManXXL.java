/*
 * Copyright (c) 2009 by M. Maraun.
 *
 *     This file is part of Maraki.
 *
 *     Maraki is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     Maraki is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with Maraki.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.maxbeth.maraki.ki;

import de.maxbeth.maraki.model.*;
import de.maxbeth.maraki.tools.Converter;
import de.maxbeth.maraki.tools.StapelIterator;

import java.util.List;

public class PacManXXL {

    BotModel botx;
    KartenModel karten;
    MapModel landkarte;
    EntfernungsSchichtModel esm;

    public PacManXXL(BotModel botx, KartenModel karten, MapModel landkarte, EntfernungsSchichtModel esm) {
        this.botx = botx;
        this.karten = karten;
        this.landkarte = landkarte;
        this.esm = esm;
    }

    public List<String> berechne() {


        List<String> reststapel = karten.getKarten().subList(0, 8);

        StapelIterator si = new StapelIterator(reststapel);
        int cx = 1;
        int better = 9999;
        Integer bestx[] = null;
        boolean ignore = false;
        Integer[] movex = null;
//        BotModel finish = null;
        while (true) {
            if (!ignore)
                movex = si.getAblaufInt();
            ignore = false;
            if (movex == null) {
                break;
            }
            BotModel checkbot = BotModel.clone(botx);
            // Mit der 5 Karte anfangen
            int moveto = bewege(checkbot, movex, 4);
            // <= -1 als Rückgabe heißt mausetot
            if (moveto < better && moveto >= 0) {
                better = moveto;
                bestx = movex;
//                finish = BotModel.clone(checkbot);
//                 System.out.println(cx + ":" + better + "/" + Converter.intToMove(movex));
                if (moveto == 0) {  //Beim ersten Endtreffer raus springen
                    break;
                }
            } else {
//                System.out.println(cx + "-" + moveto + "-" + Converter.intToMove(movex));
                if (moveto < 0) {
                    int badx = -moveto - 1;
                    int badchar = movex[badx];
                    while (badchar == movex[badx]) {
                        movex = si.getAblaufInt();
                        if (movex == null) {
                            ignore = true;
                            break;
                        }
                    }
                }
            }

            cx++;
        }
        List<String> aktionen;
        if (bestx != null) {
            aktionen = Converter.intToMove(bestx);
        } else {
            System.out.println("Keine Chance, also irgendetwas !!!");
            aktionen = karten.getKarten().subList(0, 5);
        }
//        if (finish != null) {
//            esm.increase(finish.getX(), finish.getY());
//        }
        return aktionen;
    }

    private int bewege(BotModel aktbot, Integer[] movex, int i) {
        // TODO bei einem Abbruch können wir noch melden bei welcher Karte, damit weitere Unterkombinationen
        // übersprungen werden können.
        Integer zug = movex[i];
        if (zug == 1 || zug == 2 || zug == 3) {  //MF 1,2,3
            int count = zug;
            while (count > 0) {
                int checkmove = landkarte.gehtes(aktbot.getRichtung(), aktbot.getX(), aktbot.getY(), true);
                if (checkmove == 2) {
                    return -1 - i;
                }
                if (checkmove == 1) {
                    int retx = robotzug(aktbot, landkarte, aktbot.getRichtung());
                    if (retx == -1) {
                        return -1 - i;
                    }
                    if (esm.get(aktbot.getX(), aktbot.getY()) == 0) {
                        return 0;   // Ich bin am Ziel.
                    }
                }
                count--;
            }

        }
        if (zug == 4) {
            String rueck = aktbot.getRichtung();
            rueck = Converter.convertRichtungString(3 & (2 + Converter.convertRichtung(rueck)));
            if (landkarte.gehtes(rueck, aktbot.getX(), aktbot.getY(), true) != 1) {
                return -1 - i;
            }
            int retx = robotzug(aktbot, landkarte, rueck);
            if (retx == -1) {
                return -1 - i;
            }
            if (esm.get(aktbot.getX(), aktbot.getY()) == 0) {
                return 0;   // Ich bin am Ziel.
            }

        }
        if (zug == 5)
            aktbot.drehe(3, landkarte.getField(aktbot.getX(), aktbot.getY()));// RL
        if (zug == 6)
            aktbot.drehe(1, landkarte.getField(aktbot.getX(), aktbot.getY()));// RR
        if (zug == 7)
            aktbot.drehe(2, landkarte.getField(aktbot.getX(), aktbot.getY()));// RU

        // landkarte.gehtes(aktbot.getRichtung(), aktbot.getX(), aktbot.getY() );

        aktbot = nachlauf(aktbot);
        // TODO eventuell ist hier auch schon ein Zieleinlauf.
        if (aktbot == null) {
            return -1 - i; // Patient Tod
        }
        i--;
        if (i >= 0) {
            // weiteren Zug
            return bewege(aktbot, movex, i);
        }
        int retval = esm.get(aktbot.getX(), aktbot.getY()) * 10;
        aktbot = nachlauf(aktbot);
        if (aktbot == null) {   // der naechste Schritt ist Dein Verderben !!!
            return -1;
        }
        // Falls das nächste Feld ein Tick besser ist dann ein kleinen Bonus geben
        if (retval >= 10) {
            int checkmove = landkarte.gehtes(aktbot.getRichtung(), aktbot.getX(), aktbot.getY(), true);
            if (checkmove == 1) {
                // Clone benutzen, damit der nächste Nachlauf korrekt arbeitet.
                BotModel batman = BotModel.clone(aktbot);
                int retx = robotzug(batman, landkarte, aktbot.getRichtung());
                if (retx != -1) {
                    if (retval > esm.get(batman.getX(), batman.getY()) * 10) {
                        retval--;
                    }
                }
            }
        }

        // Also auch noch einen 2ten Schritt machen, der auch ok sein muss.
        aktbot = nachlauf(aktbot);
        if (aktbot == null) {   // der naechste Schritt ist Dein Verderben !!!
            return -1;
        }

        return retval;
    }

    /**
     * Roboter ein Feld bewegen und dabei Ölfelder und Löcher beachten
     *
     * @param aktbot
     * @param landkarte
     * @return 0 = OK, -1 heißt Tod
     */
    private int robotzug(BotModel aktbot, MapModel landkarte, String richtung) {
        int cx = landkarte.gehtes(richtung, aktbot.getX(), aktbot.getY(), true);
        if (cx == 0) {
            return 0;
        }
        if (cx == 2) {
            return -1;
        }
        aktbot.move(1, richtung);
        if (landkarte.getField(aktbot.getX(), aktbot.getY()) == 'O') {
            return robotzug(aktbot, landkarte, richtung);
        }
        return 0;
    }

    /**
     * Am Ende des Zuges kommt noch etwas
     * 1. Förderband (eventuell auch Dreher
     * 2. Schieber/Presse
     * 3. Drehen
     *
     * @param bm
     * @return
     */
    private BotModel nachlauf(BotModel bm) {
        char charx = landkarte.getField(bm.getX(), bm.getY());
        if (charx == FieldModel.BANDHOCH || charx == FieldModel.BANDLINKS || charx == FieldModel.BANDRECHTS || charx == FieldModel.BANDRUNTER) {
            // bewegen und sehen was mit Löchern und Öl passiert
            int xx = robotzug(bm, landkarte, Converter.schieberichtung(charx));
            if (xx == -1) {
                return null;
            }
            char neuesband = landkarte.getField(bm.getX(), bm.getY());
            if (neuesband == FieldModel.BANDHOCH || neuesband == FieldModel.BANDLINKS || neuesband == FieldModel.BANDRECHTS || neuesband == FieldModel.BANDRUNTER) {
                if (neuesband != charx) {
                    int alt = Converter.convertRichtung(Converter.schieberichtung(charx));
                    int neu = Converter.convertRichtung(Converter.schieberichtung(neuesband));
                    int drehung = (neu - alt) & 3;
                    if (drehung == 1 || drehung == 3) {
                        bm.drehe(drehung, ' '); // Auf dem Förderband dreht er sich nur normal
                    }
                }
            }
        }

        charx = landkarte.getField(bm.getX(), bm.getY());
        // Hier wird Dosenfleisch gemacht.
        if (charx == FieldModel.PRESSELINKSRECHTS || charx == FieldModel.PRESSEOBENUNTEN) {
            return null;
        }
        if (charx == FieldModel.SCHIEBLINKS || charx == FieldModel.SCHIEBUNTEN || charx == FieldModel.SCHIEBOBEN || charx == FieldModel.SCHIEBRECHTS) {
            // bewegen und sehen was mit Löchern und Öl passiert
            int xx = robotzug(bm, landkarte, Converter.schieberichtung(charx));
            if (xx == -1) {
                return null;
            }
        }

        charx = landkarte.getField(bm.getX(), bm.getY());
        if (charx == FieldModel.LINKSDREH) {
            bm.drehe(3, ' ');  // Normale Drehung
        }
        if (charx == FieldModel.RECHTSDREH) {
            bm.drehe(1, ' ');   // Normale Drehung
        }
        return bm;
    }

}