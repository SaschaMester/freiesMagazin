/*
 * Copyright (c) 2009 by M. Maraun.
 *
 *     This file is part of Maraki.
 *
 *     Maraki is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     Maraki is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with Maraki.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.maxbeth.maraki.model;

import com.sun.xml.internal.messaging.saaj.packaging.mime.util.LineInputStream;
import de.maxbeth.maraki.constants.Richtungen;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.StringTokenizer;

public class MapModel {
    private int sizex = 0;
    private int sizey = 0;
    private char[][] map;
    private int[][] blocker;

    private int zielx, ziely;
    private int checksum = 0;

    public MapModel(String s) {
        InputStream is = null;
        try {
            is = new FileInputStream(s);
            LineInputStream lis = new LineInputStream(is);
            String lx;
            lx = lis.readLine();
            StringTokenizer st = new StringTokenizer(lx, " ");
            sizex = Integer.parseInt(st.nextToken());
            sizey = Integer.parseInt(st.nextToken());
            map = new char[sizex][sizey];
            blocker = new int[sizex][sizey];
            int liney = 0;
            while ((lx = lis.readLine()) != null) {
                for (int posx = 0; posx < sizex; posx++) {
                    char zeichen = lx.charAt(posx);
                    if (zeichen == FieldModel.ZIEL) {
                        zielx = posx;
                        ziely = liney;
                    }
                    map[posx][liney] = zeichen;
                    blocker[posx][liney] = 0;
                    checksum = checksum * 31;
                    checksum = (checksum + zeichen + (checksum/256)) & 32767;
                }
                liney++;
//                System.out.println("board.txt:" + lx);
            }
            lis.close();
            is.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int getX() {
        return sizex;
    }

    public int getY() {
        return sizey;
    }

    public char getField(int x, int y) {
        if (x < 0 || y < 0 || x >= sizex || y >= sizey) {
            System.err.println("Falsche Koordinaten x,y =" + x + "," + y);
        }
        return map[x][y];
    }

    public int getZielx() {
        return zielx;
    }

    public int getZiely() {
        return ziely;
    }

    /**
     * Kontrolle ob man in eine Richtung gehen kann von x,y
     *
     * @param richtung
     * @param x
     * @param y
     * @param vorwaerts true falls es vorwaerts gerechnet wird
     * @return 0=geht nicht (Wand/Schieber/Presse), 1 geht, 2 Tod
     */
    public int gehtes(String richtung, int x, int y, boolean vorwaerts) {
        int nextx = x, nexty = y;
        // Erst einmal die Grenzen kontrollieren
        if (richtung.equals(Richtungen.LEFT)) {
            nextx--;
            if (nextx < 0)
                return mauerblock(x, y, FieldModel.WAND_LINKS) ? 0 : 2;
            if (map[nextx][nexty] == FieldModel.SCHIEBLINKS) return 0;
            if (map[x][y] == FieldModel.SCHIEBRECHTS) return 0;
            if (mauerblock(x, y, FieldModel.WAND_LINKS)) return 0;
            if (mauerblock(nextx, nexty, FieldModel.WAND_RECHTS)) return 0;
            if (!vorwaerts && blocking(nextx, nexty, FieldModel.WAND_RECHTS)) return 0;
//            if (vorwaerts && blocking(x, y, FieldModel.WAND_LINKS)) return 0;
        }
        if (richtung.equals(Richtungen.RIGHT)) {
            nextx++;
            if (nextx >= sizex)
                return mauerblock(x, y, FieldModel.WAND_RECHTS) ? 0 : 2;
            if (map[x][y] == FieldModel.SCHIEBLINKS) return 0;
            if (map[nextx][nexty] == FieldModel.SCHIEBRECHTS) return 0;
            if (mauerblock(x, y, FieldModel.WAND_RECHTS)) return 0;
            if (mauerblock(nextx, nexty, FieldModel.WAND_LINKS)) return 0;
            if (!vorwaerts && blocking(nextx, nexty, FieldModel.WAND_LINKS)) return 0;
//            if (vorwaerts && blocking(x, y, FieldModel.WAND_RECHTS)) return 0;
        }
        if (richtung.equals(Richtungen.UP)) {
            nexty--;
            if (nexty < 0)
                return mauerblock(x, y, FieldModel.WAND_OBEN) ? 0 : 2;
            if (map[nextx][nexty] == FieldModel.SCHIEBOBEN) return 0;
            if (map[x][y] == FieldModel.SCHIEBUNTEN) return 0;
            if (mauerblock(x, y, FieldModel.WAND_OBEN)) return 0;
            if (mauerblock(nextx, nexty, FieldModel.WAND_UNTEN)) return 0;
            if (!vorwaerts && blocking(nextx, nexty, FieldModel.WAND_UNTEN)) return 0;
//            if (vorwaerts && blocking(x, y, FieldModel.WAND_OBEN)) return 0;
        }
        if (richtung.equals(Richtungen.DOWN)) {
            nexty++;
            if (nexty >= sizey)
                return mauerblock(x, y, FieldModel.WAND_UNTEN) ? 0 : 2;
            if (map[nextx][nexty] == FieldModel.SCHIEBUNTEN) return 0;
            if (map[x][y] == FieldModel.SCHIEBOBEN) return 0;
            if (mauerblock(x, y, FieldModel.WAND_UNTEN)) return 0;
            if (mauerblock(nextx, nexty, FieldModel.WAND_OBEN)) return 0;
            if (!vorwaerts && blocking(nextx, nexty, FieldModel.WAND_OBEN)) return 0;
//            if (vorwaerts && blocking(x, y, FieldModel.WAND_UNTEN)) return 0;
        }

        if (richtung.equals(Richtungen.DOWN) || richtung.equals(Richtungen.UP)) {
            if (map[nextx][nexty] == FieldModel.PRESSEOBENUNTEN || map[x][y] == FieldModel.PRESSEOBENUNTEN)
                return 0;
        }

        if (richtung.equals(Richtungen.LEFT) || richtung.equals(Richtungen.RIGHT)) {
            if (map[nextx][nexty] == FieldModel.PRESSELINKSRECHTS || map[x][y] == FieldModel.PRESSELINKSRECHTS)
                return 0;
        }

        if (map[nextx][nexty] == FieldModel.LOCH) return 2;

        return 1;
    }

    private boolean blocking(int posx, int posy, int wandtyp) {

        if ((blocker[posx][posy] & wandtyp) != 0) {
            System.out.println("BLocked" + posx + "/" + posy);
            return true;
        }
        return false;
    }

    private boolean mauerblock(int x, int y, int wand_unten) {
        return ((map[x][y] - 1) & wand_unten) != 0 && map[x][y] >= 'a' && map[x][y] <= 'p';
    }

    /**
     * Kontrolle ob Rutschen ok ist.
     *
     * @param x
     * @param y
     * @return
     */
    public boolean oilcheck(int x, int y) {
        if ((map[x][y] >= 'a' && map[x][y] <= 'p') || map[x][y] == ' '
                || map[x][y] == FieldModel.LINKSDREH
                || map[x][y] == FieldModel.ZIEL
                || map[x][y] == FieldModel.OEL
                || map[x][y] == FieldModel.RECHTSDREH) {
            return true;
        }
        return false;
    }

    public long getChecksum() {
        return checksum;
    }

    public void setBlock(int xb, int yb, int wand) {
//        System.out.println("Block:" + xb + "," + yb + ":" + wand);
        blocker[xb][yb] = wand;
    }

    public int getBlock(int x, int y) {
        return blocker[x][y];
    }
}