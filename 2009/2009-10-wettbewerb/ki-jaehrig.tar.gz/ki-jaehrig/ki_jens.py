#!/usr/bin/env python
# coding=utf8

# *************************************************************************
# ki_jens - fuer freiesMagazin Programmierwettbewerb 10/2009
# Copyright 2009 Jens-Uwe Jährig <jens-jaehrig@web.de>
# Licence: GPLv3
# *************************************************************************
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import random
import time
import operator
import sys
import pprint
from math import sqrt
from robot import robot
from board import parse_board,board
import weg_finder

PP = pprint.PrettyPrinter()
board_file = 'board.txt'
bot_file = 'bot.txt'
cards_file = 'cards.txt'
ccards_file = 'ccards.txt'

VERBOSE = 0

t = time.time()

dir_wand = {'R':1,
'L':2,
'U':4,
'D':8}

class point():
    x = 0
    y = 0
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

def parse_bot_file(bot_file):
    x, y, d = open(bot_file).readline()[:-1].split(' ')
    x = int(x)
    y = int(y)
    return robot(x, y, d)

def parse_cards_file(cards_file):
    cards_list = [a[:-1] for a in open(cards_file).readlines()]
    return cards_list

def safe_ccards(ccards_file, ccards):
    if VERBOSE > 10: print 'Save cards: ', ccards
    open(ccards_file, 'w').write('\n'.join(ccards))
    
def move(bot, cards):
    if VERBOSE > 20:print 'Cards: ', cards, '\nRobot before move: ', bot
    for card in cards:
    # Führe Kartenbewegung aus
        if bot.health == True and not bot.get_field() in 'MNH':
            if card == 'MB':
#                bot = step(robot(bot.x, bot.y, bot.d), 'RU')
                bot.rotate_uturn()
                bot = step(robot(bot.x, bot.y, bot.d), 'MF 1')
#                bot = step(robot(bot.x, bot.y, bot.d), 'RU')
                bot.rotate_uturn()
            else:
                bot = step(robot(bot.x, bot.y, bot.d), card)
        else:
            bot.health = False
            break
        if VERBOSE > 20:print 'Robot between step and board_action: ', bot

    # Führe Brettbewegung aus
        if bot.health == True and bot.get_field() not in 'MNH':
            bot = board_action(robot(bot.x, bot.y, bot.d))
        else:
            bot.health = False
            break
        if bot.get_field() in 'MNH':
            bot.health = False
            break
    
    # Steht der Bot auf einem Band am Rand des Spielfeldes in Richtung Abgrund?
    if bot.x == karte.size_x and bot.d == 'R' and bot.get_field() == '>' or \
       bot.y == karte.size_y  and bot.d == 'U' and bot.get_field() == '^' or \
       bot.x == karte.size_x  and bot.d == 'L' and bot.get_field() == '<' or \
       bot.y == karte.size_y and bot.d == 'D' and bot.get_field() == 'v' or \
       bot.get_field() in 'MNH':
        bot.health = False
# Oder halt kurz, erfasst alle Fälle in denen der Bot richtung abgund schaut.
#    if bot.get_next_field() == 'H' and bot.get_field != 'Z': bot.health = False
#        bot.health = False
#        break

    if VERBOSE > 20:
        print 'Robot after move: ', bot, '\n'
    return bot
    
def step(bot, card):
    if 'MF' in card:
        steps = int(card.split(' ')[1])
        step = 1
        for i in xrange(0, steps, 1):
            feld0 = bot.get_field()
            if feld0 == 'H':
                bot.health = False
                break
            bot.move_forward()
            limit = 0
            while bot.get_field() == 'O' and limit<20:
                limit += 1
                bot.move_forward()

    else:
        field = bot.get_field()
        if card == 'RR':
            if field != 'O':
                bot.rotate_right()
            else:
                bot.rotate_uturn()
        elif card == 'RL':
            if field != 'O':
                bot.rotate_left()
            else:
                bot.rotate_uturn()
        elif card == 'RU':
            if field != 'O':
                bot.rotate_uturn()
            else:
                pass

    if VERBOSE > 20:
        print card, bot
    if bot.get_field() in 'MNH':
        bot.health = False
    return bot

def board_action(bot):
    feld = bot.get_field()
#    if feld not in ' STUV':
    if feld in '^<v>':
        if feld == '^':
            bot.move_up()
        elif feld == '>':
            bot.move_right()
        elif feld == 'v':
            bot.move_down()
        elif feld == '<':
            bot.move_left()
        last_field=feld
        feld = bot.get_field()
        if last_field+feld == 'v<' or last_field+feld == '<^' or last_field+feld == '^>' or last_field+feld == '>v':
            bot.rotate_right()
        elif last_field+feld == 'v>' or last_field+feld == '>^' or last_field+feld == '^<' or last_field+feld == '<v':
            bot.rotate_left()
        limit = 0
        while bot.get_field() == 'O' and limit<20:
            limit += 1
            if last_field == '^':
                bot.move_up()
            elif last_field == '>':
                bot.move_right()
            elif last_field == 'v':
                bot.move_down()
            elif last_field == '<':
                bot.move_left()
        feld = bot.get_field()

    if feld in 'EDFC':
        if feld == 'E':
            bot.move_up()
        elif feld == 'D':
            bot.move_right()
        elif feld == 'F':
            bot.move_down()
        elif feld == 'C':
            bot.move_left()
        last_field=feld
        feld = bot.get_field()
        limit = 0
        while bot.get_field() == 'O' and limit<20:
            limit += 1
            if last_field == 'E':
                bot.move_up()
            elif last_field == 'D':
                bot.move_right()
            elif last_field == 'F':
                bot.move_down()
            elif last_field == 'C':
                bot.move_left()
        feld = bot.get_field()

    if feld == 'L':
        bot.rotate_left()
    if feld == 'R':
        bot.rotate_right()
    
    if bot.get_field() in 'MNH':
        bot.health = False
    return bot
    
def find_goal(karte):
    x, y = 0, 0
    for line in karte.array:
        if 'Z' in line:
            x = line.find('Z')
            break
        y += 1
    if VERBOSE > 10: print 'goal:', x, y
    return point(x, y)

def permutations(iterable, r=None):
    # permutations('ABCD', 2) --> AB AC AD BA BC BD CA CB CD DA DB DC
    # permutations(range(3)) --> 012 021 102 120 201 210
    pool = tuple(iterable)
    n = len(pool)
    r = n if r is None else r
    if r > n:
        return
    indices = range(n)
    cycles = range(n, n-r, -1)
    yield tuple(pool[i] for i in indices[:r])
    while n:
        for i in reversed(range(r)):
            cycles[i] -= 1
            if cycles[i] == 0:
                indices[i:] = indices[i+1:] + indices[i:i+1]
                cycles[i] = n - i
            else:
                j = cycles[i]
                indices[i], indices[-j] = indices[-j], indices[i]
                yield tuple(pool[i] for i in indices[:r])
                break
        else:
            return

def perm_wo(n, k):
    res = fact(n)/(fact(k)*fact(n-k))*fact(k)
    return res

# Variation (Mit Beachtung der Reihenfolge), ohne Wiederholung (Ohne Zuruecklegen)
def var_wo_rep(n, k):
    return fact(n)/fact(n-k)

# Fakultaet (factorial)
def fact(x):
    if x>1:
        return reduce(operator.mul, xrange(2, x+1))
    elif x == 0 or x == 1:
        return 1
    else:
        raise ValueError('fact() not defined for negative values')
        
if __name__ == '__main__':
    if VERBOSE > 10: print '--------------------------------------------------'
    # print '2 ', time.time()

    # Karte, Bot uns  Spielbrett initialisieren
    karte = parse_board(board_file)
    bot = parse_bot_file(bot_file)
    routenplaner = weg_finder.get_routenplaner()
    stapel_mit_8_karten = parse_cards_file(cards_file)
    # print 'len(cards)', len(cards)
    # Workaround, weil in der cards.txt über 4000 Karten sind, wenn die engine grad nicht laeuft
    if len(stapel_mit_8_karten)>8:
        if VERBOSE > 10:
            print 'Workaround fuer cards.txt aktiv'
        stapel_mit_8_karten = random.sample(stapel_mit_8_karten, 8)
        if VERBOSE > 10:
            print stapel_mit_8_karten
        if VERBOSE > 10:
            print 'len(stapel_mit_8_karten)', len(stapel_mit_8_karten)
    
    # print 'a ', time.time()
    goal = find_goal(karte)

    if VERBOSE > 10:
        print 'before perm  %.3f' % (time.time()-t)

    liste = {}
    gefundene_wege_liste = []
    a = 0
    result_of_perm = {}
    dist_from_start = abs(goal.x-bot.x)+abs(goal.y-bot.y)
    if dist_from_start < 8:
        min = 1
    else:
        min = 5
    # doppelte Einträge vermeiden
    perm_liste = []
    for number_of_cards in range(min, 6):
        for kombination in permutations(stapel_mit_8_karten, number_of_cards):
            if kombination not in perm_liste:
                perm_liste.append(kombination)
    if VERBOSE > 10: 
        print 'len(perm_liste)', len(perm_liste)
    if VERBOSE > 10:
        print perm_liste
    
    for cards in perm_liste:
        if VERBOSE > 20:
            a += 1
            if a%1000 == 0: print 'Kombinationen berechnet:', a

        bot_ende = move(robot(bot.x, bot.y, bot.d), cards)
        field = bot_ende.get_field()
        
        # Das entfernen zu kurzer wege, welche nicht im ziel enden
        if bot_ende.health and (
           len(cards) == 5 and field not in 'MNH' or
           len(cards) < 5 and field == 'Z'
           ):
            #dist = abs(goal.x-bot_ende.x)+abs(goal.y-bot_ende.y)
            dist = int(routenplaner[bot_ende.x][bot_ende.y])
            try:
                result_of_perm[cards].append({'bot': bot_ende, 'distance': dist, 'len_cards': len(cards)})
                #print bot_ende
            except:
                result_of_perm[cards] = {'bot': bot_ende, 'distance': dist, 'len_cards': len(cards)}
        else:
            bot_ende.health = False
    #PP.pprint(result_of_perm)
    #print result_of_perm
    #print len(result_of_perm)
    if VERBOSE > 10: print 'after all  %.3f' % (time.time()-t)
    
    # print '6 ', time.time()
    # print 'Laenge Liste: ', len(liste)
    if len(result_of_perm)>0:
        keys = result_of_perm.keys()

        available_distances = list(set([line['distance'] for line in result_of_perm.values()]))
        available_distances.sort()
        shortest_dist = available_distances[0]

        minimum_of_cards = 5
        available_card_len = list(set([len(key) for key in result_of_perm.keys()]))
        available_card_len.sort()
        #print 'available_card_len: ', available_card_len
        minimum_of_cards = available_card_len[0]

        #print 'available_distances:', available_distances
        #print 'shortest_dist', shortest_dist
        ###############################################################
        if shortest_dist < 2:
#        if shortest_dist > -1:
        #if True:
            final_list = []
            for key in keys:
                dist = result_of_perm[key]['distance']
                number_of_cards = result_of_perm[key]['len_cards']
                if dist == shortest_dist and number_of_cards == minimum_of_cards:
                    final_list.append(key)
            #print 'final_list', final_list

            if VERBOSE > 10: PP.pprint(shortest_dist_less_cards)

            ccards = final_list.pop()
            ####################################################
        else:
            minimum_of_cards = 5
            zwischen_liste = {}
            #print 'len(result_of_perm)', len(result_of_perm)
            for key in keys:
                # print result_of_perm[key]
                bot_ende = result_of_perm[key]['bot']
                dist = result_of_perm[key]['distance']
                number_of_cards = result_of_perm[key]['len_cards']
                
                bot_ende.move_forward()
                field = bot.get_field()
                #print bot
                if bot_ende.health and 0 <= bot_ende.x < karte.size_x and \
                   0 <= bot_ende.y < karte.size_y and (
                   len(key) == 5 and field not in 'MNH' or
                   len(key) < 5 and field == 'Z'
                   ):
                    dist = int(routenplaner[bot_ende.x][bot_ende.y])
                    try:
                        zwischen_liste[key].append({'bot': bot_ende, 'distance': dist, 'len_cards': len(key)})
                    except:
                        zwischen_liste[key] = {'bot': bot_ende, 'distance': dist, 'len_cards': len(key)}
            #print 'len(zwischen_liste)', len(zwischen_liste)
            
            available_distances = list(set([line['distance'] for line in zwischen_liste.values()]))
            available_distances.sort()
            shortest_dist = available_distances[0]
            
            available_card_len = list(set([len(key) for key in zwischen_liste.keys()]))
            available_card_len.sort()
            minimum_of_cards = available_card_len[0]
            
            keys = zwischen_liste.keys()
            final_list = []
            for key in keys:
                dist = zwischen_liste[key]['distance']
                number_of_cards = zwischen_liste[key]['len_cards']
                if dist == shortest_dist and number_of_cards == minimum_of_cards:
                    final_list.append(key)
            #print 'final_list', final_list

            if VERBOSE > 10: PP.pprint(shortest_dist_less_cards)

            ccards = final_list.pop()

        # einen zu kurzen Kartenstapel ausgleichen, falls der bot kurz vorm ziel ist
        if len(ccards)<5:
            ccards = list(ccards)
            if VERBOSE > 10: print 'ccards zu kurz', ccards
            cards_tmp = list(stapel_mit_8_karten[:])
            if VERBOSE > 10: print cards_tmp
            for card in ccards:                
                cards_tmp.remove(card)
            while len(ccards)<5:
                ccards.append(cards_tmp.pop())

        safe_ccards(ccards_file, ccards)
    else:
        if VERBOSE > 0: print 'keinen Weg gefunden'
        ccards = stapel_mit_8_karten[:5]
        safe_ccards(ccards_file, ccards)
    # print "7 %.3f" % (time.time()-t)
#    print '------------------------------------------------------------------'
#    keys = result_of_perm.keys()
#    keys.sort()
#    for i in keys:
#        print i, 'len', len(result_of_perm[i])
    # PP = pprint.PrettyPrinter()
    # PP.pprint(result_of_perm)
    sys.exit(0)
