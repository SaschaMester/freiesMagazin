#!/usr/bin/env python
# coding=utf8

# *************************************************************************
# ki_jens - fuer freiesMagazin Programmierwettbewerb 10/2009
# Copyright 2009 Jens-Uwe Jährig <jens-jaehrig@web.de>
# Licence: GPLv3
# *************************************************************************
#
#    This file is part of ki_jens.
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

wand
feld

wand={'a':0,
'b':1,
'c':2,
'd':3,
'e':4,
'f':5,
'g':6,
'h':7,
'i':8,
'j':9,
'k':10,
'l':11,
'm':12,
'n':13,
'o':14,
'p':15}
if feld in 'abcdefghijklmnp':
    if feld&1: wand_links=True
    if feld&2: wand_rechts=True
    if feld&4: wand_unten=True
    if feld&8: wand_oben=True
