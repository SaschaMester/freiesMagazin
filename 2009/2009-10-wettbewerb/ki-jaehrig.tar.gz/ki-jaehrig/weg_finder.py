#!/usr/bin/env python
# coding=utf8

# *************************************************************************
# ki_jens - fuer freiesMagazin Programmierwettbewerb 10/2009
# Copyright 2009 Jens-Uwe Jährig <jens-jaehrig@web.de>
# Licence: GPLv3
# *************************************************************************
#
#    This file is part of ki_jens.
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import board
#karte = board.parse_board('gameboards/chop_labyrinth.dat')
karte = board.parse_board()
import pprint
PP = pprint.PrettyPrinter()
import robot
import os.path
import shutil
import csv
import os

spielfeld_analyse = []

VERBOSE = 0

class point():
    x = 0
    y = 0
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

def find_goal(karte):
    x, y = 0, 0
    for line in karte.array:
        if 'Z' in line:
            x = line.find('Z')
            break
        y += 1
    if VERBOSE > 10: print 'goal:', x, y
    print 'Goal:', x, y
    return point(x, y)

def store_splf_anal_dist(x, y, dist):
    global spielfeld_analyse
    if 0 <= x < karte.size_x and 0 <= y < karte.size_y:
        org_dist = spielfeld_analyse[x][y]
        #print x, y, org_dist, dist
        if dist < org_dist:
            spielfeld_analyse[x][y] = dist

def speichern(liste,db):
    csvfile=csv.writer(open(db,'wb'),delimiter=':')
    csvfile.writerows(liste)

def auslesen(db):
    csvfile=csv.reader(open(db,'rb'),delimiter=':')
    return list(csvfile)


def get_routenplaner():
    global spielfeld_analyse
#    prefix = 'ki/db/'
    prefix = '/tmp/ki_jaehrig/'
    if not os.path.exists(prefix):
        os.mkdir(prefix)
    weg_datenbank = prefix + karte.md5_hash + '.weg'
    weg_datenbank_readable = prefix + karte.md5_hash + '.weg.readable'
    karte_datenbank = prefix + karte.md5_hash + '.karte'
    # spielfeld_analyse = []
    if os.path.exists(weg_datenbank) and os.path.exists(karte_datenbank) and \
       os.path.exists(weg_datenbank_readable):
        # print 'Datenbank gibts schon:\n', weg_datenbank,'\n'
        spielfeld_analyse = zip(*auslesen(weg_datenbank))
    else:
        goal = find_goal(karte)
        spielfeld_analyse = [(karte.size_y)*[1000] for i in range(karte.size_x)]
        spielfeld_analyse[goal.x][goal.y] = 0
        spielfeld_analyse_xy_list = [(x, y) for x in range(karte.size_x)
                               for y in range(karte.size_y)]
        a = 0
        while a < 100:
            a += 1
            for feld in spielfeld_analyse_xy_list:
                distance = spielfeld_analyse[feld[0]][feld[1]]
                if distance < 1000:
                    distance += 1

                    bot = robot.robot(*feld)
                    #print bot
                    if bot.move_up():
                        x, y = bot.get_xy()
                        store_splf_anal_dist(x, y, distance)

                    bot = robot.robot(*feld)                
                    if bot.move_right():
                        x, y = bot.get_xy()
                        store_splf_anal_dist(x, y, distance)

                    bot = robot.robot(*feld)                
                    if bot.move_down():
                        x, y = bot.get_xy()
                        store_splf_anal_dist(x, y, distance)

                    bot = robot.robot(*feld)                
                    if bot.move_left():
                        x, y = bot.get_xy()
                        store_splf_anal_dist(x, y, distance)

        speichern(zip(*spielfeld_analyse),weg_datenbank)

        shutil.copy(karte.file_name,karte_datenbank)
        datei_out = [' '.join('%4d'%int(i) for i in line) for line in zip(*spielfeld_analyse)]
        datei = open(weg_datenbank_readable,'w')
        datei.write('\n'.join(datei_out))
        datei.close()
    out_print = zip(*spielfeld_analyse)
    out_print = [' '.join('%04d'%int(i) for i in line) for line in out_print]
    # PP.pprint(out_print)
    return spielfeld_analyse
