#!/usr/bin/env python
# coding=utf8

# *************************************************************************
# ki_jens - fuer freiesMagazin Programmierwettbewerb 10/2009
# Copyright 2009 Jens-Uwe Jährig <jens-jaehrig@web.de>
# Licence: GPLv3
# *************************************************************************
#
#    This file is part of ki_jens.
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

rotate_dict={
    # Rotate Right
    'RR':{
        'U':'R',
        'R':'D',
        'D':'L',
        'L':'U'
    },
    # Rotate Left
    'RL':{
        'U':'L',
        'R':'U',
        'D':'R',
        'L':'D'
    },
    # U-Turn
    'RU':{
        'U':'D',
        'R':'L',
        'D':'U',
        'L':'R'
    }
    }
