#!/usr/bin/env python
# coding=utf8

# *************************************************************************
# ki_jens - fuer freiesMagazin Programmierwettbewerb 10/2009
# Copyright 2009 Jens-Uwe Jährig <jens-jaehrig@web.de>
# Licence: GPLv3
# *************************************************************************
#
#    This file is part of ki_jens.
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import hashlib

class board():
    array=[]
    size_x=0
    size_y=0
    waende={}
    md5_hash = ''
    file_name = ''
    def get_field(self,x,y):
        if 0 <= x < self.size_x and 0<= y < self.size_y:
            field = self.array[y][x]
        else:
            field = 'H'
        return field

def parse_board(board_file='board.txt'):
    karte=board()
    karte.file_name = board_file
    datei=[a[:-1] for a in open(board_file)]
    karte.size_x,karte.size_y=[int(a) for a in datei[0].split(' ')]
    karte.array=tuple(datei[1:])
    if not len(karte.array) == karte.size_y and len(karte.array[0]) == karte.size_x:
        print 'Error: board has wrong size'
    karte.md5_hash = hashlib.md5(open(board_file).read()).hexdigest()
    return karte

# karte = parse_board()
