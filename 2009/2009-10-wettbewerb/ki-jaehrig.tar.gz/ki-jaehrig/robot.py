#!/usr/bin/env python
# coding=utf8

# *************************************************************************
# ki_jens - fuer freiesMagazin Programmierwettbewerb 10/2009
# Copyright 2009 Jens-Uwe Jährig <jens-jaehrig@web.de>
# Licence: GPLv3
# *************************************************************************
#
#    This file is part of ki_jens.
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

board_file = 'board.txt'
bot_file = 'bot.txt'
cards_file = 'cards.txt'
ccards_file = 'ccards.txt'
from board import *

rotate_dict = {
    # Rotate Right
    'RR':{
        'U':'R',
        'R':'D',
        'D':'L',
        'L':'U'
    },
    # Rotate Left
    'RL':{
        'U':'L',
        'R':'U',
        'D':'R',
        'L':'D'
    },
    # U-Turn
    'RU':{
        'U':'D',
        'R':'L',
        'D':'U',
        'L':'R'
    }
    }

wand = {'a':0,
'b':1, # links
'c':2, # rechts
'd':3, # links, rechts
'e':4, # oben
'f':5, # links, oben
'g':6, # rechts, oben
'h':7, # links, rechts, oben
'i':8, # unten
'j':9, # links, unten
'k':10, # rechts, unten
'l':11, # links, rechts, unten
'm':12, # oben, unten
'n':13, # links, oben, unten
'o':14, # rechts, oben, unten
'p':15, # links, rechts, oben, unten
'C':2, # Schieber von Rechts - schiebt den Roboter ein Feld nach links
'D':1, # Schieber von Links - schiebt den Roboter ein Feld nach rechts
'E':8, # Schieber von Unten - schiebt den Roboter ein Feld nach oben
'F':4, # Schieber von Oben - schiebt den Roboter ein Feld nach unten
'M':3, # Links/Rechts-Schrottpresse
'N':12 # Oben/Unten Schrottpresse
}

class robot():
    x = 0
    y = 0
    d = ' '
    health = True
    def __init__(self, x=0, y=0, d='D'):
        self.x = x
        self.y = y
        self.d = d
    def __str__(self):
        return ' '.join(( str(self.x), str(self.y), self.d, str(self.health), ("'"+self.get_field()+"'") ))

    # Bewege dich hoch
    def move_up(self, steps=1):
        feld0 = self.get_field()
        feld1 = karte.get_field(self.x,self.y-1)
        if self.get_wand(feld0)&4 or self.get_wand(feld1)&8:
            return False
        else:
            self.y -= 1
            return True
    # Beweg dich nach rechts
    def move_right(self, steps=1):
        feld0 = self.get_field()
        feld1 = karte.get_field(self.x+1,self.y)
        if self.get_wand(feld0)&2 or self.get_wand(feld1)&1:
            return False
        else:
            self.x += 1
            return True
    # Beweg dich nach unten
    def move_down(self, steps=1):
        feld0 = self.get_field()
        feld1 = karte.get_field(self.x,self.y+1)
        if self.get_wand(feld0)&8 or self.get_wand(feld1)&4:
            return False
        else:
            self.y += 1
            return True
    # Beweg dich nach links
    def move_left(self, steps=1):
        feld0 = self.get_field()
        feld1 = karte.get_field(self.x-1,self.y)
        if self.get_wand(feld0)&1 or self.get_wand(feld1)&2:
            return False
        else:
            self.x -= 1
            return True
    def move_forward(self, steps=1):
        if self.d == 'U':
            self.move_up()
        elif self.d == 'R':
            self.move_right()
        elif self.d == 'D':
            self.move_down()
        elif self.d == 'L':
            self.move_left()

    def move_forward_neu(self, steps=1):
        if self.d == 'U':
            value = self.move_up()
        elif self.d == 'R':
            value = self.move_right()
        elif self.d == 'D':
            value = self.move_down()
        elif self.d == 'L':
            value = self.move_left()
        return value

    # Drehungen
    def rotate_left(self):
        self.d = rotate_dict['RL'][self.d]
    def rotate_right(self):
        self.d = rotate_dict['RR'][self.d]
    def rotate_uturn(self):
        self.d = rotate_dict['RU'][self.d]
    
    def get_wand(self, feld):
        if feld in wand.keys():
            feld_wand = wand[feld]
        else:
            feld_wand = 0
        return feld_wand
            
    def get_next_coordinate(self, steps=1):
        if self.d == 'U': return (self.x, self.y-steps)
        if self.d == 'R': return (self.x+steps, self.y)
        if self.d == 'D': return (self.x, self.y+steps)
        if self.d == 'L': return (self.x-steps, self.y)
    def get_x(self):
        return self.x
    def get_y(self):
        return self.y
    def get_d(self):
        return self.d
    def get_xy(self):
        return (self.x,self.y)
    def get_field_alt(self):
        return karte.array[self.y][self.x]
    def get_field_alt(self):
        if 0 <= self.x <= 11 and 0<= self.y <= 11:
            field = karte.array[self.y][self.x]
        else:
            field = 'H'
        return field
    def get_field(self):
        field = karte.get_field(self.x, self.y)
        return field
    def get_next_field(self):
        x, y = self.get_next_coordinate()
        #if 0 <= x <= karte.size_x and 0 <= y <= karte.size_y:
        if 0 <= x <= 11 and 0 <= y <= 11:
            field = karte.array[y][x]
        else:
            field = 'H'
        return field

karte = parse_board(board_file)
