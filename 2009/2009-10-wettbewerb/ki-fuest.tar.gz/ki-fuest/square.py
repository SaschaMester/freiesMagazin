#!/usr/bin/env python
#
#       test.py
#
#       Copyright 2009 Mario Fuest <mario@mario-desktop>
#
#       This program is free software; you can redistribute it and/or modify
#       it under the terms of the GNU General Public License as published by
#       the Free Software Foundation; either version 3 of the License, or
#       (at your option) any later version.
#
#       This program is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU General Public License for more details.
#
#       You should have received a copy of the GNU General Public License
#       along with this program; if not, write to the Free Software
#       Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#       MA 02110-1301, USA.



class Square(object):
    """
    squares are parts of the gamefield
    later squares know how to rech certain other squares
    as "sqaure" is too long, "sq" ist often used instead.
    """

    def __init__(self, pos_x, pos_y, string):
        """
        init a new square
        square knows what kind and where it is
        """

        self.x = pos_x
        self.y = pos_y
        self.end_x = self.x
        self.end_y = self.y
        self.string = string ## dont use!

        self.MV = {}
        for dir in ['LEFT', 'RIGHT', 'UP', 'DOWN']:
            self.MV[dir] = {}
            for i in range(3):
                self.MV[dir][i+1] = {'end_pos':(self.x, self.y), 'dir':dir}

        self.rotate = {'none':None,
                       'left':'rt_left',
                       'right':'rt_right',
                       '180':'rt_180',
                       'costs':1}

        self.move = {'LEFT':True,
                     'UP':True,
                     'RIGHT':True,
                     'DOWN':True}
        self._set_settings(string)


    def _set_settings(self, string):
        """
        set the square-group of a sq
        and other information the string contains
        """

        if string in ' STUVa':
            self.kind = 'EMPTY'

        elif string == 'H':
            self.kind = 'HOLE'
            #for dir in self.rotate: self.rotate[dir] = 'DEATH'

        elif string == 'O':
            self.kind = 'OIL'

        elif string == 'Z':
            self.kind = 'GOAL'
            self.goal = True

        elif string == 'L':
            self.kind = 'ROTATOR'
            self.direction = 'LEFT'

        elif string == 'R':
            self.kind = 'ROTATOR'
            self.direction = 'RIGHT'

        elif string in '<>^v':
            self.kind = 'CONVEYOR'
            dirs = {'<':'LEFT', '>':'RIGHT', '^':'UP', 'v':'DOWN'}
            self.direction = dirs[string]

        elif string in 'CDEF':
            self.kind = 'PUSHER'
            dirs = {'C':'LEFT', 'D':'RIGHT', 'E':'UP', 'F':'DOWN'}
            self.direction = dirs[string]

            dirs = {'C':'RIGHT', 'D':'LEFT', 'E':'DOWN', 'F':'UP'}
            self.move[dirs[string]] = False

        elif string == 'M':
            self.kind = 'JUNK_PRESS'
            self.move['LEFT'] = False
            self.move['RIGHT'] = False
            self.rotate = 'DEATH'

        elif string == 'N':
            self.kind = 'JUNK_PRESS'
            self.move['UP'] = False
            self.move['DOWN'] = False
            self.rotate = 'DEATH'

        elif ord(string) in xrange(98, 113): # [b:p]
            self.kind = 'WALL'
            wall_bin = ord(string) - 97

            if wall_bin & 8:
                self.move['DOWN'] = False

            if wall_bin & 4:
                self.move['UP'] = False

            if wall_bin & 2:
                self.move['RIGHT'] = False

            if wall_bin & 1:
                self.move['LEFT'] = False

        else:
            print "Warning: unknown field: %s" % string, self.x, self.y

    def __str__(self):
        return self.kind

    def __repr__(self):
        return self.string

if __name__ == '__main__':
    for ch in xrange(97, 113):
        square = Square(2, 3, chr(ch))
        print chr(ch), ch-97,  square.move
