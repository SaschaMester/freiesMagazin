#!/usr/bin/env python
#
#       field.py
#
#       Copyright 2009 Mario Fuest <mario@mario-desktop>
#
#       This program is free software; you can redistribute it and/or modify
#       it under the terms of the GNU General Public License as published by
#       the Free Software Foundation; either version 3 of the License, or
#       (at your option) any later version.
#
#       This program is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU General Public License for more details.
#
#       You should have received a copy of the GNU General Public License
#       along with this program; if not, write to the Free Software
#       Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#       MA 02110-1301, USA.

import cPickle as pickle
from math import sqrt

from square import Square

class Field(object):

    def __init__(self, field_file, difficulty='hard'):
        """
        init gamefield:
            create self.field containing lots of Squares
            set row/col len
            set goal_sq
            easysize, if difficulty != 'hard'
        """
        self.death = {}
        self.reversed = {}

        f = open(field_file)
        field_list = f.readlines()
        f.close()

        len_hight = field_list[0].split()
        self.row_len = int(len_hight[0])
        self.col_len = int(len_hight[1])

        if difficulty != 'hard':
            field_list = self._easysize(field_list[1:])

        self.field = []
        for y, row in enumerate(field_list[1:]):
            row = row.replace('\n', '')

            for x, string in enumerate(row):
                self.field.append(Square(x, y, string))
                if self.field[-1].kind == 'GOAL':
                    self.goal_sq = self.field[-1]

    def _easysize(self, field_list):
        """
        add blocs to the corners of the field,
        because you cannot fall down anymore
        """

        self.row_len += 2
        self.col_len += 2

        for i, row in enumerate(field_list):
            field_list[i] = 'p%s' % row
            field_list[i] = field_list[i].replace('\n', 'p\n')

        field_list.insert(0, self.row_len * 'p' + '\n')
        field_list.append(self.row_len * 'p' + '\n')

        return field_list


    def get_pos(self, x, y):
        return self.field[x+self.row_len*y]

    def _not_dir(self, start_dir):

       dirs = {'LEFT':'RIGHT', 'RIGHT':'LEFT', 'UP':'DOWN', 'DOWN':'UP'}
       return dirs[start_dir]

    def _get_dir(self, start_dir, rt_dir):

        if rt_dir == 'LEFT':
            dirs = {'UP':'LEFT', 'DOWN':'RIGHT', 'RIGHT':'UP', 'LEFT':'DOWN'}
            return dirs[start_dir]

        elif new == 'RIGHT':
            dirs = {'DOWN':'LEFT', 'UP':'RIGHT', 'LEFT':'UP', 'RIGHT':'DOWN'}
            return dirs[start_dir]

    def _ch_direction(self, sq, dir):

        if dir == 'LEFT':
            sq.rotate.update({'none':'rt_left',
                              'left':'rt_180',
                              'right':None,
                              '180': 'rt_right'})

        elif dir == 'RIGHT':
            sq.rotate.update({'none':'rt_right',
                              'left':None,
                              'right':'rt_180',
                              '180': 'rt_left'})

        else:
            print "Warning: Try to change direction in a wrong way:"
            print "         %s is not a valid string for 'dir'." % dir

    def _rotate(self):

        for sq in self.field:
            if sq.kind == 'ROTATOR':
                self._ch_direction(sq, sq.direction)
                sq.rotate['costs'] = 1.5

        for sq in [sq for sq in self.field if sq.kind in ['CONVEYOR', 'PUSHER']]:
            dir = sq.direction

            basic = self._basic_move(sq, dir, 0.5, 1)[0]
            if basic == 'DEATH':
                self._add_death(sq, 'ROTATE')
                continue

            end_sq = basic['end_sq']
            sq.end_x, sq.end_y = basic['end_pos']
            costs = basic['costs']

            if end_sq.kind == 'JUNK_PRESS' and sq.kind != 'PUSHER':
                self._add_death(sq, 'ROTATE')
                continue

            elif end_sq.kind == 'ROTATOR':
                costs += 0.5
                self._ch_direction(sq, end_sq.direction)

            sq.rotate['costs'] = costs

            if sq.kind == 'PUSHER':
                pass


        for sq in [sq for sq in self.field if sq.kind == 'CONVEYOR']:
            if sq.rotate == 'DEATH':
                self._add_death(sq, 'ROTATE')
                continue

            end_sq = self.get_pos(sq.end_x, sq.end_y)
            end_kind = end_sq.kind

            if end_kind == 'CONVEYOR':
                dirs = {'UP':'LEFT', 'DOWN':'RIGHT', 'RIGHT':'UP', 'LEFT':'DOWN'}
                if dirs[sq.direction] == end_sq.direction:
                    sq.rotate['costs'] += 0.5
                    self._ch_direction(sq, 'LEFT')

                elif dirs[self._not_dir(sq.direction)] == end_sq.direction:
                    sq.rotate['costs'] += 0.5
                    self._ch_direction(sq, 'RIGHT')

            elif end_kind == 'PUSHER':
                sq.end_x, sq.end_y = end_sq.x, end_sq.y
                sq.rotate['costs'] += end_sq.rotate['costs']
                sq.rotate['left'] = end_sq.rotate['left']
                sq.rotate['right'] = end_sq.rotate['right']
                sq.rotate['180'] = end_sq.rotate['180']
                sq.rotate['none'] = end_sq.rotate['none']
                sq.end_x = end_sq.end_x
                sq.end_y = end_sq.end_y

        ## roating on a oil sq
        for sq in self.field:
            end_sq = self.get_pos(sq.end_x, sq.end_y)
            if end_sq.kind == 'OIL':
                end_sq.rotate['left'] = end_sq.rotate['180']
                end_sq.rotate['right'] = end_sq.rotate['180']
                end_sq.rotate['180'] = end_sq.rotate['none']

        ## add to reversed
        for sq in self.field:
            end_sq = self.get_pos(sq.end_x, sq.end_y)

            if sq.rotate == 'DEATH':
                continue

            for rt_dir in sq.rotate:
                if rt_dir in ['left', 'right', '180']:
                    for start_dir in ['LEFT', 'RIGHT', 'UP', 'DOWN']:
                        end_dir = self._rt_dir(start_dir, sq.rotate[rt_dir])
                        self._add_reversed(end_sq.x, end_sq.y, end_dir, (sq.x, sq.y),
                                           start_dir, sq.rotate['costs'])

    def _check_out_of_range(self, x, y):

        if not 0 <= x < self.row_len:
            return True

        if not 0 <= y < self.col_len:
            return True

        return False

    def _add_to_dict(self, dic, x, y, kind):

        if dic.has_key((x, y)):
            dic[(x, y)].add(kind)
        else:
            dic[(x, y)] = set([kind])

    def _add_death(self, sq, kind):

        if kind == 'ROTATE':
            sq.rotate = 'DEATH'
        else:
            sq.MV[kind[1]][kind[0]] = 'DEATH'
        self._add_to_dict(self.death, sq.x, sq.y, kind)

    def _add_reversed(self, end_x, end_y, end_dir, start_pos, start_dir, costs):

        end_sq = self.get_pos(end_x, end_y)
        info = {'start_pos':start_pos, 'start_dir':start_dir, 'costs':costs}
        move = (end_x, end_y, end_dir)

        if self.reversed.has_key(move):
            self.reversed[move].append(info)
        else:
            self.reversed[move] = [info]

    def _basic_move(self, sq, dir, move_cost, max_length):

        moves = []
        for i in range(max_length):
            moves.append({'end_pos':(sq.x, sq.y), 'end_sq':sq, 'costs':1})

        length = 1
        while length <= max_length:
            ## walls
            if not sq.move[dir]:
                break

            elif dir == 'LEFT':
                end_x = sq.x - 1
                end_y = sq.y

            elif dir == 'RIGHT':
                end_x = sq.x + 1
                end_y = sq.y

            elif dir == 'UP':
                end_x = sq.x
                end_y = sq.y - 1

            elif dir == 'DOWN':
                end_x = sq.x
                end_y = sq.y + 1

            if self._check_out_of_range(end_x, end_y):

                for i in xrange(length-1, max_length):
                    moves[i] = 'DEATH'
                break

            end_sq = self.get_pos(end_x, end_y)

            ## walls
            if not end_sq.move[self._not_dir(dir)]:
                break

            if end_sq.kind == 'HOLE':
                for i in xrange(length-1, max_length):
                    moves[i] = 'DEATH'
                break

            elif end_sq.kind == 'OIL':
                for move in moves[length-1:]:
                    move['costs'] += 0.5

            else:
                for move in moves[length-1:]:
                    move['end_pos'] = end_x, end_y
                    move['end_sq'] = end_sq
                    move['costs'] += move_cost
                length += 1

            if end_sq.kind == 'GOAL':
                ## self.goal_sq == end_sq
                break

            sq = end_sq

        return moves

    def _rt_dir(self, old_dir, rt_dir):

        if rt_dir == None:
            return old_dir

        elif old_dir == 'LEFT':
            dirs = {'rt_left':'DOWN', 'rt_right':'UP', 'rt_180':'RIGHT'}
            return dirs[rt_dir]

        elif old_dir == 'RIGHT':
            dirs = {'rt_left':'UP', 'rt_right':'DOWN', 'rt_180':'LEFT'}
            return dirs[rt_dir]

        elif old_dir == 'UP':
            dirs = {'rt_left':'LEFT', 'rt_right':'RIGHT', 'rt_180':'DOWN'}
            return dirs[rt_dir]

        elif old_dir == 'DOWN':
            dirs = {'rt_left':'RIGHT', 'rt_right':'LEFT', 'rt_180':'UP'}
            return dirs[rt_dir]

    def _move(self, sq, start_dir):

        ## you cannot stand on a hole or goal sq,
        ## so there is no need to check those sqs
        if sq.kind in ['HOLE', 'GOAL']:
            return None

        basic = self._basic_move(sq, start_dir, 1, 3)
        for i in range(3):
            if basic[i] == 'DEATH':
                for move in xrange(i+1, 4):
                    self._add_death(sq, (move, start_dir))
                break

            end_sq = basic[i]['end_sq']
            moves = i+1

            if end_sq.rotate == 'DEATH':
                self._add_death(sq, (moves, start_dir))

            else:
                end_dir = self._rt_dir(start_dir, end_sq.rotate['none'])
                costs = end_sq.rotate['costs'] + basic[i]['costs'] - 1

                sq.MV[start_dir][moves]['end_pos'] = end_sq.end_x, end_sq.end_y
                sq.MV[start_dir][moves]['dir'] = end_dir
                sq.MV[start_dir][moves]['costs'] = end_sq.rotate['costs'] + \
                                                   basic[i]['costs'] - 1

                self._add_reversed(end_sq.end_x, end_sq.end_y, end_dir,
                                   (sq.x, sq.y), start_dir, costs)

                ## card MB
                if i == 1:
                    self._add_reversed(end_sq.end_x, end_sq.end_y, end_dir,
                                   (sq.x, sq.y), self._not_dir(start_dir), costs)


    def _check_minimal(self):
        """
        A* similar path finding function
        create list self.minimal containing the kind (x, y, dir) and
        the minimal costs to reach the goal from this sq with this dir
        """
        minimal = {}
        open_list = []
        closed_list = []
        costs = {}
        highest = 0

        for dir in ['LEFT', 'RIGHT', 'UP', 'DOWN']:
            goal_kind = (self.goal_sq.x, self.goal_sq.y, dir)
            if self.reversed.has_key(goal_kind):
                open_list.append(goal_kind)
                costs[goal_kind] = 0

        while True:
            if not open_list:
                break

            chosen = open_list[0]
            closed_list.append(chosen)
            open_list.pop(0)

            #if costs[chosen] > highest:
             #   break

            if not chosen in self.reversed:
                continue

            for root in self.reversed[chosen]:
                start_pos = root['start_pos']
                new_kind = (start_pos[0], start_pos[1], root['start_dir'])
                mv_costs = costs[chosen] + root['costs']

                if new_kind in minimal:
                    minimal[new_kind] = min(minimal[new_kind], mv_costs)
                else:
                    minimal[new_kind] = mv_costs

                highest = max(highest, minimal[new_kind])

                if not new_kind in closed_list and new_kind in self.reversed:

                    if open_list == []:
                        open_list = [new_kind]

                    if new_kind in costs:
                        costs[new_kind] = max(costs[new_kind], mv_costs)
                    else:
                        costs[new_kind] = mv_costs

                        for x, kind in enumerate(open_list):
                            if mv_costs < costs[open_list[x]]:
                                open_list.insert(x, new_kind)
                                break

                            ## never breaked -> highest costs
                            if x + 1 == len(open_list):
                                open_list.append(new_kind)
                                break

        self.minimal = minimal

    def parse(self):

        self._rotate()
        for sq in self.field:
            for dir in ['LEFT', 'RIGHT', 'UP', 'DOWN']:
                self._move(sq, dir)

        for sq in self.field:
            for c_dir in ['LEFT', 'RIGHT', 'UP', 'DOWN']:
                not_dir = self._not_dir(c_dir)
                if sq.MV[c_dir][1] != 'DEATH':
                    sq.MV[not_dir][-1] = {}
                    sq.MV[not_dir][-1].update(sq.MV[c_dir][1])
                    sq.MV[not_dir][-1]['dir'] = self._not_dir(sq.MV[not_dir][-1]['dir'])
                else:
                    sq.MV[not_dir][-1] = 'DEATH'

        self._check_minimal()

    def __str__(self):
        """slow way to create a string - just use for testing"""

        string = ''
        for x, i in enumerate(self.field):
            string += repr(i)

            if (x + 1) % self.row_len == 0:
                string += "\n"

        return string

if __name__ == '__main__':
    from pprint import pprint
    field = Field('boards/own/circus.dat', 'easy')
    field.parse()

    #print "here", field._basic_move(field.get_pos(2, 4), 'DOWN', 1, 3)

    #print field.get_pos(2, 3).rotate

    #pprint(field._basic_move(field.field[20], 'DOWN', 1, 3))
    #print field.field[2+5*12]

    print field.minimal[2, 5, 'UP']
    print field.minimal[2, 5, 'RIGHT']
    print field.get_pos(2, 5).rotate


    if False:
        print field.get_pos(10, 3).rotate
        print field.get_pos(10, 3).end_x
        print field.get_pos(10, 3).end_y
        print field.reversed[11, 3, 'DOWN']

        print field.minimal[(10, 2, 'DOWN')]
        print field.minimal[(11, 3, 'DOWN')]


    if False:

        def print_move(x, y):
            print "%s, %s:" % (x, y)
            pprint(field.field[x+12*y].MV)
            print "\n"

        print_move(0, 0)
        print_move(2, 2)
        print_move(0, 7)
        print_move(5, 4)
        print_move(10, 10)

        print field.get_pos(3, 0).rotate

        print "check cq_rt:", field.get_pos(10, 10).rotate

        for sq in field.field:
            if sq.end_x < 0 or sq.end_y < 0:
                print "fail at", sq.x, sq.y

    if False:
        for dir in ['LEFT', 'RIGHT', 'UP', 'DOWN']:
            if field.reversed.has_key((field.goal_sq.x, field.goal_sq.y, dir)):
                print field.reversed[(field.goal_sq.x, field.goal_sq.y, dir)]

        print "reversed:"
        for kind in field.reversed:
            print "\n"
            print kind, field.reversed[kind]
        print

    #print field.death[(0,1)]

    if False:
        print "comparing parse with load time:"

        f = open('foobar.dmp', 'w')
        pickle.dump(field, f)
        f.close()

        print "parse 100x:",
        import time
        p_start = time.time()
        for i in range(100):
            print i
            field.parse()
        p_end = time.time()

        print p_end - p_start

        print "load  100x:",
        l_start = time.time()
        for i in range(100):
            f = open('foobar.dmp')
            foo = pickle.load(f)
            f.close()
        l_end = time.time()

        print l_end - l_start
        print
        print "factor:", (l_end - l_start) / (p_end - p_start)
