#!/usr/bin/env python
#
#       ai.py
#
#       Copyright 2009 Mario Fuest <mario@mario-desktop>
#
#       This program is free software; you can redistribute it and/or modify
#       it under the terms of the GNU General Public License as published by
#       the Free Software Foundation; either version 3 of the License, or
#       (at your option) any later version.
#
#       This program is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU General Public License for more details.
#
#       You should have received a copy of the GNU General Public License
#       along with this program; if not, write to the Free Software
#       Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#       MA 02110-1301, USA.

from field import Field
from player import Player

## equivalent to itertools.permutations (but works with Python 2.5, too)
def permutations(iterable, r=None):
    # permutations('ABCD', 2) --> AB AC AD BA BC BD CA CB CD DA DB DC
    # permutations(range(3)) --> 012 021 102 120 201 210
    pool = tuple(iterable)
    n = len(pool)
    r = n if r is None else r
    if r > n:
        return
    indices = range(n)
    cycles = range(n, n-r, -1)
    yield tuple(pool[i] for i in indices[:r])
    while n:
        for i in reversed(range(r)):
            cycles[i] -= 1
            if cycles[i] == 0:
                indices[i:] = indices[i+1:] + indices[i:i+1]
                cycles[i] = n - i
            else:
                j = cycles[i]
                indices[i], indices[-j] = indices[-j], indices[i]
                yield tuple(pool[i] for i in indices[:r])
                break
        else:
            return

class AI(object):

    rotates = {'RL':'left',
               'RR':'right',
               'RU':'180'}

    moves = {'MF 1':1,
            'MF 2':2,
            'MF 3':3,
            'MB':-1}

    #cards = dict(rotates, **moves)

    def __init__(self, board, difficulty):

        self.player = Player()
        self.field = Field(board, difficulty)
        self.field.parse()

    def _get_move(self, card, sq, dir):
        """
        returns the result of a move:
        {'end_pos':(tupel of x,y ),
         'dir' enddir ['LEFT', 'RIGHT', 'UP', 'DOWN']
         'costs' float of the costs}
        """
        if card in self.rotates:
            if sq.rotate == 'DEATH':
                return sq.rotate

            new_dir = self.field._rt_dir(dir, sq.rotate[self.rotates[card]])
            if not new_dir:
                print "fail because of", new_dir
                return 'DEATH'

            return {'end_pos':(sq.end_x, sq.end_y), 'dir':new_dir,
                    'costs':sq.rotate['costs']}

        elif card in self.moves:
            return sq.MV[dir][self.moves[card]]

        else:
            print "Warning: Unknown card", card
            print "         -> assuming death"
            return 'DEATH'

    def _get_all_moves(self, start_pos, start_dir, cards):

        (x, y) = start_pos
        start_sq = self.field.get_pos(x, y)

        card_set = set([])
        for p in permutations(cards, 5):
            card_set.add(p)

        end = []
        for cards in card_set:
            sq = start_sq
            dir = start_dir
            costs = 0
            normal = True

            for i in range(5):
                move = self._get_move(cards[i], sq, dir)
                if move == 'DEATH':
                    normal = False
                    break

                sq = self.field.get_pos(*move['end_pos'])
                dir = move['dir']
                costs += move['costs']

                if move['end_pos'] == (self.field.goal_sq.x, self.field.goal_sq.y):
                    break

            if normal:
                cards = tuple(cards)
                updated = False
                for e in end:
                    if e['sq'] == sq and e['dir'] == dir:
                        updated = True
                        if costs < e['costs']:
                            e['costs'] = costs
                            e['cards'] = cards

                if not updated:
                    end.append({'sq':sq, 'dir':dir, 'cards':cards,
                                'costs':costs})

        #for i in end: print i
        end.sort(key=lambda obj: obj['costs'])
        return end

    def _check_save(self, sq, dir):

        ## 50% die
        if sq.rotate == 'DEATH':
            return True

        for length in [-1, 1, 2, 3]:
            if sq.MV[dir][length] != 'DEATH':
                return False

        return True

    def find_move(self, cards):

        start_pos = self.player.pos
        start_dir = self.player.dir

        cheapest = None
        self.reached_goal = False
        for move in self._get_all_moves(start_pos, start_dir, cards):

            x = move['sq'].x
            y = move['sq'].y
            dir = move['dir']

            if move['sq'] == self.field.goal_sq:
                self.reached_goal = True
                return move['cards']

            kind = (move['sq'].x, move['sq'].y, move['dir'])
            if kind in self.field.minimal:
                costs = move['costs'] + self.field.minimal[kind]
            else:
                ## applying this move means die on next move
                continue

            if not cheapest:
                cheapest = (move['cards'], costs)
            else:
                if costs < cheapest[1]:
                    cheapest = (move['cards'], costs)

        if not cheapest:
            print "Ill die, cannot survive anymore"
            return cards[:5]

        return cheapest[0]


    def _check_in_list(self, used_list, end):

        old = False
        for move in used_list:
            if end['sq'] == move['sq'] and end['dir'] == move['dir'] and end['cards'] == move['cards']:
                old = True
        return old

    def find_path(self, all_cards):
        """
        A* algorithmus to find fastes path
        need to know all cards
        """
        pos = self.player.pos
        dir = self.player.dir

        sq = self.field.get_pos(*pos)
        minimal_start = self.field.minimal[(pos[0], pos[1], dir)]
        open_list = [{'sq':sq, 'dir':dir, 'round':0, 'cards':None, 'root':None,
                      'g':0, 'h':minimal_start,'f':minimal_start}]
        closed_dict = {}

        while True:
            try:
                chosen = open_list[0]
            except IndexError:
                reached_goal = False
                break

            key = (chosen['sq'], chosen['dir'], chosen['cards'])
            last_move = key
            closed_dict[key] = chosen['root']
            open_list.pop(0)

            ## fastes way found! wohoo
            if chosen['sq'] == self.field.goal_sq:
                reached_goal = True
                break

            x, y = chosen['sq'].x, chosen['sq'].y
            start_dir = chosen['dir']
            round = chosen['round']

            #print "\n\nfor end in self._get_all_moves((%i, %i), %s, all_cards[%i]):" % (x, y, start_dir, round)
            for end in self._get_all_moves((x, y), start_dir, all_cards[round]):
                ## adding move to open_list
                act_closed = (end['sq'], end['dir'], end['cards'])
                if not act_closed in closed_dict:
                    sq = end['sq']
                    g = chosen['g'] + end['costs']
                    if (sq.x, sq.y, end['dir']) in self.field.minimal:
                        h = self.field.minimal[sq.x, sq.y, end['dir']]
                        f = g + h
                    else:
                        continue


                    root = (chosen['sq'], chosen['dir'], chosen['cards'])
                    move_dict = {'sq':end['sq'], 'dir':end['dir'], 'round':round+1,
                                 'root':root, 'cards':end['cards'],
                                 'g':g, 'h':h, 'f':f}

                    if open_list == []:
                        open_list = [move_dict]

                    used = False
                    for x, move in enumerate(open_list):
                        if end['sq'] == move['sq'] and end['dir'] == move['dir'] and end['cards'] == move['cards']:
                            if f < move['f']:
                                open_list[x].update(move_dict)
                                used = True
                            else:
                                break

                    if not used:
                        for x, move in enumerate(open_list):
                            if f < move['f']:
                                open_list.insert(x, move_dict)
                                break

                            ## never breaked -> highest costs
                            if x + 1 == len(open_list):
                                open_list.append(move_dict)
                                break

        path = []
        while last_move[2]:
            path.insert(0, last_move[2])
            last_move = closed_dict[last_move]

        if not reached_goal:
            path.append[False]

        return path

if __name__ == '__main__':
    import pprint
    all = 0
    for card in range(1):

        f = open('../decks/carddeck0%.2i.dat' % card)
        cards = f.readlines()
        f.close()

        all_cards = []
        for x, i in enumerate(cards):
            if x % 8 == 0:
                all_cards.append([])
            all_cards[x//8].append(i.strip('\n'))

        ai = AI('../gameboards/chop.dat', 'hard')

        #print "here", ai.find_move()

        if False:
            print ai._get_move('MF 1', ai.field.get_pos(0, 0), 'RIGHT')
            print ai._get_move('MF 2', ai.field.get_pos(0, 0), 'DOWN')
            print ai._get_move('MF 3', ai.field.get_pos(0, 0), 'DOWN')
            print ai._get_move('MB', ai.field.get_pos(0, 0), 'LEFT')
            print ai._get_move('MF 1', ai.field.get_pos(0, 0), 'DOWN')
            print ai._get_move('MF 1', ai.field.get_pos(11, 6), 'UP')

        #sq = ai.field.get_pos(0, 0)
        #print ai.field._rt_dir('DOWN', sq.rotate[ai.rotates['RR']])

        #pprint.pprint(ai._get_all_moves((0, 0), 'DOWN', all_cards[0]))
        print ai.find_path(all_cards)

