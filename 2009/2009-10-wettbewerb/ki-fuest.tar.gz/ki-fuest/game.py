#!/usr/bin/env python
#
#       game.py
#
#       Copyright 2009 Mario Fuest <mario@mario-desktop>
#
#       This program is free software; you can redistribute it and/or modify
#       it under the terms of the GNU General Public License as published by
#       the Free Software Foundation; either version 3 of the License, or
#       (at your option) any later version.
#
#       This program is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU General Public License for more details.
#
#       You should have received a copy of the GNU General Public License
#       along with this program; if not, write to the Free Software
#       Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#       MA 02110-1301, USA.

import shutil
import os
import os.path
import cPickle as pickle
from time import time

from ai import AI

class Game(object):

    def __init__(self, difficulty='hard', cheating='off', deck_dir='../decks'):
        """
        init game
        difficulty: easy, medium, hard
        cheating: off, normal, extreme
        deck_dir: used deck directory for extreme cheating
        """

        self.ai = AI('board.txt', difficulty)

        self.difficulty = difficulty
        self.cheating = cheating
        self.cards = self._read_cards()
        move = ''

        if cheating != 'off':
            move = self.cheat()

        else:
            move = self.ai.find_move(self.cards)

        self.save_move(move)

    def _read_cards(self):

        f = open('cards.txt')
        cards = f.readlines()
        f.close()
        self.cards = []
        for card in cards[:8]:
            self.cards.append(card.strip('\n'))

        return self.cards

    def _copy_decks(self, deck_dir):

        shutil.rmtree('decks/', ignore_errors=True)
        shutil.copytree(deck_dir, 'decks/')

    def _init_infos(self):

        f = open('infos.dmp', 'w')
        act_time = time()
        infos = {'deck':0, 'round':0, 'in_progress':False,
                 'last_read':act_time, 'card_sets':{}}
        pickle.dump(infos, f)
        f.close()

        return infos

    def _get_infos(self):

        dmp = 'infos.dmp'
        if not os.path.exists(dmp):
            infos = self._init_infos()

        f = open('infos.dmp', 'r+')
        infos = pickle.load(f)

        infos['round'] += 1

        act_time = time()
        if infos['last_read'] + 60 * 45 < act_time: ## infos too old
            infos = self._init_infos()

        else:
            infos['last_read'] = act_time

        pickle.dump(infos, f)
        f.close()
        return infos

    def _set_infos(self, key, value):

        f = open('infos.dmp', 'r+')
        infos = pickle.load(f)
        infos[key] = value
        pickle.dump(infos, f)
        f.close()

        infos = self.infos

    def _get_all_cards(self, deck):

        if not deck in self.infos['card_sets']:
            return False

        cards = self.infos['card_sets'][deck]

        all_cards = []
        for x, i in enumerate(cards):
            if x % 8 == 0:
                all_cards.append([])
            all_cards[x//8].append(i.strip('\n'))

        return all_cards

    def _new_deck(self):

        f = open('infos.dmp', 'r+')
        infos = pickle.load(f)
        if infos['deck'] == 99:
            infos['deck'] = 0
        else:
            infos['deck'] += 1
        infos['round'] = 0

        pickle.dump(infos, f)
        f.close()


    def _save_card_set(self, card_set):

        f = open('infos.dmp', 'r+')
        infos = pickle.load(f)
        infos['card_sets']


        if not infos['deck'] in infos['card_sets']:
            infos['card_sets'][infos['deck']] = []

        for card in infos['card_sets']:
            infos['card_sets'][infos['deck']].append(card)

        pickle.dump(infos, f)
        f.close()

    def cheat(self):

        infos = self._get_infos()
        self.infos = infos

        ## extreme cheating does not work
        #if self.cheating == 'extreme':
         #   self._copy_decks(deck_dir)

        if infos['in_progress']:
            round = infos['round']
            in_progress = infos['in_progress']
            if round in in_progress:
                if in_progress[round]:
                    print "know what to do"
                    return in_progress[round]
            else:
                self._set_infos('in_progress', False)
                self._new_deck()

        all_cards = self._get_all_cards(infos['deck'])
        if all_cards and all_cards[0] == self.cards:

            print "cheating: A* search for best path considering all cards"
            path = self.ai.find_path(all_cards)
            self._set_infos('in_progress', path)

            return path[0]

        #elif all_cards and all_cards[0] != self.cards:
         #   self._init_infos()

        else:
            print "non cheating"
            move = self.ai.find_move(self.cards)
            self._save_card_set(self.cards)

            if self.ai.reached_goal:
                self._new_deck()
            return move

    def save_move(self, move):

        move_str = ''
        for mv in move:
            move_str += mv
            move_str += '\n'

        f = open('ccards.txt', 'w')
        f.write(move_str)
        f.close()

if __name__ == '__main__':
    game = Game(cheating='off')


