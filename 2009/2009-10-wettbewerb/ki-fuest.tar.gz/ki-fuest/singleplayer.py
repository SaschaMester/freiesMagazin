#!/usr/bin/env python
#       singeplayer.py
#
#       Copyright 2009 Mario Fuest <mario@mario-desktop>
#
#       This program is free software; you can redistribute it and/or modify
#       it under the terms of the GNU General Public License as published by
#       the Free Software Foundation; either version 3 of the License, or
#       (at your option) any later version.
#
#       This program is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU General Public License for more details.
#
#       You should have received a copy of the GNU General Public License
#       along with this program; if not, write to the Free Software
#       Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#       MA 02110-1301, USA.

f = open('cards.txt', 'r')
cards = f.readlines()
f.close()

print
print 'Cards: 1: %s' % cards[0],
print '       2: %s' % cards[1],
print '       3: %s' % cards[2],
print '       4: %s' % cards[3],
print '       5: %s' % cards[4],
print '       6: %s' % cards[5],
print '       7: %s' % cards[6],
print '       8: %s' % cards[7],
print

while True:
    ccards = raw_input('Choose five of them: ').split()
    if len(ccards) == 5 and len(set(ccards)) == 5:
        break

    elif ccards == ['new']:
        ccards = ['1', '2', '3', '4', '5']
        break

    else:
        print 'Type five different numbers from 1 to 8, idiot!'

ccards_string = ''
for card in ccards:
    ccards_string += cards[int(card)-1]

f = open('ccards.txt', 'w')
f.write(ccards_string)
f.close()

