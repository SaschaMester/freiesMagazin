#!/usr/bin/env python
#
#       test.py
#
#       Copyright 2009 Mario Fuest <mario@mario-desktop>
#
#       This program is free software; you can redistribute it and/or modify
#       it under the terms of the GNU General Public License as published by
#       the Free Software Foundation; either version 3 of the License, or
#       (at your option) any later version.
#
#       This program is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU General Public License for more details.
#
#       You should have received a copy of the GNU General Public License
#       along with this program; if not, write to the Free Software
#       Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#       MA 02110-1301, USA.

import random

"""
this are functions to test the behaviour of the ai
or some usefull tools.
so these functions are NOT written in a nice way.
"""

def create_field(field, filename):

    if type(field[0]) == type([]):
        field = [i for i in j in field]

    field_str = '12 12\n'
    for x, CQ in enumerate(field):
        if CQ == None: field_str += ' '
        elif CQ == 'HOLE': field_str += 'H'
        elif CQ == 'START_LEFT':field_str += 'S'
        elif CQ == 'START_RIGHT': field_str += 'T'
        elif CQ == 'START_UP': field_str += 'U'
        elif CQ == 'START_DOWN': field_str += 'V'
        elif CQ == 'OIL': field_str += 'O'
        elif CQ == 'GOAL': field_str += 'Z'
        elif CQ == 'RT_LEFT': field_str += 'L'
        elif CQ == 'RT_RIGHT': field_str += 'R'
        elif CQ == 'CQ_LEFT': field_str += '<'
        elif CQ == 'CQ_RIGHT': field_str += '>'
        elif CQ == 'CQ_UP': field_str += '^'
        elif CQ == 'CQ_DOWN': field_str +='v'
        elif CQ == 'MV_LEFT': field_str += 'C'
        elif CQ == 'MV_RIGHT': field_str += 'D'
        elif CQ == 'MV_UP': field_str += 'E'
        elif CQ == 'MV_DOWN': field_str +='F'
        elif CQ == 'PRESS_-': field_str +='M'
        elif CQ == 'PRESS_|': field_str +='N'
        elif CQ in range(16): field_str += chr(CQ + 97)
        else: print "hrmpf", x, CQ

        if (x + 1) % 12 == 0:
            field_str += '\n'

    print field_str

    f = open(filename, 'w')
    f.write(field_str)
    f.close()


def create_random(filename, kind_list):
    field = ['START_DOWN']
    for i in xrange(142):
        field.append(random.choice(kind_list))
    field.append('GOAL')

    create_field(field, filename)

create_field(field, 'boards/other/snakepit.dat')
