﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//    This program was designed for the programming contest of <http://www.freiesmagazin.de/>
//    Copyright (C) 2009 Martin Sommer
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.﻿
namespace SeeSharpSoft.Games.Cards.RoboRally
{
    public class RoboCard
    {
		public static Dictionary<String, CardType> CARDCODING = new Dictionary<String, CardType>();
		
		static RoboCard()
		{
			CARDCODING.Add("MF 1", CardType.MoveForwardOne);
			CARDCODING.Add("MF 2", CardType.MoveForwardTwo);
            CARDCODING.Add("MF 3", CardType.MoveForwardThree);
            CARDCODING.Add("MB", CardType.MoveBackwardOne);
            CARDCODING.Add("RL", CardType.TurnLeft);
            CARDCODING.Add("RR", CardType.TurnRight);
            CARDCODING.Add("RU", CardType.TurnAround);
		}
		
		public static int GetActionCount(CardType cardType)
		{
			switch(cardType)
			{
				case CardType.MoveForwardTwo:
					return 2;
				case CardType.MoveForwardThree:
					return 3;
				default:
					return 1;
			}
		}
		
		public static RoboCard DecodeCard(String encoded)
		{
			encoded = encoded.Trim();
			return new RoboCard(CARDCODING[encoded]);
		}
		
		public static string EncodeCard(RoboCard card)
		{
			return EncodeCard(card.CardType);
		}		
		
		public static string EncodeCard(CardType cardType)
		{
			foreach(KeyValuePair<String, CardType> ct in CARDCODING)
			{
				if(ct.Value == cardType) return ct.Key; 
			}
			//this shouldnt happen!
			return "???";
		}
		
        private CardType _cardType = CardType.Undefined;

        public CardType CardType
        {
            get { return _cardType; }
            set { _cardType = value; }
        }

        public RoboCard(CardType type)
        {
            CardType = type;
        }

        public IEnumerable<RoboAction> GetActionList(Direction direction)
        {
            switch (CardType)
            {
                case CardType.MoveBackwardOne:
                    return new RoboAction[] { new RoboMovement(RoboRotation.Rotate(direction, Rotation.Around)) };
                case CardType.MoveForwardOne:
                    return new RoboAction[] { new RoboMovement(direction) };
                case CardType.MoveForwardTwo:
                    return new RoboAction[] { new RoboMovement(direction), new RoboMovement(direction) };
                case CardType.MoveForwardThree:
                    return new RoboAction[] { new RoboMovement(direction), new RoboMovement(direction), new RoboMovement(direction) };
                case CardType.TurnLeft:
                    return new RoboAction[] { new RoboRotation(Rotation.Left) };
                case CardType.TurnRight:
                    return new RoboAction[] { new RoboRotation(Rotation.Right) };
                case CardType.TurnAround:
                    return new RoboAction[] { new RoboRotation(Rotation.Around) };
                case CardType.Undefined:
                    return new RoboAction[] { RoboAction.EMPTY };
            }
            return new RoboAction[] { RoboAction.EMPTY };
        }

        public IEnumerable<RoboAction> GetActionList(RoboPosition position)
        {
            return GetActionList(position.Direction);
        }

        public override string ToString()
        {
            return CardType.ToString();
        }
    }
}
