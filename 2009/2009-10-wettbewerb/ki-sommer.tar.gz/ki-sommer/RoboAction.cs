﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeeSharpSoft.Games.RoboRally
{
    public class RoboAction
    {
        public static readonly RoboAction EMPTY = new RoboAction();

        public virtual RoboPosition PerformAction(RoboPosition position, RoboBoard board)
        {
            return PerformAction(position);
        }
        public virtual RoboPosition PerformAction(RoboPosition position)
        {
            return position;
        }

        public override bool Equals(object obj)
        {
            return obj != null && obj.GetHashCode() == this.GetHashCode();
        }
		
		public override int GetHashCode()
		{
			return this.GetType().GetHashCode();
		}
    }
	
	public class RoboDie : RoboAction
	{
		public override RoboPosition PerformAction(RoboPosition position)
		{
			return new RoboPosition(position.X, position.Y, position.Direction, true);
		}
	}

	public class RoboMovement : RoboAction
    {
        public static readonly RoboMovement UP = new RoboMovement(Direction.Up);
        public static readonly RoboMovement DOWN = new RoboMovement(Direction.Down);
        public static readonly RoboMovement LEFT = new RoboMovement(Direction.Left);
        public static readonly RoboMovement RIGHT = new RoboMovement(Direction.Right);

        private Direction _direction;
        
        public Direction Direction {
        	get {
        		return _direction;
        	}
			set {
				_direction = value;
			}
        }

        public RoboMovement(Direction direction)
        {
            Direction = direction;
        }

        public override RoboPosition PerformAction(RoboPosition position, RoboBoard board)
        {
            RoboField field = board.GetField(position);

            if (!field.CanLeave(this.Direction)) return position;

            RoboPosition result = PerformAction(position);

            RoboField neighbor = board.GetField(result);

            if (neighbor == null || !neighbor.CanEnter(RoboRotation.Rotate(this.Direction, Rotation.Around))) return position;

            return result;
        }

        public override RoboPosition PerformAction(RoboPosition position)
        {
            switch (Direction)
            {
                case Direction.Up:
                    return new RoboPosition(position.X, position.Y - 1, position.Direction);
                case Direction.Left:
                    return new RoboPosition(position.X - 1, position.Y, position.Direction);
                case Direction.Right:
                    return new RoboPosition(position.X + 1, position.Y, position.Direction);
                case Direction.Down:
                    return new RoboPosition(position.X, position.Y + 1, position.Direction);
            }
            return position;
        }

		public override int GetHashCode()
		{
			return (int)Direction;
		}
    }
	
	public class RoboRotation : RoboAction
    {
        public static readonly RoboRotation NONE = new RoboRotation(Rotation.None);
        public static readonly RoboRotation LEFT = new RoboRotation(Rotation.Left);
        public static readonly RoboRotation RIGHT = new RoboRotation(Rotation.Right);
        public static readonly RoboRotation AROUND = new RoboRotation(Rotation.Around);

        private Rotation _rotation;
        
        public Rotation Rotation {
        	get {
        		return _rotation;
        	}
			set {
				_rotation = value;
			}
        }

        public RoboRotation(Rotation rotation)
        {
            Rotation = rotation;
        }

        public RoboRotation(Direction previous, Direction next)
            : this(GetRotation(previous, next))
        {
        }

        public static Direction Rotate(Direction direction, Rotation rotation)
        {
            switch (rotation)
            {
                case Rotation.Around:
                    return (Direction)(((int)direction + 2) % 4);
                case Rotation.Left:
                    return (Direction)(((int)direction + 3) % 4);
                case Rotation.Right:
                    return (Direction)(((int)direction + 1) % 4);
                default:
                    return direction;
            }
        }

        public static Rotation GetRotation(Direction previousDirection, Direction newDirection)
        {
            if (previousDirection == newDirection) return Rotation.None;
            if (IsOpposite(previousDirection, newDirection)) return Rotation.Around;
            if ((int)previousDirection == (int)(newDirection + 3) % 4) return Rotation.Right;
            return Rotation.Left;
        }

        public static bool IsOpposite(Direction a, Direction b)
        {
            return ((int)a - (int)b) % 2 == 0;
        }

        public Direction Rotate(Direction direction)
        {
            return Rotate(direction, this.Rotation);
        }

		public override int GetHashCode()
		{
			return (int)Rotation;
		}

        public override RoboPosition PerformAction(RoboPosition position)
        {
            return new RoboPosition(position.X, position.Y, Rotate(position.Direction));
        }
    }

}
