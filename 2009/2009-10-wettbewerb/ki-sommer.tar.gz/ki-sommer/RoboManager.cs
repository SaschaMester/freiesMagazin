﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SeeSharpSoft.Games.RoboRally.GUI;
using System.Threading;
using System.Windows.Forms;

namespace SeeSharpSoft.Games.RoboRally
{
	/// <summary>
	/// This class is supposed to be main actor to play with human players and interact between those.
	/// </summary>
    public class RoboManager
    {
        public static BoardControl GUI { set; get; }

        public static RoboPosition PerformAction(RoboBoard board, ActionPhase actionPhase, RoboAction action, RoboPosition position)
        {
            if (GUI != null)
            {
                GUI.RoboPosition = new RoboPosition(position.X - 1, position.Y - 1, position.Direction);
                GUI.Refresh();
                Thread.Sleep(5);
                Application.DoEvents();
                //Thread.Sleep(10);
            }

            if (action == null) return position;

            position = action.PerformAction(position, board);
            return PerformAction(board, actionPhase, board.GetField(position).OnRobotAction(actionPhase, action, position), position);
        }

        public static RoboPosition PlayCard(RoboBoard board, RoboCard card, RoboPosition position)
        {
            RoboPosition result = new RoboPosition(position.X, position.Y, position.Direction);
            foreach (RoboAction action in card.GetActionList(result))
            {
                result = PerformAction(board, ActionPhase.ActionCard, action, result);
            }

            result = PerformAction(board, ActionPhase.ActionConveyor, RoboAction.EMPTY, result);
            result = PerformAction(board, ActionPhase.ActionPusher, RoboAction.EMPTY, result);
            result = PerformAction(board, ActionPhase.ActionRotator, RoboAction.EMPTY, result);

            return result;
        }

        public static RoboCard[] CardPile { set; get; }

        public static void CreateCardPile()
        {
            List<RoboCard> temp = CreateCardPile(5600);
			Random randomizer = new Random();
			
			CardPile = new RoboCard[temp.Count];
		    for (int k = 0; k < temp.Count; k++)
            {
                int randomIndex = randomizer.Next(temp.Count);
                CardPile[k] = temp[randomIndex];
                temp.RemoveAt(randomIndex);
            }
        }

        /// <summary>
        /// Creates a cardpile with respect to the probabilities of the seven different cardtypes.
        /// </summary>
        /// <param name="nrOfCards">Size of the pile - pile can be have some more cards to keep correct distribution of the cards.</param>
        /// <returns>Cardpile.</returns>
        public static List<RoboCard> CreateCardPile(int nrOfCards)
        {
            List<RoboCard> cards = new List<RoboCard>(nrOfCards);
            int max = (int)Math.Ceiling(nrOfCards / 14d);
            for (int i = 0; i < max; i++)
            {
                cards.Add(new RoboCard(CardType.MoveForwardThree));
                cards.Add(new RoboCard(CardType.MoveBackwardOne));
                cards.Add(new RoboCard(CardType.TurnAround));

                cards.Add(new RoboCard(CardType.MoveForwardTwo));
                cards.Add(new RoboCard(CardType.MoveForwardTwo));

                cards.Add(new RoboCard(CardType.MoveForwardOne));
                cards.Add(new RoboCard(CardType.MoveForwardOne));
                cards.Add(new RoboCard(CardType.MoveForwardOne));

                cards.Add(new RoboCard(CardType.TurnLeft));
                cards.Add(new RoboCard(CardType.TurnLeft));
                cards.Add(new RoboCard(CardType.TurnLeft));

                cards.Add(new RoboCard(CardType.TurnRight));
                cards.Add(new RoboCard(CardType.TurnRight));
                cards.Add(new RoboCard(CardType.TurnRight));
            }

            return cards;
        }



    }
}
