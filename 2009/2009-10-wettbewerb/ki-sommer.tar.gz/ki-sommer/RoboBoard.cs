﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;

namespace SeeSharpSoft.Games.RoboRally
{
    public class RoboBoard
    {
		private RoboField[,] _fields;

        private Size _size;
        public Size Size { set { _size = value; _fields = new RoboField[_size.Width, _size.Height]; } get { return _size; } }

        public RoboField[,] Fields {
        	get {
        		return _fields;
        	}
        }

        public void Save(String filename)
        {
            StreamWriter writer = new StreamWriter(filename, false);
            writer.WriteLine(this.Size.Width + " " + this.Size.Height);
            writer.WriteLine(this.ToString());
            writer.Close();
        }

        public bool Load(String filename, Difficulty difficulty)
        {
            System.IO.StreamReader reader = null;
            try
            {
                reader = new System.IO.StreamReader(filename);

                Size = GetSize(reader.ReadLine());

                for (int y = 0; y < Size.Height; y++)
                {
                    for (int x = 0; x < Size.Width; x++)
                    {
						RoboField field = null;
						if (y == 0 || x == 0 || y == Size.Height - 1 || x == Size.Width - 1)
						{
							field = (difficulty == Difficulty.Hard ?
								RoboField.CreateField(FieldType.Hole) : RoboField.DecodeField('p'));
						}
						else
						{
							char encoded = (char)reader.Read();
                            if (encoded == '\r' || encoded == '\n')
                            {
                                x--;
                                continue;
                            }
                            field = (difficulty == Difficulty.Easy &&
									(encoded == RoboField.EncodeField(FieldType.Hole) ||
									encoded == RoboField.EncodeField(FieldType.Oil) ||
									encoded == RoboField.EncodeField(FieldType.ScrapLeftRight) ||
									encoded == RoboField.EncodeField(FieldType.ScrapUpDown))) ?
										RoboField.DecodeField(' ') :
										RoboField.DecodeField(encoded);
						}

                        field.X = x;
                        field.Y = y;
                        field.Board = this;

                        Fields[x, y] = field;
                    }
                    //new line?!
                    if(y > 0 && y < Size.Height - 1) reader.Read();
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                if (reader != null) reader.Close();
            }
            return true;
        }

        public RoboField GetField(RoboPosition position)
        {
            if (position.Y < 0 || position.X < 0 || position.Y >= Size.Height || position.X >= Size.Width) return null;
            return Fields[position.X, position.Y];
        }

        public RoboField GetDestination()
        {
            for (int y = 0; y < Size.Height; y++)
            {
                for (int x = 0; x < Size.Width; x++)
                {
                    if (Fields[x, y].IsDestination) return Fields[x, y];
                }
            }
            return null;
        }

        public RoboField GetStart()
        {
            for (int y = 0; y < Size.Height; y++)
            {
                for (int x = 0; x < Size.Width; x++)
                {
                    if (Fields[x, y].IsStart) return Fields[x, y];
                }
            }
            return null;
        }

        private static Size GetSize(String sizeLine)
        {
            String[] split = sizeLine.Split(' ');
            return new Size(int.Parse(split[0]) + 2, int.Parse(split[1]) + 2);
        }

        public override string ToString()
        {
            return ToString(null);
        }

        public string ToString(RoboPosition position)
        {
            StringBuilder result = new StringBuilder();
            for (int y = 0; y < Size.Height; y++)
            {
                for (int x = 0; x < Size.Width; x++)
                {
                    if (position != null && position.X == x && position.Y == y) result.Append('X');
                    else result.Append(Fields[x, y]);
                }
                result.AppendLine();
            }
            return result.ToString();
        }
    }
}
