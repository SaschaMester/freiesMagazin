using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
//    This program was designed for the programming contest of <http://www.freiesmagazin.de/>
//    Copyright (C) 2009 Martin Sommer
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.﻿
namespace SeeSharpSoft.Games.Board.RoboRally
{
    public class RoboBoard
    {
		private RoboField[,] _fields;
        private Size _size;
        public Size Size { set { _size = value; _fields = new RoboField[_size.Width, _size.Height]; } get { return _size; } }

        public RoboField[,] Fields {
        	get {
        		return _fields;
        	}
        }

        public bool Load(String filename, Difficulty difficulty)
        {
            System.IO.StreamReader reader = null;
            try
            {
                reader = new System.IO.StreamReader(filename);

                Size = GetSize(reader.ReadLine());

                for (int y = 0; y < Size.Height; y++)
                {
                    for (int x = 0; x < Size.Width; x++)
                    {
						RoboField field = null;
						if (y == 0 || x == 0 || y == Size.Height - 1 || x == Size.Width - 1)
						{
							field = (difficulty == Difficulty.Hard ?
								RoboField.CreateField(FieldType.Hole) : RoboField.DecodeField('p'));
						}
						else
						{
							char encoded = (char)reader.Read();
                            field = (difficulty == Difficulty.Easy &&
									(encoded == RoboField.EncodeField(FieldType.Hole) ||
									encoded == RoboField.EncodeField(FieldType.Oil) ||
									encoded == RoboField.EncodeField(FieldType.ScrapLeftRight) ||
									encoded == RoboField.EncodeField(FieldType.ScrapUpDown))) ?
										RoboField.DecodeField(' ') :
										RoboField.DecodeField(encoded);
						}

                        field.X = x;
                        field.Y = y;
                        field.Board = this;

                        Fields[x, y] = field;
                    }
                    //new line?!
                    if(y > 0 && y < Size.Height - 1) reader.Read();
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                if (reader != null) reader.Close();
            }
            return true;
        }

        public RoboField GetField(RoboPosition position)
        {
            if (position.Y < 0 || position.X < 0 || position.Y >= Size.Height || position.X >= Size.Width) return null;
            return Fields[position.X, position.Y];
        }

        private static Size GetSize(String sizeLine)
        {
            String[] split = sizeLine.Split(' ');
            return new Size(int.Parse(split[0]) + 2, int.Parse(split[1]) + 2);
        }

        public override string ToString()
        {
            return ToString(null);
        }

        public string ToString(RoboPosition position)
        {
            StringBuilder result = new StringBuilder();
            for (int y = 0; y < Size.Height; y++)
            {
                for (int x = 0; x < Size.Width; x++)
                {
                    if (position != null && position.X == x && position.Y == y) result.Append('X');
                    else result.Append(Fields[x, y]);
                }
                result.AppendLine();
            }
            return result.ToString();
        }
    }
}