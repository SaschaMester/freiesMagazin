﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace SeeSharpSoft.Games.RoboRally
{
    public class RoboPosition
    {
		public static RoboPosition LoadPosition(String filename)
		{
			StreamReader reader = new StreamReader(filename);
			RoboPosition result = DecodePosition(reader.ReadLine());
			reader.Close();
			return result;
		}
		
		public static RoboPosition DecodePosition(String position)
		{
			String[] parts = position.Split(' ');
			Direction direction = Direction.Up;
			switch(parts[2])
			{
			case "L":
				direction = Direction.Left;
				break;
			case "R":
				direction = Direction.Right;
				break;
			case "D":
				direction = Direction.Down;
				break;
			case "U":
				direction = Direction.Up;
				break;
			}
			return new RoboPosition(int.Parse(parts[0]), int.Parse(parts[1]), direction); 
		}
		
        private int _x, _y;
        private Direction _direction;
        private bool _isDead = false;
        
        public int X {
        	get {
        		return _x;
        	}
			set {
				_x = value;
			}
        }

        public int Y {
        	get {
        		return _y;
        	}
			set {
				_y = value;
			}
        }

        public Direction Direction {
        	get {
        		return _direction;
        	}
			set {
				_direction = value;
			}
        }

        public bool IsDead {
        	get {
        		return _isDead;
        	}
			set {
				_isDead = value;
			}
        }

        public RoboPosition(int x, int y, Direction direction, bool isDead) : this(x, y, direction)
        {
            IsDead = isDead;
        }		
		
        public RoboPosition(int x, int y, Direction direction)
        {
            X = x;
            Y = y;
            Direction = direction;
        }

        public override string ToString()
        {
            return String.Format("Position: [{0}, {1}]; Direction: {2}", X, Y, Direction);
        }

        public override bool Equals(object obj)
        {
            RoboPosition pos = obj as RoboPosition;
            return pos != null && pos.X == this.X && pos.Y == this.Y && pos.Direction == this.Direction && pos.IsDead == this.IsDead;
        }
		
		public override int GetHashCode()
		{
			return EncodePosition(this.X, this.Y, this.Direction);
		}

        public static int EncodePosition(int positionX, int positionY, Direction direction)
        {
            return ((int)direction << 24) | (positionX << 12) | positionY;
        }

        public static RoboPosition DecodePosition(int position)
        {
            return new RoboPosition(((0x00FFF000 & position) >> 12), (0x00000FFF & position), (Direction)((0x0F000000 & position) >> 24));
        }
    }
}
