using System;
using System.Collections.Generic;
using SeeSharpSoft.Collections;

namespace SeeSharpSoft.Games.RoboRally.Players.KI
{
	public class RoboKIPlayer : RoboPlayer
	{			
		private StateGraph _stateGraph;
		
		public StateGraph StateGraph {
			get {
				return _stateGraph;
			}
			set
			{
				_stateGraph = value;
			}
		}

		public SeeSharpSoft.Games.RoboRally.RoboPosition Position {
			get {
				return _position;
			}
			set
			{
				_position = value;
			}
		}
		
		private RoboPosition _position;
		
		public RoboKIPlayer(StateGraph graph, RoboPosition position)
		{
			StateGraph = graph;
			Position = position;
		}
		
		public RoboCard[] CalculateCards()
		{
			RoboCard[] result = null;
			
			ICollection<int> permutations = Permutation(Cards, 0, 5);
			
			double bestRating = double.MaxValue;
            double rating = double.MaxValue;
			//if there is no way out of misery (robo will die for sure), some cards must be chosen somehow

            RoboCard[] cards;
			foreach(int encodedCards in permutations)
			{
                cards = RoboCard.DecodeCards(encodedCards);

                if (result == null) result = cards;

				rating = CalculateRating(cards);
				
				if(rating < bestRating)
				{					
					bestRating = rating;
					result = cards;
					
					//Console.WriteLine("Found better solution: {0} => {1}", bestRating.ToString("n0"), GetCardString(StateGraph, result, Position));
				}
			}

			return result;
		}

		//This method doesnt really belong here - just did it for quick "debugging" -> damn, really(!!) miss the debugging feature of VS ;)
		public static String GetCardString(StateGraph graph, IEnumerable<RoboCard> cards, RoboPosition pos)
		{
			String result = "";
			RoboPosition finalPosition = new RoboPosition(pos.X, pos.Y, pos.Direction);
			foreach(RoboCard card in cards)
			{
				finalPosition = graph.PerformAction(card, finalPosition);
				result += card + " (" + finalPosition + "); ";
			}
			return result;
		}
		
		private double CalculateRating(RoboCard[] cards)
		{
			RoboPosition target = new SeeSharpSoft.Games.RoboRally.RoboPosition(Position.X, Position.Y, Position.Direction);
			//use counter to take winning move with less cards
			int counter = int.MinValue;
			foreach(RoboCard card in cards)
			{
                if (StateGraph.Board.GetField(target).IsDestination) return counter;
				target = StateGraph.PerformAction(card, target);
				counter++;
			}
			return StateGraph.GetNode(target).Rating;
		}
		
		//does any generic permutation/combination function exist in .NET?? (should be!)
        public static ICollection<int> Permutation(RoboCard[] cards, int start, int n)
        {
            HashSetEx<int> result = new HashSetEx<int>();

            if (start == n)
            {
                result.Add(RoboCard.EncodeCards(cards));
            }
            else
            {
                for (int i = start; i < cards.Length; i++)
                {
                    RoboCard tmp = cards[i];

                    cards[i] = cards[start];
                    cards[start] = tmp;

                    result.AddRange(Permutation(cards, start + 1, n));

                    cards[start] = cards[i];
                    cards[i] = tmp;
                }
            }

            return result;
        }

	}
}
