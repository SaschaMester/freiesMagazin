﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SeeSharpSoft.Collections;
using System.Windows.Forms;
using System.Drawing;
//    This program was designed for the programming contest of <http://www.freiesmagazin.de/>
//    Copyright (C) 2009 Martin Sommer
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.﻿
namespace SeeSharpSoft.Games.RoboRally.Players.KI
{
    public class WeightCalculator
    {
		private int _nrOfSimulations = 3300;
		
		public WeightCalculator(StateGraph graph)
        {
            Graph = graph;
        }

        public WeightCalculator(StateGraph graph, int nrOfTest)
            : this(graph)
        {
            _nrOfSimulations = nrOfTest;
        }
		
        private StateGraph _graph;

        public StateGraph Graph
        {
            get { return _graph; }
            set { _graph = value; }
        }


        /// <summary>
        /// Get or set how many simulations shall be done.
        /// </summary>
        public int SimulationCount
        {
            get { return _nrOfSimulations; }
            set { _nrOfSimulations = value; }
        }

        #region not used for GeorgW
        private double _calcFactor = 1d;
        private int _calculationDepth = -1;
        private int CalculationDepth
        {
            get
            {
                if (_calculationDepth < 0) _calculationDepth = CalculationFactor * (Graph.Nodes.Count - 8*(Graph.Board.Size.Width + Graph.Board.Size.Height) + 16) + Graph.Board.Size.Width * Graph.Board.Size.Height;
                return _calculationDepth;
            }
            set
            {
                _calculationDepth = value;
            }
        }

        private int CalculationFactor
        {
            get
            {
                //calc with double to enable something like (SimulationCount / 8.5) * 1.5
                return (int)Math.Ceiling((SimulationCount / 100) * _calcFactor);
            }
        }

        #endregion

        GenericHashtable<FieldNode, GenericHashtable<int, FieldNode>> _cachedMoves;

		private int _pileSize = 5600;
        private List<FieldNode> _targets;
        /// <summary>
        /// Get all target nodes - that will be 4 nodes.
        /// </summary>
        public List<FieldNode> Targets
        {
            get
            {
                if (_targets == null) _targets = GetTargetNodes();
                return _targets;
            }
        }

        /// <summary>
        /// Get whether given position is the destination.
        /// </summary>
        /// <param name="position">Position to check.</param>
        /// <returns>True if position is destination field, false else.</returns>
        private bool IsDestination(RoboPosition position)
        {
            return Graph.Board.GetField(position).IsDestination;
            //return Targets.Contains(Graph.GetNode(position));
        }

        public void DoCalculate()
        {
            _cachedMoves = new GenericHashtable<FieldNode, GenericHashtable<int, FieldNode>>(Graph.Nodes.Count);
            DateTime start = DateTime.Now;

            DoCalcGeorgW();

			//alternative calculation method with unsatisfying calculation-formula and -results
			//DoCalcVersionMAX();
			
            DateTime stop = DateTime.Now;
			Console.WriteLine("Weighting took " + (stop - start));
        }

        #region GeorgCalc

        private void DoCalcGeorgW()
        {
			CalcNodeDistance(Targets[0]);
			
            List<FieldNode> ignoreList = new List<FieldNode>();
            GenericHashtable<FieldNode, FieldNode> simNodes = GetGeorgSimulationNodes(ignoreList);

            foreach (FieldNode node in simNodes.Keys)
            {
                node.Rating = node.Distance;
            }

            double penalty = Graph.Board.Size.Width * Graph.Board.Size.Height;
            //double penalty = simNodes.Last(elem => !ignoreList.Contains(elem.Key)).Key.Distance * 5f;

            foreach (FieldNode node in ignoreList)
            {
                if (IsDestination(node.Position)) node.Rating = 0d;
                else node.Rating = penalty;

                simNodes.Remove(node);
            }

            SimulationCount -= simNodes.Count;

            double start = 0.7d;
            double end = 0.999d;

            double a = 1d - start;
            double b = (-1d / SimulationCount) * Math.Log((1d - end) / a);

            int round = 0;
            double weight = 0d;

            double best = 0d;
            Dictionary<int, IEnumerable<int>> cardCombos = CreateCardCombinations();
            GenericHashtable<int, FieldNode> cachedMovesNode;

            foreach (KeyValuePair<int, IEnumerable<int>> cardElem in cardCombos)
            {
                weight = 1d - a * Math.Exp(-b * round);

                foreach (FieldNode node in simNodes.Keys)
                {
                    cachedMovesNode = _cachedMoves[node];

                    ICollection<FieldNode> hits = CalcNodeHitsCached(node, cardElem.Value, cachedMovesNode);
                    best = double.PositiveInfinity;
                    foreach (FieldNode target in hits)
                    {
                        if (target.Rating < best) best = target.Rating;
                    }
                    //node.Key.Rating = weight * node.Key.Rating + (1d - weight) * (1d + best);
                    node.Rating = weight * node.Rating + 1d + best - weight - weight*best;
                }

                round++;
            }

            //adjust some ratings
            foreach (FieldNode node in Graph.Nodes)
            {
                if (IsDestination(node.Position)) node.Rating = 0;
                else if (node.Rating == 0 || ignoreList.Contains(node)) node.Rating = double.PositiveInfinity;
            }
        }

		//dont calculate for fields, that cant/shouldnt be reached
        private GenericHashtable<FieldNode, FieldNode> GetGeorgSimulationNodes(
            List<FieldNode> fieldsToIgnore
        )
        {
            GenericHashtable<FieldNode, FieldNode> result =
                new GenericHashtable<FieldNode, FieldNode>(Graph.Nodes.Count);

            IEnumerable<int> allCardCombos = CreateAllCardCombinations();

            FieldNode proofNode;

            Stack<FieldNode> nodesToProof = new Stack<FieldNode>(Graph.Nodes.Count);
            nodesToProof.Push(Graph.GetStartNode());

            result.Add(Graph.GetStartNode(), Graph.GetStartNode());

            GenericHashtable<int, FieldNode> cachedMovesNode;

            while (nodesToProof.Count > 0)
            {
                proofNode = nodesToProof.Pop();

                if (proofNode.GetHashCode() == 0 || IsDestination(proofNode.Position))
                {
                    fieldsToIgnore.Add(proofNode);
                    continue;
                }

                cachedMovesNode = new GenericHashtable<int, FieldNode>(17000);

                ICollection<FieldNode> hits = CalcNodeHitsUncached(proofNode, allCardCombos, cachedMovesNode);

                _cachedMoves.Add(proofNode, cachedMovesNode);

                //ignore fields that leads to dead for sure - also target node will be ignored
                //(ignored nodes will be removed from simulationnodes at the end)
                if (hits.Count < 3)
                {
                    fieldsToIgnore.Add(proofNode);
                    continue;
                }

                foreach (FieldNode target in hits)
                {
                    if (!result.ContainsKey(target))
                    {
                        result.Add(target,target);
                        nodesToProof.Push(target);
                    }
                }

            }

            return result;
        }
//Ford-Bellmann to get first-round node ratings
//01  für jedes v aus V                   
//02      Distanz(v) := unendlich
//03  Distanz(s) := 0
//
//04  wiederhole n - 1 mal               
//05      für jedes (u,v) aus E
//06          wenn Distanz(u) + Gewicht(u,v) < Distanz(v)
//07          dann
//08              Distanz(v) := Distanz(u) + Gewicht(u,v)
        private void CalcNodeDistance(FieldNode destination)
        {
            destination.Distance = 0;

            for (int i = 0; i < Graph.Nodes.Count - 1; i++)
            {
                foreach (FieldNode node in Graph.Nodes)
                {
                    foreach (object elem in Enum.GetValues(typeof(CardType)))
                    {
                        FieldNode neighbor = node.Moves[elem] as FieldNode;

                        if (neighbor.Distance + node.Costs[neighbor] < node.Distance)
                        {
                            node.Distance = neighbor.Distance + (int)node.Costs[neighbor];
                        }
                    }
                }
            }

        }
		//Replaces general function 'CalcNodeHits(...)' in case we know that NO moves are cached yet
		private ICollection<FieldNode> CalcNodeHitsUncached(FieldNode node, IEnumerable<int> combos, GenericHashtable<int, FieldNode> cachedMoves)
        {
            HashSet<FieldNode> hits = new HashSet<FieldNode>();
            foreach (int encodedCards in combos)
            {
                FieldNode target = Graph.PerformActionCore(RoboCard.DecodeCards(encodedCards), node);
            	cachedMoves.Add(encodedCards, target);

                if (!hits.Contains(target)) hits.Add(target);
            }
            return hits;
        }
		//Replaces general function 'CalcNodeHits(...)' in case we know that ALL moves are cached
		private ICollection<FieldNode> CalcNodeHitsCached(FieldNode node, IEnumerable<int> combos, GenericHashtable<int, FieldNode> cachedMoves)
        {
            HashSet<FieldNode> hits = new HashSet<FieldNode>();
            foreach (int encodedCards in combos)
            {
                FieldNode target = cachedMoves[encodedCards];

                if (!hits.Contains(target)) hits.Add(target);
            }
            return hits;
        }
		
        #endregion

		#region CalcMAX
		
        private void DoCalcVersionMAX()
        {
            //Probabilities for each node to die within one round - will be calculated within the simulation
            GenericHashtable<FieldNode, decimal> dieDict = new GenericHashtable<FieldNode, decimal>(Graph.Nodes.Count);

            //Simulation will happen here!
            GenericHashtable<FieldNode, GenericHashtable<FieldNode, decimal>> oneRoundProbs = CreateOneRoundProbabilities(dieDict);

            DateTime start = DateTime.Now;

            GenericHashtable<FieldNode, decimal> prevDict = null;
            GenericHashtable<FieldNode, decimal> notProbDict = new GenericHashtable<FieldNode, decimal>(oneRoundProbs.Count);
            GenericHashtable<FieldNode, decimal> probDict = new GenericHashtable<FieldNode, decimal>(oneRoundProbs.Count);
            decimal probability = 0m;
            decimal probTemp = 0m;

            foreach (KeyValuePair<FieldNode, GenericHashtable<FieldNode, decimal>> nodeElem in oneRoundProbs)
            {
                if (IsDestination(nodeElem.Key.Position))
                {
                    notProbDict.Add(nodeElem.Key, 0m);
                    probDict.Add(nodeElem.Key, 1m);
                }
                else
                {
                    notProbDict.Add(nodeElem.Key, 1m);
                    probDict.Add(nodeElem.Key, 0m);
                }
            }

            //foreach (KeyValuePair<int, GenericHashtable<FieldNode, double>> stepElem in result)
            for (int round = 1; round < CalculationDepth; round++)
            {
                prevDict = probDict;
                probDict = new GenericHashtable<FieldNode, decimal>(oneRoundProbs.Count);

                foreach (KeyValuePair<FieldNode, GenericHashtable<FieldNode, decimal>> node in oneRoundProbs)
                {
                    GenericHashtable<FieldNode, decimal> neighbourDict = node.Value;
					
                    probTemp = 1m;
                    probability = 0m;
                    foreach (KeyValuePair<FieldNode, decimal> elem in neighbourDict)
                    {
                        //if (node.Key == elem.Key) continue;

						probTemp = elem.Value * prevDict[elem.Key];
						if (probTemp > probability) probability = probTemp;
						
                        //probTemp *= (1m - elem.Value * prevDict[elem.Key]);
                    }

                    probability = (1m - dieDict[node.Key]) * probability;

                    //probability += (1m - probability) * prevDict[node.Key];
                    //probability = (1m - probTemp) * (1m - dieDict[node.Key]);
					
                    probDict.Add(node.Key, probability);

					probTemp = probability * notProbDict[node.Key];
					
                    node.Key.Rating += (double)(round * probTemp);
					
                    //notProbDict[node.Key] = notProbDict[node.Key] * (1d - probability);
                    notProbDict[node.Key] -= probTemp;
                }
            }

            //adjust some ratings
            foreach (FieldNode node in Graph.Nodes)
            {
                if (IsDestination(node.Position)) node.Rating = 0;
                else if (node.Rating == 0) node.Rating = double.PositiveInfinity;
//				else node.Rating += (double)((1m - probDict[node]) * CalculationDepth);
                else node.Rating += (double)(notProbDict[node] * CalculationDepth);
            }

            DateTime stop = DateTime.Now;
            Console.WriteLine("Calculation took " + (stop - start) + " - " + CalculationDepth);
        }

        /// <summary>
        /// Creates an dictionary containing all nodes and their probabilities for reaching any "reachable" neighbour node within one round.
        /// Probabilities will be calculated with a so called "Monte-Carlo-Simulation".
        /// </summary>
        /// <param name="dieDict">Probabilities for each node to die within one round. (dictionary will be modified/extended by this method)</param>
        /// <returns>Dictionary containing all nodes and their probabilities for reaching any "reachable" neighbour node within one round.</returns>
        private GenericHashtable<FieldNode, GenericHashtable<FieldNode, decimal>> CreateOneRoundProbabilities(
            GenericHashtable<FieldNode, decimal> dieDict
        )
        {
            Dictionary<int, IEnumerable<int>> cardCombos = CreateCardCombinations();

            DateTime start = DateTime.Now;

            List<FieldNode> fieldsToIgnore = new List<FieldNode>(50);

            GenericHashtable<FieldNode, GenericHashtable<FieldNode, decimal>> result = GetSimulationNodes(fieldsToIgnore);

            //cache moves for a complete combination of 5 cards -> highly increases calculation!
            
            GenericHashtable<int, FieldNode> cachedMovesNode;

            GenericHashtable<FieldNode, decimal> probDict;
            
            FieldNode calcNode;

            decimal singleProp = 1m / (SimulationCount + 1m);

            foreach (FieldNode node in fieldsToIgnore) result.Remove(node);

            foreach (KeyValuePair<FieldNode, GenericHashtable<FieldNode, decimal>> simulationElement in result)
            {
                calcNode = simulationElement.Key;
                probDict = simulationElement.Value;
                cachedMovesNode = _cachedMoves[calcNode];

				if(!dieDict.ContainsKey(calcNode)) dieDict.Add(calcNode, 0m);
				
                foreach (KeyValuePair<int, IEnumerable<int>> elem in cardCombos)
                {
                    ICollection<FieldNode> hits = CalcNodeHits(calcNode, elem.Value, cachedMovesNode);
                    foreach (FieldNode target in hits)
                    {
                        probDict[target] += singleProp;
                    }
                    //only one node can be reached - a dead end for sure (except destination field - will be handled after iteration)
                    if (hits.Count == 1) dieDict[calcNode] += singleProp;
                }
            }

            foreach (FieldNode node in fieldsToIgnore)
            {
				probDict = new GenericHashtable<FieldNode, decimal>();
                if (IsDestination(node.Position))
				{
					dieDict.Add(node, 0m);
					probDict.Add(node, 1m);
				}
                else
				{
					dieDict.Add(node, 1m);
					probDict.Add(Graph.GetNode(0), 1m);
				}

                result.Add(node, probDict);
            }
			
            DateTime stop = DateTime.Now;
            Console.WriteLine("Simulation took " + (stop - start) + " - " + result.Count);

            return result;
        }

        //dont calculate for fields, that cant/shouldnt be reached
        private GenericHashtable<FieldNode, GenericHashtable<FieldNode, decimal>> GetSimulationNodes(
            List<FieldNode> fieldsToIgnore
        )
        {
            GenericHashtable<FieldNode, GenericHashtable<FieldNode, decimal>> result =
                new GenericHashtable<FieldNode, GenericHashtable<FieldNode, decimal>>(Graph.Nodes.Count);

            IEnumerable<int> allCardCombos = CreateAllCardCombinations();
            GenericHashtable<FieldNode, decimal> probDict;
            FieldNode proofNode;
            decimal singleProp = 1m / (SimulationCount + 1m);

            Stack<FieldNode> nodesToProof = new Stack<FieldNode>(Graph.Nodes.Count);
            nodesToProof.Push(Graph.GetStartNode());

            result.Add(Graph.GetStartNode(), new GenericHashtable<FieldNode, decimal>(500));

            GenericHashtable<int, FieldNode>  cachedMovesNode;

            while (nodesToProof.Count > 0)
            {
                proofNode = nodesToProof.Pop();

                if (proofNode.GetHashCode() == 0 || IsDestination(proofNode.Position))
                {
                    fieldsToIgnore.Add(proofNode);
                    continue;
                }

                probDict = result[proofNode];

                cachedMovesNode = new GenericHashtable<int, FieldNode>(17000);

                ICollection<FieldNode> hits = CalcNodeHits(proofNode, allCardCombos, cachedMovesNode);

                _cachedMoves.Add(proofNode, cachedMovesNode);

                //ignore fields that leads to dead for sure - also target node will be ignored
                //(ignored nodes will be removed from simulationnodes at the end)
                if (hits.Count < 3)
                {
                    fieldsToIgnore.Add(proofNode);
                    continue;
                }

                foreach (FieldNode target in hits)
                {
                    probDict.Add(target, singleProp);
                    if (!result.ContainsKey(target))
                    {
                        result.Add(target, new GenericHashtable<FieldNode, decimal>(Graph.Nodes.Count));
                        nodesToProof.Push(target);
                        //for every node we need to simulate we lower the expectation-calculation-depth to scale overall-performance
                        CalculationDepth -= CalculationFactor;
                    }
                }

            }

            return result;
        }

		#endregion
		
        #region Helper

        /// <summary>
        /// Calculates all nodes that can be reached by given cardcombination from given node.
        /// </summary>
        /// <param name="node">Startnode.</param>
        /// <param name="combos">Set of cardcombinations to check.</param>
        /// <param name="cachedMoves">Cached moves for a complete combination of 5 cards -> highly increases calculation!</param>
        /// <returns>A set of all fields that can be reached from startnode with given cardcombinations.</returns>
        private ICollection<FieldNode> CalcNodeHits(FieldNode node, IEnumerable<int> combos, GenericHashtable<int, FieldNode> cachedMoves)
        {
            HashSet<FieldNode> hits = new HashSet<FieldNode>();
            foreach (int encodedCards in combos)
            {
                FieldNode target = GetTargetFieldNode(node, encodedCards, cachedMoves);

                if (!hits.Contains(target)) hits.Add(target);
            }
            return hits;
        }
        /// <summary>
        /// Returns the node that will be reached by given cardcombination from startnode.
        /// </summary>
        /// <param name="node">Startnode.</param>
        /// <param name="encodedCards">Cardcombination (5 cards).</param>
        /// <param name="cachedMoves">Cached moves for a complete combination of 5 cards -> highly increases calculation!</param>
        /// <returns>Target node.</returns>
        private FieldNode GetTargetFieldNode(FieldNode node, int encodedCards, GenericHashtable<int, FieldNode> cachedMoves)
        {
			if(cachedMoves.ContainsKey(encodedCards)) return cachedMoves[encodedCards];
            FieldNode target = Graph.PerformActionCore(RoboCard.DecodeCards(encodedCards), node);
            cachedMoves.Add(encodedCards, target);
            return target;
        }
        /// <summary>
        /// Randomly creates n ("SimulationCount") handcard-combination-combinations ;) - taking 5 from 8.
        /// </summary>
        /// <returns>n ("SimulationCount") handcard-combination-combinations.</returns>
        private Dictionary<int, IEnumerable<int>> CreateCardCombinations()
        {
            DateTime start = DateTime.Now;

            Random randomizer = new Random();
            int randomIndex;

            List<RoboCard> pile = RoboManager.CreateCardPile(_pileSize);// = RoboManager.CreateCardPile((int)(Math.Ceiling((_nrOfSimulations * 8d) / 14d)) * 14);

            Dictionary<int, IEnumerable<int>> result = new Dictionary<int, IEnumerable<int>>();

            RoboCard[] cards = new RoboCard[8];
            List<int> combos = new List<int>();

            for (int i = 0; i < SimulationCount; i++)
            {
				if(pile.Count == 0) pile = RoboManager.CreateCardPile(_pileSize);
				
                for (int k = 0; k < 8; k++)
                {
                    randomIndex = randomizer.Next(pile.Count);
                    cards[k] = pile[randomIndex];
                    pile.RemoveAt(randomIndex);
                }

                combos = new List<int>();
                foreach (int elem in RoboKIPlayer.Permutation(cards, 0, 5))
                {
                    combos.Add(elem);
                }
                result.Add(i, combos);
            }

            DateTime stop = DateTime.Now;
            Console.WriteLine("Calc cardcombinations took " + (stop - start) + " - " + result.Count);

            return result;
        }

        /// <summary>
        /// Create all 5-card-combinations that ever can be played (7^5).
        /// </summary>
        /// <returns>Set of all 5-card-combinations that ever can be played.</returns>
        private IEnumerable<int> CreateAllCardCombinations()
        {
            List<int> result = new List<int>(17000);

            for (int i1 = 1; i1 < 8; i1++)
                for (int i2 = 1; i2 < 8; i2++)
                    for (int i3 = 1; i3 < 8; i3++)
                        for (int i4 = 1; i4 < 8; i4++)
                            for (int i5 = 1; i5 < 8; i5++)
                                result.Add(i1 | (i2 << 3) | (i3 << 6) | (i4 << 9) | (i5 << 12));

            return result;
        }

        /// <summary>
        /// Returns all target nodes - one destination "field" means four destination "nodes".
        /// </summary>
        /// <returns>Target nodes.</returns>
        private List<FieldNode> GetTargetNodes()
        {
            List<FieldNode> targets = new List<FieldNode>(4);

            foreach (FieldNode node in Graph.Nodes)
            {
                if (Graph.Board.GetField(node.Position).IsDestination) targets.Add(node);
            }

            return targets;
        }

        #endregion
    }
}
