﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeeSharpSoft.Games.RoboRally.Players.KI
{
	/// <summary>
	/// Thought this class would be usefull for KI, but only the static helper methods got used.
	/// </summary>
    public class RoboState
    {
        public RoboState()
        {
            Position = new RoboPosition(0, 0, Direction.Left);
            _playedCards = new RoboCard[5];
        }

        public RoboState(int encodedState)
        {
            EncodedState = encodedState;
        }

        private RoboPosition _position;
        public RoboPosition Position
        {
            get { return _position; }
            set {
                _position = value;

                _encodedState = -1;
            }
        }

        private RoboCard[] _playedCards;
        public RoboCard[] PlayedCards
        {
            get { return _playedCards; }
            set {
                _playedCards = value;

                _encodedState = -1;
            }
        }

        private int _encodedState = -1;
        public int EncodedState
        {
            get {
                if (_encodedState < 0) _encodedState = EncodeState(this);

                return _encodedState;
            }
            set {
                _position = DecodePosition(value >> 16);
                _playedCards = DecodeCards(value & 0x0000FFFF);

                _encodedState = value;
            }
        }

        public override int GetHashCode()
        {
            return EncodedState;
        }

        #region Static helper

        public static int EncodePosition(RoboPosition position)
        {
            return EncodePosition(position.X, position.Y, position.Direction);
        }

        public static int EncodePosition(int positionX, int positionY, Direction direction)
        {
            return ((int)direction << 24) | (positionX << 12) | positionY;
        }

        public static RoboPosition DecodePosition(int position)
        {
            return new RoboPosition(((0x00FFF000 & position) >> 12), (0x00000FFF & position), (Direction)((0x0F000000 & position) >> 24));
        }
		
//		public static int EncodePosition(RoboPosition position)
//        {
//            return EncodePosition(position.X, position.Y, position.Direction, position.IsDead);
//        }		
//		
//		public static int EncodePosition(int positionX, int positionY, Direction direction, bool isDead)
//        {
//            return ((isDead ? 1 : 0) << 20) | ((int)direction << 16) | (positionX << 8) | positionY;
//        }
//
//        public static RoboPosition DecodePosition(int position)
//        {
//            return new RoboPosition(((0x0000FF00 & position) >> 8), (0x000000FF & position), (Direction)((0x000F0000 & position) >> 16), (0x00F00000 & position) > 1);
//        }

        public static int EncodeCards(RoboCard[] cards)
        {
            int result = 0;
            for (int i = 0; i < cards.Length && i < 5; i++) result |= ((int)cards[i].CardType << (i * 3));
            return result;
        }

        public static RoboCard[] DecodeCards(int cards)
        {
            RoboCard[] result = new RoboCard[5];
            for (int i = 0; i < 5; i++) result[i] = new RoboCard((CardType)((cards >> (i * 3)) & 7));
            return result;
        }

        public static int EncodeState(RoboState state)
        {
            return (EncodePosition(state.Position) << 16) | EncodeCards(state.PlayedCards);
        }

        public static RoboState DecodeState(int gamestate)
        {
            return new RoboState(gamestate);
        }

        #endregion
    }
}
