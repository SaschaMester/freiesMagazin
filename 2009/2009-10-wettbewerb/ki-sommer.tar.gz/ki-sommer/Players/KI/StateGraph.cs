﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SeeSharpSoft.Collections;
using System.IO;

namespace SeeSharpSoft.Games.RoboRally.Players.KI
{
    public class StateGraph : Graph<RoboField>
    {
        public static StateGraph CreateGraphCore(RoboBoard board)
        {
            StateGraph result = CreateNodes(board);

            foreach (FieldNode node in result.Nodes)
            {
                //these are all types of cards from 1 to 7 -> dont change the enum!!
                for (int i = 0; i < 8; i++)
                {
                    RoboPosition position = StateGraph.PlayCard(board, new RoboCard((CardType)i),
                            new RoboPosition(node.Field.X, node.Field.Y, node.Direction));

                    if (position.IsDead)
                    {
                        result.AddDirectedEdge(
                            node,
                            //0,0 is dummyfield
                            result.GetNode(0),
                            i);
                    }
                    else
                    {
                        result.AddDirectedEdge(
                            node,
                            result.GetNode(position.GetHashCode()),
                            i);
                    }
                }

            }

            return result;
        }

        public static StateGraph CreateGraph(RoboBoard board)
        {
            StateGraph result = CreateGraphCore(board);
			
			result.CalcNodeRatings();
			
            return result;
        }

        public static StateGraph CreateNodes(RoboBoard board)
        {
            ICollection<Node<RoboField>> nodes = new HashList<Node<RoboField>>(1000);
            for (int y = 0; y < board.Size.Height; y++)
            {
                for (int x = 0; x < board.Size.Width; x++)
				{
					//Graph contains 4 times as many "fields" as the board -> for every direction
					//(thats why some ratings are somehow related to factor 4)
                    nodes.Add(new FieldNode(Direction.Up, board.Fields[x, y]));
                    nodes.Add(new FieldNode(Direction.Right, board.Fields[x, y]));
                    nodes.Add(new FieldNode(Direction.Down, board.Fields[x, y]));
                    nodes.Add(new FieldNode(Direction.Left, board.Fields[x, y]));
                }
            }

            return new StateGraph(board, nodes);
		}
		
        public static RoboPosition PlayCard(RoboBoard board, RoboCard card, RoboPosition position)
		{
            RoboPosition result = new RoboPosition(position.X, position.Y, position.Direction);
            foreach (RoboAction action in card.GetActionList(result))
            {
                if (board.GetField(result).IsDestination) return result;
				result = RoboManager.PerformAction(board, ActionPhase.ActionCard, action, result);
            }

            result = RoboManager.PerformAction(board, ActionPhase.ActionConveyor, RoboAction.EMPTY, result);
            result = RoboManager.PerformAction(board, ActionPhase.ActionPusher, RoboAction.EMPTY, result);
            result = RoboManager.PerformAction(board, ActionPhase.ActionRotator, RoboAction.EMPTY, result);

            return result;
        }

        private RoboBoard _board;
        
        public RoboBoard Board {
        	get {
        		return _board;
        	}
			set {
				_board = value;
			}
        }

        public StateGraph(RoboBoard board, ICollection<Node<RoboField>> nodes) : base(nodes)
        {
            Board = board;
        }

        public FieldNode PerformActionCore(RoboCard card, RoboPosition position)
        {
            return ((FieldNode)GetNode(position).Moves[card.CardType]);
        }

        public RoboPosition PerformAction(RoboCard card, RoboPosition position)
        {
            return PerformActionCore(card, position).Position;
        }

        public FieldNode PerformActionCore(RoboCard card, FieldNode node)
        {
            return (FieldNode)node.Moves[card.CardType];
        }

        public RoboPosition PerformAction(IEnumerable<RoboCard> cards, RoboPosition position)
        {
            RoboPosition result = new RoboPosition(position.X, position.Y, position.Direction, position.IsDead);
            foreach (RoboCard card in cards)
            {
                result = PerformAction(card, result);
            }
            return result;
        }

        public FieldNode PerformActionCore(IEnumerable<RoboCard> cards, FieldNode node)
        {
            FieldNode result = node;
            foreach (RoboCard card in cards)
            {
                result = PerformActionCore(card, result);
            }
            return result;
        }

        public override GraphNode<RoboField> CreateNode()
        {
            return new FieldNode();
        }

        public void SaveRaw(String filename)
        {
            StreamWriter writer = new StreamWriter(filename, false);
            //store original board for later check
            writer.Write(this.ToString());
            writer.Close();
        }

        public void Save(string filename)
        {
			StreamWriter writer = new StreamWriter(filename, false);
			//store original board for later check
			writer.Write(this.Board.ToString());
            foreach (FieldNode field in Nodes)
            {
                foreach (object elem in Enum.GetValues(typeof(CardType)))
                {
                    writer.Write(field.Moves[elem].GetHashCode() + " ");
                }
				writer.WriteLine(field.Rating + " ");
            }
            writer.Close();
        }

        public bool Load(string filename)
        {
			StreamReader reader = new StreamReader(filename);
			
			//check whether board fits the graph by comparing stored board
			String board = Board.ToString();
			char[] result = new char[board.Length]; 
			reader.Read(result, 0, result.Length);
			if(board != new string(result))
			{
				reader.Close();
				return false;			
			}

            char[] separator = new char[] { ' ' };
            String[] nodes = null;
            foreach (FieldNode field in Nodes)
            {
				nodes = reader.ReadLine().Split(separator);
                for (int i = 0; i < 8; i++)
                {
                    this.AddDirectedEdge(field, GetNode(int.Parse(nodes[i])) as FieldNode, i);
                }
				field.Rating = double.Parse(nodes[8]);
            }
			reader.Close();
			
			return true;
        }
		
		public FieldNode GetNode(RoboPosition position)
		{
			return GetNode(position.GetHashCode());
		}
		
		public FieldNode GetNode(int position)
		{
            HashList<Node<RoboField>> nodes = (HashList<Node<RoboField>>)Nodes;
            return nodes[position] as FieldNode;
		}

        public FieldNode GetStartNode()
        {
            RoboField field = Board.GetStart();
            return GetNode(new RoboPosition(field.X, field.Y, field.StartDirection));
        }
		
		public void CalcNodeRatings()
		{
            WeightCalculator calc = new WeightCalculator(this);
            calc.DoCalculate();
		}

        public override String ToString()
		{
			StringBuilder result = new StringBuilder();
			for(int y = 0; y < Board.Size.Height; y++)
			{
				for(int d = 0; d < 4; d++)
				{
					for(int x = 0; x < Board.Size.Width; x++)
					{ 
						int pos = RoboPosition.EncodePosition(x, y, (Direction)d); 
						result.Append(GetNode(pos).Rating.ToString("n2").PadRight(10) + " ");
					}
					result.AppendLine();
				}
				result.AppendLine();
			}
			return result.ToString();
		}
    }
}
