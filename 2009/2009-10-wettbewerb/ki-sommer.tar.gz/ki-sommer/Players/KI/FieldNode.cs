﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SeeSharpSoft.Collections;

namespace SeeSharpSoft.Games.RoboRally.Players.KI
{
    public class FieldNode : GraphNode<RoboField>, IComparable<FieldNode>
    {
        public static Dictionary<CardType, double> PROBABILITY = new Dictionary<CardType, double>();

		static FieldNode()
		{
			PROBABILITY.Add(CardType.Undefined, 0f);
            PROBABILITY.Add(CardType.MoveBackwardOne, 0.071f);
            PROBABILITY.Add(CardType.MoveForwardOne, 0.241f);
            PROBABILITY.Add(CardType.MoveForwardTwo, 0.143f);
            PROBABILITY.Add(CardType.MoveForwardThree, 0.071f);
            PROBABILITY.Add(CardType.TurnLeft, 0.241f);
            PROBABILITY.Add(CardType.TurnRight, 0.241f);
            PROBABILITY.Add(CardType.TurnAround, 0.071f);
		}
		
		/// <value>
		/// Encoding of the fieldnode as a simple integer shall improve the speed...
		/// </value>
        private int _hashCode = -1;
		private double _rating = 0d;
        private int _distance = int.MaxValue;

        public int Distance
        {
            get { return _distance; }
            set { _distance = value; }
        }

        private Direction _direction;
        public RoboField Field { get { return Value; } set { Value = value; } }

        private GenericHashtable<CardType, Node<RoboField>> _moves;
        public GenericHashtable<CardType, Node<RoboField>> Moves
        {
            get { return _moves; }
            set { _moves = value; }
        }

        public RoboPosition Position
        {
            get
            {
                return new RoboPosition(Field.X, Field.Y, Direction);
            }
        }

        public SeeSharpSoft.Games.RoboRally.Direction Direction {
        	get {
        		return _direction;
        	}
			set {
				_direction = value;
			}
        }

        public double Rating {
        	get {
        		return _rating;
        	}
			set
			{
				_rating = value;
			}
        }

        public FieldNode()
        {
            Moves = new GenericHashtable<CardType, Node<RoboField>>();
        }

        protected FieldNode(Direction direction)
            : this()
        {
            Direction = direction;
        }

        public FieldNode(Direction direction, RoboField field)
            : this(direction)
        {
            Value = field;
			Rating = 0;
            _hashCode = Position.GetHashCode();
        }

        public static FieldNode CreateFieldNode(RoboBoard board, int encoded)
        {
            RoboPosition position = RoboPosition.DecodePosition(encoded);
            return new FieldNode(position.Direction, board.GetField(position));
        }

        public override void AddNeighbor(Node<RoboField> neighbor, double weight)
        {
			CardType cType = (CardType)weight;
            Moves.Add(cType, neighbor);
//			AdjustRating(neighbor);
			if(!base.Neighbors.Contains(neighbor))
          		base.AddNeighbor(neighbor, 1f);// (1f - PROBABILITY[(CardType)weight]) + 1f);
        }
		
//		private void AdjustRating(Node<RoboField> neighbor)
//		{
//			Rating += neighbor.Rating / 8;
//		}

        public override bool Equals(object obj)
        {
            return obj is FieldNode && obj != null && ((FieldNode)obj)._hashCode == this._hashCode;
        }

        public override int GetHashCode()
        {
            return _hashCode;
        }

        public override string ToString()
        {
            return Position.ToString() + " (" + Distance + "; " + Rating + ")";
        }

        public int CompareTo(FieldNode other)
        {
            int result = this.Distance - other.Distance;
            return result == 0 ? this.GetHashCode() - other.GetHashCode() : result;
        }
    }
}
