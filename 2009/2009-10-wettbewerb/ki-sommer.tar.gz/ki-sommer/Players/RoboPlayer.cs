﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace SeeSharpSoft.Games.RoboRally.Players
{
	/// <summary>
	/// Base class for players - might be useful for later implementation of human players.
	/// </summary>
    public abstract class RoboPlayer
    {
        private RoboCard[] _cards;
		
		public RoboCard[] Cards {
			get {
				return _cards;
			}
			set
			{
				_cards = value;
			}
		}
		
		public RoboPlayer()
		{
			Cards = new RoboCard[8];
		}
		
		public bool ReadCardsFromFile(String filename)
		{
			System.IO.StreamReader reader = null;
            try
            {
                reader = new System.IO.StreamReader(filename);

				for(int i = 0; i < Cards.Length; i++)
				{
					Cards[i] = RoboCard.DecodeCard(reader.ReadLine());
				}
			}
			catch
			{
				return false;
			}
			finally
			{
				 if (reader != null) reader.Close();
			}
			return true;
		}
		
		public static void SaveCardsToFile(String filename, IEnumerable<RoboCard> cards)
		{
			StreamWriter writer = new StreamWriter(filename, false);
            foreach (RoboCard card in cards)
            {
				writer.WriteLine(RoboCard.EncodeCard(card));
            }
            writer.Close();
		}
    }
}
