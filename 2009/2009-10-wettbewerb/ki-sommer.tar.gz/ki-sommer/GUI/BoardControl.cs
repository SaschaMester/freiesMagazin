﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SeeSharpSoft.Games.RoboRally.GUI
{
    public partial class BoardControl : Control
    {
        public static IDictionary<char, string> IMAGENAMES = new Dictionary<char,string>();
        public static IDictionary<char, Image> IMAGES;

        static BoardControl()
        {
            IMAGENAMES.Add('X', "bot.png");
            IMAGENAMES.Add(' ', "floor.png");
            IMAGENAMES.Add('S', "floor.png");
            IMAGENAMES.Add('T', "floor.png");
            IMAGENAMES.Add('U', "floor.png");
            IMAGENAMES.Add('V', "floor.png");
            IMAGENAMES.Add('H', "hole.png");
            IMAGENAMES.Add('O', "oil.png");
            IMAGENAMES.Add('Z', "finish.png");
            IMAGENAMES.Add('L', "rotate-left.png");
            IMAGENAMES.Add('R', "rotate-right.png");
            IMAGENAMES.Add('<', "belt-left.png");
            IMAGENAMES.Add('>', "belt-right.png");
            IMAGENAMES.Add('^', "belt-up.png");
            IMAGENAMES.Add('v', "belt-down.png");
            IMAGENAMES.Add('C', "pusher-left.png");
            IMAGENAMES.Add('D', "pusher-right.png");
            IMAGENAMES.Add('E', "pusher-up.png");
            IMAGENAMES.Add('F', "pusher-down.png");
            IMAGENAMES.Add('M', "squeezer-leftright.png");
            IMAGENAMES.Add('N', "squeezer-updown.png");
            IMAGENAMES.Add('a', "floor.png");
            IMAGENAMES.Add('b', "wall-left.png");
            IMAGENAMES.Add('c', "wall-right.png");
            IMAGENAMES.Add('d', "wall-leftright.png");
            IMAGENAMES.Add('e', "wall-up.png");
            IMAGENAMES.Add('f', "wall-leftup.png");
            IMAGENAMES.Add('g', "wall-rightup.png");
            IMAGENAMES.Add('h', "wall-leftrightup.png");
            IMAGENAMES.Add('i', "wall-down.png");
            IMAGENAMES.Add('j', "wall-leftdown.png");
            IMAGENAMES.Add('k', "wall-rightdown.png");
            IMAGENAMES.Add('l', "wall-leftrightdown.png");
            IMAGENAMES.Add('m', "wall-updown.png");
            IMAGENAMES.Add('n', "wall-leftupdown.png");
            IMAGENAMES.Add('o', "wall-rightupdown.png");
            IMAGENAMES.Add('p', "wall-leftrightupdown.png");
        }

        public static void LoadImages(string basePath)
        {
            IMAGES = new Dictionary<char, Image>();
            foreach (KeyValuePair<char, string> elem in IMAGENAMES)
            {
                IMAGES.Add(elem.Key, Image.FromFile(basePath + "/" + elem.Value));
            }
        }

        public BoardControl()
        {
            this.DoubleBuffered = true;
            this.BackColor = Color.Black;
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public RoboBoard Board { set; get;}
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public RoboPosition RoboPosition { set; get; }

        private float _zoom = 1f;
        [DefaultValue(1f)]
        public float Zoom
        {
            get { return _zoom; }
            set { _zoom = value; }
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            base.OnPaintBackground(e);

            if (Board == null) return;

            if (IMAGES == null) LoadImages(Application.StartupPath + @"/Images/new");

            int fieldSize = GetFieldSize();

            for (int y = 1; y < Board.Size.Height - 1; y++)
            {
                float yPos = (y - 1) * fieldSize * Zoom;
                if (yPos > e.ClipRectangle.Height) break;

                for (int x = 1; x < Board.Size.Width - 1; x++)
                {
                    float xPos = (x - 1) * fieldSize * Zoom;
                    if (xPos > e.ClipRectangle.Width) break;

                    Image image = IMAGES[Board.Fields[x, y].EncodedField];

                    e.Graphics.DrawImage(image, xPos, yPos, fieldSize * Zoom, fieldSize * Zoom);
                }
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            if (RoboPosition == null) return;

            int fieldSize = GetFieldSize();

            Image roboImage = IMAGES['X'];

            switch (RoboPosition.Direction)
            {
                case Direction.Left:
                    roboImage.RotateFlip(RotateFlipType.Rotate180FlipNone);
                    e.Graphics.DrawImage(roboImage,
                        RoboPosition.X * fieldSize * Zoom,
                        RoboPosition.Y * fieldSize * Zoom,
                        fieldSize,
                        fieldSize);
                    roboImage.RotateFlip(RotateFlipType.Rotate180FlipNone);
                    break;
                case Direction.Up:
                    roboImage.RotateFlip(RotateFlipType.Rotate270FlipNone);
                    e.Graphics.DrawImage(roboImage,
                        RoboPosition.X * fieldSize * Zoom,
                        RoboPosition.Y * fieldSize * Zoom,
                        fieldSize,
                        fieldSize);
                    roboImage.RotateFlip(RotateFlipType.Rotate90FlipNone);
                    break;
                case Direction.Down:
                    roboImage.RotateFlip(RotateFlipType.Rotate90FlipNone);
                    e.Graphics.DrawImage(roboImage,
                        RoboPosition.X * fieldSize * Zoom,
                        RoboPosition.Y * fieldSize * Zoom,
                        fieldSize,
                        fieldSize);
                    roboImage.RotateFlip(RotateFlipType.Rotate270FlipNone);
                    break;
                default:
                    e.Graphics.DrawImage(roboImage,
                        RoboPosition.X * fieldSize * Zoom,
                        RoboPosition.Y * fieldSize * Zoom,
                        fieldSize,
                        fieldSize);
                    break;
            }
        }

        public int GetFieldSize()
        {
            if (Board == null) return 0;

            return Math.Min(this.Width / (Board.Size.Width - 2), this.Height / (Board.Size.Height - 2));
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);

            Invalidate();
        }
    }
}
