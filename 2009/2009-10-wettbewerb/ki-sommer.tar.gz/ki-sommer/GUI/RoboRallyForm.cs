﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SeeSharpSoft.Games.RoboRally.Players;
using SeeSharpSoft.Games.RoboRally.Players.KI;
using System.Threading;

namespace SeeSharpSoft.Games.RoboRally.GUI
{
    public partial class RoboRallyForm : Form
    {
		private int _iterations = 10;
		
        public RoboRallyForm()
        {
            InitializeComponent();
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public RoboBoard Board { get { return boardControl.Board; } }

        private void loadBoardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(openFileDialog.ShowDialog(this) != DialogResult.OK) return;

            RoboBoard board = new RoboBoard();
            board.Load(openFileDialog.FileName, Difficulty.Hard);
            boardControl.Board = board;
			
			this.Refresh();
        }

        public List<RoboCard[]> CardPiles { set; get; }

        private void createPilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
		 	CreateCardPiles();
        }
		
		private void CreateCardPiles()
		{
			List<RoboCard[]> piles = new List<RoboCard[]>(_iterations);
            for (int iterations = 0; iterations < _iterations; iterations++)
            {
                RoboManager.CreateCardPile();
                piles.Add(RoboManager.CardPile);
            }
            CardPiles = piles;
		}

        private void startGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Board == null) return;

            //AdjustKI(1f, 17f);

            AdjustKI(1f);

            //Console.WriteLine("{0} mal gestorben, insgesamt {1} Karten gebraucht!", deads, usedCards);

            //MessageBox.Show(String.Format("{0} mal gestorben, insgesamt {1} Karten gebraucht!", deads, usedCards));
        }

        private void AdjustKI(double min, double max)
        {
            Dictionary<double, double> results = new Dictionary<double, double>(20);
            for (int i = 1; i < 20; i++)
            {
                if(!results.ContainsKey(min)) results.Add(min, AdjustKI(min));
                Console.WriteLine("Rating {0} (min): {1}", min, results[min]);
                if (!results.ContainsKey(max)) results.Add(max, AdjustKI(max));
                Console.WriteLine("Rating {0} (max): {1}", max, results[max]);

                if (results[min] == results[max]) break;
                else if (results[min] <= results[max]) max = (min + max) / 2;
                else min = (min + max) / 2;
            }

            min = double.MaxValue;
            foreach(KeyValuePair<double, double> elem in results)
            {
                min = Math.Min(min, elem.Value);
                if(min == elem.Value) max = elem.Key;
            }

            Console.WriteLine("Best: {0}", max);

            MessageBox.Show("Best: " + max + " mit " + min);
        }

        private double AdjustKI(double adjustment)
        {
            //StateGraph.RATEADJUSTMENT = adjustment;
            DateTime start = DateTime.Now;
            StateGraph graph = StateGraph.CreateGraph(Board);

            DateTime stop = DateTime.Now;
            //MessageBox.Show("Calculation took " + (stop - start));

            graph.SaveRaw(Application.StartupPath + "/stategraph.txt");

            //Console.WriteLine(graph.ToString());

            int deads = 0;
            int usedCards = 0;

			if(RoboManager.CardPile == null) CreateCardPiles();
			
            for (int iterations = 0; iterations < _iterations; iterations++)
            {
                RoboManager.CreateCardPile();
                //RoboManager.CardPile = CardPiles[iterations];

                RoboCard[] cards = new RoboCard[8];
                RoboPosition position = graph.GetStartNode().Position;// new RoboPosition(1, 1, Direction.Right);

                int countCards = 0;

                RoboManager.GUI = null;

                RoboKIPlayer player = new RoboKIPlayer(graph, position);

				int round = 0;
                do
                {
                    for (int i = 0; i < 8; i++)
                    {
                        cards[i] = RoboManager.CardPile[round*8 + i];
                    }

                    player.Cards = cards;
                    player.Position = position;

                    RoboCard[] result = player.CalculateCards();

                    RoboManager.GUI = boardControl;
                    //RoboManager.GUI = null;

                    foreach (RoboCard card in result)
                    {
                        countCards++;
                        position = StateGraph.PlayCard(Board, card, position);
                        if (Board.GetField(position).IsDestination) break;
                    }

                    RoboManager.GUI = null;
					
					round++;
                }
                while (!position.IsDead && !Board.GetField(position).IsDestination && round < 700);

                if (position.IsDead) deads++;

                usedCards += countCards;

                Console.WriteLine("{0} mal gestorben, insgesamt {1} Karten gebraucht!", deads, usedCards);
                
                Application.DoEvents();
            }
            MessageBox.Show(String.Format("{0} mal gestorben, insgesamt {1} Karten gebraucht!", deads, usedCards));
            return deads * 1000 + usedCards / (_iterations + 1);
        }

    }
}
