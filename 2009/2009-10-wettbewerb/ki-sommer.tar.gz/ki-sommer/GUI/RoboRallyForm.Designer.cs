﻿namespace SeeSharpSoft.Games.RoboRally.GUI
{
    partial class RoboRallyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.roboRallyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadBoardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.boardControl = new SeeSharpSoft.Games.RoboRally.GUI.BoardControl();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.createPilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.roboRallyToolStripMenuItem,
            this.kIToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(1002, 28);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip";
            // 
            // roboRallyToolStripMenuItem
            // 
            this.roboRallyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadBoardToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.roboRallyToolStripMenuItem.Name = "roboRallyToolStripMenuItem";
            this.roboRallyToolStripMenuItem.Size = new System.Drawing.Size(89, 24);
            this.roboRallyToolStripMenuItem.Text = "RoboRally";
            // 
            // loadBoardToolStripMenuItem
            // 
            this.loadBoardToolStripMenuItem.Name = "loadBoardToolStripMenuItem";
            this.loadBoardToolStripMenuItem.Size = new System.Drawing.Size(155, 24);
            this.loadBoardToolStripMenuItem.Text = "Load board";
            this.loadBoardToolStripMenuItem.Click += new System.EventHandler(this.loadBoardToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(155, 24);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // kIToolStripMenuItem
            // 
            this.kIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.startGameToolStripMenuItem,
            this.createPilesToolStripMenuItem});
            this.kIToolStripMenuItem.Name = "kIToolStripMenuItem";
            this.kIToolStripMenuItem.Size = new System.Drawing.Size(34, 24);
            this.kIToolStripMenuItem.Text = "KI";
            // 
            // startGameToolStripMenuItem
            // 
            this.startGameToolStripMenuItem.Name = "startGameToolStripMenuItem";
            this.startGameToolStripMenuItem.Size = new System.Drawing.Size(155, 24);
            this.startGameToolStripMenuItem.Text = "Start game";
            this.startGameToolStripMenuItem.Click += new System.EventHandler(this.startGameToolStripMenuItem_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel1.Controls.Add(this.boardControl, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 28);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1002, 667);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // boardControl
            // 
            this.boardControl.BackColor = System.Drawing.Color.Black;
            this.boardControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.boardControl.Location = new System.Drawing.Point(3, 3);
            this.boardControl.Name = "boardControl";
            this.boardControl.Size = new System.Drawing.Size(796, 661);
            this.boardControl.TabIndex = 0;
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog";
            // 
            // createPilesToolStripMenuItem
            // 
            this.createPilesToolStripMenuItem.Name = "createPilesToolStripMenuItem";
            this.createPilesToolStripMenuItem.Size = new System.Drawing.Size(155, 24);
            this.createPilesToolStripMenuItem.Text = "Create Piles";
            this.createPilesToolStripMenuItem.Click += new System.EventHandler(this.createPilesToolStripMenuItem_Click);
            // 
            // RoboRallyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1002, 695);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.menuStrip);
            this.MainMenuStrip = this.menuStrip;
            this.Name = "RoboRallyForm";
            this.Text = "RoboRally";
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem roboRallyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadBoardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private BoardControl boardControl;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.ToolStripMenuItem kIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem startGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createPilesToolStripMenuItem;
    }
}