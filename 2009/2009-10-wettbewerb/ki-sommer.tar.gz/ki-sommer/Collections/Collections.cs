using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
//    This program was designed for the programming contest of <http://www.freiesmagazin.de/>
//    Copyright (C) 2009 Martin Sommer
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.﻿
namespace SeeSharpSoft.Collections
{
	//ATTENTION: These collections are only raw implementation for this program - only use them at
	//your own risk! They may not have the expected behavior in all cases...
	
    public class GenericHashtable<K, V> : Hashtable, IEnumerable<KeyValuePair<K, V>>
    {
		public GenericHashtable() : base() {}
		public GenericHashtable(int capacity) : base(capacity) {}
		
        public void Add(K key, V value)
        {
            base.Add(key, value);
        }

        public V this[K key]
        {
            get
            {
                return (V)base[key];
            }
            set
            {
				base[key] = value;
            }
        }
		
		public new IEnumerator<KeyValuePair<K, V>> GetEnumerator()
        {
            foreach (K key in base.Keys) yield return new KeyValuePair<K, V>(key, this[key]);
        }
    }
	
    public class HashList<T> : GenericHashtable<int, T>, IList<T>
    {
		public HashList() : base() {}
		public HashList(int capacity) : base(capacity) {}
		
        #region IList<T> Members

        public int IndexOf(T item)
        {
            return item.GetHashCode();
        }

        public void Insert(int index, T item)
        {
            this.Add(index, item);
        }

        public void RemoveAt(int index)
        {
            base.Remove(index);
        }

        #endregion

        #region ICollection<T> Members

        public void Add(T item)
        {
			int hash = item.GetHashCode();
			if(!base.ContainsKey(hash)) base.Add(hash, item);
        }
		
		public void AddRange(IEnumerable<T> collection)
		{
			foreach(T elem in collection) Add(elem);
		}

        public bool Contains(T item)
        {
            return base.Contains(item.GetHashCode());
        }

        public void CopyTo(T[] array, int arrayIndex)
        {
            base.CopyTo(array, arrayIndex);
        }

        public bool Remove(T item)
        {
            if (!Contains(item)) return false;
            base.Remove(item.GetHashCode());
            return true;
        }

        #endregion

        #region IEnumerable<T> Members

        public new IEnumerator<T> GetEnumerator()
        {
            foreach (T item in base.Values)
            {
                yield return item;
            }
        }

        #endregion
    }

	public class HashSetEx<T> : HashSet<T>
	{
		public void AddRange(IEnumerable<T> collection)
		{
			foreach(T elem in collection)
			{
				if(!this.Contains(elem)) this.Add(elem);
			}
		}
	}
	
    public class Node<T>
    {
        // Private member-variables
        private T data;
        private ICollection<Node<T>> neighbors = null;

        public Node() {}
        public Node(T data) : this(data, null) {}
        public Node(T data, ICollection<Node<T>> neighbors)
        {
            this.data = data;
            this.neighbors = neighbors;
        }

        public T Value
        {
            get
            {
                return data;
            }
            set
            {
                data = value;
            }
        }

        protected ICollection<Node<T>> Neighbors
        {
            get
            {
                return neighbors;
            }
            set
            {
                neighbors = value;
            }
        }

        protected virtual ICollection<Node<T>> CreateNeighborList()
        {
            return new List<Node<T>>();
        }
    }	
	
    public class GraphNode<T> : Node<T>
    {
        private GenericHashtable<Node<T>, double> costs;

        public GraphNode() : base() { }
        public GraphNode(T value) : base(value) { }
        public GraphNode(T value, ICollection<Node<T>> neighbors) : base(value, neighbors) { }

        new public ICollection<Node<T>> Neighbors
        {
            get
            {
                if (base.Neighbors == null)
                    base.Neighbors = CreateNeighborList();

                return base.Neighbors;
            }
        }

        public GenericHashtable<Node<T>, double> Costs
        {
            get
            {
                if (costs == null)
                    costs = new GenericHashtable<Node<T>, double>();

                return costs;
            }
        }

        public void AddNeighbor(Node<T> neighbor)
        {
            AddNeighbor(neighbor, 0f);
        }

        public virtual void AddNeighbor(Node<T> neighbor, double weight)
        {
            Neighbors.Add(neighbor);
            Costs.Add(neighbor, weight);
        }
    }

    public class Graph<T> : IEnumerable<T>
    {
        private ICollection<Node<T>> _nodeSet;

        public Graph() : this(null) { }
        public Graph(ICollection<Node<T>> nodeSet)
        {
            if (nodeSet == null)
                this._nodeSet = CreateNodeSet();
            else
                this._nodeSet = nodeSet;
        }

        public void AddNode(GraphNode<T> node)
        {
            _nodeSet.Add(node);
        }

        public void AddNode(T value)
        {
            AddNode(CreateNode(value));
        }

        public void AddDirectedEdge(GraphNode<T> from, GraphNode<T> to, double cost)
        {
            from.AddNeighbor(to, cost);
        }

        public void AddUndirectedEdge(GraphNode<T> from, GraphNode<T> to, double cost)
        {
            from.AddNeighbor(to, cost);
            to.AddNeighbor(from, cost);
        }

        public GraphNode<T> CreateNode(T value)
        {
            GraphNode<T> result = CreateNode();
            result.Value = value;
            return result;
        }

        public virtual GraphNode<T> CreateNode()
        {
            return new GraphNode<T>();
        }

        protected virtual ICollection<Node<T>> CreateNodeSet()
        {
            return new List<Node<T>>();
        }

        public bool Contains(T value)
        {
			foreach(Node<T> node in Nodes)
			{
				if(node.Value.Equals(value)) return true;
			}
			return false;
//is LinQ fully implemented in Mono yet?!
//            return _nodeSet.First(elem => elem.Value.Equals(value)) != null;
        }

        public ICollection<Node<T>> Nodes
        {
            get
            {
                return _nodeSet;
            }
        }

        public int Count
        {
            get { return _nodeSet.Count; }
        }

        #region IEnumerable<T> Members

        public IEnumerator<T> GetEnumerator()
        {
            throw new NotImplementedException();
        }

        #endregion

        #region IEnumerable Members

        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }

        #endregion
    }
	
}