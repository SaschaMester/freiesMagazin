﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using SeeSharpSoft.Games.RoboRally.Players.KI;
using SeeSharpSoft.Games.RoboRally.Players;

namespace SeeSharpSoft.Games.RoboRally
{
    static class Program
    {
        /// <summary>
        /// Der Haupteinstiegspunkt für die Anwendung.
        /// </summary>
        [STAThread]
        static void Main_GUI(String[] args)
        {
            Application.Run(new GUI.RoboRallyForm());
        }
		[STAThread]
        public static void Main(String[] args)
        {
            Console.WriteLine("SeeSharpSoft's RoboRallyPlayer by GeeK");

            DateTime start = DateTime.Now;

            Console.WriteLine("----- START -----");

            Difficulty difficulty = Difficulty.Hard;

            Console.WriteLine("Set difficulty ...");
            if (args.Length > 0)
            {
                switch (args[0].ToLower())
                {
                    case "easy":
                        difficulty = Difficulty.Easy;
                        break;
                    case "normal":
                        difficulty = Difficulty.Normal;
                        break;
                    case "hard":
                        difficulty = Difficulty.Hard;
                        break;
                }
            }
            Console.WriteLine("=> {0}", difficulty.ToString());

            string cardFile = "./cards.txt";
            string positionFile = "./bot.txt";
            string boardFile = "./board.txt";
            string resultFile = "./ccards.txt";
            string graphFile = boardFile + ".stategraph";

            RoboBoard board = new RoboBoard();
            Console.WriteLine("Load board from {0} ...", boardFile);
            board.Load(boardFile, difficulty);

            //			Console.WriteLine("Board:");
            //			Console.WriteLine(board);			

            StateGraph graph = null;
            Console.WriteLine("Check graph file {0} ...", graphFile);
            System.IO.FileInfo file = new System.IO.FileInfo(graphFile);
            if (!file.Exists)
            {
                Console.WriteLine("Create graph ...");
                graph = StateGraph.CreateGraph(board);

                Console.WriteLine("Graph:");
                Console.WriteLine(graph);

                Console.WriteLine("Save graph file {0} ...", graphFile);
                graph.Save(graphFile);
            }
            else
            {
                Console.WriteLine("Create nodes ...");
                graph = StateGraph.CreateNodes(board);
                Console.WriteLine("Load graph file {0} ...", graphFile);

                if (!graph.Load(graphFile))
                {
                    Console.WriteLine("Graph is outdated ...");
                    Console.WriteLine("Create graph ...");

                    graph = StateGraph.CreateGraph(board);

                    Console.WriteLine("Graph:");
                    Console.WriteLine(graph);

                    Console.WriteLine("Save graph file {0} ...", graphFile);
                    graph.Save(graphFile);
                }
            }


            Console.WriteLine("Load position {0} ...", positionFile);
            RoboPosition position = RoboPosition.LoadPosition(positionFile);
            Console.WriteLine("=> Position: {0}", position);
            //add 1 cause internally the board has a "fieldwall" (holes around the real board) 
            position.X++;
            position.Y++;

            RoboKIPlayer player = new RoboKIPlayer(graph, position);
            Console.WriteLine("Load cards {0} ...", cardFile);
            player.ReadCardsFromFile(cardFile);

            Console.Write(" => ");
            foreach (RoboCard card in player.Cards)
            {
                Console.Write(card + " ");
            }
            Console.WriteLine();

            Console.WriteLine("Start calculation ...");

            RoboCard[] result = player.CalculateCards();

            Console.Write(" => ");
            RoboPosition finalPosition = position;
            foreach (RoboCard card in result)
            {
                finalPosition = graph.PerformAction(card, finalPosition);
                Console.Write(card + " ");
            }
            finalPosition.X--;
            finalPosition.Y--;
            Console.WriteLine();

            Console.WriteLine("### Suggested position: {0}", finalPosition);

            RoboPlayer.SaveCardsToFile(resultFile, result);
            Console.WriteLine("Save result {0} ...", resultFile);

            Console.WriteLine("----- STOP -----");
            DateTime stop = DateTime.Now;
            Console.WriteLine("({0})", stop - start);
        }
    }
}
