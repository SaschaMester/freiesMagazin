# Copyright (c) 2009, Stefan Haller
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.

from globalvars import debug_mode
import globalvars

class Card:
    forward = 0
    rotate = 0
    
    def to_string(self):
        if self.forward != 0:
            if self.forward > 0:
                return 'MF ' + str(self.forward)
            else:
                return 'MB'
        else:
            if self.rotate == -1:
                return 'RL'
            elif self.rotate == 1:
                return 'RR'
            else:
                return 'RU'
        
    def set_from_string(self, string):
        if string == 'MF 1':
            self.forward = 1
            self.rotate = 0
        elif string == 'MF 2':
            self.forward = 2
            self.rotate = 0
        elif string == 'MF 3':
            self.forward = 3
            self.rotate = 0
        elif string == 'MB':
            self.forward = -1
            self.rotate = 0
        elif string == 'RR':
            self.forward = 0
            self.rotate = 1
        elif string == 'RL':
            self.forward = 0
            self.rotate = -1
        elif string == 'RU':
            self.forward = 0
            self.rotate = 2
        else:
            raise


def cards_from_file(lines):
    tmp = []
    
    for line in lines:
        c = Card()
        c.set_from_string(line[:-1])
        tmp.append(c)
    
    if len(tmp) != 8:
        raise
    
    return tmp
