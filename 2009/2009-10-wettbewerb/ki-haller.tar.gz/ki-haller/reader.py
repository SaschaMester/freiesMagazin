# Copyright (c) 2009, Stefan Haller
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.

from globalvars import debug_mode
import globalvars
import bot
import cards
import board


class Reader:
    def read_bot(self):
        f = open(globalvars.filename_bot, 'r')
        line = f.readline()
        f.close()
        self.bot = bot.Bot()
        self.bot.parse_from_file(line[0:-1])
        
    
    def read_board(self):
        f = open(globalvars.filename_board, 'r')
        lines = list(f)
        f.close()
        
        self.board = board.Board()
        self.board.parse_from_file(lines)
    
    def read_cards(self):
        f = open(globalvars.filename_cards, 'r')
        lines = [f.readline() for i in range(0,8)]
        f.close()
        
        self.cards = cards.cards_from_file(lines)
    
    
    def read(self):
        self.read_bot()
        self.read_board()
        self.read_cards()
        
