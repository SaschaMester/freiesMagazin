#! /usr/bin/env python

# Copyright (c) 2009, Stefan Haller
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.

import sys
import multiprocessing
from reader import Reader
import bot
import pathfinding
import globalvars

num_processes = multiprocessing.cpu_count() * 2

class BotProcess(multiprocessing.Process):
    best = sys.maxsize
    best_next = None
    best_cards = []
    
    def test_cards(self, cards):
        running_bot = bot.Bot()
        running_bot.clone(self.bot)
        running_bot.board = self.board
        running_bot.cards = cards
        pos = running_bot.run()
        if pos != None:
            value = self.paths.get_value(pos)
            value_next = -1
            if value is not None:
                better = value < self.best
                
                if value == self.best:
                    value_next = self.paths.get_value_next(pos)
                    if value_next is not None:
                        if self.best_next is None:
                            better = True
                        else:
                            if value_next < self.best_next:
                                better = True
                
                if better:
                    self.best_cards = [card for card in cards]
                    self.best = value
                    if value_next == -1:
                        self.best_next = self.paths.get_value_next(pos)
                    else:
                        self.best_next = value_next
                    
                    if value == 0:
                        return False
        return True
    
    def run(self):
        for i in range(self.start_value, len(self.possibilities), num_processes):
            if not self.test_cards(self.possibilities[i]):
                break
        
        self.pipe.send([self.best, self.best_next, self.best_cards])

class Main:
    best = sys.maxsize
    best_cards = None
    best_pos = None
    best_next = None
    
    reader = None
    bot = None
    board = None
    
    possibilities = None
    
    def iterend(self, cards):
        self.possibilities.append([card for card in cards])
    
    def iter(self, deck, cards, number):
        for card in deck:
            if card not in cards[0:number]:
                cards[number] = card
                if number < 4:
                    result = self.iter(deck, cards, number+1)
                else:
                    result = self.iterend(cards)
    
    def run(self):
        if sys.argv[1] == 'easy':
            globalvars.difficulty = 0
        elif sys.argv[1] == 'normal':
            globalvars.difficulty = 1
        elif sys.argv[1] == 'hard':
            globalvars.difficulty = 2
        else:
            print('Need difficulty!')
            raise
        
        self.reader = Reader()
        self.reader.read()
        
        self.board = self.reader.board
        self.bot = self.reader.bot
        
        paths = pathfinding.Pathfinding()
        paths.board = self.board
        paths.init()
        
        self.possibilities = []
        cards = [ None for i in range(0,5) ]
        self.iter(self.reader.cards, cards, 0)
        
        processes = []
        for i in range(0, num_processes):
            process = [None, None]
            processes.append(process)
            process[0] = BotProcess()
            process[0].possibilities = self.possibilities
            process[0].bot = self.bot
            process[0].board = self.board
            process[0].paths = paths
            process[0].start_value = i
            process[1], process[0].pipe = multiprocessing.Pipe()
            process[0].start()
        
        for process in processes:
            process[0].join()
            best, best_next, best_cards = process[1].recv()
            better = best < self.best
            
            if best == self.best:
                if best_next is not None:
                    if self.best_next is None:
                        better = True
                    else:
                        if best_next < self.best_next:
                            better = True
            
            if better:
                self.best_cards = best_cards
                self.best = best
                self.best_next = best_next
        
        if self.best_cards is None:
            print('----------------------------------------')
            print('* WARNING: No way found, bot will die! *')
            print('----------------------------------------')
            
            self.best_cards = []
            counter = 1
            for card in self.reader.cards:
                if counter > 5:
                    break
                self.best_cards.append(card)
                counter += 1
        
        f = open(globalvars.filename_ccards, 'w')
        for i in self.best_cards:
            f.write(i.to_string() + '\n')
        f.close()
        
        if (globalvars.debug_mode) and (len(self.best_cards) == 5):
            rbot = bot.Bot()
            rbot.clone(self.bot)
            rbot.board = self.board
            rbot.cards = self.best_cards
            pos = rbot.run()
            
            if pos is not None:
                f = open(globalvars.filename_directory + 'bot2.txt', 'w')
                f.write(str(pos[0]))
                f.write(' ')
                f.write(str(pos[1]))
                f.write(' ')
                if pos[2] == 0:
                    f.write('L')
                elif pos[2] == 1:
                    f.write('U')
                elif pos[2] == 2:
                    f.write('R')
                elif pos[2] == 3:
                    f.write('D')
                f.write('\n')
            else:
                try:
                    os.remove(globalvars.filename_directory + 'bot2.txt')
                except:
                    pass

main = Main()
main.run()
