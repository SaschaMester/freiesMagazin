# Copyright (c) 2009, Stefan Haller
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.

import globalvars

class Board:
    width = 0
    height = 0
    board = None
    
    finish = None
    
    def is_wall_left(self, coord):
        if (globalvars.difficulty < 2) and (coord[0] == 0):
            return True
        
        field = self.board[coord[1]][coord[0]]
        return (field == 'b') or \
               (field == 'd') or \
               (field == 'f') or \
               (field == 'h') or \
               (field == 'j') or \
               (field == 'l') or \
               (field == 'n') or \
               (field == 'p') or \
               (field == 'D') or \
               (field == 'M')
    
    def is_wall_right(self, coord):
        if (globalvars.difficulty < 2) and (coord[0] == self.width-1):
            return True
        
        field = self.board[coord[1]][coord[0]]
        return (field == 'c') or \
               (field == 'd') or \
               (field == 'g') or \
               (field == 'h') or \
               (field == 'k') or \
               (field == 'l') or \
               (field == 'o') or \
               (field == 'p') or \
               (field == 'C') or \
               (field == 'M')
    
    def is_wall_up(self, coord):
        if (globalvars.difficulty < 2) and (coord[1] == 0):
            return True
        
        field = self.board[coord[1]][coord[0]]
        return (field == 'e') or \
               (field == 'f') or \
               (field == 'g') or \
               (field == 'h') or \
               (field == 'm') or \
               (field == 'n') or \
               (field == 'o') or \
               (field == 'p') or \
               (field == 'F') or \
               (field == 'N')
    
    def is_wall_down(self, coord):
        if (globalvars.difficulty < 2) and (coord[1] == self.height-1):
            return True
        
        field = self.board[coord[1]][coord[0]]
        return (field == 'i') or \
               (field == 'j') or \
               (field == 'k') or \
               (field == 'l') or \
               (field == 'm') or \
               (field == 'n') or \
               (field == 'o') or \
               (field == 'p') or \
               (field == 'E') or \
               (field == 'N')
    
    def is_inside(self, coord):
        return (coord[0] >= 0) and \
               (coord[0] < self.width) and \
               (coord[1] >= 0) and \
               (coord[1] < self.height)
    
    def is_hole(self, coord):
        field = self.board[coord[1]][coord[0]]
        return (field == 'H')
    
    def is_press(self, coord):
        field = self.board[coord[1]][coord[0]]
        return (field == 'M') or \
               (field == 'N')
    
    def is_band_left(self, coord):
        field = self.board[coord[1]][coord[0]]
        return (field == '<')
    
    def is_band_right(self, coord):
        field = self.board[coord[1]][coord[0]]
        return (field == '>')
    
    def is_band_up(self, coord):
        field = self.board[coord[1]][coord[0]]
        return (field == '^')
    
    def is_band_down(self, coord):
        field = self.board[coord[1]][coord[0]]
        return (field == 'v')
    
    def is_pusher_left(self, coord):
        field = self.board[coord[1]][coord[0]]
        return (field == 'C')
    
    def is_pusher_right(self, coord):
        field = self.board[coord[1]][coord[0]]
        return (field == 'D')
    
    def is_pusher_up(self, coord):
        field = self.board[coord[1]][coord[0]]
        return (field == 'E')
    
    def is_pusher_down(self, coord):
        field = self.board[coord[1]][coord[0]]
        return (field == 'F')
    
    def is_wheel_left(self, coord):
        field = self.board[coord[1]][coord[0]]
        return (field == 'L')
    
    def is_wheel_right(self, coord):
        field = self.board[coord[1]][coord[0]]
        return (field == 'R')
    
    def is_oil(self, coord):
        field = self.board[coord[1]][coord[0]]
        return (field == 'O')
    
    def parse_from_file(self, lines):
        line = lines[0]
        del lines[0]
        
        tmp = line.split(' ')
        self.width = int(tmp[0])
        self.height = int(tmp[1])
        
        self.board = [ [ None for i in range(0, self.width)] for i in range(0,self.height) ]
        y = 0
        for line in lines:
            x = 0
            for char in line[:-1]:
                self.board[y][x] = char
                if char == 'Z':
                    self.finish = [x, y]
                x += 1
            y += 1
