# Copyright (c) 2009, Stefan Haller
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.

from globalvars import debug_mode
import globalvars

class Bot:
    x = 0
    y = 0
    z = 0
    
    dead = False
    
    def set_position(self, x, y, z):
        self.x = int(x)
        self.y = int(y)
        self.z = int(z)
    
    def clone(self, bot):
        self.x = bot.x
        self.y = bot.y
        self.z = bot.z
    
    def parse_from_file(self, line):
        start = 0
        end = 0
        counter = 0
        
        tmp = line.split(' ')
        
        if tmp[2] == 'L':
            z = 0
        elif tmp[2] == 'U':
            z = 1
        elif tmp[2] == 'R':
            z = 2
        elif tmp[2] == 'D':
            z = 3
        
        self.set_position(tmp[0], tmp[1], z)
    
    def left(self):
        if self.board.is_inside((self.x, self.y)):
            if self.board.is_wall_left((self.x, self.y)):
                return
        
        if self.board.is_inside((self.x-1, self.y)):
            if self.board.is_wall_right((self.x-1, self.y)):
                return
        
        self.x -= 1
        
        self.end_of_move()
        
        if self.dead:
            return
        
        if self.board.is_oil((self.x, self.y)):
            self.left()
    
    def right(self):
        if self.board.is_inside((self.x, self.y)):
            if self.board.is_wall_right((self.x, self.y)):
                return
        
        if self.board.is_inside((self.x+1, self.y)):
            if self.board.is_wall_left((self.x+1, self.y)):
                return
        
        self.x += 1
        
        self.end_of_move()
        
        if self.dead:
            return
        
        if self.board.is_oil((self.x, self.y)):
            self.right()
    
    def up(self):
        if self.board.is_inside((self.x, self.y)):
            if self.board.is_wall_up((self.x, self.y)):
                return
        
        if self.board.is_inside((self.x, self.y-1)):
            if self.board.is_wall_down((self.x, self.y-1)):
                return
        
        self.y -= 1
        
        self.end_of_move()
        
        if self.dead:
            return
        
        if self.board.is_oil((self.x, self.y)):
            self.up()
    
    def down(self):
        if self.board.is_inside((self.x, self.y)):
            if self.board.is_wall_down((self.x, self.y)):
                return
        
        if self.board.is_inside((self.x, self.y+1)):
            if self.board.is_wall_up((self.x, self.y+1)):
                return
        
        self.y += 1
        
        self.end_of_move()
        
        if self.dead:
            return
        
        if self.board.is_oil((self.x, self.y)):
            self.down()
    
    def rotate_left(self):
        if self.board.is_oil((self.x, self.y)):
            self.z -= 2
        else:
            self.z -= 1
        
        while self.z < 0:
            self.z += 4
    
    def rotate_right(self):
        if self.board.is_oil((self.x, self.y)):
            self.z += 2
        else:
            self.z += 1
        
        while self.z > 3:
            self.z -= 4
    
    def end_of_move(self):
        if self.dead:
            return
        
        if not self.board.is_inside((self.x, self.y)):
            self.kill()
            return
        
        if self.board.is_hole((self.x, self.y)):
            self.kill()
            return
    
    def end_of_turn(self):
        if self.dead:
            return
        
        if self.board.is_band_left((self.x, self.y)):
            self.left()
            if self.dead:
                return
            if self.board.is_band_up((self.x, self.y)):
                self.rotate_right()
            elif self.board.is_band_down((self.x, self.y)):
                self.rotate_left()
        elif self.board.is_band_right((self.x, self.y)):
            self.right()
            if self.dead:
                return
            if self.board.is_band_up((self.x, self.y)):
                self.rotate_left()
            elif self.board.is_band_down((self.x, self.y)):
                self.rotate_right()
        elif self.board.is_band_up((self.x, self.y)):
            self.up()
            if self.dead:
                return
            if self.board.is_band_left((self.x, self.y)):
                self.rotate_left()
            elif self.board.is_band_right((self.x, self.y)):
                self.rotate_right()
        elif self.board.is_band_down((self.x, self.y)):
            self.down()
            if self.dead:
                return
            if self.board.is_band_left((self.x, self.y)):
                self.rotate_right()
            elif self.board.is_band_right((self.x, self.y)):
                self.rotate_left()
        
        if self.dead:
            return
        
        if self.board.is_pusher_left((self.x, self.y)):
            self.left()
        elif self.board.is_pusher_right((self.x, self.y)):
            self.right()
        elif self.board.is_pusher_up((self.x, self.y)):
            self.up()
        elif self.board.is_pusher_down((self.x, self.y)):
            self.down()
        
        if self.dead:
            return
        
        if self.board.is_press((self.x, self.y)):
            self.kill()
        
        if self.dead:
            return
        
        if self.board.is_wheel_left((self.x, self.y)):
            self.rotate_left()
        elif self.board.is_wheel_right((self.x, self.y)):
            self.rotate_right()
    
    def kill(self):
        self.dead = True
    
    def run(self):
        for card in self.cards:
            rotate = card.rotate
            
            while rotate > 0:
                self.rotate_right()
                rotate-= 1
            
            while rotate < 0:
                self.rotate_left()
                rotate += 1
            
            forward = card.forward
            
            horiz = self.z == 0 or \
                    self.z == 2
            if self.z == 0 or \
               self.z == 1:
                forward = -forward
            
            while (forward != 0) and (not self.dead):
                if horiz and forward < 0:
                    self.left()
                    forward += 1
                elif not horiz and forward < 0:
                    self.up()
                    forward += 1
                elif horiz and forward > 0:
                    self.right()
                    forward -= 1
                elif not horiz and forward > 0:
                    self.down()
                    forward -= 1
            
            self.end_of_turn()
            
            if self.dead:
                break
        
        if self.dead:
            return None
        else:
            return [ self.x, self.y, self.z ]
