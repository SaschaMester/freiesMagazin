# Copyright (c) 2009, Stefan Haller
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.

import globalvars
import os.path

class Pathfinding:
    width = 0
    height = 0
    mapping = None
    board = None
    
    def get_value(self, pos):
        if not self.board.is_inside(pos):
            return None
        
        result = self.mapping[pos[1]][pos[0]]
        if result < 0:
            return None
        
        return result
    
    def get_value_next(self, pos):
        if pos[2] == 0:
            pos[0] -= 1
        elif pos[2] == 1:
            pos[1] -= 1
        elif pos[2] == 2:
            pos[0] += 1
        elif pos[2] == 3:
            pos[1] += 1
        else:
            raise
        
        if not self.board.is_inside(pos):
            return None
        
        return self.mapping[pos[1]][pos[0]]
    
    def connect_left(self, new_fields, x, y):
        if self.board.is_inside((x,y)):
            if self.board.is_wall_left((x,y)):
                return
       
        x -= 1
        if self.board.is_inside((x,y)):
            if self.board.is_wall_right((x,y)):
                return
            
            if self.mapping[y][x] is None:
                self.mapping[y][x] = self.mapping[y][x+1] + 1
                new_fields.append((x,y))
    
    def connect_right(self, new_fields, x, y):
        if self.board.is_inside((x,y)):
            if self.board.is_wall_right((x,y)):
                return
       
        x += 1
        if self.board.is_inside((x,y)):
            if self.board.is_wall_left((x,y)):
                return
            
            if self.mapping[y][x] is None:
                self.mapping[y][x] = self.mapping[y][x-1] + 1
                new_fields.append((x,y))
    
    def connect_top(self, new_fields, x, y):
        if self.board.is_inside((x,y)):
            if self.board.is_wall_up((x,y)):
                return
       
        y -= 1
        if self.board.is_inside((x,y)):
            if self.board.is_wall_down((x,y)):
                return
            
            if self.mapping[y][x] is None:
                self.mapping[y][x] = self.mapping[y+1][x] + 1
                new_fields.append((x,y))
    
    def connect_bottom(self, new_fields, x, y):
        if self.board.is_inside((x,y)):
            if self.board.is_wall_down((x,y)):
                return
       
        y += 1
        if self.board.is_inside((x,y)):
            if self.board.is_wall_up((x,y)):
                return
            
            if self.mapping[y][x] is None:
                self.mapping[y][x] = self.mapping[y-1][x] + 1
                new_fields.append((x,y))
    
    def calculate(self):
        for y in range(0, self.height):
            for x in range(0, self.width):
                if self.board.is_hole((x,y)):
                    self.mapping[y][x] = -1
        
        (x, y) = self.board.finish
        self.mapping[y][x] = 0
        
        new_fields = [(x, y)]
        while len(new_fields) != 0:
            old = new_fields
            new_fields = []
            for field in old:
                self.connect_left(new_fields, field[0], field[1])
                self.connect_right(new_fields, field[0], field[1])
                self.connect_top(new_fields, field[0], field[1])
                self.connect_bottom(new_fields, field[0], field[1])
    
    def write(self):
        f = open(globalvars.filename_paths, 'w')
        for y in self.mapping:
            for x in y:
                f.write(str(x))
                f.write("|")
        f.close()
    
    def read(self):
        f = open(globalvars.filename_paths, 'r')
        l = f.readline().split('|')
        f.close()
        
        counter = 0
        for y in range(0, self.height):
            for x in range(0, self.width):
                value = l[counter]
                
                if value == 'None':
                    self.mapping[y][x] = None
                else:
                    self.mapping[y][x] = int(value)
                
                counter += 1
    
    def init(self):
        self.width = self.board.width
        self.height = self.board.height
        
        self.mapping = [[None for x in range(0,self.width)] for y in range(0,self.height)]
        
        self.calculate()
        
        if globalvars.debug_mode:
            f = open(globalvars.filename_directory + 'path_human.txt', 'w')
            for y in self.mapping:
                for x in y:
                    value = x
                    if value is None:
                        value = -1
                    f.write('{0:2} '.format(value))
                f.write('\n')
            f.close()
