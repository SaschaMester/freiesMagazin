#ifndef BOARDGRAPH_HH
#define BOARDGRAPH_HH

// *************************************************************************
// robots-ki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Alexander Mergel
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <vector>
#include "position.hh"
#include "gameboard.hh"
#include "bot.hh"
#include "carddeck.hh"


class BoardGraph
{
  public:     
    
    BoardGraph(const std::string& boardname);
    bool getBestDeck(CardDeck deck, Position pos, BotEnumViewDirection dir, CardDeck& bestDeck);
    
    
  private:
    struct Tile;
    
    double getCostAndBadness(Position pos,BotEnumViewDirection dir,CardDeck& deck);   
    void createGraph(const std::string& boardname);
    bool load(char* graphname);
    void save(char* graphname);
   
   struct Path
   {
     Tile* from;
     Tile* to;
     unsigned short cost;
   };
    
    struct Tile
    {
      int id;
      Position pos; 			//Position of the Tile
      BotEnumViewDirection dir; 	//Direction on the Tile
      Path nextTile[7]; 		//next Tile for each of the seven cards
      std::vector<Path*> prevTile; 	//list of Tiles that point to this Tile
      double badness;
      double oldbadness;
      bool markedForUpdate;
    };
            
    //dynamic array of the board
    std::vector<Tile> m_board;
    
    // width of game board
    unsigned int m_width;

    // height of game board
    unsigned int m_height;
};


#endif
