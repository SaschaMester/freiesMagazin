// *************************************************************************
// robots-ki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Alexander Mergel
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <math.h>
#include <queue> 

#include "basefunctions.hh"

#include "boardgraph.hh"
#include "movementgenerator.hh"

BoardGraph::BoardGraph(const std::string& boardname)
{
  /*generate a hash of the gameboard-file*/
  std::ifstream boardFile;

  boardFile.open( boardname.c_str(), std::ios::in );

  if ( !boardFile.good() )
  {
    std::cout << "Error: Loading " << boardname << " failed." << std::endl;
    return ;
  }
  
  boardFile.seekg(0,std::ios_base::end);
  std::streampos fileSize=boardFile.tellg();
  
  char* boardString=new char[(int)fileSize+1]; 
  boardFile.seekg(std::ios_base::beg);
  boardFile.read(boardString,fileSize);
  boardString[fileSize]=(char)(BaseFunctions::getGameLevel());
  
  std::locale loc;                 // the "C" locale
  const std::collate<char>& coll = std::use_facet<std::collate<char> >(loc);
  long hash=coll.hash(boardString,boardString+fileSize+1);
  delete[] boardString;
  char graphname[20+2*sizeof(long)];
  sprintf(graphname,"boardgraph%lx.dat",hash);
  
  /*look if a graph has been saved for this gameboard*/
  if(!load(graphname))
  {
    /*no saved graph found -> create the graph and save it*/
    createGraph(boardname);
    save(graphname);
  }
}

void BoardGraph::createGraph(const std::string& boardname)
{ 
  GameBoard board;
  
  if(!board.loadAscii( boardname ))
  {
      std::cout << "Error: Loading " << boardname << " failed." << std::endl;
      return ;
  }
    
  m_width=board.getWidth();
  m_height=board.getHeight();
  
  m_board.resize(m_width*m_height*4);
  
  /*Build a double connected Graph of the Game Board*/
  
  for (unsigned int d=0;d<4;d++)
  {
    for (unsigned int j = 0; j < m_height; j++ )
    {
	for (unsigned int i = 0; i < m_width; i++ )
	{
	    m_board[d+i*4+j*m_width*4].id=d+i*4+j*m_width*4;
	    m_board[d+i*4+j*m_width*4].pos.set(i,j);
	    m_board[d+i*4+j*m_width*4].dir=(BotEnumViewDirection)(1<<d);

	    m_board[d+i*4+j*m_width*4].badness=100;
	    m_board[d+i*4+j*m_width*4].oldbadness=-1;
	    m_board[d+i*4+j*m_width*4].markedForUpdate=false;
	    
	    for(unsigned int k=0;k<7;k++)
	    {
	      if((i==board.getEndPos().x())&&(j==board.getEndPos().y())) //End Tiles link only to themselves
	      {
		m_board[d+i*4+j*m_width*4].nextTile[k].to=&(m_board[d+i*4+j*m_width*4]);
		m_board[d+i*4+j*m_width*4].nextTile[k].cost=0;
	      }
	      else
	      {
		// get movement for this card
		unsigned short cost;
		Position pos=m_board[d+i*4+j*m_width*4].pos;
		BotEnumViewDirection direction=m_board[d+i*4+j*m_width*4].dir;
		
		bool goodMove=MovementGenerator::getMovement(board,(CardEnumType)(k+1), pos, direction, cost);
		
		if(!goodMove)
		{
		  m_board[d+i*4+j*m_width*4].nextTile[k].to=NULL;
		}
		else
		{
		  unsigned int x=pos.x();
		  unsigned int y=pos.y();
		  unsigned int dir = (direction>4)+(direction>2)+(direction>1);
		  m_board[d+i*4+j*m_width*4].nextTile[k].to=&(m_board[dir+x*4+y*m_width*4]);
		  m_board[d+i*4+j*m_width*4].nextTile[k].from=&m_board[d+i*4+j*m_width*4];
		  m_board[dir+x*4+y*m_width*4].prevTile.push_back(&(m_board[d+i*4+j*m_width*4].nextTile[k]));
		  m_board[d+i*4+j*m_width*4].nextTile[k].cost=cost;
		}
	      }
	      
	    }	  
	}
    }
  }
  
 
      
  /*Assigne a "badness-value" to each GameField (and each direction)*/
  std::queue<Tile*> fifo;
  double updateTrigger=0.05;
  //double cardprob[]={4.0/56, 8.0/56, 12.0/56, 4.0/56, 12.0/56, 12.0/56, 4.0/56}; 
  double cardprob[]={0.359, 0.603, 0.765, 0.359, 0.765, 0.765, 0.359};
  
  for(int d=0;d<4;d++)
  {
    m_board[d+board.getEndPos().x()*4+board.getEndPos().y()*4*m_width].badness=0;
    m_board[d+board.getEndPos().x()*4+board.getEndPos().y()*4*m_width].oldbadness=0;   
    for(unsigned int i=0;i<m_board[d+board.getEndPos().x()*4+board.getEndPos().y()*4*m_width].prevTile.size();i++){
      fifo.push(m_board[d+board.getEndPos().x()*4+board.getEndPos().y()*4*m_width].prevTile[i]->from);
      m_board[d+board.getEndPos().x()*4+board.getEndPos().y()*4*m_width].prevTile[i]->from->markedForUpdate=true;
    }
  }

  while (!fifo.empty())
  {
    Tile* tile=fifo.front();
    fifo.pop();
    tile->markedForUpdate=false;
    
    double best1=INFINITY;
    double best2=INFINITY;
    unsigned int bestj=0;
    
    for(unsigned int j=0;j<7;j++)
    {
      if(tile->nextTile[j].to!=NULL)
      {
	if (tile->nextTile[j].to->badness+tile->nextTile[j].cost < best1)
	{
	  best2=best1;
	  best1=tile->nextTile[j].to->badness+tile->nextTile[j].cost;
	  bestj=j;
	}
	else if (tile->nextTile[j].to->badness+tile->nextTile[j].cost < best2)
	{
	  best2=tile->nextTile[j].to->badness+tile->nextTile[j].cost;
	}
      }
    }
    
    tile->badness= best1*cardprob[bestj] + best2*(1-cardprob[bestj]);
    if(tile->oldbadness==-1) tile->oldbadness=100; //first visit
    
    if (fabs(tile->oldbadness - tile->badness) > updateTrigger)
    {	  
      tile->oldbadness=tile->badness;
      for(unsigned int i=0;i<tile->prevTile.size();i++)
      {
	if(!tile->prevTile[i]->from->markedForUpdate)
	{
	  tile->prevTile[i]->from->markedForUpdate=true;
	  fifo.push(tile->prevTile[i]->from);
	}
      }
    }
    
  }     

  for(unsigned int i=0;i<m_board.size();i++) 
  {
    if(m_board[i].oldbadness==-1) m_board[i].badness=INFINITY;
  }	    
    
}

double BoardGraph::getCostAndBadness(Position pos,BotEnumViewDirection dir,CardDeck& deck)
{
  unsigned int x=pos.x();
  unsigned int y=pos.y();
  unsigned int d = (dir>4)+(dir>2)+(dir>1);
  unsigned int cost=0;
  
  Tile* tile=&(m_board[d+x*4+y*m_width*4]);
  
  for(int i=0;i<5;i++)
  {
    cost=cost+tile->nextTile[deck[i]->getId()-1].cost;
    tile=tile->nextTile[deck[i]->getId()-1].to;
    if (tile==NULL) return INFINITY; //Robo dead
    if (tile->badness==0) return cost;  //Goal reached
  }
  
  return cost+tile->badness;
}

bool BoardGraph::getBestDeck(CardDeck deck,Position pos, BotEnumViewDirection dir, CardDeck& bestDeck)
{
  
  /*Find the Deck that leads to a Game Field with minimal badness (and minimal cost to get there)*/
  
    CardDeck tmpDeck=CardDeck(5U,true);
    
    double bestbadness=INFINITY;
    
    for(int k1=0; k1<8; k1++)
    {
	tmpDeck.setCard(0,deck[k1]);
	
        for(int k2=0; k2<8; k2++)
	{
	  if(k1==k2) continue;
	  tmpDeck.setCard(1,deck[k2]);
	  
	  for(int k3=0;k3<8;k3++)
	  {
	    if((k3==k1)||(k3==k2)) continue;
	    tmpDeck.setCard(2,deck[k3]);
	    
	   for(int k4=0;k4<8; k4++)
	    {
	      if((k4==k1)||(k4==k2)||(k4==k3)) continue;
	      tmpDeck.setCard(3,deck[k4]);
	      
	       for(int k5=0;k5<8;k5++)
	      {
		if((k5==k1)||(k5==k2)||(k5==k3)||(k5==k4)) continue;
		tmpDeck.setCard(4,deck[k5]);
		
		double tmpbadness=getCostAndBadness(pos,dir,tmpDeck);
		
		if(tmpbadness<bestbadness)
		{
		  bestbadness=tmpbadness;
		  bestDeck=tmpDeck;
		}
		
	      }
	    }
	  }
	}
    }
    
    if(bestbadness==INFINITY)
    { 
      bestDeck=tmpDeck; 
      return false;
    } 
    return true;
}

void BoardGraph::save(char* graphname)
{
  std::ofstream outFile;
  outFile.open( graphname, std::ios::out|std::ios::binary);
  outFile.write((char*)&m_width,sizeof(int));
  outFile.write((char*)&m_height,sizeof(int));
  
  for (unsigned int d=0;d<4;d++)
  {
    for (unsigned int j = 0; j < m_height; j++ )
    {
	for (unsigned int i = 0; i < m_width; i++ )
	{
	  /*nextTile*/
	  for(unsigned int k=0;k<7;k++) 
	  {
	    if(m_board[d+i*4+j*m_width*4].nextTile[k].to==NULL)
	    {
	      int id=-1;
	      outFile.write((char*)&id,sizeof(int));
	    }
	    else
	    {
	      int id=m_board[d+i*4+j*m_width*4].nextTile[k].to->id;
	      outFile.write((char*)&id,sizeof(int));
	      outFile.write((char*)&(m_board[d+i*4+j*m_width*4].nextTile[k].cost),sizeof(unsigned short));
	    }
	  }
	  /*badness*/
	  outFile.write((char*)&( m_board[d+i*4+j*m_width*4].badness),sizeof(double));
	}
    }
  }
  
}

bool BoardGraph::load(char* graphname)
{
  std::ifstream inFile;
  inFile.open(graphname, std::ios::in|std::ios::binary);
  if(!inFile.good()) return false;
  
  inFile.read((char*)&m_width,sizeof(int));
  inFile.read((char*)&m_height,sizeof(int));
  m_board.resize(m_width*m_height*4);
  for (unsigned int d=0;d<4;d++)
  {
    for (unsigned int j = 0; j < m_height; j++ )
    {
	for (unsigned int i = 0; i < m_width; i++ )
	{
	  m_board[d+i*4+j*m_width*4].id=d+i*4+j*m_width*4;
	  m_board[d+i*4+j*m_width*4].pos.set(i,j);
	  m_board[d+i*4+j*m_width*4].dir=(BotEnumViewDirection)(1<<d);
	  
	  /*nextTile*/
	  for(unsigned int k=0;k<7;k++) 
	  {
	    int id;
	    inFile.read((char*)&id,sizeof(int));
	    
	    if(id>=0)
	    {
	      m_board[d+i*4+j*m_width*4].nextTile[k].to=&m_board[id];
	      inFile.read((char*)&(m_board[d+i*4+j*m_width*4].nextTile[k].cost),sizeof(unsigned short));
	    }
	    else
	    {
	      m_board[d+i*4+j*m_width*4].nextTile[k].to=NULL;
	    }
	  } 
	  /*badness*/
	  inFile.read((char*)&( m_board[d+i*4+j*m_width*4].badness),sizeof(double));
	}
    }
  }
  return true;
}
