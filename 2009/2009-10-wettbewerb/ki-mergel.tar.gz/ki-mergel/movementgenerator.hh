// *************************************************************************
// robots-ki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Alexander Mergel
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef MOVEMENTGENERATOR_HH
#define MOVEMENTGENERATOR_HH

#include "position.hh"
#include "gameboard.hh"
#include "cardenums.hh"
#include "sequence.hh"
#include "bot.hh"
#include "carddeck.hh"

class MovementGenerator
{
  public:
    static bool getMovement(const GameBoard& board, CardEnumType cardID, Position& pos, BotEnumViewDirection& dir, unsigned short & cost);
  private:
    static void cardIDtoSeq(CardEnumType id, Sequence& seq);
    static bool botHasReachedEndPosition(const GameBoard& board, const Bot& bot);
    static bool isValidMovement(const GameBoard& board,const Bot& bot, const std::string& move );
    static bool generateSequenceAndMoveRobot(const GameBoard& board, Bot& bot, unsigned short & cost ,const Sequence& startSeq, const bool recursiveCall );
};

#endif