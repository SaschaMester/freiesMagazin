// *************************************************************************
// robots-ki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Alexander Mergel
// Based on robots-engine/game.cpp (Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>)
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "movementgenerator.hh"

#include "botfunctions.hh"
#include "basefunctions.hh"
 
#include <iostream>
 
bool MovementGenerator::getMovement(const GameBoard& board, CardEnumType cardID, Position& pos, BotEnumViewDirection& dir, unsigned short & cost)
 {
      Sequence startSeq;
      cardIDtoSeq(cardID,startSeq);
      
      Bot bot;
      bot.setPos(pos);
      bot.setView((BaseEnumDirection)dir);
      
      cost=2;
      
      generateSequenceAndMoveRobot(board, bot, cost, startSeq, false );
      
      if(bot.isDestroyed())
      {
	return false;
      }
      else
      {
	pos=bot.getPos();
	dir=bot.getViewDirection();
	return true;
      }
 }
 
void MovementGenerator::cardIDtoSeq(CardEnumType id, Sequence& seq)
{
  switch(id)
  {
    case CE_TYPE_NONE: break;
    case CE_TYPE_MOVE_FORWARD_3: seq.push_back("MF");
    case CE_TYPE_MOVE_FORWARD_2: seq.push_back("MF");
    case CE_TYPE_MOVE_FORWARD_1: seq.push_back("MF"); break;
    case CE_TYPE_MOVE_BACKWARD: seq.push_back("MB"); break;
    case CE_TYPE_ROTATE_LEFT: seq.push_back("RL"); break;
    case CE_TYPE_ROTATE_RIGHT: seq.push_back("RR"); break;
    case CE_TYPE_ROTATE_UTURN: seq.push_back("RU"); break;
  }
}

// transform the movement of the start sequence to the game board
// and the robot 
bool MovementGenerator::generateSequenceAndMoveRobot(const GameBoard& board, Bot& bot, unsigned short& cost,
						    const Sequence& startSeq, const bool recursiveCall ) 
{
    bool moved = false;

    for ( unsigned int ii = 0; ii < startSeq.size(); ii++ )
    {
        if ( !bot.isDestroyed() && !bot.isFinished() )
        {
            // check if this movement is valid
            // means if there is a wall that would block the movement
            // or if we would leave the field ( = invisible wall )
            if ( isValidMovement(board,  bot, startSeq.at(ii) ) )
            {
                moved = true;
		
                // only count if no end move
                if (!(startSeq.at(ii) == "Z" || startSeq.at(ii) == "Y" || startSeq.at(ii) == "X" ))
                {
                    if ( !recursiveCall )
                    {
                        // add own move
                        cost+=2;
                    }
                    else
                    {
                        // add board move
                        cost+=1;
                    }
                }
		
                // move robot by itself
                bot.move( startSeq.at(ii),
                            board.getWidth(), board.getHeight() );

                
                if ( botHasReachedEndPosition(board, bot) )
                {
                    // robot has reched end
                    bot.move( "Z", board.getWidth(),
                                     board.getHeight() );
                }

                // only if the movement is valid we will check the on entry
                const Position pos( bot.getPos() );

                if ( !bot.isDestroyed() && !bot.isFinished() &&
                     NULL != board[pos] )
                {
                    Sequence localSeq;

                    if ( bot.isLastMovement() )
                    {
                        // last action of the robot was a move
                        board[pos]->getSequenceOnEntry( localSeq,
                                           bot.getLastMovement() );
                    }
                    else if ( bot.isLastRotation() )
                    {
                        // a rotation on entry can only be done one time
                        if ( !recursiveCall )
                        {
                            // last action was a rotation
                            board[pos]->getSequenceOnEntry( localSeq,
                                               bot.getLastRotation() );
                        }
                    }
                    else
                    {
                        std::cerr << "MovementGenerator::generateSequenceAndMoveRobot() "
                                  << "Error: Last action of robot was "
                                  << "neither move nor rotation."
                                  << std::endl;
                    }

                    // move robot recursivly
                    generateSequenceAndMoveRobot(board, bot, cost, localSeq, true );

                    // check if robot is dead
                }
            }
            else if ( BE_GAME_LEVEL_HARD == BaseFunctions::getGameLevel() )
            {
                // game level is HARD, so we must check if the bot move
                // out of game board
                // bot only if there is not wall that stop us falling

                if ( bot.wouldLeaveBoard( startSeq.at(ii),
                                            board.getWidth(),
                                            board.getHeight() ) )
                {

                    Position pos ( bot.getPos() );
                    const BaseEnumDirection dir = BotFunctions::convertToDirection( startSeq.at(ii), bot.getViewDirection() );

                    if (  NULL == board[pos] || board[pos]->canLeave( dir ) )
                    {
                        moved = true;
                        bot.move( "X", board.getWidth(),
                                         board.getHeight() );
                    }
                }
            }
            // else we will ignore the movement
        }

    } // for

    // only in the first call we must check were there robot finally stands
    // and of course if the robot is not destroyed yet
    if ( !recursiveCall )
    {
        bool isPushedByBelt = false;

        Position pos;

        // first phase: TE_PHASE_MOVE
        pos = bot.getPos();
        if ( !bot.isDestroyed() && !bot.isFinished() &&
             NULL != board[ pos ] )
        {
            Sequence localSeq;

            // get sequence for this robot when standing on this field
            board[pos]->getSequence( localSeq, TE_PHASE_MOVE );

            // move robot recursivly
            if ( generateSequenceAndMoveRobot(board, bot, cost, localSeq, true ) )
            {
                moved = true;
                isPushedByBelt = true;
            }
        }

        // second phase: TE_PHASE_PUSH
        pos = bot.getPos();
        if ( !bot.isDestroyed() && !bot.isFinished() &&
             NULL != board[ pos ] )
        {
            Sequence localSeq;

            // get sequence for this robot when standing on this field
            board[pos]->getSequence( localSeq, TE_PHASE_PUSH );

            // move robot recursivly
            if ( generateSequenceAndMoveRobot( board, bot, cost, localSeq, true ) )
            {
                moved = true;
                isPushedByBelt = false;
            }
        }

        // third phase: TE_PHASE_ROTATE
        pos = bot.getPos();
        if ( !bot.isDestroyed() && !bot.isFinished() &&
             NULL != board[ pos ] )
        {
            Sequence localSeq;

            // get sequence for this robot when standing on this field
            board[pos]->getSequence( localSeq, TE_PHASE_ROTATE );

            // move robot recursivly
            if ( generateSequenceAndMoveRobot( board, bot, cost, localSeq, true ) )
            {
                moved = true;
                isPushedByBelt = false;
            }
        }

        // fourth phase: Rotation on conveyor belt
        pos = bot.getPos();
        if ( !bot.isDestroyed() && !bot.isFinished() &&
             NULL != board[ pos ] )
        {
            if ( bot.isLastMovement() )
            {
                Sequence localSeq;

                // get sequence for this robot when standing on this field
                board[pos]->getSequenceOnEntry( localSeq,
                                                  bot.getLastMovement(),
                                                  isPushedByBelt );

                // move robot recursivly
                if ( generateSequenceAndMoveRobot( board, bot, cost, localSeq, true ) )
                {
                    moved = true;
                }
            }
        }
    }
    return moved;
}

// check if this movement is valid
bool MovementGenerator::isValidMovement(const GameBoard& board, const Bot& bot, const std::string& move )
{
    bool valid = false;

    if ( "MF" == move || "MB" == move || "ML" == move ||
         "MR" == move || "MU" == move || "MD" == move )
    {
        // get new position if robot would move this way
        Position pos ( bot.getPos() );
        Position newPos;

        if ( bot.getNewPos( newPos, move,
                              board.getWidth(),
                              board.getHeight() ) )
        {
            if ( NULL != board[pos] && NULL != board[newPos] )
            {
                const BaseEnumDirection dir = BotFunctions::convertToDirection( move, bot.getViewDirection() );

                //std::cout << "dir: " << m_bot.getViewDirection() << " "
                          //<< dir << std::endl;

                // check if field can be left and next entered
                if ( board[pos]->canLeave( dir ) &&
                     board[newPos]->canEnter( dir ) )
                {
                    valid = true;
                }

            }
        }
    }
    else if ( "RL" == move || "RR" == move || "RU" == move )
    {
        // rotations are okay
        valid = true;
    }
    else if ( "X" == move || "Z" == move )
    {
        // destroying or finish is okay
        valid = true;
    }
    else
    {
        std::cerr << "MovementGenerator::isValidMovement(string) "
                  << "Error: Movement "
                  << move.c_str()
                  << " not recognized."
                  << std::endl;
    }

    return valid;
}

// return true if bot has reached end position
bool MovementGenerator::botHasReachedEndPosition(const GameBoard& board,const Bot& bot)
{
    bool reached = false;

    if ( NULL != board[ bot.getPos() ] )
    {
        reached = board[ bot.getPos() ]->isType( TE_TYPE_END );
    }

    return reached;
}