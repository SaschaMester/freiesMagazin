// *************************************************************************
// robots-ki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Alexander Mergel
// Original Author: Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <string>

#include "bot.hh"
#include "gameboard.hh"
#include "carddeck.hh"
#include "basefunctions.hh"
#include "boardgraph.hh"


const std::string boardname("board.txt");
const std::string deckname("cards.txt");
const std::string choosendeckname("ccards.txt");
const std::string botname("bot.txt");

int main( int argc, char *argv[] )
{
    std::string mode("normal");
    
    if ( argc==2 )
    {
        // try to extract optional game level
        std::string level( "normal" );
        level = argv[1];
        BaseFunctions::setGameLevel( level );
    }    
    
    // ignore other arguments or when level is incorrect
    
    //Load carddeck
    CardDeck deck;
    if ( !deck.load( deckname) )
    {
	std::cout << "Error: Loading "<< deckname << " failed."<< std::endl;
	return -1;
    }
    
    if ( deck.size() != 8  )
    {        
	std::cout << "Error: Number of cards "<< deck.size()<< " does not equal 8." << std::endl;
	return -1;
    }
    
    
    Bot bot;
    if(!bot.load( botname ))
    {
	std::cout << "Error: Loading " << botname << " failed." << std::endl;
	return -1;
    }
    
    BoardGraph graph(boardname);
    
    CardDeck bestDeck;
    
    if(!graph.getBestDeck(deck, bot.getPos(), bot.getViewDirection(), bestDeck))
    {
      std::cout << "Warning: No good move found!!!" << std::endl;
    }

    // save new deck
    if ( !bestDeck.save( "ccards.txt" ) )
    {
	std::cout << "Error: Saving ccard.txt failed."
		  << std::endl;
	return -1;
    }
    
    return 0;
}
