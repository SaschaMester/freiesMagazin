// *************************************************************************
// robots-ki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <fstream>
#include <algorithm>

#include "cardpermutation.hh"

// Default constructor.
CardPermutation::CardPermutation()
: m_deck(NULL), m_numOut(0), m_numSigma(0)
{
}

// Constructor.
// Generates all permutations of cards.
CardPermutation::CardPermutation( const CardDeck& deck,
                                  const unsigned int numCards )
: m_deck(NULL), m_numOut(0), m_numSigma(0)
{
    create( deck, numCards );
}

// Destructor.
CardPermutation::~CardPermutation()
{
    clear();
}

// Clear all.
void CardPermutation::clear()
{
    m_permutation.clear();

    // do not delete deck because it's a reference
    m_deck = NULL;
}

// Generate all combinations choosing
// numCards out of the card deck and permute them.
const bool CardPermutation::create( const CardDeck& deck,
                                    const unsigned int numCards )
{
    // First I want to explain the (really bad) algorithm:
    // The goal is to draw m cards out of n given cards.
    // * There are (n over m) =  n! / ( (n-m)! * m! )
    //   possibilities for this.
    // * When we have these five cards, we can sort them
    //   in m! ways.
    //
    // So what will we do?
    // * Create an array of indices from 0 to n-1.
    //   It's easier to permute numbers.
    // * Get all combinations of five digits from this
    //   integer array.
    // * Then permute this array with all possibilities.
    //   Because of performance we will not permute each single
    //   array with the cards but again permute only
    //   an array with numbers 0 to m-1.

    bool ok = false;

    // clear everything old
    clear();
    
    m_deck = &deck;

    if ( numCards <= deck.size() )
    {
        // the factorial of > 12 is bigger than 2^32
        if ( ( numCards <= 12  ) &&
             ( ( deck.size() - numCards ) <= 12 ) )
        {
            // we could only could code 31 cards inside
            // a 32-bit integer
            if ( deck.size() <= 31 )
            {
                // get all combinations from m cards out of n
                unsigned long numOut = 0;
                UIntArrayArray basePermutations;

                if ( getMOutOfNInts( basePermutations, numOut,
                                     deck.size(), numCards ) )
                {
                    /*
                    std::cout << "numOut: " << numOut << "\n"
                              << "deckSize: " << deck.size() << "\n"
                              << "numCards: " << numCards << "\n";

                    for ( unsigned int i = 0; i < basePermutations.size(); i++ )
                    {
                        std::cout << i << ": ";
                        for ( unsigned int j = 0; j < basePermutations[i].size(); j++ )
                        {
                            std::cout << basePermutations[i][j] << " ";
                        }
                        std::cout << std::endl;
                    }
                    */

                    // get array with integers from 0 to numCards-1
                    // and the number of permuting them
                    unsigned long numSigma = 0;
                    UIntArray numbers;

                    if ( getNumPermutations( numbers, numSigma, numCards ) )
                    {
                        /*
                        std::cout << "numSigma: " << numSigma << "\n"
                                  << "numCards: " << numCards << "\n";

                        for ( unsigned int i = 0; i < numbers.size(); i++ )
                        {
                            std::cout << numbers[i] << " ";
                        }
                        std::cout << std::endl;
                        * */

                        // calculate all permutations
                        if ( calculatePermutations( m_permutation,
                                                    basePermutations,
                                                    numbers,
                                                    numOut,
                                                    numSigma,
                                                    numCards ) )
                        {
                            // print();

                            // store values
                            m_numOut = numOut;
                            m_numSigma = numSigma;

                            ok = true;
                        }
                    }
                }
            }
        }
        else
        {
            // it's not possible to get so much cards
            std::cerr << "CardPermutation::CardPermutation "
                      << "Error: Number of choosen cards "
                      << numCards
                      << " and size of deck "
                      << deck.size()
                      << " minus number of choose cards "
                      << numCards
                      << " must not be bigger than 12."
                      << std::endl;
        }
    }
    else
    {
        // it's not possible to get so much cards
        std::cerr << "CardPermutation::CardPermutation "
                  << "Error: Number of choosen cards "
                  << numCards
                  << " is bigger than given number of cards "
                  << deck.size()
                  << "."
                  << std::endl;
    }

    if ( !ok )
    {
        // some error occured, clear all
        clear();
    }

    return ok;
}


// static method
// calculate factorial
const unsigned long CardPermutation::factorial( const unsigned int number, const unsigned int start )
{
    unsigned long fac = 1;

    for ( unsigned int ii = start; ii < number; ii++ )
    {
        fac *= (ii+1);
    }

    return fac;
}

// static method
// calculate binomial coefficient
const unsigned long CardPermutation::binomial( const unsigned int numerator,
                                               const unsigned int denominator )
{
    unsigned long bin = 0;

    if ( numerator >= denominator )
    {
        // normally that would be:
        // factorial(numerator) / ( factorial( numerator - denominator )
        //                          * factorial( denominator ) );
        //
        // but it's not intelligent to calculate a product and divide
        // by most common numbers

        if ( numerator > 2*denominator )
        {
            /*
            std::cout << "1: "
                      << factorial( numerator, numerator - denominator ) << "/"
                      << factorial( denominator )
                      << std::endl;
                      */

            // it's better to calculate the factorial
            // from ( numerator - denominator + 1) to numerator
            bin = factorial( numerator, numerator - denominator ) /
                  factorial( denominator );
        }
        else
        {
            /*
            std::cout << "2: "
                      << factorial( numerator, denominator ) << "/"
                      << factorial( numerator - denominator )
                      << std::endl;
                      */

            // it's better to calculate the factorial
            // from denominator + 1 to numerator
            bin = factorial( numerator, denominator  ) /
                  factorial( numerator - denominator );
        }
    }

    return bin;
}

// static method
// check if numBits are set in bitmask between 0 and maxBit
const bool CardPermutation::bitsSet( const unsigned long bitMask,
                                     const unsigned int numBits,
                                     const unsigned int maxBits )
{
    bool correct = false;

    unsigned int counter = 0;

    if ( numBits <= maxBits )
    {
        // go through the bitmask and test each bit
        for ( unsigned int ii = 0; ii < maxBits; ii++ )
        {
            if ( 0 != ( bitMask & (1 << ii) ) )
            {
                // std::cout << ii << " ";
                counter++;
            }
            if ( counter > numBits )
            {
                // we can stop here
                break;
            }
        }
    }

    // std::cout << std::endl;

    if ( numBits == counter )
    {
        correct = true;
    }

    /*
    std::cout << " bitMask: " << bitMask
              << " bitsSet: " << counter
              << " numBits: " << numBits
              << " maxBits: " << maxBits
              << " return: " << correct
              << std::endl;
              */

    return correct;
}

// static method
// get those integers in an array that bits are set in the bitMask.
// The number of set bits must equal the size of the array.
// return true if everything is okay
const bool CardPermutation::getIntegersFromBitMask( UIntArray& array,
                                          const unsigned long bitMask,
                                          const unsigned int maxBits )
{
    bool ok = false;

    if ( array.size() <= maxBits )
    {
        // suppose everything is okay
        ok = true;

        unsigned int counter = 0;

        // go through the bitmask and test each bit
        for ( unsigned int ii = 0; ii < maxBits; ii++ )
        {
            if ( 0 != ( bitMask & (1 << ii) ) )
            {
                // std::cout << ii << " ";

                if ( counter < array.size() )
                {
                    // bit is set
                    // store integer
                    array[counter] = ii;
                    counter++;
                }
                else
                {
                    std::cerr << "CardPermutation::getIntegersFromBitMask "
                              << "Error: Counter "
                              << counter
                              << " would be bigger than array size "
                              << array.size()
                              << "."
                              << std::endl;
                    ok = false;
                    break;
                }
            }
        }

        // std::cout << std::endl;

        if ( ok && array.size() != counter )
        {
            std::cerr << "CardPermutation::getIntegersFromBitMask "
                      << "Error: Counter "
                      << counter
                      << " is not equal to array size "
                      << array.size()
                      << "."
                      << std::endl;
            ok = false;
        }
    }
    else
    {
        std::cerr << "CardPermutation::getIntegersFromBitMask "
                  << "Error: Array size "
                  << array.size()
                  << " is bigger than maximum bits "
                  << maxBits
                  << "."
                  << std::endl;
    }

    return ok;
}

// static method
// get all combinations for m out of n integers
// return true if everything is okay
const bool CardPermutation::getMOutOfNInts( UIntArrayArray& array,
                                            unsigned long& num,
                                            const unsigned int n,
                                            const unsigned int m )
{
    bool ok = false;

    if ( m <= n && m <= 12 && (n - m) <= 12 && n <= 31 )
    {
        // calculate number of binomial combinations
        num = binomial( n, m );

        /*
        std::cout << "numOut: " << num << "\n"
                  << "deckSize: " << n << "\n"
                  << "numCards: " << m << "\n";
                  */

        array.resize( num );

        // bitmask with max number of integers
        // that means maxBitmask is equal to all integers should
        // be choosen
        const unsigned long maxBitmask = ( 1 << n );

        unsigned int counter = 0;

        // suppose everything is finde
        ok = true;

        // now go through all bitmasks and could the bits
        for ( unsigned long ii = 0; ii < maxBitmask; ii ++ )
        {
            // check if the right number of bits are set
            if ( bitsSet( ii, m, n ) )
            {
                // in the bit mask there are m bits set
                // => create array from it

                if ( counter < array.size() )
                {
                    // set new array size
                    array[counter].resize(m);

                    // get permutation
                    if ( getIntegersFromBitMask( array[counter], ii, n ) )
                    {
                        counter++;
                    }
                    else
                    {
                        ok = false;
                        break;
                    }
                }
                else
                {
                    std::cerr << "CardPermutation::getMOutOfNInts "
                              << "Error: Counter for combinations "
                              << counter
                              << " is bigger than reserved array size "
                              << array.size()
                              << "."
                              << std::endl;
                    ok = false;
                    break;
                }
            }
        }

        // only check the number if everything is still okay
        if ( ok && num != counter )
        {
            std::cerr << "CardPermutation::getMOutOfNInts "
                      << "Error: Counter for combinations "
                      << counter
                      << " is not equal to reserved array size "
                      << array.size()
                      << "."
                      << std::endl;
            ok = false;
        }
    }


    return ok;
}

// static method
// calculate number of perumtations for m integers
// and array with base array to permute
// return true if everything is okay
const bool CardPermutation::getNumPermutations( UIntArray& array,
                                                unsigned long& num,
                                                const unsigned int m )
{
    bool ok = false;

    if ( m <= 12 )
    {
        // Create the array with numbers from 0 to m-1
        // as described above.
        array.resize(m);

        for ( unsigned int ii = 0; ii < m; ii++ )
        {
            array[ii] = ii;
        }

        // number of combinations for permuting these
        // m cards.
        num = factorial(m);

        ok = true;
    }

    return ok;
}

// static method
// calculate all permutations
const bool CardPermutation::calculatePermutations(
                            UIntArrayArrayArray& permutation,
                            const UIntArrayArray& basePermutations,
                            UIntArray& numbers,
                            const unsigned long numOut,
                            const unsigned long numSigma,
                            const unsigned int numCards )
{

    bool ok = false;

    if ( numOut > 0 &&
         basePermutations.size() == numOut &&
         basePermutations[0].size() == numCards )
    {
        // set correct size for all arrays
        permutation.resize( numOut );

        for ( unsigned long ii = 0; ii < numOut; ii++ )
        {
            permutation[ii].resize( numSigma );

            for ( unsigned long jj = 0; jj < numSigma; jj++ )
            {
                permutation[ii][jj].resize( numCards );
            }
        }

        // suppose everything is okay
        ok = true;

        // get all permutations
        unsigned long counter = 0;
        do
        {
            /*
            for ( unsigned int i = 0; i < numbers.size(); i++ )
            {
                std::cout << numbers[i] << " ";
            }
            std::cout << std::endl;
            */

            if ( counter < numSigma )
            {
                for ( unsigned long ii = 0; ii < numOut; ii++ )
                {
                    for ( unsigned int kk = 0; kk < numCards; kk++ )
                    {
                        permutation[ii][counter][kk] = basePermutations[ii][numbers[kk]];
                    }
                }
                counter++;
            }
            else
            {
                std::cerr << "CardPermutation::calculatePermutations "
                          << "Error: Counter for combinations "
                          << counter
                          << " is bigger than reserved array size "
                          << numSigma
                          << "."
                          << std::endl;
                ok = false;
                break;
            }

        } while ( std::next_permutation( &(numbers[0]), &(numbers[0])+numCards ) );

        if ( ok && numSigma != counter )
        {
            std::cerr << "CardPermutation::calculatePermutations "
                      << "Error: Counter for combinations "
                      << counter
                      << " is not equal to reserved array size "
                      << numSigma
                      << "."
                      << std::endl;
            ok = false;
        }
    }

    return ok;
}

// get deck from permutation
// return true if everything is okay
const bool CardPermutation::getPermutatedDeck( CardDeck& deck,
                                               const unsigned long ii,
                                               const unsigned long jj ) const
{
    bool ok = false;

    // std::cout << "Deck: " << m_deck << std::endl;

    if ( NULL != m_deck )
    {
        // std::cout << ii << " < " << m_permutation.size() << std::endl;

        if ( ii < m_permutation.size() )
        {
            // std::cout << jj << " < " << m_permutation[ii].size() << std::endl;

            if ( jj < m_permutation[ii].size() )
            {
                deck.resize( m_permutation[ii][jj].size() );

                for ( unsigned int kk = 0; kk < m_permutation[ii][jj].size(); kk++ )
                {
                    if ( deck.isShadowCopy() )
                    {
                        if ( ( NULL == m_deck->operator[]( m_permutation[ii][jj][kk] ) ) ||
                             ( !deck.setCard( kk, m_deck->operator[]( m_permutation[ii][jj][kk] ) ) ) )
                        {
                            return ok;
                        }
                    }
                    else
                    {
                        if ( ( NULL == m_deck->operator[]( m_permutation[ii][jj][kk] ) ) ||
                             ( !deck.setCard( kk, m_deck->operator[]( m_permutation[ii][jj][kk] )->clone() ) ) )
                        {
                            return ok;
                        }
                    }
                }

                ok = true;
            }
        }
    }

    return ok;
}

// Print all permutations.
void CardPermutation::print() const
{
    for ( unsigned long ii = 0; ii < m_permutation.size(); ii++ )
    {
        for ( unsigned long jj = 0; jj < m_permutation[ii].size(); jj ++)
        {
            std::cout << ii << " " << jj << ": ";

            for ( unsigned int kk = 0; kk < m_permutation[ii][jj].size(); kk++ )
            {
                std::cout << m_permutation[ii][jj][kk] << " ";
            }

            std::cout << std::endl;
        }
    }
}
