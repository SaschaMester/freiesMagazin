// *************************************************************************
// robots-ki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <cstdlib>

#include "gameki.hh"
#include "basefunctions.hh"
#include "botfunctions.hh"
#include "graph.hh"

// Constructor.
// Load all files.
GameKI::GameKI()
: Game(), m_finishPos(0,0), m_error(GK_ERROR_NONE)
{
    if ( isValid() )
    {
        // set end position
        m_finishPos = m_board.getEndPos();
        
        // open statistics
        m_stats.setFile( "ki-stats.txt", false ); 
        
        // init way finding graph with original board
        Graph graph( m_board );
        
        //std::cout << "GameKI::GameKI() "
                  //<< " Info: "
                  //<< graph.isValid()
                  //<< std::endl;
        
        if ( graph.isValid() )
        {
            // graph.saveGraphviz( "graph.dot" );

            // calculate way from bot position to finish
            Dijkstra way( graph, m_bot.getPos() );

            // get shortest path from bot position
            // to goal as list of positions
            way.getShortestPath( m_shortestPath );
            
            //PositionVector::const_reverse_iterator rit;
            //std::cout << "Path:";
            //for ( rit = m_shortestPath.rbegin(); rit < m_shortestPath.rend(); rit++ )
            //{
                //std::cout << " -> ("
                          //<< (*rit).x() << "," << (*rit).y()
                          //<< ")";
            //}
            //std::cout << std::endl;

            // graph.saveGraphviz( "graph.dot" );
        }
    }
    else
    {
        m_error = GK_ERROR_FILE_NOT_LOADED;
    }
}

// Destructor.
GameKI::~GameKI()
{
    // save statistics
    if ( m_stats.isValid() )
    {
        // add new round
        m_stats.increase( Stats::SE_NUM_ROUNDS );
        m_stats.save();
    }

    // if bot is finished we will delete the stats-file
    if ( m_bot.isDestroyed() || m_bot.isFinished() )
    {
        m_stats.removeFile();
    }
}

// Create all possibilities and save best to disk.
// return true if everything is okay
bool GameKI::chooseAndSaveBestDeck( const std::string& deckname )
{
    bool ok = false;

    if ( hasNoError() )
    {
        if ( m_deck.size() == 8 )
        {
            // create permutation with all possibilities
            // to draw 5 cards from the 8 loaded
            m_permutation.create( m_deck, 5 );
            
            // m_permutation.print();
            // m_board.saveExtendedAscii( "ascii-board.txt" );

            bool negative = false;
            
            if ( m_stats.get( Stats::SE_NUM_CARD_MOVES ) > 400 )
            {
                // If we have more than M movements this is an
                // indicator that we will not reach the finish in time
                // to get a positive value.
                // So we will kill the bot if it's possible.
                negative = true;

                // m_stats.print();
                // std::cout << "Negative: " << negative << std::endl;

                // only show message if we have not done so before
                if ( m_stats.get( Stats::SE_NUM_BOT_DESTROYED ) == 0 )
                {
                    std::cout << "Error: Target not found after "
                              << m_stats.get( Stats::SE_NUM_CARD_MOVES )
                              << " movements. Will try to kill myself!"
                              << std::endl;
                }

                // as indicator that we want to kill ourself, we will
                // set a flag
                m_stats.increase( Stats::SE_NUM_BOT_DESTROYED );
            }
            
            CardDeck newDeck;
            if ( chooseBestDeck( newDeck, negative ) )
            {
                // move bot
                if ( generateAndStoreSequence( newDeck ) )
                {
                    if ( newDeck.save( deckname ) )
                    {
                        ok = true;
                    }
                    else
                    {
                        m_error = GK_ERROR_FILE_NOT_SAVED;
                    }
                }
                else
                {
                    m_error = GK_ERROR_FILE_NOT_SAVED;
                }
            }
            else
            {
                m_error = GK_ERROR_NO_DECK_FOUND;
            }
        }
        else
        {
            std::cout << "GameKI::chooseAndSaveBestDeck "
                      << "Error: Number of cards "
                      << m_deck.size()
                      << " does not equal 8."
                      << std::endl;

            m_error = GK_ERROR_NUMBER_OF_CARDS;
        }
    }

    return ok;
}

// generate sequence for GUI from cards
// and save it to disk
bool GameKI::generateAndStoreSequence( const CardDeck& choosenCards )
{
    bool ok = true;

    for ( unsigned int ii = 0; ii < choosenCards.size(); ii++ )
    {
        if ( NULL != choosenCards[ii] )
        {
            // get movement for this card
            Sequence startSeq;
            choosenCards[ii]->getSequence( startSeq );

            //std::cout << "start seq: ";
            //startSeq.print(false);
            //std::cout << std::endl;

            // now we must transform this movement to the game board
            // and the robot
            Sequence endSeq;
            generateSequenceAndMoveRobot( endSeq, startSeq, m_bot, false );

            //std::cout << "end seq:   ";
            //endSeq.print(false);
            //std::cout << std::endl;

            // add separator for each card
            // if the game is not finished yet
            if ( endSeq.size() > 0 )
            {
                if ( isEndMove( endSeq.back() ) )
                {
                    // game is finished => stop here
                    break;
                }
                else
                {
                    // count number of movements and add them in stats file
                    for ( unsigned int jj = 0; jj < endSeq.size(); jj++ )
                    {
                        // only count card if not a separator
                        if ( !endSeq.at(jj).find("----") == 0 )
                        {
                            // we will not separate by movements from cards
                            // or from board
                            m_stats.increase( Stats::SE_NUM_CARD_MOVES );
                        }
                    }
                }
            }
        }
        else
        {
            ok = false;
        }
    }

    // std::cout << "ok: " << ok << std::endl;

    return ok;
}

// Choose best deck from cards.
// return true if everything is okay
bool GameKI::chooseBestDeck( CardDeck& deck, const bool negative ) const
{
    // print();

    // The idea:
    // Go through each possible deck combination.
    // Get the corresponding sequence.
    // Check where the robot will land.
    // Use the deck in which the robot is nearest to the goal.

    // best position on board
    int bestChoice = 0;
    unsigned long bestDeck[2] = { 0, 0 };

    bool found = false;

    // we have enough information to calculate the deck
    CardDeck newDeck( false, true );
    Bot newBot;

    for ( unsigned long ii = 0; ii < m_permutation.getNumMOutOfN(); ii++ )
    {
        for ( unsigned long jj = 0; jj < m_permutation.getNumPermutations(); jj ++)
        {
            // reset robot
            newBot = m_bot;

            // std::cout << ii << " " << jj << ": ";

            // get permutated deck
            if ( m_permutation.getPermutatedDeck( newDeck, ii, jj ) )
            {
                /*
                for ( unsigned int kk = 0; kk < newDeck.size(); kk++ )
                {
                    std::cout << newDeck[kk]->print() << " ";
                }
                */

                // generate sequence for GUI from cards
                if ( generateAndStoreSequence( newDeck, newBot ) )
                {
                    /*
                    Position pos = newBot.getPos();

                    const unsigned int dist =
                          abs( pos.x() - m_finishPos.x() ) + abs( pos.y() - m_finishPos.y() );

                    std::cout << "Bot: " << pos.x() << " " << pos.y()
                              << " View: " << (int)newBot.getViewDirection()
                              << " Dead: " << newBot.isDestroyed()
                              << " Finish: " << newBot.isFinished()
                              << " Dist: " << dist;
                              */

                    if ( found )
                    {
                        // we have already found a good one
                        const int choice = getChoicePoints( newBot, negative );
                    
                        if ( choice > bestChoice )
                        {
                            bestChoice = choice;
                            bestDeck[0] = ii;
                            bestDeck[1] = jj;
                            found = true;
                        }
                    }
                    else
                    {
                        // store first good one
                        bestChoice = getChoicePoints( newBot, negative );
                        bestDeck[0] = ii;
                        bestDeck[1] = jj;
                        found = true;
                    }
                }
            }
            
            // std::cout << std::endl;

        }
    }

    bool ok = false;

    if ( found )
    {
        // get best deck
        ok = m_permutation.getPermutatedDeck( deck, bestDeck[0], bestDeck[1] );

        std::cout << "Bot: "
                  << m_bot.getPos().x() << " "
                  << m_bot.getPos().y() << " "
                  << (int)m_bot.getViewDirection() << " ";

        std::cout << "Deck: "
                  << bestDeck[0] << " "
                  << bestDeck[1] << " "
                  << bestChoice << " ";
                  
        for ( unsigned int kk = 0; kk < deck.size(); kk++ )
        {
            std::cout << deck[kk]->print() << " ";
        }
        
        std::cout << std::endl;
    }
    else
    {
        std::cerr << "GameKI::chooseBestSequence "
                  << "No matching deck found."
                  << std::endl;
    }

    return ok;
}

// Return points for the position of the bot on the game board.
int GameKI::getChoicePoints( const Bot& bot, const bool negative ) const
{
    // The idea for the function:
    // * Bot is finished  =  1000 points
    // * Bot is destroyed = -1000 points
    // * Else:
    //   * Bot distance           = l1-norm to finish points
    //   * Points from Tile around the robot
   
    int points = 0;

    if ( bot.isFinished() )
    {
        // bot is finished => great! :)
        points = GK_WEIGHT_FINISH;
    }
    else if ( bot.isDestroyed() )
    {
        // bot is destroyed => very bad! :(
        points = GK_WEIGHT_DESTROYED;

        // if we want the negative result, we must multiply with -1
        // that means we would weight a dead as positive
        if ( negative )
        {
            points *= -1;
        }
    }
    else
    {
        // get points from robot position
        points += getChoicePointsFromRobotPosition( bot );

        //std::cout << "GameKI::getChoicePoints1 "
                  //<< "Bot: (" << bot.getPos().x() << ","
                              //<< bot.getPos().y() << ") "
                              //<< (int)bot.getViewDirection() << " "
                  //<< "Points: " << points
                  //<< std::endl;
        
        // get points from tile type the robot stands on
        points += getChoicePointsFromTileTypeConveyorBelt( bot );

        //std::cout << "GameKI::getChoicePoints2 "
                  //<< "Bot: (" << bot.getPos().x() << ","
                              //<< bot.getPos().y() << ") "
                              //<< (int)bot.getViewDirection() << " "
                  //<< "Points: " << points
                  //<< std::endl;
    }
    
    return points;
    
}

// return number of points for robot position
int GameKI::getChoicePointsFromRobotPosition( const Bot& bot ) const
{
    // get bot position
    const Position &pos = bot.getPos();
    
    // points for that move
    int points = 0;
    
    if ( !m_shortestPath.empty() )
    {
        // The idea is the following:
        // We check for each path position how far away
        // we are with the bot position.
        // Then we choose the path position with the lowest l1-distance
        // to it.

        PositionVector::const_reverse_iterator rit;

        // print vector
        //std::cout << "Path:";
        //for ( rit = m_shortestPath.rbegin(); rit < m_shortestPath.rend(); rit++ )
        //{
            //std::cout << " -> ("
                      //<< (*rit).x() << "," << (*rit).y()
                      //<< ")";
        //}
        //std::cout << std::endl;
        
        // go through path and check each position
        unsigned int shortestDist = 10000;
        unsigned int shortestPos = 0;
        unsigned int counter = 0;
        
        // Note: It's bettet to keep on the path (even Hansel and Gretel
        // know that). Otherwise it's possible we leave the path a
        // little bit and land in a dead end.
        
        for ( rit = m_shortestPath.rbegin(); rit < m_shortestPath.rend(); rit++ )
        {
            const unsigned int dist = L1norm( pos, (*rit) );
            
            if ( dist <= shortestDist )
            {
                shortestDist = dist;
                shortestPos = counter;
            }
            counter++;
        }
        
        if ( 0 == shortestDist )
        {
            // add points and leave loop
            points += GK_WEIGHT_CORRECT_PATH;
            points += GK_WEIGHT_POSITION * shortestPos;
            // points += GK_WEIGHT_POSITION_DIST * shortestDist;
        }
                
        //std::cout << "GameKI::getChoicePointsFromRobotPosition "
                  //<< " Pos "
                  //<< "(" << pos.x() << "," << pos.y() <<  ")"
                  //<< " found at " << shortestPos
                  //<< " with dist "
                  //<< shortestDist
                  //<< "."
                  //<< std::endl;
    }
    else
    //if ( 0 == points )
    {
        // if we do not have a shortest path
        // we use the direct approach as fall back mode

        // calculate distance (l1-norm) to finish
        const unsigned int distance = L1norm( pos, m_finishPos );
              
        // get old bot position
        const Position &oldPos = m_bot.getPos();
              
        // calculate distance (l1-norm) to finish
        const unsigned int oldDistance = L1norm( oldPos, m_finishPos );
              
        // that means if we are further away than before that's bad
        // if we are nearer that's good
        // we weight the distance with 3
        points = GK_WEIGHT_POSITION * ( oldDistance - distance );

        // add negative value if we do not move forward in ANY direction.
        // this should help if the robot gets stuck.
        if ( pos == oldPos )
        {
            points += GK_WEIGHT_STUCK;
        }

        //std::cout << "GameKI::getChoicePointsFromRobotPosition "
                  //<< " oldDist: " << oldDistance
                  //<< " newDist: " << distance
                  //<< std::endl;
    }

    return points;
}

// return number of points for tile robot stands on
// if this is a conveyor belt
int GameKI::getChoicePointsFromTileTypeConveyorBelt( const Bot& bot ) const
{
    int points = 0;

    // get bot position
    const Position &pos = bot.getPos();

    // 5. Check for conveyor belt
    if ( NULL != m_board[pos] )
    {
        if ( m_board[pos]->isType( TE_TYPE_CONVEYOR_BELT ) )
        {
            // bot stands on a conveyor belt
            Position pos2;

            // get position of tile on board
            TileMaskPosition border = m_board.isBorderTile( pos );
            
            // and maybe there is a hole
            // next to the conveyor belt
            if ( pos.x() > 0 )
            {
                pos2.set( pos.x()-1, pos.y() );
                if ( m_board[pos2]->isType( TE_TYPE_HOLE ) )
                {
                    border = (TileMaskPosition)(border | TM_POSITION_LEFT);
                }
            }
            if ( pos.x() < m_board.getWidth()-1 )
            {
                pos2.set( pos.x()+1, pos.y() );
                if ( m_board[pos2]->isType( TE_TYPE_HOLE ) )
                {
                    border = (TileMaskPosition)(border | TM_POSITION_RIGHT);
                }
            }
            if ( pos.y() > 0 )
            {
                pos2.set( pos.x(), pos.y()-1 );
                if ( m_board[pos2]->isType( TE_TYPE_HOLE ) )
                {
                    border = (TileMaskPosition)(border | TM_POSITION_UP);
                }
            }
            if ( pos.y() < m_board.getHeight()-1 )
            {
                pos2.set( pos.x(), pos.y()+1 );
                if ( m_board[pos2]->isType( TE_TYPE_HOLE ) )
                {
                    border = (TileMaskPosition)(border | TM_POSITION_DOWN);
                }
            }

            // if ( border != 0 )
            //{
                //std::cout << "BELT " << pos.x() << " " << pos.y()
                          //<< " Border: " << border
                          //<< " Move: " << m_board[pos]->getMoveDir()
                          //<< std::endl;
            //}
            
            if ( border & m_board[pos]->getMoveDir() )
            {
                // the conveyor belt goes over the edge
                
                // get bot position
                if ( border & BotFunctions::convertToDirection( bot.getViewDirection() ) )
                {
                    // the bot looks in the direction of the edge
                    // this is mostly the dead
                    points = -800;
                }
                else if ( border & BotFunctions::convertToOppositeDirection( bot.getViewDirection() ) )
                {
                    // the robot stand in opposite direction of belt
                    // so he has a little chance to escape
                    points = - 400;
                }
                else
                {
                    // otherwise the robots stands orthogonal
                    // to the belt and mostly only need to
                    // step one step in front or back
                    points = -200;
                }
            }
        }
    }

    return points;
}

// return l1 norm of two positions
unsigned int GameKI::L1norm( const Position& pos1, const Position& pos2 )
{
    const unsigned int dist = ( abs( pos1.x() - pos2.x() ) + abs( pos1.y() - pos2.y() ) );

    //std::cout << "(" << pos1.x() << "," << pos1.y() << ") - "
              //<< "(" << pos2.x() << "," << pos2.y() << ") = "
              //<< dist << "."
              //<< std::endl;

    return dist;
}
