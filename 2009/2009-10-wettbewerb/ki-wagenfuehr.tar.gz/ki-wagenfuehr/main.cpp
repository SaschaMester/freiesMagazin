// *************************************************************************
// robots-ki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <string>

#include "gameki.hh"
#include "basefunctions.hh"

int main( int argc, char *argv[] )
{
    // try to extract optional game level
    std::string level( "normal" );

    if ( 2 == argc )
    {
        level = argv[1];
    }
    // ignore other arguments
    
    int retValue = -1;
    
    // set game level
    if ( BaseFunctions::setGameLevel( level ) )
    {
        std::cout << "Level: " << level.c_str() << std::endl;

        // create game ki
        GameKI KI;

        if ( KI.hasNoError() )
        {
            // choose best choice
            KI.chooseAndSaveBestDeck( "ccards.txt" );
        }
        
        retValue = (int)KI.getError();
    }
    else
    {
        std::cerr << "Level " << level.c_str() << " is not correct."
                  << std::endl;
        retValue = (int)GameKI::GK_ERROR_LEVEL_NOT_CORRECT;
    }

    return retValue;
}
