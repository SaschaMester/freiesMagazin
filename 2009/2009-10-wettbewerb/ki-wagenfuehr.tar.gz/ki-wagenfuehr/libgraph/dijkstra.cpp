// *************************************************************************
// robots-ki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <iostream>

#include "dijkstra.hh"
#include "baseenums.hh"

// Default constructor.
// Constructor setting graph and start position
Dijkstra::Dijkstra( const Graph& graph, const Position& startPos )
    : m_endPosReachable(false), m_startNode(NULL)
{
    // init algorithm 
    if ( init( graph, startPos ) )
    {
        // now search the shortest path
        if ( !searchShortestPath() )
        {
            // if there was an error we should not reach the end
            m_endPosReachable = false;
        }
    }
    else
    {
        // if there was an error we should not reach the end
        m_endPosReachable = false;
    }
}

// Destructor.
Dijkstra::~Dijkstra()
{
    // do not delete the pointers in the lists!
    m_startNode = NULL;
}

// Init algorithm with start position and check graph.
// Return true if everything is okay.
bool Dijkstra::init( const Graph& graph, const Position& startPos )
{
    bool ok = false;
    
    // check if graph is okay
    if ( graph.isValid() )
    {
        // set start node
        m_startNode = graph[startPos];
        
        // mark start node
        m_startNode->setStartNode();

        // set end node
        m_endNode = graph[graph.getEndPos()];
        
        if ( m_endNode->isEndNode() )
        {
            // check if position is on game board
            if ( NULL != m_startNode )
            {
                // fill list with pointers to accessable nodes
                m_unknownNodeNeighborList.push_back( m_startNode );
                
                //std::cout << "Dijkstra::init(Graph, Pos) "
                          //<< " Info:"
                          //<< " Start: " << m_startNode
                          //<< std::endl;
                
                // set distance of first node to zero
                m_startNode->setDistanceFromStart( 0 );

                ok = true;
            }
            else
            {
                std::cerr << "Dijkstra::init(Graph, Pos) "
                          << "Error: Start position "
                          << "(" << startPos.x() << "," << startPos.y() << ")"
                          << " not found in graph!"
                          << std::endl;
            }
        }
        else
        {
            std::cerr << "Dijkstra::init(Graph, Pos) "
                      << "Error: End node "
                      << m_endNode
                      << " is not marked as end node!"
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "Dijkstra::init(Graph, Pos) "
                  << "Error: Graph is not valid!"
                  << std::endl;
    }
    
    return ok;
}

// Search shortest path from start element in list.
// Return true if everything is okay.
bool Dijkstra::searchShortestPath()
{
    bool ok = true;

    // iterate over all elements in list
    while ( !m_unknownNodeNeighborList.empty() )
    {
        Node* nearest = searchAndRemoveNearestNodeFromStart();
        
        //std::cout << std::endl << "------------------------------------------------------------------" << std::endl;
        //std::cout << "Dijkstra::searchShortestPath() "
                  //<< " Info:"
                  //<< " Nearest: "
                  //<< nearest
                  //<< std::endl;
        
        if ( NULL != nearest )
        {
            //std::cout << "Dijkstra::searchShortestPath() "
                      //<< " Info:"
                      //<< " is End: "
                      //<< nearest->isEndNode()
                      //<< " Dist: "
                      //<< nearest->getDistanceFromStart()
                      //<< " Pos: (" << nearest->getPosition().x()
                      //<< "," <<  nearest->getPosition().y() << ")"
                      //<< std::endl;

            // check if this is the end node
            if ( nearest->isEndNode() )
            {
                //std::cout << "Dijkstra::searchShortestPath() "
                          //<< " Info: End set!"
                          //<< std::endl;
                m_endPosReachable = true;
            }

            // add new node to knownList
            m_knownNodeNeighborList.push_back( nearest );

            // now check all neighbors of this node
            if ( !checkNeighbors( nearest ) )
            {
                // there was an error, break here
                ok = false;
                break;
            }
        }
        else
        {
            // We have not found a node in the list even
            // if it's not empty
            // This should not happen.
            std::cerr << "Dijkstra::searchShortestPath() "
                      << " Error: Node is NULL!"
                      << std::endl;
            ok = false;
            break;
        }
    }

    return ok;
}

// search the nearest node form the start node in the
// list with node and unknown neighbors
// and remove it form the list.
Node* Dijkstra::searchAndRemoveNearestNodeFromStart()
{
    NodePointerVector::iterator it;
    NodePointerVector::iterator nearestIt;
    Node *nearestNode = NULL;

    // store if we iterate the first element
    bool first = true;

    for ( it = m_unknownNodeNeighborList.begin();
             it < m_unknownNodeNeighborList.end(); it++ )
    {
        // if this is the first element or the new
        // node is nearer that the currently nearest element
        // we store it.
        if ( first ||
             (*it)->getDistanceFromStart() < (*nearestIt)->getDistanceFromStart() )
        {
            nearestIt = it;
            first = false;
        }
    }
    
    // if we have at least one relevant element, we will remove
    // the node from the list.
    if ( !first )
    {
        nearestNode = (*nearestIt);
        m_unknownNodeNeighborList.erase( nearestIt );
    }
    
    return nearestNode;
}

// check all neighbors of this node and add them to
// our list if necessary.
// Return true if everything is okay.
bool Dijkstra::checkNeighbors( Node* node )
{
    bool ok = false;
    
    if ( NULL != node )
    {
        // suppose everything is okay
        ok = true;

        for ( int ii = 0; ii < 4; ii++ )
        {
            // convert iterator to viewing direction
            const BaseEnumDirection view = (BaseEnumDirection)(1 << ii);

            // check if there is a neighbor
            Node *neighbor = node->getNeighbor( view );
            
            //std::cout << "Dijkstra::checkNeighbors(Node*) "
                      //<< " Info:"
                      //<< " " << node
                      //<< " " << neighbor
                      //<< " View: " << view
                      //<< std::endl;
            
            if ( NULL != neighbor )
            {
                const bool neighborInKnownList =
                               find( m_knownNodeNeighborList, neighbor );
                const bool neighborInUnknownList = 
                               find( m_unknownNodeNeighborList, neighbor );

                //std::cout << "Dijkstra::checkNeighbors(Node*) "
                          //<< " Info:"
                          //<< " in known: " << neighborInKnownList
                          //<< " in unknown: " << neighborInUnknownList
                          //<< " Pos: (" << neighbor->getPosition().x()
                          //<< "," <<  neighbor->getPosition().y() << ")"
                          //<< std::endl;

                // check if neighbor node is already in a list
                if ( !neighborInKnownList && !neighborInUnknownList )
                {
                    // add this neighbor to the list and mark edge
                    if ( !addNeighborAndMarkEdge( node, neighbor, view ) )
                    {
                        // There was an error so break here.
                        ok = false;
                        break;
                    }
                }
                else if ( neighborInUnknownList )
                {
                    // we already have stored the neighbor and can
                    // check the new distance.
                    if ( !markEdgesToNeighbor( node, neighbor, view ) )
                    {
                        // There was an error so break here.
                        ok = false;
                        break;
                    }
                }
                else
                {
                    // If the neighbor is in the known list
                    // we already have checked it.
                    // That further means the edge to this neighbor
                    // cannot be the shortest, so mark it.
                    if ( !node->setEdgeState( view, EDGE_STATE_NORMAL ) )
                    {
                        ok = false;
                        break;
                    }
                }
            }

            // std::cout << "--------------------------" << std::endl << std::endl;
        } // for
    }
    else
    {
        std::cerr << "Dijkstra::checkNeighbors(Node*) "
                  << " Error: Node is NULL!"
                  << std::endl;
    }
    
    return ok;
}

// Add a new neighbor to the list and mark edge.
// Return true if everything is okay
bool Dijkstra::addNeighborAndMarkEdge( Node* node, Node *neighbor,
                                       const BaseEnumDirection view )
{
    bool ok = false;
    
    if ( NULL != node && NULL != neighbor )
    {
        //std::cout << "Dijkstra::addNeighborAndMarkEdge(Node*,Node*,view) "
                  //<< " Info:"
                  //<< " " << node
                  //<< " " << neighbor
                  //<< " View: " << view
                  //<< " Dist: " << neighbor->getDistanceFromStart()
                  //<< " -> " << node->getDistanceFromStart() + node->getDistance( view )
                  //<< std::endl;

        // the neighbor is new, we have not found it
        // in one of our lists => so add it
        m_unknownNodeNeighborList.push_back( neighbor );
        
        // mark the edge from node to neighbor as shortest
        // First check if we are in the correct state.
        if ( node->setEdgeState( view, EDGE_STATE_SHORTEST ) )
        {
            // calculate new distance
            neighbor->setDistanceFromStart( node->getDistanceFromStart() +
                                            node->getDistance( view ) );
            ok = true;
        }
    }
    else
    {
        std::cerr << "Dijkstra::addNeighborAndMarkEdge(Node*,Node*,view) "
                  << " Error: Node or neighbor is NULL: "
                  << node << " " << neighbor << "."
                  << std::endl;
    }
    
    return ok;
}

// Mark the edges to a neighbor and calculate new distance.
// Return true if everything is okay
bool Dijkstra::markEdgesToNeighbor( Node* node, Node *neighbor,
                                    const BaseEnumDirection view )
{
    bool ok = false;
    
    if ( NULL != node && NULL != neighbor )
    {
        const int newDist = node->getDistanceFromStart() +
                            node->getDistance( view );

        //std::cout << "Dijkstra::markEdgesToNeighbor(Node*,Node*,view) "
                  //<< " Info:"
                  //<< " " << node 
                  //<< " " << neighbor
                  //<< " View: " << view
                  //<< " OldDist: " << neighbor->getDistanceFromStart()
                  //<< " NewDist: " << newDist
                  //<< std::endl;

        if ( newDist < neighbor->getDistanceFromStart() )
        {
            // mark the old shortest node to this neighbor as normal edge
            if ( node->setShortestPathPredecessorNeighbor( view ) )
            {
                // set new distance
                neighbor->setDistanceFromStart( newDist );
                ok = true;
            }
        }
        else
        {
            // Do not use this edge as shortest because the old one is
            // shorter.
            if ( node->setEdgeState( view, EDGE_STATE_NORMAL ) )
            {
                ok = true;
            }
        }
    }
    else
    {
        std::cerr << "Dijkstra::addNeighborAndMarkEdge(Node*,Node*) "
                  << " Error: Node or neighbor is NULL: "
                  << node << " " << neighbor << "."
                  << std::endl;
    }
    
    return ok;
}

// Search node in list.
// Return true if found.
bool Dijkstra::find( NodePointerVector& list, const Node* node )
{
    NodePointerVector::iterator it;
    bool found = false;

    for ( it = list.begin(); it < list.end(); it++ )
    {
        if ( (*it) == node )
        {
            found = true;
            break;
        }
    }
    return found;
}

// Get shortest path from start to finish if calculated.
// Return true if everything is okay
bool Dijkstra::getShortestPath( PositionVector& path )
{
    bool ok = false;

    // clear old path
    path.clear();
    
    // print the whole path with all nodes and states
    // printGraph();

    // is the start node given    
    if ( NULL != m_startNode )
    {
        // Can we reach the finish?
        if ( m_endPosReachable && NULL != m_endNode )
        {
            // We must go from end to start to get the shortest path.
            Node *node = m_endNode;
            Node *lastNode = NULL;

            // iterate until we have no predecessor
            while ( NULL != node )
            {
                // store position
                path.push_back( node->getPosition() );
                lastNode = node;
                node = node->getShortestPathPredecessor();
            }

            // at the end the last node must equal the start node
            if ( lastNode == m_startNode )
            {
                ok = true;
            }
            else
            {
                std::cerr << "Dijkstra::getShortestPath(PositionVector) "
                          << " Error: End node not found."
                          << std::endl;
            }
        }
        else
        {
            std::cerr << "Dijkstra::getShortestPath(PositionVector) "
                      << " Error: No possible way found to finish."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "Dijkstra::getShortestPath(PositionVector) "
                  << " Error: Start node is NULL!"
                  << std::endl;
    }
    
    return ok;
}

// print the whole path with all nodes and states
void Dijkstra::printGraph() const
{
    Node *node = m_startNode;

    std::cout << std::endl << "Start: " << node << std::endl;

    NodePointerVector printedNodes;
    
    // print graph recursivly from this node
    printGraph( node, printedNodes );
}

// print the node and all edges
void Dijkstra::printGraph( Node* node,
                           NodePointerVector& printedNodes ) const
{
    if ( NULL != node && !find( printedNodes, node) )
    {
        std::cout << "------------------------------------------" << std::endl
                  << "Node: " << node
                  << " (" << node->getPosition().x() << "," << node->getPosition().y() << ")"
                  << " Dist: " << node->getDistanceFromStart()
                  << std::endl;

        // add node to list of printed nodes
        printedNodes.push_back(node);
    
        // print edges
        for ( unsigned int ii = 0; ii < 4; ii++ )
        {
            const BaseEnumDirection view = (BaseEnumDirection)(1 << ii);
            std::cout << "      Edge " << view << ":"
                      << " " << node->getNeighbor( view )
                      << " Dist: " << node->getDistance( view )
                      << " State: " << node->getEdgeState( view )
                      << std::endl;
        }
        
        // iterate over all neighbors
        for ( unsigned int ii = 0; ii < 4; ii++ )
        {
            const BaseEnumDirection view = (BaseEnumDirection)(1 << ii);
            printGraph( node->getNeighbor( view ), printedNodes );
        }
    }
}
