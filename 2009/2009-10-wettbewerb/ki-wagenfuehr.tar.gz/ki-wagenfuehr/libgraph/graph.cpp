// *************************************************************************
// robots-ki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <iostream>

#include "graph.hh"
#include "basefunctions.hh"

// Default constructor.
Graph::Graph( const GameBoard& originalBoard  )
    : m_width(0), m_height(0), m_valid(false)
{
    init( originalBoard );
}

// Destructor.
Graph::~Graph()
{
    clear();
}

// delete graph
void Graph::clear()
{
    for ( unsigned int jj = 0; jj < getHeight(); jj++ )
    {
        for ( unsigned int ii = 0; ii < getWidth(); ii++ )
        {
            if ( NULL != m_board[aPos(ii,jj)] )
            {
                // free memory
                delete m_board[aPos(ii,jj)];
                m_board[aPos(ii,jj)] = NULL;
            }
        }
    }
    
    m_endPos.set(0,0);
}

// access node element
// boundary check only in debug version
Node* Graph::operator[] ( const Position& pos ) const
{
    if ( pos.x() < getWidth() &&
         pos.y() < getHeight() )
    {
        return m_board[aPos(pos)];
    }

    std::cerr << "Graph::operator[] "
              << " Access from ("
              << pos.x() << "," << pos.y()
              << ") is out of bounds ("
              << getWidth()-1 << "," << getHeight()-1
              << ")."
              << std::endl;

    return NULL;
}

// Init graph with given game board.
// Return true if everything is okay.
bool Graph::init( const GameBoard& originalBoard )
{
    bool ok = false;
    
    // clear old graph at the beginning
    clear();
    
    if ( originalBoard.isValid() &&
         originalBoard.getWidth() > 0 &&
         originalBoard.getHeight() > 0 )
    {
        // set new size
        m_width = originalBoard.getWidth();
        m_height = originalBoard.getHeight();

        // allocate enough memory for the tiles
        m_board.resize( getWidth()*getHeight() );

        bool memoryError = false;
        
        //std::cout << "Graph::init(GameBoard) "
                  //<< " Info: Pointer memory allocated."
                  //<< std::endl; 
        
        // allocate memory for new tiles
        for ( unsigned int jj = 0; jj < getHeight(); jj++ )
        {
            for ( unsigned int ii = 0; ii < getWidth(); ii++ )
            {
                m_board[aPos(ii,jj)] = new Node( Position(ii,jj) );
                
                if ( NULL == m_board[aPos(ii,jj)] )
                {
                    // memory could not be allocated.
                    memoryError = true;
                    
                    std::cerr << "Graph::init(GameBoard) "
                              << " Error: Could not allocate memory at"
                              << " (" << ii << "," << jj << ")."
                              << std::endl; 
                    break;
                }
            }
            
            if ( memoryError )
            {
                break;
            }
        }

        //std::cout << "Graph::init(GameBoard) "
                  //<< " Info: Tile memory allocated: "
                  //<< memoryError
                  //<< std::endl; 
        
        // only connect neighbors if all nodes could be allocated
        if ( !memoryError )
        {
            // init neighbors
            if ( initNeighbors( originalBoard ) )
            {
                // store end position
                m_endPos = originalBoard.getEndPos();
                
                // set end pos flag for this node
                m_board[aPos(m_endPos)]->setEndNode();
                
                ok = true;
            }
        }
    }
    
    // set validity status
    m_valid = ok;
    
    return ok;
}

// Init all neighbors on the board.
// Return true if everything is okay.
bool Graph::initNeighbors( const GameBoard& originalBoard )
{
    Position pos1, pos2;
    BaseEnumDirection view;
    
    bool ok = false;
    
    // go through the game board and create information
    // for the neighbors
    for ( unsigned int jj = 0; jj < getHeight(); jj++ )
    {
        for ( unsigned int ii = 0; ii < getWidth(); ii++ )
        {
            // set this position
            pos1.set(ii,jj);

            //std::cout << "Graph::initNeighbors(GameBoard) "
                      //<< " Info: Befor "
                      //<< " Pos: " << pos1.x() << " " << pos1.y()
                      //<< " " << m_board[aPos(pos1)]
                      //<< " " << m_board[aPos(pos1)]->getNeighbor( BE_DIRECTION_LEFT )
                      //<< " " << m_board[aPos(pos1)]->getNeighbor( BE_DIRECTION_RIGHT )
                      //<< " " << m_board[aPos(pos1)]->getNeighbor( BE_DIRECTION_UP )
                      //<< " " << m_board[aPos(pos1)]->getNeighbor( BE_DIRECTION_DOWN )
                      //<< std::endl;
            
            // tile to the left
            if ( ii > 0 )
            {
                view = BE_DIRECTION_LEFT;
                pos2.set( ii-1, jj );
                if ( !initNeighbors( originalBoard, pos1, pos2, view ) )
                {
                    return ok;
                }
            }
            
            // tile to the right
            if ( ii < getWidth()-1 )
            {
                view = BE_DIRECTION_RIGHT;
                pos2.set( ii+1, jj );
                if ( !initNeighbors( originalBoard, pos1, pos2, view ) )
                {
                    return ok;
                }
            }

            // tile above
            if ( jj > 0  )
            {
                view = BE_DIRECTION_UP;
                pos2.set( ii, jj-1 );
                if ( !initNeighbors( originalBoard, pos1, pos2, view ) )
                {
                    return ok;
                }
            }

            // tile below
            if ( jj < getHeight()-1  )
            {
                view = BE_DIRECTION_DOWN;
                pos2.set( ii, jj+1 );
                if ( !initNeighbors( originalBoard, pos1, pos2, view ) )
                {
                    return ok;
                }
            }

            //std::cout << "Graph::initNeighbors(GameBoard) "
                      //<< " Info: After "
                      //<< " Pos: " << pos1.x() << " " << pos1.y()
                      //<< " " << m_board[aPos(pos1)]
                      //<< " " << m_board[aPos(pos1)]->getNeighbor( BE_DIRECTION_LEFT )
                      //<< " " << m_board[aPos(pos1)]->getNeighbor( BE_DIRECTION_RIGHT )
                      //<< " " << m_board[aPos(pos1)]->getNeighbor( BE_DIRECTION_UP )
                      //<< " " << m_board[aPos(pos1)]->getNeighbor( BE_DIRECTION_DOWN )
                      //<< std::endl;
        }
    }
    
    // recheck all tiles for oil tiles
    // the problem with oil tiles is that you normally
    // cannot stand on them
    // That means we must "override" a oil tile in the direction the
    // robot moves.
    if ( recheckOilNeighbors( originalBoard ) )
    {
        ok = true;
    }
    
    return ok;
}

// Connect the node on pos1 with the node on pos2 if possible.
// Return true if possible.
bool Graph::initNeighbors( const GameBoard& originalBoard,
                           const Position& pos1,
                           const Position& pos2,
                           const BaseEnumDirection view)
{
    //std::cout << "Graph::initNeighbors(GameBoard,pos1,pos2,view) "
              //<< " Info: "
              //<< " Pos1: (" << pos1.x() << "," << pos1.y() << ")"
              //<< " " << m_board[aPos(pos1)]
              //<< " Pos2: (" << pos2.x() << "," << pos2.y() << ")"
              //<< " " << m_board[aPos(pos2)]
              //<< std::endl;

    bool ok = false;
    
    // check if tiles exists on board
    if ( NULL != m_board[aPos(pos1)] && NULL != m_board[aPos(pos2)] &&
         NULL != originalBoard[pos1] && NULL != originalBoard[pos2] )
    {
        // get opposite view
        const BaseEnumDirection oppView = BaseFunctions::getOppositeDirection( view );

        //std::cout << "Graph::initNeighbors(GameBoard,pos1,pos2,view) "
                  //<< " Info: "
                  //<< " View: " << view
                  //<< " OppView: " << oppView
                  //<< " Leave: " << originalBoard[pos1]->canLeave( view )
                  //<< " Enter: " << originalBoard[pos2]->canEnter( view )
                  //<< " " << m_board[aPos(pos1)]->getNeighbor( view )
                  //<< " " << m_board[aPos(pos2)]->getNeighbor( oppView ) 
                  //<< std::endl;
                  
        // we will only check tiles that do not have a neighbor yet
        // otherwise we would set many tiles doubled
        if ( NULL == m_board[aPos(pos1)]->getNeighbor( view ) &&
             NULL == m_board[aPos(pos2)]->getNeighbor( oppView ) )
        {
            // check if we can leave this tile and move to the other
            if ( originalBoard[pos1]->canLeave( view ) &&
                 originalBoard[pos2]->canEnter( view ) )
            {
                // check if the origin and target is not a hole
                if ( !originalBoard[pos1]->isType( TE_TYPE_HOLE ) &&
                     !originalBoard[pos2]->isType( TE_TYPE_HOLE ) )
                {
                    // calculate distance for moving from pos1 to pos2
                    // and back
                    int dist1 = 0, dist2 = 0;
                    
                    if ( calculateDistance( originalBoard[pos1],
                                            originalBoard[pos2],
                                            dist1, dist2,
                                            view, oppView ) )
                    {
                        //std::cout << "A: "
                                  //<< originalBoard[pos1]->isType(TE_TYPE_OIL)
                                  //<< " weight: " << dist1
                                  //<< " pos: " << pos1.x() << "," << pos1.y()
                                  //<< " | "
                                  //<< originalBoard[pos2]->isType(TE_TYPE_OIL)
                                  //<< " weight: " << dist2
                                  //<< " pos: " << pos2.x() << "," << pos2.y()
                                  //<< std::endl;

                        // associate both neighbors
                        if ( m_board[aPos(pos1)]->setNeighborAndDistance(view, m_board[aPos(pos2)], dist1 ) &&
                             m_board[aPos(pos2)]->setNeighborAndDistance(oppView, m_board[aPos(pos1)], dist2 ) )
                        {
                            ok = true;
                        }
                    }
                }
                else
                {
                    ok = true;
                }
            }
            else
            {
                ok = true;
            }
        }
        else
        {
            ok = true;
        }
    }
    else
    {
        std::cout << "Graph::initNeighbors(GameBoard,pos1,pos2,view) "
                  << " Error: Some board pointer is NULL "
                  << " " << m_board[aPos(pos1)]
                  << " " << m_board[aPos(pos2)]
                  << " " << originalBoard[pos1]
                  << " " << originalBoard[pos2]
                  << "." << std::endl;
    }
    
    return ok;
}

// Recheck the game board for oil trails.
// Return true if everything is okay.
bool Graph::recheckOilNeighbors( const GameBoard& originalBoard )
{
    bool ok = false;

    // go through the game board and check for oil tiles
    
    // check each row
    for ( unsigned int jj = 0; jj < getHeight(); jj++ )
    {
        if ( !recheckOilNeighborsInRow( jj, originalBoard ) )
        {
            return ok;
        }
    }
    
    // check each column
    for ( unsigned int ii = 0; ii < getWidth(); ii++ )
    {
        if ( !recheckOilNeighborsInColumn( ii, originalBoard ) )
        {
            return ok;
        }
    }
    
    ok= true;
    return ok;
}

// Recheck the game board for oil trails in a row.
// Return true if everything is okay.
bool Graph::recheckOilNeighborsInRow( const unsigned int row,
                                      const GameBoard& originalBoard )
{
    Position pos;
    bool ok = true;

    for ( unsigned int ii = 0; ii < getWidth(); ii++ )
    {
        // set position
        pos.set(ii,row);
        
        if ( NULL != originalBoard[pos] &&
             originalBoard[pos]->isType( TE_TYPE_OIL ) )
        {
            Node *node = m_board[aPos(pos)];
            if ( NULL != node )
            {
                if ( !node->isolateNodeLeftRight() )
                {
                    ok = false;
                    break;
                }
            }
        }
    }
    
    return ok;
}

// Recheck the game board for oil trails in a row.
// Return true if everything is okay.
bool Graph::recheckOilNeighborsInColumn( const unsigned int column,
                                         const GameBoard& originalBoard )
{
    Position pos;
    bool ok = true;

    for ( unsigned int jj = 0; jj < getHeight(); jj++ )
    {
        // set position
        pos.set(column,jj);
        
        if ( NULL != originalBoard[pos] &&
             originalBoard[pos]->isType( TE_TYPE_OIL ) )
        {
            Node *node = m_board[aPos(pos)];
            if ( NULL != node )
            {
                if ( !node->isolateNodeUpDown() )
                {
                    ok = false;
                    break;
                }
            }
        }
    }
    
    return ok;
}

// Calculate distance when going from tile1 to tile 2 and back
// Return true if everything is okay.
bool Graph::calculateDistance( const BaseTile* tile1, const BaseTile* tile2,
                               int& dist1, int& dist2,
                               const BaseEnumDirection view,
                               const BaseEnumDirection oppView ) const
{
    bool ok = false;

    dist1 = 0;
    dist2 = 0;

    if ( NULL != tile1 && NULL != tile2 )
    {
        bool distSet1 = false;
        bool distSet2 = false;

        // handle OIL and HOLE
        distSet1 = calculateDistanceFromTile( tile1, dist1 );
        distSet2 = calculateDistanceFromTile( tile2, dist2 );

        // handle BELT and PUSHER
        distSet1 = calculateDistanceToTile( tile2, dist1, view, oppView ) || distSet1;
        distSet2 = calculateDistanceToTile( tile1, dist2, oppView, view ) || distSet2;
        
        // in all other cases the distance will be 1
        if ( !distSet1 )
        {
            dist1 = 1;
        }
        if ( !distSet2 )
        {
            dist2 = 1;
        }

        ok = true;
    }
    else
    {
        std::cerr << "Graph::calculateDistance(...) "
                  << " Error: Some board pointer is NULL "
                  << " " << tile1
                  << " " << tile2
                  << "." << std::endl;
    }
    
    return ok;
}

// Calculate distance when coming from this tile.
// Return true if weight was set
bool Graph::calculateDistanceFromTile( const BaseTile* tile,
                                       int& dist ) const
{
    bool distSet = false;
    
    // Note: Do not reset weight because it may be set before!
    
    if ( NULL != tile )
    {
        // if tile is an OIL tile we suppose
        // that we slide over it, so the costs are 0
        if ( tile->isType( TE_TYPE_OIL ) )
        {
            dist = 0;
            distSet = true;
        }
        // if tile is a HOLE tile (that should not happen)
        // we could not leave this tile, so the costs are high
        else if ( tile->isType( TE_TYPE_HOLE ) )
        {
            dist = 1000;
            distSet = true;
        }
        // everything else should be handled outside
    }
    else
    {
        std::cout << "Graph::calculateDistanceFromTile(BaseTile,int) "
                  << " Error: Board pointer is NULL "
                  << " " << tile
                  << "." << std::endl;
    }
    
    return distSet;
}

// Calculate distance when going to this tile.
// Return true if weight was set
bool Graph::calculateDistanceToTile( const BaseTile* tile,
                                     int& dist,
                                     const BaseEnumDirection view,
                                     const BaseEnumDirection oppView ) const
{
    bool distSet = false;
    
    // Note: Do not reset weight because it may be set before!
    
    if ( NULL != tile )
    {
        if ( tile->isType( TE_TYPE_CONVEYOR_BELT ) )
        {
            if ( (int)tile->getMoveDir() == (int)oppView )
            {
                dist = 3;
                distSet = true;
            }
            else if ( (int)tile->getMoveDir() != (int)view )
            {
                dist = 2;
                distSet = true;
            }
            else if ( (int)tile->getMoveDir() == (int)view )
            {
                dist = 0;
                distSet = true;
            }
        }
        else if ( tile->isType( TE_TYPE_PUSHER ) )
        {
            if ( (int)tile->getPushDir() == (int)oppView )
            {
                dist = 3;
                distSet = true;
            }
            else if ( (int)tile->getPushDir() != (int)view )
            {
                dist = 2;
                distSet = true;
            }
        }
        else if ( tile->isType( TE_TYPE_SQUEEZER ) )
        {
            // squeezers are bad, we should avoid going through them
            dist = 20;
            distSet = true;
        }
        // everything else should be handled outside
    }
    else
    {
        std::cout << "Graph::calculateDistanceToTile(BaseTile,int.view) "
                  << " Error: Board pointer is NULL "
                  << " " << tile
                  << "." << std::endl;
    }
    
    return distSet;
}

// Save graph to disc
// as graphviz dot-file
// return true if everything is okay
bool Graph::saveGraphviz( const std::string& filename ) const
{
    static const std::string shortestPathColor = "orange";
    
    bool ok = false;

    if ( !filename.empty() )
    {
        std::ofstream outFile;

        outFile.open( filename.c_str(), std::ios::out );
        
        const Node *endNode = NULL;

        if ( outFile.good() )
        {
            // in the first lines we store width and height
            outFile << "digraph G {" << std::endl;
            outFile << "  overlap=scalexy" << std::endl;

            for ( unsigned int jj = 0; jj < getHeight(); jj++ )
            {
                for ( unsigned int ii = 0; ii < getWidth(); ii++ )
                {
                    const Node* node = m_board[aPos(ii,jj)];
                    
                    //std::cout << "Graph::saveGraphviz "
                              //<< " Info:"
                              //<< " Pos: " << ii << " " << jj
                              //<< " " << node
                              //<< std::endl;
                    
                    if ( NULL != node )
                    {
                        // use color green for even edges and nodes
                        std::string color = "green";
                        std::string tempColor;
                        
                        // if we have an odd node, we use blue
                        if ( (ii+jj)%2 == 1 )
                        {
                            color = "blue";
                        }

                        //std::cout << "Graph::saveGraphviz "
                                  //<< " Info:"
                                  //<< " Color: " << color.c_str()
                                  //<< " " << node->getNeighbor( BE_DIRECTION_LEFT )
                                  //<< " " << node->getNeighbor( BE_DIRECTION_RIGHT )
                                  //<< " " << node->getNeighbor( BE_DIRECTION_UP )
                                  //<< " " << node->getNeighbor( BE_DIRECTION_DOWN )
                                  //<< std::endl;

                        // print single node first
                        const bool isStartOrEnd = node->isStartNode() ||
                                                  node->isEndNode();

                        // save end node for later
                        if ( node->isEndNode() )
                        {
                            endNode = node;
                        }

                        tempColor = color;
                        if ( isStartOrEnd )
                        {
                            color = shortestPathColor;
                        }
                        saveGraphvizNode( outFile, ii, jj, node->getDistanceFromStart(),
                                          color, isStartOrEnd );
                        color = tempColor;
                        
                        for ( unsigned int kk = 0; kk < 4; kk++ )
                        {
                            const BaseEnumDirection view = (BaseEnumDirection)(1 << kk);
                            
                            Node *neighbor = node->getNeighbor( view );
                            
                            if ( NULL != neighbor )
                            {
                                tempColor = color;
                                // if this is the shortes path mark it as shortestPathColor
                                if ( EDGE_STATE_SHORTEST == node->getEdgeState( view ) )
                                {
                                    color = shortestPathColor;
                                }
                                
                                // get position of neighbor node
                                const Position pos = neighbor->getPosition();
                                saveGraphvizEdge( outFile, ii, jj, pos.x(), pos.y(),
                                                  node->getDistance( view ), color );
                                color = tempColor;
                            }
                        }
                    }
                    else
                    {
                        std::cerr << "Graph::saveGraphviz(string) "
                                  << "Error: Node at "
                                  << ii << "," << jj
                                  << " is NULL."
                                  << std::endl;
                        return ok;
                    }
                }
            }

            // write shortest path separately
            // We must go from end to start to get the shortest path.
            const Node *lastNode = NULL;
            while ( NULL != endNode )
            {
                const Position pos = endNode->getPosition();

                // mark start node
                if ( endNode->isStartNode() )
                {
                    outFile << "  S [ label=\"\",shape=plaintext ]"
                            << std::endl;
                    outFile << "  S ->"
                            << "  \"" << pos.x() << "_" << pos.y() << "\" "
                            << "[ color="
                            << shortestPathColor.c_str()
                            << " ]"
                            << std::endl;
                }

                // mark end node
                if ( endNode->isEndNode() )
                {
                    outFile << "  E [ label=\"\",shape=plaintext ]"
                            << std::endl;
                    outFile << "  \"" << pos.x() << "_" << pos.y() << "\" "
                            << " -> E"
                            << "[ color="
                            << shortestPathColor.c_str()
                            << " ]"
                            << std::endl;
                }

                // only reprint the nodes between start and end
                if ( !endNode->isStartNode() && !endNode->isEndNode() )
                {
                    saveGraphvizNode( outFile, pos.x(), pos.y(),
                                      endNode->getDistanceFromStart(),
                                      shortestPathColor, true );
                }
                lastNode = endNode;
                endNode = endNode->getShortestPathPredecessor();
            }

            outFile << "}" << std::endl;
            outFile.close();

            ok = true;
        }
        else
        {
            std::cerr << "Graph::saveGraphviz(string) "
                      << "Error: File "
                      << filename.c_str()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "Graph::saveGraphviz(string) "
                  << "Error: Filename is empty."
                  << std::endl;
    }

    return ok;
}

// Save single node to outstream in graphviz format.
void Graph::saveGraphvizNode( std::ofstream& outFile,
                              const unsigned int x, const unsigned int y,
                              const int dist,
                              const std::string& color,
                              const bool isEndNode ) const
{
    if ( outFile.good() )
    {
        outFile << "  \"" << x << "_" << y << "\""
                << " [ "
                << " label=\"(" << x << "," << y << ") " << dist << "\","
                << "color=" << color.c_str() << ",";
        
        // fill end node with color to see it better
        if ( !isEndNode )
        {
            outFile << "fontcolor=" << color.c_str();
        }
        else
        {
            outFile << "fontcolor=white,style=filled";
        }
                
        outFile << " ]"
                << std::endl;
    }
}

// Save edge to outstream in graphviz format.
void Graph::saveGraphvizEdge( std::ofstream& outFile,
                              const unsigned int x1, const unsigned int y1,
                              const unsigned int x2, const unsigned int y2,
                              const int dist,
                              const std::string& color ) const
{
    if ( outFile.good() )
    {
        outFile << "  \"" << x1 << "_" << y1 << "\" "
                << "->"
                << "  \"" << x2 << "_" << y2 << "\" "
                << "[ "
                << "label=\"" << dist << "\","
                << "color=" << color.c_str() << ","
                << "fontcolor=" << color.c_str() << ","
                << "fontsize=10"
                << " ]"
                << std::endl;
    }
}
