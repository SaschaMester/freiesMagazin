// *************************************************************************
// robots-ki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef EDGE_HH
#define EDGE_HH

#include "edgeenums.hh"

// Forward declaration.
class Node;

// An edge connects two nodes.
class Edge
{
public:
    // Default constructor.
    Edge() : m_neighbor(NULL), m_distance(0), m_state(EDGE_STATE_NONE) {}
    
    // Destructor, nothing to do.
    virtual ~Edge() {}

    // Set a neighbor and it's distance for traveling.
    void setNeighborAndDistance( Node* newNeighbor,
                                 const int distance )
    {
        m_neighbor = newNeighbor;
        m_distance = distance;
    }

    // Return neighbor.
    Node* getNeighbor() const
    {
        return m_neighbor;
    }
    
    // Return distance.
    int getDistance() const
    {
        return m_distance;
    }

    // get edge state
    EdgeState getState() const
    {
        return m_state;
    }
    
    // set new edge state
    void setState( const EdgeState state )
    {
        m_state = state;
    }
    
protected:
    // Neighbor for this edge.
    Node* m_neighbor;
    
    // Distance to travel to this edge
    // (if neighbor is not NULL).
    int m_distance;

    // state for this edge in Dijkstra algorithm.
    EdgeState m_state;
};

#endif // EDGE_HH
