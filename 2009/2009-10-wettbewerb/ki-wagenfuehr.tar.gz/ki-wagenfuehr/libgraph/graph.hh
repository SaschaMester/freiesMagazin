// *************************************************************************
// robots-ki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef GRAPH_HH
#define GRAPH_HH

#include <string>
#include <vector>

#include "node.hh"
#include "gameboard.hh"
#include "position.hh"
#include "baseenums.hh"

typedef std::vector<Node*> NodePointerVector;

// Class for creating a path from robot position to game board finish.
class Graph
{
public:
    // Constructor, create graph.
    Graph( const GameBoard& originalBoard );

    // Destructor.
    ~Graph();

    // return width of graph
    unsigned int getWidth() const
    {
        return m_width;
    }

    // return height of graph
    unsigned int getHeight() const
    {
        return m_height;
    }
    
    // return flag if graph is valid.
    bool isValid() const
    {
        return m_valid;
    }

    // Return end position that we want to reach.
    const Position& getEndPos() const
    {
        return m_endPos;
    }

    // access node element
    Node* operator[] ( const Position& pos ) const;

    // Init graph with given game board.
    // Return true if everything is okay.
    bool init( const GameBoard& originalBoard );

    // Save graph to disc
    // as graphviz dot-file
    // return true if everything is okay
    bool saveGraphviz( const std::string& filename ) const;

protected:
    // delete graph
    void clear();

    // Init all neighbors on the board.
    // Return true if everything is okay.
    bool initNeighbors( const GameBoard& originalBoard );

    // Connect the tile on pos1 with the tile on pos2 if possible.
    // Return true if possible.
    bool initNeighbors( const GameBoard& originalBoard,
                        const Position& pos1, const Position& pos2,
                        const BaseEnumDirection view );

    // Recheck the game board for oil tiles.
    // Return true if everything is okay.
    bool recheckOilNeighbors( const GameBoard& originalBoard );

    // Recheck the game board for oil trails in a row.
    // Return true if everything is okay.
    bool recheckOilNeighborsInRow( const unsigned int row,
                                   const GameBoard& originalBoard );
                                   
    // Recheck the game board for oil trails in a row.
    // Return true if everything is okay.
    bool recheckOilNeighborsInColumn( const unsigned int column,
                                      const GameBoard& originalBoard );

    // Calculate weight when going from tile1 to tile 2 and back
    // Return true if everything is okay.
    bool calculateDistance( const BaseTile* tile1, const BaseTile* tile2,
                            int& dist1, int& dist2,
                            const BaseEnumDirection view,
                            const BaseEnumDirection oppView ) const;

    // Calculate distance when coming from this tile.
    // Return true if weight was set
    bool calculateDistanceFromTile( const BaseTile* tile,
                                    int& dist ) const;

    // Calculate distance when going to this tile.
    // Return true if weight was set
    bool calculateDistanceToTile( const BaseTile* tile,
                                  int& dist,
                                  const BaseEnumDirection view,
                                  const BaseEnumDirection oppView ) const;

    // Save single node to outstream in graphviz format.
    void saveGraphvizNode( std::ofstream& outFile,
                           const unsigned int x, const unsigned int y,
                           const int dist,
                           const std::string& color,
                           const bool isEndNode ) const;

    // Save edge to outstream in graphviz format.
    void saveGraphvizEdge( std::ofstream& outFile,
                           const unsigned int x1, const unsigned int y1,
                           const unsigned int x2, const unsigned int y2,
                           const int distance,
                           const std::string& color ) const;

    // Return array position for easier access.
    unsigned int aPos( const Position& pos ) const
    {
        return pos.x()+pos.y()*getWidth();
    }

    unsigned int aPos( const unsigned int x, const unsigned int y ) const
    {
        return x+y*getWidth();
    }

    ////////////////
    // Members
    ///////////////
    
    // Pointer to all tiles in the game board with neighbors etc.
    NodePointerVector m_board;
    
    // Width of game board.
    unsigned int m_width;
    
    // Height of game board.
    unsigned int m_height;
    
    // Flag if constructed astar board is valid.
    bool m_valid;
    
    // End position that we want to reach.
    Position m_endPos;
    
};

#endif // GRAPH_HH
