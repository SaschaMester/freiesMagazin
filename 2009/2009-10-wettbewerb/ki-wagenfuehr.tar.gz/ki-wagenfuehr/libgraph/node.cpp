// *************************************************************************
// robots-ki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#define MAX(a,b) ( ( (a)>(b) ) ? (a) : (b) )

#include <iostream>

#include "node.hh"

// Default constructor.
Node::Node( const Position& pos )
    : m_endNode( false ), m_startNode( false ), m_distanceFromStart(0),
      m_position(pos), m_shortestPathPredecessor(NULL)
{
}

// Destructor.
Node::~Node()
{
    // do not destruct anything, because we only have pointers
    // to real existing objects
    m_shortestPathPredecessor = NULL;
}

// Set a neighbor and it's distance for this node.
bool Node::setNeighborAndDistance( const BaseEnumDirection view,
                                   Node* newNeighbor,
                                   const int distance )
{
    //std::cout << "Node::setNeighborAndWeight(view,Node*,int) "
              //<< " Info:"
              //<< " " << this
              //<< " " << newNeighbor
              //<< " View: " << view
              //<< " Weight: " << weight
              //<< std::endl;

    bool ok = false;

    // convert view to value for array access
    const int value = convertViewToInt( view );
    
    if ( 0 <= value && value < 4 )
    {
        m_edge[value].setNeighborAndDistance( newNeighbor, distance );
        ok = true;
    }
    return ok;    
}

// Get the neighbor in a direction.
Node* Node::getNeighbor( const BaseEnumDirection view ) const
{
    Node *neighbor = NULL;

    // convert view to value for array access
    const int value = convertViewToInt( view );
    if ( 0 <= value && value < 4 )
    {
        neighbor = m_edge[value].getNeighbor();
    }

    return neighbor;    
}

// Get the distance in a direction (makes only sense if neighbor != NULL)
int Node::getDistance( const BaseEnumDirection view ) const
{
    unsigned int weight = 0;

    // convert view to value for array access
    const int value = convertViewToInt( view );
    if ( 0 <= value && value < 4 )
    {
        weight = m_edge[value].getDistance();
    }

    return weight;    
}

// Get the edge state in a direction (makes only sense if neighbor != NULL).
EdgeState Node::getEdgeState( const BaseEnumDirection view ) const
{
    EdgeState state = EDGE_STATE_NONE;

    // convert view to value for array access
    const int value = convertViewToInt( view );
    if ( 0 <= value && value < 4 )
    {
        state = m_edge[value].getState();
    }

    return state; 
}

// Set next edge state in a direction.
bool Node::setEdgeState( const BaseEnumDirection view,
                         const EdgeState state )
{
    bool ok = false;

    // convert view to value for array access
    const int value = convertViewToInt( view );
    if ( 0 <= value && value < 4 )
    {
        //std::cout << "Node::setEdgeState(view,state) "
                  //<< " Info: "
                  //<< " " << this
                  //<< " View: " << view
                  //<< " State: " << m_edge[value].getState()
                  //<< " -> " << state
                  //<< " Neighbor: " << m_edge[value].getNeighbor()
                  //<< std::endl;

        m_edge[value].setState( state );
        
        // if we have the edge state shortest we should mark this
        // node as predeccessor of the neighbor.
        if ( EDGE_STATE_SHORTEST == state )
        {
            Node *neighbor = m_edge[value].getNeighbor();
            if ( NULL != neighbor )
            {
                if ( neighbor->setShortestPathPredecessor( this ) )
                {
                    ok = true;
                }
            }
            else
            {
                std::cerr << "Node::setEdgeState(view,state) "
                          << " Error: State set but neighbor is NULL!"
                          << std::endl;
            }
        }
        else
        {
            ok = true;
        }
    }
    
    return ok;
}

// Check each neighbor and return the direction if it matches
// the given node.
BaseEnumDirection Node::hasNeighbor( const Node* node ) const
{
    BaseEnumDirection view = BE_DIRECTION_NONE;

    if ( NULL != node )
    {
        if ( node == m_edge[0].getNeighbor() )
        {
            view = BE_DIRECTION_LEFT;
        }
        else if ( node == m_edge[1].getNeighbor() )
        {
            view = BE_DIRECTION_RIGHT;
        }
        else if ( node == m_edge[2].getNeighbor() )
        {
            view = BE_DIRECTION_UP;
        }
        else if ( node == m_edge[3].getNeighbor() )
        {
            view = BE_DIRECTION_DOWN;
        }
    }
    else
    {
        std::cerr << "Node::hasNeighbor "
                  << " Error: Node is NULL!"
                  << std::endl;
    }

    return view;    
}


// Convert view to integer value for array access.
// Return -1 if not valid.
int Node::convertViewToInt( const BaseEnumDirection view ) const
{
    int value = -1;
    
    switch ( view )
    {
        case BE_DIRECTION_LEFT:
            value = 0;
            break;
        case BE_DIRECTION_RIGHT:
            value = 1;
            break;
        case BE_DIRECTION_UP:
            value = 2;
            break;
        case BE_DIRECTION_DOWN:
            value = 3;
            break;
        default:
            std::cerr << "Node::convertViewToInt(view) "
                      << " Error: Unknown case "
                      << view
                      << " in switch."
                      << std::endl;
            break;
    }
    return value;
}

// Set predecessor node in shortest path.
bool Node::setShortestPathPredecessor( Node* pred )
{
    if ( NULL == pred )
    {
        std::cerr << "Node::setShortestPathPredecessor "
                  << " Error: Predecessor should not be NULL!"
                  << std::endl;
    }
    m_shortestPathPredecessor = pred;
    
    return ( NULL != m_shortestPathPredecessor );
}

// Set this node as new predecessor in shortest path for the
// neighbor node in direction view.
// Return true if everything is okay.
bool Node::setShortestPathPredecessorNeighbor( const BaseEnumDirection view )
{
    bool ok = false;
    
    // get neighbor node in this direction
    Node *neighbor = getNeighbor( view );

    //std::cout << "Node::setShortestPathPredecessorNeighbor(view) "
              //<< " " << this
              //<< " View: " << view
              //<< " " << neighbor
              //<< std::endl;
    
    if ( NULL != neighbor )
    {
        // suppose everything is ok
        ok = true;

        Node *pred = neighbor->getShortestPathPredecessor();
        if ( NULL != pred )
        {
            // get view direction for this predecessor
            const BaseEnumDirection view2 = pred->hasNeighbor( neighbor );

            if ( BE_DIRECTION_NONE != view2 )
            {
                // mark edge as normal and not shortest anymore
                if ( !pred->setEdgeState( view2, EDGE_STATE_NORMAL ) )
                {
                    ok = false;
                }
            }
            else
            {
                std::cerr << "Node::setShortestPathPredecessorNeighbor(view) "
                          << " Error: Neighbor "
                          << neighbor
                          << " from predecessor "
                          << pred
                          << " not found."
                          << std::endl;
                ok = false;
            }
        }
        
        if ( ok )
        {
            ok = false;
            
            // set new predecessor for neighbor node
            if ( neighbor->setShortestPathPredecessor( this ) )
            {
                // mark this edge as shortest to neighbor
                if ( setEdgeState( view, EDGE_STATE_SHORTEST ) )
                {
                    ok = true;
                }
            }
        }
    }
    else
    {
        std::cerr << "Node::setShortestPathPredecessorNeighbor(view) "
                  << " Error: Neighbor from node "
                  << this
                  << " is NULL: "
                  << view
                  << "."
                  << std::endl;
        ok = false;
    }

    return ok;
}

// Isolate a node and connect the left and right neighbors.
// Return true if everything is okay.
bool Node::isolateNodeLeftRight()
{
    bool ok = true;

    // get neighbors
    Node *leftNeighbor = getNeighbor( BE_DIRECTION_LEFT );
    Node *rightNeighbor = getNeighbor( BE_DIRECTION_RIGHT );
        
    if ( ok && ( NULL != leftNeighbor ) )
    {
        const int rightDist = leftNeighbor->getDistance( BE_DIRECTION_RIGHT );
        const int leftDist = getDistance( BE_DIRECTION_RIGHT );
        ok = leftNeighbor->setNeighborAndDistance( BE_DIRECTION_RIGHT,
                                                   rightNeighbor,
                                                   MAX(rightDist,leftDist) );
    }
        
    if ( ok && ( NULL != rightNeighbor ) )
    {
        const int rightDist = getDistance( BE_DIRECTION_LEFT );
        const int leftDist = rightNeighbor->getDistance( BE_DIRECTION_LEFT );
        ok = rightNeighbor->setNeighborAndDistance( BE_DIRECTION_LEFT,
                                                    leftNeighbor,
                                                    MAX(rightDist,leftDist) );
    }

    if ( ok )
    {
        ok = setNeighborAndDistance( BE_DIRECTION_RIGHT, NULL, 0 ) &&
             setNeighborAndDistance( BE_DIRECTION_LEFT, NULL, 0 );
    }

    return ok;
}

// Isolate a node and connect the up and down neighbors.
// Return true if everything is okay.
bool Node::isolateNodeUpDown()
{
     bool ok = true;

    // get neighbors neighbors
    Node *upNeighbor = getNeighbor( BE_DIRECTION_UP );
    Node *downNeighbor = getNeighbor( BE_DIRECTION_DOWN );
        
    if ( ok && ( NULL != upNeighbor ) )
    {
        const int downDist = upNeighbor->getDistance( BE_DIRECTION_DOWN );
        const int upDist = getDistance( BE_DIRECTION_DOWN );
        ok = upNeighbor->setNeighborAndDistance( BE_DIRECTION_DOWN,
                                                 downNeighbor,
                                                 MAX(downDist,upDist) );
    }

    if ( ok && ( NULL != downNeighbor ) )
    {
        const int downDist = getDistance( BE_DIRECTION_UP );
        const int upDist = downNeighbor->getDistance( BE_DIRECTION_UP );
        ok = downNeighbor->setNeighborAndDistance( BE_DIRECTION_UP,
                                                   upNeighbor,
                                                   MAX(downDist,upDist) );
    }

    if ( ok )
    {
        ok = setNeighborAndDistance( BE_DIRECTION_DOWN, NULL, 0 ) &&
             setNeighborAndDistance( BE_DIRECTION_UP, NULL, 0 );
    }
    
    return ok;
}
