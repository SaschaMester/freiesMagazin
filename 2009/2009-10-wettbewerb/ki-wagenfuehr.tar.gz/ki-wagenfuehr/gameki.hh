// *************************************************************************
// robots-ki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef GAMEKI_HH
#define GAMEKI_HH

#include <string>

#include "game.hh"
#include "cardpermutation.hh"
#include "baseenums.hh"
#include "tileenums.hh"
#include "stats.hh"
#include "dijkstra.hh"

// KI for game
class GameKI : public Game
{
public:
    // enum for different error states
    enum GameKiEnumError
    {
        GK_ERROR_NONE              = 0,
        GK_ERROR_FILE_NOT_LOADED   = 1,
        GK_ERROR_FILE_NOT_SAVED    = 2,
        GK_ERROR_BOARD_NOT_VALID   = 3,
        GK_ERROR_NO_DECK_FOUND     = 4,
        GK_ERROR_NUMBER_OF_CARDS   = 5,
        GK_ERROR_LEVEL_NOT_CORRECT = 6
    };

    // Constructor.
    // Load all files.
    GameKI ();

    // Destructor.
    ~GameKI();

    // return error value
    const GameKiEnumError getError() const
    {
        return m_error;
    }

    // return if not error
    bool hasNoError() const
    {
        return ( GK_ERROR_NONE == m_error );
    }

    // Create all possibilities and save best to disk.
    // return true if everything is okay
    bool chooseAndSaveBestDeck( const std::string& deckname );

    // generate sequence for GUI from cards
    // and save it to disk
    bool generateAndStoreSequence( const CardDeck& choosenCards );

    // Same as before but with another robot.
    bool generateAndStoreSequence( const CardDeck& choosenCards, Bot& bot ) const
    {
        return Game::generateAndStoreSequence( choosenCards, bot );
    }

private:

    // enum with different weights for 
    enum GameKiEnumWeight
    {
        GK_WEIGHT_DESTROYED     = -800,
        GK_WEIGHT_FINISH        = 1000,
        GK_WEIGHT_CORRECT_PATH  = 50,
        GK_WEIGHT_STUCK         = -30,
        GK_WEIGHT_POSITION      = 3,
        GK_WEIGHT_POSITION_DIST = -4
    };

    //////////////
    // Methods
    //////////////
    
    // Choose best deck from cards.
    // return true if everything is okay
    bool chooseBestDeck( CardDeck& deck, const bool negative = false ) const;

    // Return points for the position of the bot on the game board.
    // Negative is bad, positive is good.
    int getChoicePoints( const Bot& bot, const bool negative ) const;

    // return number of points for robot position
    int getChoicePointsFromRobotPosition( const Bot& bot ) const;

    // return number of points for tile robot stands on
    // if this is a conveyor belt
    int getChoicePointsFromTileTypeConveyorBelt( const Bot& bot ) const;

    // return l1 norm of two positions
    static unsigned int L1norm( const Position& pos1, const Position& pos2 );

    ///////////////
    // Members
    ///////////////

    // Permutation for card deck.
    CardPermutation m_permutation;

    // Position on game board for finish.
    Position m_finishPos;

    // Error value during construction.
    GameKiEnumError m_error;

    // Statistics file.
    Stats m_stats;
    
    // Shortest path of dijkstra algorithm.
    PositionVector m_shortestPath;
};

#endif
