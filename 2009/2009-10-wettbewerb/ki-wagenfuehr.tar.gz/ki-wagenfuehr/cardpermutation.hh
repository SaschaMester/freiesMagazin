// *************************************************************************
// robots-ki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Dominik Wagenfuehr <dominik.wagenfuehr@deesaster.org>
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef CARDPERMUTATION_HH
#define CARDPERMUTATION_HH

#include <vector>

#include "carddeck.hh"

typedef std::vector<unsigned int> UIntArray;
typedef std::vector<UIntArray> UIntArrayArray;
typedef std::vector<UIntArrayArray> UIntArrayArrayArray;

class CardPermutation
{
public:
    // Default constructor.
    CardPermutation();

    // Constructor.
    // Generate all combinations choosing
    // numCards out of the card deck and permute them.
    CardPermutation( const CardDeck& m_deck,
                     const unsigned int numCards );

    // Destructor.
    ~CardPermutation();

    // Generate all combinations choosing
    // numCards out of the card deck and permute them.
    const bool create( const CardDeck& deck,
                       const unsigned int numCards );

    // Return number of possibilities for choosing m out of n cards.
    const unsigned long getNumMOutOfN() const
    {
        return m_numOut;
    }

    // Return number of permutations on m.
    const unsigned long getNumPermutations() const
    {
        return m_numSigma;
    }

    // Get deck from permutation.
    // return true if everything is okay
    const bool getPermutatedDeck( CardDeck& deck,
                                  const unsigned long ii,
                                  const unsigned long jj ) const;

    // Print all permutations.
    void print() const;

private:

    //////////////
    // Methods
    //////////////

    // Clear all.
    void clear();

    ////////////////////
    // Static Methods
    ////////////////////

    // calculate factorial
    static const unsigned long factorial( const unsigned int number,
                                          const unsigned int start = 0 );

    // calculate binomial coefficient
    static const unsigned long binomial( const unsigned int numerator,
                                         const unsigned int denominator );

    // return true if numBits are set in bitmask between 0 and maxBit
    static const bool bitsSet( const unsigned long bitMask,
                               const unsigned int numBits,
                               const unsigned int maxBits );

    // get those integers in an array that bits are set in the bitMask.
    // The number of set bits must equal the size of the array.
    // return true if everything is okay
    static const bool getIntegersFromBitMask( UIntArray& array,
                                              const unsigned long bitMask,
                                              const unsigned int maxBits );

    // get all combinations for m out of n integers
    // return true if everything is okay
    static const bool getMOutOfNInts( UIntArrayArray& array,
                                      unsigned long& num,
                                      const unsigned int n,
                                      const unsigned int m );

    // calculate number of perumtations for m integers
    // and array with base array to permute
    // return true if everything is okay
    static const bool getNumPermutations( UIntArray& array,
                                          unsigned long& num,
                                          const unsigned int m );

    // calculate all permutations
    static const bool calculatePermutations(
                                UIntArrayArrayArray& permutation,
                                const UIntArrayArray& basePermutations,
                                UIntArray& numbers,
                                const unsigned long numOut,
                                const unsigned long numSigma,
                                const unsigned int numCards );

    ///////////////
    // Members
    ///////////////

    // pointer to given card deck
    const CardDeck* m_deck;

    // This holds all combinations for getting
    // m cards out of n.
    UIntArrayArrayArray m_permutation;

    // Number of possibilities for choosing m out of n cards.
    unsigned long m_numOut;

    // Number of permutations on m.
    unsigned long m_numSigma;
};

#endif // CARDPERMUTATION_HH
