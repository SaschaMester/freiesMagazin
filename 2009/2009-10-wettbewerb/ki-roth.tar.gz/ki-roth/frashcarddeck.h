// *************************************************************************
// frashbotki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Frank Roth <frank.roth.de@googlemail.com
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef FRASHCARDDECK_H_
#define FRASHCARDDECK_H_

#include <vector>
#include <iostream>
#include <cstdlib>

#include "carddeck.hh"




class FrashCardDeck : public CardDeck
{
public:
	// constructor	
	FrashCardDeck();
	// destructor
	virtual ~FrashCardDeck();

    // Copy constructor.
    FrashCardDeck( const FrashCardDeck& deck );


    // Assigment operator.
    const FrashCardDeck& operator=( const FrashCardDeck& deck );

    // access card element
    BaseCard* operator[] ( const unsigned int index ) const;

    const unsigned int size() const
    {
        return m_deck.size();
    }

    // clear all elements (delete pointers)
    // but do not change the size!
    void clear();

    // clear all elements (delete pointers)
    // and deletes the allocated memory for the deck
    // set size to (0,0)
    void clearAll();

    // set new size for game board
    // all elements will be deleted!
    // return true if memory could be allocated
    void resize( const unsigned int newSize );

	const bool save( const std::string& filename ) const;

    // deck of cards
    std::vector <BaseCard*> m_deck;
};

#endif /* FRASHCARDDECK_H_ */
