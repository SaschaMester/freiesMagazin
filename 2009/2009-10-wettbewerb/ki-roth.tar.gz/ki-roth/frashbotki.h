// *************************************************************************
// frashbotki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Frank Roth <frank.roth.de@googlemail.com
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef FRASHBOT_H_
#define FRASHBOT_H_

#include <iostream>
#include <string>
#include <queue>
#include <vector>
#include <algorithm>
#include <string>

#include "carddeck.hh"
#include "basefunctions.hh"
#include "gameboard.hh"
#include "bot.hh"
#include "frashgame.h"
#include "frashcarddeck.h"


// Path between old and new postion + direction
struct Path{
	Position from, to;
	BaseEnumDirection move;
};


// my implementation of a KI
class FrashBotKI {
public:
	// constructor
	FrashBotKI();
	// constructor for preloaded board, bot and carddeck
	FrashBotKI(const GameBoard& board, const Bot& bot, const CardDeck& deck);
	// virtual destructor
	virtual ~FrashBotKI();

	// run the FrashBot-KI
	void selectCards(FrashCardDeck& deck);
	// set a new bot
	void setBot(const Bot& bot);
	// set a new gameboard
	void setGameBoard(const GameBoard& board);
	// set a new carddeck
	void setCardDeck(const CardDeck& deck);

	// save pathmap for debugging
	const bool savePathMap(const std::string filename);
protected:
	// creates a map with values of length of path to the goal for each tile
	void createPathMap(void);
	// checks if path is possible and saves values to pathmap 
	void checkPath(const Path path);
	// gets a value from pathmap NOT_CHECKED if not in boundaries
	int getPathMapPos(const Position pos) const;
	// sets a pos in pathmap with value
	void setPathMapPos(const Position pos, const int value);
	// permutation over all card combinations
	void probeCards(FrashCardDeck& deck);

	// saves bot
	Bot m_Bot;
	// saves gameboard
	GameBoard m_Board;
	// saves carddeck
	CardDeck m_Deck;

	// map with bestpath
	int* m_PathMap;
	// size of map (width, height)
	unsigned int m_mapX, m_mapY;
	// for smart pathmap generation
	std::queue<Path*> m_pathQueue;
	// const for a not checked oder not valid positions
	static const int NOT_CHECKED = -1;
};

#endif /* FRASHBOT_H_ */
