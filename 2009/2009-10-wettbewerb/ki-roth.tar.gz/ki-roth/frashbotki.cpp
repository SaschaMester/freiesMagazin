// *************************************************************************
// frashbotki - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Frank Roth <frank.roth.de@googlemail.com
// Licence: GPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "frashbotki.h"

// constructor
FrashBotKI::FrashBotKI()
{
	m_PathMap = 0;
	m_mapX = m_mapY = 0;
}

// constructor for preloaded board, bot and carddeck
FrashBotKI::FrashBotKI(const GameBoard& board, const Bot& bot, const CardDeck& deck)
{
	m_Board = board;
	m_Bot = bot;
	m_Deck = deck;

	m_mapX = m_Board.getWidth();
	m_mapY = m_Board.getHeight();

	m_PathMap = new int[m_mapX*m_mapY];

}

// virtual destructor
FrashBotKI::~FrashBotKI() {
	delete m_PathMap;
}

// run the FrashBot-KI
void FrashBotKI::selectCards(FrashCardDeck& deck)
{
	createPathMap();
//	savePathMap("pathmap.txt");
	probeCards(deck);
}

// set a new bot
void FrashBotKI::setBot(const Bot& bot)
{
	m_Bot = bot;
}

// set a new gameboard
void FrashBotKI::setGameBoard(const GameBoard& board)
{
	m_Board = board;

	m_mapX = m_Board.getWidth();
	m_mapY = m_Board.getHeight();


	delete[] m_PathMap;
	m_PathMap = new int[m_mapX*m_mapY];

}

// set a new carddeck
void FrashBotKI::setCardDeck(const CardDeck& deck)
{
	m_Deck = deck;
}

// creates a map with values of length of path to the goal for each tile
void FrashBotKI::createPathMap(void)
{

	// init complete pathmap to NOT_CHECKED
	for(unsigned int i=0; i < m_mapX*m_mapY; i++)
	{
		m_PathMap[i] = NOT_CHECKED;
	}
	
	// saves endPosition of Bot
	Position endPos(m_Board.getEndPos());

	// pointer to path structs
	Path *nextPath;

	// new path struct for all 4 directions
	nextPath = new Path;
	nextPath->from.set(endPos.x()+1,endPos.y());
	nextPath->to = endPos;
	nextPath->move = BE_DIRECTION_LEFT;
	// push to a path queue
	m_pathQueue.push(nextPath);

	nextPath = new Path;
	nextPath->from.set(endPos.x()-1,endPos.y());
	nextPath->to = endPos;
	nextPath->move = BE_DIRECTION_RIGHT;
	// push to a path queue
	m_pathQueue.push(nextPath);

	nextPath = new Path;
	nextPath->from.set(endPos.x(),endPos.y()+1);
	nextPath->to = endPos;
	nextPath->move = BE_DIRECTION_UP;
	// push to a path queue
	m_pathQueue.push(nextPath);

	nextPath = new Path;
	nextPath->from.set(endPos.x(),endPos.y()-1);
	nextPath->to = endPos;
	nextPath->move = BE_DIRECTION_DOWN;
	// push to a path queue
	m_pathQueue.push(nextPath);

	// endPos gets value 0
	setPathMapPos(endPos,0);

//	std::cout << "FrashBot::createPathMap::pathqueue size:" << std::endl;

	// process the complete pathqueue
	while(!m_pathQueue.empty())
	{
		// check if path possible, how much it will cost
		checkPath(*m_pathQueue.front());
		// std::cout << m_pathQueue.size() << std::endl;

		// free memory and processed paths
		delete m_pathQueue.front();
		m_pathQueue.pop();
	}
}

// checks if path is possible and saves values to pathmap 
void FrashBotKI::checkPath(const Path path)
{
	// in boundaries?
	if(path.from.x() < 0) return;
	if(path.from.y() < 0) return;
	if(path.from.x() > m_Board.getWidth()-1) return;
	if(path.from.y() > m_Board.getHeight()-1) return;

	if(path.to.x() < 0) return;
	if(path.to.y() < 0) return;
	if(path.to.x() > m_Board.getWidth()-1) return;
	if(path.to.y() > m_Board.getHeight()-1) return;
	
	// already checked?
	if(getPathMapPos(path.from) != NOT_CHECKED) return;

	const BaseTile* tile;
	tile = m_Board[path.from];

	// std::cout << "Tile:" << std::endl;
	// tile->print();

	// check it it is an possible path
	if((m_Board[path.to]->canEnter(path.move))
			&& (tile->canLeave(path.move))
			&& (!tile->isType(TE_TYPE_HOLE)))
	{
		Path *nextPath;
		
		// generates new paths for 4 directions, push them to the pathqueue
		nextPath = new Path;
		nextPath->from.set(path.from.x()+1,path.from.y());
		nextPath->to = path.from;
		nextPath->move = BE_DIRECTION_LEFT;
		m_pathQueue.push(nextPath);

		nextPath = new Path;
		nextPath->from.set(path.from.x()-1,path.from.y());
		nextPath->to = path.from;
		nextPath->move = BE_DIRECTION_RIGHT;
		m_pathQueue.push(nextPath);

		nextPath = new Path;
		nextPath->from.set(path.from.x(),path.from.y()+1);
		nextPath->to = path.from;
		nextPath->move = BE_DIRECTION_UP;
		m_pathQueue.push(nextPath);

		nextPath = new Path;
		nextPath->from.set(path.from.x(),path.from.y()-1);
		nextPath->to = path.from;
		nextPath->move = BE_DIRECTION_DOWN;
		m_pathQueue.push(nextPath);

		// moving against conveyer cost 1/3 more
		if(tile->isType(TE_TYPE_CONVEYOR_BELT))
		{

			if(    ((tile->getMoveDir() == TM_MOVE_DOWN) && (path.move == BE_DIRECTION_UP))
				|| ((tile->getMoveDir() == TM_MOVE_UP) && (path.move == BE_DIRECTION_DOWN))
				|| ((tile->getMoveDir() == TM_MOVE_RIGHT) && (path.move == BE_DIRECTION_LEFT))
				|| ((tile->getMoveDir() == TM_MOVE_LEFT) && (path.move == BE_DIRECTION_RIGHT)))
			{
				setPathMapPos(path.from,getPathMapPos(path.to)+3);
			} else setPathMapPos(path.from,getPathMapPos(path.to)+2);
		} else setPathMapPos(path.from,getPathMapPos(path.to)+2);
	} else setPathMapPos(path.from,NOT_CHECKED);

	/*
	else if(tile->isType(TE_TYPE_HOLE))
	{
		setPathMapPos(path.from,NOT_CHECKED);
	} else	setPathMapPos(path.from,getPathMapPos(path.to)+1);
	*/
}

// gets a value from pathmap NOT_CHECKED if not in boundaries
int FrashBotKI::getPathMapPos(const Position pos) const
{
	// if it is a valid position
	if(	   (pos.x() >= 0)
		&& (pos.y() >= 0)
		&& (pos.x() < m_mapX)
		&& (pos.y() < m_mapY))
	{
		return m_PathMap[pos.x()+pos.y()*m_mapX];
	} // not in bounds
	else return NOT_CHECKED;
}

// sets a pos in pathmap with value
void FrashBotKI::setPathMapPos(const Position pos, const int value)
{
	m_PathMap[pos.x()+pos.y()*m_mapX] = value;
}

// save pathmap for debugging
const bool FrashBotKI::savePathMap(const std::string filename)
{
    bool ok = false;

    if ( !filename.empty() )
    {
        std::ofstream outFile;

        outFile.open( filename.c_str(), std::ios::out );

        if ( outFile.good() )
        {
        	for(unsigned int y = 0; y < m_mapY; y++)
        	{
        		for(unsigned int x = 0; x < m_mapX; x++)
        		{
        	        outFile << m_PathMap[x+y*m_mapX] << "  ";

        		}

        		outFile << std::endl;
        	}

        	outFile << std::endl;
        	outFile.close();

        	ok = true;
        }
        else
        {
            std::cerr << "FrashBot::savePathMap(string) "
                      << "Error: File "
                      << filename.c_str()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "FrashBot::savePathMap(string) "
                  << "Error: Filename is empty."
                  << std::endl;
    }
    return ok;
}

// permutation over all card combinations
void FrashBotKI::probeCards(FrashCardDeck& deck)
{
	// a card combination
	std::vector<BaseCard*> bcVect;
	// best found card combination
	std::vector<BaseCard*> bestVect;
	// minimal cost with a card combination
	int minCost = NOT_CHECKED;
	// virtual cost, if the other 3 cards would be played
	int costV = NOT_CHECKED;
//	if there is the possibility to finish with this cards
	int minSteps = NOT_CHECKED;

	bool nextPermut = false;
//	bool usedDefault = true;

	// clone complete carddeck
	for(int i = 0; i < 8; i++)
	{
		bcVect.push_back(m_Deck[i]);
	}

	// game object for move sequence simulation
	FrashGame frashGame(m_Board,m_Bot);
	
	// pre-sort bcVect (for correct work of permutation )
	std::sort(bcVect.begin(),bcVect.end());

	// if there isn't any solution, the first combination is the choice
	bestVect.assign(bcVect.begin(), bcVect.end());

	// traverse all permutations
	while (std::next_permutation(bcVect.begin(), bcVect.end()) )
	{
		// reset bot
		Bot xBot(m_Bot.getPos(),m_Bot.getViewDirection());
		frashGame.setBot(xBot);
		
		// create a CardDeck for current permutation
		FrashCardDeck choosenCards;
		choosenCards.m_deck.assign(bcVect.begin(), bcVect.end());

		nextPermut = false;

		// move the first 5 steps
		for (unsigned int ii = 0; ii < 5; ii++ )
		{

			// get movement for this card
			Sequence startSeq;
			choosenCards[ii]->getSequence( startSeq );

			// now we must transform this movement to the game board
			// and the robot

			Sequence endSeq;

			frashGame.generateSequenceAndMoveRobot( endSeq, startSeq, xBot, false );

			// don't use move, if bot would be destroyed
			if(xBot.isDestroyed())
			{
				// std::cout << "isDestroyed " << minCost << " " << minSteps << std::endl;
				nextPermut = true;
				break;
			}
			// if there is a finish move with less equal 5 steps
			else if(xBot.isFinished())
			{
				if(minSteps == NOT_CHECKED)
				{
					minSteps = ii + 1;
//					std::cout << "isFinishedfist "<< minCost << " " << minSteps << std::endl;
					bestVect.assign(bcVect.begin(), bcVect.end());
//					usedDefault = false;
				}
				else if(int(ii+1) < minSteps)
				{
					minSteps = ii + 1;
//					std::cout << "isFinishedless " << minCost << " " << minSteps << std::endl;
					bestVect.assign(bcVect.begin(), bcVect.end());
//					usedDefault = false;
				}
				nextPermut = true;
				break;
			} // possible move

		}

		// the first 5 steps are done, NO finish move yet
		if((!nextPermut) && (minSteps == NOT_CHECKED))
		{
			// get path costs for carddeck
			int cost = getPathMapPos(xBot.getPos());
			// is possible path
			if(cost != NOT_CHECKED)
			{
				// found a possible path already
				if(minCost != NOT_CHECKED)
				{
					// path costs less then founded paths before
					if(cost < minCost)
					{
						minCost = cost;
						costV = minCost;
//						std::cout << "lesscost " << minCost << " " << costV << std::endl;
						bestVect.assign(bcVect.begin(), bcVect.end());
//						usedDefault = false;
					}
					// costs are the same as other card combinations before
					else if (cost == minCost)
					{
						// play the game virtual 3 cards further
						for(int j = 5; j < 8; j++)
						{

							// get movement for this card
							Sequence startVSeq;
							choosenCards[j]->getSequence( startVSeq );

							Sequence endVSeq;

							frashGame.generateSequenceAndMoveRobot( endVSeq, startVSeq, xBot, false );

							int costtmp = getPathMapPos(xBot.getPos());

							// next 3 cards found a possible way
							// bot isn't destroyed
							if((costtmp < costV)
								&& (costtmp != NOT_CHECKED)
								&& (!xBot.isDestroyed()))
							{

								costV = costtmp;
//								std::cout << "samecost " << minCost << " " << costV << std::endl;
								bestVect.assign(bcVect.begin(), bcVect.end());
//								usedDefault = false;
							}

						}
					}
				}
				else  // take the found path as first one
				{
					minCost = cost;
//					std::cout << "firstpath " << minCost << " " << minSteps << std::endl;

					bestVect.assign(bcVect.begin(), bcVect.end());
//					usedDefault = false;
				}
			}
		}
	}

//	std::cout << "Select " << minCost << " " << minSteps << std::endl;
//	std::cout << "UsedDefaults" << usedDefault << std::endl;

	bestVect.resize(5);
	deck.m_deck.assign(bestVect.begin(),bestVect.end());

}



