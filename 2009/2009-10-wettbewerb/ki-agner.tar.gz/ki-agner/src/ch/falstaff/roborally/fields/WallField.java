/**
 *
 * Created at 09.11.2009 by Stefan Agner
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package ch.falstaff.roborally.fields;

import ch.falstaff.roborally.GameBoard;

/**
 * This represents a field with walls. Also used for Pusher fields and others.
 * @author sag
 *
 */
public class WallField extends EmptyField {
	protected char type;
	public WallField(char type, GameBoard gameboard, int x, int y)
	{
		super(gameboard, x, y);
		this.type = type;
	}
	
	@Override
	/**
	 * Check if the field is driveable from direction "from".
	 */
	public boolean drivable(int from) {
		byte walls = (byte)(type - 'a');
		if(from == 0) // oben
			return (walls & 4)==0;
		if(from == 1) // rechts
			return (walls & 2)==0;
		if(from == 2) // unten
			return (walls & 8)==0;
		if(from == 3) // links
			return (walls & 1)==0;
		return true;
	}

	@Override
	/**
	 * Look if a field is leavable in direction "to".
	 */
	public boolean leaveable(int direction) {
		byte walls = (byte)(type - 'a');
		// Prüfe eigenes Feld...
		if(direction == 0 && (walls & 4) > 0) // oben
			return false;
		if(direction == 1 && (walls & 2) > 0) // rechts
			return false;
		if(direction == 2 && (walls & 8) > 0) // unten
			return false;
		if(direction == 3 && (walls & 1) > 0) // links
			return false;
		
		return true;
	}
}
