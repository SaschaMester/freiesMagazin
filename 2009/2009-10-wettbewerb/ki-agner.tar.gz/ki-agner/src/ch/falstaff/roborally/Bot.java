/**
 *
 * Created at 09.11.2009 by Stefan Agner
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package ch.falstaff.roborally;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import ch.falstaff.roborally.cards.Card;
import ch.falstaff.roborally.cards.MoveCard;
import ch.falstaff.roborally.cards.TurnCard;
import ch.falstaff.roborally.fields.ConveyorField;
import ch.falstaff.roborally.fields.Field;
import ch.falstaff.roborally.fields.PusherField;
import ch.falstaff.roborally.fields.RotatingWheelField;

/**
 * Class which represents the bot. It saves the state of the bot, so its cloneable and 
 * you can test some cards on it.
 * @author sag
 *
 */
public class Bot {
	public int xpos;
	public int ypos;
	public int direction; // 0 = up, 1 = rechts, 2 = down, 3 = links
	public boolean dead;
	private GameBoard gb;
	
	/**
	 * Creates a new bot with positions from parameters
	 */
	private Bot(int xpos, int ypos, int direction, GameBoard gb)
	{	
		this.xpos = xpos;
		this.ypos = ypos;
		this.direction = direction;
		this.dead = false;
		this.gb = gb;
	}
	
	/**
	 * Creates a new bot with positions from a file 
	 */
	public static Bot createBot(String filename, GameBoard gb)
	{
		try {
			BufferedReader br = new BufferedReader(new FileReader(filename));
			String line = br.readLine(); 
			String[] botInfos = line.split(" ");
			int xpos = Integer.parseInt(botInfos[0]);
			int ypos = Integer.parseInt(botInfos[1]);
			char cdirection = botInfos[2].charAt(0);
			int direction = 0;
			switch(cdirection)
			{
				case 'U':
					direction = 0;
					break;
				case 'R':
					direction = 1;
					break;
				case 'D':
					direction = 2;
					break;
				case 'L':
					direction = 3;
					break;
				default:
					throw new Exception();
			}
			return new Bot(xpos, ypos, direction, gb);
		} catch (IndexOutOfBoundsException e) {
			System.err.println("Wrong format of bot file...");
			return null;
		} catch (FileNotFoundException e) {
			System.err.println("Bot file not found...");
			return null;
		} catch (IOException e) {
			System.err.println("Error while reading bot...");
			return null;
		} catch (Exception e) {
			System.err.println("Wrong format of bot file...");
			return null;
		}
	}
	

	/**
	 * Play a card with this bot on its gameboard...
	 * This contains the main game logic...
	 */
	public void doCard(Card c) throws BotDiedException
	{
		if(c.getClass().equals(MoveCard.class))
		{
			// We've got a move card...
			MoveCard mc = (MoveCard)c;
			
			// Calculate each single step...
			for(int i=0;i<Math.abs(mc.getCount());i++)
			{
				makeStep(mc.getCount()<0);
				
				// Start the passive action (OilField...)
				int direction = this.direction;
				if(mc.getCount()<0)
					direction += 2;
				direction %= 4;
				doPassiveActions(direction, 0);
			}
		}
		else if(c.getClass().equals(TurnCard.class))
		{
			// We've got a turn card...
			TurnCard tc = (TurnCard)c;
			turn(tc.getTurn());
			doPassiveActions(-1, tc.getTurn());
		}
		
		// Execute the elementary actions...
		executeActions();
	}
	
	/**
	 * Does passive actions as long as necessary
	 * @param momentum The last direction the bot was moved (-1 = no movement)
	 * @param turnmomentum Last turn momentum (positive = clockwise, nevativ = reverse clockwise, 0 = none) 
	 * @throws BotDiedException 
	 */
	private void doPassiveActions(int momentum, int turnmomentum) throws BotDiedException
	{
		Field f;
		do {
			f = gb.gameboard[xpos][ypos];
			f.passiveAction(this, momentum, turnmomentum);
		} while (!f.equals(gb.gameboard[xpos][ypos]));
	}
	
	/**
	 * Executes elementary actions according to documented order
	 * @throws BotDiedException
	 */
	private void executeActions() throws BotDiedException {
		Field f = gb.gameboard[xpos][ypos];
		
		if(f.getClass().equals(ConveyorField.class))
		{
			ConveyorField cf = (ConveyorField)f;
			f.doAction(this);
			
			// Execute passive Action on new field (if any, else it doesn't matter)
			doPassiveActions(cf.getConveyorDirection(), 0);
			f = gb.gameboard[xpos][ypos];
		}
		
		
		if(f.getClass().equals(PusherField.class))
		{
			PusherField pf = (PusherField)f;
			f.doAction(this);
			
			
			// Execute again the passive Action on new field
			doPassiveActions(pf.getPusherDirection(), 0);
			f = gb.gameboard[xpos][ypos];
		}
		
		
		if(f.getClass().equals(RotatingWheelField.class))
		{
			f.doAction(this);
			f = gb.gameboard[xpos][ypos];
		}
		
	}
	
	/**
	 * Bot should make a step. Does it allways in its current direction.
	 * @param backward If he should go backward, say true here
	 * @throws BotDiedException
	 */
	private void makeStep(boolean backward) throws BotDiedException
	{
		int direction = this.direction;
		if(backward)
			direction += 2;
		direction %= 4;
		Field f = gb.gameboard[xpos][ypos];
		
		// Only move the bot if the next field is accessible
		if(f.leaveable(direction) && gb.getNextFieldStepDriveable(direction, xpos, ypos))
		{
			moveBot(direction);
		}
	}
	
	/**
	 * Moves the bot in a specific direction.
	 * @param direction
	 * @throws BotDiedException
	 */
	public void moveBot(int direction) throws BotDiedException
	{
		// Do It!
		switch(direction)
		{
		case 0:
			ypos = ypos - 1;
			if(ypos<0)
			{
				if(Main.level == GameLevel.hard)
				{
					this.dead = true;
					throw new BotDiedException("Felt out of Gameboard at the upper border");
				}
				else
					ypos = 0;
			}
			break;
		case 1:
			xpos = xpos + 1;
			if(xpos>=gb.xsize)
			{
				if(Main.level == GameLevel.hard)
				{
					this.dead = true;
					throw new BotDiedException("Felt out of Gameboard at the right border");
				}
				else
					xpos = gb.xsize-1;
			}
			break;
		case 2:
			ypos = ypos + 1;
			if(ypos>=gb.ysize)
			{
				if(Main.level == GameLevel.hard)
				{
					this.dead = true;
					throw new BotDiedException("Felt out of Gameboard at the lower border");
				}
				else
					ypos = gb.ysize-1;
			}
			break;
		case 3:
			xpos = xpos - 1;
			if(xpos<0)
			{
				if(Main.level == GameLevel.hard)
				{
					this.dead = true;
					throw new BotDiedException("Felt out of Gameboard at the left border");
				}
				else
					xpos = 0;
			}
			break;
		}
	}
	
	
	public int getDirectionRaiting()
	{
		int raiting = 0;
		// Positive raiting if we look to the destination, negativ if we look away, and a field in that direction must be accessible...
		Field f = gb.gameboard[xpos][ypos];
		if(!f.leaveable(this.direction))
			return -2;
		else
		{
			if(!gb.getNextFieldStepDriveable(this.direction, xpos, ypos))
				return -2;
		}
		
		Field fnext = gb.getNextFieldStep(this.direction, xpos, ypos);
		if(fnext != null)
		{
			raiting = fnext.getRating() - f.getRating();  
		}
		else
		{
			if(Main.level.equals(GameLevel.hard))
				return -20;
		}
		
		if(f.getClass().equals(ConveyorField.class))
		{
			ConveyorField cf = (ConveyorField)f;
			raiting += cf.getDirectionRaiting();
		}
		return raiting;
	}

	public void turnRight()
	{
		direction++;
		direction %= 4;
	}
	public void turnLeft()
	{
		direction--;
		direction+=4; //Avoid -1, doesnt does what we want at modulo!
		direction %= 4;
	}
	
	public Bot clone()
	{
		return new Bot(xpos, ypos, direction, gb);
	}
	
	/**
	 * Saves the bot current position. API-style..
	 * @param filename
	 */
	public void save(String filename)
	{
		try {
			BufferedWriter br = new BufferedWriter(new FileWriter(filename));
			char direction = 'X';
			switch(this.direction)
			{
				case 0:
					direction = 'U';
					break;
				case 1:
					direction = 'R';
					break;
				case 2:
					direction = 'D';
					break;
				case 3:
					direction = 'L';
					break;
			}
			br.write(xpos + " " + ypos + " " + direction);
			br.close();
		} catch (IOException e) {
			System.out.println("Could not write bots new position: " + e.getMessage());
		}
	}

	public void turn(int turn) {
		direction += turn + 4;
		direction %= 4;
	}
	
}
