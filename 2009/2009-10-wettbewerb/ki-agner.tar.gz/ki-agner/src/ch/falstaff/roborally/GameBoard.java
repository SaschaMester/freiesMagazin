/**
 *
 * Created at 09.11.2009 by Stefan Agner
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package ch.falstaff.roborally;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import ch.falstaff.roborally.fields.Field;
import ch.falstaff.roborally.fields.GoalField;


public class GameBoard {
	public int xsize;
	public int ysize;
	public int goalx;
	public int goaly;
	public Field[][] gameboard;
	
	
	private GameBoard(String filename)
		throws IOException, FileNotFoundException
	{
		BufferedReader br = new BufferedReader(new FileReader(filename));
		String line = br.readLine();
		xsize = Integer.parseInt(line.split(" ")[0]);
		ysize = Integer.parseInt(line.split(" ")[1]);
		gameboard = new Field[xsize][ysize];
		
		int y = 0;
		int x = 0;
		while((line = br.readLine()) != null)
		{
			for(x=0;x<line.length();x++)
			{
				Field field = Field.createField(line.charAt(x), this, x, y);
				gameboard[x][y] = field;
				// Ziel gefunden? Aufschreiben...
				if(field.getClass().equals(GoalField.class))
				{
					goalx = x; 
					goaly = y;
				}
			}
			y++;
		}
		
		// Create Raiting according to distance to goal
		createRating(goalx, goaly, xsize*ysize);
		if(Main.DEBUG)
			printRaiting();
	}
	
	public void printRaiting()
	{
		for(int y = 0;y<ysize;y++)
		{
			for(int x = 0;x<xsize;x++)
			{
				System.out.print(gameboard[x][y].getRating() + "\t");
			}
			System.out.println();
		}
	}
	
	/*
	 * Load Gameboard from File...
	 */
	public static GameBoard createGameBoard(String filename)
	{
		try {
			return new GameBoard(filename);
		} catch (FileNotFoundException e) {
			System.err.println("Gameboard file not found...");
			return null;
		} catch (IOException e) {
			System.err.println("Error while reading gameboard...");
			return null;
		}
	}
	private void createRating(int fieldx, int fieldy, int rating)
	{
		Field f = gameboard[fieldx][fieldy];
		if(f.getRating()<rating)
			f.setRating(rating);
		
		Field fnext = null;
		rating--;
		/*
		// Set the rating in all 4 directions...
		for(int direction = 0; direction<4;direction++)
		{
			if(f.leaveable(direction) || f.getClass().equals(GoalField.class))
			{
				fnext = getNextFieldStep(direction, fieldx, fieldy);
				if(fnext != null)
				{
					int directionoposite = direction + 2;
					directionoposite %= 4;
					if(fnext.getRating() < rating && fnext.drivable(directionoposite))
						fnext.setRating(rating);
				}
			}
		}
		*/
		// Follow possible ways, if our rating is better than the existing...
		for(int direction = 0; direction<4;direction++)
		{
			if(f.leaveable(direction) || f.getClass().equals(GoalField.class))
			{
				fnext = getNextFieldStep(direction, fieldx, fieldy);
				if(fnext != null)
				{
					int directionoposite = direction + 2;
					directionoposite %= 4;
					// Only when its our rating (we overwrite longer ways up here, and don't should overwrite shorter ways...)
					if(fnext.getRating() < rating && fnext.drivable(directionoposite))
						createRating(fnext.x, fnext.y, rating);
				}
			}
		}
	}
	/*
	private void createRating(int fieldx, int fieldy, int rating)
	{
		Field f = gameboard[fieldx][fieldy];
		Field fnext = null;
		rating--;
		
		// Set the rating in all 4 directions...
		for(int direction = 0; direction<4;direction++)
		{
			if(f.leaveable(direction) || f.getClass().equals(GoalField.class))
			{
				fnext = getNextFieldStep(direction, fieldx, fieldy);
				if(fnext != null)
				{
					int directionoposite = direction + 2;
					directionoposite %= 4;
					if(fnext.getRating() < rating && fnext.drivable(directionoposite))
						fnext.setRating(rating);
				}
			}
		}
		
		// Follow possible ways, if its our rating...
		for(int direction = 0; direction<4;direction++)
		{
			if(f.leaveable(direction) || f.getClass().equals(GoalField.class))
			{
				fnext = getNextFieldStep(direction, fieldx, fieldy);
				if(fnext != null)
				{
					int directionoposite = direction + 2;
					directionoposite %= 4;
					// Only when its our rating (we overwrite longer ways up here, and don't should overwrite shorter ways...)
					if(fnext.getRating() == rating && fnext.drivable(directionoposite))
						createRating(fnext.x, fnext.y, rating);
				}
			}
		}
		
		

	}
*/
	/**
	 * Find out, if the next field, in given direction, is driveable 
	 * @param direction
	 * @param xpos
	 * @param ypos
	 * @return
	 */
	public boolean getNextFieldStepDriveable(int direction, int xpos, int ypos)
	{
		int directionoposite = direction + 2;
		directionoposite %= 4;
		Field f = getNextFieldStep(direction, xpos, ypos);
		if(f==null)
			return Main.level == GameLevel.hard;
		else
			return f.drivable(directionoposite);
			
	}
	
	/**
	 * Gets the next field in given direction
	 * @param direction
	 * @param xpos
	 * @param ypos
	 * @return Field or null if there is no field (border..)
	 */
	public Field getNextFieldStep(int direction, int xpos, int ypos)
	{
		if(direction == 0)
		{
			int tmpy = ypos-1;
			if(tmpy<0)
				return null;
			else
			{
				return gameboard[xpos][tmpy];
			}
		}
		if(direction == 1)
		{
			int tmpx = xpos+1;
			if(tmpx>=xsize)
				return null;
			else
				return gameboard[tmpx][ypos];
		}
		if(direction == 2)
		{
			int tmpy = ypos+1;
			if(tmpy>=ysize)
				return null;
			else
				return gameboard[xpos][tmpy];
		}
		if(direction == 3)
		{
			int tmpx = xpos-1;
			if(tmpx<0)
				return null;
			else
				return gameboard[tmpx][ypos];
		}
		return null;
		
	}
}
