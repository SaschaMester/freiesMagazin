/**
 *
 * Created at 09.11.2009 by Stefan Agner
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package ch.falstaff.roborally.fields;

import ch.falstaff.roborally.Bot;
import ch.falstaff.roborally.BotDiedException;
import ch.falstaff.roborally.GameBoard;
import ch.falstaff.roborally.GameLevel;
import ch.falstaff.roborally.Main;

/**
 * This class represents a conveyor field.
 * @author sag
 *
 */
public class ConveyorField extends EmptyField {
	private char type;
	
	public ConveyorField(char type, GameBoard gameboard, int x, int y)
	{
		super(gameboard, x, y);
		this.type = type;
	}
	
	/**
	 * Get the rating for the direction which this field moves you..
	 * @return a direction
	 */
	public int getDirectionRaiting()
	{
		int raiting = 0;
		Field f = gameboard.getNextFieldStep(getConveyorDirection(), x, y);
		if(f != null)
		{
			int direction = getConveyorDirection();
			direction %= 4;
			if(f.drivable(direction))
			{
				if(getRating() < f.getRating())
					raiting++;
				else
					raiting--;
			}
		}
		else
		{
			if(Main.level.equals(GameLevel.hard))
				raiting -= 20;
		}
		return raiting;
	}
	
	
	/**
	 * Gets the direction which this conveyor will move the bot.
	 * @return a direction
	 */
	public int getConveyorDirection()
	{
		int direction = -1;
		if(type=='^')
			direction = 0;
		if(type=='>')
			direction = 1;
		if(type=='v')
			direction = 2;
		if(type=='<')
			direction = 3;
		return direction;
	}

	/**
	 * Do the moving action!
	 */
	@Override
	public void doAction(Bot b) throws BotDiedException {
		int direction = getConveyorDirection();
		Field f = gameboard.gameboard[b.xpos][b.ypos];
		if(gameboard.getNextFieldStepDriveable(direction, x, y))
		{
			b.moveBot(direction);
			Field fnext = gameboard.gameboard[b.xpos][b.ypos];
				
				
			if(fnext.getClass().equals(ConveyorField.class) && f.getClass().equals(ConveyorField.class) &&
			   !f.equals(fnext))
			{
				// The will only turned left or right, according to FAQ... 
				// Means: Opposite looking conveyor field doesn't turn the bot.
				ConveyorField fc = (ConveyorField)f;
				ConveyorField fnextc = (ConveyorField)fnext;
				int leftdirection = fc.getConveyorDirection() + 3;
				leftdirection %= 4;
				int rightdirection = fc.getConveyorDirection() + 1;
				rightdirection %= 4;
				if(leftdirection==fnextc.getConveyorDirection())
					b.turnLeft();
				if(rightdirection==fnextc.getConveyorDirection())
					b.turnRight();
				// TODO: Known bug: FAQ says:
				// Ja, derzeit wird der Bot auch gedreht, wenn er von einem Fließband über eine Ölspur auf ein 
				// anderes Fließband geschoben wird. Das klingt etwas ungewöhlich, aber ist so umgesetzt
				// We don't support this case! Its an bug in the engine in my opinion anyway :-D
			}
		}
		
	}
}
