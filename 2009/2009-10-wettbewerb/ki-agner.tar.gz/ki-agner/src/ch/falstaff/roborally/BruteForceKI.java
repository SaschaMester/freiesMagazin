/**
 *
 * Created at 11.11.2009 by Stefan Agner
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package ch.falstaff.roborally;

import ch.falstaff.roborally.cards.TurnCard;
import ch.falstaff.roborally.fields.ConveyorField;
import ch.falstaff.roborally.fields.Field;

public class BruteForceKI implements KI {
	private static int CARDS_TO_CHOOSE = 5; 
	private GameBoard gb;
	private CardSet bestArray;
	private int current_card_rating[] = new int[CARDS_TO_CHOOSE];
	private int current_card_rating_direction[] = new int[CARDS_TO_CHOOSE];
	
	public BruteForceKI(GameBoard gb)
	{
		this.gb = gb;
	}
	
	/* 
     * Runs the KI!
	 */
	public CardSet runKI(Bot b, CardSet cards) throws NoSolutionFoundException
	{
		permuteCards(1, cards, new CardSet(), b);
		if(bestArray == null)
			throw new NoSolutionFoundException(this.getClass().toString() + ": Found no solution!");

		if(Main.DEBUG)
		{
			System.out.println("Best Raiting found: " + current_card_rating[4]);
			for(int k=0;k<bestArray.size();k++)
			{
				try {
					b.doCard(bestArray.get(k));
				} catch (BotDiedException e) {
				}
				System.out.print(bestArray.get(k).toString() + ", ");
				System.out.println("Bot should End at: " + b.xpos + " " + b.ypos + " Direction: " + b.direction);
			}
			System.out.println();
			System.out.println("Bot should End at: " + b.xpos + " " + b.ypos + " Direction: " + b.direction);
			b.save("bot-new.txt");
		}
		return bestArray;
	}

	/*
	 * Premute all Card variations...
	 */
	private void permuteCards(int level, CardSet cards, CardSet choosencards, Bot b)
	{
		// Loop through the incoming card deck...
		for(int i=0;i<cards.size();i++)
		{
			if(level==CARDS_TO_CHOOSE)
			{
				// Add the last card
				CardSet currentchoosencards = choosencards.clone();
				currentchoosencards.add(cards.get(i));
				
				// See what we have with this combination...
				calculateRaiting(currentchoosencards, b);
			}
			else
			{
				// Remove the card we took in this permutation...
				CardSet childcards = cards.clone();
				CardSet childchoosencards = choosencards.clone();
				
				// Add that card to the childs choosen cars...
				childchoosencards.add(childcards.remove(i));
				permuteCards(level+1, childcards, childchoosencards, b);
			}
		}
	}
	
	private void calculateRaiting(CardSet choosencards, Bot b)
	{
		// Lets play this combination!
		Bot bclone = b.clone();
		
		// We have a own bot, we can do whatever we want... We play ALL card on it!
		int[] new_card_raiting = new int[CARDS_TO_CHOOSE];
		int[] new_card_raiting_direction = new int[CARDS_TO_CHOOSE];
		try {
			for(int k=0;k<choosencards.size();k++)
			{
				bclone.doCard(choosencards.get(k));
				new_card_raiting[k] += gb.gameboard[bclone.xpos][bclone.ypos].getRating();
				new_card_raiting_direction[k] = bclone.getDirectionRaiting();
			}
		}
		catch(BotDiedException e)
		{
			// Uuuh, our bot died, this is no solution at all!
			return;
		}
		
		// All cards played, what do we have as final rating?
		Field f = gb.gameboard[bclone.xpos][bclone.ypos];
		
		// If its a hard game, we probably shouldn't be at a convoyor field!
		if(f.getClass().equals(ConveyorField.class) && Main.level == GameLevel.hard)
		{
			// Test a "non moving" card set on the bot. If it leads to dead, its a bad solution...
			Bot bclone2 = bclone.clone();
			try {
				for(int i=0;i<CARDS_TO_CHOOSE;i++)
					bclone2.doCard(new TurnCard(1));
			} catch (BotDiedException e) {
				// Bad solution, don't consider it to take...
				return;
			}
		}
		
		// Its equal to that before, take it if
		for(int l=CARDS_TO_CHOOSE;l>0;l--)
		{
			// Take this raiting if its better, or equal but has a better direction...
			if(current_card_rating[l-1] < new_card_raiting[l-1] ||
			   current_card_rating[l-1] == new_card_raiting[l-1] && 
			   current_card_rating_direction[l-1]<new_card_raiting_direction[l-1])
			{
				//current_rating = new_raiting;
				current_card_rating = new_card_raiting;
				current_card_rating_direction = new_card_raiting_direction;
				bestArray = choosencards.clone();
				return;
			} 
			else if(current_card_rating[l-1]>new_card_raiting[l-1])
				return;
		}
	}

}
