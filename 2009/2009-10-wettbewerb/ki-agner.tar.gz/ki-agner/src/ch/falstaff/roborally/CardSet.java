/**
 *
 * Created at 09.11.2009 by Stefan Agner
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package ch.falstaff.roborally;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import ch.falstaff.roborally.cards.Card;

/**
 * Class represents a cardset.
 * @author sag
 *
 */
public class CardSet extends  ArrayList<Card> {
	
	private static final long serialVersionUID = 1L;


	private CardSet(String filename) throws IOException
	{
		super();
		BufferedReader br = new BufferedReader(new FileReader(filename));
		String line;
		while((line = br.readLine()) != null)
		{
			add(Card.createCard(line));
		}
	}
	
	
	public CardSet() 
	{
		super();
	}


	public static CardSet createCardSet(String filename)
	{
		try {
			return new CardSet(filename);
		} catch (FileNotFoundException e) {
			System.err.println("Cardset file not found...");
			return null;
		} catch (IOException e) {
			System.err.println("Error while reading cardset...");
			return null;
		}

	}
	
	public CardSet clone()
	{
		return (CardSet)super.clone();		
	}
	
	public void save(String filename)
	{		
	    try {
    	    // Create choosen Card file 
    	    FileWriter fstream = new FileWriter(filename);
    	    BufferedWriter out = new BufferedWriter(fstream);
    	    for(int i = 0;i<size();i++)
    	    	out.write(get(i).toString() + "\n");
    	    out.close();
	    }
	    catch (IOException e)
	    {
	    	System.err.println("Error: " + e.getMessage());
	    }
	}
	
}
