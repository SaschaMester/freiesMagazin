/**
 *
 * Created at 09.11.2009 by Stefan Agner
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package ch.falstaff.roborally.fields;

import ch.falstaff.roborally.Bot;
import ch.falstaff.roborally.BotDiedException;
import ch.falstaff.roborally.GameBoard;

public abstract class Field {
	protected GameBoard gameboard;
	public int x;
	public int y;
	protected int raiting;

	/**
	 * This implement active actions, which have a strict order...
	 * @param b
	 * @throws BotDiedException
	 */
	public abstract void doAction(Bot b) throws BotDiedException;
	
	/**
	 * This implements an action which happens immediately when the bot reaches a field
	 * @param b
	 * @param momentdirection The last direction the bot was moved (-1 = no movement)
	 * @param turnmomentum Last turn momentum (positive = clockwise, nevativ = reverse clockwise, 0 = none)
	 * @throws BotDiedException
	 */
	public abstract void passiveAction(Bot b, int momentdirection, int turnmomentum) throws BotDiedException;
	
	public abstract boolean leaveable(int direction);
	public abstract boolean drivable(int from);
	
	
	public Field(GameBoard gameboard, int x, int y) {
		this.gameboard = gameboard;
		this.x = x;
		this.y = y;
	}

	public void setRating(int value)
	{
		this.raiting = value;
	}
	
	public int getRating()
	{
		return this.raiting;
	}
	
	/**
	 * The field creator...
	 * @param fieldCharacter Character of the field according API
	 * @param gameboard Gameboard which this fields belong to
	 * @param x X-Position on the gameboard
	 * @param y Y-Position on the gameboard
	 * @return The newly created Field...
	 */
	public static Field createField(char fieldCharacter, GameBoard gameboard, int x, int y)
	{
		Field field;
		switch(fieldCharacter)
		{
			case ' ':
			case 'S':
			case 'T':
			case 'U':
			case 'V':
				field = new EmptyField(gameboard, x, y);
				break;
			case 'H':
				field = new HoleField(gameboard, x, y);
				break;
			case 'O':
				field = new OilField(gameboard, x, y);
				break;
			case 'Z':
				field = new GoalField(gameboard, x, y);
				break;
			case 'R':
			case 'L':
				field = new RotatingWheelField(fieldCharacter, gameboard, x, y);
				break;
			case '<':
			case '>':
			case '^':
			case 'v':
				field = new ConveyorField(fieldCharacter, gameboard, x, y);
				break;
			case 'C':
			case 'D':
			case 'E':
			case 'F':
			case 'M':
			case 'N':
				field = new PusherField(fieldCharacter, gameboard, x, y);
				break;
			default:
				field = new WallField(fieldCharacter, gameboard, x, y);
				break;
		}
		return field; 
	}
	
	@Override
	public int hashCode() {
		return 1000 * x + y;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Field other = (Field) obj;
		if (x != other.x || y != other.y)
			return false;
		return true;
	}
}
