/**
 *
 * Created at 09.11.2009 by Stefan Agner
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package ch.falstaff.roborally;

public class Main {
	public static boolean DEBUG = false;
	public static GameLevel level;
	
	/**
	 * Starting function of the KI. Basically reads all given data, calls the KI and returns the cardset.
	 * @param args
	 * @throws BotDiedException 
	 */
	public static void main(String[] args) throws BotDiedException {
		level = GameLevel.normal;
		if(args.length > 0)
		{
			if(args[0].startsWith("easy"))
				level = GameLevel.easy;
			if(args[0].startsWith("normal"))
				level = GameLevel.normal;
			if(args[0].startsWith("hard"))
				level = GameLevel.hard;
		}
		System.out.println("Starting KI with Level: " + level.toString());
		
		// Read the gamebaord...
		GameBoard gb = GameBoard.createGameBoard("board.txt");
		if(gb==null)
			System.exit(1);

		// Read the bot...
		Bot b = Bot.createBot("bot.txt", gb);
		if(b==null)
			System.exit(2);

		// Read the cardset...
		CardSet cs = CardSet.createCardSet("cards.txt");
		if(cs==null)
			System.exit(3);

		if(DEBUG)
		{
			System.out.println("Verfügbare Karten:");
			for(int c = 0;c<cs.size();c++)
				System.out.print(cs.get(c).toString() + ", ");
			System.out.println();
		}
		
		// Start the KI...
		CardSet ccards;
		try {
			KI ki = new BruteForceKI(gb);
			ccards = ki.runKI(b, cs);
		} catch (NoSolutionFoundException e1) {
	    	System.err.println("Error: " + e1.getMessage());
	    	// Oh no, hes gonna die... just take the first 5 cards, to be API conform...
			ccards = new CardSet();
			ccards.addAll(cs.subList(0, 5));
		}
		
		// Write the choosen cards down...
		ccards.save("ccards.txt");
		
	}
	
}
