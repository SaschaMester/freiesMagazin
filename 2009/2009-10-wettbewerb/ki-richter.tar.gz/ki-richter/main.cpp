// *************************************************************************
// robots-ki-HAL - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Tom Richter <tomi.xy@gmx.de>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

/*
There are 6720 different possibilities to choose cards.
The KI excludes possibilities, which would end in the same position or in a 'dying' position.

The first approach for the HAL-KI was a kind of monte carlo simulation for every remaining possibility.
This means HAL does random moves till he reaches the goal or dies. The cards, whith which he has the highest probability to reach the goal, are choosen. For difficult boards a reward for coming the goal nearer was added. (This is reqired if the depth of monte carlo simulation is not enough for reaching the goal. If there are impasses this could fail.)

If there are only few possibilities to die (not a hard board, middle of the board) this method is quiet slow. The second approach (HAL2) improves the time consumption. In the first run HAL2 analyzes the board and allocates every possible position on it a number. The higher the number, the easier it is to reach the goal out of this position. The numbers are determined by doing random moves and using the already calculated information. The analyesd board is saved and loaded each time Hal is started afterwards.
Then HAL chooses the cards, with which he comes to the best position (with the highest number).
*/

//#include <time.h>
#include <iostream>
#include <string>
#include "baseenums.hh"
#include "basefunctions.hh"
#include "carddeck.hh"
#include "hal.hh"

int main( int argc, char *argv[] )
{
	int retValue = 0;
    if ( 2 == argc )
    {
        // try to extract optional game level
        std::string level( "normal" );
        level = argv[1];
        BaseFunctions::setGameLevel( level );
    }
    // ignore other arguments or when level is incorrect

    CardDeck deck;
    if ( deck.load( "cards.txt" ) )
    {
        if ( deck.size() == 8 )
        {
			// clock_t startingClock = clock();
			HAL2 hal(deck);			
           
			// start HAL1
            /*if (!hal.lookForGoalDeathAndSameCards())
			{
				unsigned int numSim=400;
				if (BaseFunctions::getGameLevel()!=BE_GAME_LEVEL_HARD)
				{
					numSim=50;
				}
				hal.startSimulation(numSim, 20, 500);				
			}*/
			// end HAL 1
			// start HAL 2

			 if (!hal.loadAnalysedBoard())
			{
                // hal.analyseBoard(50, 10, 3, true);				
                hal.analyseBoard(50, 20, 10, false);
				hal.saveAnalysedBoard();
			    // hal.printAnalysedBoard();
			}
			hal.lookForBestMoveOnAnalysedBoard();
			// end HAL 2

			// clock_t endingClock = clock();
			// std::cout
			//	 << ((double)(endingClock-startingClock))/CLOCKS_PER_SEC
			//	 << "s used (clock)" << std::endl;
			
			CardDeck ccards;
            // create new deck with choosen 5 cards
            if ( hal.ChooseCards(ccards) )
            {
                // save new deck
                if ( ccards.save("ccards.txt") )
                {   
                    retValue = 0;
                }
                else
                {
                    std::cout << "Error: Saving ccard.txt failed."
                              << std::endl;
                    retValue = 4;
                }
            }
            else
            {
                std::cout << "Error: Could not get 5 cards from deck."
                          << std::endl;
                
                retValue = 3;
            }
        }
        else
        {
            std::cout << "Error: Number of cards "
                      << deck.size()
                      << " does not equal 8."
                      << std::endl;
            
            retValue = 2;
        }
    }
    else
    {
        std::cout << "Error: Loading card.txt failed."
                  << std::endl;
        retValue = 1;
    }
    return retValue;
}
