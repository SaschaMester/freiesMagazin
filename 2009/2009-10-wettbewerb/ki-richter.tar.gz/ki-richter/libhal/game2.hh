// *************************************************************************
// robots-engine - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Tom Richter <tomi.xy@gmx.de>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef GAME2_HH
#define GAME2_HH

#include "game.hh"

class Game2 : public Game
{

public:
		
    // Constructor for KI
    // Loads board and bot position from disk, but does not load deck
    Game2( const bool withoutMeaning );

	// get the board file
	const std::string getBoardFile();
		
	// return an identifier for bot position and view direction
	unsigned int getPosViewIdent();

	// give bot candy as a meassure for distance to goal
	unsigned int giveCandy();

	// generate a sequence which can be used by KI
	const bool generateSequenceForKI( const CardDeck& choosenCards );

    // return true if bot is destroyed
    const bool botIsDestroyed() const { return m_bot.isDestroyed();}

    // return true if bot has reached end position
    const bool botHasReachedGoal() const { return botHasReachedEndPosition();}

	// reset bot to start
    const bool reset(){	m_bot=m_bot_begin; return true; }

	// reset bot to start and stats to 0
    const bool resetstats(){ m_bot=m_bot_begin; m_stats=Stats(); return true; }

	// reset game to given bot
    const bool reset(Bot& bot){	m_bot=bot; return true; }

	// return game board
	const bool getBoard(GameBoard& board){ board = m_board;	return true; }

	// return bot
	Bot getBot(){ return m_bot;}

    // returns view direction between 0 and 3
    unsigned int getBotViewDirectionAsInt();

    // return minus points from stats
    double getMinusPointsFromStats(){ return m_stats.get(Stats::SE_NUM_PLAYED_CARDS)+m_stats.get(Stats::SE_NUM_CARD_MOVES)
                    +0.5*m_stats.get(Stats::SE_NUM_BOARD_MOVES); }

private:

	// saved bot at starting position
    Bot m_bot_begin;

    Stats m_stats;
};

#endif // GAME2_HH
