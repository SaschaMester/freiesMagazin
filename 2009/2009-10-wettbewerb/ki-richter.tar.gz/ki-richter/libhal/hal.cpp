// *************************************************************************
// robots-engine / libhal - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Tom Richter <tomi.xy@gmx.de>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <string.h>
#include <sstream>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <iomanip>
#include <math.h>
#include <time.h>

#include "basefunctions.hh"
#include "bot.hh"
#include "hal.hh"

const std::string analysedboardfile("HAL_data");
const std::string lastanalysedboardfile("HAL_data2");

// Default constructor, HAL can choose 5 cards out of deck
HAL::HAL( const CardDeck& deck )
:m_game(true),
m_deck(deck),
m_ident(0)
{
	m_game.getBoard(m_board);
	for (unsigned int ii=0; ii<6720; ii++){ m_doNotChoose[ii]=false; }
	srand((unsigned int) time(NULL));
}

// HAL has to choose the cards now
const bool HAL::ChooseCards(CardDeck& ccards)
{
	return m_deck.getCards( ccards, 5, m_ident, false);
}

// HAL looks for the goal, for bad moves and for same cards in the deck.
// He should do that before a monte carlo simulation.
const bool HAL::lookForGoalDeathAndSameCards()
{
	CardDeck2 deck_save=m_deck;
	CardDeck2 ccards;
	bool doNotChooseThis=false;
	bool foundGoal=false;
	for (unsigned int ii=0; ii<6720; ii++)
	{
		// exclude similar decks of choosen cards
		doNotChooseThis=!m_deck.getCards(ccards, 5, ii, true);
		m_deck=deck_save;
		if (doNotChooseThis==true){m_doNotChoose[ii]=true; continue;}
		// look for goal and danger
		m_game.generateSequenceForKI(ccards);
		if ( m_game.botHasReachedGoal() ){ foundGoal=true; m_ident=ii; break; }
		doNotChooseThis=m_game.botIsDestroyed();
		if ( doNotChooseThis == true ){ m_doNotChoose[ii]=true; }
		m_game.reset();
	}
	return foundGoal;
}

// HAL starts a monte carlo simulation to maximize candy
const bool HAL::startSimulation(unsigned int numSim, unsigned int numSimDepth, unsigned int goalReward)
{
	// unsigned int numOfDecksBeforeSim=0;
	// for (unsigned int ii=0; ii<6720; ii++)
	// {if (!m_doNotChoose[ii]){numOfDecksBeforeSim++;}}
	
	// start monte carlo simulation		
	srand ((unsigned int) time(NULL) );
	CardDeck2 deck_save=m_deck;
	CardDeck2 ccards, simccards;
	unsigned int maxCandy=0;
	unsigned int candy;			
	unsigned int iiSim=0;
	unsigned int botPosViewArray[6720]={0};
	unsigned int botPosView;
	for (unsigned int ii=0; ii<6720; ii++)
	{  
		if (!m_doNotChoose[ii])
		{
			m_deck.getCards(ccards, 5, ii, false);
			m_deck=deck_save;
			m_game.generateSequenceForKI(ccards);
			botPosView=m_game.getPosViewIdent();
			// look for decks which would end in the same bot position
			// and exclude them
			unsigned int jj=0;
			while ( jj < iiSim )
			{	
				if ( botPosViewArray[jj] == botPosView )
				{	
					m_doNotChoose[ii]=true;
					break;
				}
				jj++;
			}
			if ( jj<iiSim ) { m_game.reset(); continue; }						
			botPosViewArray[iiSim]=botPosView;
			iiSim++;
			// start simulation
			candy=1;
			for (unsigned int jj=0; jj<numSim; jj++)
			{
				if (jj>0){m_game.generateSequenceForKI(ccards);}
				for (unsigned int kk=0; kk<numSimDepth; kk++)
				{
					simccards.initRandomCards();  // generate 5 random cards
					m_game.generateSequenceForKI(simccards);
					if (m_game.botHasReachedGoal()){candy+=goalReward; break;} // reward for finding goal
					if (m_game.botIsDestroyed()){break;}        // no reward for being destroyed
					if (kk==numSimDepth-1){candy+=m_game.giveCandy();} // reward for not being destroyed between 0 and 10
				}
				m_game.reset();
			}
			if (candy>maxCandy)
			{
				maxCandy=candy;
				m_ident=ii;
			}
		}
	}
	//unsigned int numOfDecksAfterSim=0;
	//for (unsigned int ii=0; ii<6720; ii++)
	//{if (!doNotChoose[ii]){numOfDecksAfterSim++;}}
	//std::cout << "Number of different sets: 6720 -> " << numOfDecksBeforeSim << " -> " << numOfDecksAfterSim << std::endl;
	//std::cout << "relative Candy = " << ((double)maxCandy)/numSimDepth/goalReward << std::endl;
	return true;
}

// Constructor for HAL2
HAL2::HAL2( const CardDeck& deck )
:HAL(deck)
{
	for (unsigned int ii=0; ii<20; ii++)
		for (unsigned int jj=0; jj<20; jj++)
			for (unsigned int kk=0; kk<4; kk++)
			 	m_analysedBoard[ii][jj][kk]=0;
	m_startx=m_board.getStartPos().x();
	m_starty=m_board.getStartPos().y();
	m_startview=(unsigned int)(log((double)(m_board.getStartViewDirection()))/log(2));		
}

// Analyze board, give every position on the board a number. The higher the number,
// the easier it is to reach the goal.
const bool HAL2::analyseBoard(unsigned int numSim, unsigned int maxIter, unsigned int maxLoops, bool randomMoves)
{
    std::cout << "HAL: analysing board" << std::endl;
    if (!randomMoves){ numSim=7; }
	double probability = 1./numSim;
	Position goal = m_board.getEndPos();
	unsigned int maxx=m_board.getWidth();
	unsigned int maxy=m_board.getHeight();
	unsigned int xg=goal.x(); unsigned int yg=goal.y();
	unsigned int maxSquare=xg+1;
	if (yg+1>maxSquare){maxSquare=yg+1;}
	if (maxx-xg>maxSquare){maxSquare=maxx-xg;}
	if (maxy-yg>maxSquare){maxSquare=maxy-yg;}	
	CardDeck2 simccards;	
	unsigned int numIter=0;
	double simpleCandy[20][20][4];
    for (unsigned int kk=0; kk<4; kk++) { m_analysedBoard[xg][yg][kk]=1e20; } // candy for reaching goal
	
	// holes, squeezers, boxes -> number=-1
	for (unsigned int ii=0; ii<maxx; ii++) for (unsigned int jj=0; jj<maxy; jj++)
	{
		const BaseTile* tile = m_board[Position(ii, jj)];
		if (   tile->isType( TE_TYPE_HOLE )
			|| tile->isType( TE_TYPE_SQUEEZER )
			|| tile->getWalls() == TM_WALL_ALL )
			for (unsigned int kk=0; kk<4; kk++)
				m_analysedBoard[ii][jj][kk]=-1;
	}

	// starting with a 3x3 to sizex x sizey square
	// for each position on square choose numSim-times 5 random cards (if randomMoves=true) or
    // 1 card (if randomMoves=false)
	// and collect points depending on end position
	memcpy(simpleCandy, m_analysedBoard, sizeof(m_analysedBoard));
	for (unsigned int square = 1; square<maxSquare; square++)
	{   
		for (unsigned int ii=0; ii<2*square+1; ii++)
		{
			for (unsigned int jj=0; jj<2*square+1; jj++)
			{
				if (ii+xg>=square && jj+yg>=square && ii+xg<maxx+square && jj+yg<maxy+square && !(ii==square && jj==square))
				{	
					unsigned int xPos=ii+xg-square; unsigned int yPos = jj+yg-square;
					if (m_analysedBoard[xPos][yPos][0]>=0)
					{
						for (unsigned int kk=0; kk<4; kk++)
						{
							double candy=0;
							Bot simbot(Position(xPos, yPos), (BotEnumViewDirection) (unsigned int) pow(2,(double)kk) );
                            for (unsigned int iiSim=0; iiSim<numSim; iiSim++)
							{
								m_game.reset(simbot);
								if (randomMoves){ simccards.initRandomCards(); } // generate 5 random cards
                                else { probability = simccards.initOneCard(iiSim); } // generate 1 card
								m_game.generateSequenceForKI(simccards);
							    if (!m_game.botIsDestroyed()){ candy+=giveCandyOfAnalysedBoard()*probability; }	
                            }
							simpleCandy[xPos][yPos][kk]=candy;
						}
						
					}
				}
			}
		}
		memcpy(m_analysedBoard, simpleCandy, sizeof(simpleCandy));
	}
	// do maxIter additional runs on whole board
    // if start position has no candy yet, do maxLoops*maxIter additional runs on whole board
    unsigned int numLoops=0;
    while ((0==m_analysedBoard[m_startx][m_starty][m_startview] && numLoops<maxLoops) || numIter<maxIter)
    {
      numLoops++;
	  while (numIter<numLoops*maxIter)
	  {
		for (unsigned int ii=0; ii<maxx; ii++)
		{
			for (unsigned int jj=0; jj<maxy; jj++)
			{
				if (!(ii==xg && jj==yg))
				{
					for (unsigned int kk=0; kk<4; kk++) if (m_analysedBoard[ii][jj][kk]==0)
					{
						double candy=0;
						Bot simbot(Position(ii, jj), (BotEnumViewDirection) (unsigned int) pow(2,(double)kk) );							
						for (unsigned int iiSim=0; iiSim<numSim; iiSim++)
						{
							m_game.reset(simbot);
							if (randomMoves){ simccards.initRandomCards(); } // generate 5 random cards
                            else { probability = simccards.initOneCard(iiSim); } // generate 1 card
							m_game.generateSequenceForKI(simccards);
							if (!m_game.botIsDestroyed()){ candy+=giveCandyOfAnalysedBoard()*probability; }	
						}
						simpleCandy[ii][jj][kk]=candy;
					}					
				}
			}
		}
        memcpy(m_analysedBoard, simpleCandy, sizeof(simpleCandy));
		numIter++;
      }
    }
	bool ok=true;
	if (numIter==maxLoops*maxIter && numIter>0){ std::cout << "HAL: no clue" << numIter << std::endl; ok=false; } // failed, start position has no candy
	return ok;
}

// print analysed board of all 4 view directions
const bool HAL2::printAnalysedBoard()
{
	for (unsigned int ii=0; ii<4; ii++)
	{
		if (ii==0) {std::cout<< "<-";}
		if (ii==1) {std::cout<< "->";}
		if (ii==2) {std::cout<< "^";}
		if (ii==3) {std::cout<< "v";}
		std::cout << std::endl;
		printAnalysedBoard(ii);
	}
	return true;
}

// print analysed board with given view direction
const bool HAL2::printAnalysedBoard(unsigned int view)
{
	for (unsigned int ii=0; ii<m_board.getHeight(); ii++)
	{
		for (unsigned int jj=0; jj<m_board.getWidth(); jj++)
		{
			std::cout << std::setprecision(2) << std::setw(8) << m_analysedBoard[jj][ii][view];
		}
		std::cout << std::endl;
	}
	std::cout << std::endl;
	return true;
}

// save analysed board in data file
const bool HAL2::saveAnalysedBoard()
{	
	bool ok=false;
	// save board
	m_board.saveAscii(lastanalysedboardfile);
    std::ofstream outFile1(lastanalysedboardfile.c_str(), std::ios::out | std::ios::app);
	if ( outFile1.good() )
	{	
        outFile1 << BaseFunctions::convertGameLevelToString() << std::endl;
		outFile1.close();	
	}
	else
	{
		std::cerr << "HAL2::saveAnalysedBoard() "
			<< "Error: File "
			<< lastanalysedboardfile.c_str()
			<< " could not be opened."
			<< std::endl;
	}    

	// save analysed board
	std::cout << "HAL: saving " << analysedboardfile.c_str() << std::endl;
	std::ofstream outFile2(analysedboardfile.c_str(), std::ios::out | std::ios::binary);
	if ( outFile2.good() )
	{	
		outFile2.write((char *) &m_analysedBoard, sizeof m_analysedBoard);
		outFile2.close();	
		ok = true;
	}
	else
	{
		std::cerr << "HAL2::saveAnalysedBoard() "
			<< "Error: File "
			<< analysedboardfile.c_str()
			<< " could not be opened."
			<< std::endl;
	}
	return ok;
}

// load analysed board from data file
const bool HAL2::loadAnalysedBoard()
{	
	bool ok=false;
	bool loadFile=false;
	// compare board from last run with actual board
	if (m_board.getStartPos()==m_game.getBot().getPos())
	{
		std::ifstream in1(m_game.getBoardFile().c_str());
		std::ifstream in2(lastanalysedboardfile.c_str());
		if ( in2.good() )
		{ 
			if( in1.good() )
			{
				loadFile=true;
				char ch1, ch2;
  				while (in1.get(ch1)) {
	    			if (!in2.get(ch2) || (ch1 != ch2)) {
      					loadFile=false; break;}
			  	}
                std::string level;
                in2 >> level;
                if (level!=BaseFunctions::convertGameLevelToString()) {loadFile=false;}
			 	in1.close();
			}
			in2.close();
		}
    }
	// load analysed board
	if (m_board.getStartPos()!=m_game.getBot().getPos() || loadFile)
	{	
        std::cout << "HAL: loading " << analysedboardfile.c_str() << std::endl;
		std::ifstream inFile(analysedboardfile.c_str(), std::ios::in | std::ios::binary);
		if ( inFile.good() )
		{	
			inFile.read((char *) &m_analysedBoard, sizeof m_analysedBoard);
			inFile.close();
			ok=true;
		}
		else
		{
			std::cerr << "HAL2::loadAnalysedBoard() "
				<< "Error: File "
				<< analysedboardfile.c_str()
				<< " could not be opened."
				<< std::endl;
		}
	}
	return ok;
}

// look for the best move on an analysed board
const bool HAL2::lookForBestMoveOnAnalysedBoard()
{
	CardDeck2 deck_save=m_deck;
	CardDeck2 ccards;
	bool doNotChooseThis=false;
	bool foundGoal=false;
	double simpleCandy[6720]={0};
	for (unsigned int ii=0; ii<6720; ii++)
	{
		// exclude similar decks of choosen cards
		doNotChooseThis=!m_deck.getCards(ccards, 5, ii, true);
		m_deck=deck_save;
		if ( doNotChooseThis==true ){ continue; }
		// look for goal and danger
		m_game.generateSequenceForKI(ccards);
		if ( m_game.botHasReachedGoal() ){ foundGoal=true; m_ident=ii; m_game.resetstats(); break; }
		if ( !m_game.botIsDestroyed() )
		{
			simpleCandy[ii]=m_analysedBoard[m_game.getBot().getPos().x()]
											[m_game.getBot().getPos().y()]
											[m_game.getBotViewDirectionAsInt()];
		}
		else
		{
			simpleCandy[ii]=-1;
		}
		m_game.reset();
	}
	// look which cards to choose to get to the best position (with most candy)
	if (!foundGoal)
	{
		double maxCandy=-1;
		for (unsigned int ii=0; ii<6720; ii++) if (simpleCandy[ii]>maxCandy)
		{
			maxCandy=simpleCandy[ii];
			m_ident=ii;
		}
        if (maxCandy==0) { for (unsigned int ii=0; ii<6720; ii++)
		{
            if ( simpleCandy[ii]==-1 ){ m_ident=ii; break; } // if goal can not be reached from any end field do suicide
		}}
	}
    // look for best way to goal
    if (foundGoal)
    {
        double minMinusPoints = 100;
	    for (unsigned int ii=0; ii<6720; ii++)
	    {
		    m_deck.getCards(ccards, 5, ii, false);
		    m_deck=deck_save;
		    m_game.generateSequenceForKI(ccards);
    		if (m_game.botHasReachedGoal())
            {
                double minusPoints=m_game.getMinusPointsFromStats();
                if ( minusPoints < minMinusPoints )
                {
                    minMinusPoints=minusPoints;
                    m_ident=ii;      
                }
            }
	    	m_game.resetstats();
	    }
    }
	return foundGoal;
}

