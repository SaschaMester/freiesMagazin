// *************************************************************************
// robots-engine - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Tom Richter <tomi.xy@gmx.de>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <cstdlib>
#include "game2.hh"

const std::string boardname2("board.txt");
const std::string botname2("bot.txt");

// Constructor for KI
// Loads board and bot position from disk
Game2::Game2( const bool KI )
:Game()
{
    if ( m_board.loadAscii( boardname2 ) )
    {
    	if ( m_bot.load( botname2 ) )
		{
        	m_bot_begin=m_bot;
        }
    }
}	


// get the board file
const std::string Game2::getBoardFile()
{
    return boardname2;
}


// return an identifier for bot position and view direction
unsigned int Game2::getPosViewIdent()
{
	unsigned int temp=0;
    if ( m_bot.getViewDirection() == BE_VIEW_DIRECTION_LEFT )
    {
		temp=0;
	}
	else if ( m_bot.getViewDirection() == BE_VIEW_DIRECTION_RIGHT )
	{
		temp=1;
	}
	else if ( m_bot.getViewDirection() == BE_VIEW_DIRECTION_UP )
	{
		temp=2;
	}
	else if ( m_bot.getViewDirection() == BE_VIEW_DIRECTION_DOWN )
	{
		temp=3;
	}
	return m_bot.getPos().x() + m_bot.getPos().y() * m_board.getWidth()
		+ temp * m_board.getWidth() * m_board.getHeight()+1;
}

// returns view direction between 0 and 3
unsigned int Game2::getBotViewDirectionAsInt()
{
	unsigned int temp=0;
    if ( m_bot.getViewDirection() == BE_VIEW_DIRECTION_LEFT )
    {
		temp=0;
	}
	else if ( m_bot.getViewDirection() == BE_VIEW_DIRECTION_RIGHT )
	{
		temp=1;
	}
	else if ( m_bot.getViewDirection() == BE_VIEW_DIRECTION_UP )
	{
		temp=2;
	}
	else if ( m_bot.getViewDirection() == BE_VIEW_DIRECTION_DOWN )
	{
		temp=3;
	}
	return temp;
}

// give bot candy as a meassure for distance to goal
unsigned int Game2::giveCandy()
{
	Position goal = m_board.getEndPos();
	return (unsigned int) (m_board.getWidth() + m_board.getHeight()
		- abs((int) (goal.x()) - (int) (m_bot.getPos().x()))
		- abs((int) (goal.y()) - (int) (m_bot.getPos().y())))
		* 5 / m_board.getWidth(); // value between 0 and 10
}

// generate a sequence which can be used by KI
const bool Game2::generateSequenceForKI( const CardDeck& choosenCards )
{
    bool ok = true;

    // global sequence with complete movement of all five cards
    Sequence globalSeq;

    for ( unsigned int ii = 0; ii < choosenCards.size(); ii++ )
    {
        if ( NULL != choosenCards[ii] )
        {
            // add new card
            m_stats.increase( Stats::SE_NUM_PLAYED_CARDS );

            // get movement for this card
            Sequence startSeq;
            choosenCards[ii]->getSequence( startSeq );

            // now we must transform this movement to the game board
            // and the robot
            Sequence endSeq;
            generateSequenceAndMoveRobot( endSeq, startSeq, m_stats, false );
            globalSeq.append( endSeq );
            if ( endSeq.size() > 0 && isEndMove( endSeq.back() ) ) { break; }
        }
        else
        {
            ok = false;
        }
    }

    return ok;
}
