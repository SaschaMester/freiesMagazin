// *************************************************************************
// robots-engine / libhal - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Tom Richter <tomi.xy@gmx.de>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef HAL_HH
#define HAL_HH
#include <math.h>

#include "bot.hh"
#include "carddeck2.hh"
#include "gameboard.hh"
#include "game2.hh"

class HAL
{
public:
	
	// Default constructor, HAL can choose 5 cards out of deck
    HAL( const CardDeck& deck );

	// HAL has to choose the cards now
	const bool ChooseCards(CardDeck& ccards);

	// HAL looks for the goal, for bad moves and for doubled cards in the deck.
	// He should do that before a monte carlo simulation.
	const bool lookForGoalDeathAndSameCards();

	// HAL starts a monte carlo simulation to maximize candy
	const bool startSimulation(unsigned int numSim=400, unsigned int numSimDepth=20, unsigned int goalReward=500);
			
protected:
	// game for simulating and playing random moves
	Game2 m_game;

    // game board with tiles
    GameBoard m_board;

    // card deck with cards
    CardDeck2 m_deck;

	// identifier of cards to be choosen
	unsigned int m_ident;

	// HAL will not choose these cards
	bool m_doNotChoose[6720];
	
};

class HAL2 : public HAL
{
public:
	
	// Constructor for HAL2
    HAL2( const CardDeck& deck );
		
	// Analyze board, give every position on the board a number. The higher the number,
	// the easier it is to reach the goal.			
	const bool analyseBoard(unsigned int numSim=50, unsigned int maxIter=20, unsigned int maxLoops=20, bool randomMoves=false);

	// print analysed board of all view directions
	const bool printAnalysedBoard();

	// print analysed board with given view direction	
	const bool printAnalysedBoard(unsigned int view);

	// save analysed board in data file		
	const bool saveAnalysedBoard();
	
	// load analysed board from data file		
	const bool loadAnalysedBoard();

	// look for the best move on an analysed board
	const bool lookForBestMoveOnAnalysedBoard();

private:
	
	// returns the candy of a given bot position
	double giveCandyOfAnalysedBoard()
	{
		return m_analysedBoard[m_game.getBot().getPos().x()]
			[m_game.getBot().getPos().y()]
			[m_game.getBotViewDirectionAsInt()];
	}

	// the analysed board, values: -1 and 0 to 1e20
	double m_analysedBoard[20][20][4];

	// start position of bot on given board (to determine if data file can be loaded)
	unsigned int m_startx, m_starty, m_startview;
};

#endif // HAL_HH
