// *************************************************************************
// robots-engine / libcards - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Tom Richter <tomi.xy@gmx.de>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <sstream>
#include <iostream>
#include <cstdlib>

#include "carddeck2.hh"

// Save card deck to stringstream	
/*
const bool CardDeck2::save(std::stringstream& outfile, const bool unusedOnly) const
{
    bool ok = false;
            // in the first line we store the size
            // const unsigned int size = ( ( unusedOnly ) ? getNumUnusedCards() : size() );
            // outFile << size << std::endl;

            for ( unsigned int ii = 0; ii < size(); ii++ )
            {
                if ( NULL != m_deck[ii] )
                {
                    if ( ( !unusedOnly ) ||
                         ( unusedOnly && !m_deck[ii]->isUsed() ) )
                    {
                        // save tile directly to file
                        if ( !m_deck[ii]->save( outfile ) )
                        {
                            return ok;
                        }
                    }
                }
            }
            ok = true;
    return ok;
}*/

// init random cards
const bool CardDeck2::initRandomCards( const unsigned int newSize )
{
    resize( newSize ); // set new size
    m_shadowCopy = false; // we create original content
    for ( unsigned int ii = 0; ii < 5; ii++ )
    {
        unsigned int r=rand()%14;
        if (r==0) { setCard( ii, (BaseCard*)( new MoveCard(3) ) ); }
        if (r==1) { setCard( ii, (BaseCard*)( new MoveCard(-1) ) ); }
        if (r==2) { setCard( ii, (BaseCard*)( new RotationCard( CE_ROTATION_UTURN ) ) ); }
        if (r==3 || r==4) { setCard( ii, (BaseCard*)( new MoveCard(2) ) ); }
        if (r>=5 && r<=7) { setCard( ii, (BaseCard*)( new MoveCard(1) ) ); }
        if (r>=8 && r<=10) { setCard( ii, (BaseCard*)( new RotationCard( CE_ROTATION_RIGHT))); }
        if (r>=11) { setCard( ii, (BaseCard*)( new RotationCard( CE_ROTATION_LEFT ) ) ); }
    }
    return true;
}

// init one card
double CardDeck2::initOneCard( const unsigned int which )
{
    resize( 1 ); // set new size
    m_shadowCopy = false; // we create original content
    double probability=1./14;
    for ( unsigned int ii = 0; ii < 5; ii++ )
    {
        if (which==0) { setCard( 0, (BaseCard*)( new MoveCard(3) ) ); }
        if (which==1) { setCard( 0, (BaseCard*)( new MoveCard(-1) ) ); }
        if (which==2) { setCard( 0, (BaseCard*)( new RotationCard( CE_ROTATION_UTURN ) ) ); }
        if (which==3) { setCard( 0, (BaseCard*)( new MoveCard(2) ) ); probability=2./14; }
        if (which==4) { setCard( 0, (BaseCard*)( new MoveCard(1) ) ); probability=3./14; }
        if (which==5) { setCard( 0, (BaseCard*)( new RotationCard( CE_ROTATION_RIGHT))); probability=3./14; }
        if (which==6) { setCard( 0, (BaseCard*)( new RotationCard( CE_ROTATION_LEFT ) ) ); probability=3./14; }
    }
    return probability;
}

// get a special choice of number cards and store them in the deck
// the identifier for the choosen cards is 0 <= ident < size! / (size-number)!
const bool CardDeck2::getCards( CardDeck& deck,
                               const unsigned int number,
                               unsigned int ident,
							   bool excludeDoubledCards)
{
    bool ok = true;

    if ( number <= size() )
    {
        // clear old data and set correct size
        deck.resize( number );
        unsigned int jj;

        // copy cards
		unsigned int same[10]={0};
        for ( unsigned int ii = 0; ii < number; ii++ )
        {	
			div_t divresult = div (ident, size()-ii);
			ident=divresult.quot;
			jj=getUnusedCard(divresult.rem);
			if (excludeDoubledCards && sameCards[jj]>0)
			{	
				for ( unsigned int kk = 0; kk < 4; kk++ )
				{
					if ( kk*size() < sameCards[jj] && sameCards[jj] < 1+kk*(size()+1) )
					{
						if ( same[kk]+1+kk*size() >= sameCards[jj] )
							{ same[kk]=sameCards[jj]-kk*size(); }
						else { ok=false; break; }
					}
				}
				if (!ok) {break;}				
			}
			deck.setCard ( ii, m_deck[jj]->clone() );
            m_deck[jj]->setUsed(true);
        }
    }
    else
    {
        std::cerr << "CardDeck::getCards(cards,int) "
                  << "Error: Number of cards "
                  << number
                  << " is greater than size "
                  << size()
                  << "."
                  << std::endl;
    }

    return ok;
}

// save information in sameCards where are the same cards in the deck
const bool CardDeck2::lookForSameCards()
{
	for ( unsigned int ii = 0; ii < size(); ii++ ) {sameCards[ii]=0;}
	unsigned int base=0;
	unsigned int pos;
    for ( unsigned int ii = 0; ii < size(); ii++ )
	{	
		if ( sameCards[ii]==0 )
		{
			pos = findNext ( m_deck[ii], ii+1 );
			unsigned int jj = base * size() + 1;
			if ( pos < size() ) { sameCards[ii]=jj; base++; }
			while ( pos<size() )
			{	
				jj++;
				sameCards[pos]=jj;
				pos=findNext(m_deck[pos], pos+1);
			}
		}
	}
	
	return true;
}

// return position of given card in deck after position pos0-1
const unsigned int CardDeck2::findNext( const BaseCard* card, unsigned int pos0, const bool unusedOnly ) const
{
    unsigned int pos = size();
	
    for ( unsigned int ii = pos0; ii < size(); ii++ )
    {
        if ( NULL != m_deck[ii] && NULL != card )
        {
            if ( ( ( !unusedOnly ) || ( unusedOnly && !m_deck[ii]->isUsed() ) ) &&
                 ( m_deck[ii]->equals( *card ) ) )
            {
                pos = ii;
                break;
            }
        }
    }

    return pos;
}

// get number of jjth unused cards
const unsigned int CardDeck2::getUnusedCard(unsigned int jj) const
{
    for ( unsigned int ii = 0; ii < size(); ii++ )
    {
        if ( NULL != m_deck[ii] && m_deck[ii]->isUsed())
        {   jj++;}
        if (ii== jj){break;}
    }

    return jj;
}
