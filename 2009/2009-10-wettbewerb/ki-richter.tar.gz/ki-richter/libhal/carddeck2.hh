// *************************************************************************
// robots-engine / libcards - freiesMagazin Programmierwettbewerb 10/2009
// Copyright 2009 Tom Richter <tomi.xy@gmx.de>
// Licence: LGPLv3
// *************************************************************************

/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef CARDECK2_HH
#define CARDECK2_HH

#include "carddeck.hh"

class CardDeck2 : public CardDeck 
{
public:

    // Constructors
    CardDeck2(const bool initDeck = false, const bool shadowCopy = false ):CardDeck(initDeck, shadowCopy){};
    CardDeck2(const unsigned int newSize, const bool shadowCopy):CardDeck(newSize, shadowCopy){};
    CardDeck2(const CardDeck& deck):CardDeck(deck){};

    // get a special choice of number cards and store them in the deck
    // the identifier for the choosen cards is 0 <= ident < size! / (size-number)!
    const bool getCards( CardDeck& deck,
                        const unsigned int number,
                        const unsigned int which,
                        bool excludeDoubledCards);

    // save where are the same cards in the deck
    const bool lookForSameCards();

    // init random cards
    const bool initRandomCards( const unsigned int newSize = 5 );
    // init one cards
    double initOneCard( const unsigned int which );
    
    // get number of unused cards
    //const unsigned int getNumberUnusedCards() const { return getNumUnusedCards(); };
    //using CardDeck::getNumUnusedCards();

private:

    // get the number of jjth unused cards
    const unsigned int getUnusedCard(const unsigned int jj) const;

    // return position of given card in deck after position pos0-1
    const unsigned int findNext( const BaseCard* card, unsigned int pos0, const bool unusedOnly = true ) const;

    // information where in the deck are the same cards
    unsigned int sameCards[20];

};

#endif // CARDDECK2_HH
