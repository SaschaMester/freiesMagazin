#-------------------------------------------------------------------------------
# Copyright (c) 2009, Andreas Schiefer
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#     * Redistributions of source code must retain the above copyright notice, 
#       this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the RobotViewer nor the names of its contributors 
#       may be used to endorse or promote products derived from this software
#       without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#-------------------------------------------------------------------------------

from __future__ import with_statement #For Python < 2.6

import logging
from collections import defaultdict

import pyglet

import config
from opengl import *
from consts import *
from model import MapError
from util import texture_file
from cgmath import Vec3, Quaternion
from view import get_map_vertices, Translation, Transformation, InspectCamera
from geometry import MeshData

_texture_cache = {}
def _texture(name, format=GL_RGBA):
    """
    Loads and returns the id of the OpenGL texture for the given name
    """
    if name in _texture_cache:
        logging.info("Loading texture '%s' from cache" % name)
        return _texture_cache[name]
    with pyglet.resource.file(texture_file(name)) as f:
        logging.info("Loading texture from file '%s'..." % f.name)
        img = pyglet.image.load(name, file=f)
    tex = create_texture(img.width, img.height, None, format=format,
                         mipmap=True, anisotropy=config.graphics.anisotropy,
                         wrap=GL_REPEAT)
    img.blit_to_texture(GL_TEXTURE_2D, 0, 0, 0, 0)
    _texture_cache[name] = tex
    return tex

def _get_pos_on_map(map_coords, map_size):
    """
    Translates the grid-position to an offset-vector from the map center
    """
    x_offset = -(map_size[0]) / 2.0
    y_offset = (map_size[1]) / 2.0
    return Vec3((x_offset + map_coords[0] + 0.5,
                 y_offset - map_coords[1] - 0.5,
                 0.0))

_rotation_angles = { LEFT : 90.0, RIGHT : 270.0, UP : 0.0, DOWN : 180.0 }


class BasicRenderer(object):
    """
    Basic OpenGL renderer using fixed function pipeline
    """
    def __init__(self, game):
        """
        Initializes the renderer for the given game
        """
        logging.info("Using basic OpenGL renderer")
        self._game = game
        self._game.views.append(self)
        self._game.push_handlers(self)
        self._camera_type = "global"
        d = self._game.map.get_size()[0] + 1.5
        self._camera = InspectCamera(self._game,
                                     Vec3((0.0, -1.0, 2.0)).normalize() * d,
                                     (0.0, 0.0, 0.0),
                                     (0.0, 0.0, 1.0))
        self._camera.max_sizes = (self._game.map.size[0]/2.0+2.0,
                                  self._game.map.size[1]/2.0+2.0)
        self._skyline_min_size = d * 1.5
        self._map = Map(self._game.map)
        self._skyline = Skyline()
        self._truck_ramp = TruckRamp(self._game.map)
        self._robot = Robot(self._game)
        self._objects = defaultdict(list)
        self._add_map_objects()
    
    def _add_map_objects(self):
        field_objects = {
            FIELD_PUSHER : Pusher,
            FIELD_PRESS : Press,
            FIELD_WALL : Wall,
            FIELD_HOLE : Hole,
            FIELD_CUBE : Box,
            FIELD_ROTATE : Rotator,
            FIELD_CONVEYOR : Conveyor,
        }
        map_size = self._game.map.size
        for x in range(map_size[0]):
            for y in range(map_size[1]):
                field = self._game.map.get_field(x, y)
                if field.fieldtype in field_objects:
                    cls = field_objects[field.fieldtype]
                    pos = _get_pos_on_map((x, y), map_size)
                    self._objects[cls].append(cls(field, self._game.robot, pos,
                                                  self._game.map))
    
    def on_key_press(self, symbol, modifiers):
        """
        Event handler for key presses (used to set different camera types)
        """
        if symbol in (pyglet.window.key._1, pyglet.window.key.NUM_1):
            self._camera_type = "global"
            self._camera.look_at = Vec3((0.0, 0.0, 0.0))
            self._camera.distance = self._game.map.get_size()[0] + 1.5
            self._camera.max_sizes = (self._game.map.size[0]/2.0+2.0,
                                      self._game.map.size[1]/2.0+2.0)
        elif symbol in (pyglet.window.key._2, pyglet.window.key.NUM_2):
            self._camera_type = "robot_pos"
            self._camera.look_at = Vec3((0.0, 0.0, 0.0))
            self._camera.distance = 0.0 #Use min distance of camera
            self._camera.max_sizes = (2.0, 2.0)
        elif symbol in (pyglet.window.key._3, pyglet.window.key.NUM_3):
            self._camera_type = "robot_pos_rot"
            self._camera.look_at = Vec3((0.0, 0.0, 0.0))
            self._camera.distance = 0.0 #Use min distance of camera
            self._camera.max_sizes = (2.0, 2.0)
    
    def setup(self, width, height):
        """
        Gets called before draw() to set up projection and states
        """
        glViewport(0, 0, width, height)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(65, width / float(height), 0.5, 500.0)
        glMatrixMode(GL_MODELVIEW)
        #Setup default flags
        glEnable(GL_NORMALIZE)
        glEnable(GL_ALPHA_TEST)
        glAlphaFunc(GL_GREATER, 0.5)
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_CULL_FACE)
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        glLightfv(GL_LIGHT0, GL_AMBIENT, array((0.3, 0.3, 0.3, 1.0)))
        glLightfv(GL_LIGHT0, GL_DIFFUSE, array((0.8, 0.8, 0.8, 1.0)))
        glLightfv(GL_LIGHT0, GL_POSITION, array((-100.0, 100.0, 100.0, 0.0)))
        glEnableClientState(GL_TEXTURE_COORD_ARRAY)
        glEnableClientState(GL_NORMAL_ARRAY)
        glEnableClientState(GL_VERTEX_ARRAY)
        glEnable(GL_TEXTURE_2D)
        glEnable(GL_COLOR_MATERIAL)
        glColor3f(1.0, 1.0, 1.0)
        self._camera.update()
    
    def draw(self):
        """
        Sets the camera and draws the scene
        """
        glLoadIdentity()
        gluLookAt(self._camera.position[0],
                  self._camera.position[1],
                  self._camera.position[2],
                  self._camera.look_at[0],
                  self._camera.look_at[1],
                  self._camera.look_at[2],
                  self._camera.up[0],
                  self._camera.up[1],
                  self._camera.up[2])
        if self._camera_type in ("robot_pos", "robot_pos_rot"):
            robot_pos, robot_angle, robot_axis = self._robot.transformation
            if self._camera_type == "robot_pos_rot":
                glRotatef(-robot_angle, *robot_axis)
            cam_pos = -robot_pos[0], -robot_pos[1], min(0.0, -robot_pos[2])
            glTranslatef(*cam_pos)
        self._map.draw()
        self._truck_ramp.draw()
        self._robot.draw()
        for cls, instances in self._objects.iteritems():
            cls.bind()
            for obj in instances:
                obj.draw(bind=False)
        d = max(self._skyline_min_size, self._camera.distance)
        glScalef(d, d, d)
        self._skyline.draw()


class Map(object):
    """
    Basic OpenGL renderer for the map
    """
    def __init__(self, model):
        """
        Initializes the map renderer
        """
        self._model = model
        self._setup_map()
    
    def _setup_map(self):
        """
        Sets up the map to render
        """
        self._map_vbo = create_buffer()
        glBindBuffer(GL_ARRAY_BUFFER, self._map_vbo)
        self._map_ibo = create_buffer()
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, self._map_ibo)
        vertices = []
        vertex_count = 0
        for u, v, x, y, z in get_map_vertices(self._model):
            vertices.extend((x, y, z, 0.0, 0.0, 1.0, u, v))
            vertex_count += 1
        indices = []
        for i in range(0, vertex_count, 4):
            indices.extend((i, i+1, i+2))
            indices.extend((i, i+2, i+3))
        self._map_element_count = len(indices)
        glBufferData(GL_ARRAY_BUFFER, len(vertices)*4, array(vertices),
                     GL_STATIC_DRAW)
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, len(indices)*4,
                     array(indices, GLuint), GL_STATIC_DRAW)
        self._tex = _texture(config.graphics.textures.map, format=GL_RGBA)

    def bind(self):
        """
        Binds the VBO and IBO
        Gets called by draw() automatically if not forced to not call bind()
        """
        glBindBuffer(GL_ARRAY_BUFFER, self._map_vbo)
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, self._map_ibo)
        glVertexPointer(3, GL_FLOAT, 32, 0)
        glNormalPointer(GL_FLOAT, 32, 12)
        glTexCoordPointer(2, GL_FLOAT, 32, 24)
        glBindTexture(GL_TEXTURE_2D, self._tex)

    def draw(self, bind=True):
        """
        Draws the map
        """
        if bind:
            self.bind()
        glDrawElements(GL_TRIANGLES, self._map_element_count,
                       GL_UNSIGNED_INT, None)


class TruckRamp(object):
    """
    Truck-Ramp object around the playfield
    """
    def __init__(self, map_model):
        """
        Initializes the truck ramp (with a given map)
        """
        self._map_model = map_model
        self._setup_ramp()
    
    def _get_ramp_points(self):
        """
        Returns all control points needed for the ramp geometry
        """
        x0 = self._map_model.get_size()[0] / 2.0
        y0 = self._map_model.get_size()[1] / 2.0
        z0 = 0.0
        x1 = x0 + 0.5
        y1 = y0 + 0.5
        z1 = -0.1
        x2 = x1 - 0.0625
        y2 = y1 - 0.0625
        z2 = z0 - 0.5
        x3 = x0 + 1.5
        y3 = y0 + 1.5
        return (
            (-x0, -y0, z0), (x0, -y0, z0), (x0, y0, z0), (-x0, y0, z0),
            (-x1, -y1, z0), (x1, -y1, z0), (x1, y1, z0), (-x1, y1, z0),
            (-x1, -y1, z1), (x1, -y1, z1), (x1, y1, z1), (-x1, y1, z1),
            (-x2, -y2, z1), (x2, -y2, z1), (x2, y2, z1), (-x2, y2, z1),
            (-x2, -y2, z2), (x2, -y2, z2), (x2, y2, z2), (-x2, y2, z2),
            (-x3, -y3, z2), (x3, -y3, z2), (x3, y3, z2), (-x3, y3, z2)
        )
    
    def _setup_ramp(self):
        """
        Sets up the ramp geometry with uv layout depending on the map-size
        """
        points = self._get_ramp_points()
        vertices = []
        indices = []
        def add_quad(start_ring, start_index, n, uv):
            offset = 4 * start_ring
            vertices.extend(points[offset+start_index] + n + uv[0])
            vertices.extend(points[offset+(start_index+1)%4] + n + uv[1])
            vertices.extend(points[offset+4+start_index] + n + uv[2])
            vertices.extend(points[offset+4+(start_index+1)%4] + n + uv[3])
        self._ramp_vbo = create_buffer()
        glBindBuffer(GL_ARRAY_BUFFER, self._ramp_vbo)
        self._ramp_ibo = create_buffer()
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, self._ramp_ibo)
        for i, n_side in enumerate(((0.0, -1.0, 0.0), (1.0, 0.0, 0.0),
                                    (0.0, 1.0, 0.0), (-1.0, 0.0, 0.0))):
            if i in (0, 2):
                size = float(self._map_model.get_size()[0])
            else:
                size = float(self._map_model.get_size()[1])
            n = (0.0, 0.0, 1.0)
            add_quad(0, i, n, ((0.0, 0.95), (size, 0.95), (-0.5, 0.75),
                (size + 0.5, 0.75)))
            add_quad(4, i, n, ((-0.5 + 1.0/16.0, 3.0/8.0),
                (size+0.5-1.0/16.0, 3.0/8.0), (-1.5, 0.05), (size + 1.5, 0.05)))
            n = (0.0, 0.0, -1.0)
            add_quad(2, i, n, ((-0.5, 11.0/16.0), (size + 0.5, 11.0/16.0),
                (-0.5 + 1.0/16.0, 21.0/32.0), (size+0.5-1.0/16.0, 21.0/32.0)))
            #Add ground plane, so you can not look through map from below
            uv = (0.05, 0.05)
            vertices.extend(points[16] + n + uv)
            vertices.extend(points[17] + n + uv)
            vertices.extend(points[19] + n + uv)
            vertices.extend(points[18] + n + uv)
            add_quad(1, i, n_side, ((-0.5, 0.75), (size + 0.5, 0.75),
                (-0.5, 11.0/16.0), (size + 0.5, 11.0/16.0)))
            add_quad(3, i, n_side, ((-0.5 + 1.0/16.0, 21.0/32.0),
                (size + 0.5 - 1.0/16.0, 21.0/32.0), (-0.5 + 1.0/16.0, 3.0/8.0),
                (size + 0.5 - 1.0/16.0, 3.0/8.0)))
        for i in range(0, len(vertices) // 8, 4):
            indices.extend((i + 0, i + 2, i + 3, i + 0, i + 3, i + 1))
        self._ramp_element_count = len(indices)
        glBufferData(GL_ARRAY_BUFFER, len(vertices)*4, array(vertices),
                     GL_STATIC_DRAW)
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, len(indices)*4,
                     array(indices, GLuint), GL_STATIC_DRAW)
        self._tex = _texture(config.graphics.textures.truck_ramp)

    def bind(self):
        """
        Binds the VBO and IBO
        Gets called by draw() automatically if not forced to not call bind()
        """
        glBindBuffer(GL_ARRAY_BUFFER, self._ramp_vbo)
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, self._ramp_ibo)
        glVertexPointer(3, GL_FLOAT, 32, 0)
        glNormalPointer(GL_FLOAT, 32, 12)
        glTexCoordPointer(2, GL_FLOAT, 32, 24)
        glBindTexture(GL_TEXTURE_2D, self._tex)

    def draw(self, bind=True):
        """
        Draws the truck-ramp
        """
        if bind:
            self.bind()
        glDrawElements(GL_TRIANGLES, self._ramp_element_count,
                       GL_UNSIGNED_INT, None)


class Mesh(object):
    """
    Base class for all meshes
    """
    def __init__(self, name):
        """
        Loads mesh data and sets up VBO and IBO used to render the mesh
        """
        self._mesh_data = MeshData(name)
        self._setup_mesh()
    
    def _setup_mesh(self):
        """
        Creates the VBO and IBO used to render the mesh
        """
        self._vbo = create_buffer()
        glBindBuffer(GL_ARRAY_BUFFER, self._vbo)
        self._ibo = create_buffer()
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, self._ibo)
        glBufferData(GL_ARRAY_BUFFER, self._mesh_data.data_size,
                     self._mesh_data.data, GL_STATIC_DRAW)
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, self._mesh_data.indices_size,
                     self._mesh_data.indices, GL_STATIC_DRAW)
    
    def bind(self):
        """
        Binds the VBO and IBO
        Gets called by draw() automatically if not forced to not call bind()
        """
        glBindBuffer(GL_ARRAY_BUFFER, self._vbo)
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, self._ibo)
        glVertexPointer(3, GL_FLOAT, 32, 0)
        glNormalPointer(GL_FLOAT, 32, 12)
        glTexCoordPointer(2, GL_FLOAT, 32, 24)
        
    def draw(self, bind=True):
        """
        Draws the mesh
        If bind is set to False, bind() must be called manually before draw.
        This is only usefull if multiple instances of this mesh are drawn one
        after another (safes calls to bind() then)
        """
        if bind:
            self.bind()
        glDrawElements(GL_TRIANGLES, self._mesh_data.index_count,
                       GL_UNSIGNED_INT, None)


class Robot(object):
    """
    Basic OpenGL robot renderer
    """
    _mesh = Mesh(config.graphics.meshes.robot)
    _box = Mesh(config.graphics.meshes.box)
    _tex = _texture(config.graphics.textures.robot, format=GL_RGB)
    _box_tex = _texture(config.graphics.textures.box, format=GL_RGB)
    
    def __init__(self, game):
        """
        Initializes the robot mesh
        """
        self._game = game
        self._game.robot.observers.append(self)
        self._setup_robot()
        self._setup_box()
    
    def _setup_robot(self):
        """
        Sets up the robot to render from the model
        """
        model = self._game.robot
        self._current_coords = model.position
        pos = _get_pos_on_map(self._current_coords, self._game.map.size)
        angle = _rotation_angles[model.orientation]
        rot = Quaternion.from_angle_axis(angle, (0.0, 0.0, 1.0))
        self._transformation = Transformation(pos, rot)
        self._scale = Translation(Vec3((1.0, 1.0, 1.0)))
    
    def _setup_box(self):
        rot = Quaternion.identity()
        self._box_transformation = Transformation((0.0, 0.275, 0.5), rot)
    
    def _check_state(self):
        """
        Checks for changes in the robots state (finished movement, etc.)
        """
        if (self._game.robot.state in (STATE_MOVING, STATE_PUSHED) and
            not self._transformation.moving):
            self._game.dispatch_event("on_state_finished")
    
    def _handle_pressed(self, field):
        """
        Handles the animation if the robot gets pressed on a FIELD_PRESS
        """
        self._scale.move_to(Vec3((0.33, 1.0, 1.0)), MOVE_DURATION * 0.5)
        self._transformation.rotate_to(self._transformation.rotation,
                                     MOVE_DURATION * 0.7)
        if UP in field.direction:
            rot = (Quaternion.from_angle_axis(30.0, Vec3((1.0, 0.0, 0.0))) *
                   self._transformation.rotation)
        else:
            rot = (Quaternion.from_angle_axis(30.0, Vec3((0.0, 1.0, 0.0))) *
                   self._transformation.rotation)
        self._transformation.rotate_to(rot, MOVE_DURATION)
    
    def _handle_fall_in_hole(self, field):
        """
        Handles the animation if the robot falls into a FIELD_HOLE
        """
        move = Vec3((0.0, 0.0, -1.5))
        self._scale.move_to(Vec3((1.0, 1.0, 1.0)), 0.25)
        self._scale.move_to(Vec3((0.5, 0.5, 0.5)), 0.5)
        self._transformation.move_to(self._transformation.position + move,
                                     MOVE_DURATION * 0.75)
        pos = self._box_transformation.position
        rot = (Quaternion.from_angle_axis(165.0, Vec3((1.0, 0.0, 0.0))) *
               self._box_transformation.rotation)
        self._box_transformation.move_to(pos - move, MOVE_DURATION * 0.75)
        self._box_transformation.move_to(pos, MOVE_DURATION * 0.75)
        self._box_transformation.rotate_to(rot, MOVE_DURATION)
    
    def _fall_off_up(self):
        rot = Quaternion.from_angle_axis(90, Vec3((-1.0, 0.0, 0.0)))
        if self._game.robot.orientation == UP:
            rot = Quaternion.from_angle_axis(90, (0.0, 1.0, 0.0)) * rot
        trans = Vec3((0.0, 0.25, -0.2))
        rot = rot * self._transformation.rotation
        self._transformation.rotate_to(rot, MOVE_DURATION * 0.5)
        self._transformation.move_to(self._transformation.position,
                                     MOVE_DURATION * 0.25)
        self._transformation.move_to(self._transformation.position + trans,
                                     MOVE_DURATION * 0.25)
        # Box
        box_pos = Vec3(self._box_transformation.position)
        box_rot = self._box_transformation.rotation
        offset = { UP : 0.1, LEFT : 0.1, RIGHT : -0.1, DOWN : 0.0 }
        self._box_transformation.transform_to(box_pos, box_rot,
                                              MOVE_DURATION * 0.4)
        self._box_transformation.transform_to(box_pos +
            Vec3((offset[self._game.robot.orientation], 0.0, 0.4)),
            box_rot, MOVE_DURATION * 0.25)
        if self._game.robot.orientation == DOWN:
            rot = Quaternion.from_angle_axis(90.0, Vec3((1.0, 0.0, 0.0)))
            self._box_transformation.transform_to(
                box_pos + Vec3((0.0, -0.2, 0.7)), box_rot * rot,
                MOVE_DURATION * 0.3)

    def _fall_off_left(self):
        rot = Quaternion.from_angle_axis(90, Vec3((0.0, -1.0, 0.0)))
        if self._game.robot.orientation == LEFT:
            rot = Quaternion.from_angle_axis(90, (1.0, 0.0, 0.0)) * rot
        trans = Vec3((-0.25, 0.0, -0.2))
        rot = rot * self._transformation.rotation
        self._transformation.rotate_to(rot, MOVE_DURATION * 0.5)
        self._transformation.move_to(self._transformation.position,
                                     MOVE_DURATION * 0.25)
        self._transformation.move_to(self._transformation.position + trans,
                                     MOVE_DURATION * 0.25)
        # Box
        box_pos = Vec3(self._box_transformation.position)
        box_rot = self._box_transformation.rotation
        offset = { UP : -0.1, LEFT : -0.1, RIGHT : 0.0, DOWN : 0.1 }
        self._box_transformation.transform_to(box_pos, box_rot,
                                              MOVE_DURATION * 0.4)
        self._box_transformation.transform_to(box_pos +
            Vec3((offset[self._game.robot.orientation], 0.0, 0.4)),
            box_rot, MOVE_DURATION * 0.25)
        if self._game.robot.orientation == RIGHT:
            rot = Quaternion.from_angle_axis(90.0, Vec3((1.0, 0.0, 0.0)))
            self._box_transformation.transform_to(
                box_pos + Vec3((0.0, -0.2, 0.7)), box_rot * rot,
                MOVE_DURATION * 0.3)

    def _fall_off_right(self):
        rot = Quaternion.from_angle_axis(90, Vec3((0.0, 1.0, 0.0)))
        if self._game.robot.orientation == RIGHT:
            rot = Quaternion.from_angle_axis(90, (1.0, 0.0, 0.0)) * rot
        trans = Vec3((0.25, 0.0, -0.2))
        rot = rot * self._transformation.rotation
        self._transformation.rotate_to(rot, MOVE_DURATION * 0.5)
        self._transformation.move_to(self._transformation.position,
                                     MOVE_DURATION * 0.25)
        self._transformation.move_to(self._transformation.position + trans,
                                     MOVE_DURATION * 0.25)
        # Box
        box_pos = Vec3(self._box_transformation.position)
        box_rot = self._box_transformation.rotation
        offset = { UP : 0.1, LEFT : 0.0, RIGHT : 0.1, DOWN : -0.1 }
        self._box_transformation.transform_to(box_pos, box_rot,
                                              MOVE_DURATION * 0.4)
        self._box_transformation.transform_to(box_pos +
            Vec3((offset[self._game.robot.orientation], 0.0, 0.4)),
            box_rot, MOVE_DURATION * 0.25)
        if self._game.robot.orientation == LEFT:
            rot = Quaternion.from_angle_axis(90.0, Vec3((1.0, 0.0, 0.0)))
            self._box_transformation.transform_to(
                box_pos + Vec3((0.0, -0.2, 0.7)), box_rot * rot,
                MOVE_DURATION * 0.3)

    def _fall_off_down(self):
        rot = Quaternion.from_angle_axis(90, Vec3((1.0, 0.0, 0.0)))
        if self._game.robot.orientation == DOWN:
            rot = Quaternion.from_angle_axis(90, (0.0, 1.0, 0.0)) * rot
        trans = Vec3((0.0, -0.25, -0.2))
        rot = rot * self._transformation.rotation
        self._transformation.rotate_to(rot, MOVE_DURATION * 0.5)
        self._transformation.move_to(self._transformation.position,
                                     MOVE_DURATION * 0.25)
        self._transformation.move_to(self._transformation.position + trans,
                                     MOVE_DURATION * 0.25)
        # Box
        box_pos = Vec3(self._box_transformation.position)
        box_rot = self._box_transformation.rotation
        offset = { UP : 0.0, LEFT : -0.1, RIGHT : 0.1, DOWN : -0.1 }
        self._box_transformation.transform_to(box_pos, box_rot,
                                              MOVE_DURATION * 0.4)
        self._box_transformation.transform_to(box_pos +
            Vec3((offset[self._game.robot.orientation], 0.0, 0.4)),
            box_rot, MOVE_DURATION * 0.25)
        if self._game.robot.orientation == UP:
            rot = Quaternion.from_angle_axis(90.0, Vec3((1.0, 0.0, 0.0)))
            self._box_transformation.transform_to(
                box_pos + Vec3((0.0, -0.2, 0.7)), box_rot * rot,
                MOVE_DURATION * 0.3)

    def _handle_fall_off_field(self):
        """
        Handle animation when robot falls off the playfield
        """
        pos = self._game.robot.position
        if pos[0] < 0:
            self._fall_off_left()
        elif pos[1] < 0:
            self._fall_off_up()
        elif pos[0] >= self._game.map.get_size()[0]:
            self._fall_off_right()
        elif pos[1] >= self._game.map.get_size()[1]:
            self._fall_off_down()

    def _handle_finish(self):
        """
        Handles animation when robot finishes
        """
        translations = {
            LEFT : Vec3((0.2, 0.0, 0.0)),
            RIGHT : Vec3((-0.2, 0.0, 0.0)),
            UP : Vec3((0.0, -0.2, 0.0)),
            DOWN : Vec3((0.0, 0.2, 0.0)),
        }
        curr_rot = self._transformation.rotation
        next_rot = Quaternion.from_angle_axis(10.0, Vec3((1.0, 0.0, 0.0)))
        next_rot = curr_rot * next_rot
        curr_pos = self._transformation.position
        next_pos = curr_pos + translations[self._game.robot.orientation]
        self._transformation.rotate_to(next_rot, MOVE_DURATION * 0.1)
        self._transformation.rotate_to(curr_rot, MOVE_DURATION * 0.2)
        self._transformation.move_to(curr_pos, MOVE_DURATION * 0.25)
        self._transformation.move_to(next_pos, MOVE_DURATION * 0.25)
        box_pos0 = Vec3(self._box_transformation.position)
        box_pos1 = box_pos0 + Vec3((0.0, 0.010, 0.1))
        box_pos2 = box_pos0 + Vec3((0.0, 0.215, 0.2))
        box_pos3 = box_pos0 + Vec3((0.0, 0.225, -0.5))
        self._box_transformation.move_to(box_pos0, MOVE_DURATION * 0.1)
        self._box_transformation.move_to(box_pos1, MOVE_DURATION * 0.15)
        self._box_transformation.move_to(box_pos2, MOVE_DURATION * 0.25)
        self._box_transformation.move_to(box_pos3, MOVE_DURATION * 0.5)
    
    def _get_transformation(self):
        self._transformation.update()
        pos = self._transformation.position
        angle, axis = self._transformation.rotation.get_angle_axis()
        return pos, angle, axis
    transformation = property(_get_transformation)
    
    def on_position_change(self, pos):
        """
        Gets called if the position of the robot-model changed
        """
        next_pos = _get_pos_on_map(pos, self._game.map.size)
        self._transformation.move_to(next_pos, MOVE_DURATION)
    
    def on_orientation_change(self, rot):
        """
        Gets called if the orientation of the robot-model changed
        """
        next_angle = _rotation_angles[rot]
        next_rot = Quaternion.from_angle_axis(next_angle, (0.0, 0.0, 1.0))
        self._transformation.rotate_to(next_rot, MOVE_DURATION)
    
    def on_state_change(self, state):
        """
        Gets called if the robots state changes (e.g. if it dies)
        """
        if state == STATE_DEAD:
            try:
                field = self._game.map.get_field(*self._game.robot.position)
            except MapError:
                self._handle_fall_off_field()
                return
            field_actions =  { FIELD_PRESS : self._handle_pressed,
                               FIELD_HOLE : self._handle_fall_in_hole }
            if field.fieldtype in field_actions:
                field_actions[field.fieldtype](field)
        elif state == STATE_FINISH:
            self._handle_finish()
        elif state == STATE_IDLE: #Reset all (for game restart)
            self._setup_robot()
            self._setup_box()
            self._game.robot.state = STATE_MOVING

    
    def on_get_pushed(self, direction):
        """
        Gets called if the robot gets pushed (put position does not change)
        """
        next_rot = {
            LEFT : Quaternion.from_angle_axis(5, (0.0, 1.0, 0.0)),
            RIGHT : Quaternion.from_angle_axis(5, (0.0, -1.0, 0.0)),
            UP : Quaternion.from_angle_axis(5, (-1.0, 0.0, 0.0)),
            DOWN : Quaternion.from_angle_axis(5, (1.0, 0.0, 0.0)),
        }[direction]
        move = {
            LEFT : Vec3((-0.2, 0.0, 0.05)),
            RIGHT : Vec3((0.2, 0.0, 0.05)),
            UP : Vec3((0.0, 0.2, 0.05)),
            DOWN : Vec3((0.0, -0.2, 0.05)),
        }[direction]
        next_rot = next_rot * self._transformation.rotation
        next_pos = self._transformation.position + move
        self._transformation.transform_to(next_pos, next_rot,
                                          MOVE_DURATION * 0.4)
        self._transformation.transform_to(next_pos, next_rot,
                                          MOVE_DURATION * 0.2)
        self._transformation.transform_to(self._transformation.position,
                                          self._transformation.rotation,
                                          MOVE_DURATION * 0.4)
    
    @classmethod
    def bind(cls):
        pass
    
    def draw(self, bind=True):
        """
        Draws the robot
        """
        glBindTexture(GL_TEXTURE_2D, self._tex)
        self._check_state()
        self._transformation.update()
        self._box_transformation.update()
        self._scale.update()
        pos = self._transformation.position
        angle, axis = self._transformation.rotation.get_angle_axis()
        glPushMatrix()
        glTranslatef(*pos)
        glRotatef(angle, *axis)
        glScalef(*self._scale.position)
        self._mesh.draw()
        pos = self._box_transformation.position
        angle, axis = self._box_transformation.rotation.get_angle_axis()
        glTranslatef(*pos)
        glRotatef(angle, *axis)
        glBindTexture(GL_TEXTURE_2D, self._box_tex)
        self._box.draw()
        glPopMatrix()


class Pusher(object):
    """
    Pusher object
    """
    _fixed = Mesh(config.graphics.meshes.pusher_fixed)
    _anchor = Mesh(config.graphics.meshes.pusher_anchor)
    _pusher = Mesh(config.graphics.meshes.pusher)
    _tex = _texture(config.graphics.textures.pusher, GL_RGB)
    
    def __init__(self, field, robot, pos, map):
        self._field = field
        self._robot = robot
        self._robot.observers.append(self)
        rot = Quaternion.from_angle_axis(_rotation_angles[field.direction],
                                         Vec3((0.0, 0.0, 1.0)))
        self._transformation = Transformation(pos, rot)
        self._pusher_offset = Translation(Vec3((0.0, 0.0, 0.0)))
        self._robot_is_on_field = False
    
    def on_position_change(self, pos):
        """
        Gets called if the robots position changes
        """
        if self._robot_is_on_field and self._robot.state == STATE_PUSHED:
            move = Vec3((0.0, 0.2, 0.0))
            self._pusher_offset.move_to(move, MOVE_DURATION * 0.2)
            self._pusher_offset.move_to(move, MOVE_DURATION * 0.2)
            self._pusher_offset.move_to(Vec3((0.0, 0.0, 0.0)),
                                         MOVE_DURATION * 0.2)
        self._robot_is_on_field = (self._field.coords == self._robot.position)

    def on_get_pushed(self, direction):
        """
        Gets called if the robot gets pushed (put position does not change)
        """
        if self._robot_is_on_field and self._robot.state == STATE_PUSHED:
            move = Vec3((0.0, 0.2, 0.0))
            self._pusher_offset.move_to(move, MOVE_DURATION * 0.4)
            self._pusher_offset.move_to(move, MOVE_DURATION * 0.2)
            self._pusher_offset.move_to(Vec3((0.0, 0.0, 0.0)),
                                         MOVE_DURATION * 0.4)
    
    @classmethod
    def bind(cls):
        glBindTexture(GL_TEXTURE_2D, cls._tex)
    
    def draw(self, bind=True):
        if bind:
            self.bind()
        self._transformation.update()
        self._pusher_offset.update()
        glPushMatrix()
        glTranslatef(*self._transformation.position)
        angle, axis = self._transformation.rotation.get_angle_axis()
        glRotatef(angle, *axis)
        self._fixed.draw()
        glTranslatef(*self._pusher_offset.position * 0.75)
        self._anchor.draw()
        glTranslatef(*self._pusher_offset.position * 0.25)
        self._pusher.draw()
        glPopMatrix()


class Press(object):
    """
    Press object
    """
    _fixed = Mesh(config.graphics.meshes.pusher_fixed)
    _anchor = Mesh(config.graphics.meshes.pusher_anchor)
    _pusher = Mesh(config.graphics.meshes.pusher)
    _tex = _texture(config.graphics.textures.pusher, GL_RGB)
    
    def __init__(self, field, robot, pos, map):
        self._field = field
        self._robot = robot
        self._robot.observers.append(self)
        rot = Quaternion.from_angle_axis(_rotation_angles[field.direction[0]],
                                         Vec3((0.0, 0.0, 1.0)))
        self._transformation = Transformation(pos, rot)
        self._pusher_offset = Translation(Vec3((0.0, 0.0, 0.0)))
        self._robot_is_on_field = False
    
    def on_state_change(self, state):
        """
        Gets called if the robots state changes
        """
        self._robot_is_on_field = (self._field.coords == self._robot.position)
        if self._robot_is_on_field and self._robot.state == STATE_DEAD:
            move = Vec3((0.0, 0.2, 0.0))
            self._pusher_offset.move_to(move, MOVE_DURATION * 0.5)
            self._pusher_offset.move_to(move, MOVE_DURATION * 0.2)
            self._pusher_offset.move_to(Vec3((0.0, 0.0, 0.0)),
                                         MOVE_DURATION * 0.3)
    
    @classmethod
    def bind(cls):
        glBindTexture(GL_TEXTURE_2D, cls._tex)
    
    def draw(self, bind=True):
        if bind:
            self.bind()
        self._transformation.update()
        self._pusher_offset.update()
        glPushMatrix()
        glTranslatef(*self._transformation.position)
        angle, axis = self._transformation.rotation.get_angle_axis()
        glRotatef(angle, *axis)
        self._fixed.bind()
        self._fixed.draw(False)
        glRotatef(180.0, 0.0, 0.0, 1.0)
        self._fixed.draw(False)
        self._anchor.bind()
        glTranslatef(*self._pusher_offset.position * 0.75)
        self._anchor.draw(False)
        glTranslatef(*self._pusher_offset.position * -0.75)
        glRotatef(180.0, 0.0, 0.0, 1.0)
        glTranslatef(*self._pusher_offset.position * 0.75)
        self._anchor.draw(False)
        glTranslatef(*self._pusher_offset.position * -0.75)
        self._pusher.bind()
        glTranslatef(*self._pusher_offset.position)
        self._pusher.draw(False)
        glTranslatef(*self._pusher_offset.position * -1.0)
        glRotatef(180.0, 0.0, 0.0, 1.0)
        glTranslatef(*self._pusher_offset.position)
        self._pusher.draw(False)
        glPopMatrix()


class Wall(object):
    """
    Walls for one field
    """
    _mesh = Mesh(config.graphics.meshes.wall)
    _tex = _texture(config.graphics.textures.wall, GL_RGB)
    
    def __init__(self, field, robot, pos, map):
        """
        Initializes the wall at the given position for the given field
        (robot is not used by the wall)
        """
        self._field = field
        self._translation = Translation(pos)

    @classmethod
    def bind(cls):
        cls._mesh.bind()
        glBindTexture(GL_TEXTURE_2D, cls._tex)

    def draw(self, bind=True):
        """
        Draws a wall for every side stored in field.direction
        If bind is True, bind the mesh automatically before drawing
        """
        if bind:
            self.bind()
        self._translation.update()
        glPushMatrix()
        glTranslatef(*self._translation.position)
        for side in self._field.direction:
            glRotatef(_rotation_angles[side], 0.0, 0.0, 1.0)
            self._mesh.draw(False)
            glRotatef(-_rotation_angles[side], 0.0, 0.0, 1.0) #undo rotation
        glPopMatrix()


class Hole(object):
    """
    Hole geometry
    """
    _mesh = Mesh(config.graphics.meshes.hole)
    _tex = _texture(config.graphics.textures.hole, GL_RGB)
    
    def __init__(self, field, robot, pos, map):
        """
        Initializes the hole at the given position for the given field
        (robot is not used by the hole)
        """
        self._field = field
        self._translation = Translation(pos)

    @classmethod
    def bind(cls):
        cls._mesh.bind()
        glBindTexture(GL_TEXTURE_2D, cls._tex)

    def draw(self, bind=True):
        """
        Draws the hole geometry
        If bind is True, bind the mesh automatically before drawing
        """
        if bind:
            self.bind()
        self._translation.update()
        glPushMatrix()
        glTranslatef(*self._translation.position)
        self._mesh.draw(False)
        glPopMatrix()


class Box(object):
    """
    Boxes on a blocked field
    """
    _wood_mesh = Mesh(config.graphics.meshes.wood)
    _box_mesh = Mesh(config.graphics.meshes.box)
    _tex = _texture(config.graphics.textures.box, GL_RGB)
    
    def __init__(self, field, robot, pos, map):
        """
        Initializes the boxes at the given position for the given field
        (robot is not used by the box)
        """
        self._field = field
        self._translation = Translation(pos)

    @classmethod
    def bind(cls):
        glBindTexture(GL_TEXTURE_2D, cls._tex)

    def draw(self, bind=True):
        """
        Draws the geometry of the boxes
        If bind is True, bind the mesh automatically before drawing
        """
        if bind:
            self.bind()
        self._translation.update()
        glPushMatrix()
        glTranslatef(*self._translation.position)
        #Draw wooden spacer
        glPushMatrix()
        self._wood_mesh.bind()
        for translation in ((-0.25, 0.25, 0.0), (0.5, 0.0, 0.0),
            (-0.5, -0.5, 0.0), (0.5, 0.0, 0.0)):
            glTranslatef(*translation)
            self._wood_mesh.draw(False)
        glPopMatrix()
        #Draw Boxes
        self._box_mesh.bind()
        for translation in ((-0.25, 0.25, 0.05), (0.5, 0.0, 0.0),
            (-0.5, -0.5, 0.0), (0.5, 0.0, 0.0), (0.0, 0.0, 0.4),
            (-0.5, 0.0, 0.0), (0.5, 0.5, 0.0), (-0.5, 0.0, 0.0)):
            glTranslatef(*translation)
            self._box_mesh.draw(False)
        glPopMatrix()


class Rotator(object):
    """
    Rotation disk geometry
    """
    _mesh = Mesh(config.graphics.meshes.rotator)
    _left_tex = _texture(config.graphics.textures.rotate_l, GL_RGB)
    _right_tex = _texture(config.graphics.textures.rotate_r, GL_RGB)
    _rotation = { LEFT : 90.0, RIGHT : -90.0 }
    
    def __init__(self, field, robot, pos, map):
        """
        Initializes the rotation disk at the given position for the given field
        """
        self._field = field
        self._robot = robot
        if field.direction == LEFT:
            self._used_tex = self._left_tex
        else:
            self._used_tex = self._right_tex
        self._angle = self._rotation[field.direction]
        robot.observers.append(self)
        self._transformation = Transformation(pos, Quaternion.identity())
        self._robot_is_on_field = False
    
    def on_position_change(self, pos):
        """
        Gets called if the position of the robot-model changed
        """
        self._robot_is_on_field = (self._field.coords == self._robot.position)
    
    def on_orientation_change(self, rot):
        """
        Gets called if the orientation of the robot-model changed
        """
        if self._robot_is_on_field and self._robot.state == STATE_PUSHED:
            next_rot = self._transformation.rotation
            next_rot *= Quaternion.from_angle_axis(self._angle, (0.0, 0.0, 1.0))
            self._transformation.rotate_to(next_rot, MOVE_DURATION)

    @classmethod
    def bind(cls):
        cls._mesh.bind()

    def draw(self, bind=True):
        """
        Draws the rotator geometry
        If bind is True, bind the mesh automatically before drawing
        """
        if bind:
            self.bind()
        self._transformation.update()
        glBindTexture(GL_TEXTURE_2D, self._used_tex)
        glPushMatrix()
        glTranslatef(*self._transformation.position)
        angle, axis = self._transformation.rotation.get_angle_axis()
        glRotatef(angle, *axis)
        self._mesh.draw(False)
        glPopMatrix()


class Conveyor(object):
    """
    Conveyor belt geometry
    """
    _conveyor = Mesh(config.graphics.meshes.conveyor)
    _belt = Mesh(config.graphics.meshes.conveyor_belt)
    _conveyor_tex = _texture(config.graphics.textures.conveyor, GL_RGB)
    _belt_tex = _texture(config.graphics.textures.conveyor_belt, GL_RGB)
    _rotation = { LEFT : 0.0, RIGHT : 180.0, UP : -90.0, DOWN : 90.0 }
    
    def __init__(self, field, robot, pos, map):
        """
        Initializes the rotation disk at the given position for the given field
        """
        self._field = field
        self._map = map
        self._robot = robot
        robot.observers.append(self)
        rot = Quaternion.from_angle_axis(self._rotation[field.direction],
                                         (0.0, 0.0, 1.0))
        self._transformation = Transformation(pos, rot)
        self._belt_translation = Translation(Vec3((0.0, 0.0, 0.0)))
        self._robot_is_on_field = False
        self._is_on_any_conveyor = False
    
    def on_position_change(self, pos):
        """
        Gets called if the position of the robot-model changed
        """
        if self._robot_is_on_field and self._robot.state == STATE_PUSHED:
            self._belt_translation.move_to((-1.0, 0.0, 0.0), MOVE_DURATION)
        self._robot_is_on_field = (self._field.coords == self._robot.position)
        if (self._robot_is_on_field and self._robot.state == STATE_PUSHED and
            self._is_on_any_conveyor):
            self._belt_translation.move_to((-1.0, 0.0, 0.0), MOVE_DURATION)
        try:
            field = self._map.get_field(*pos)
            if field.fieldtype == FIELD_CONVEYOR:
                self._is_on_any_conveyor = True
            else:
                self._is_on_any_conveyor = False
        except MapError:
            pass

    def _check_state(self):
        """
        Checks if the animation has finished (and resets it)
        """
        if (self._robot.state in (STATE_MOVING, STATE_PUSHED) and
            not self._belt_translation.moving):
            self._belt_translation.position = Vec3((0.0, 0.0, 0.0))

    @classmethod
    def bind(cls):
        pass

    def draw(self, bind=True):
        """
        Draws the conveyor belt geometry
        """
        self._check_state()
        self._transformation.update()
        self._belt_translation.update()
        glPushMatrix()
        glTranslatef(*self._transformation.position)
        angle, axis = self._transformation.rotation.get_angle_axis()
        glRotatef(angle, *axis)
        glBindTexture(GL_TEXTURE_2D, self._conveyor_tex)
        self._conveyor.draw()
        glBindTexture(GL_TEXTURE_2D, self._belt_tex)
        glMatrixMode(GL_TEXTURE)
        glLoadIdentity()
        glTranslatef(*self._belt_translation.position)
        self._belt.draw()
        glLoadIdentity()
        glMatrixMode(GL_MODELVIEW)
        glPopMatrix()


class Skyline(object):
    """
    Skyline geometry
    """
    _mesh = Mesh(config.graphics.meshes.skyline)
    _tex = _texture(config.graphics.textures.skyline, GL_RGB)
    
    def __init__(self):
        """
        Initializes the skyline
        """
        pass

    @classmethod
    def bind(cls):
        cls._mesh.bind()
        glBindTexture(GL_TEXTURE_2D, cls._tex)

    def draw(self, bind=True):
        """
        Draws the skyline
        If bind is True, bind the mesh automatically before drawing
        """
        if bind:
            self.bind()
        glPushMatrix()
        self._mesh.draw(False)
        glPopMatrix()
