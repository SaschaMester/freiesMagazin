#-------------------------------------------------------------------------------
# Copyright (c) 2009, Andreas Schiefer
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#     * Redistributions of source code must retain the above copyright notice, 
#       this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the RobotViewer nor the names of its contributors 
#       may be used to endorse or promote products derived from this software
#       without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#-------------------------------------------------------------------------------
from __future__ import with_statement #For Python < 2.6

try:
    import json
except ImportError:
    import simplejson as json
import logging

import pyglet

import config
from opengl import array, GLuint
from util import mesh_file


class MeshData(object):
    def __init__(self, name):
        filename = mesh_file(name)
        logging.info("Loading indexed mesh from file '%s'..." % filename)
        with pyglet.resource.file(filename) as mesh:
            self._load_mesh_from_file(mesh)

    def _load_mesh_from_file(self, f):
        mesh = json.load(f)
        self.indices = array(mesh["indices"], GLuint)
        self.index_count = len(mesh["indices"])
        self.indices_size = self.index_count * 4
        self.data = array(mesh["co_no_uv"])
        self.data_size = len(mesh["co_no_uv"]) * 4


class MeshDataUnindexed(object):
    """
    Holds unindexed mesh data
    For every occurance of an index, the vertex data is duplicated
    Suitable for rendering with e.g. glDrawArrays
    """
    def __init__(self, name):
        filename = mesh_file(name)
        logging.info("Loading unindexed mesh from file '%s'..." % filename)
        with pyglet.resource.file(filename) as mesh:
            self._load_mesh_from_file(mesh)

    def _load_mesh_from_file(self, f):
        mesh = json.load(f)
        data = mesh["co_no_uv"]
        unindexed = []
        for index in mesh["indices"]:
            i = index * 8
            unindexed.extend(data[i:i+8])
        self.data = array(unindexed)
        self.data_size = len(unindexed) * 4
        self.vertex_count = len(mesh["indices"])
