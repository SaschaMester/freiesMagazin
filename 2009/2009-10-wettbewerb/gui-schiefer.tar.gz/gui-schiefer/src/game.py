#-------------------------------------------------------------------------------
# Copyright (c) 2009, Andreas Schiefer
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#     * Redistributions of source code must retain the above copyright notice, 
#       this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the RobotViewer nor the names of its contributors 
#       may be used to endorse or promote products derived from this software
#       without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#-------------------------------------------------------------------------------
from __future__ import with_statement #For Python < 2.6

import logging

import pyglet

import config
from opengl import *
from util import texture_file
from consts import MIN_FPS
from model import Map, Robot


def get_window_config():
    multisample = config.graphics.multisample
    if multisample > 0:
        return Config(sample_buffers=1, samples=multisample, double_buffer=True,
                      depth_size=config.graphics.depth_size)
    else:
        return Config(double_buffer=True, depth_size=config.graphics.depth_size)


class Game(pyglet.window.Window):
    """
    Main game class
    Creates a window, holds all game state (the models) and calls .draw() on
    each attached view (in the order they were added)
    """
    def __init__(self, *args, **kwargs):
        """
        Initializes the window (see pyglet.window.Window for parameters)
        """
        super(Game, self).__init__(*args, **kwargs)
        pyglet.resource.path[:] = [config.paths.data]
        pyglet.resource.reindex()
        self.map = None
        self.robot = None
        self.views = []
        self.round = 0
        self.card_round = 0
        self.card_total = 0
        self.finished = False
        self.was_error = False
        self.error_msg = ""
        self._first_run = True
        pyglet.clock.schedule_interval(self._update, 1.0/MIN_FPS)
        self._show_loading_screen()
    
    def _show_loading_screen(self):
        # Provide a simple loading screen while everything will be initialized
        name = "loading_scene.png"
        with pyglet.resource.file(texture_file(name)) as f:
            loading_image = pyglet.image.load(name, file=f)
            loading_sprite = pyglet.sprite.Sprite(loading_image)
            loading_sprite.scale = self.height/768.0
            loading_sprite.x = (self.width-loading_sprite.width)//2
            loading_sprite.y = (self.height-loading_sprite.height)//2
        self.clear()
        # Must setup 2d projection, because context is not yet inizialized by
        # the pyglet window (this happens when event-processing starts)
        glViewport(0, 0, self.width, self.height)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        glOrtho(0, self.width, 0, self.height, -1, 1)
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        loading_sprite.draw()
        self.flip()
    
    def _update(self, dt):
        """
        Does nothing, just ensures that the window gets refreshed
        """
    
    def load_map(self, filename):
        """
        Loads a map from a file
        """
        self._map_filename = filename
        self.map = Map.from_file(filename)
        start_pos = self.map.get_start_pos()
        start_field = self.map.get_field(*start_pos)
        self.robot = Robot(start_pos, start_field.direction)
    
    def start(self):
        """
        Starts the mainloop of the game (and returns when the game is closed)
        """
        logging.info("Starting main loop...")
        pyglet.app.run()
    
    def restart(self):
        """
        Restarts the current game
        """
        logging.info("Restarting game")
        self.round = 0
        self.card_round = 0
        self.card_total = 0
        self.finished = False
        self.was_error = False
        self.error_msg = ""
        self._first_run = False
        old_robot = self.robot
        self.load_map(self._map_filename)
        new_robot = self.robot
        self.robot = old_robot
        self.robot.position = new_robot.position
        self.robot.orientation = new_robot.orientation
        self.robot.state = new_robot.state
        self.dispatch_event("on_restart_game")

    def on_draw(self):
        """
        Event handler that clears the window and draws all views
        """
        if self._first_run:
            self.dispatch_event("on_state_finished")
            self._first_run = False
        self.clear()
        for view in self.views:
            view.setup(self.width, self.height)
            view.draw()

Game.register_event_type("on_state_finished")
Game.register_event_type("on_restart_game")
