#-------------------------------------------------------------------------------
# Copyright (c) 2009, Andreas Schiefer
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#     * Redistributions of source code must retain the above copyright notice, 
#       this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the RobotViewer nor the names of its contributors 
#       may be used to endorse or promote products derived from this software
#       without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#-------------------------------------------------------------------------------
import logging
import timeit

from simplui import *

import config
from opengl import *
from util import GameClock


class StatusGUI(object):
    """
    Simple status gui that displays some basic information
    """
    def __init__(self, game):
        """
        Initializes the gui
        Registers itself at the Game object so that it gets drawn by it in
        on_draw() along with other views
        """
        logging.info("Using basic status GUI")
        self._game = game
        self._game.views.append(self)
        self._game.push_handlers(self)
        self._clock = GameClock()
        self._change_time = None
        self._setup_gui(config.paths.data + "/" + config.paths.themes +
                        config.graphics.theme)

    def _setup_gui(self, theme):
        """
        Creates the GUI dialog
        """
        win_size = (self._game.width, self._game.height)
        self._frame = Frame(Theme(theme), w=win_size[0], h=win_size[1])
        self._game.push_handlers(self._frame)
        self._pause_speed_label = Label("Speed: PAUSE ")
        self._speed_slider = Slider(w=75, min=0.25, max=10.0, value=1.0,
                                    action=self._on_speed_change)
        self._pause_toggle = Checkbox('Pause', action=self._on_toggle_pause)
        self._error_label = Label("")
        dialog = Dialogue("RobotViewer", x=win_size[0]-290, y=win_size[1]-25,
                          content=
            VLayout(autosizex=True, hpadding=0, vpadding=0, children=[
                HLayout(autosizex=True, hpadding=0, children=[
                    self._pause_speed_label,
                    VLayout(autosizex=True, hpadding=0, vpadding=0, children=[
                        HLayout(autosizex=True, hpadding=0, vpadding=0,
                                children=[self._speed_slider]),
                        self._pause_toggle,
                    ]),
                    Button("Restart", action=self._on_restart_click),
                    Button("Quit", action=self._on_close_click)
                ]),
                self._error_label,
            ])
        )
        self._frame.add(dialog)

    def _on_speed_change(self, slider):
        self._clock.speed = slider.value
        slider.value += 0.001
    
    def _on_toggle_pause(self, chkbox):
        if not self._game.was_error:
            self._clock.pause = chkbox.value

    def _on_restart_click(self, button):
        self._game.restart()

    def _on_close_click(self, button):
        self._game.close()
    
    def on_mouse_drag(self, x, y, dx, dy, buttons, modifiers):
        #Hackish way to check if dialog is moved, then don't propagate the
        #on_mouse_drag event further (to prevent camera movement etc)
        if self._frame.children[0]._in_drag:
            return pyglet.event.EVENT_HANDLED
    
    def setup(self, width, height):
        """
        Sets up the projection for this view and some common state
        """
        glViewport(0, 0, width, height)
        glMatrixMode(gl.GL_PROJECTION)
        glLoadIdentity()
        glOrtho(0, width, 0, height, -1, 1)
        glMatrixMode(gl.GL_MODELVIEW)
        glLoadIdentity()
        glColor4f(0.9, 0.9, 0.9, 0.8)
        glDisable(GL_DEPTH_TEST)
        glDisable(GL_LIGHTING)

    def draw(self):
        """
        Updates some labels and draws the GUI
        """
        tick = timeit.default_timer()
        if self._game.was_error:
            self._clock.pause = True
            self._error_label.text = " ERROR: " + self._game.error_msg
        else:
            if self._game.finished:
                self._error_label.text = " Finished"
            else:
                self._error_label.text = " Running..."
        if self._clock.pause:
            if not self._change_time or tick > (self._change_time + 0.5):
                self._pause_speed_label.text = " Speed: PAUSE"
                self._change_time = None
        else:
            self._pause_speed_label.text = " Speed: %.2f" % self._clock.speed
            self._change_time = None
        if self._clock.speed != self._speed_slider.value:
            if self._clock.speed < self._speed_slider.max:
                self._speed_slider.value = self._clock.speed
                self._pause_speed_label.text = " Speed: %.2f"%self._clock.speed
                self._change_time = tick
        self._pause_toggle.value = self._clock.pause
        self._frame.draw()