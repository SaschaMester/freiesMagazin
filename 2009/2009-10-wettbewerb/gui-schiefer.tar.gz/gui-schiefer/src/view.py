#-------------------------------------------------------------------------------
# Copyright (c) 2009, Andreas Schiefer
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#     * Redistributions of source code must retain the above copyright notice, 
#       this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the RobotViewer nor the names of its contributors 
#       may be used to endorse or promote products derived from this software
#       without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#-------------------------------------------------------------------------------
"""
Common view module that contains things that can be used by all views
Also provides methods to get an instance of an specific view
"""

import math

import pyglet

import config
import consts
from util import GameClock
from cgmath import Quaternion, Vec3


def get_view_instance(name, args):
    """
    Returns an instance of the specified view
    name must be of the form "module.class"
    args are passed to the constructor of the class
    """
    modulename, classname = name.split(".")
    module = __import__(modulename)
    instance = getattr(module, classname)(*args)
    return instance

def get_field_vertices_uv(field):
    """
    Returns the uv-coordinates for the given field
    """
    field_uvs = {
        consts.FIELD_EMPTY : ((0.0, 1.0), (0.0, 0.75), (0.25, 0.75), (0.25, 1.0)),
        consts.FIELD_HOLE : ((0.25, 1.0), (0.25, 0.75), (0.5, 0.75), (0.5, 1.0)),
        consts.FIELD_OIL : ((0.5, 1.0), (0.5, 0.75), (0.75, 0.75), (0.75, 1.0)),
        consts.FIELD_START : ((0.75, 1.0), (0.75, 0.75), (1.0, 0.75), (1.0, 1.0)),
        consts.FIELD_FINISH : ((0.0, 0.75), (0.0, 0.5), (0.25, 0.5), (0.25, 0.75)),
        consts.FIELD_ROTATE : ((0.25, 0.75), (0.25, 0.5), (0.5, 0.5), (0.5, 0.75)),
        consts.FIELD_CONVEYOR: ((0.5, 0.75), (0.5, 0.5), (0.75, 0.5), (0.75, 0.75)),
        consts.FIELD_PUSHER : ((0.75, 0.75), (0.75, 0.5), (1.0, 0.5), (1.0, 0.75)),
        consts.FIELD_PRESS : ((0.0, 0.5), (0.0, 0.25), (0.25, 0.25), (0.25, 0.5)),
        consts.FIELD_WALL : ((0.25, 0.5), (0.25, 0.25), (0.5, 0.25), (0.5, 0.5)),
        consts.FIELD_CUBE : ((0.5, 0.5), (0.5, 0.25), (0.75, 0.25), (0.75, 0.5)),
    }
    if field.fieldtype in field_uvs:
        return field_uvs[field.fieldtype]
    else: #Use bottom right corner texture for unknown fields...
        return ((0.75, 0.25), (0.75, 0.0), (1.0, 0.0), (1.0, 0.25))

def get_map_vertices(map):
    """
    Calculates all vertices for the given map
    For every field this generator yields four (u, v, x, y, z) tuples
    """
    map_size = map.get_size()
    X_SIZE = 1.0 #X is from left to right
    Y_SIZE = -1.0 #Y is from top to bottom
    x_offset = (-X_SIZE * map_size[0]) / 2.0
    y_offset = (-Y_SIZE * map_size[1]) / 2.0
    for x in xrange(map_size[0]):
        for y in xrange(map_size[1]):
            field = map.get_field(x, y)
            uv1, uv2, uv3, uv4 = get_field_vertices_uv(field)
            yield uv1 + (x_offset+(x*X_SIZE), y_offset+(y*Y_SIZE), 0.0)
            yield uv2 + (x_offset+(x*X_SIZE), y_offset+((y+1)*Y_SIZE), 0.0)
            yield uv3 + (x_offset+((x+1)*X_SIZE), y_offset+((y+1)*Y_SIZE), 0.0)
            yield uv4 + (x_offset+((x+1)*X_SIZE), y_offset+(y*Y_SIZE), 0.0)


class Translation(object):
    """
    Stores the translation (position) of an object
    Provides methods to change the translation over time
    (for movement, animations, etc)
    """
    def __init__(self, position):
        """
        Initializes the translation with a position
        """
        self.position = position
        self._clock = GameClock(self)
        self._time_to_target = 0.0
        self._target_pos = None
        self._next_targets = []
    
    def _get_moving(self):
        return (self._target_pos is not None)
    moving = property(_get_moving)
    
    def move_to(self, position, duration):
        """
        Changes the position to the specified position in 'duration' seconds
        """
        if self.moving:
            self._next_targets.append((position, duration))
        else:
            self._time_to_target = duration
            self._target_pos = position
            self._clock.start()
    
    def update(self):
        """
        Updates the position if it is currently changing over time
        """
        if self.moving:
            dt = min(self._clock.tick(), self._time_to_target)
            factor = dt / self._time_to_target
            movement = self._target_pos - self.position
            self.position += movement * factor
            if factor < 1.0:
                self._time_to_target = self._time_to_target - dt
            else:
                if self._next_targets:
                    next = self._next_targets.pop(0)
                    self._time_to_target = next[1]
                    self._target_pos = next[0]
                    self._clock.start()
                else:
                    self._time_to_target = 0.0
                    self._target_pos = None


class Rotation(object):
    """
    Stores the rotation of an object
    Provides methods to change the rotation over time
    (for movement, animations, etc)
    """
    def __init__(self, rotation):
        """
        Initializes the rotation
        """
        self.rotation = rotation
        self._clock = GameClock(self)
        self._time_elapsed = 0.0
        self._rotation_duration = 0.0
        self._rotation_start = None
        self._rotation_target = None
        self._next_rotations = []
    
    def _get_moving(self):
        return (self._rotation_target is not None)
    moving = property(_get_moving)
    
    def rotate_to(self, rotation, duration):
        """
        Changes the rotation to the specified rotation in 'duration' seconds
        """
        if self.moving:
            self._next_rotations.append((rotation, duration))
        else:
            self._time_elapsed = 0.0
            self._rotation_duration = duration
            self._rotation_start = self.rotation
            self._rotation_target = rotation
            self._clock.start()
    
    def update(self):
        """
        Updates the rotation if it is currently changing over time
        """
        if self.moving:
            max_dt = self._rotation_duration - self._time_elapsed
            dt = min(self._clock.tick(), max_dt)
            factor = (self._time_elapsed + dt) / self._rotation_duration
            self.rotation = Quaternion.slerp(self._rotation_start,
                                             self._rotation_target,
                                             factor)
            if factor < 1.0:
                self._time_elapsed += dt
            else:
                if self._next_rotations:
                    next = self._next_rotations.pop(0)
                    self._time_elapsed = 0.0
                    self._rotation_duration = next[1]
                    self._rotation_start = self.rotation
                    self._rotation_target = next[0]
                    self._clock.start()
                else:
                    self._time_elapsed = 0.0
                    self._rotation_duration = 0.0
                    self._rotation_start = None
                    self._rotation_target = None


class Transformation(object):
    """
    Class representing both translation (position) and rotation of an object
    """
    def __init__(self, position, rotation):
        self._translation = Translation(position)
        self._rotation = Rotation(rotation)
    
    def _get_position(self):
        return self._translation.position
    position = property(_get_position)
    
    def _get_rotation(self):
        return self._rotation.rotation
    rotation = property(_get_rotation)
    
    def _get_moving(self):
        return self._translation.moving or self._rotation.moving
    moving = property(_get_moving)
    
    def move_to(self, position, duration):
        """
        See Translation.move_to()
        """
        self._translation.move_to(position, duration)
    
    def rotate_to(self, rotation, duration):
        """
        See Rotation.rotate_to()
        """
        self._rotation.rotate_to(rotation, duration)
    
    def transform_to(self, position, rotation, duration):
        """
        Combines move_to and rotate_to with the same duration
        """
        self._translation.move_to(position, duration)
        self._rotation.rotate_to(rotation, duration)
    
    def update(self):
        """
        Updates the current translation and rotation
        """
        self._translation.update()
        self._rotation.update()


class InspectCamera(object):
    """
    Camera that allows to inspect an object
    The camera can be rotated within a semi-sphere over the object with a
    variable distance to the object.
    """
    def __init__(self, window, position, look_at, up):
        """
        Initializes the camera to the given position and to look at the given
        look_at point. The up vector is only stored for later reference by the
        user.
        """
        self._window = window
        self._window.push_handlers(self)
        self.look_at = Vec3(look_at)
        self.up = Vec3(up)
        self.position = Vec3(position)
        self.min_distance = 3.33
        self.max_distance = 100000.0
        self.max_sizes = None
    
    def _get_position(self):
        d = self._distance
        azimuth = self._azimuth
        sin_elevation = math.sin(self._elevation)
        return self.look_at + Vec3((d * sin_elevation * math.cos(azimuth),
                                    d * sin_elevation * math.sin(azimuth),
                                    d * math.cos(self._elevation)))
    def _set_position(self, pos):
        self._distance = (self.look_at - pos).length()
        self._azimuth = math.atan2(pos[1], pos[0])
        proj_len = math.sqrt(pos[0]**2 + pos[1]**2)
        self._elevation = (math.pi * 0.5) - math.atan(pos[2] / proj_len)
    position = property(_get_position, _set_position)
    
    def _get_distance(self):
        return self._distance
    def _set_distance(self, d):
        self._distance = min(max(d, self.min_distance), self.max_distance)
    distance = property(_get_distance, _set_distance)

    def _pan(self, dx, dy):
        old_look_at = self.look_at
        d = self._distance
        pos = self.position
        up = Vec3((0.0, 0.0, 1.0))
        view = self.look_at - pos
        right = view.cross(up).normalize()
        f = 0.0025 # Factor that scales the panning down
        self.look_at -= right * dx * (f * d / config.graphics.pan_factor)
        forward = (self.look_at - (pos[0], pos[1], 0.0)).normalize()
        self.look_at -= forward * dy * (f * d / config.graphics.pan_factor)
        if self.max_sizes:
            x_size = self.max_sizes[0]
            y_size = self.max_sizes[1]
            if not (-x_size <= self.look_at[0] <= x_size):
                self.look_at = old_look_at
            elif not (-y_size <= self.look_at[1] <= y_size):
                self.look_at = old_look_at

    def on_key_press(self, symbol, modifier):
        """
        Event handler for key presses
        """
        direction = { pyglet.window.key.PAGEUP : 1,
                      pyglet.window.key.PAGEDOWN : -1 }
        if symbol in direction:
            d = direction[symbol]
            new_distance = self._distance + d * config.graphics.zoom_speed
            self.distance = new_distance

    def on_text_motion(self, motion):
        """
        Event handler for cursor keys (with key-repeat)
        """
        panning = {
            pyglet.window.key.MOTION_LEFT : (10, 0),
            pyglet.window.key.MOTION_RIGHT : (-10, 0),
            pyglet.window.key.MOTION_UP : (0, -10),
            pyglet.window.key.MOTION_DOWN : (0, 10),
        }
        if motion in panning:
            self._pan(*panning[motion])

    def on_mouse_drag(self, x, y, dx, dy, buttons, modifiers):
        """
        Event handler that gets called when the mouse gets dragged
        """
        if buttons == pyglet.window.mouse.LEFT:
            if y > self._window.height / 2.0:
                self._azimuth += dx * 0.01
            else:
                self._azimuth -= dx * 0.01
            new_elevation = self._elevation + dy * 0.01
            if 0.01 < new_elevation < math.pi * 0.4:
                self._elevation = new_elevation
        elif (buttons == pyglet.window.mouse.RIGHT or
              buttons == pyglet.window.mouse.MIDDLE):
            self._pan(dx, dy)
    
    def on_mouse_scroll(self, x, y, scroll_x, scroll_y):
        """
        Event handler that gets called when the mouse-wheel gets scrolled
        """
        new_distance = self._distance + scroll_y * config.graphics.zoom_speed
        self.distance = new_distance

    def update(self):
        """
        Does currently nothing for this camera, only here to conform with
        camera interface
        """
        pass
