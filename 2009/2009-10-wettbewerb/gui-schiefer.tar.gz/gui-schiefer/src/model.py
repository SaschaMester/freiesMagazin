#-------------------------------------------------------------------------------
# Copyright (c) 2009, Andreas Schiefer
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#     * Redistributions of source code must retain the above copyright notice, 
#       this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the RobotViewer nor the names of its contributors 
#       may be used to endorse or promote products derived from this software
#       without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#-------------------------------------------------------------------------------
"""
Model module containing relevant datastructures for RobotViewer
The model-classes in this module hold all game-state from the game-engine
(which is read from files)
"""
from __future__ import with_statement #For Python < 2.6

import sys
import logging

from consts import *


class Robot(object):
    """
    Robot model
    Stores current position, orientation and a state
    """
    def __init__(self, position, orientation):
        """
        Creates a new Robot and places it on the given position
        orientation is the view direction of the robot (LEFT, RIGHT, UP, DOWN)
        """
        self._position = position
        self._orientation = orientation
        self._state = STATE_IDLE
        self.observers = []
    
    def __str__(self):
        return "Robot<%d, %d, %s, %s>" % (self.position[0], self.position[1],
                                          self.orientation, self.state)
    
    def _notify(self, event, value):
        """
        Dispatches the given event with the given value to all registered
        observers
        """
        for observer in self.observers:
            if hasattr(observer, event):
                getattr(observer, event)(value)
    
    def _set_position(self, pos):
        if pos != self._position:
            self._position = pos
            self._notify("on_position_change", pos)
    def _get_position(self):
        return self._position
    position = property(_get_position, _set_position)

    def _set_orientation(self, rot):
        if rot != self._orientation:
            self._orientation = rot
            self._notify("on_orientation_change", rot)
    def _get_orientation(self):
        return self._orientation
    orientation = property(_get_orientation, _set_orientation)

    def _set_state(self, state):
        if state != self._state:
            self._state = state
            self._notify("on_state_change", state)
    def _get_state(self):
        return self._state
    state = property(_get_state, _set_state)
    
    def move_left(self):
        """
        Moves robot to the left (on the map, not from robots perspective)
        """
        self.position = (self.position[0]-1, self.position[1])
    
    def move_right(self):
        """
        Moves robot to the right (on the map, not from robots perspective)
        """
        self.position = (self.position[0]+1, self.position[1])
    
    def move_up(self):
        """
        Moves robot up (on the map, not from robots perspective)
        """
        self.position = (self.position[0], self.position[1]-1)
    
    def move_down(self):
        """
        Moves robot down (on the map, not from robots perspective)
        """
        self.position = (self.position[0], self.position[1]+1)
    
    def rotate_left(self):
        """
        Turns the robot 90 degrees to the left
        """
        self.orientation = {
            LEFT : DOWN,
            RIGHT : UP,
            UP : LEFT,
            DOWN : RIGHT,
        }[self.orientation]

    def rotate_right(self):
        """
        Turns the robot 90 degrees to the right
        """
        self.orientation = {
            LEFT : UP,
            RIGHT : DOWN,
            UP : RIGHT,
            DOWN : LEFT,
        }[self.orientation]
    
    def rotate_around(self):
        """
        Turns the robot 180 degrees
        """
        self.orientation = {
            LEFT : RIGHT,
            RIGHT : LEFT,
            UP : DOWN,
            DOWN : UP,
        }[self.orientation]
    
    def push_only(self, direction):
        """
        Pushes the robot into the given direction (does not change its position)
        For the special case, when robot stands between pusher and wall
        """
        self._notify("on_get_pushed", direction)
    
    def set_state_from_char(self, state):
        """
        Sets the robot state from a char (X, Y, Z)
        """
        states = {
            "X" : STATE_DEAD,
            "Y" : STATE_OUT_OF_ENERGY,
            "Z" : STATE_FINISH,
        }
        if state in states:
            self.state = states[state]


class Field(object):
    """
    Model of a single field on the map
    """
    def __init__(self, coords, fieldtype, direction):
        """
        Creates a new field
        fieldtype is any of the FIELD_* constants defined in this module
        direction is specific to the fieldtype:
          START: View directon on start (LEFT, RIGHT, UP, DOWN)
          ROTATE: Direction of rotation (LEFT, RIGHT)
          CONVEYOR: Direction of movement (LEFT, RIGHT, UP, DOWN)
          PUSHER: Direction of movement (LEFT, RIGHT, UP, DOWN)
          PRESS: List from where you cannot enter ([LEFT, RIGHT], [UP, DOWN])
          WALL: List of directions where walls are ([LEFT], [RIGHT, UP], ...)
          All other fieldtypes have no direction (None)
        """
        self.coords = coords
        self.fieldtype = fieldtype
        self.direction = direction
    
    def __str__(self):
        return "Field<(%i, %i) - %s, %s>" % (self.coords[0], self.coords[1],
                                             self.fieldtype, self.direction)
    
    @classmethod
    def from_char(cls, coords, field):
        """
        Returns a new Field from a char describing the properties
        """
        field_dict = {
            " " : (FIELD_EMPTY, None),
            "H" : (FIELD_HOLE, None),
            "O" : (FIELD_OIL, None),
            "S" : (FIELD_START, LEFT),
            "T" : (FIELD_START, RIGHT),
            "U" : (FIELD_START, UP),
            "V" : (FIELD_START, DOWN),
            "Z" : (FIELD_FINISH, None),
            "L" : (FIELD_ROTATE, LEFT),
            "R" : (FIELD_ROTATE, RIGHT),
            "<" : (FIELD_CONVEYOR, LEFT),
            ">" : (FIELD_CONVEYOR, RIGHT),
            "^" : (FIELD_CONVEYOR, UP),
            "v" : (FIELD_CONVEYOR, DOWN),
            "C" : (FIELD_PUSHER, LEFT),
            "D" : (FIELD_PUSHER, RIGHT),
            "E" : (FIELD_PUSHER, UP),
            "F" : (FIELD_PUSHER, DOWN),
            "M" : (FIELD_PRESS, [LEFT, RIGHT]),
            "N" : (FIELD_PRESS, [UP, DOWN]),
            "a" : (FIELD_EMPTY, None),               #0
            "b" : (FIELD_WALL, [LEFT]),              #1
            "c" : (FIELD_WALL, [RIGHT]),             #2
            "d" : (FIELD_WALL, [LEFT, RIGHT]),       #3
            "e" : (FIELD_WALL, [UP]),                #4
            "f" : (FIELD_WALL, [LEFT, UP]),          #5
            "g" : (FIELD_WALL, [RIGHT, UP]),         #6
            "h" : (FIELD_WALL, [LEFT, RIGHT, UP]),   #7
            "i" : (FIELD_WALL, [DOWN]),              #8
            "j" : (FIELD_WALL, [LEFT, DOWN]),        #9
            "k" : (FIELD_WALL, [RIGHT, DOWN]),       #10
            "l" : (FIELD_WALL, [LEFT, RIGHT, DOWN]), #11
            "m" : (FIELD_WALL, [UP, DOWN]),          #12
            "n" : (FIELD_WALL, [LEFT, UP, DOWN]),    #13
            "o" : (FIELD_WALL, [RIGHT, UP, DOWN]),   #14
            "p" : (FIELD_CUBE, None),                #16
        }
        return cls(coords, *field_dict[field])


class MapError(Exception):
    """
    Custom Exception for map errors
    """
    def __init__(self, value):
        Exception.__init__(self)
        self.value = value
        
    def __str__(self):
        return repr(self.value)


class Map(object):
    """
    Holds all properties of a map (including all fields)
    """
    def __init__(self, size_x, size_y, fields, name=""):
        """
        Creates a new map with the given size and fields
        fields is a string with size_y lines and size_x characters each line
        name is just a symbolic name for debugging purposes
        """
        self._x_size = size_x
        self._y_size = size_y
        self._fields = {}
        self.name = name
        self._start_position = None
        self._init_fields(fields)
    
    def _init_fields(self, fields):
        """
        Initializes the fields of the map
        """
        col = 0
        row = 0
        for field in fields:
            if field == "\n":
                col = 0
                row += 1
            else:
                self._fields[(col, row)] = Field.from_char((col, row), field)
                if field in "STUV":
                    self._start_position = (col, row)
                col += 1
    
    @classmethod
    def from_file(cls, filename):
        """
        Loads a map from the file 'filename' and returns a new Map instance
        """
        logging.info("Loading map '%s'..." % filename)
        try:
            with open(filename) as mapfile:
                x_size, y_size = (int(i) for i in mapfile.readline().split(" "))
                rows = []
                for line in mapfile:
                    if len(rows) < y_size:
                        line = line.strip("\n\r") #Remove newline chars
                        #Make sure the line is x_size characters long
                        rows.append(line[:x_size].ljust(x_size, " "))
                while len(rows) < y_size:
                    #Make sure there are y_size lines
                    rows.append(" " * x_size)
            fields = "\n".join(rows)
            return cls(x_size, y_size, fields, filename)
        except Exception, error:
            logging.debug(error, exc_info=sys.exc_info())
            raise MapError("Loading map file '%s' failed!" % filename)
    
    def get_size(self):
        """
        Returns the size as a tuple (size_x, size_y)
        """
        return (self._x_size, self._y_size)
    size = property(get_size)
    
    def get_start_pos(self):
        """
        Returns the start position in the map
        A MapError is raised if there is no start position set in the map
        """
        if not self._start_position:
            raise MapError("No start position set!")
        return self._start_position
    
    def get_field(self, x, y):
        """
        Returns the field at the given coordinates
        Raises an MapError if there is no such field
        """
        try:
            return self._fields[(x, y)]
        except KeyError:
            raise MapError("No field at (%i, %i)" % (x, y))
