#-------------------------------------------------------------------------------
# Copyright (c) 2009, Andreas Schiefer
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#     * Redistributions of source code must retain the above copyright notice, 
#       this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the RobotViewer nor the names of its contributors 
#       may be used to endorse or promote products derived from this software
#       without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#-------------------------------------------------------------------------------
"""
Controller module
Contains various classes that controll the model/view
"""
import logging

import pyglet
from pyglet.window import key

import config
from consts import *
from model import MapError
from util import GameClock


def _get_next_state(current):
    return {
        STATE_IDLE : STATE_IDLE,
        STATE_MOVING : STATE_IDLE,
        STATE_PUSHED : STATE_IDLE,
    }[current]


class KeyboardController(object):
    """
    Keyboard controller allowing to control game state with the keyboard
    May also allow to move the robot with the cursor keys
    """
    def __init__(self, game, control_robot=False):
        """
        Initializes the controller
        Registers its event handlers at the Game object
        If control_robot is True, the cursor keys control the robot
        """
        self._game = game
        self._clock = GameClock()
        game.push_handlers(self)
        self._control_robot = (control_robot and
                               config.graphics.allow_keyboard_movement)
        self._can_move = True
    
    def on_key_press(self, symbol, modifiers):
        """
        Event handler for key presses
        """
        key_actions = {
            key.LEFT : self._handle_left,
            key.RIGHT : self._handle_right,
            key.UP : self._handle_up,
            key.DOWN : self._handle_down,
            key.SPACE : self._handle_turn,
            key.P : self._handle_pause,
            key.BREAK : self._handle_pause,
            key.PLUS : self._handle_speed_up,
            key.NUM_ADD : self._handle_speed_up,
            key.MINUS : self._handle_speed_down,
            key.NUM_SUBTRACT : self._handle_speed_down,
            key.HOME : self._handle_speed_normal,
            key.R : self._handle_restart,
        }
        if symbol in key_actions:
            key_actions[symbol]()
    
    def on_text_motion(self, motion):
        #Prevent others from getting the keys, if we control the robot
        if self._control_robot:
            return pyglet.event.EVENT_HANDLED

    def on_state_finished(self):
        """
        Gets called after the view finished some action and sets the next state
        The view is responsible for dispatching the on_state_finished event on
        the game if the action (like moving, etc.) finishes
        """
        self._game.robot.state = _get_next_state(self._game.robot.state)
        self._can_move = True

    def on_restart_game(self):
        """
        Gets called if the user restarts the game
        """
        self._clock.pause = False
        self._clock.speed = 1.0

    def _test_set_moving_state(self):
        """
        Returns True and sets the robots state to MOVING if current state is
        IDLE and game is not paused, else returns False
        """
        if not self._control_robot: #Moving not allowed
            return False
        #if self._game.robot.state == STATE_IDLE and not self._clock.pause:
        if self._can_move and not self._clock.pause:
            self._can_move = False
            self._game.robot.state = STATE_MOVING
            return True
        return False
    
    def _handle_left(self):
        """
        Handles the left-key action
        """
        if self._test_set_moving_state():
            self._game.robot.rotate_left()
    
    def _handle_right(self):
        """
        Handles the right-key action
        """
        if self._test_set_moving_state():
            self._game.robot.rotate_right()

    def _handle_turn(self):
        """
        Handles the turn-around action
        """
        if self._test_set_moving_state():
            self._game.robot.rotate_left()
            self._game.robot.rotate_left()

    def _handle_up(self):
        """
        Handles the up-key action
        """
        if self._test_set_moving_state():
            moves = {
                LEFT : self._game.robot.move_left,
                RIGHT : self._game.robot.move_right,
                UP : self._game.robot.move_up,
                DOWN : self._game.robot.move_down,
            }
            moves[self._game.robot.orientation]()
    
    def _handle_down(self):
        """
        Handles the down-key action
        """
        if self._test_set_moving_state():
            moves = {
                LEFT : self._game.robot.move_right,
                RIGHT : self._game.robot.move_left,
                UP : self._game.robot.move_down,
                DOWN : self._game.robot.move_up,
            }
            moves[self._game.robot.orientation]()

    def _handle_pause(self):
        if not self._game.was_error:
            self._clock.pause = not self._clock.pause
    
    def _handle_speed_up(self):
        if self._clock.speed < SPEED_INCREASE: # Allow smaller steps near 0.0
            self._clock.speed = self._clock.speed + (SPEED_INCREASE / 2.0)
        else:
            self._clock.speed = self._clock.speed + SPEED_INCREASE
    
    def _handle_speed_down(self):
        if self._clock.speed <= SPEED_INCREASE: # Allow smaller steps near 0.0
            self._clock.speed = self._clock.speed - (SPEED_DECREASE / 2.0)
        else:
            self._clock.speed = self._clock.speed - SPEED_DECREASE
    
    def _handle_speed_normal(self):
        self._clock.speed = 1.0
    
    def _handle_restart(self):
        self._game.restart()


class GlobalSequenceController(object):
    """
    Controller that processes a list of tokens (saved by the game engine)
    """
    def __init__(self, game, sequence):
        """
        Initializes this controller
        """
        self._game = game
        self._game.push_handlers(self)
        self._robot_model = game.robot
        self._sequence = sequence
        self._clock = GameClock()
        self._current_token = 0
        self._last_field = None
        self._last_move = None
        self._board_movements = False
        self._past_board_moves = set()
    
    def _get_current_field(self):
        """
        Returns the current field or none if the robot is outside
        """
        try:
            return self._game.map.get_field(*self._robot_model.position)
        except MapError:
            return None
    
    def _check_non_moving_push(self):
        """
        If the robot moves on a PUSHER field, but isn't pushed, there must be a
        wall. In this case allow the view to display an animation -
        so call the push_only method on the robot to fire an event
        """
        if self._last_field and not FIELD_PUSHER in self._past_board_moves:
            field = self._get_current_field()
            if field and field.fieldtype == FIELD_PUSHER:
                self._robot_model.state = STATE_PUSHED
                self._robot_model.push_only(field.direction)
    
    def _error(self, msg, long_msg):
        logging.error(msg)
        logging.error(long_msg)
        self._game.error_msg = msg
        self._game.was_error = True
        self._clock.pause = True

    def _process(self):
        """
        Gets the next token from the sequence and calls the according handler
        """
        if ((not self._game.finished) and
            (self._current_token < len(self._sequence))):
            next_token = self._sequence[self._current_token]
            self._current_token += 1
            if not next_token:  #Ignore empty tokens...
                self._process() #move on with the next one
                return
            actions = {
                "--" :  self._handle_board_movement_start,
                "----" : self._handle_next_card,
                "--------" : self._handle_next_round,
                "ML" : self._handle_move,
                "MR" : self._handle_move,
                "MU" : self._handle_move,
                "MD" : self._handle_move,
                "RL" : self._handle_move,
                "RR" : self._handle_move,
                "RU" : self._handle_move,
                "X" : self._handle_end_state,
                "Y" : self._handle_end_state,
                "Z" : self._handle_end_state,
            }
            if next_token in actions:
                actions[next_token](next_token)
        else:
            self._handle_end_of_sequence()
    
    def _handle_board_movement_start(self, token):
        """
        Handles start of board movements
        """
        self._board_movements = True
    
    def _handle_next_card(self, token):
        """
        Handles the next-card marker
        """
        self._check_non_moving_push()
        self._board_movements = False
        self._last_move = None
        self._past_board_moves = set()
        self._game.card_round += 1
        self._game.card_total += 1
        self._process()
    
    def _handle_next_round(self, token):
        """
        Handles the next-round marker
        """
        self._check_non_moving_push()
        self._board_movements = False
        self._last_move = None
        self._past_board_moves = set()
        self._game.card_round = 0
        self._game.round += 1
        self._process()
    
    def _handle_end_of_sequence(self):
        """
        Handles the end of the sequence list
        """
        self._game.finished = True
    
    def _handle_move(self, token):
        """
        Handles move tokens (and rotations)
        """
        if self._current_token > 1 and not self._last_field:
            self._error("Robot left game board",
                "Sequence doesn't fit to board! Wrong files?")
        self._last_field = self._get_current_field()
        if self._last_field and self._last_field.fieldtype in (FIELD_HOLE):
            self._error("Robot survived hole",
                "Sequence doesn't fit to board! Wrong files?")
        if self._board_movements:
            self._robot_model.state = STATE_PUSHED
        else:
            #Test for moves across multiple fields (like MF 3 or MF 2)
            if not self._last_move: #No last move -> robot is moving
                self._robot_model.state = STATE_MOVING
            elif self._last_move != token: #Last move was different
                self._robot_model.state = STATE_PUSHED
            elif self._last_move in ["RL", "RR", "RU"]: #Last move was rotation
                self._robot_model.state = STATE_PUSHED
            else:
                forward_directions = { "LEFT" : "ML", "RIGHT" : "MR",
                                       "UP" : "MU", "DOWN" : "MD" }
                fwd = forward_directions[self._robot_model.orientation]
                if token != fwd: #Is move in the right direction? (only forward)
                    self._robot_model.state = STATE_PUSHED
                else:
                    #Multiple-fields move detected...
                    self._robot_model.state = STATE_MOVING
        if self._robot_model.state == STATE_PUSHED and self._last_field:
            self._past_board_moves.add(self._last_field.fieldtype)
        {
            "ML" : self._robot_model.move_left,
            "MR" : self._robot_model.move_right,
            "MU" : self._robot_model.move_up,
            "MD" : self._robot_model.move_down,
            "RL" : self._robot_model.rotate_left,
            "RR" : self._robot_model.rotate_right,
            "RU" : self._robot_model.rotate_around,
        }[token]()
        self._last_move = token
    
    def _handle_end_state(self, token):
        """
        Handles all end tokens like death, finish, etc...
        """
        token_correct = True
        current_field = self._get_current_field()
        if token == "X":
            if current_field:
                if not current_field.fieldtype in (FIELD_HOLE, FIELD_PRESS):
                    token_correct = False
        elif token == "Z":
            if not current_field:
                token_correct = False
            else:
                if not current_field.fieldtype in (FIELD_FINISH):
                    token_correct = False
        if token_correct:
            self._game.finished = True
            self._robot_model.set_state_from_char(token)
        else:
            self._error("Robot died/finished unexpectedly", 
                "Sequence doesn't fit to board! Wrong files?")
    
    def on_state_finished(self):
        """
        Gets called after the view finished some action and sets the next state
        The view is responsible for dispatching the on_state_finished event on
        the game if the action (like moving, etc.) finishes
        """
        next_state = _get_next_state(self._robot_model.state)
        self._robot_model.state = next_state
        if next_state == STATE_IDLE:
            self._process()
        return pyglet.event.EVENT_HANDLED

    def on_restart_game(self):
        """
        Gets called if the user restarts the game
        """
        self._current_token = 0
        self._last_field = None
        self._last_move = None
        self._game.finished = False
