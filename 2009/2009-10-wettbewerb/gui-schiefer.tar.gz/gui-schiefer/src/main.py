#-------------------------------------------------------------------------------
# Copyright (c) 2009, Andreas Schiefer
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#     * Redistributions of source code must retain the above copyright notice, 
#       this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the RobotViewer nor the names of its contributors 
#       may be used to endorse or promote products derived from this software
#       without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#-------------------------------------------------------------------------------
"""
Main module for RobotViewer
Parses all command-line arguments and sets up the game according the paramers
"""
from __future__ import with_statement #For Python < 2.6

import logging
from optparse import OptionParser

import pyglet

import config
from game import Game, get_window_config
from model import MapError
import view
from controller import KeyboardController, GlobalSequenceController

APP_NAME = "RobotViewer"
VERSION = "1.1"
EXECUTABLE_NAME = "./robotviewer"

def main(args, options):
    """
    Main entry point
    Creats a game, attaches controllers and views and runs the game
    mapfile is the filename of the map
    options are the command line arguments from optparse
    """
    if options.debug:
        logging.basicConfig(level=logging.DEBUG,
                            format="%(levelname)s: %(message)s")
    else:
        logging.basicConfig(level=logging.ERROR,
                            format="%(levelname)s: %(message)s")
        pyglet.options["debug_gl"] = False
    try:
        width = 800 if not options.fullscreen else None
        height = 600 if not options.fullscreen else None
        try:
            game = Game(caption=APP_NAME + " " + VERSION,
                        fullscreen=options.fullscreen,
                        vsync=True, width=width, height=height,
                        config=get_window_config())
        except pyglet.window.NoSuchConfigException:
            logging.info("Falling back to basic config!")
            game = Game(caption=APP_NAME + " " + VERSION,
                        fullscreen=options.fullscreen,
                        vsync=True, width=width, height=height)
        game.load_map(args[0])
        try:
            view.get_view_instance(config.graphics.renderers[options.gui],
                                   [game])
        except KeyError:
            logging.error("Specified GUI '%s' not found!" % options.gui)
            return
        if options.debug:
            view.get_view_instance(config.graphics.renderers.debug, [game])
        else:
            view.get_view_instance(config.graphics.renderers.status, [game])
        if len(args) == 1: #No sequence file specified
            logging.error("No sequence file specified!\n" +
                          "(But you can just view the board)")
            KeyboardController(game, True)
        else:
            KeyboardController(game)
            with open(args[1]) as seq_file:
                sequence = [line.strip() for line in seq_file]
            GlobalSequenceController(game, sequence)
        game.start()
    except MapError, map_error:
        logging.error(map_error.value)


if __name__ == "__main__":
    _usage = "usage: %prog [options] board [sequence] (use --help for details)"
    _parser = OptionParser(usage=_usage, version=APP_NAME + " " + VERSION,
                           prog=EXECUTABLE_NAME)
    _parser.add_option("-d", "--debug", action="store_true", dest="debug",
                       default=False, help="with debug GUI")
    _parser.add_option("-g", "--gui", dest="gui", metavar="GUI",
                      default="default", help="Specify renderer (basic, shader)"
                      " The default is set in the 'graphics.json' config file")
    _parser.add_option("-f", "--fullscreen", action="store_true",
                      dest="fullscreen", default=config.graphics.fullscreen,
                      help="start in fullscreen mode")
    _options, _arguments = _parser.parse_args()
    if not _arguments:
        _parser.error("No board specified!")
    else:
        main(_arguments, _options)
