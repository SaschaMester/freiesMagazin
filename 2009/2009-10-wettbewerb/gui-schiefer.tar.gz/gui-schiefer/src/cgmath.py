#-------------------------------------------------------------------------------
# Copyright (c) 2009, Andreas Schiefer
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#     * Redistributions of source code must retain the above copyright notice, 
#       this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the RobotViewer nor the names of its contributors 
#       may be used to endorse or promote products derived from this software
#       without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#-------------------------------------------------------------------------------
"""
ComputerGraphics math module
Contains classes often needed in graphics applications like Vector, Quaternion
"""

import math

class Vec3(tuple):
    """
    Simple Vector3 class
    Subclass of tuple for speed reasons - much faster to create than a custom
    class if we don't specify an __init__ method
    """
    def __add__(self, other):
        return Vec3((self[0] + other[0],
                     self[1] + other[1],
                     self[2] + other[2]))
    __radd__ = __add__

    def __sub__(self, other):
        return Vec3((self[0] - other[0],
                     self[1] - other[1],
                     self[2] - other[2]))
    
    def __rsub__(self, other):
        return Vec3((other[0] - self[0],
                     other[1] - self[1],
                     other[2] - self[2]))

    def __mul__(self, n):
        return Vec3((self[0] * n, self[1] * n, self[2] * n))
    __rmul__ = __mul__
    
    def __neg__(self):
        return Vec3((-self[0], -self[1], -self[2]))

    def cross(self, other):
        """
        Returns the cross product of the vector with the other
        """
        a1, a2, a3 = self
        b1, b2, b3 = other
        return Vec3((a2*b3 - a3*b2, a3*b1 - a1*b3, a1*b2 - a2*b1))

    def dot(self, other):
        """
        Returns the dot product of the vector with the other
        """
        return self[0] * other[0] + self[1] * other[1] + self[2] * other[2]

    def length(self):
        """
        Returns the length of the vector
        """
        return math.sqrt(self[0]**2 + self[1]**2 + self[2]**2)
    
    def normalize(self):
        """
        Returns the vector normalized to length 1.0
        """
        length = math.sqrt(self[0]**2 + self[1]**2 + self[2]**2)
        return Vec3((self[0] / length, self[1] / length, self[2] / length))


class Quaternion(tuple):
    """
    Quaternion class used to represent rotations
    The first element is the real part, the rest is the imaginary part
    """
    def __mul__(self, other):
        a, b, c, d = self
        e, f, g, h = other
        return Quaternion((a * e - b * f - c * g - d * h,
                           a * f + b * e + c * h - d * g,
                           a * g - b * h + c * e + d * f,
                           a * h + b * g - c * f + d * e))
    
    def normalize(self):
        """
        Returns the normalized unit quaternion
        """
        magnitude = self[0]**2 + self[1]**2 + self[2]**2 + self[3]**2
        if magnitude == 1.0:
            return self
        scale = math.sqrt(magnitude)
        return Quaternion((self[0] / scale,
                           self[1] / scale,
                           self[2] / scale,
                           self[3] / scale))
    
    def dot(self, other):
        """
        Returns the dot product of this quaternion and the other
        """
        a, b, c, d = self
        e, f, g, h = other
        return a*e + b*f + c*g + d*h

    def get_angle_axis(self):
        """
        Returns the angle in degrees and the rotation-axis as Vec3
        """
        a, b, c, d = self.normalize()
        if (b, c, d) == (0.0, 0.0, 0.0):
            return 0.0, Vec3((0.0, 0.0, -1.0))
        return math.degrees(math.acos(a) * 2.0), Vec3((b, c, d)).normalize()

    @classmethod
    def identity(cls):
        """
        Returns the identity quaternion (= no rotation)
        """
        return Quaternion((1, 0, 0, 0))

    @classmethod
    def from_angle_axis(cls, angle, axis):
        """
        Creates a quaternion from an angle-axis rotation
        angle is the rotation angle in degrees
        axis is the rotation axis (must not be normalized)
        """
        angle = math.radians(angle)
        sin_half_angle = math.sin(angle * 0.5)
        b, c, d = Vec3(axis).normalize() * sin_half_angle
        return cls((math.cos(angle * 0.5), b, c, d))
    
    @classmethod
    def slerp(cls, start, end, t, delta=0.001):
        """
        Spherical linear interpolation between two quaternions
        t must be in the range from 0.0 to 1.0
        delta specifies the smallest possible angle
        """
        n_start = start.normalize()
        n_end = end.normalize()
        a, b, c, d = n_start
        e, f, g, h = n_end
        if n_start.dot(n_end) < 0.0: #Invert sign to avoid extra spinning
            e, f, g, h = -e, -f, -g, -h
        cos_angle = min(max(a*e + b*f + c*g + d*h, -1.0), 1.0)
        angle = math.acos(cos_angle)
        if abs(angle) < delta:
            return start
        d1 = math.sin((1-t) * angle) / math.sin(angle)
        d2 = math.sin(t * angle) / math.sin(angle)
        return cls((a * d1 + e * d2,
                    b * d1 + f * d2,
                    c * d1 + g * d2,
                    d * d1 + h * d2)).normalize()
        
