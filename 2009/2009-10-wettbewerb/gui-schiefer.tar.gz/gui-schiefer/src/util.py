#-------------------------------------------------------------------------------
# Copyright (c) 2009, Andreas Schiefer
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#     * Redistributions of source code must retain the above copyright notice, 
#       this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the RobotViewer nor the names of its contributors 
#       may be used to endorse or promote products derived from this software
#       without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#-------------------------------------------------------------------------------
"""
Utility module containing commonly used classes and methods
"""

import timeit

import config


def texture_file(name):
    """
    Returns the filename for the given texture name
    """
    return config.paths.textures + config.graphics.texture_set + name

def mesh_file(name):
    """
    Returns the filename for the given mesh name
    """
    return config.paths.meshes + config.graphics.mesh_set + name


class GameClock(object):
    """
    Flexible clock for use in animations, movements, etc
    More flexible clock with less overhead than pyglet.clock for stuff that
    don't need exact, fixed, scheduled updates.
    This also allows for global, flexible settable speed and pause-state.
    """
    _clock = timeit.default_timer
    _state = { "speed" : 1.0, "pause" : False }
    _objects = {}
    
    def __init__(self, key="__game__"):
        """
        Creates a clock instance for a given key
        """
        self._key = key
        
    def start(self):
        """
        Starts the clock for this instance's key
        """
        self._objects[self._key] = self._clock()
    
    def _get_pause(self):
        return self._state["pause"]
    def _set_pause(self, paused):
        tick = self._clock()
        #Update last-ticks so that time during pause gets ignored,
        #but not the time between last tick and the beginning of pause
        if paused:
            for key, last_tick in self._objects.iteritems():
                self._objects[key] = tick - last_tick
        else:
            for key, time_before_pause in self._objects.iteritems():
                self._objects[key] = tick - time_before_pause
        self._state["pause"] = paused
    pause = property(_get_pause, _set_pause)
    
    def _get_speed(self):
        return self._state["speed"]
    def _set_speed(self, value):
        if value <= 0.0:# or self.pause:
            return
        if not self.pause: # Don't tick during pause
            tick = self._clock()
            #Update all last-ticks, so that the time before the speed-update
            #is handeled with the old speed
            for key, last_tick in self._objects.iteritems():
                self._objects[key] = tick - ((tick-last_tick)*self.speed/value)
        self._state["speed"] = value
    speed = property(_get_speed, _set_speed)
    
    def tick(self):
        """
        Updates the clock for this instance's key
        Returns the time since the last call to tick()
        """
        if not self.pause:
            tick = self._clock()
            dt = (tick - self._objects[self._key]) * self.speed
            self._objects[self._key] = tick
            return dt
        else:
            return 0.0
