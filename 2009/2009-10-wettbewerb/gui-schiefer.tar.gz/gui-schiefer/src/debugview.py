#-------------------------------------------------------------------------------
# Copyright (c) 2009, Andreas Schiefer
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#     * Redistributions of source code must retain the above copyright notice, 
#       this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the RobotViewer nor the names of its contributors 
#       may be used to endorse or promote products derived from this software
#       without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#-------------------------------------------------------------------------------
import logging
from os.path import basename

from simplui import *

import config
from opengl import *
from util import GameClock
from model import MapError


class DebugRenderer(object):
    """
    Debug GUI displaying various things such as robot position etc.
    """
    def __init__(self, game):
        """
        Initializes the renderer
        Registers itself at the Game object so that it gets drawn by it in
        on_draw() along with other views
        """
        logging.info("Using debug GUI")
        self._game = game
        self._game.views.append(self)
        self._game.push_handlers(self)
        self._clock = GameClock()
        self._setup_gui(config.paths.data + "/" + config.paths.themes +
                        config.graphics.theme)
    
    def _setup_gui(self, theme):
        """
        Creates the GUI dialog(s)
        """
        win_size = (self._game.width, self._game.height)
        self._frame = Frame(Theme(theme), w=win_size[0], h=win_size[1])
        self._game.push_handlers(self._frame)
        self._fps_label = Label(" XXX.XX FPS")
        self._pause_speed_label = Label(" Speed: XX.XX")
        self._position_label = Label("Position: (XX, YY)")
        self._orientation_label = Label("Orientation: XXXXXX")
        self._state_label = Label("State: XXXXXXXX")
        self._map_field_type = Label("Field: XXXXXXXXX")
        self._round = Label("Round: %i" % 000)
        self._card_round = Label("Card (Round): %i" % 0)
        self._card_total = Label("Card (Total): %i" % 000)
        self._finished = Label("Finished: %s" % str(False))
        dialog = Dialogue("Inspector", x=25, y=win_size[1]-25, content=
            VLayout(autosizex=True, hpadding=0, children=[
                self._fps_label,
                self._pause_speed_label,
                FoldingBox("Robot", content=
                    VLayout(autosizex=True, children=[
                        self._position_label,
                        self._orientation_label,
                        self._state_label,
                    ])
                ),
                FoldingBox("Map", content=
                    VLayout(autosizex=True, children=[
                        Label("Name: %s" % basename(self._game.map.name)),
                        Label("Size: (%i, %i)" % self._game.map.get_size()),
                        self._map_field_type,
                    ])
                ),
                FoldingBox("Game", content=
                    VLayout(autosizex=True, children=[
                        self._round,
                        self._card_round,
                        self._card_total,
                        self._finished,
                        Button("Restart", action=self._on_restart_click),
                        Button('Quit RobotViewer', action=self._on_close_click)
                    ])
                ),
            ])
        )
        self._frame.add(dialog)
    
    def _on_restart_click(self, button):
        self._game.restart()
    
    def _on_close_click(self, btn):
        self._game.close()
    
    def on_mouse_drag(self, x, y, dx, dy, buttons, modifiers):
        #Hackish way to check if dialog is moved, then don't propagate the
        #on_mouse_drag event further (to prevent camera movement etc)
        if self._frame.children[0]._in_drag:
            return pyglet.event.EVENT_HANDLED
    
    def setup(self, width, height):
        """
        Sets up the projection for this view and some common state
        """
        glViewport(0, 0, width, height)
        glMatrixMode(gl.GL_PROJECTION)
        glLoadIdentity()
        glOrtho(0, width, 0, height, -1, 1)
        glMatrixMode(gl.GL_MODELVIEW)
        glLoadIdentity()
        glColor4f(0.9, 0.9, 0.9, 0.8)
        glDisable(GL_DEPTH_TEST)
        glDisable(GL_LIGHTING)

    def draw(self):
        """
        Updates some labels and draws the GUI
        """
        self._fps_label.text = " %.2f FPS" % pyglet.clock.get_fps()
        if self._clock.pause:
            self._pause_speed_label.text = " Speed: PAUSE"
        else:
            self._pause_speed_label.text = " Speed: %.2f" % self._clock.speed
        self._position_label.text = "Position: (%i, %i)" % (
            self._game.robot.position)
        self._orientation_label.text = "Orientation: %s" % (
            self._game.robot.orientation)
        self._state_label.text = "State: %s" % (self._game.robot.state)
        try:
            current_field = self._game.map.get_field(*self._game.robot.position)
            fieldtype = current_field.fieldtype
        except MapError:
            fieldtype = "OUTSIDE"
        self._map_field_type.text = "Field: %s" % fieldtype
        self._round.text = "Round: %i" % self._game.round
        self._card_round.text = "Card (Round): %i" % self._game.card_round
        self._card_total.text = "Card (Total): %i" % self._game.card_total
        self._finished.text = "Finished: %s" % str(self._game.finished)
        self._frame.draw()
