/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "serverclient.hh"
#include "trace.hh"

// Qt
////////
#include <QTcpSocket>

// Sys
////////
#include <iostream>

// Constructor
ServerClient::ServerClient()
: QObject(), m_socket(0), m_id(-1)
{
    Trace::print( MTP_CLIENT, STP_CLIENT_STRUCTOR,
                  "ServerClient::ServerClient Start" );
    // do nothing
    
    Trace::print( MTP_CLIENT, STP_CLIENT_STRUCTOR,
                  "ServerClient::ServerClient Start" );
}

// Destructor.
ServerClient::~ServerClient()
{
    Trace::print( MTP_CLIENT, STP_CLIENT_STRUCTOR,
                  "ServerClient::~ServerClient Start" );

    // reset all data
    reset();

    Trace::print( MTP_CLIENT, STP_CLIENT_STRUCTOR,
                  "ServerClient::~ServerClient Start" );
}

// reset connection and index
void ServerClient::reset()
{
    Trace::print( MTP_CLIENT, STP_CLIENT_SET,
                  "ServerClient::reset Start " + QString::number(m_id) );

    // From Qt manual:
    // The socket is created as a child of the server, which means
    // that it is automatically deleted when the QTcpServer object
    // is destroyed. It is still a good idea to delete the object
    // explicitly when you are done with it, to avoid wasting memory.

#ifdef QT_DEBUG
        std::cout << "(II) ServerClient::reset "
                  << " ServerClient " << m_id
                  << " connection " << m_socket
                  << " resetted."
                  << std::endl;
#endif

    if ( m_socket )
    {
        // close connection first
        m_socket->close();

        // Note: If we delete the socket, we get a segmentation fault!
        
        // delete m_socket;
        m_socket = NULL;
    }
    
    m_id = -1;

    Trace::print( MTP_CLIENT, STP_CLIENT_SET,
                  "ServerClient::reset End" );
}

// Set new connection and index.
bool ServerClient::set( QTcpSocket* socket, const int clientId )
{
    Trace::print( MTP_CLIENT, STP_CLIENT_SET,
                  "ServerClient::set Start " + QString::number(clientId) );

    bool ok = false;

    // socket should not be set before
    if ( !m_socket)
    {
        if ( -1 == m_id )
        {
            if ( socket )
            {
                if ( clientId >= 0 )
                {
#ifdef QT_DEBUG
                    std::cout << "(II) ServerClient::setConnection "
                              << " ServerClient "
                              << " set index "      << clientId
                              << " set connection " << socket
                              << std::endl;
#endif

                    m_id = clientId;
                    m_socket = socket;
                    ok = true;

                    // signal when data can be read from client
                    if ( !connect( m_socket, SIGNAL(readyRead()),
                                   this, SLOT(slot_receiveData()) ) )
                    {
                        std::cerr << "(EE) ServerClient::set  "
                                  << " ServerClient " << m_id
                                  << " Connect 1 not possible!"
                                  << std::endl;
                    }

                    // check for errors
                    if ( !connect( m_socket, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(slot_displayError(QAbstractSocket::SocketError)) ) )
                    {
                        std::cerr << "(EE) ServerClient::set  "
                                  << " ServerClient " << m_id
                                  << " Connect 2 not possible!"
                                  << std::endl;
                    }

                    // signal when the connection is cancelled
                    if ( !connect( m_socket, SIGNAL(disconnected()), this, SLOT(slot_clientDisconnected()) ) )
                    {
                        std::cerr << "(EE) ServerClient::set "
                                  << " ServerClient " << m_id
                                  << " Connect 3 not possible!"
                                  << std::endl;
                        ok = false;
                    }
                }
                else
                {
                    std::cerr << "(EE) ServerClient::set "
                              << " ServerClient "
                              << " index is negative "
                              << " Connection " << socket
                              << std::endl;
                }
            }
            else
            {
                std::cerr << "(EE) ServerClient::set "
                          << " ServerClient " << clientId
                          << " Connection is NULL!"
                          << std::endl;
            }
        }
        else
        {
            std::cerr << "(EE) ServerClient::set "
                      << " ServerClient " << m_id
                      << " Connection " << m_socket
                      << " Index alredy set."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "(EE) ServerClient::set "
                  << " ServerClient " << m_id
                  << " Connection " << m_socket
                  << " already set!"
                  << std::endl;
    }

    Trace::print( MTP_CLIENT, STP_CLIENT_SET,
                  "ServerClient::set End " + QString::number(ok) );

    return ok;
}

// Check if the connection to a client is established.
bool ServerClient::isConnected() const
{
    const bool connected = ( ( 0 != m_socket) &&
                             ( m_id >= 0 ) &&
                             ( QAbstractSocket::ConnectedState == m_socket->state() ) );
    return connected;
}

// Stop connection to the server.
bool ServerClient::stopConnection()
{
    Trace::print( MTP_CLIENT, STP_CLIENT_CONNECTION,
                  "ServerClient::stopConnection Start " + QString::number(m_id) );

    bool ok = false;

    if ( isConnected() )
    {
        m_socket->disconnectFromHost();

#ifdef QT_DEBUG
        std::cout << "(II) ServerClient::stopConnection "
                  << " ServerClient " << m_id
                  << " connection to server stopped."
                  << std::endl;
#endif
        ok = true;
    }
    else
    {
        std::cout << "(EE) ServerClient::stopConnection "
                  << " ServerClient " << m_id
                  << " already disconnected."
                  << std::endl;
    }

    Trace::print( MTP_CLIENT, STP_CLIENT_CONNECTION,
                  "ServerClient::stopConnection End " + QString::number(ok) );

    return ok;
}
    
// Send some data to a client.
bool ServerClient::send( const QString& data, const int msecs )
{
    Trace::print( MTP_CLIENT, STP_CLIENT_SEND,
                  "ServerClient::send Start " + QString::number(m_id) + " " + data );

    bool ok = false;

    if ( isConnected() )
    {
        if ( m_socket->isWritable() )
        {
            m_socket->write( (data + "|").toLatin1() );
            
#ifdef QT_DEBUG
            std::cout << "(II) ServerClient::send "
                      << " ServerClient " << m_id
                      << " Socket " << m_socket
                      << " Send \"" << data.toStdString() << "\"."
                      << std::endl;        
#endif

#ifdef QT_DEBUG
            std::cout << "(II) ServerClient::send "
                      << " ServerClient " << m_id
                      << " Socket " << m_socket
                      << " Waiting for " << m_socket->bytesToWrite()
                      << " Bytes to be written."
                      << std::endl;        
#endif        

            // wait until bytes has been written
            ok = m_socket->waitForBytesWritten( msecs );
            
            if ( !ok )
            {
                // we could not send the data, but (!) maybe we have
                // send them before
                // so we check if there is still data in the buffer
                // that has not been sent

                // It's possible that we will receive a disconnect
                // at this point if the client has disconnected
                // (without saying so). This client would be deleted
                // then from outside and we are not allowed to access it.
                if ( isConnected() )
                {
                    if ( m_socket->bytesToWrite() > 0 )
                    {
                        std::cerr << "(EE) ServerClient::send "
                                    << " ServerClient " << m_id
                                  << " Socket " << m_socket
                                  << ", " << m_socket->bytesToWrite()
                                  << " Bytes not sent!"
                                  << std::endl;
                    }
                    else
                    {
                        ok = true;
                    }
                }
            }

#ifdef QT_DEBUG
            std::cout << "(II) ServerClient::send "
                      << " ServerClient " << m_id
                      << " Socket " << m_socket
                      << " Bytes written: " << ok << "."
                      << std::endl;        
#endif
        }
        else
        {
            std::cerr << "(EE) ClientConnection::send "
                      << " ServerClient " << m_id
                      << " Socket " << m_socket
                      << " is not writeable."
                      << std::endl;        
        }
    }
#ifdef QT_DEBUG
    else
    {
        std::cerr << "(EE) ServerClient::send "
                  << " ServerClient " << m_id
                  << " no connection " << m_socket
                  << std::endl;        
    }
#endif

    Trace::print( MTP_CLIENT, STP_CLIENT_SEND,
                  "ServerClient::send End " + QString::number(ok) );
    
    return ok;
}

// Data can be read from the connection.
void ServerClient::slot_receiveData()
{
    Trace::print( MTP_CLIENT, STP_CLIENT_RECEIVE,
                  "ServerClient::slot_receiveData Start " + QString::number(m_id) );

    if ( isConnected() )
    {
        if ( m_socket->isReadable() )
        {
            const QString data = m_socket->readAll();

#ifdef QT_DEBUG
            std::cout << "(II) ServerClient::slot_receiveData "
                      << " ServerClient " << m_id
                      << " Socket " << m_socket
                      << " Received \"" << data.toStdString() << "\"."
                      << std::endl;
#endif

            // send signal that connects this connection
            // to the client to receive and process the data
            emit sig_receiveData( data, m_id );
        }
        else
        {
            std::cerr << "(EE) ServerClient::slot_receiveData "
                      << " ServerClient " << m_id
                      << " Socket " << m_socket
                      << " is not readable."
                      << std::endl;        
        }
    }
#ifdef QT_DEBUG
    else
    {
        std::cerr << "(EE) ServerClient::slot_receiveData "
                  << " ServerClient " << m_id
                  << " no connection " << m_socket
                  << " or stream not readable: "
                  << (m_socket && m_socket->isReadable())
                  << std::endl;        
    }
#endif    
}

// an error occured in the client connection
void ServerClient::slot_displayError( QAbstractSocket::SocketError socketError )
{
    // ignore closing of connections
    // ignore timeouts 
    if ( QAbstractSocket::RemoteHostClosedError != socketError &&
         QAbstractSocket::SocketTimeoutError    != socketError )
    {
        std::cerr << "(EE) ServerClient::slot_displayError "
                  << " ServerClient " << m_id
                  << " Socket " << m_socket
                  << " Error " << socketError
                  << std::endl;
    }
}

// the client has been disconnected
void ServerClient::slot_clientDisconnected()
{
    Trace::print( MTP_CLIENT, STP_CLIENT_CONNECTION,
                  "ServerClient::slot_clientDisconnected Start " + QString::number(m_id) );

#ifdef QT_DEBUG
    std::cout << "(II) ServerClient::slot_clientDisconnected "
              << " ServerClient " << m_id
              << " disconnected " << m_socket
              << " sender " << sender()
              << std::endl;
#endif

    // disconnect client
    emit sig_clientDisconnected( m_id );

    Trace::print( MTP_CLIENT, STP_CLIENT_CONNECTION,
                  "ServerClient::slot_clientDisconnected End " );
}

        
#ifdef QT_DEBUG
// Print client connection informations.
void ServerClient::print( const int index ) const
{
    std::cout << "(II) ServerClient::print ";
    if ( index >= 0 )
    {
        std::cout << " " << index;
    }
    std::cout << " ServerClient " << this
              << " id " << m_id
              << " connection " << m_socket
              << std::endl;
}
#endif

