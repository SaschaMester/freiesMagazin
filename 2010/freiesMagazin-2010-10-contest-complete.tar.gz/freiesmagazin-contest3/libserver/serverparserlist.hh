/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef SERVERPARSERLIST_HH
#define SERVERPARSERLIST_HH

// Own
/////////
#include "direction.hh"
#include "serverparsercommand.hh"

// Qt
////////
#include <QList>
#include <QChar>

// forward declaration
//////////////////////////
class ServerParser;
class QString;

/// List of server parsers.
/**
 * Each connected client to a server should have it's own
 * server parser to process the received commands.
 */
class ServerParserList
{
public:

    ////////////////////////////////
    // Constructor and Operators
    ////////////////////////////////

    /// Constructor
    ServerParserList();
    
    /// Destructor.
    ~ServerParserList();
    
    ////////////////////////////////
    // Setting data
    ////////////////////////////////

    /// Delete all elements
    void clear();
    
    /// Create and add new parser.
    /**
     * @return true if the parser could be created and the id
     * is uniqe
     * @param parserId Parser that should be removed (not list index).
     */
    bool add( const int parserId );
    
    /// Remove a parser.
    /**
     * @param parserId Parser that should be removed (not list index).
     * @return true if parser could be removed
     */
    bool remove( const int parserId );

    /// Reset a parser.
    /**
     * @param parserId Parser that should be reset (not list index).
     * @return true if parser could be reset
     */
    bool reset( const int parserId );

    /// Separate data and extract command as new string.
    /**
     * It's possible that the string contains several commands
     * separated by a special separator. On the other hand it is
     * possible that the string is not finished and no separator
     * is found. That means we must wait till the command is complete.
     * The commands will be added in m_commandQueue and can be
     * processed later, if the index is correct.
     * 
     * @param data String with reveived data from a network connection.
     * @param parserId Id of the sender of the parsed commands (-1 means the server).
     * @param separator Separator to separate the given data, default
     *        is the pipe symbol ('|')
     * @return true if string could be separated
     */
    bool separate( const QString& data, const int parserId,
                   const QChar& separator = '|' );

    /// Set flag if processing of commands is active.
    /**
     * @param parserId The parser that will be processed.
     * @param active Flag if processing is active or not.
     * @return true if flag could be set
     */
    bool setProcessed( const int parserId, const bool active ) const;
    
    ////////////////////////////////
    // Getting data
    ////////////////////////////////
    
    /// Return stored movement.
    /**
     * This variable is set, if SPC_MOVE is the current command.
     * @param move Direction of client
     * @param parserId Index of parser that should return data.
     * @return true if data could bet get
     */
    bool getMovement( Direction& move, const int parserId ) const;

    /// Return stored view.
    /**
     * This variable is set, if SPC_MOVE is the current command.
     * @param view View of client
     * @param parserId Index of parser that should return data.
     * @return true if data could bet get
     */
    bool getView( Direction& view, const int parserId ) const;

    /// Return true if processing of commands is active.
    /**
     * @param parserId The parser id (not list index).
     * @return true if parser is currently processed
     */
    bool isProcessed( const int parserId ) const;

    /// Return true if command queue is empty.
    /**
     * @param parserId The parser id (not list index).
     * @return true if command queue is empty
     */
    bool isCommandQueueEmpty( const int parserId ) const;

    /// Process next command from command queue.
    /**
     * The next element from the command queue will be get and
     * processed if possible. The return value tell the caller
     * what command it is and what data he can get now.
     * Normally the other class should process or at least get and
     * reset all data. Otherwise it could come to an error.
     * Note: Before processing you should call setProcessed()
     * so that not other process can get the parser data.
     * @return command enum that tells which command has been processed
     */
    ServerParserCommand processNextCommand( const int parserId );
    
    //////////////////////////
    // Index-based getter
    //////////////////////////

    /// Return number of elements in list.
    int count() const { return m_list.count(); }

    /// Return parser id of some parser.
    /**
     * This method is the only one that uses the correct list index.
     * All other methods will use the parserId.
     * @param index Index in list.
     * @return parser id to index or -1 if not found
     */
    int getParserId( const int index ) const;

private:

    /// Find a client id in the parser list.
    /**
     * @return index in list with this parserId or -1 if not found
     */
    int find( const int parserId ) const;

    /// CHeck if parserId is already stored.
    /**
     * @return true if parserId is contained in list
     */
    int contains( const int parserId ) const;

private:
    /// Copy constructor.
    /**
     * This is not implemented, because I do not want to copy the list.
     */
    ServerParserList( const ServerParserList& list );

    /// Assignment operator.
    /**
     * This is not implemented, because I do not want to copy the list.
     */
    ServerParserList& operator=( const ServerParserList& list );

private:

    /// List with all parser.
    /**
     * Each client has it's own parser so that we do not mix up
     * commands.
     */
    QList<ServerParser*> m_list;
    
};

#endif // SERVERPARSERLIST_HH
