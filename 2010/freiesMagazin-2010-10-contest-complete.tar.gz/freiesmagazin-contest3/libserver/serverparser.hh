/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef SERVERPARSER_HH
#define SERVERPARSER_HH

// Own
////////
#include "parser.hh"
#include "serverparsercommand.hh"
#include "direction.hh"

// Qt
////////
#include <QString>

// Forward declarations
//////////////////////////
class QStringList;

/// Class for parsing network commands on a server.
/**
 * This class receives data from its base class Parser.
 * It checks the strings for the sender, commands and parameters.
 * If a data string has been parsed the command will
 * be stored inside a queue and can be processed later.
 * 
 * Note: ServerParser parses client connections that means
 * all data a server can receive from a client.
 */
class ServerParser : public Parser
{
public:
    /// Constructor.
    ServerParser( const int id );

    /// Initializes/reset all variables with default values.
    /**
     * This method should be called after processNextCommand
     * and the caller has processed all variables outside.
     * If you do not call this method the variables will never
     * be set back and no further command can be processed.
     */
    void reset();
    
    /// Reset all data and deletes all commands in the command queue.
    /**
     * This is the same as reset() but will delete all commands in the
     * queue. So handle with care!
     */
    void resetAll();

    /// Process next command from command queue.
    /**
     * The next element from the command queue will be get and
     * processed if possible. The return value tell the caller
     * what command it is and what data he can get now.
     * Normally the other class should process or at least get and
     * reset all data. Otherwise it could come to an error.
     * Note: Before processing you should call setProcessed()
     * so that not other process can get the parser data.
     * @return command enum that tells which command has been processed
     */
    ServerParserCommand processNextCommand();

    /// Set flag if processing of commands is active.
    void setProcessed( const bool active ) { m_isProcessed = active; }

    //////////////////////
    // Getter-methods
    //////////////////////

    /// Return true if processing of commands is active.
    bool isProcessed() const { return m_isProcessed; }

    /// Return client sender id.
    /**
     * This variable is set in the constructor.
     * @return client sender id
     */
    int getId() const { return m_senderClientId; }
    
    /// Return stored movement direction.
    /**
     * This variable is set, if SPC_MOVE is the current command.
     * @return view
     */
    Direction getMovement() const { return m_move; }

    /// Return stored view.
    /**
     * This variable is set, if SPC_MOVE is the current command.
     * @return view
     */
    Direction getView() const { return m_view; }

private:
    /// Process command.
    /**
     * Process all command parts in the given list.
     * It then stores the relevant parts inside variables.
     * Depending on the data given the return value
     * tells the caller what are the correct variables to get.
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ServerParserCommand processCommand( QStringList& commandParts );

    /// Process command that is for the server.
    /**
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ServerParserCommand processServerCommand( QStringList& commandParts );

    /// Process command that the client has accepted its id.
    /**
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ServerParserCommand processServerCommandIdOk( QStringList& commandParts );

    /// Process command that the client has not accepted its id.
    /**
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ServerParserCommand processServerCommandIdNotOk( QStringList& commandParts );

    /// Process command for movement of client.
    /**
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ServerParserCommand processServerCommandMove( QStringList& commandParts );
    
private:

    /// Check if all variables has been processed/resetted.
    /**
     * This method checks all variables if some is still set before
     * processing another command. If one is still set that means
     * that noone has get it outside.
     * @return true if all data has been processed or reset properly.
     */
    bool isAllVarsProcessed();

    /// Process a command that extracts a direction.
    /**
     * @param commandParts List with all command parts to process.
     * @return true if no error has occured
     */
    bool processCommandMoveDir( QStringList& commandParts );

    /// Process a command that extracts a direction.
    /**
     * @param commandParts List with all command parts to process.
     * @return true if no error has occured
     */
    bool processCommandViewDir( QStringList& commandParts );

private:
    //////////////////////
    // members
    //////////////////////

    /// Current command that has been processed.
    /**
     * If there is no command, it will be set to SPC_NO_COMMAND (default).
     */
    ServerParserCommand m_commandId;

    /// The client id that has been sent the command.
    /**
     * We will have a own parser for every connection
     * so that we cannot mix the the signals. The id
     * will be set one time in the constructor and is fixed then.
     */
    int m_senderClientId;

    /// This flag tells if the parser currently is processing something.
    /**
     * The flag must be set via setProcessed() from outside
     * if the processing starts.
     */
    bool m_isProcessed;

    /// New direction that should be set for movement.
    /**
     * Only valid if the command is SPC_MOVE.
     */
    Direction m_move;

    /// New direction that should be set for viewing.
    /**
     * Only valid if the command is SPC_MOVE
     */
    Direction m_view;
    
};

#endif // SERVERPARSER_HH
