/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef SERVERCLIENT_HH
#define SERVERCLIENT_HH

// Qt
////////
#include <QObject>
#include <QAbstractSocket>

// Forward declarations
////////////////////////////
class QTcpSocket;

/// Server Client.
/**
 * This class represents the a client that is stored
 * by the server.
 * If the connection is NULL and/or the index is negative
 * no connection is established.
 * Therefore the connection and the index are the only
 * members that can only be set one time. If they are set
 * you must call reset() first before setting a new connection
 * or index.
 * The class is derived from QObject to inherit the
 * signal/slot concept.
*/
class ServerClient : public QObject
{
Q_OBJECT

public:

    /////////////////////////////
    // Constructors/Operators
    /////////////////////////////

    /// Constructor
    ServerClient();
    
    /// Destructor.
    /**
     * Resets all data.
     * @see reset()
     */
    ~ServerClient();

    /////////////////////////////
    // Setting data.
    /////////////////////////////

    /// Reset all data.
    /**
     * Even if the connection has been allocated from outside
     * we are allowed to delete it here to break the connection.
     * Normally it has been closed before by the client or
     * the server.
     * All other data is reset too so that a new connection can
     * be established.
     */
    void reset();

    /// Set new connection and index.
    /**
     * Set new TCP socket that was created in the server
     * from an incoming client connection.
     * It will only be set if no connection and no index
     * was set before! So you need to call reset() first,
     * if you want to set a new connection.
     * @param socket client connection
     * @param clientId client id, that must be non negative
     * @return true if connection and index could be set
     */
    bool set( QTcpSocket* socket, const int clientId );
    
    /////////////////////////////
    // Getting data
    /////////////////////////////

    /// Return index of the client.
    int getIndex() const { return m_id; }

    /// Check if the connection to a client is established.
    /**
     * Established means that the TCP socket pointer is not NULL,
     * the index is not negative and ths socket connection
     * is in the state QAbstractSocket::ConnectedState.
     * @return true if connection is established
     */
    bool isConnected() const;

    /////////////////////////////
    // Sending data
    /////////////////////////////
    
    /// Send some data to a client.
    /**
     * The data is send to the TCP socket. We will wait
     * one second till the data has been sent.
     * @param data to sent
     * @return true if data has been sent
     */
    bool send( const QString& data, const int msecs = 1000 );
    
#ifdef QT_DEBUG
    /// Print client informations.
    /**
     * @param index optional index to print in front of data,
     *        the index is ignored if negative
     */
    void print( const int index = - 1 ) const;
#endif

signals:
    /// Signal when data has been received on a client connection.
    /**
     * The signal is given if new data has been received.
     * Normally the signal will caught by the client
     * so that it can interpret the data.
     * @param data received data
     * @param clientId client connection that has received the data
     */
    void sig_receiveData( const QString& data, const int clientId );
    
    /// Signal when a client has been disconnected.
    /**
     * The signal should be catched from the server so that
     * it can delete the connection from its connections list
     * and inform all other clients about the disconnection.
     * @param index client that has disconnected
     */
    void sig_clientDisconnected( const int clientId );

private slots:

    /// Data can be read from a client connection.
    /**
     * The client has received some data that can be read
     * from the TCP socket.
     */
    void slot_receiveData();
    
    /// An error occured in the client connection.
    /**
     * If an error occurred in the connection this method is called.
     * If the client has only closed the connection no error will
     * be printed.
     * @param socketError error id
     */
    void slot_displayError( QAbstractSocket::SocketError socketError );
    
    /// The client has disconnected.
    /**
     * This method is called when the connection is closed.
     */
    void slot_clientDisconnected();

private:
    /// Stop connection to the server.
    /**
     * If a connection is established to a server, it will be closed.
     * @return true if server is stopped
     */
    bool stopConnection();

private:
    /// Copy constructor.
    /**
     * This is not implemented because I don't want a copy.
     */
    ServerClient( const ServerClient& client );

    /// Assigment operator.
    /**
     * This is not implemented because I don't want a copy.
     */
    const ServerClient& operator=( const ServerClient& client );

private:

    /// TCP connection to client.
    QTcpSocket* m_socket;
    
    /// Index of the client this connection points to.
    /**
     * The index is important so that the server knows
     * which client has which id. Otherwise he would
     * need to poll each client if a special is for
     * him or the client needs to decide it itself.
     */
    int m_id;
};

#endif // SERVERCLIENT_HH
