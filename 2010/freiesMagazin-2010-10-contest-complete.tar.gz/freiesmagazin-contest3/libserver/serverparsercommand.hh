/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef SERVERPARSERCOMMAND_HH
#define SERVERPARSERCOMMAND_HH

/// Enum for all commands that can be processed.
/**
 * Depending on this enum another class get the correct data it
 * needs after a command is processed.
 */
enum ServerParserCommand
{
    SPC_NO_COMMAND = 0,         // no command has been given
    SPC_ERROR,                  // there was an error processing a command
    SPC_PING,                   // the client has pinged the server
    SPC_ID_OKAY,                // the client accepted its id
    SPC_ID_NOT_OKAY,            // the client does not accepted its id
    SPC_MOVE,                   // movement and rotation of an client
    
    SPC_NUM_COMMANDS            // number of commands
                                // do not add new commands after this line!
};

#endif // SERVERPARSERCOMMAND_HH
