/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "serverparser.hh"
#include "trace.hh"

// Qt
////////
#include <QStringList>

// Sys
////////
#include <iostream>

// Constructor.
ServerParser::ServerParser( const int id )
: Parser(), m_senderClientId(id), m_isProcessed(false)
{
    Trace::print( MTP_SERVERPARSER, STP_SP_STRUCTOR,
                  "ServerParser::ServerParser Start" );

    // initialize variables
    reset();

    Trace::print( MTP_SERVERPARSER, STP_SP_STRUCTOR,
                  "ServerParser::ServerParser Start" );
}

// Initializes/reset all variables with default values.
void ServerParser::reset()
{
    Trace::print( MTP_SERVERPARSER, STP_SP_SET,
                  "ServerParser::reset Start" );

    // no command given
    m_commandId = SPC_NO_COMMAND;

    // no dir set
    m_move = DIRECTION_NONE;    

    // no view set
    m_view = DIRECTION_NONE;

    // processing is not active
    m_isProcessed = false;

    Trace::print( MTP_SERVERPARSER, STP_SP_SET,
                  "ServerParser::reset End " );
}

// Reset all data and deletes all commands in the command queue.
void ServerParser::resetAll()
{
    Trace::print( MTP_SERVERPARSER, STP_SP_SET,
                  "ServerParser::resetAll Start " );

    reset();

    setProcessed(true);
    
    // delete queue
    while ( !isCommandQueueEmpty() )
    {
        getNextCommand();
    }

    setProcessed(false);

    Trace::print( MTP_SERVERPARSER, STP_SP_SET,
                  "ServerParser::resetAll End " );
}
    
// Process next command from command queue.
ServerParserCommand ServerParser::processNextCommand()
{
    Trace::print( MTP_SERVERPARSER, STP_SP_PROCESS,
                  "ServerParser::processNextCommand Start " );

    ServerParserCommand nextCommand = SPC_NO_COMMAND;
    
    if ( !isCommandQueueEmpty() )
    {
        // there is one element in the queue

        // check for unprocessed variables
        if ( isAllVarsProcessed() )
        {
            // get next command
            const Command command = getNextCommand();

            // split the string by spaces into parts
            QStringList commandParts( Parser::split( command.getCommand() ) );
            
#ifdef QT_DEBUG
    std::cout << "(II) ServerParser::processNextCommand "
              << " Command "
              << " \"" << command.getCommand().toStdString() << "\""
              << " from sender " << command.getIndex()
              << " list count: " << commandParts.count()
              << std::endl;
#endif

            // process all command parts
            nextCommand = processCommand( commandParts );

            if ( SPC_ERROR != nextCommand )
            {
                // if the command has not produced an error
                // the command part list should be empty
                
                if ( !commandParts.isEmpty() )
                {
                    std::cerr << "(EE) ServerParser::processNextCommand "
                              << " There are still "
                              << commandParts.count()
                              << " command parts in the list: "
                              << "\"" << commandParts.first().toStdString() << "\""
                              << std::endl;
 
                    reset();
                    nextCommand = SPC_ERROR;
                }
            }
            
            if ( SPC_ERROR != nextCommand )
            {
                // if the command has not produced an error
                // the sender should match it extracted client id
                
                if ( command.getIndex() != m_senderClientId )
                {
                    std::cerr << "(EE) ServerParser::processNextCommand "
                              << " Client id in string " 
                              << m_senderClientId
                              << " does not match sender of command "
                              << command.getIndex()
                              << std::endl;
 
                    reset();
                    nextCommand = SPC_ERROR;
                }
            }
        }
        else
        {
            // else there are still variables that has not been processed
            // so we will wait till this is done.
            nextCommand = m_commandId;
        }
    }

    Trace::print( MTP_SERVERPARSER, STP_SP_PROCESS,
                  "ServerParser::processNextCommand End " + QString::number(nextCommand) );
    
    return nextCommand;
}

// Check if all variables has been processed/resetted.
bool ServerParser::isAllVarsProcessed()
{
    Trace::print( MTP_SERVERPARSER, STP_SP_PROCESS,
                  "ServerParser::isAllVarsProcessed Start " );

    bool processed = true;

    if ( SPC_NO_COMMAND != m_commandId )
    {
        processed = false;
    }

    // Note: It's enough to check if there is no command pending.
    // If none is, we can set a new command and only this variables
    // are valid.

#ifdef QT_DEBUG
    std::cout << "(II) ServerParser::isAllVarsProcessed "
              << " All processed: "   << processed
              << std::endl;
#endif

    Trace::print( MTP_SERVERPARSER, STP_SP_PROCESS,
                  "ServerParser::isAllVarsProcessed End " + QString::number(processed) );

    return processed;
}

// Process command.
ServerParserCommand ServerParser::processCommand( QStringList& commandParts )
{
    Trace::print( MTP_SERVERPARSER, STP_SP_PROCESS,
                  "ServerParser::processCommand Start " + QString::number( commandParts.count() ) );

    ServerParserCommand nextCommand = SPC_NO_COMMAND;

    // Check if there is a least one command part
    if ( commandParts.count() > 0 )
    {
        // process other command parts
        nextCommand = processServerCommand( commandParts );
    }
    else
    {
        std::cerr << "(EE) ServerParser::processCommand "
                  << " Command part list is empty."
                  << std::endl;
                  
        reset();
        nextCommand = SPC_ERROR;
    }
    
    Trace::print( MTP_SERVERPARSER, STP_SP_PROCESS,
                  "ServerParser::processCommand End " + QString::number(nextCommand) );

    return nextCommand;
}

// Process command that is for the server.
ServerParserCommand ServerParser::processServerCommand( QStringList& commandParts )
{
    Trace::print( MTP_SERVERPARSER, STP_SP_PROCESS,
                  "ServerParser::processServerCommand Start " + QString::number( commandParts.count() ) );

    ServerParserCommand nextCommand = SPC_NO_COMMAND;

    // Check if there is a least one command part
    if ( commandParts.count() > 0 )
    {
#ifdef QT_DEBUG
        std::cout << "(II) ServerParser::processServerCommand "
                  << " Command"
                  << " \"" << commandParts.first().toStdString() << "\"."
                  << std::endl;
#endif

        if  ( 0 == commandParts.first().compare( "ID_OKAY" ) )
        {
            // this is an id receipt
            
            // delete first part that has been processed
            commandParts.removeFirst();              
            
            // the client has accepted its id
            nextCommand = SPC_ID_OKAY;
        }
        else if  ( 0 == commandParts.first().compare( "ID_NOT_OKAY" ) )
        {
            // this is an id receipt
            
            // delete first part that has been processed
            commandParts.removeFirst();              
            
            // the client has not accepted its id
            nextCommand = SPC_ID_NOT_OKAY;
        }
        else if  ( 0 == commandParts.first().compare( "PING" ) )
        {
            // this is just a ping
            
            // delete first part that has been processed
            commandParts.removeFirst();              
            
            // process the id given from the server
            nextCommand = SPC_PING;
        }
        else if  ( 0 == commandParts.first().compare( "MOVE" ) )
        {
            // delete first part that has been processed
            commandParts.removeFirst();
            
            // extract new player data
            nextCommand = processServerCommandMove( commandParts );
        }
        else
        {
            // everything else is not understood!
            std::cerr << "(EE) ServerParser::processServerCommand "
                      << " Do not understand command"
                      << " \"" << commandParts.first().toStdString() << "\"."
                      << std::endl;

            reset();
            nextCommand = SPC_ERROR;
        }
    }
    else
    {
        std::cerr << "(EE) ServerParser::processServerCommand "
                  << " Command part list is empty."
                  << std::endl;
        
        reset();
        nextCommand = SPC_ERROR;
    }
    
    Trace::print( MTP_SERVERPARSER, STP_SP_PROCESS,
                  "ServerParser::processServerCommand End " + QString::number(nextCommand) );

    return nextCommand;
}

// Process command for movement of client.
ServerParserCommand ServerParser::processServerCommandMove( QStringList& commandParts )
{
    Trace::print( MTP_SERVERPARSER, STP_SP_PROCESS,
                  "ServerParser::processServerCommandMove Start " + QString::number( commandParts.count() ) );

    ServerParserCommand nextCommand = SPC_NO_COMMAND;
    
    // Check if there is a least three command parts
    // first command is the position
    if ( processCommandMoveDir( commandParts ) )
    {
        // second command is the viewing direction
        if ( processCommandViewDir( commandParts ) )
        {
            nextCommand = SPC_MOVE;
        }
        else
        {
            reset();
            nextCommand = SPC_ERROR;
        }
    }
    else
    {
        reset();
        nextCommand = SPC_ERROR;
    }

    Trace::print( MTP_SERVERPARSER, STP_SP_PROCESS,
                  "ServerParser::processServerCommandMove End " + QString::number(nextCommand) );

    return nextCommand;
}

// Process a command that extracts a direction.
bool ServerParser::processCommandMoveDir( QStringList& commandParts )
{
    Trace::print( MTP_SERVERPARSER, STP_SP_PROCESS,
                  "ServerParser::processCommandMoveDir Start " + QString::number( commandParts.count() ) );

    bool ok = false;

    // Check if there is a least one command part
    if ( commandParts.count() > 0 )
    {
#ifdef QT_DEBUG
        std::cout << "(II) ServerParser::processCommandMoveDir "
                  << " Command"
                  << " \"" << commandParts.first().toStdString() << "\"."
                  << std::endl;
#endif

        // the next command holds a direction
        if ( Parser::getDir( m_move, commandParts.first() ) )
        {
            // The direction could be extracted.
            ok = true;
        }

        // delete first part that has been processed
        commandParts.removeFirst();              
    }
    else
    {
        std::cerr << "(EE) ServerParser::processCommandMoveDir "
                  << " Command part list is empty."
                  << std::endl;
    }
    
    Trace::print( MTP_SERVERPARSER, STP_SP_PROCESS,
                  "ServerParser::processCommandMoveDir End " + QString::number(ok) );

    return ok;
}

// Process a command that extracts a direction.
bool ServerParser::processCommandViewDir( QStringList& commandParts )
{
    Trace::print( MTP_SERVERPARSER, STP_SP_PROCESS,
                  "ServerParser::processCommandViewDir Start " + QString::number( commandParts.count() ) );

    bool ok = false;

    // Check if there is a least one command part
    if ( commandParts.count() > 0 )
    {
#ifdef QT_DEBUG
        std::cout << "(II) ServerParser::processCommandViewDir "
                  << " Command"
                  << " \"" << commandParts.first().toStdString() << "\"."
                  << std::endl;
#endif

        // the next command holds a direction
        if ( Parser::getDir( m_view, commandParts.first() ) )
        {
            if ( m_view != DIRECTION_NONE )
            {
                // The direction could be extracted.
                ok = true;
            }
            else
            {
                std::cerr << "(EE) ServerParser::processCommandViewDir "
                          << " Client move "
                          << m_view
                          << " is not valid."
                          << std::endl;
            }
        }

        // delete first part that has been processed
        commandParts.removeFirst();              
    }
    else
    {
        std::cerr << "(EE) ServerParser::processCommandViewDir "
                  << " Command part list is empty."
                  << std::endl;
    }
    
    Trace::print( MTP_SERVERPARSER, STP_SP_PROCESS,
                  "ServerParser::processCommandViewDir End " + QString::number(ok) );

    return ok;
}
