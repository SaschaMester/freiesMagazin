/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef SERVERCLIENTLIST_HH
#define SERVERCLIENTLIST_HH

// Qt
////////
#include <QObject>
#include <QList>

// Forward declaration
//////////////////////////
class ServerClient;
class QTcpSocket;

/// List of client connections.
/**
 * The class contains a QList and has some additional functions.
 * It's not derived because that would mean to overload some
 * default functions so that the list is always sorted.
 * It can happen that the indices of the clients in the list have
 * gaps (e.g. if a client disconnects). If a new client connection
 * is added it will get the first free client index.
 * Because we are not allowed to copy client connections (because
 * of the TCP socket pointer) we will only store pointers
 * as list elements.
 */
class ServerClientList : public QObject
{
Q_OBJECT

public:

    ////////////////////////////////
    // Constructor and Operators
    ////////////////////////////////

    /// Constructor
    ServerClientList();
    
    /// Destructor.
    ~ServerClientList();

    ////////////////////////////////
    // Getting data
    ////////////////////////////////

    /// Return number of connection clients.
    /**
     * This is equal to the current active number of
     * client connections in the list.
     * @return number of connection clients
     */
    int getNumConnectedClients() const;

    /// Get list with all client ids, that are currently connected.
    /**
     * @param list List with client ids.
     **/
    void getConnectedClients( QList<int>& list ) const; 

    /// Check if client exists.
    /**
     * @param clientId Client to check.
     * @return true if client exists else false
     */
    bool exists( const int clientId ) const;
        
    ////////////////////////////////
    // Setting data
    ////////////////////////////////
    
    /// Clears list with all clients and stop connections.
    void clear();

    /// Add new client connection.
    /**
     * Add a new client connection with the given TCP socket into the
     * list. Each client connection will get a unique id. The index
     * will be given depending on the first free index in
     * the list, starting at 0.
     * @return Id of new client if connection could be stored or
     *         a negative value if an error occured.
     */
    int add( QTcpSocket* client );
    
    /// Remove a client connection from the list.
    /**
     * Remove the client with the correct index from the list.
     * Removing means that the client will be disconnected and reset.
     * @param clientId Id of client that should be removed (not list index!)
     * @return true if client(s) could be removed
     */
    bool remove( const int clientId );

    ////////////////////////////
    // Sending methods
    ///////////////////////////    

    /// Send some data to a client.
    /**
     * We will wait 1 second till the data must have been sent.
     * @param clientId Id of client we want data send to (not list index!)
     * @param data to send
     * @return true if data has been sent
     */
    bool send( const int clientId, const QString& data, const int msecs = 1000 );

    /// Send data to a all clients that listen.
    /**
     * We will wait 1 second till the data must have been sent.
     * @param data to send
     * @return true if data has been sent
     */
    bool sendAll( const QString& data, const int msecs = 1000 );

    /// Send data to a all clients except one.
    /**
     * We will wait 1 second till the data must have been sent.
     * @param data to send
     * @param clientId Client that should not receive the message
     * @return true if data has been sent
     */
    bool sendAllExcept( const QString& data, const int clientId, const int msecs = 1000 );

    /// Send data to a all clients except one and some more. ;)
    /**
     * We will wait 1 second till the data must have been sent.
     * @param data to send
     * @param clientId Client that should not receive the message
     * @param clientIdList List of client IDs that should not receive the message either
     * @return true if data has been sent
     */
    bool sendAllExcept( const QString& data, const int clientId, const QList<int>& clientIdList, const int msecs = 1000 );

#ifdef QT_DEBUG
    /// Print all client connections.
    void print() const;
#endif

signals:
    /// Signal when data has been received on a client connection.
    /**
     * The signal is given if new data has been received.
     * Normally the signal will caught by the client
     * so that it can interpret the data.
     * @param data received data
     * @param clientId client connection that has received the data
     */
    void sig_receiveData( const QString& data, const int clientId );
    
    /// Signal when a client has been disconnected.
    /**
     * The signal should be catched from the server so that
     * it can delete the connection from its connections list
     * and inform all other clients about the disconnection.
     * @param index client that has disconnected
     */
    void sig_clientDisconnected( const int clientId );

private slots:

    /// A client has disconnected.
    /**
     * @param index client that has disconnected
     */
    void slot_clientDisconnected( const int clientId );

private:
    /// Get next free index, starting at 0.
    /**
     * Because the list can have gaps (if a client disconnects)
     * we search the first free index in the remaining clients.
     * @return the index or -1 if no index is free (should not happen!)
     */
    int getNextFreeIndex();
    
    /// Check if clientId is valid.
    bool isValid( const int clientId, const bool needConnect = true ) const;

    /// Copy constructor.
    /**
     * This is not implemented, because I do not want to copy the list.
     */
    ServerClientList( const ServerClientList& list );

    /// Assignment operator.
    /**
     * This is not implemented, because I do not want to copy the list.
     */
    ServerClientList& operator=( const ServerClientList& list );

private:

    /// Sorted list with all client connections.
    /**
     * It will increase when more clients are connected.
     * Disconnected clients will not be removed from the list
     * but the place will be kept "empty".
     * With this method we have less memory loss and an access
     * time of O(1) (instead of O(log n) for a list with
     * index gaps).
     */
    QList<ServerClient*> m_list;
    
};

#endif // SERVERCLIENTLIST_HH
