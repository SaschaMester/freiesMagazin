/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "serverclientlist.hh"
#include "serverclient.hh"
#include "trace.hh"

// Qt
////////
#include <QTcpSocket>

// Sys
////////
#include <iostream>

// Constructor
ServerClientList::ServerClientList()
: QObject()
{
    Trace::print( MTP_CLIENTLIST, STP_CL_STRUCTOR,
                  "ServerClientList::ServerClientList Start" );

    // nothing to do

    Trace::print( MTP_CLIENTLIST, STP_CL_STRUCTOR,
                  "ServerClientList::ServerClientList End" );
}
    
// Destructor.
ServerClientList::~ServerClientList()
{
    Trace::print( MTP_CLIENTLIST, STP_CL_STRUCTOR,
                  "ServerClientList::~ServerClientList Start" );

    // clear list
    clear();

    Trace::print( MTP_CLIENTLIST, STP_CL_STRUCTOR,
                  "ServerClientList::~ServerClientList End" );
}

// A client has disconnected.
void ServerClientList::slot_clientDisconnected( const int clientId )
{
    Trace::print( MTP_CLIENTLIST, STP_CL_ADDREMOVE,
                  "ServerClientList::slot_clientDisconnected Start "  + QString::number(clientId) );

#ifdef QT_DEBUG
    std::cout << "(II) ServerClientList::slot_clientDisconnected "
              << " Client " << clientId
              << " disconnected " 
              << " sender " << sender()
              << std::endl;
#endif

    // currently we will just send a signal
    emit sig_clientDisconnected( clientId );

    Trace::print( MTP_CLIENTLIST, STP_CL_ADDREMOVE,
                  "ServerClientList::slot_clientDisconnected End" );

}

// clears list with all clients and stop connections
void ServerClientList::clear()
{
    Trace::print( MTP_CLIENTLIST, STP_CL_GETSET,
                  "ServerClientList::clear Start" );

    // delete pointers
    while ( !m_list.isEmpty() )
    {
        // take first element
        ServerClient *client = m_list.takeFirst();

        // release memory if necessary
        if ( client )
        {
            delete client;
        }
    }

    Trace::print( MTP_CLIENTLIST, STP_CL_GETSET,
                  "ServerClientList::clear End" );
}

// Return number of connection clients.
int ServerClientList::getNumConnectedClients() const
{
    Trace::print( MTP_CLIENTLIST, STP_CL_GETSET,
                  "ServerClientList::getNumConnectedClients Start ");

    int num = 0;

    for ( int ii = 0; ii < m_list.count(); ii++ )
    {
        if ( isValid(ii) )
        {
            num++;
        }
    }

    Trace::print( MTP_CLIENTLIST, STP_CL_GETSET,
                  "ServerClientList::getNumConnectedClients End " + QString::number(num) );

    return num;
}

// Get list with all client ids, that are currently connected.
void ServerClientList::getConnectedClients( QList<int>& list ) const
{
    Trace::print( MTP_CLIENTLIST, STP_CL_GETSET,
                  "ServerClientList::getNumConnectedClients Start ");

    // clear list to start empty
    list.clear();

    for ( int ii = 0; ii < m_list.count(); ii++ )
    {
        if ( isValid(ii) )
        {
            // append index (= id), if the connection is valid
            list.append(ii);
        }
    }
}
    
// Add new client connection.
int ServerClientList::add( QTcpSocket* socket )
{
    Trace::print( MTP_CLIENTLIST, STP_CL_ADDREMOVE,
                  "ServerClientList::add Start" );

    int index = -1;

    // check if pointers are set
    if ( socket )
    {
        // Get next free index.
        index = getNextFreeIndex();
        
        // check that the indices are positive
        if ( index >= 0 )
        {
            bool ok = true;

            // connect signals
            if ( !connect( m_list[index], SIGNAL( sig_receiveData(const QString&,const int) ), this, SIGNAL( sig_receiveData(const QString&,const int) ) ) )
            {
                std::cerr << "(EE) ServerClientList::add "
                          << " Client " << index
                          << " Connect 1 not possible!"
                          << std::endl;
                ok = false;
            }

            if ( !connect( m_list[index], SIGNAL( sig_clientDisconnected(const int) ), this, SLOT( slot_clientDisconnected(const int) ) ) )
            {
                std::cerr << "(EE) ServerClientList::add "
                          << " Client " << index
                          << " Connect 1 not possible!"
                          << std::endl;
                ok = false;
            }

            if ( ok )
            {
#ifdef QT_DEBUG
                std::cout << "(II) ServerClientList::add "
                          << " Set client " << index
                          << " socket " << socket
                          << std::endl;
#endif

                // set new client
                m_list[index]->set( socket, index );
            }

        }
        else
        {
            index = -1;
        }
    }
    else
    {
        std::cerr << "(EE) ServerClientList::add "
                  << " Socket is NULL!"
                  << std::endl;
    }

    Trace::print( MTP_CLIENTLIST, STP_CL_ADDREMOVE,
                  "ServerClientList::add End " + QString::number(index) );

    // If the index is negative, that means that there was an error.
    return index;
}

// Remove a client connection from the list.
bool ServerClientList::remove( const int clientId )
{
    Trace::print( MTP_CLIENTLIST, STP_CL_ADDREMOVE,
                  "ServerClientList::remove Start " + QString::number(clientId) );

    bool ok = false;

    // false means that the client does not need to be connected to be valid
    if ( isValid(clientId, false) )
    {
        std::cout << "(II) ServerClientList::remove "
                  << " Remove client " << clientId
                  << std::endl;

        // disconnect all signals
        m_list[clientId]->disconnect();

        // reset client
        m_list[clientId]->reset();
    }

    Trace::print( MTP_CLIENTLIST, STP_CL_ADDREMOVE,
                  "ServerClientList::remove End " + QString::number(ok) );

    return ok;
}

// send some string to a client
bool ServerClientList::send( const int clientId, const QString& data, const int msecs )
{
    Trace::print( MTP_CLIENTLIST, STP_CL_SEND,
                  "ServerClientList::send Start " + QString::number(clientId) + " " + data );

    bool ok = false;

    if ( isValid(clientId) )
    {
        ok = m_list[clientId]->send( data, msecs );
    }
    
    Trace::print( MTP_CLIENTLIST, STP_CL_SEND,
                  "ServerClientList::send End " + QString::number(ok) );

    return ok;
}

// Send data to a all clients that listen.
bool ServerClientList::sendAll( const QString& data, const int msecs )
{
    Trace::print( MTP_CLIENTLIST, STP_CL_SEND,
                  "ServerClientList::sendAll Start " + data );

    bool ok = true;

    // Note: If the list is empty we will return true!

    for ( int ii = 0; ii < m_list.count(); ii++ )
    {
        if ( isValid(ii) )
        {
            if ( !m_list[ii]->send( data, msecs ) )
            {
                // sending failed
                ok = false;
            }
        }
    }
    
    Trace::print( MTP_CLIENTLIST, STP_CL_SEND,
                  "ServerClientList::sendAll End " + QString::number(ok) );

    return ok;
}

// Send data to a all clients except one.
bool ServerClientList::sendAllExcept( const QString& data, const int clientId, const int msecs )
{
    Trace::print( MTP_CLIENTLIST, STP_CL_SEND,
                  "ServerClientList::sendAllExcept Start " + data + " " + QString::number(clientId) );

    bool ok = true;

    // Note: If the list is empty we will return true!

    for ( int ii = 0; ii < m_list.count(); ii++ )
    {
        if ( isValid(ii) && clientId != ii )
        {
            if ( !m_list[ii]->send( data, msecs ) )
            {
                // sending failed
                ok = false;
            }
        }
    }
    
    Trace::print( MTP_CLIENTLIST, STP_CL_SEND,
                  "ServerClientList::sendAllExcept End " + QString::number(ok) );

    return ok;
}

/// Send data to a all clients except one and some more. ;)
bool ServerClientList::sendAllExcept( const QString& data, const int clientId, const QList<int>& clientIdList, const int msecs  )
{
    Trace::print( MTP_CLIENTLIST, STP_CL_SEND,
                  "ServerClientList::sendAllExcept Start " + data + " " + QString::number(clientId) );

    bool ok = true;

    // Note: If the list is empty we will return true!

    for ( int ii = 0; ii < m_list.count(); ii++ )
    {
        if ( isValid(ii) && clientId != ii && !clientIdList.contains(ii) )
        {
            if ( !m_list[ii]->send( data, msecs ) )
            {
                // sending failed
                ok = false;
            }
        }
    }
    
    Trace::print( MTP_CLIENTLIST, STP_CL_SEND,
                  "ServerClientList::sendAllExcept End " + QString::number(ok) );

    return ok;
}
    
// Get next free index, starting at 0.
int ServerClientList::getNextFreeIndex()
{
    Trace::print( MTP_CLIENTLIST, STP_CL_SEARCH,
                  "ServerClientList::getNextFreeIndex Start" );

    int index = -1;

    // the list holds all connections sorted by index
    // that means at the first "gap" or after the last
    // element we can add a new index.
    for ( int ii = 0; ii < m_list.count(); ii++ )
    {
#ifdef QT_DEBUG
        std::cout << "(II) ServerClientList::getNextFreeIndex "
                  << ii
                  << " Client: "     << m_list[ii]->getIndex()
                  << std::endl;
#endif

        if ( -1 == m_list[ii]->getIndex() )
        {
            // This client has no index, so it must be free.
            index = ii;
            break;
        }
    }
    
    if ( -1 == index )
    {
        // We have not found an empty place,
        // so we will really add one client.

        index = m_list.count();
        
#ifdef QT_DEBUG
        std::cout << "(II) ServerClientList::getNextFreeIndex "
                  << " Set client " << index
                  << std::endl;
#endif

        // add empty client
        ServerClient *client = new ServerClient();

        if ( client )
        {
            m_list.push_back( client );
        }
        else
        {
            std::cerr << "(EE) ServerClientList::getNextFreeIndex "
                      << " Client is NULL for index "
                      << index << "."
                      << std::endl;
            index = -1;
        }
    }
    
    // This should not happen, but check anyway.
    if ( index < 0 )
    {
        std::cerr << "(EE) ServerClientList::getNextFreeIndex "
                  << " Index " << index << " is negative!"
                  << std::endl;
    }

#ifdef QT_DEBUG
    std::cout << "(II) ServerClientList::getNextFreeIndex "
              << " Insert client " << index
              << std::endl;
#endif

    Trace::print( MTP_CLIENTLIST, STP_CL_SEARCH,
                  "ServerClientList::getNextFreeIndex End " + QString::number(index) );

    return index;
}

/// Check if clientId is valid.
bool ServerClientList::isValid( const int clientId, const bool needConnect ) const
{
    return ( ( 0 <= clientId && clientId < m_list.count() ) &&
             ( !needConnect || m_list.at(clientId)->isConnected() ) );
}

// Check if client exists.
bool ServerClientList::exists( const int clientId ) const
{
    Trace::print( MTP_CLIENTLIST, STP_CL_SEARCH,
                  "ServerClientList::exists End " + QString::number(clientId) );

    bool found = false;
    
    for ( int ii = 0; ii < m_list.count(); ii++ )
    {
        if ( clientId == m_list[ii]->getIndex() )
        {
            found = true;
            break;
        }
    }

    Trace::print( MTP_CLIENTLIST, STP_CL_SEARCH,
                  "ServerClientList::exists End " + QString::number(found) );

    return found;    
}
    
#ifdef QT_DEBUG
// print all client connections
void ServerClientList::print() const
{
    // the list holds all connections sorted by index
    // that means at the first "gap" or after the last
    // element we can add a new index.
    for ( int ii = 0; ii < m_list.count(); ii++ )
    {
        m_list[ii]->print( ii );
    }
}
#endif
