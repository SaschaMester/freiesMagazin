<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>AiEngine</name>
    <message>
        <location filename="main.cpp" line="100"/>
        <source>Unknown option: </source>
        <translation>Unbekannte Option: </translation>
    </message>
    <message>
        <location filename="main.cpp" line="138"/>
        <source>Usage: </source>
        <translation>Aufruf: </translation>
    </message>
    <message>
        <location filename="main.cpp" line="138"/>
        <source> [OPTIONS]</source>
        <translation> [OPTIONEN]</translation>
    </message>
    <message>
        <location filename="main.cpp" line="139"/>
        <source>Starts the example AI for the Right2Live-contest of freiesMagazin.</source>
        <translation>Started die Beispiel-KI fuer den Right2Live-Wettbewerb von freiesMagazin.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="141"/>
        <source>Possible options: </source>
        <translation>Moegliche Optionen: </translation>
    </message>
    <message>
        <location filename="main.cpp" line="142"/>
        <source>Mode for moving of AI. Possible values:</source>
        <translation>Modus fuer die KI-Bewegung. Moegliche Werte:</translation>
    </message>
    <message>
        <location filename="main.cpp" line="143"/>
        <source>   AI does not move at all.</source>
        <translation>KI bewegt sich gar nicht.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="144"/>
        <source>   AI will not move, but look around.</source>
        <translation>KI bewegt sich nicht, aber schaut umher.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="145"/>
        <source>   AI will move and look randomly (default).</source>
        <translation>KI bewegt sich und schaut zufaellig (Standard).</translation>
    </message>
    <message>
        <location filename="main.cpp" line="146"/>
        <source>Print informations during game.</source>
        <translation>Gibt waehrend des Spiels Informationen aus.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="147"/>
        <source>Show this help text.</source>
        <translation>Zeigt diese Hilfe an.</translation>
    </message>
</context>
</TS>
