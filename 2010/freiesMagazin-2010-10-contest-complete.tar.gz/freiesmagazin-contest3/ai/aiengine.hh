/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef AIENGINE_HH
#define AIENGINE_HH

// Own
/////////
#include "gamemap.hh"
#include "player.hh"
#include "playerlist.hh"
#include "client.hh"
#include "fieldlist.hh"
#include "clientparsercommand.hh"
#include "aimode.hh"

// Qt
///////
#include <QObject>

/// Engine for artifical engine.
/**
 * The engine holds all data and client for receiving and sending
 * data. It must parse all data and calculate the next move of the ai.
 */
class AiEngine : public QObject
{
Q_OBJECT

public:
    /// Constructor
    /**
     * Create a new engine with a empty player and an empty map.
     */
    AiEngine();

    /// Destructor
    virtual ~AiEngine() { }

    /// Connect to a server.
    /**
     * This method is the most important function to connect to a
     * server. The adress and port of the server will be given from
     * outside.
     * The client tries to connect to the server for 3 seconds and
     * give an error if it times out.
     * @param address server adress for connection
     * @param port port the server listens for new connections
     * @param msecs time to try to establish a connection in milliseconds
     *        (default is 3 seconds).
     * @return true if connection could be established
     */
    bool connectToServer( const QHostAddress address, const quint16 port,
                          const int msecs = 3000 );

    /// Wait until server kills connection.
    /**
     * The client will wait endlessly until the connection breaks.
     * This should be called after the engine has been constructed
     * and the client connected to a server.
     */
    void waitUntilDisconnected();

    /// Set a new behaviour mode.
    /**
     * We have different modes for starting AIs with different
     * behaviour. Possible values are
     * NONE, LOOK, RANDOM (default).
     */
    void setMode( const AiMode mode ) { m_mode = mode; }

    /// Show game information during game like players, moves etc.
    void showGameInfo( const bool show ) { m_showGameInfo = show; }
    
protected slots:

    /// Client has been connected to the server.
    /**
     * We should wait here until the server gives us our id.
     */
    void slot_connected();

    /// Client has been disconnected from the server.
    /**
     * Nothing to do here I think.
     */
    void slot_disconnected();

    /// Process a command.
    void slot_processCommand( const ClientParserCommand commandId );

protected:

    /// Get player id.
    virtual void processCommandId();

    /// Connect another client.
    virtual void processCommandConnectOther();

    /// Disconnect another client.
    virtual void processCommandDisconnectOther();

    /// Disconnect the client.
    virtual void processCommandDisconnect();

    /// Set data of own player.
    virtual void processCommandSet();

    /// Set data of other player.
    virtual void processCommandSeePlayer();

    /// See a new key.
    virtual void processCommandSeeKey();

    /// Get a new key
    virtual void processCommandGetKey();

    /// change the team of a player
    virtual void processCommandTeamChange();

    /// Load new map.
    virtual void processCommandLoadMap();

    /// Start calculation of next move.
    virtual void processCommandStartCalculation();

    /// Store toxic value in game map.
    /**
     * This is not implemented here.
     */
    virtual void processCommandStoreToxicValue() { }

    /// Extract life of some player.
    /**
     * This is not implemented here.
     */
    virtual void processCommandStoreLife() { }

    /// Calculate next move of player.
    /**
     * Derive from this class and overload this method to
     * create your own bot.
     * Depending on the AiMode the player will move
     * in some way over to field. A direction he moves
     * and a new viewing direction will be calculated.
     * @return true if everything is okay
     */
    virtual bool calcNextMove( Direction& move, Direction& view );

protected:

    /// Player.
    /**
     * This is the own player that moves around the game board.
     */
    Player m_player;

    /// List of other players.
    /**
     * For each client that connects to the server we will be informed
     * and must create a new player so that we can track it's movement.
     */
    PlayerList m_otherPlayers;

    /// The loaded map.
    /**
     * The map contains only walls, empty fields and doors.
     */
    GameMap m_map;

    /// This is a list of all visible keys.
    /**
     * We will remember which keys we have seen on the game map.
     * The collected keys are stored in the Player.
     */
    FieldList m_visibleKeys;

    /// Client connection for receiving and sending data.
    Client m_client;

    /// Behaviour mode how the AI should move.
    AiMode m_mode;

    /// Show game informations during game like players, moves etc.
    /**
     * As default it's disabled.
     */
    bool m_showGameInfo;
};

#endif // AIENGINE_HH
