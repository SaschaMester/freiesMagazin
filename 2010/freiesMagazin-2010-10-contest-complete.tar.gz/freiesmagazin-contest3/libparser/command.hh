/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef COMMAND_HH
#define COMMAND_HH

// Qt
////////
#include <QString>

/// Command from a server or client.
/**
 * The class contains the actual command as string and further
 * an optional id who the sender of the command was.
 */
class Command
{
    /// The parser is a friend because it may set a new command.
    friend class Parser;

public:
    /// Constructor.
    Command();
    
    /// Constructor
    /**
     * @param command given command
     * @param index optional index of the one who has sent the command
     */
    Command( const QString& command, const int index = -1 );

    /// Add a new command to a existing command part.
    /**
     * If the index of the given command does not match the
     * existing index the command string will not be added.
     * @param commandToAdd command to add
     * @return true if string could be added 
     */ 
    bool add( const Command& commandToAdd );

    /// Add a new command to a existing command part.
    /**
     * If the index of the given command does not match the
     * existing index the command string will not be added.
     * @param command given command
     * @param index index of the one who has sent the command
     * @return true if string could be added 
     */ 
    bool add( const QString& command, const int index );

    /// Return command.
    /**
     * @return stored command
     */
    const QString& getCommand() const { return m_command; }
    
    /// Return index.
    /**
     * @return index (if any is set)
     */
    int getIndex() const { return m_index; }
    
    /// Check if command is empty.
    /**
     * @return true if command string is empty.
     */
    bool isEmpty() const { return m_command.isEmpty(); }

    /// Clear command.
    /**
     * That means the string is cleared and the index is set back to -1.
     */
    void clear() { m_command.clear(); m_index = -1; }

protected:
    /// Set a new command.
    /**
     * This will set a new command. The class is protected
     * so that not anybody can change an already stored command.
     * @param command new command to store
     * @param index index to check if this is the same as the already
     *        stored
     * @return true if index is the same as the already stored one
     */
    bool setCommandAndCheckIndex( const QString& command, const int index );

    /// Set command and index.
    /**
     * @param command given command
     * @param index optional index of the one who has sent the command
     */
    void set( const QString& command, const int index )
    {
        m_command = command;
        m_index = index;
    }

private:
    /// A given command.
    /**
     * These commands were received from a client or server and will
     * later be stored in a queue.
     */
    QString m_command;

    /// Index who has sent the command.
    /**
     * If this index is negative the command must have been sent
     * from the server.
     */
    int m_index;
};

#endif // COMMAND_HH
