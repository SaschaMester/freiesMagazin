/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef PARSER_HH
#define PARSER_HH

// Own
///////////
#include "command.hh"
#include "commandqueue.hh"
#include "direction.hh"
#include "team.hh"

// Qt
////////
#include <QStringList>
#include <QString>
#include <QObject>

// Forward declarations
/////////////////////////
class QChar;
class QPoint;
class Key;

/// Base class for parsing received string over a network connection.
/**
 * This class receives the data and extract the commands in the string
 * separated by a special separator. If a command is not finished
 * (no pipe at the end), it will be stored inside a string buffer.
 * At the next receivement it will fill the buffer up.
 * All parsed commands will be stored inside a queue and can be get
 * from there.
 */
class Parser : public QObject
{
Q_OBJECT

public:
    /// Separate data and extract command as new string.
    /**
     * It's possible that the string contains several commands
     * separated by a special separator. On the other hand it is
     * possible that the string is not finished and no separator
     * is found. That means we must wait till the command is complete.
     * The commands will be added in m_commandQueue and can be
     * processed later, if the index is correct.
     * 
     * @param data String with reveived data from a network connection.
     * @param index Id of the sender of the parsed commands (-1 means the server).
     * @param separator Separator to separate the given data, default
     *        is the pipe symbol ('|')
     */
    void separate( const QString& data, const int index,
                   const QChar& separator = '|' );


    /// Return true if command queue is empty.
    /**
     * @return true if command queue is empty
     */
    bool isCommandQueueEmpty() const
    {
        return m_commandQueue.empty();
    }

signals:

    /// Signal that a command has been received.
    /**
     * The signal is send everything getNextCommand is called and
     * returns a non empty command.
     */
    void sig_receivedCommand( const QString& command );

protected:

    /// Get next element from command queue.
    /**
     * @return next Command in queue. If the queue is empty an
     *         empty command will be returned.
     */
    Command getNextCommand();

    /**************************
     * Static methods
     **************************
     */

    /// Split a string by a separator.
    /**
     * This functions uses the split-command of QString, but uses
     * a space as default separator. Further empty entries will not be
     * stored in the list.
     * @param data String to split.
     * @param separator Separator to split the given data, default
     *        is a space (' ')
     */
    static QStringList split ( const QString& data, const QChar& separator = ' ' );

    /// Try to extract an id as integer.
    /**
     * IDs must be a non-negative integer.
     * @param id Id that should be set
     * @param stringId String that contains the id.
     * @return true if id could be extracted
     */
    static bool getId( int& id, const QString& stringId );

    /// Try to extract an id as integer.
    /**
     * Position must be two non-negative integer separated by comma.
     * @param pos Position that should be set
     * @param stringPos String that contains the position.
     * @return true if position could be extracted
     */
    static bool getPos( QPoint& pos, const QString& stringPos );

    /// Try to extract a direction.
    /**
     * @param dir Direction that should be set
     * @param stringDir String that contains the direction.
     * @return true if direction could be extracted
     */
    static bool getDir( Direction& dir, const QString& stringDir );

    /// Try to extract a key.
    /**
     * The key must a single lower case letter.
     * @param key Key that should be set
     * @param stringKey String that contains the key id.
     * @return true if direction could be extracted
     */
    static bool getKey( Key& key, const QString& stringKey );

    /// Try to extract a team.
    /**
     * @param team Team that should be set
     * @param stringTeam String that contains the team.
     * @return true if team could be extracted
     */
    static bool getTeam( Team& team, const QString& stringTeam );

    /// Try to extract a double value.
    /**
     * @param value Value that should be set.
     * @param stringValue String that contains the value.
     * @return true if team could be extracted
     */
    static bool getDouble( double& value, const QString& stringValue );

private:

    /// Remove left characters from a string.
    /**
     * @param data The given string.
     * @param num Number of characters to remove from left side.
     * @return new string with ( data.len - num ) characters if possible
     */
    static QString removeFromLeft( const QString& data, const int num );

    /// Remove right characters from a string.
    /**
     * @param data The given string.
     * @param num Number of characters to remove from right side.
     * @return new string with ( data.len - num ) characters if possible
     */
    static QString removeFromRight( const QString& data, const int num );

private:

    /// Received command that is not finished yet.
    Command m_unfinishedCommand;
    
    /// A queue with commands.
    /**
     * These commands in the queue has been parsed but not been
     * processed yet. Normally that will happen if the sender is faster
     * than the receiver.
     * The commands in the queue must be processed as fast as possible
     * otherwise it could happen that the memory exceeds.
     */
    CommandQueue m_commandQueue;
};

#endif // PARSER_HH
