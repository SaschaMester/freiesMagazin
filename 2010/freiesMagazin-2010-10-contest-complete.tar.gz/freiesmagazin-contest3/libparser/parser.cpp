/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "parser.hh"
#include "key.hh"
#include "trace.hh"

// Qt
////////
#include <QtAlgorithms>
#include <QChar>
#include <QPoint>
#include <QRegExp>

// Sys
////////
#include <iostream>

// Separate data and extract command as new string.
void Parser::separate( const QString& data, const int index,
                       const QChar& separator )
{
    Trace::print( MTP_PARSER, STP_PARSER_SEPARATE,
                  "Parser::separate Start " + data + " " + QString::number(index) );
                  
#ifdef QT_DEBUG
    std::cout << "(II) Parser::separate "
              << " Separate \""   << data.toStdString() << "\""
              << " by '" << separator.toAscii() << "'"
              << " and index " << index
              << std::endl;
#endif

    // check if data is empty
    // if so, we have nothing to do
    if ( !data.isEmpty() )
    {
        // count numbers of separators in the string
        // this would be the number of finished commands
        // we need to handle.
        const int numSeparators = data.count( separator );

        if ( 0 >= numSeparators )
        {
            if ( !m_unfinishedCommand.isEmpty() )
            {
                // There is a command in the buffer that we
                // have not processed yet => this is bad.
                std::cerr << "(EE) Parser::separate "
                          << " Buffer \""
                          << m_unfinishedCommand.getCommand().toStdString() << "\""
                          << " has not been processed."
                          << std::endl;
            }

            // no separator means the command is not finished
            // so store it in the buffer
            m_unfinishedCommand.set( data, index );
        }
        else
        {
            // we have at least one pipe = one command
            // copy data because we need to change it
            QString cpData(data);
            
            // check if we have a separator at the end
            const bool separatorAtEnd = cpData.endsWith( separator );
    
            // temporary storage for a unfinished command
            // if we have some finished and one unfinished command
            // in the data.
            QString tempUnfinishedCommand;

            // command with string and index
            Command command;

            // if we have no separator at the end, the last command
            // is not finished yet and we must store it
            if ( !separatorAtEnd )
            {
                // search last separator
                const int pos = cpData.lastIndexOf( separator );
                
                // store unfinished command
                tempUnfinishedCommand = removeFromLeft( cpData, pos + 1);
                
                // delete unfinished part
                cpData = cpData.left( pos + 1 );
            }
            
            // now we MUST have a separator at the end
            if ( cpData.endsWith( separator ) )
            {
                // seach all separators until everything is processed
                int pos = -1;
                do
                {
                    pos = cpData.indexOf( separator );
                    
                    // pos <= 0 means only the separator in the string
                    // and therefore no command at all
                    if ( pos >= 1 )
                    {
                        if ( !m_unfinishedCommand.isEmpty() )
                        {
                            command = m_unfinishedCommand;

                            // add extracted data
                            command.add(cpData.left(pos), index);
                        }
                        else
                        {
                            command.set(cpData.left(pos), index);
                        }
                        
                        // clear unfinished command
                        m_unfinishedCommand.clear();
                        
#ifdef QT_DEBUG
                        std::cout << "(II) Parser::separate "
                                  << " Data"
                                  << " \"" << command.getCommand().toStdString() << "\""
                                  << " ready."
                                  << " Data"
                                  << " \"" << cpData.toStdString() << "\""
                                  << " left."
                                  << std::endl;
#endif
                        // add command to queue
                        m_commandQueue.enqueue( command );
                    }

                    // delete used part
                    cpData = removeFromLeft( cpData, pos + 1 );
                    
                } while ( pos >= 0 );
            }
            else
            {
                std::cerr << "(EE) Parser::separate "
                          << " Data"
                          << " \"" << cpData.toStdString() << "\""
                          << " does not end with separator"
                          << " '" << separator.toAscii() << "'."
                          << std::endl;
            }
            
            // store optional unfinished command
            m_unfinishedCommand.set( tempUnfinishedCommand, index );
        
        } // numNewlines > 0
    } // !data.isEmpty()

    Trace::print( MTP_PARSER, STP_PARSER_SEPARATE,
                  "Parser::separate End" );
}

// Get next element from command queue.
Command Parser::getNextCommand()
{
    Command command;

    if ( !m_commandQueue.empty() )
    {
        command = m_commandQueue.dequeue();
        
        if ( !command.isEmpty() )
        {
            emit sig_receivedCommand( command.getCommand() );
        }
    }
        
    return command;
}
    
// Remove left characters from a string.
QString Parser::removeFromLeft( const QString& data, const int num )
{
    return data.right( data.length() - num );
}

// Remove right characters from a string.
QString Parser::removeFromRight( const QString& data, const int num )
{
    return data.left( data.length() - num );
}

// Split a string by a separator.
QStringList Parser::split ( const QString& data, const QChar& separator )
{
    return data.split( separator, QString::SkipEmptyParts );
}

// Try to extract an id as integer.
bool Parser::getId( int& id, const QString& stringId )
{
    bool ok = false;

    Trace::print( MTP_PARSER, STP_PARSER_STATIC_GET,
                  "Parser::getId Start " + stringId );
    
    if ( QRegExp( "^[0-9]+$" ).exactMatch( stringId ) )
    {
        id = stringId.toInt( &ok );
    }

    Trace::print( MTP_PARSER, STP_PARSER_STATIC_GET,
                  "Parser::getId End " + QString::number((int)ok) + " Id: " + QString::number(id) );
    
    return ok;
}

// Try to extract an id as integer.
bool Parser::getPos( QPoint& pos, const QString& stringPos )
{
    bool ok = false;

    Trace::print( MTP_PARSER, STP_PARSER_STATIC_GET,
                  "Parser::getPos Start " + stringPos );
    
    if ( QRegExp( "^[0-9]+,[0-9]+$" ).exactMatch( stringPos ) )
    {
        const int posComma = stringPos.indexOf(',');

        if ( posComma >= 0 )
        {
            const int x = stringPos.left(posComma).toInt( &ok );
            if ( ok )
            {
                const int y = stringPos.right(stringPos.length()-posComma-1).toInt( &ok );
                pos.setX(x);
                pos.setY(y);
            }
        }
    }

    Trace::print( MTP_PARSER, STP_PARSER_STATIC_GET,
                  "Parser::getPos End " + QString::number((int)ok) + " Pos: " + QString::number(pos.x()) + " " + QString::number(pos.y()) );
    
    return ok;
}

// Try to extract a direction.
bool Parser::getDir( Direction& dir, const QString& stringDir )
{
    bool ok = true;

    Trace::print( MTP_PARSER, STP_PARSER_STATIC_GET,
                  "Parser::getDir Start " + stringDir );

    if ( 0 == stringDir.compare( "NONE" ) )
    {
        dir = DIRECTION_NONE;
    }
    else if ( 0 == stringDir.compare( "NORTH" ) )
    {
        dir = DIRECTION_NORTH;
    }
    else if ( 0 == stringDir.compare( "NORTH_WEST" )  )
    {
        dir = DIRECTION_NORTH_WEST;
    }
    else if ( 0 == stringDir.compare( "WEST" )  )
    {
        dir = DIRECTION_WEST;
    }
    else if ( 0 == stringDir.compare( "SOUTH_WEST" )  )
    {
        dir = DIRECTION_SOUTH_WEST;
    }
    else if ( 0 == stringDir.compare( "SOUTH" )  )
    {
        dir = DIRECTION_SOUTH;
    }
    else if ( 0 == stringDir.compare( "SOUTH_EAST" )  )
    {
        dir = DIRECTION_SOUTH_EAST;
    }
    else if ( 0 == stringDir.compare( "EAST" )  )
    {
        dir = DIRECTION_EAST;
    }
    else if ( 0 == stringDir.compare( "NORTH_EAST" )  )
    {
        dir = DIRECTION_NORTH_EAST;
    }
    else
    {
        // direction not recognized
        ok = false;
    }

    Trace::print( MTP_PARSER, STP_PARSER_STATIC_GET,
                  "Parser::getDir End " + QString::number((int)ok) + " Dir: " + QString::number((int)dir) );

    return ok;
}

/// Try to extract a key.
bool Parser::getKey( Key& key, const QString& stringKey )
{
    bool ok = false;

    Trace::print( MTP_PARSER, STP_PARSER_STATIC_GET,
                  "Parser::getKey Start " + stringKey );
    
    if ( QRegExp( "^[a-z]$" ).exactMatch( stringKey ) )
    {
        // we know that we have exactly one char
        ok = key.set( stringKey.at(0) );
    }

    Trace::print( MTP_PARSER, STP_PARSER_STATIC_GET,
                  "Parser::getKey End " + QString::number((int)ok) + " Key: " + QString( key.get() ) );
    
    return ok;
}
    
// Try to extract a team.
bool Parser::getTeam( Team& team, const QString& stringTeam )
{
    bool ok = false;

    Trace::print( MTP_PARSER, STP_PARSER_STATIC_GET,
                  "Parser::getTeam Start " + stringTeam );

    if ( 0 == stringTeam.compare( "BLUE" ) )
    {
        team = TEAM_BLUE;
        ok = true;
    }
    else if ( 0 == stringTeam.compare( "RED" )  )
    {
        team = TEAM_RED;
        ok = true;
    }
    // else team not recognized

    Trace::print( MTP_PARSER, STP_PARSER_STATIC_GET,
                  "Parser::getTeam End " + QString::number((int)ok) + " Team: " + QString::number((int)team) );

    return ok;
}

// Try to extract a double value.
bool Parser::getDouble( double& value, const QString& stringValue )
{
    bool ok = false;

    Trace::print( MTP_PARSER, STP_PARSER_STATIC_GET,
                  "Parser::getDouble Start " + stringValue );

    value = stringValue.toDouble( &ok );

    Trace::print( MTP_PARSER, STP_PARSER_STATIC_GET,
                  "Parser::getDouble End " + QString::number((int)ok) + " Value: " + QString::number(value) );
    return ok;
}
