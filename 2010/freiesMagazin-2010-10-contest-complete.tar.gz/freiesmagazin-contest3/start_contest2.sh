#!/bin/bash

# Usage: ./start_contest2.sh contest1 100 5

# Create log directory
mkdir -p logs

MAP="$1"
NUMGAMES=$2
NUMITER=$3

for (( II=1; $II <= $NUMITER; II++ ))
do
    ./start_contest.sh $MAP $NUMGAMES $II > "logs/$MAP-$II.log" 2>&1
done

# Punkte listen
# for (( JJ=1; $JJ <= 5; JJ++ )) ; do for (( II=0; $II < 6; II++ )) ; do egrep "Player $II" contest1-$JJ.log | egrep -v "invalid" | sed 's/,/./g' | nawk '{ sum+=$7 } END {print sum}' ; done ; done

# Suche hohe Punktzahlen
# egrep "Score" *.log | nawk '{ print $7" "$0 }' | sort -n

# Fehler suchen
# egrep -v "^\(II\)|^Start|^-----" *.log
