/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "player.hh"
#include "trace.hh"
#include "key.hh"

// Sys
////////
#include <iostream>

/// Constructor
Player::Player()
: m_id(-1), m_position(-1,-1), m_view(DIRECTION_NORTH),
  m_team(TEAM_BLUE), m_invalid(false), m_numStandStills(0),
  m_lifePower(100.0), m_forcedTeamChange(false), m_score(0)
{
    Trace::print( MTP_PLAYER, STP_PLAYER_STRUCTOR,
                  "Player::Player Start " );
                  
    for ( int ii = 0; ii < TEAM_MAX_NUM; ii++ )
    {
        m_roundsInTeam[ii] = 0;
        m_teamCatches[ii] = 0;
    }

    Trace::print( MTP_PLAYER, STP_PLAYER_STRUCTOR,
                  "Player::Player End " );
}

// Reset everything of a player except the index.
void Player::reset()
{
    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::reset Start Index " + QString::number(m_id) );

    m_position.setX(-1);
    m_position.setY(-1);
    m_view = DIRECTION_NORTH;
    m_team = TEAM_BLUE;
    m_knownKeys.clear();
    m_lifePower = 100.0;
    // Note: We do not want to reset the invalid-flag!
    m_numStandStills = 0;
    m_forcedTeamChange = false;
    m_score = 0.0;

    for ( int ii = 0; ii < TEAM_MAX_NUM; ii++ )
    {
        m_roundsInTeam[ii] = 0;
        m_teamCatches[ii] = 0;
    }
    
    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::reset End " );
}

// Set new index.
bool Player::setIndex( const int index )
{
    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::setIndex Start Index " + QString::number(index) );

    bool ok = ( -1 == m_id );
    
    if ( index > -1 )
    {
#ifdef QT_DEBUG
        std::cout << "(II) Player::setIndex "
                  << index
                  << std::endl;
#endif
    
        m_id = index;
    }
    else
    {
        std::cerr << "(EE) Player::setIndex "
                  << index
                  << " is negative."
                  << std::endl;
        ok = false;
    }

    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::setIndex End " + QString::number((int)ok) );    

    return ok;
}
    
// Set new player position.
bool Player::setPosition( const QPoint& pos )
{
    bool ok = false;

    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::setPosition Start Pos " + QString::number(pos.x()) + " " + QString::number(pos.y()) );

    // store old position
    const QPoint oldPos = getPosition();

    if ( pos.x() >= 0 && pos.y() >= 0 )
    {
        m_position = pos;
        ok = true;

        if ( oldPos == pos )
        {
            // This is the same position as before so the player
            // has not moved.
            m_numStandStills++;
        }
        else
        {
            // The player has moved, so we must reset the counter.
            m_numStandStills = 0;
        }

        // count rounds of player in this team
        m_roundsInTeam[m_team]++;
    }
    else
    {
        std::cerr << "(EE) Player::setPosition "
                  << "( " << pos.x() << ", " << pos.y() << " )"
                  << " is not valid."
                  << std::endl;
    }

    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::setPosition End " + QString::number((int)ok) );    
    
    return ok;
}

// Set new view direction.
bool Player::setView( const Direction view )
{
    bool ok = false;

    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::setView Start View " + QString::number((int)view) );

    // It's not possible that the player does not look in any direction.
    if ( DIRECTION_NONE != view )
    {
        m_view = view;
        ok = true;
    }
    else
    {
        std::cerr << "(EE) Player::setView "
                  << " Player must look somewhere."
                  << std::endl;
    }

    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::setView End " + QString::number((int)ok) );    
    
    return ok;
}

// Set new team membership.
bool Player::setTeam( const Team team, const bool forced )
{
    bool ok = false;

    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::setTeam Start Team " + QString::number((int)team) );

    if ( team < TEAM_MAX_NUM )
    {
        m_team = team;
        m_forcedTeamChange = forced;
        ok = true;
    }
    else
    {
        std::cerr << "(EE) Player::setTeam "
                  << " Team "
                  << toString(team).toStdString()
                  << " is invalid."
                  << std::endl;
    }

    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::setTeam End " + QString::number((int)ok) );    
    
    return ok;
}

// Increase the number of catches.
bool Player::increaseCatched( const Team team )
{
    bool ok = false;

    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::increaseCatched Start Team " + QString::number((int)team) );

    if ( team < TEAM_MAX_NUM )
    {
        m_teamCatches[team]++;
        ok = true;
    }
    else
    {
        std::cerr << "(EE) Player::increaseCatched "
                  << " Team "
                  << toString(team).toStdString()
                  << " is invalid."
                  << std::endl;
    }

    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::increaseCatched End " + QString::number((int)ok) );

    return ok;
}
    
// Set life power.
void Player::setLife( const double value )
{
    m_lifePower = value;

    if ( m_lifePower <= 0.0 )
    {
        m_lifePower = 0.0;
    }
}

// Subtract life power.
void Player::decreaseLife( const double value )
{
    m_lifePower -= value;

    if ( m_lifePower <= 0.0 )
    {
        m_lifePower = 0.0;
    }
}
    
// Add new key to the known keys.
bool Player::addKey( const Key& key )
{
    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::addKey Start Key " + QString(key.get()) );

    // Check, if key is already stored.
    bool known = hasKey( key );

    if ( !known )
    {
        // key is not known, so add it
        m_knownKeys.append( key );
        known = true;
    }
    
    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::addKey End " + QString::number((int)known) );

    return known;
}

// Check if player has key.
bool Player::hasKey( const Key& key ) const
{
    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::hasKey Start Key " + QString(key.get()) );

    const bool has = m_knownKeys.contains( key );

    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::hasKey End " + QString::number(has) );

    return has;
}

// Get number of rounds the player was in team.
int Player::getNumRoundsInTeam( const Team team ) const
{
    int number = 0;

    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::getNumRoundsInTeam Start Team " + QString::number(team) );

    if ( team < TEAM_MAX_NUM )
    {
        number = m_roundsInTeam[team];
    }
    else
    {
        std::cerr << "(EE) Player::getNumRoundsInTeam "
                  << " Team "
                  << toString(team).toStdString()
                  << " is invalid."
                  << std::endl;
    }

    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::getNumRoundsInTeam End " + QString::number(number) );

    return number;
}

// Get number of player that has been catched of this team by the player.
int Player::getNumCatchesOfTeam( const Team team ) const
{
    int number = 0;

    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::getNumCatchesOfTeam Start Team " + QString::number(team) );

    if ( team < TEAM_MAX_NUM )
    {
        number = m_teamCatches[team];
    }
    else
    {
        std::cerr << "(EE) Player::getNumCatchesOfTeam "
                  << " Team "
                  << toString(team).toStdString()
                  << " is invalid."
                  << std::endl;
    }

    Trace::print( MTP_PLAYER, STP_PLAYER_SET,
                  "Player::getNumCatchesOfTeam End " + QString::number(number) );

    return number;
}

    
// Convert a direction to a string.
QString Player::toString( const Direction dir )
{
    QString retValue;

    switch ( dir )
    {
    case DIRECTION_NONE:
        retValue = "NONE";
        break;
    case DIRECTION_NORTH:
        retValue = "NORTH";
        break;
    case DIRECTION_NORTH_WEST:
        retValue = "NORTH_WEST";
        break;
    case DIRECTION_WEST:
        retValue = "WEST";
        break;
    case DIRECTION_SOUTH_WEST:
        retValue = "SOUTH_WEST";
        break;
    case DIRECTION_SOUTH:
        retValue = "SOUTH";
        break;
    case DIRECTION_SOUTH_EAST:
        retValue = "SOUTH_EAST";
        break;
    case DIRECTION_EAST:
        retValue = "EAST";
        break;
    case DIRECTION_NORTH_EAST:
        retValue = "NORTH_EAST";
        break;
    default:
        retValue = "ERROR";
        break;
    }

    return retValue;
}
// Convert a direction to a string.
QString Player::toShortString( const Direction dir )
{
    QString retValue;

    switch ( dir )
    {
    case DIRECTION_NONE:
        retValue = "NONE";
        break;
    case DIRECTION_NORTH:
        retValue = "N";
        break;
    case DIRECTION_NORTH_WEST:
        retValue = "NW";
        break;
    case DIRECTION_WEST:
        retValue = "W";
        break;
    case DIRECTION_SOUTH_WEST:
        retValue = "SW";
        break;
    case DIRECTION_SOUTH:
        retValue = "S";
        break;
    case DIRECTION_SOUTH_EAST:
        retValue = "SE";
        break;
    case DIRECTION_EAST:
        retValue = "E";
        break;
    case DIRECTION_NORTH_EAST:
        retValue = "NE";
        break;
    default:
        retValue = "ERROR";
        break;
    }

    return retValue;
}

// Convert a team to a string.
QString Player::toString( const Team team )
{
    QString retValue;

    switch ( team )
    {
    case TEAM_BLUE:
        retValue = "BLUE";
        break;
    case TEAM_RED:
        retValue = "RED";
        break;
    default:
        retValue = "ERROR";
        break;
    }

    return retValue;
}

// Move position from start to target by movement direction.
bool Player::movePosition( QPoint& targetPos, const QPoint& startPos,
                           const Direction movement )
{
    bool ok = true;
    
    // create new position
    switch ( movement )
    {
    case DIRECTION_NONE:
        targetPos = startPos;
        break;
    case DIRECTION_NORTH:
        targetPos = QPoint( startPos.x(),     startPos.y() - 1 );
        break;
    case DIRECTION_NORTH_WEST:
        targetPos = QPoint( startPos.x() - 1, startPos.y() - 1 );
        break;
    case DIRECTION_WEST:
        targetPos = QPoint( startPos.x() - 1, startPos.y() );
        break;
    case DIRECTION_SOUTH_WEST:
        targetPos = QPoint( startPos.x() - 1, startPos.y() + 1 );
        break;
    case DIRECTION_SOUTH:
        targetPos = QPoint( startPos.x(),     startPos.y() + 1 );
        break;
    case DIRECTION_SOUTH_EAST:
        targetPos = QPoint( startPos.x() + 1, startPos.y() + 1 );
        break;
    case DIRECTION_EAST:
        targetPos = QPoint( startPos.x() + 1, startPos.y() );
        break;
    case DIRECTION_NORTH_EAST:
        targetPos = QPoint( startPos.x() + 1, startPos.y() - 1 );
        break;
    default:
        std::cerr << "(EE) Player::movePosition "
                  << " Default case reached for movement "
                  << Player::toString(movement).toStdString()
                  << std::endl;
        ok = false;
        break;
    }

    return ok;
}

