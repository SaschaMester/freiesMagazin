/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef TRACEENUMS_HH
#define TRACEENUMS_HH

/// Enumerator for all main trace points.
/**
 * Normally we have a trace point for each class that exists.
 */
enum MainTracePoint
{
    MTP_COMMAND = 0,     // trace points in class Command
    MTP_PARSER,          // trace points in class Parser
    MTP_CLIENT,          // trace points in class Client
    MTP_CLIENTCONNECTION,// trace points in class ClientConnection
    MTP_CLIENTLIST,      // trace points in class ClientList (for server)
    MTP_CLIENTPARSER,    // trace points in class ClientParser
    MTP_SERVERPARSER,    // trace points in class ServerParser
    MTP_SERVERPARSERLIST,// trace points in class ServerParserList
    MTP_SERVER,          // trace points in class Server
    MTP_GAMEMAP,         // trace points in class GameMap
    MTP_FIELD,           // trace points in class Field
    MTP_PLAYER,          // trace points in class Player
    MTP_KEY,             // trace points in class Key
    MTP_AI_ENGINE,       // trace points in class AiEngine
    MTP_GAME_ENGINE,     // trace points in class GameEngine
    MTP_GAME_WINDOW,     // trace points in class GameWindow
    MTP_GAME_AREA,       // trace points in class GameArea

    MTP_MAXNUM_TRACEPOINTS  // maximum number of main trace points
                            // do not add new tracepoints after this point
};

/// Sub trace points for class Command
enum SubTracePointsCommand
{
    STP_COMMAND_STRUCTOR  = 0x0001,      // constructor/destructor/clear
    STP_COMMAND_SET_ADD   = 0x0002      // set and add commands
};

/// Sub trace points for class Parser
enum SubTracePointsParser
{
    STP_PARSER_SEPARATE   = 0x0001,       // Separate commands.
    STP_PARSER_STATIC_GET = 0x0002       // Static get methods
};

/// Sub trace points for class Client
enum SubTracePointsClient
{
    STP_CLIENT_STRUCTOR   = 0x0001,     // constructor/destructor
    STP_CLIENT_CONNECTION = 0x0002,     // all connections
    STP_CLIENT_RECEIVE    = 0x0004,     // receive data
    STP_CLIENT_SEND       = 0x0008,     // send data
    STP_CLIENT_PROCESS    = 0x0010,     // process commands
    STP_CLIENT_SET        = 0x0020      // setting data
};

/// Sub trace points for class ClientConnection
enum SubTracePointsClientConnection
{
    STP_CC_STRUCTOR   = 0x0001,     // constructor/destructor
    STP_CC_RECEIVE    = 0x0002,     // receive data
    STP_CC_SEND       = 0x0004,     // send data
    STP_CC_ERROR      = 0x0008      // error occurred
};

/// Sub trace points for class ClientList
enum SubTracePointsClientList
{
    STP_CL_STRUCTOR  = 0x0001,      // constructor/destructor/clear
    STP_CL_ADDREMOVE = 0x0002,      // adding and removing of elements
    STP_CL_SEARCH    = 0x0004,      // search client or free index
    STP_CL_SEND      = 0x0008,      // send data
    STP_CL_GETSET    = 0x0010       // get and set data
};

/// Sub trace points for class ClientParser
enum SubTracePointsClientParser
{
    STP_CP_STRUCTOR  = 0x0001,      // constructor/destructor/clear
    STP_CP_SET       = 0x0002,      // setting data
    STP_CP_PROCESS   = 0x0004       // processing data
};

/// Sub trace points for class ServerParser
enum SubTracePointsServerParser
{
    STP_SP_STRUCTOR  = 0x0001,      // constructor/destructor/clear
    STP_SP_SET       = 0x0002,      // setting data
    STP_SP_PROCESS   = 0x0004       // processing data
};

/// Sub trace points for class ServerParserList
enum SubTracePointsServerParserList
{
    STP_SPL_STRUCTOR   = 0x0001,     // constructor/destructor
    STP_SPL_ADDREMOVE  = 0x0002,     // add/remove elements
    STP_SPL_SET        = 0x0004      // setting data
};

/// Sub trace points for class ClientConnectionList
enum SubTracePointsServer
{
    STP_SERV_STRUCTOR   = 0x0001,     // constructor/destructor
    STP_SERV_CONNECTION = 0x0002,     // all connections
    STP_SERV_RECEIVE    = 0x0004,     // receive data
    STP_SERV_SEND       = 0x0008,     // send data
    STP_SERV_PROCESS    = 0x0010,     // process commands
    STP_SERV_SET        = 0x0020,     // setting data
    STP_SERV_GUI        = 0x0040      // GUI server and connection
};

/// Sub trace points for class Field
enum SubTracePointsField
{
    STP_FIELD_STRUCTOR   = 0x0001,     // constructor/destructor
    STP_FIELD_SET        = 0x0002,     // set data
    STP_FIELD_CHECK      = 0x0004      // some check functions
};

/// Sub trace points for class GameMap
enum SubTracePointsGameMap
{
    STP_MAP_STRUCTOR   = 0x0001,     // constructor/destructor
    STP_MAP_LOADSAVE   = 0x0002,     // loading and saving
    STP_MAP_ACCESS     = 0x0004,     // access to elements
    STP_MAP_SIZE       = 0x0008,     // changing size of map/clearing
    STP_MAP_VIEW       = 0x0004      // viewing
};

/// Sub trace points for class Player
enum SubTracePointsPlayer
{
    STP_PLAYER_STRUCTOR   = 0x0001,     // constructor/destructor
    STP_PLAYER_SET        = 0x0002     // set data
};

/// Sub trace points for class Key
enum SubTracePointsKey
{
    STP_KEY_SET   = 0x0001         // set keys
};

/// Sub trace points for class AiEngine
enum SubTracePointsAiEngine
{
    STP_AI_STRUCTOR   = 0x0001,     // constructor/destructor
    STP_AI_CONNECTION = 0x0002,     // all connections
    STP_AI_RECEIVE    = 0x0004,     // receive data
    STP_AI_SEND       = 0x0008,     // send data
    STP_AI_PROCESS    = 0x0010,     // all connections
    STP_AI_SET        = 0x0020,     // set data
    STP_AI_CALC       = 0x0040      // calculation
};

/// Sub trace points for class GameEngine
enum SubTracePointsGameEngine
{
    STP_GE_STRUCTOR   = 0x0001,     // constructor/destructor
    STP_GE_GAMEMAP    = 0x0002,     // accessing game map
    STP_GE_PLAYERS    = 0x0004,     // accessing players
    STP_GE_GAME       = 0x0008      // the game itself
};

/// Sub trace points for class GameWindow
enum SubTracePointsGameWindow
{
    STP_GW_STRUCTOR   = 0x0001,     // constructor/destructor
    STP_GW_CONNECT    = 0x0002,     // all connections
    STP_GW_PROCESS    = 0x0004      // process commands
};

/// Sub trace points for class GameArea
enum SubTracePointsGameArea
{
    STP_GA_STRUCTOR   = 0x0001      // constructor/destructor
};


#endif // TRACEENUMS_HH
