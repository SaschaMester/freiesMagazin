/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
///////
#include "gamemap.hh"
#include "trace.hh"

// Qt
////////
#include <QString>
#include <QFile>
#include <QTextStream>
#include <QtAlgorithms>

// Sys
////////
#include <iostream>
#include <cmath>

// Static
Field GameMap::m_dummyField;

// Default constructor
GameMap::GameMap()
: m_size(0,0)
{
    Trace::print( MTP_GAMEMAP, STP_MAP_STRUCTOR,
                  "GameMap::GameMap Start" );
                  
    Trace::print( MTP_GAMEMAP, STP_MAP_STRUCTOR,
                  "GameMap::GameMap End" );
}

// Clear map.
void GameMap::clear()
{
    Trace::print( MTP_GAMEMAP, STP_MAP_SIZE,
                  "GameMap::clear Start" );

    // clear map
    m_map.clear();
    
    // reset size
    m_size.setWidth(0);
    m_size.setHeight(0);

    Trace::print( MTP_GAMEMAP, STP_MAP_SIZE,
                  "GameMap::clear End" );
}
    
// Set size of map.
bool GameMap::setSize( const int width, const int height )
{
    Trace::print( MTP_GAMEMAP, STP_MAP_SIZE,
                  "GameMap::setSize Start " + QString::number(width) + " " + QString::number(height) );

    bool ok = false;
    
    // the size must be positive
    if ( width > 0 && height > 0 )
    {
        // set size
        m_size.setWidth(width);
        m_size.setHeight(height);
        ok = true;

#ifdef QT_DEBUG
        std::cout << "(II) GameMap::setSize "
                  << " Set size "
                  << width << "/" << height
                  << "."
                  << std::endl;
#endif
    }
    else
    {
        std::cerr << "(EE) GameMap::setSize "
                  << " Size "
                  << width << "/" << height
                  << " must be positive."
                  << std::endl;
    }

    Trace::print( MTP_GAMEMAP, STP_MAP_SIZE,
                  "GameMap::setSize End " + QString::number((int)ok) );

    return ok;
}

// Check if given file name is a valid map name.
bool GameMap::isValidMapname( const QString& filename ) const
{
    // The map name must have the form xxx.map
    return ( filename.length() > 4 && filename.right(4) == ".map" );
}

// Load map from disc.
bool GameMap::load( const QString& filename )
{
    Trace::print( MTP_GAMEMAP, STP_MAP_LOADSAVE,
                  "GameMap::load Start " + filename );

    bool ok = false;

    // first we clear the array
    clear();
    
    // check file name size
    if ( isValidMapname( filename ) )
    {
        // create toxic filename
        const QString toxicFile = filename.left( filename.lastIndexOf( '.' ) ) + ".toxic";

        // flag if the toxic map exixts
        // the map is optional and will be ignored if it's not there
        const bool toxicMapExists = QFile::exists(toxicFile);

        // open file
        QFile inFile( filename );

        QFile tinFile( toxicFile );

        if ( inFile.open(QFile::ReadOnly) &&
             ( !toxicMapExists || tinFile.open(QFile::ReadOnly) ) )
        {
#ifdef QT_DEBUG
            std::cout << "(II) GameMap::load "
                      << " Map: "
                      << filename.toStdString()
                      << " Toxic Map: "
                      << toxicFile.toStdString()
                      << " exists: "
                      << toxicMapExists
                      << std::endl;
#endif

            // open text stream
            QTextStream stream( &inFile );
            QTextStream tstream( &tinFile );
            
            // width and height of map
            int width = 0;
            int height = 0;
            int twidth = 0;
            int theight = 0;
            
            // check stream format
            if ( checkStreamFormat( width, height, stream, false ) &&
                 ( !toxicMapExists || checkStreamFormat( twidth, theight, tstream, true ) ) )
            {
                // check, if the sizes matches
                if ( ( !toxicMapExists ) ||
                     ( width == twidth && height == theight ) )
                {
                    // set size
                    if ( setSize( width, height ) )
                    {
                        // now we can extract each field (character)
                        QChar c = '\0';
                        QChar tc = ' ';
                        
                        int ii = 0;
                        int jj = 0;
                        
                        // now read each character from file
                        // until end of file
                        while ( !stream.atEnd() )
                        {
                            // read character
                            stream >> c;

                            if ( toxicMapExists )
                            {
                                if ( !tstream.atEnd() )
                                {
                                    // read letter from toxic file
                                    tstream >> tc;
                                }
                                else
                                {
                                    // stream ended too early
                                    std::cerr << "(EE) GameMap::load "
                                              << " Stream for toxic map "
                                              << toxicFile.toStdString()
                                              << " ended too early at "
                                              << "line " << jj
                                              << ", char " << ii
                                              << std::endl;
                                }
                            }
                            
                            if ( c != '\n' )
                            {
                                // this is no newline, so create new field
                                // and add it to the map
                                m_map.append( Field( QPoint(ii, jj), c, tc ) );
                                ii++;
                            }
                            else
                            {
                                // check if the toxic map has a newline too
                                if ( toxicMapExists && tc != '\n' )
                                {
                                    std::cerr << "(EE) GameMap::load "
                                              << " Missing newline in toxic map "
                                              << toxicFile.toStdString()
                                              << " at line " << jj
                                              << ", char " << ii
                                              << std::endl;
                                }

                                ii = 0;
                                jj++;
                            }
                        }
                    
                        // check size of list
                        if ( m_size.width()*m_size.height() == m_map.size() )
                        {
                            // extract all keys and doors
                            if ( extractTypeFromMap( m_keys, FT_KEY ) &&
                                 extractTypeFromMap( m_doors, FT_DOOR ) )
                            {
                                ok = true;
                            }
                        }
                        else
                        {
                            std::cerr << "(EE) GameMap::load "
                                      << " Map size "
                                      << m_map.count()
                                      << " does not match set size "
                                      << m_size.width()*m_size.height() << " = "
                                      << m_size.width() << "*" << m_size.height()
                                      << std::endl;
                        }
                    }
                    // else the size could not be set and we
                    // already have printed an error.
                }
                else
                {
                    // size is not correct
                    std::cerr << "(EE) GameMap::load "
                              << " Map size "
                              << width << "," << height
                              << " does not match toxic map size "
                              << twidth << "," << theight
                              << std::endl;
                }
            }
            // else the stream format is not correct and we
            // already have printed an error
            
            // close file again
            inFile.close();
            tinFile.close();
        }
        else
        {
            std::cerr << "(EE) GameMap::load "
                      << " File "
                      << filename.toStdString()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "(EE) GameMap::load "
                  << " Filename \""
                  << filename.toStdString()
                  << "\" is not valid."
                  << std::endl;
    }

    Trace::print( MTP_GAMEMAP, STP_MAP_LOADSAVE,
                  "GameMap::load End " + QString::number((int)ok) );

    return ok;
}

// Check if stream format is correct for loading.
bool GameMap::checkStreamFormat( int& width, int& height,
                                 QTextStream& stream, const bool toxic ) const
{
    Trace::print( MTP_GAMEMAP, STP_MAP_LOADSAVE,
                  "GameMap::checkStreamFormat Start" );

    // character from stream
    QChar c = '\0';

    // flag if a new line should be started
    // is set to true after each \n and at the start of the stream
    bool newline = true;

    // now read each character from stream until end
    int lineNumber = 1;
    int pos = 0;
    int maxWidth = -1;
    int maxHeight = 0;
    
    // suppose everything is okay
    bool ok = true;
    
    while ( !stream.atEnd() )
    {
        // read character
        stream >> c;

        if ( c == '\n' )
        {
            // end of line

            if ( -1 == maxWidth )
            {
                // we haven't set the width yet
                // so store it as reference for all other lines
                maxWidth = pos;
            }
            else
            {
                // check if we have read enough characters
                if ( pos != maxWidth )
                {
                    std::cerr << "(EE) GameMap::checkStreamFormat "
                              << " Linebreak found but character expected"
                              << " at line number "
                              << lineNumber
                              << " position "
                              << pos
                              << " (starts at [0,0])."
                              << std::endl;
                    ok = false;
                    break;
                }
            }

            // new line will start with the next character
            newline = true;
            lineNumber++;
        }
        else
        {
            // new character
            
            // we only understand letters, spaces and hash #
            // for the toxic map we understand digits and spaces
            if ( ( !toxic && Field::isValidChar( c ) ) ||
                 ( Field::isValidToxicChar( c ) ) )
            {
                // count new line if necessary
                if ( newline )
                {
                    pos = 0;
                    maxHeight++;
                    newline = false;
                }
                
                // count characters
                pos++;
                
                if ( maxWidth > -1 && pos > maxWidth )
                {
                    std::cerr << "(EE) GameMap::checkStreamFormat "
                              << " Linebreak expected but not found"
                              << " at line number "
                              << lineNumber
                              << " position "
                              << pos
                              << " (starts at [0,0])."
                              << std::endl;
                    ok = false;
                    break;
                }
            }
            else
            {
                std::cerr << "(EE) GameMap::checkStreamFormat "
                          << " Character '"
                          << c.toAscii()
                          << "' unknown at line number "
                          << lineNumber
                          << " position "
                          << pos
                          << " (starts at [0,0])."
                          << std::endl;
                ok = false;
                break;
            }
        }
    } // while

    // Note: A known problem is when the map only contains one
    // line without a newline.
    // So we must check this here.
    if ( maxWidth == -1 && maxHeight == 1 )
    {
        maxWidth = pos;
    }

    // check if width and height is positive
    if ( maxWidth > 0 && maxHeight > 0 )
    {
        width = maxWidth;
        height = maxHeight;
    }
    else
    {
        std::cerr << "(EE) GameMap::checkStreamFormat "
                  << " Width "
                  << maxWidth
                  << " and height "
                  << lineNumber
                  << " must be positive."
                  << std::endl;
    }

    // reset stream
    ok = stream.seek(0) && ok;

#ifdef QT_DEBUG
    std::cout << "(II) GameMap::checkStreamFormat "
              << ok
              << std::endl;
#endif

    Trace::print( MTP_GAMEMAP, STP_MAP_LOADSAVE,
                  "GameMap::checkStreamFormat End " + QString::number((int)ok) );

    return ok;
}

// Save map to disc.
bool GameMap::save( const QString& filename, const bool withoutKeys ) const
{
    Trace::print( MTP_GAMEMAP, STP_MAP_LOADSAVE,
                  "GameMap::save Start " + filename );

    bool ok = false;

    // check file name size
    if ( !filename.isEmpty() )
    {
        // open file
        QFile outFile( filename );
        if ( outFile.open( QFile::WriteOnly ) )
        {
            // open text stream
            QTextStream stream( &outFile );

            ok = true;

            for ( int jj = 0; jj < m_size.height(); jj++ )
            {
                for ( int ii = 0; ii < m_size.width(); ii++ )
                {
                    // calculate position in list for better access
                    const int aPos = ii + jj*m_size.width();

                    // to be sure, we check the size of the list
                    if ( aPos < m_map.size() )
                    {
                        stream << m_map[aPos].toAscii( withoutKeys );
                    }
                    else
                    {
                        std::cerr << "(EE) GameMap::save "
                                  << " Position " << aPos
                                  << " out of boundary: " << m_map.size()
                                  << std::endl;
                        
                        ok = false;
                        break;
                    }
                    
                    if ( !ok )
                    {
                        break;
                    }
                } // ii
                
                // newline
                stream << '\n';
            } // jj
                
            // close file again
            outFile.close();
        }
        else
        {
            std::cerr << "(EE) GameMap::save "
                      << " File "
                      << filename.toStdString()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "(EE) GameMap::save "
                  << " Filename is empty."
                  << std::endl;
    }

    Trace::print( MTP_GAMEMAP, STP_MAP_LOADSAVE,
                  "GameMap::save End " + QString::number((int)ok) );

    return ok;
}


// Access field element.
const Field& GameMap::operator[] ( const QPoint& pos ) const
{
    Trace::print( MTP_GAMEMAP, STP_MAP_ACCESS,
                  "GameMap::operator[] const Start " + QString::number(pos.x()) + " " + QString::number(pos.y()) );

    // check boundaries
    if ( 0 <= pos.x() && pos.x() < m_size.width() &&
         0 <= pos.y() && pos.y() < m_size.height() )
    {
        // calculate position in list for better access
        const int aPos = pos.x() + pos.y()*m_size.width();

        // to be sure, we check the size of the list
        if ( aPos < m_map.size() )
        {
            Trace::print( MTP_GAMEMAP, STP_MAP_ACCESS,
                          "GameMap::operator[] const End 1" );

            return m_map[aPos];
        }
    }

    std::cerr << "(EE) GameMap::operator[] "
              << " Position "
              << pos.x() << "/" << pos.y()
              << " out of range of "
              << m_size.width() << "/" << m_size.height()
              << " or "
              << pos.x() + pos.y()*m_size.height()
              << " is greater than list size "
              << m_map.size()
              << std::endl;

    Trace::print( MTP_GAMEMAP, STP_MAP_ACCESS,
                  "GameMap::operator[] const End 0" );

    return m_dummyField;
}

// Access field element (as reference).
Field& GameMap::operator[] ( const QPoint& pos )
{
    Trace::print( MTP_GAMEMAP, STP_MAP_ACCESS,
                  "GameMap::operator[] Start " + QString::number(pos.x()) + " " + QString::number(pos.y()) );

    // check boundaries
    if ( 0 <= pos.x() && pos.x() < m_size.width() &&
         0 <= pos.y() && pos.y() < m_size.height() )
    {
        // calculate position in list for better access
        const int aPos = pos.x() + pos.y()*m_size.width();

        // to be sure, we check the size of the list
        if ( aPos < m_map.size() )
        {
            Trace::print( MTP_GAMEMAP, STP_MAP_ACCESS,
                          "GameMap::operator[] End 1" );

            return m_map[aPos];
        }
    }

    std::cerr << "(EE) GameMap::operator[] "
              << " Position "
              << pos.x() << "/" << pos.y()
              << " out of range of "
              << m_size.width() << "/" << m_size.height()
              << " or "
              << pos.x() + pos.y()*m_size.height()
              << " is greater than list size "
              << m_map.size()
              << std::endl;

    Trace::print( MTP_GAMEMAP, STP_MAP_ACCESS,
                  "GameMap::operator[] End 0" );

    return m_dummyField;
}


// Extract all field types from the map.
bool GameMap::extractTypeFromMap( QList<Field>& list, const FieldType fieldType )
{
    Trace::print( MTP_GAMEMAP, STP_MAP_ACCESS,
                  "GameMap::extractTypeFromMap Start" );
    
    // delete old list
    list.clear();
    
    bool ok = true;
    
    for ( int jj = 0; jj < m_size.height(); jj++ )
    {
        for ( int ii = 0; ii < m_size.width(); ii++ )
        {
            // calculate position in list for better access
            const int aPos = ii + jj*m_size.width();

            // to be sure, we check the size of the list
            if ( aPos < m_map.size() )
            {
                if ( m_map[aPos].isType( fieldType ) )
                {
                    // add field to list
                    list.append( m_map[aPos] );
                }
            }
            else
            {
                std::cerr << "(EE) GameMap::extractTypeFromMap "
                          << " Position " << aPos
                          << " out of boundary: " << m_map.size()
                          << std::endl;
                
                ok = false;
                break;
            }
        }
    }

    if ( ok )
    {
        // sort list if necessary
        if ( list.size() > 1 )
        {
            qSort( list.begin(), list.end() );
        }
    }

    Trace::print( MTP_GAMEMAP, STP_MAP_ACCESS,
                  "GameMap::extractTypeFromMap End " + QString::number((int)ok) );
    
    return ok;
}

// Get number of empty fields in the map.
int GameMap::getNumEmptyFields() const
{
    Trace::print( MTP_GAMEMAP, STP_MAP_ACCESS,
                  "GameMap::getNumEmptyFields Start " );

    int num = 0;

    for ( int ii = 0; ii < m_map.count(); ii++ )
    {
        if ( m_map[ii].isType( FT_EMPTY ) )
            num++;
    }

    Trace::print( MTP_GAMEMAP, STP_MAP_ACCESS,
                  "GameMap::getNumEmptyFields End " + QString::number(num) );

    return num;
}

// Return true if position is valid (inside size.)
bool GameMap::isValidPos( const QPoint& pos ) const
{
    return ( 0 <= pos.x() && pos.x() < m_size.width() &&
             0 <= pos.y() && pos.y() < m_size.height() );
}

// Check if target position is visible from other position.
bool GameMap::isPositionVisible( const QPointF& targetPos, const QPointF& pos,
                                 const QList<QPoint>& addBlockedFields ) const
{
    Trace::print( MTP_GAMEMAP, STP_MAP_VIEW,
                  "GameMap::isPositionVisible Start " );

    // if there wouldn't be a wall between the two positions
    // we could suppose that we see the target position.
    bool visible = true;

    // Now we check for each field that is a wall or a door, if it
    // intersects the viewing line between both positions.
    for ( int ii = 0; ii < m_map.count(); ii++ )
    {
        if ( m_map[ii].isType( FT_BLOCK ) ||
             m_map[ii].isType( FT_DOOR ) )
        {
            if ( isBlockingView( targetPos, pos, m_map[ii].getPos() ) )
            {
                visible = false;
                break;
            }
        }
    }
    
    // At last we check the additional blocked fields.
    // But only if the target pos is still visible
    if ( visible )
    {
        for ( int kk = 0; kk < addBlockedFields.count(); kk++ )
        {
            if ( isBlockingView( targetPos, pos, addBlockedFields[kk] ) )
            {
                visible = false;
            }
        }
    }

    Trace::print( MTP_GAMEMAP, STP_MAP_VIEW,
                  "GameMap::isPositionVisible End " + QString::number(visible) );

    return visible;
}

// Check if something blocks the view between two positions.
bool GameMap::isBlockingView( const QPointF& targetPos,
                              const QPointF& standingPos,
                              const QPoint& blockingPos ) const
{
    bool block = false;

    Trace::print( MTP_GAMEMAP, STP_MAP_VIEW,
                  "GameMap::isBlockingView Start " );

    // Each block will be created from four lines.
    // So we will have four checks to decide if it blocks the view.

#ifdef QT_DEBUG
    std::cout << "(II) GameMap::isBlockingView "
              << " To: "   << targetPos.x()   << " " << targetPos.y()
              << " From: " << standingPos.x() << " " << standingPos.y()
              << " Via: "  << blockingPos.x() << " " << blockingPos.y()
              << std::endl;
#endif

    // first line, lower side (remember that the coordinates are upside down)
    if ( !block )
    {
        const QPointF A( blockingPos.x(),   blockingPos.y() );
        const QPointF B( blockingPos.x()+1, blockingPos.y() );

        block = intersect( targetPos, standingPos, A, B );

#ifdef QT_DEBUG
    std::cout << "(II) GameMap::isBlockingView "
              << " Block lower side: " << block
              << " A " << A.x() << " " << A.y()
              << " B " << B.x() << " " << B.y()
              << std::endl;
#endif
    }

    // second line, right side
    if ( !block )
    {
        const QPointF A( blockingPos.x()+1, blockingPos.y()   );
        const QPointF B( blockingPos.x()+1, blockingPos.y()+1 );

        block = intersect( targetPos, standingPos, A, B );

#ifdef QT_DEBUG
    std::cout << "(II) GameMap::isBlockingView "
              << " Block right side: " << block
              << " A " << A.x() << " " << A.y()
              << " B " << B.x() << " " << B.y()
              << std::endl;
#endif
    }

    // third line, upper side
    if ( !block )
    {
        const QPointF A( blockingPos.x()+1, blockingPos.y()+1 );
        const QPointF B( blockingPos.x()  , blockingPos.y()+1 );

        block = intersect( targetPos, standingPos, A, B );

#ifdef QT_DEBUG
    std::cout << "(II) GameMap::isBlockingView "
              << " Block upper side: " << block
              << " A " << A.x() << " " << A.y()
              << " B " << B.x() << " " << B.y()
              << std::endl;
#endif
    }

    // fourth line, left side
    if ( !block )
    {
        const QPointF A( blockingPos.x(), blockingPos.y()+1 );
        const QPointF B( blockingPos.x(), blockingPos.y() );

        block = intersect( targetPos, standingPos, A, B );

#ifdef QT_DEBUG
    std::cout << "(II) GameMap::isBlockingView "
              << " Block left side: " << block
              << " A " << A.x() << " " << A.y()
              << " B " << B.x() << " " << B.y()
              << std::endl;
#endif
    }

    Trace::print( MTP_GAMEMAP, STP_MAP_VIEW,
                  "GameMap::isBlockingView End " + QString::number(block) );

    return block;
}

// Check if something blocks the view between two positions.
bool GameMap::intersect( const QPointF& A, const QPointF& B,
                         const QPointF& C, const QPointF& D ) const
{
    bool sect = false;

    Trace::print( MTP_GAMEMAP, STP_MAP_VIEW,
                  "GameMap::intersect Start " );

    // So this algorithm is very easy:
    // 1. Create difference vectors AB, CD and AC
    // 2. Create matrices X = ( AC AB ), Y = ( AC CD ), Z = ( AB CD )
    // 3. The parameter values for the lines are
    //    x = det(Y) / det(Z), y = det(X) / det(Z)
    // If det(Z) = 0, then the lines are parallel.

#ifdef QT_DEBUG
    std::cout << "(II) GameMap::intersect "
              << " A: " << A.x() << " " << A.y()
              << " B: " << B.x() << " " << B.y()
              << " C: " << C.x() << " " << C.y()
              << " D: " << D.x() << " " << D.y()
              << std::endl;
#endif

    const QPointF AB = B-A;
    const QPointF CD = D-C;
    const QPointF AC = C-A;

    const double numerAB = AC.x()*CD.y() - AC.y()*CD.x();
    const double numerCD = AC.x()*AB.y() - AC.y()*AB.x();
    const double denom = AB.x()*CD.y() - AB.y()*CD.x();

#ifdef QT_DEBUG
    std::cout << "(II) GameMap::intersect "
              << " numerAB: " << numerAB
              << " numerCD: " << numerCD
              << " denom: "   << denom
              << std::endl;
#endif

    // we use 0.0001 as indicator, that the denominator is 0
    // this should be enough
    if ( std::fabs(denom) > 0.0001 )
    {
        const double paramAB = numerAB/denom;
        const double paramCD = numerCD/denom;

#ifdef QT_DEBUG
    std::cout << "(II) GameMap::intersect "
              << " paramAB: " << paramAB
              << " paramCD: " << paramCD
              << std::endl;
#endif

        // if the parameters are between 0 and 1, we have a
        // intersection
        if ( 0.0 <= paramAB && paramAB <= 1.0 &&
             0.0 <= paramCD && paramCD <= 1.0 )
        {
            sect = true;
        }
    }
    else
    {
        // lines are parallel, but they could have a point in common
        if ( A == C || A == D || B == C || B == D )
        {
            sect = true;
        }
    }

    Trace::print( MTP_GAMEMAP, STP_MAP_VIEW,
                  "GameMap::intersect End " + QString::number(sect) );

    return sect;
}


