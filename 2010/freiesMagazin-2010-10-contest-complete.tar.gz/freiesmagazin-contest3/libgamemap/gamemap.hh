/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef GAMEMAP_HH
#define GAMEMAP_HH

// Own
///////
#include "field.hh"
#include "fieldlist.hh"

// Qt
///////
#include <QSize>

// Forward declarations
//////////////////////////
class QPoint;
class QPointF;
class QString;
class QTextStream;

/// The game map holds all game fields.
/**
 * The game map loads a map from disk and represent it with
 * different tiles for empty and block fields, keys and doors.
 */
class GameMap
{
public:
    /// Default constructor
    GameMap();
    
    /// Load map from disc.
    /**
     * @param filename that contains the map as ascii characters
     * @return true if file could be loaded.
     */
    bool load( const QString& filename );
    
    /// Save map to disc.
    /**
     * For clients the keys are not allowed to be written on disc
     * so sometimes withoutKeys must be true.
     * @param filename filename to save map to
     * @param withoutKeys if true keys will be handled as empty fields
     * @return true if file could be saved.
     */
    bool save( const QString& filename, const bool withoutKeys = false ) const;

    /// Get size of game map.
    /**
     * @return size of map
     */
    const QSize& getSize() const { return m_size; }

    /// Access field element.
    /**
     * If the position is outside the map boundaries
     * an invalid field will be returned.
     * The first position is at (0,0).
     * @param pos position on map to get field from
     * @return field at position
     */
    const Field& operator[] ( const QPoint& pos ) const;

    /// Access field element (as reference).
    /**
     * See above.
     * @param pos position on map to get field from
     * @return field at position
     */
    Field& operator[] ( const QPoint& pos );

    /// Get list with all keys on the map.
    /**
     * The list is sorted first by character and then by position.
     * @return list of keys
     */
    const FieldList& getKeys() const { return m_keys; }

    /// Get list with all doors on the map.
    /**
     * The list is sorted first by character and then by position.
     * @return list of doors
     */
    const FieldList& getDoors() const { return m_doors; }

    /// Get number of empty fields in the map.
    /**
     * This methods is really slow and you should not use it
     * too often.
     * @return number of empty fields
     */
    int getNumEmptyFields() const;

    /// Return true if position is valid (inside size.)
    bool isValidPos( const QPoint& pos ) const;

    /// Check if target position is visible from other position.
    /**
     * We will check if there are doors or walls between otherPos
     * and targetPos if we in some direction. Additional positions
     * of fields could be given that are blocked too.
     * @param targetPos Position we want to see.
     * @param pos Position we are looking from.
     * @param addBlockedFields Other positions that are blocked.
     * @return true if targetPos is visible from otherPos
     */
    bool isPositionVisible( const QPointF& targetPos, const QPointF& pos,
                            const QList<QPoint>& addBlockedFields ) const;

    /// Check if something blocks the view between two positions.
    /**
     * The order of targetPos and standingPos does not matter!
     * @param targetPos Position we want to see.
     * @param standingPos Position we are looking from.
     * @param blockingPos Blocking position (define four line segments)
     * @return true if blockingPos blocks view
     */
    bool isBlockingView( const QPointF& targetPos,
                         const QPointF& standingPos,
                         const QPoint& blockingPos ) const;

    /// Clear map.
    /**
     * Delete all field elements in the list and reset the size 0.
     */
    void clear();
    
private:

    /// Check if given file name is a valid map name.
    /**
     * The filename must have the form xxx.map.
     * @param filename Filename to check.
     * @return return true if filename is valid
     */
    bool isValidMapname( const QString& filename ) const;

    /// Set width x height of map.
    /**
     * This method does not set the size for the list!
     * @param width width of map
     * @param height height of map
     * @return true if size could be set
     */
    bool setSize( const int width, const int height );
    
    /// Check if stream format is correct for loading.
    /**
     * Checks if each line contains the same number of characters
     * and that each character is known as valid file element.
     * The width and height of the map will be stored.
     * The stream will be resetted to the start after reading everything.
     * @param[out] width stored width (number of characters in each line)
     * @param[out] height stored heigth (number of lines)
     * @param[in] stream the stream that contains the map
     * @param toxic If true only digits and spaces are valid for toxic map
     * @return true if stream format is correct
     */
    bool checkStreamFormat( int& width, int& height, QTextStream& stream,
                            const bool toxic ) const;

    /// Extract all field types from the map.
    /**
     * @param list the values will be be sorted into this list
     * @param fieldType type of field to store
     * @return true if everything is okay
     */
    bool extractTypeFromMap( FieldList& list, const FieldType fieldType );

    /// Check if something blocks the view between two positions.
    bool intersect( const QPointF& A, const QPointF& B,
                    const QPointF& C, const QPointF& D ) const;

private:

    /// List with all fields of the map.
    /**
     * The list contains the width x height fields.
     */
    FieldList m_map;

    /// Size of game map.
    /**
     * If the size is 0, the game map is not set.
     */
    QSize m_size;
    
    /// List of all keys on the map.
    /**
     * The list is sorted first by character and then by position.
     */
    FieldList m_keys;

    /// List of all doors on the map.
    /**
     * The list is sorted first by character and then by position.
     */
    FieldList m_doors;
    
    ///
    /**
     * Dummy field for returning if the access is out of
     * boundaries.
     * @see operator[]
     */
    static Field m_dummyField;
    
};

#endif // GAMEMAP_HH
