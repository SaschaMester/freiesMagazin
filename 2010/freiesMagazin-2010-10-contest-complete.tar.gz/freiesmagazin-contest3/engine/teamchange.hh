/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef TEAMCHANGE_HH
#define TEAMCHANGE_HH

// Own
////////
#include "team.hh"

/// Team change.
/**
 * This simple struct just stores a player id and a team name. It will
 * be used to store team changes to a team.
 * We do not check any data that is inserted into the class!
 */
struct TeamChange
{
    /// Constructor;
    TeamChange( const int id, const Team t, const bool f )
        : playerId(id), team(t), forced(f)
    { }

    /// Stored player id.
    /**
     * This id should not be negative, but we will not check it
     * if someone sets it.
     */
    int playerId;

    /// Stored team.
    /**
     * This is the team a player will switch to. Usually it should
     * not be the same as the current team of the player. But again
     * there is no check.
     */
    Team team;

    /// Flag if the team change was forced and not induced by infection.
    bool forced;

};

#endif // TEAMCHANGE_HH
