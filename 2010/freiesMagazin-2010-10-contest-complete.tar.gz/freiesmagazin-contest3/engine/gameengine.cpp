/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "gameengine.hh"
#include "trace.hh"
#include "key.hh"
#include "field.hh"
#include "player.hh"
#include "playeraction.hh"
#include "teamchange.hh"

// Qt
///////
#include <QDir>
#include <QPoint>
#include <QSize>
#include <QStringList>
#include <QVector>

// Sys
//////////
#include <iostream>
#include <cstdlib>
#include <ctime>

// Maximum number of rounds without team change.
// After this we will force a team change to get the game going.
#define NUM_ROUNDS_WO_TEAMCHANGE (25)

// Factor for points and when a new teamchange should occur.
#define NUM_ROUNDS_WO_TEAMCHANGE_FACTOR (10.0)

// Time in seconds for waiting after sending the game map to each player
#define NUM_SECS_WAIT_AFTER_MAP (5)

// Time in seconds for waiting for a player to finish it's move.
#define NUM_SECS_WAIT_PLAYER_MOVE (5)

// Constructor;
GameEngine::GameEngine()
: QObject(), m_gameStarted(false), m_roundStarted(false), m_numRounds(0),
  m_numRoundsWithoutTeamChange(0), m_waitForKey(false), m_showGameInfo(false)
{
    Trace::print( MTP_GAME_ENGINE, STP_GE_STRUCTOR,
                  "GameEngine::GameEngine Start " );

    // initialize random seed
    srand ( time(NULL) );

    // set temp filename
    m_mapNameWithoutKeys = QDir::tempPath();

    // add separator
    if ( !m_mapNameWithoutKeys.endsWith( QDir::separator() ) )
    {
        m_mapNameWithoutKeys += QDir::separator();
    }

    // add file name
    m_mapNameWithoutKeys += "board.map";

    // connect server signals
    if ( !connect( &m_server, SIGNAL( sig_clientConnected(const int) ),
                   this, SLOT( slot_addPlayer(const int) ) ) )
    {
        std::cerr << "(EE) GameEngine::GameEngine "
                  << " Connect failed for "
                  << "Server::sig_clientConnected -> GameEngine::slot_addPlayer"
                  << std::endl;
    }

    if ( !connect( &m_server, SIGNAL( sig_clientDisconnected(const int) ),
                   this, SLOT( slot_removePlayer(const int) ) ) )
    {
        std::cerr << "(EE) GameEngine::GameEngine "
                  << " Connect failed for "
                  << "Server::sig_clientConnected -> GameEngine::slot_removePlayer"
                  << std::endl;
    }

    if ( !connect( &m_server, SIGNAL( sig_clientMovement(const int,const Direction,const Direction) ),
                   this, SLOT( slot_movePlayer(const int,const Direction,const Direction) ) ) )
    {
        std::cerr << "(EE) GameEngine::GameEngine "
                  << " Connect failed for "
                  << "Server::sig_clientMovement -> GameEngine::slot_movePlayer"
                  << std::endl;
    }

    if ( !connect( &m_server, SIGNAL( sig_guiConnected() ),
                   this, SLOT( slot_guiConnected() ) ) )
    {
        std::cerr << "(EE) GameEngine::GameEngine "
                  << " Connect failed for "
                  << "Server::sig_guiConnected -> GameEngine::slot_guiConnected"
                  << std::endl;
    }



    Trace::print( MTP_GAME_ENGINE, STP_GE_STRUCTOR,
                  "GameEngine::GameEngine End " );
}

// Destructor.
GameEngine::~GameEngine()
{
    Trace::print( MTP_GAME_ENGINE, STP_GE_STRUCTOR,
                  "GameEngine::~GameEngine Start " );

    // if the save game is still open, close it
    if ( m_saveGameFile.isOpen() )
    {
        m_saveGameFile.close();
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_STRUCTOR,
                  "GameEngine::~GameEngine End " );
}

// Load a map and save it without keys in some file.
bool GameEngine::loadAndSaveMap( const QString& filename )
{
    Trace::print( MTP_GAME_ENGINE, STP_GE_GAMEMAP,
                  "GameEngine::loadAndSaveMap Start " + filename );

    bool ok = false;

    if ( !m_gameStarted )
    {
        if ( m_showGameInfo )
        {
            std::cout << "(II) GameEngine::loadAndSaveMap "
                      << " Map: "
                      << filename.toStdString()
                      << std::endl;
        }
        
        // create string with complete path of filename
        QString completeFilename = QFileInfo(filename).canonicalFilePath();

        // load map
        if ( m_map.load( completeFilename ) )
        {
            m_mapName = completeFilename;

            // Send the map.
            m_server.sendGui( "MAP " + m_mapName );

            if ( m_saveGameFile.isOpen() )
            {
                QTextStream out(&m_saveGameFile);
                out << "MAP " << m_mapName << endl;
            }
            
            // save map in temp file without keys
            // the map will be send to the clients later
            if ( m_map.save( m_mapNameWithoutKeys, true ) )
            {
                ok = true;
            }
        }
    }
    else
    {
        std::cerr << "(EE) GameEngine::loadAndSaveMap "
                  << " Game has already started!"
                  << std::endl;
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAMEMAP,
                  "GameEngine::loadAndSaveMap End " + QString::number(ok) );

    return ok;
}

// Start server so that it listens to connection.
bool GameEngine::startListening( const QHostAddress& address, const quint16 port )
{
    bool ok = false;
    
    if ( !m_gameStarted )
    {
        ok = m_server.startListening( address, port );
    }
    else
    {
        std::cerr << "(EE) GameEngine::startListening "
                  << " Game has already started!"
                  << std::endl;
    }

    return ok;
}

// Wait until some number of players are available to start game.
bool GameEngine::waitUntilNumberOfPlayers( const int number )
{
    Trace::print( MTP_GAME_ENGINE, STP_GE_PLAYERS,
                  "GameEngine::waitUntilNumberOfPlayers Start " + QString::number(number) );

    bool ok = false;

    if ( !m_gameStarted )
    {
        while ( m_players.count() < number )
        {
            // wait 10 milliseconds for a new connection
            m_server.waitForNewConnection( 100 );

            // wait 10 milliseconds for a gui connection
            m_server.waitForNewGuiConnection( 100 );

            // Note: In the first attempt I pinged all waiting clients
            // so that the server will receive data. I don't understand
            // it, but if the server does not send any more data to a
            // client, the server won't recognized any data send from the
            // client. So a client accepts it's ID is not waiting
            // anymore.
            // Unfortunately if a client disconnects know, the server will
            // again not recognize it until it sends some data to the client.
            // So we will ping now every client every second so that we
            // see who is still alive and who isn't.
            m_server.pingAllClients();
        }

        ok = true;
    }
    else
    {
        std::cerr << "(EE) GameEngine::waitUntilNumberOfPlayers "
                  << " Game has already started!"
                  << std::endl;
    }
    
    Trace::print( MTP_GAME_ENGINE, STP_GE_PLAYERS,
                  "GameEngine::waitUntilNumberOfPlayers End " + QString::number(ok) );

    return ok;
}

// Start a new game.
bool GameEngine::startGame()
{
    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::startGame Start " + QString::number(m_players.count()) );

    bool ok = false;

    if ( !m_gameStarted )
    {
        if ( m_players.count() > 0 )
        {
            // we should have at least one player

            // the game will start now
            m_gameStarted = true;

            // inform server that all further connections will be declined
            m_server.declineNewConnections();

            // init a new game
            if ( initGame() )
            {
                // start the rounds, it will return if all players
                // are RED
                ok = startRounds();
            }
        }
        else
        {
            std::cerr << "(EE) GameEngine::startGame "
                      << " There are no players to start game!"
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "(EE) GameEnginClientListe::startGame "
                  << " Game has already started!"
                  << std::endl;
    }
    
    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::startGame End " + QString::number(ok) );

    return ok;
}

// Add a new player.
void GameEngine::slot_addPlayer( const int playerId )
{
    Trace::print( MTP_GAME_ENGINE, STP_GE_PLAYERS,
                  "GameEngine::slot_addPlayer Start " + QString::number(playerId) );

    if ( !m_gameStarted )
    {
#ifdef QT_DEBUG
        std::cerr << "(II) GameEngine::slot_addPlayer "
                  << " Player " << playerId
                  << std::endl;
#endif
        // we will check if there is already a player with this id
        if ( !m_players.contains( playerId ) )
        {
            if ( m_showGameInfo )
            {
                std::cout << "(II) GameEngine::slot_addPlayer "
                          << playerId
                          << std::endl;
            }

            // add player to list
            m_players.add( playerId );

            if ( m_saveGameFile.isOpen() )
            {
                QTextStream out(&m_saveGameFile);
                out << "CONNECTED " << playerId << endl;
            }
        }
        else
        {
            // The player already exists! That could be the case
            // if the server has forgotten to inform us when a client
            // disconnects. But this should not happen!
            std::cerr << "(EE) GameEngine::slot_addPlayer "
                      << " Player " << playerId
                      << " already exists."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "(EE) GameEngine::slot_addPlayer "
                  << " Game has already started! "
                  << " Player " << playerId
                  << std::endl;
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_PLAYERS,
                  "GameEngine::slot_addPlayer End " );
}

// Remove player.
void GameEngine::slot_removePlayer( const int playerId )
{
    Trace::print( MTP_GAME_ENGINE, STP_GE_PLAYERS,
                  "GameEngine::slot_removePlayer Start " + QString::number(playerId) );

#ifdef QT_DEBUG
    std::cerr << "(II) GameEngine::slot_removePlayer "
              << " Player " << playerId
              << std::endl;
#endif

    // we will check if there is already a player with this id
    if ( m_players.contains( playerId ) )
    {
        if ( m_showGameInfo )
        {
            std::cout << "(II) GameEngine::slot_removePlayer "
                      << playerId
                      << std::endl;
        }

        if ( m_saveGameFile.isOpen() )
        {
            QTextStream out(&m_saveGameFile);
            out << "DISCONNECTED " << playerId << endl;
        }
        
        if ( !m_gameStarted )
        {

            // remove player from list
            m_players.remove( playerId );
        }
        else
        {
            // The game has started. We will not delete the player
            // but mark it as invalid. It will not move and we
            // won't inform other players about its position.
            m_players.setInvalid( playerId, true );

            // if the round has started and the player has not moved
            // yet we will set a dummy action, to keep the size of
            // the list correct
            if ( m_roundStarted )
            {
                if ( !m_plannedMoves.contains( playerId ) )
                {
                    m_plannedMoves.add( playerId, DIRECTION_NONE, m_players.getView( playerId ) );
                }
            }
        }
    }
    else
    {
        std::cerr << "(EE) GameEngine::slot_removePlayer "
                  << " Player " << playerId
                  << " does not exists."
                  << std::endl;
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_PLAYERS,
                  "GameEngine::slot_addPlayer End " );
}

// Move player.
void GameEngine::slot_movePlayer( const int playerId,
                                  const Direction movement,
                                  const Direction view )
{
    Trace::print( MTP_GAME_ENGINE, STP_GE_PLAYERS,
                  "GameEngine::slot_movePlayer Start " + QString::number(playerId) );

    if ( m_roundStarted )
    {
        // we will check if there is a player with this id
        if ( m_players.contains( playerId ) )
        {
            // check if view is correct, the movement could not be wrong
            Direction newView = view;
            
            if ( DIRECTION_NONE == newView )
            {
                // The player does not want to look anywhere.
                // But closing your eyes does not help in a
                // hide and seek game. ;)
                // We will set the previous viewing direction.
                newView = m_players.getView( playerId );
            }

            // we will store the movement inside the planned list

            // If the player has already send a movement, we
            // will overwrite the old one! This will automatically
            // be done.
            m_plannedMoves.add( playerId, movement, newView );

            if ( m_showGameInfo )
            {
                std::cout << "(II) GameEngine::slot_movePlayer "
                          << " Player " << playerId
                          << " Move " << Player::toString(movement).toStdString()
                          << " View " << Player::toString(newView).toStdString()
                          << std::endl;
            }
        }
        else
        {
            std::cerr << "(EE) GameEngine::slot_removePlayer "
                      << " Player " << playerId
                      << " does not exists."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "(EE) GameEngine::slot_movePlayer "
                  << " No round has started! "
                  << " Player " << playerId
                  << std::endl;
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_PLAYERS,
                  "GameEngine::slot_movePlayer End " );
}

// The time has run out for the clients to move their player.
void GameEngine::slot_timesUpForMovement()
{
    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::slot_timesUpForMovement Start " );

    // we will stop the round here
    m_roundStarted = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::slot_timesUpForMovement End " );
}

// Init a new game.
bool GameEngine::initGame()
{
    bool ok = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::initGame Start " );

    // Get list of player ids (only one time).
    m_playerIds = m_players.getListOfIds();
    
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        // Reset all players (we will not reset the invalid flag).
        m_players.resetAll();

        if ( !m_players.isInvalid( m_playerIds[ii] ) )
        {
            // Send the map to all clients whose players are valid.
            m_server.send( m_playerIds[ii], "MAP " + m_mapNameWithoutKeys );

            // Note: We will ignore if the sending has failed,
            // because maybe a client has disconnected.
            // We do not want to break the whole game.
        }
    }

    // after sending the map we will give the players some time
    // to create some walking tree etc.
    int counter = 0;

    do
    {
        // I misuse the server a little bit for the timer.
        m_server.waitForNewGuiConnection( 100 );
        counter++;

    } while ( counter < 10*NUM_SECS_WAIT_AFTER_MAP );

    // set random position for all players
    if ( setRandomStartPositions() )
    {
        ok = true;
    }

    // reset round objects
    m_roundStarted = false;
    m_numRounds = 0;
    m_numRoundsWithoutTeamChange = 0;
    m_plannedMoves.clear();

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::initGame End " + QString::number(ok) );

    return ok;
}

// Set random start position for all players.
bool GameEngine::setRandomStartPositions()
{
    bool ok = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::setRandomStartPosition Start " );

    // check if we have enough place on the game board to
    // place the players
    if ( m_map.getNumEmptyFields() > m_playerIds.count() )
    {
        // the new position
        QPoint position;

        // List with set positions.
        QList<QPoint> listOfPositions;

        // suppose everything is ok
        ok = true;

        for ( int ii = 0; ii < m_playerIds.count(); ii++ )
        {
            if ( !m_players.isInvalid( m_playerIds[ii] ) )
            {
                do
                {
                    // This will return a random position on the map.
                    // The position is valid, that means it is an empty field.
                    getRandomPositionOnMap(position);

                    // It could be, that one of the previous set positions
                    // are equal to the new one.
                    // So we will check if we already have set it.
                } while ( listOfPositions.contains( position ) );

                // so we have a new valid position
                // set it
                if ( m_players.setPosition( m_playerIds[ii], position ) )
                {
                    // add position to list
                    listOfPositions.append( position );

                    if ( m_showGameInfo )
                    {
                        std::cout << "(II) GameEngine::setRandomStartPositions "
                                  << " Player "
                                  << m_playerIds[ii]
                                  << " Pos "
                                  << "(" << position.x() << "," << position.y() << ")"
                                  << " View "
                                  << " NORTH "
                                  << std::endl;
                    }

                }
                else
                {
                    // there was an error
                    ok = false;
                    break;
                }
            }
        }
    }
    else
    {
        std::cerr << "(EE) GameEngine::setRandomStartPosition "
                  << " We do not have enough free space on the map to place all "
                  << m_playerIds.count()
                  << " players."
                  << std::endl;
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::setRandomStartPosition End " + QString::number(ok) );

    return ok;
}

// Get single random position on empty field on map.
void GameEngine::getRandomPositionOnMap( QPoint& position ) const
{

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::getRandomPositionOnMap Start " );

    // get map size
    const QSize& mapSize = m_map.getSize();

    // Note: We should be sure at this point that there is still a nice
    // place for the player. So someone should have asked getNumEmptyFields!

    // iterate until we get an empty field
    do
    {
        position.setX( rand() % mapSize.width() );
        position.setY( rand() % mapSize.height() );
    } while ( !m_map[position].isType(FT_EMPTY) );

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::getRandomPositionOnMap End " );
}

// Start rounds.
bool GameEngine::startRounds()
{
    bool ok = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::startRounds Start " );

    // ignore to the clients
    ignoreClients( true );

    // wait 10 milliseconds for a new gui connection
    m_server.waitForNewGuiConnection( 10 );
    
    // we must send the initial positions to the players
    if ( sendGameData() )
    {
        ok = true;

        // repeat until all valid players are RED
        while ( ok && !areAllPlayers( TEAM_RED ) )
        {
            if ( m_waitForKey )
            {
                std::cout << "Press ENTER to go on!" << std::endl;
                const int c = std::cin.get();

                // if we receive a 'c' for continue, we will not
                // wait anymore.
                if ( c == 'c' )
                {
                    m_waitForKey = false;
                }
            }

            // wait 10 milliseconds for a new gui connection
            m_server.waitForNewGuiConnection( 10 );

            // we have several phases:

            // 1. Start round, so that we can receive a movement.
            if ( !ok || !startNewRound() )
            {
                ok = false;
            }

            // 2. Move players
            if ( !ok || !movePlayers() )
            {
                ok = false;
            }

            // 4. Give each player its keys
            if ( !ok || !setGetKeys() )
            {
                ok = false;
            }

            // 5. Set new life power for each player
            if ( !ok || !setLifeForPlayers() )
            {
                ok = false;
            }

            // 6. Check if players change the team.
            if ( !ok || !checkAndApplyTeamChanges() )
            {
                ok = false;
            }

            // 7. Send all game data to clients
            if ( !ok || !sendGameData() )
            {
                ok = false;
            }
        }

        // print game information at end
        printGameInfo();
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::startRounds End " + QString::number(ok) );

    return ok;
}

// Set new life power for each player.
bool GameEngine::setLifeForPlayers()
{
    bool ok = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::setLifeForPlayers Start " );

    ok = true;

    // iterate over all players
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( !m_players.isInvalid( m_playerIds[ii] ) )
        {
            // we will decrease the power for every player not only
            // for BLUE ones

            const QPoint pos = m_players.getPosition( m_playerIds[ii] );

            if ( m_map.isValidPos( pos ) )
            {
                // get toxic value
                double toxic = m_map[pos].getToxicValue();

                // multiply toxic value by non movements
                toxic *= ( m_players.getNumStandStills( m_playerIds[ii] ) + 1 );

                // subtract toxic value form life energy
                if ( m_players.decreaseLife( m_playerIds[ii], toxic ) )
                {
                    if ( m_showGameInfo )
                    {
                        std::cout << "(II) GameEngine::setLifeForPlayers "
                                  << " Player "
                                  << m_playerIds[ii]
                                  << " Life "
                                  << m_players.getLife( m_playerIds[ii] )
                                  << std::endl;
                    }
                }
                else
                {
                    std::cerr << "(EE) GameEngine::setLifeForPlayers "
                              << " Player "
                              << m_playerIds[ii]
                              << " is not valid."
                              << std::endl;
                    ok = false;
                    break;
                }
            }
            else
            {
                std::cerr << "(EE) GameEngine::setLifeForPlayers "
                          << " Position "
                          << pos.x() << "," << pos.y()
                          << " is not valid on game map."
                          << std::endl;
                ok = false;
                break;
            }
        }
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::setLifeForPlayers End " + QString::number(ok) );

    return ok;
}

// Give each player its key.
bool  GameEngine::setGetKeys()
{
    bool ok = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::setGetKeys Start " );

    ok = true;

    const FieldList& keyFields = m_map.getKeys();

    // iterate over all players
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( !m_players.isInvalid( m_playerIds[ii] ) )
        {
            // get information of player
            const QPoint pos = m_players.getPosition( m_playerIds[ii] );

            // iterate over all keys
            for ( int jj = 0; jj < keyFields.count(); jj++ )
            {
                const Field& keyField = keyFields[jj];

                if ( keyField.isType( FT_KEY ) )
                {
                    if ( pos == keyField.getPos() )
                    {
                        if ( m_showGameInfo )
                        {
                            std::cout << "(II) GameEngine::setGetKeys "
                                      << " Player "
                                      << m_playerIds[ii]
                                      << " Key "
                                      << keyField.toAscii()
                                      << std::endl;
                        }

                        // the player stands on the field and can get the key
                        m_players.addKey( m_playerIds[ii],
                                          Key( QChar(keyField.toAscii()) ) );
                    }
                }
                else
                {
                    std::cerr << "(EE) GameEngine::setGetKeys "
                              << " Field "
                              << keyField.toAscii()
                              << " is not of type KEY."
                              << std::endl;
                    ok = false;
                    break;
                }
            }
        }
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::setGetKeys End " + QString::number(ok) );

    return ok;
}
    
// Send all necessary data to the clients.
bool GameEngine::sendGameData()
{
    bool ok = true;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::sendGameData Start " );

    // a. Inform all clients about their own position
    if ( !ok || !sendOwnPosition() )
    {
        ok = false;
    }
    
    // b. Inform all clients about the positions of other players
    if ( !ok || !sendOtherPositions() )
    {
        ok = false;
    }

    // c. Inform all clients about the positions of the keys
    if ( !ok || !sendKeyPositions() )
    {
        ok = false;
    }

    // d. Send current life power
    if ( !ok || !sendLifePower() )
    {
        ok = false;
    }

    // e. Send toxic value of fields
    if ( !ok || !sendToxicValue() )
    {
        ok = false;
    }
    
    // f. Apply and send team changes
    if ( !ok || !sendTeamChanges() )
    {
        ok = false;
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::sendGameData End " + QString::number(ok) );

    return ok;
}

// Start a new round.
bool GameEngine::startNewRound()
{
    bool ok = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::startNewRound Start " );

    m_plannedMoves.clear();

    // add pseudo actions for each invalid player
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( m_players.isInvalid( m_playerIds[ii] ) )
        {
            m_plannedMoves.add( m_playerIds[ii], DIRECTION_NONE, m_players.getView( m_playerIds[ii] ) );
        }
    }

#ifdef QT_DEBUG
    std::cout << "(II) GameEngine::startNewRound "
              << " Players: " << m_playerIds.count()
              << " Moved: "   << m_plannedMoves.count()
              << " Start timer with " << NUM_SECS_WAIT_PLAYER_MOVE << " seconds."
              << std::endl;
#endif

    // loop until the timer is up
    m_roundStarted = true;
    m_numRounds++;

    if ( m_showGameInfo )
    {
        std::cout << "(II) GameEngine::startNewRound "
                  << " Round " << m_numRounds
                  << std::endl;
    }

    // send start flag to GUI
    m_server.sendGui( "START " + QString::number(m_numRounds) );

    if ( m_saveGameFile.isOpen() )
    {
        QTextStream out(&m_saveGameFile);
        out << "START " << QString::number(m_numRounds) << endl;
    }

    // listen to the clients
    ignoreClients( false );

    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( !m_players.isInvalid( m_playerIds[ii] ) )
        {
            // the other players will receive the start command
            m_server.send( m_playerIds[ii], "START " + QString::number(m_numRounds) );
        }
    }

    // Note: We must first set the roundStarted flag
    // and then send the START command. Otherwise
    // it could be that the client sends its answer to fast
    // and we haven't set the roundStarted flag.
    int counter = 0;

    do
    {
        // Note: The planned actions will usually set
        // by slot_movePlayer.
        // But because we do not really want to wait endlessly
        // we use something like a timer: I misuse the server
        // a little bit and wait for a new GUI.
        // If a GUI connects in this loop the waiting time will be
        // decreased a little bit.
        m_server.waitForNewGuiConnection( 100 );
        counter++;

        // Ping all clients to receive data from them.
        // See problem above!
        m_server.pingAllClients();

    } while ( ( counter < 10*NUM_SECS_WAIT_PLAYER_MOVE ) &&
              ( m_plannedMoves.count() < m_playerIds.count() ) );

#ifdef QT_DEBUG
    std::cout << "(II) GameEngine::startNewRound "
              << " Players: " << m_playerIds.count()
              << " Moved: "   << m_plannedMoves.count()
              << std::endl;
#endif

    // ignore to the clients
    ignoreClients( true );

    // round has ended
    m_roundStarted = false;

    // if we have reached this point everything is fine
    ok = true;

    // check if there are still some players that
    // haven't moved. We set some pseudo actions
    // like above
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( !m_plannedMoves.contains( m_playerIds[ii] ) )
        {
            m_plannedMoves.add( m_playerIds[ii], DIRECTION_NONE, m_players.getView( m_playerIds[ii] ) );
        }
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::startNewRound End " + QString::number(ok) );

    return ok;
}

// Ignore or listen to all clients.
void GameEngine::ignoreClients( const bool ignore )
{
    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::ignoreClients Start " + QString::number(ignore) );

    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( !m_players.isInvalid( m_playerIds[ii] ) )
        {
            m_server.ignoreClient( m_playerIds[ii], ignore );
        }
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::ignoreClients End " );
}

// Check if all players are in one team.
bool GameEngine::areAllPlayers( const Team team ) const
{
    bool ok = true;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::areAllPlayers Start Team " + QString::number(team) );

    // Get list of player ids.
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( !m_players.isInvalid( m_playerIds[ii] ) )
        {
            // check if the team matches
            const bool isInTeam = m_players.isTeam( m_playerIds[ii], team );

#ifdef QT_DEBUG
            std::cout << "(II) GameEngine::areAllPlayers "
                      << " Player "
                      << m_playerIds[ii]
                      << " is in team "
                      << Player::toString(team).toStdString()
                      << ": " << isInTeam
                      << std::endl;
#endif

            if ( !isInTeam )
            {
                ok = false;
                break;
            }
        }
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::areAllPlayers End " + QString::number(ok) );

    return ok;
}

// Ssend all team changes to all clients.
bool GameEngine::sendTeamChanges()
{
    bool ok = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::sendTeamChanges Start " + QString::number(m_teamChanges.count()) );

    ok = true;

    // change the team in the player list
    for ( int jj = 0; jj < m_teamChanges.count(); jj++ )
    {
        // create text for sending
        const QString teamChangeText( "TEAMCHANGE " +
                                Player::toString( m_teamChanges[jj].team ) + " " +
                                QString::number(m_teamChanges[jj].playerId) );

        // The team changes will be sent to all players, no
        // matter what team.
        for ( int ii = 0; ii < m_playerIds.count(); ii++ )
        {
            if ( !m_players.isInvalid( m_playerIds[ii] ) )
            {
                // Only send info to valid clients
                m_server.send( m_playerIds[ii], teamChangeText );
                
                // Note: We will not check if the sending was okay.
            }
        }

        // send text to gui
        m_server.sendGui( teamChangeText );

        if ( m_saveGameFile.isOpen() )
        {
            QTextStream out(&m_saveGameFile);
            out << teamChangeText << endl;
        }
    }

    // clear team change list
    m_teamChanges.clear();

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::sendTeamChanges End " + QString::number(ok) );

    return ok;
}


// Check if players change the team and set the result.
bool GameEngine::checkAndApplyTeamChanges()
{
    bool ok = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::checkAndApplyTeamChanges Start " );

    // Note: Most of the logic in this method will use the fact that
    // we only have two teams and we always switch from BLUE -> RED.
    // Should we have more teams or if we could switch from RED ->
    // BLUE, we must think abouth another algorithm.

    // clear team change list
    m_teamChanges.clear();

    // get number of players in team blue
    const int numBluePlayers = getNumPlayersInTeam( TEAM_BLUE );

    // check if some player has no life power, so he will switch the team
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( !m_players.isInvalid( m_playerIds[ii] ) )
        {
            if ( m_players.isTeam( m_playerIds[ii], TEAM_BLUE ) )
            {
                // the player is in the correct team
                if ( m_players.getLife( m_playerIds[ii] ) <= 0.0 )
                {
                    // the player has no life power
                    // so he must change the team
                    m_teamChanges.append(
                        TeamChange( m_playerIds[ii], TEAM_RED, false )
                    );
                }
            }
        }
    }

    // Note: We will not cascade the effect of team changes! That means
    // if someone has lost all his life power and will change the team
    // he will not infect others that stand besides him in this round.
    // They will have the chance of one round to run away.

    // Check who stands near someone and must switch the team.
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( !m_players.isInvalid( m_playerIds[ii] ) )
        {
            if ( m_players.isTeam( m_playerIds[ii], TEAM_BLUE ) )
            {
                // the player is in the correct team

                // get the list of players of the other team
                // that besides this one
                QList<int> neighbors;

                if ( getListOfNeighbors( neighbors, m_players.getPosition( m_playerIds[ii] ), TEAM_RED ) )
                {
                    if ( m_showGameInfo )
                    {
                        for ( int jj = 0; jj < neighbors.count(); jj++ )
                        {
                            std::cout << "(II) GameEngine::checkAndApplyTeamChanges "
                                      << " Player "
                                      << m_playerIds[ii]
                                      << " surrounded by Player "
                                      << neighbors[jj]
                                      << std::endl;
                        }
                    }


                    if ( !neighbors.isEmpty() )
                    {
                        // the player is faced by other team members
                        // so he must change the team
                        m_teamChanges.append(
                            TeamChange( m_playerIds[ii], TEAM_RED, false )
                        );
                    }

                    // Give the surrounding players some extra points
                    // for catching this player.
                    // We will use maxNumRounds/numBluePlayers as
                    // additional points.
                    if ( neighbors.count() > 0 )
                    {
                        if ( numBluePlayers > 0 )
                        {
                            // get number of rounds till end
                            const int numMaxRoundsToGo = getMaxRoundsToGo();

                            // calculate points for each player that has
                            // catched this one
                            const double points = numMaxRoundsToGo * 1.0 / numBluePlayers * 1.0 / neighbors.count();

#ifdef QT_DEBUG
                            std::cout << "(II) GameEngine::checkAndApplyTeamChanges "
                                      << " Points for catching player "
                                      << m_playerIds[ii]
                                      << ": "
                                      << points
                                      << " Rounds to go: "
                                      << numMaxRoundsToGo
                                      << " Blue players: "
                                      << numBluePlayers
                                      << " Catchers: "
                                      << neighbors.count()
                                      << std::endl;
#endif
                        
                            for ( int jj = 0; jj < neighbors.count(); jj++ )
                            {
                                m_players.addScore( neighbors[jj], points );
                                m_players.increaseCatched( neighbors[jj], TEAM_BLUE );
                            }
                        }
                    }
                }
            }
        }
    }

    if ( !m_teamChanges.isEmpty() )
    {
        // otherwise we can reset the counter
        m_numRoundsWithoutTeamChange = 0;
    }
    else
    {
        // if we have no team change we must add the counter
        m_numRoundsWithoutTeamChange++;
    }

#ifdef QT_DEBUG
    std::cout << "(II) GameEngine::checkAndApplyTeamChanges "
              << " Counter without change: " << m_numRoundsWithoutTeamChange
              << std::endl;
#endif

    // if the counter is to high, we will change the team state of
    // one player automatically
    // But only if this is not the last player! He will get the chance
    // to live till the round is over
    if ( ( m_numRoundsWithoutTeamChange >=
           ( NUM_ROUNDS_WO_TEAMCHANGE + m_numRounds/NUM_ROUNDS_WO_TEAMCHANGE_FACTOR ) ) &&
           numBluePlayers > 1 )
    {
#ifdef QT_DEBUG
        std::cout << "(II) GameEngine::checkAndApplyTeamChanges "
                  << " Change player team automatically!"
                  << std::endl;
#endif

        // We use the players with least life as indicator who will
        // change the team.
        QList<int> leastLife;
        if ( getPlayersWithLeastLife( leastLife, TEAM_BLUE ) )
        {
            ok = true;

            // The list could only be empty if all valid players
            // that are in the BLUE team became invalid because
            // their client has disconnected.
            // I will set the return value to true in that case too.

            // Note 30.08.2010
            // I've decided against changing multiple players at once.
            // The reason is that very often ALL players will change
            // the team and the game ends after some rounds.
            // The new strategy is to wait until we have some single
            // player that is least seen.

            // Note 09.09.2010
            // Next try: If the map is large or if we have many players
            // it happens that we do not have such a unique least seen
            // player. So we will count up and up and nobody changes
            // the team. So Dominik H. had a new idea: Each field on
            // the game map is toxic and has some toxic level. There
            // is no field with a toxic value of 0.0. Every
            // round the player will loose some energy from his life
            // bar (it starts at 100%) standing on a field.
            // If he does not move in one round, the toxic value will
            // be multiplied. So each round the player will loose
            // TOXIC_VALUE * ( NUM_ROUNDS_NOT_MOVED + 1 ) life.
            // If after some rounds nobody has changed the team,
            // we will convert the player with the least life.
            // If there is none, we will wait to the next round.
            // If a player has no life power he will definitly change
            // the team, no matter what round.
            // At the end of each round the clients will be informed
            // about the toxic level of the field they are standing on.
            // So if they move around a lot they can trace the toxic
            // value of the whole game map. In the best case (TV=0.01%,
            // player is moving) a player can last 10.000 rounds. In
            // the worst case (TV=0.1%, player stands still), it will
            // only be 45 rounds. (Not considered the automatic
            // conversions).

            if ( 1 == leastLife.count() )
            {
                for ( int kk = 0; kk < leastLife.count(); kk++ )
                {
                    if ( !m_players.isInvalid( leastLife[kk] ) )
                    {
                        // append team change to list
                        m_teamChanges.append(
                            TeamChange( leastLife[kk], TEAM_RED, true )
                        );

                        // reset the counter, because we have a team change
                        m_numRoundsWithoutTeamChange = 0;
                    }
                    else
                    {
                        std::cerr << "(EE) GameEngine::checkAndApplyTeamChanges "
                                  << " Least seen player "
                                  << leastLife[kk]
                                  << " is invalid."
                                  << std::endl;
                        ok = false;
                    }
                }
            }
        }
    }
    else
    {
        ok = true;
    }

#ifdef QT_DEBUG
    std::cout << "(II) GameEngine::checkAndApplyTeamChanges "
              << " Changes: " << m_teamChanges.count()
              << std::endl;
#endif

    // apply team changes
    if ( ok )
    {
        const double factor = getNumPlayersInTeam(TEAM_RED)*1.0/(NUM_ROUNDS_WO_TEAMCHANGE_FACTOR);

        // change the team in the player list
        for ( int jj = 0; jj < m_teamChanges.count(); jj++ )
        {
            if ( m_showGameInfo )
            {
                std::cout << "(II) GameEngine::checkAndApplyTeamChanges "
                          << " Player "
                          << m_teamChanges[jj].playerId
                          << " Team "
                          << Player::toString( m_teamChanges[jj].team ).toStdString()
                          << " Forced "
                          << m_teamChanges[jj].forced
                          << std::endl;
            }

            if ( !m_players.setTeam( m_teamChanges[jj].playerId,
                                     m_teamChanges[jj].team,
                                     m_teamChanges[jj].forced ) )
            {
                std::cerr << "(EE) GameEngine::checkAndApplyTeamChanges "
                          << " Team change for player "
                          << m_teamChanges[jj].playerId
                          << " in team "
                          << Player::toString( m_teamChanges[jj].team ).toStdString()
                          << " could not be done."
                          << std::endl;

                // This is a major error that should not happen.
                ok = false;
                break;
            }
            else
            {
                // add number of rounds as score
                m_players.addScore( m_teamChanges[jj].playerId,
                                    factor*m_numRounds );
            }
        }
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::checkAndApplyTeamChanges End " + QString::number(ok) );

    return ok;
}

// Get list of all neighbors of some team to this position.
bool GameEngine::getListOfNeighbors( QList<int>& neighbors,
                                     const QPoint& pos, const Team team ) const
{
    bool ok = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::getListOfNeighbors Start Pos " + QString::number(pos.x()) + " " + QString::number(pos.y()) + " Team " + Player::toString(team) );

    // clear list
    neighbors.clear();
    ok = true;

    // Check all players of this team if they stand beside the given
    // position.
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( !m_players.isInvalid( m_playerIds[ii] ) )
        {
            if ( m_players.isTeam( m_playerIds[ii], team ) )
            {
                if ( areNeighboredPos( pos, m_players.getPosition( m_playerIds[ii] ) ) )
                {
                    neighbors.append( m_playerIds[ii] );
                }
            }
        }
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::getListOfNeighbors End " + QString::number(ok) );

    return ok;
}

// check if two positions are neighbored.
bool GameEngine::areNeighboredPos( const QPoint& targetPos, const QPoint& startPos ) const
{
    bool neighbored = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::areNeighboredPos Start " );

#ifdef QT_DEBUG
    std::cout << "(II) GameEngine::areNeighboredPos "
              << " Target: " << targetPos.x() << "," << targetPos.y()
              << " Start:  " << startPos.x() << "," << startPos.y()
              << std::endl;
#endif

    // calculate difference
    const QPoint diff( targetPos - startPos );

    if ( std::abs( diff.x() ) <= 1 && std::abs( diff.y() ) <= 1 )
    {
        if ( diff.x() == 0 || diff.y() == 0 )
        {
            neighbored = true;
        }
        else
        {
            // create list of all positions of the other players
            // because they could block the movement
            QList<QPoint> otherPlayerPositions;

            for ( int ii = 0; ii < m_playerIds.count(); ii++ )
            {
                if ( !m_players.isInvalid( m_playerIds[ii] ) )
                {
                    const QPoint pos = m_players.getPosition( m_playerIds[ii] );
                    // Note: Even if there are some invalid players
                    // that would block this position we will ignore
                    // them.
                    if ( targetPos != pos && startPos != pos )
                    {
                        // get player position
                        otherPlayerPositions.append( pos );
                    }
                }
            }

            // We make it a little bit more complicated:
            // If the players are neighbored diagonally
            // we will check if if there are two blocked ways
            // between the players, so that the grabbing of each
            // other is impossible. If at least one field is empty
            // or a key field, we will say they are neighbored.

            // Note 29.12.2010:
            // It's stupid that you must walk around a diagonally
            // blocked field but can grab someone diagonally.
            // So I have changed this!

            // Get neighbored positions.
            const QPoint field1( startPos.x() + diff.x(), startPos.y() );
            const QPoint field2( startPos.x(), startPos.y() + diff.y() );

            if ( ( m_map[field1].isType( FT_BLOCK ) ||
                   m_map[field1].isType( FT_DOOR ) ||
                   otherPlayerPositions.contains( field1 ) ) ||
                 ( m_map[field2].isType( FT_BLOCK ) ||
                   m_map[field2].isType( FT_DOOR ) ||
                   otherPlayerPositions.contains( field2 ) ) )
            {
                neighbored = false;
            }
            else
            {
                neighbored = true;
            }
        }
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::areNeighboredPos End " + QString::number(neighbored) );

    return neighbored;
}

// Move player (position) from start to target by movement direction.
bool GameEngine::movePosition( QPoint& targetPos, const QPoint& startPos, const Direction movement, const int playerId, const bool ignoreOtherPlayers ) const
{
    bool ok = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::movePosition Start " );

    // Note: The init is important because we will only handle
    // the target position in the loop below.
    targetPos = startPos;

    // first check if startPos is valid
    if ( m_map.isValidPos( startPos ) )
    {
#ifdef QT_DEBUG
        std::cout << "(II) GameEngine::movePosition "
                  << " Start position "
                  << targetPos.x() << " " << targetPos.y()
                  << " Move "
                  << Player::toString(movement).toStdString()
                  << std::endl;
#endif

        // create list of all positions of the other players
        // because they could block the movement
        QList<QPoint> otherPlayerPositions;

        if ( !ignoreOtherPlayers )
        {
            for ( int ii = 0; ii < m_playerIds.count(); ii++ )
            {
                if ( !m_players.isInvalid( m_playerIds[ii] ) )
                {
                    // Note: Even if there are some invalid players
                    // that would block this position we will ignore
                    // them.
                    if ( playerId != m_playerIds[ii] )
                    {
                        // get player position
                        otherPlayerPositions.append( m_players.getPosition( m_playerIds[ii] ) );
                    }
                }
            }
        }
#ifdef QT_DEBUG
        else
        {
            std::cout << "(II) GameEngine::movePosition "
                      << " Ignore other players. "
                      << std::endl;
        }
#endif

        do
        {
            ok = true;

            // move position in direction
            if ( Player::movePosition( targetPos, targetPos, movement) )
            {
#ifdef QT_DEBUG
                std::cout << "(II) GameEngine::movePosition "
                          << " Target position "
                          << targetPos.x() << " " << targetPos.y()
                          << std::endl;
#endif
                if ( m_map.isValidPos(targetPos) )
                {
                    // check if the movement is diagonal and if something
                    // is blocking the way.
                    if ( isBlockedByDiagonalMovement( targetPos, movement,
                                                      otherPlayerPositions,
                                                      playerId ) )
                    {
                        // reset position and leave while loop here
                        targetPos = startPos;
                        break;
                    }

                    // check if the reached position is a door-field
                    // If not we will leave the loop anyway.
                    if ( m_map[targetPos].isType( FT_DOOR ) )
                    {
#ifdef QT_DEBUG
                        std::cout << "(II) GameEngine::movePosition "
                                  << " Target position is door "
                                  << m_map[targetPos].toAscii()
                                  << std::endl;
#endif

                        if ( !hasPlayerKeyToDoor( m_map[targetPos], playerId ) )
                        {
                            // player does not have the right key
                            // we will leave the while-loop here
                            break;
                        }
                    }
                }
            }
            else
            {
                // there was an error, stop here
                ok = false;
                break;
            }

        } while ( m_map.isValidPos(targetPos) &&
                  m_map[targetPos].isType(FT_DOOR) );

        bool valid = false;

        if ( ok )
        {
#ifdef QT_DEBUG
            std::cout << "(II) GameEngine::movePosition "
                      << " Final target position "
                      << targetPos.x() << " " << targetPos.y()
                      << std::endl;
#endif

            // check if new position is valid
            if ( m_map.isValidPos(targetPos) )
            {
                // it must be an empty field or a key field
                if ( m_map[targetPos].isType( FT_EMPTY ) ||
                     m_map[targetPos].isType( FT_KEY ) )
                {
#ifdef QT_DEBUG
                    std::cout << "(II) GameEngine::movePosition "
                              << " Target is empty. "
                              << std::endl;
#endif

                    if ( !otherPlayerPositions.contains( targetPos ) )
                    {
                        // pos is not occupied
                        valid = true;
                    }
#ifdef QT_DEBUG
                    else
                    {
                        std::cout << "(II) GameEngine::movePosition "
                                  << " Some player already stands here."
                                  << std::endl;
                    }
#endif
                }
#ifdef QT_DEBUG
                else
                {
                    std::cout << "(II) GameEngine::movePosition "
                              << " Target is not empty. "
                              << std::endl;
                }
#endif
            }
        }

        // so finally, if the target position is not valid
        // we must reset it to the start position, the player
        // could not move in the wished direction as it seems
        if ( !valid )
        {
#ifdef QT_DEBUG
            std::cout << "(II) GameEngine::movePosition "
                      << " (not valid) Set new pos "
                      << startPos.x() << " " << startPos.y()
                      << std::endl;
#endif
            targetPos = startPos;
        }
#ifdef QT_DEBUG
        else
        {
            std::cout << "(II) GameEngine::movePosition "
                      << " (valid) Set new pos "
                      << targetPos.x() << " " << targetPos.y()
                      << std::endl;
        }
#endif

    }
    else
    {
        // start position is not valid
        std::cerr << "(EE) GameEngine::movePosition "
                  << " Position "
                  << startPos.x() << " " << startPos.y()
                  << " is not valid."
                  << std::endl;
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::movePosition End " + QString::number(ok) );

    return ok;
}

// Return true if movement is diagonal and blocked by something.
bool GameEngine::isBlockedByDiagonalMovement( const QPoint& reachedPos, const Direction movement, const QList<QPoint> addBlockedFields, const int playerId ) const
{
    bool blocked = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::isBlockedByDiagonalMovement Start " );

    // check if move was diagonal
    QPoint nField1;
    QPoint nField2;

    // For diagonal movements we must check if one
    // of the two neighboring fields is blocked
    // by a wall or a door.
    // A door is valid if the player has the key
    // for it.
    if ( isDiagonalMovement( nField1, nField2,
                             reachedPos, movement ) )
    {
#ifdef QT_DEBUG
        std::cout << "(II) GameEngine::isBlockedByDiagonalMovement "
                  << " Field1 "
                  << nField1.x() << " " << nField1.y()
                  << " Field2 "
                  << nField2.x() << " " << nField2.y()
                  << " Reached "
                  << reachedPos.x() << " " << reachedPos.y()
                  << " Dir "
                  << Player::toString( movement ).toStdString()
                  << std::endl;
#endif


        // diagonal movement, check neighbor fields
        // they must be valid
        if ( m_map[nField1].isType( FT_BLOCK ) ||
             m_map[nField2].isType( FT_BLOCK ) )
        {
            // one of the two fields is blocked
            // and we could not move there
            blocked = true;
        }
        else if ( m_map[nField1].isType( FT_DOOR) &&
                  !hasPlayerKeyToDoor( m_map[nField1], playerId ) )
        {
            // this is a door and only accessable
            // if the player has the key
            blocked = true;
        }
        else if ( m_map[nField2].isType( FT_DOOR) &&
                  !hasPlayerKeyToDoor( m_map[nField2], playerId ) )
        {
            // this is a door and only accessable
            // if the player has the key
            blocked = true;
        }
        else if ( addBlockedFields.contains( nField1 ) ||
                  addBlockedFields.contains( nField2 ) )
        {
            // check if something else stands in the way
            blocked = true;
        }
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::isBlockedByDiagonalMovement End " + QString::number(blocked) );

    return blocked;
}

// Check if movement is diagonal and return the neighbored positions for it.
bool GameEngine::isDiagonalMovement( QPoint& field1, QPoint& field2, const QPoint& reachedPos, const Direction movement ) const
{
    bool diagonal = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::isDiagonalMovement Start " );
    
    switch ( movement )
    {
    case DIRECTION_NORTH_WEST:
        Player::movePosition( field1, reachedPos, DIRECTION_SOUTH );
        Player::movePosition( field2, reachedPos, DIRECTION_EAST );
        diagonal = true;
        break;
    case DIRECTION_NORTH_EAST:
        Player::movePosition( field1, reachedPos, DIRECTION_SOUTH );
        Player::movePosition( field2, reachedPos, DIRECTION_WEST );
        diagonal = true;
        break;
    case DIRECTION_SOUTH_WEST:
        Player::movePosition( field1, reachedPos, DIRECTION_NORTH );
        Player::movePosition( field2, reachedPos, DIRECTION_EAST );
        diagonal = true;
        break;
    case DIRECTION_SOUTH_EAST:
        Player::movePosition( field1, reachedPos, DIRECTION_NORTH );
        Player::movePosition( field2, reachedPos, DIRECTION_WEST );
        diagonal = true;
        break;
    default:
        diagonal = false;
        break;
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::isDiagonalMovement End " + QString::number(diagonal) );

    return diagonal;
}                  

// Check if some player has the key to a door.
bool GameEngine::hasPlayerKeyToDoor( const Field& doorField, const int playerId ) const
{
    bool hasKey = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::hasPlayerKeyToDoor Start " );

    // transform the door to a key
    Field keyField;
    if ( doorField.convertToKeyField( keyField ) )
    {
        // create Key
        Key key( keyField.toAscii() );

        // check if the player has the key
        if ( m_players.hasKey( playerId, key ) )
        {
            hasKey = true;
            
#ifdef QT_DEBUG
            std::cout << "(II) GameEngine::hasPlayerKeyToDoor "
                      << " Player has key "
                      << keyField.toAscii()
                      << std::endl;
#endif
        }
#ifdef QT_DEBUG
        else
        {
            std::cout << "(II) GameEngine::hasPlayerKeyToDoor "
                      << " Player does not have key "
                      << keyField.toAscii()
                      << std::endl;
        }
#endif
    }
    else
    {
        std::cout << "(EE) GameEngine::hasPlayerKeyToDoor "
                  << " Field "
                  << doorField.toAscii()
                  << " could not be converted to key."
                  << std::endl;
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::hasPlayerKeyToDoor End " + QString::number(hasKey) );

    return hasKey;
}

// Get all players with least life.
bool GameEngine::getPlayersWithLeastLife( QList<int>& leastLifePlayers, const Team team ) const
{
    bool ok = false;
    leastLifePlayers.clear();

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::getPlayersWithLeastLife Start " + QString::number(team) );

    ok = true;

    // the default is 100 percent, so we make it bigger
    double leastLifeValue = 1000.0;

    // iterate over all players
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( !m_players.isInvalid( m_playerIds[ii] ) )
        {
            if ( m_players.isTeam( m_playerIds[ii], team ) )
            {
                const double playerLife = m_players.getLife( m_playerIds[ii] );

                if ( playerLife > 0.0 )
                {
                    if ( playerLife < leastLifeValue )
                    {
                        // this player has less life power than the others
                        leastLifePlayers.clear();
                        leastLifePlayers.append( ii );
                        leastLifeValue = playerLife;
                    }
                    else if ( playerLife == leastLifeValue )
                    {
                        // the player has the same life power
                        // as the currently smalles one
                        // so store the id
                        leastLifePlayers.append( ii );
                    }
                    // else the value is bigger, do nothing
                }
                // else we should already have converted
                // the player!
            }
        }
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::getPlayersWithLeastLife End " + QString::number(ok) );

    return ok;
}

// Check if some player is visible from another position.
bool GameEngine::isVisible( const QPoint& targetPos, const QPoint& pos, const Direction view ) const
{
    bool visible = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::isVisible Start " );

    // Get list of positions of all players (minus the two given
    // positions). That will be used as additional blocking elements.
    // for these two players.
    QList<QPoint> addBlockedFields;
    
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( !m_players.isInvalid( m_playerIds[ii] ) )
        {
            const QPoint thirdPos = m_players.getPosition( m_playerIds[ii] );

            if ( ( thirdPos != targetPos ) && ( thirdPos != pos ) )
            {
                // this player does stand on another position
                // so add it
                addBlockedFields.append( thirdPos );
            }
        }
    }
        
    // First we will check if we could possible see the target position
    // from our position if we look in the direction view.

    // Note 26.10.2010:
    // It's possible that the field is surrounded by blocks
    // and is only open on one side. If we only check the
    // four corners, they would intersect with the blocks
    // around and so the field would not be visible.
    // Therefore we will not use the real corners but will go a
    // little bit (0.0001) inside the target position.

    // set four corners of the target
    QPointF corner[4];
    corner[0] = QPointF( targetPos.x()+0.0001, targetPos.y()+0.0001 );
    corner[1] = QPointF( targetPos.x()+0.9999, targetPos.y()+0.0001 );
    corner[2] = QPointF( targetPos.x()+0.9999, targetPos.y()+0.9999 );
    corner[3] = QPointF( targetPos.x()+0.0001, targetPos.y()+0.9999 );

    // "eyes" of origin = middle of field
    const QPointF originP( pos.x() + 0.5, pos.y() + 0.5 );

    // check for every corner if it's visible
    for ( int ii = 0; ii < 4; ii++ )
    {
        if ( isPossibleVisible( corner[ii], originP, view ) )
        {
            // Checking if one player (from otherPos) sees another one
            // (on pos) is a mathematical question. We will create a line
            // from otherPos to pos and check all intersections with
            // the walls and doors on the game map.
            if ( m_map.isPositionVisible( corner[ii], originP, addBlockedFields ) )
            {
                // the corner is visible => so is the target
                visible = true;
                break;
            }
        }
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::isVisible End " + QString::number(visible) );

    return visible;
}

// Check if target position is possible visible from pos.
bool GameEngine::isPossibleVisible( const QPointF& targetPos, const QPointF& pos,
                                    const Direction view ) const
{
    bool visible = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::isPossibleVisible Start " );

    // We can only see a span of 180 degree in the viewing
    // direction. Therefore everything that is "behind" a player is
    // not visible to him.

    // The algorithm is very easy:
    // 1. Calculate the view end point E.
    // 2. Calculate the viewing vector E-P.
    // 3. Calculate diff vector T-P.
    // 4. Calculate scalar product s = ( E-P, T-P ).
    // If s > 0 E and T lie on the same side and therefore T is visible
    // from P.
    // If s < 0 E and T lie on different sided and therefore T is not
    // visible from P.
    // If s == 0, we say that it's still visible.

    // Attention: Each field on the game map has a size of 1 in
    // both dimension. A player will only have "eyes" at the center
    // of it. So we do not calculate with positions but with
    // the center of each field!
    // The target at the other hand will have dimensions of 1x1
    // of the field he's standing on. So if we see at least one
    // of the four field cornes, the target is visible.

    // set target
    QPointF viewP( pos );

    if ( calcViewEndPoint( viewP, pos, view ) )
    {
#ifdef QT_DEBUG
        std::cout << "(II) GameEngine::isPossibleVisible "
                  << " To: "   << targetPos.x() << " " << targetPos.y() 
                  << " From: " << pos.x() << " " << pos.y() 
                  << " View: " << viewP.x() << " " << viewP.y() 
                  << std::endl;
#endif

        // calcuate viewing vector
        const QPointF viewVec( viewP - pos );

        // calculate diff vector
        const QPointF diffVec( targetPos - pos );

        // calculate scalar product
        const qreal scalProd = viewVec.x() * diffVec.x() + viewVec.y() * diffVec.y();

#ifdef QT_DEBUG
        std::cout << "(II) GameEngine::isPossibleVisible "
                  << " viewVec: "  << viewVec.x() << " " << viewVec.y() 
                  << " diffVec: "  << diffVec.x() << " " << diffVec.y() 
                  << " scalProd: " << scalProd
                  << std::endl;
#endif

        // Check visibility by scalar product
        // Only one corner must be visible.
        visible = ( scalProd > 0.0 );
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::isPossibleVisible End " + QString::number(visible) );

    return visible;
}

// Calculate viewing end point.
bool GameEngine::calcViewEndPoint( QPointF& endPoint, const QPointF& pos,
                                   const Direction view ) const
{
    bool ok = true;
    endPoint = pos;

    switch ( view )
    {
    case DIRECTION_NORTH:
        endPoint = QPointF( endPoint.x(),     endPoint.y() - 1 );
        break;
    case DIRECTION_NORTH_WEST:
        endPoint = QPointF( endPoint.x() - 1, endPoint.y() - 1 );
        break;
    case DIRECTION_WEST:
        endPoint = QPointF( endPoint.x() - 1, endPoint.y() );
        break;
    case DIRECTION_SOUTH_WEST:
        endPoint = QPointF( endPoint.x() - 1, endPoint.y() + 1 );
        break;
    case DIRECTION_SOUTH:
        endPoint = QPointF( endPoint.x(),     endPoint.y() + 1 );
        break;
    case DIRECTION_SOUTH_EAST:
        endPoint = QPointF( endPoint.x() + 1, endPoint.y() + 1 );
        break;
    case DIRECTION_EAST:
        endPoint = QPointF( endPoint.x() + 1, endPoint.y() );
        break;
    case DIRECTION_NORTH_EAST:
        endPoint = QPointF( endPoint.x() + 1, endPoint.y() - 1 );
        break;
    default:
        std::cerr << "(EE) GameEngine::calcViewEndPoint "
                  << " Default case reached for view "
                  << Player::toString(view).toStdString()
                  << std::endl;
        ok = false;        
        break;
    }

    return ok;
}

// Get maximum number of rounds left fot the game.
int GameEngine::getMaxRoundsToGo() const
{
    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::getMaxRoundsToGo Start " );

    int rounds = 0;

    // We have a team change every NUM_ROUNDS_WO_TEAMCHANGE + m_numRounds/NUM_ROUNDS_WO_TEAMCHANGE_FACTOR
    // if no player changes the team before.
    // So if we are currently in round
    //     m = (m_numRounds-m_numRoundsWithoutTeamChange)
    // the next change will be at
    //     m' = NUM_ROUNDS_WO_TEAMCHANGE_FACTOR/(NUM_ROUNDS_WO_TEAMCHANGE_FACTOR-1)*(NUM_ROUNDS_WO_TEAMCHANGE + m)
    // We must calculate this m' for every blue player with
    // new start rounds m.
    const int numBluePlayers = getNumPlayersInTeam( TEAM_BLUE );

    // the base round where everything starts
    int baseRounds = m_numRounds - m_numRoundsWithoutTeamChange;

    for ( int ii = 0; ii < numBluePlayers; ii++ )
    {
        const int finalRound = NUM_ROUNDS_WO_TEAMCHANGE_FACTOR*(NUM_ROUNDS_WO_TEAMCHANGE + baseRounds) / (NUM_ROUNDS_WO_TEAMCHANGE_FACTOR - 1) - baseRounds;
        // (5*(NUM_ROUNDS_WO_TEAMCHANGE+baseRounds))/4-baseRounds;
        rounds += finalRound;
        baseRounds += finalRound;
    }

    // now we must subtract the rounds we already have without any
    // teamchange
    rounds -= m_numRoundsWithoutTeamChange;

    if ( rounds < 0 )
    {
        // Note: The last player will not be converted automatically
        // he can move around until catched or no life energy.
        // So it is possible that a red player catches the last blue
        // one after the regular calculated end of the game.
        // Then the number of resulting rounds is be negative
        // and the red player will be punished for catching the blue
        // one. (We do not want this yet!)
        if( numBluePlayers > 1 )
        {
            std::cerr << "(EE) GameEngine::getMaxRoundsToGo "
                      << " Number of rounds "
                      << rounds
                      << " would be negative."
                      << std::endl;

        }
        rounds = 0;
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::getMaxRoundsToGo End " + QString::number(rounds) );

    return rounds;
}

// Count number of players in some team.
int GameEngine::getNumPlayersInTeam( const Team team ) const
{
    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::getNumPlayersInTeam Start " );

    int number = 0;

    // iterate over all players
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( !m_players.isInvalid( m_playerIds[ii] ) )
        {
            if ( m_players.isTeam( m_playerIds[ii], team ) )
            {
                number++;
            }
        }
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::getNumPlayersInTeam End " + QString::number(number) );

    return number;
}

// Move all players depending on the planned moves.
bool GameEngine::movePlayers()
{
    bool ok = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::movePlayers Start " );

    // All players must have planned their moves.
    // So we will iterate over all and try to accept their
    // actions.

    if ( m_plannedMoves.count() == m_playerIds.count() )
    {
        ok = true;

        // Note: The order of the planned moves is important because
        // the first planned move will be executed at first.
        // So it could happen that two player try to access the same
        // field but one is faster than the other.
        for ( int ii = 0; ii < m_plannedMoves.count(); ii++ )
        {
            // We will move all players. The invalid ones
            // will have a move action that should not move them
            // at all!
            PlayerAction action;
            if ( m_plannedMoves.get( action, ii ) )
            {
                QPoint pos;
                if ( movePosition( pos, m_players.getPosition( action.id ),
                                   action.movement, action.id,
                                   false ) )
                {
                    if ( m_showGameInfo )
                    {
                        std::cout << "(II) GameEngine::movePlayers "
                                  << " Player "
                                  << action.id
                                  << " Pos "
                                  << "(" << pos.x() << "," << pos.y() << ")"
                                  << " View "
                                  << Player::toString( action.view ).toStdString()
                                  << std::endl;
                    }

                    // set the player
                    if ( !m_players.setPosition( action.id, pos ) ||
                         !m_players.setView( action.id, action.view ) )
                    {
                        ok = false;
                        break;
                    }
                }
                else
                {
                    ok = false;
                    break;
                }
            }
            else
            {
                ok = false;
                break;
            }
        }
    }
    else
    {
        std::cerr << "(EE) GameEngine::movePlayers "
                  << " Size of planned moves "
                  << m_plannedMoves.count()
                  << " and size of players "
                  << m_playerIds.count()
                  << " do not match."
                  << std::endl;
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::movePlayers End " + QString::number(ok) );

    return ok;
}

// Create string with movement for sending.
QString GameEngine::createTextForSendingOwnPos( const int playerId ) const
{
    const QPoint pos = m_players.getPosition( playerId );
    const Direction view = m_players.getView( playerId );

    return QString( "SET " + QString::number(pos.x()) +
                    "," + QString::number(pos.y()) + " " +
                    Player::toString(view) );
}

// Create string with movement for sending.
QString GameEngine::createTextForSendingOtherPos( const int playerId ) const
{
    const QPoint pos = m_players.getPosition( playerId );
    const Direction view = m_players.getView( playerId );

    return QString( "SEE_PLAYER " + QString::number(pos.x()) +
                    "," + QString::number(pos.y()) + " " +
                    Player::toString(view) + " " + QString::number( playerId ) );
}

// Create string with key for sending.
QString GameEngine::createTextForSendingSeeKey( const Field& keyField ) const
{
    // Note: We do not check if the keyField is really a key!

    const QPoint& pos = keyField.getPos();

    return QString( "SEE_KEY " + QString::number(pos.x()) +
                    "," + QString::number(pos.y()) + " " +
                    QString( keyField.toAscii() ) );
}

// Create string with key for sending.
QString GameEngine::createTextForSendingGetKey( const Field& keyField ) const
{
    // Note: We do not check if the keyField is really a key!
    return QString( "GET_KEY " + QString( keyField.toAscii() ) );
}

// Create texts with movements of other players for sending.
bool GameEngine::createTextForSendingPlayers( QStringList& texts,
                                              const int playerId ) const
{
    bool ok = false;

    texts.clear();

    // get information of player
    const Team team = m_players.getTeam( playerId );
    const QPoint pos = m_players.getPosition( playerId );
    const Direction view = m_players.getView( playerId );

    ok = true;

    Team oteam;
    QPoint opos;
    Direction oview;
    bool visible = false;;

    // iterate over all players
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( playerId != m_playerIds[ii] )
        {
            // we are not allowed to inform the same player
            // about his own position.
            
            if ( !m_players.isInvalid( m_playerIds[ii] ) )
            {
                oteam = m_players.getTeam( m_playerIds[ii] );
                opos  = m_players.getPosition( m_playerIds[ii] );
                oview = m_players.getView( m_playerIds[ii] );
                visible = false;

                // we must check if they are in the same team
                if ( team == oteam )
                {
                    // same team, so the players are allowed to
                    // see each other (even through walls)
                    texts.append( createTextForSendingOtherPos( m_playerIds[ii] ) );
                    visible = true;
                }
                else
                {
                    // not the same team, but maybe the see each other
                    if ( isVisible( m_players.getPosition( m_playerIds[ii] ),
                                    pos, view ) )
                    {
                        // the player sees the other one directly
                        texts.append( createTextForSendingOtherPos( m_playerIds[ii] ) );
                        visible = true;
                    }
                }

                if ( m_showGameInfo && visible )
                {
                    std::cout << "(II) GameEngine::seePlayer "
                              << " Player "
                              << playerId
                              << " Other "
                              << m_playerIds[ii]
                              << " Pos "
                              << "(" << opos.x() << "," << opos.y() << ")"
                              << " View "
                              << Player::toString( oview ).toStdString()
                              << " Team "
                              << Player::toString( oteam ).toStdString()
                              << std::endl;
                }
            } 
        }
    }

    return ok;
}
                                          
// Create strings which keys are visible for sending.
bool GameEngine::createTextForSendingKeys( QStringList& texts,
                                           const FieldList& keyFields,
                                           const int playerId ) const
{
    bool ok = false;

    texts.clear();

    // get information of player
    const QPoint pos = m_players.getPosition( playerId );
    const Direction view = m_players.getView( playerId );

    ok = true;

    // iterate over all keys
    for ( int ii = 0; ii < keyFields.count(); ii++ )
    {
        const Field& key = keyFields[ii];

        if ( key.isType( FT_KEY ) )
        {
            if ( pos == key.getPos() )
            {
                // the player stands on the field and can get the key
                texts.append( createTextForSendingGetKey( key ) );

                if ( m_showGameInfo )
                {
                    std::cout << "(II) GameEngine::getKey "
                              << " Player "
                              << playerId
                              << " Key "
                              << key.toAscii()
                              << std::endl;
                }
            }
            else
            {
#ifdef QT_DEBUG
                std::cout << "(II) GameEngine::checkKey "
                          << " Player "
                          << playerId
                          << " Key "
                          << key.toAscii()
                          << " Pos "
                          << "(" << key.getPos().x()
                          << "," << key.getPos().y() << ")"
                          << std::endl;
#endif

                // check if the player sees the key
                if ( isVisible( key.getPos(),
                                pos, view ) )
                {
                    // the player sees the key
                    texts.append( createTextForSendingSeeKey( key ) );

                    if ( m_showGameInfo )
                    {
                        std::cout << "(II) GameEngine::seeKey "
                                  << " Player "
                                  << playerId
                                  << " Key "
                                  << key.toAscii()
                                  << " Pos "
                                  << "(" << key.getPos().x()
                                  << "," << key.getPos().y() << ")"
                                  << std::endl;
                    }
                }
            }
        }
        else
        {
            std::cerr << "(EE) GameEngine::createTextForSendingKeys "
                      << " Field "
                      << key.toAscii()
                      << " is not of type KEY."
                      << std::endl;
            ok = false;
            break;
        }
    }

    return ok;
}

// Inform all clients about their own position
bool GameEngine::sendOwnPosition()
{
    bool ok = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::sendOwnPosition Start " );

    ok = true;

    // iterate over all players
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( !m_players.isInvalid( m_playerIds[ii] ) )
        {
            m_server.send( m_playerIds[ii],
                           createTextForSendingOwnPos( m_playerIds[ii] ) );

            // Note: We do not check the return result of the sending.

            // send text to gui
            // Note: For the GUI there are only other pos!
            m_server.sendGui( createTextForSendingOtherPos( m_playerIds[ii] ) );

            if ( m_saveGameFile.isOpen() )
            {
                QTextStream out(&m_saveGameFile);
                out << createTextForSendingOtherPos( m_playerIds[ii] ) << endl;
            }
        }
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::sendOwnPosition End " + QString::number(ok) );

    return ok;
}

// Inform all clients about the positions of other players
bool GameEngine::sendOtherPositions()
{
    bool ok = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::sendOtherPositions Start " );

    QStringList texts;
    ok = true;

    // iterate over all players
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( !m_players.isInvalid( m_playerIds[ii] ) )
        {
            // create a list with the texts we will send to this client
            if ( createTextForSendingPlayers( texts, m_playerIds[ii] ) )
            {
                // send texts
                for ( int kk = 0; kk < texts.count(); kk++ )
                {
                    m_server.send( m_playerIds[ii], texts[kk] );

                    // Note: We do not check the return result of the sending.
                }
            }
            else
            {
                ok = false;
                break;
            }
        }
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::sendOtherPositions End " + QString::number(ok) );

    return ok;
}

// Inform all clients about the positions of the keys
bool GameEngine::sendKeyPositions()
{
    bool ok = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::sendKeyPositions Start " );

    QStringList texts;
    ok = true;

    // get keys
    const FieldList& keyFields = m_map.getKeys();

    // iterate over all players
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( !m_players.isInvalid( m_playerIds[ii] ) )
        {
            // create a list with the texts we will send to this client
            if ( createTextForSendingKeys( texts, keyFields, m_playerIds[ii] ) )
            {
                // send texts
                for ( int kk = 0; kk < texts.count(); kk++ )
                {
                    m_server.send( m_playerIds[ii], texts[kk] );

                    // Note: We do not check the return result of the sending.
                }
            }
            else
            {
                ok = false;
                break;
            }
        }
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::sendKeyPositions End " + QString::number(ok) );

    return ok;
}

// Send current life power to clients.
bool GameEngine::sendLifePower()
{
    bool ok = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::sendLifePower Start " );

    ok = true;
    
    // iterate over all players
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( !m_players.isInvalid( m_playerIds[ii] ) )
        {
            // get life power
            const double life = m_players.getLife( m_playerIds[ii] );

            const QString text( "LIFE " + QString::number( life, 'f', 2 )+
                                " " + QString::number(m_playerIds[ii]) );

            m_server.send( m_playerIds[ii], text);

            // send to gui
            m_server.sendGui( text );

            if ( m_saveGameFile.isOpen() )
            {
                QTextStream out(&m_saveGameFile);
                out << text << endl;
            }
            // Note: We do not check the return result of the sending.
        }
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::sendLifePower End " + QString::number(ok) );

    return ok;
}

// Send toxic value of player position to clients.
bool GameEngine::sendToxicValue()
{
    bool ok = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::sendToxicValue Start " );

    ok = true;

    // iterate over all players
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        if ( !m_players.isInvalid( m_playerIds[ii] ) )
        {
            const QPoint pos = m_players.getPosition( m_playerIds[ii] );

            if ( m_map.isValidPos( pos ) )
            {
                const double toxic = m_map[pos].getToxicValue();

                const QString text( "TOXIC " + QString::number(pos.x()) +
                                    "," + QString::number(pos.y()) +
                                    " " + QString::number( toxic, 'f', 2 ) );

                m_server.send( m_playerIds[ii], text );

                if ( m_showGameInfo )
                {
                    std::cout << "(II) GameEngine::sendToxic "
                              << " Player "
                              << m_playerIds[ii]
                              << " Toxic "
                              << toxic
                              << std::endl;
                }

                // Note: We do not check the return result of the sending.

                // There is not need to send the value to the GUI
                // because it should have loaded the correct map
                // with toxic values.

                if ( m_saveGameFile.isOpen() )
                {
                    QTextStream out(&m_saveGameFile);
                    out << text << endl;
                }
            }
            else
            {
                std::cerr << "(EE) GameEngine::sendToxicValue "
                          << " Position "
                          << pos.x() << "," << pos.y()
                          << " is not valid on game map."
                          << std::endl;
                ok = false;
                break;
            }
        }
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::sendToxicValue End " + QString::number(ok) );

    return ok;
}

// Slot that a new gui has connected.
void GameEngine::slot_guiConnected()
{
    if ( !m_mapName.isEmpty() )
    {
        // Send the map.
        m_server.sendGui( "MAP " + m_mapName );

        // send information about players
        for ( int ii = 0; ii < m_playerIds.count(); ii++ )
        {
            if ( !m_players.isInvalid( m_playerIds[ii] ) )
            {
                m_server.sendGui( createTextForSendingOtherPos( m_playerIds[ii] ) );

                // get life power
                const double life = m_players.getLife( m_playerIds[ii] );

                const QString text( "LIFE " + QString::number( life, 'f', 2 )+
                                    " " + QString::number(m_playerIds[ii]) );

                m_server.sendGui( text );

                // create text for sending
                const Team team = m_players.getTeam( m_playerIds[ii] );
                const QString teamChangeText( "TEAMCHANGE " +
                                              Player::toString(team) + " " +
                                              QString::number(m_playerIds[ii]) );

                m_server.sendGui( teamChangeText );
            }
        }
    }
}

// Print game information at end of game.
void GameEngine::printGameInfo() const
{
    // Every player get one point for each round he was in the team BLUE,
    // not matter if the team change was forced or not.
    for ( int ii = 0; ii < m_playerIds.count(); ii++ )
    {
        std::cout << "(II) Player "
                  << m_playerIds[ii]
                  << ":"
                  << " Rounds "
                  << m_players.getNumRoundsInTeam( m_playerIds[ii], TEAM_BLUE ) - 1
                  << " Score "
                  << QString::number( m_players.getScore( m_playerIds[ii] ) ).replace('.',',').toStdString()
                  << " Catched "
                  << m_players.getNumCatchesOfTeam( m_playerIds[ii], TEAM_BLUE )
                  << " Forced "
                  << m_players.wasForcedTeamChange( m_playerIds[ii] )
                  << " Team "
                  << Player::toString( m_players.getTeam( m_playerIds[ii] ) ).toStdString();

        if ( m_players.isInvalid( m_playerIds[ii] ) )
        {
            std::cout << " (invalid)";
        }

        std::cout << std::endl;
    }
}

// Set filename for saving game progress to.
bool GameEngine::saveGame( const QString& saveFilename )
{
    bool ok = false;

    // if the save game is still open, close it
    if ( m_saveGameFile.isOpen() )
    {
        m_saveGameFile.close();
    }

    if ( !saveFilename.isEmpty() )
    {
        // set new filename for saving
        m_saveGameFile.setFileName( saveFilename );

        // open file for writing
        if ( m_saveGameFile.open(QFile::WriteOnly | QFile::Truncate) )
        {
            // file is open
            ok = true;
        }
        else
        {
            std::cerr << "(EE) GameEngine::saveGame "
                      << " File "
                      << saveFilename.toStdString()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "(EE) GameEngine::saveGame "
                  << " Filename is empty."
                  << std::endl;
    }

    return ok;
}
