/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
/////////
#include "gameengine.hh"
#include "trace.hh"

// Qt
//////////
#include <QHostAddress>
#include <QString>
#include <QCoreApplication>
#include <QTranslator>
#include <QLocale>

// Sys
////////
#include <iostream>

int main( int argc, char *argv[] )
{
    int retValue = 255;

    // Create Qt application.
    QCoreApplication app( argc, argv );

    QTranslator appTranslator;
    if ( appTranslator.load( "engine_" + QLocale::system().name() ) )
    {
        app.installTranslator( &appTranslator );
    }

    // Trace::activate( MTP_GAMEMAP,           0x000F );
    // Trace::activate( MTP_FIELD,             0x0006 );
    // Trace::activate( MTP_PLAYER,            0x0003 );
    // Trace::activate( MTP_KEY,               0x0001 );
    // Trace::activate( MTP_COMMAND,           0x0003 );
    // Trace::activate( MTP_PARSER,            0x0003 );
    // Trace::activate( MTP_CLIENT,            0x003F );
    // Trace::activate( MTP_CLIENTLIST,        0x001F );
    // Trace::activate( MTP_SERVERPARSER,      0x0007 );
    // Trace::activate( MTP_SERVERPARSERLIST,  0x0007 );
    // Trace::activate( MTP_SERVER,            0x007F );
    // Trace::activate( MTP_GAME_ENGINE,       0x000F );

    // number of players for game
    int numPlayers = -1;

    // first we must extract map, number of players etc.
    // The values below represent the index in the parameter
    // list. -1 means not set.
    int mapIndex = -1;
    int playerIndex = -1;
    int saveIndex = -1;

    // Flag, if we want to wait for a key in each round.
    // This is usefull for debugging.
    bool waitForKey = false;

    // Flag if the engine should give any output like
    // connected players, set positions etc.
    bool showInfo = false;

    // Flag if help should be shown
    // This will override all other flags!
    bool showHelp = false;

    // Flag if game should be saved.
    bool saveGame = false;

    // iterate over all arguments
    // the first argument is the calling name.
    for ( int ii = 1; ii < argc; ii++ )
    {
        const QString param(argv[ii]);

        if ( param == "--info" || param == "-i" )
        {
            showInfo = true;
        }
        else if ( param == "--help" || param == "-h" )
        {
            showHelp = true;
        }
        else if ( param == "--wait" || param == "-w" )
        {
            waitForKey = true;
        }
        else if ( param == "--players" || param == "-p" )
        {
            // in this case the next argument must be the
            // number if players
            if ( ii+1 < argc )
            {
                playerIndex = ii+1;
                // ignore next argument
                ii++;
            }
        }
        else if ( param == "--map" || param == "-m" )
        {
            // in this case the next argument must be the
            // mapname
            if ( ii+1 < argc )
            {
                mapIndex = ii+1;
                // ignore next argument
                ii++;
            }
        }
        else if ( param == "--save" || param == "-s" )
        {
            saveGame = true;
            
            // in this case the next argument must be the
            // filename for saving
            if ( ii+1 < argc )
            {
                saveIndex = ii+1;
                // ignore next argument
                ii++;
            }
        }
        else
        {
            std::cerr << GameEngine::tr("Unknown option: ").toStdString()
                      << param.toStdString() << std::endl << std::endl;
            showHelp = true;
            break;
        }
    }

    if ( !showHelp )
    {
        if ( playerIndex == -1 )
        {
            std::cerr << GameEngine::tr("Number of players must be set.").toStdString()
                      << std::endl << std::endl;
            showHelp = true;
        }
        else
        {
            bool ok = false;
            numPlayers = QString( argv[playerIndex] ).toInt(&ok);
            
            // extraction has failed, we will not start the game
            if ( !ok )
            {
                std::cerr << GameEngine::tr("Could not extract number of players from ").toStdString()
                          << argv[playerIndex] << std::endl << std::endl;
                showHelp = true;
            }
            else
            {
                if ( numPlayers <= 0 )
                {
                    std::cerr << GameEngine::tr("Number of players ").toStdString()
                              << numPlayers
                              << GameEngine::tr(" must be positive.").toStdString()
                              << std::endl << std::endl;
                    showHelp = true;
                }
            }
        }
    }

    if ( !showHelp )
    {
        if ( mapIndex == -1 )
        {
            std::cerr << GameEngine::tr("Map file must be set.").toStdString()
                      << std::endl << std::endl;
            showHelp = true;
        }
    }

    if ( !showHelp && saveGame )
    {
        if ( saveIndex == -1 )
        {
            std::cerr << GameEngine::tr("Filename for saving game data must be set.").toStdString()
                      << std::endl << std::endl;
            showHelp = true;
        }
    }

    if ( showHelp )
    {
        // we want to show the help or some important index
        // was not set
        std::cout << GameEngine::tr("Usage: ").toStdString() << argv[0] << GameEngine::tr(" [OPTIONS]").toStdString() << std::endl;
        std::cout << GameEngine::tr("Starts the engine for the Right2Live-contest of freiesMagazin.").toStdString() << std::endl;
        std::cout << std::endl;
        std::cout << GameEngine::tr("Possible options: ").toStdString() << std::endl;
        std::cout << "  -m, --map FILE     " << GameEngine::tr("Load a map file for the game.").toStdString() << std::endl;
        std::cout << "  -p, --players NUM  " << GameEngine::tr("Wait for NUM players before the game starts.").toStdString() << std::endl
                  << "                     " << GameEngine::tr("NUM must be a positive integer.").toStdString() << std::endl;
        std::cout << "  -s, --save FILE    " << GameEngine::tr("Save game process to file.").toStdString() << std::endl;
        std::cout << "  -w, --wait         " << GameEngine::tr("Wait for a key before each round.").toStdString() << std::endl;
        std::cout << "  -i, --info         " << GameEngine::tr("Print informations during game.").toStdString() << std::endl;
        std::cout << "  -h, --help         " << GameEngine::tr("Show this help text.").toStdString() << std::endl;
    }
    else
    {
        // create a new game engine
        GameEngine engine;

        // set flags
        engine.waitForKeyPressed( waitForKey );
        engine.showGameInfo( showInfo );

        if ( !saveGame || engine.saveGame( argv[saveIndex] ) )
        {
            // load map
            if ( engine.loadAndSaveMap( argv[mapIndex] ) )
            {
                // start server
                if ( engine.startListening( QHostAddress::LocalHost, 15000 ) )
                {
                    // wait until some players are available
                    if ( engine.waitUntilNumberOfPlayers( numPlayers ) )
                    {
                        if ( engine.startGame() )
                        {
                            retValue = 0;
                        }
                    }
                }
            }
        }
    }

    return retValue;
}
