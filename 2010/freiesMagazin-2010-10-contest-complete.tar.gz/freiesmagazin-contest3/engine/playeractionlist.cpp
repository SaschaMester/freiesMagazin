/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
/////////
#include "playeractionlist.hh"

// Constructor
PlayerActionList::PlayerActionList()
{
    // nothing to do
}

// Return number of elements in list.
int PlayerActionList::count()
{
    return m_list.count();
}

// Check if player with id is in list.
bool PlayerActionList::contains( const int playerId ) const
{
    return ( find( playerId ) >= 0 );
}

// Get a copy of a player action.
bool PlayerActionList::get( PlayerAction& action, const int index ) const
{
    bool ok = false;

    if ( 0 <= index && index < m_list.count() )
    {
        action = m_list[index];
        ok = true;
    }

    return ok;
}

// Clears all actions in the list.
void PlayerActionList::clear()
{
    m_list.clear();
}

// Add new player action.
bool PlayerActionList::add( const int playerId, const Direction move,
                            const Direction view )
{
    bool ok = false;
    
    // check if view and player is valid
    if ( playerId >= 0 && DIRECTION_NONE != view )
    {
        // new player action
        PlayerAction action;

        // search player id
        const int index = find( playerId );

        if ( index >= 0 )
        {
            // if we have found the element, remove it from the list
            m_list.removeAt( index );
        }

        // set the data ...
        action.id = playerId;
        action.movement = move;
        action.view = view;

        // ... and append it
        m_list.append( action );
        
        ok = true;
    }

    return ok;
}

// Find player id.
int PlayerActionList::find( const int playerId ) const
{
    int index = -1;

    for ( int ii = 0; ii < m_list.count(); ii++ )
    {
        if ( playerId == m_list[ii].id )
        {
            // player found
            index = ii;
            break;
        }
    }

    return index;
}

