/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef PLAYERACTIONLIST_HH
#define PLAYERACTIONLIST_HH

// Own
/////////
#include "direction.hh"
#include "playeraction.hh"

// Qt
///////
#include <QList>

/// List of player actions.
/**
 * The list will contain player actions. It has the speciality
 * that adding an action with a player id that is already in it
 * will overwrite the previous action.
 */
class PlayerActionList
{
public:

    ////////////////////////////////
    // Constructor and Operators
    ////////////////////////////////

    /// Constructor
    PlayerActionList();
    
    ////////////////////////////////
    // Getting data
    ////////////////////////////////

    /// Return number of elements in list.
    int count();

    /// Check if player with id is in list.
    /**
     * @return true if player id was found
     */
    bool contains( const int playerId ) const;
    
    /// Get a copy of a player action.
    /**
     * Important: The index is NOT the player id. We will later
     * iterate over the list and then the order of the adding is
     * important.
     * @param action Action to overwrite
     * @param index Index in list, not player id.
     * @return true if action could be get
     */
    bool get( PlayerAction& action, const int index ) const;

    ////////////////////////////////
    // Setting data
    ////////////////////////////////
    
    /// Clears all actions in the list.
    void clear();

    /// Add new player action.
    /**
     * If the player id already exists in the list, we will overwrite
     * the old state. Further we will then move the action to the
     * end of the list.
     * @param playerId Id of player.
     * @param move Planned movement direction (may be NONE)
     * @param view View the look at (must not be NONE)
     * @return true if action could be added (or set)
     */
    bool add( const int playerId, const Direction move, const Direction view );

private:

    /// Find player id.
    /**
     * @return index of player id in list or -1 if not found
     */
    int find( const int playerId ) const;

    /// List of player actions.
    /**
     * The order of the list is important because later we will apply
     * the action by the first come first server principe.
     */
    QList<PlayerAction> m_list;
    
};

#endif // PLAYERACTIONLIST_HH
