<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>GameEngine</name>
    <message>
        <location filename="main.cpp" line="140"/>
        <source>Unknown option: </source>
        <translation>Unbekannte Option: </translation>
    </message>
    <message>
        <location filename="main.cpp" line="151"/>
        <source>Number of players must be set.</source>
        <translation>Anzahl Spieler muss gesetzt sein.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="163"/>
        <source>Could not extract number of players from </source>
        <translation>Konnte Spieleranzahl nicht extrahieren aus </translation>
    </message>
    <message>
        <location filename="main.cpp" line="171"/>
        <source>Number of players </source>
        <translation>Spieleranzahl </translation>
    </message>
    <message>
        <location filename="main.cpp" line="173"/>
        <source> must be positive.</source>
        <translation> muss positiv sein.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="185"/>
        <source>Map file must be set.</source>
        <translation>Kartendatei muss angegeben sein.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="195"/>
        <source>Filename for saving game data must be set.</source>
        <oldsource>Filename must be set if you want to save to file.</oldsource>
        <translation type="unfinished">Dateiname zum Speichern der Spieldaten muss angegeben sein.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="205"/>
        <source>Usage: </source>
        <translation>Aufruf: </translation>
    </message>
    <message>
        <location filename="main.cpp" line="205"/>
        <source> [OPTIONS]</source>
        <translation> [OPTIONEN]</translation>
    </message>
    <message>
        <location filename="main.cpp" line="206"/>
        <source>Starts the engine for the Right2Live-contest of freiesMagazin.</source>
        <translation>Startet die Engine für den Right2Live-Wettbewerb von freiesMagazin.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="208"/>
        <source>Possible options: </source>
        <translation>Mögliche Optionen: </translation>
    </message>
    <message>
        <location filename="main.cpp" line="209"/>
        <source>Load a map file for the game.</source>
        <translation>Lädt eine bestimmte Karte für das Spiel.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="210"/>
        <source>Wait for NUM players before the game starts.</source>
        <translation>Wartet auf NUM Spieler, ehe das Spiel beginnt.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="211"/>
        <source>NUM must be a positive integer.</source>
        <translation>NUM muss eine positive Zahl sein.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="212"/>
        <source>Save game process to file.</source>
        <translation>Speichere Spieldaten in Datei.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="213"/>
        <source>Wait for a key before each round.</source>
        <translation>Wartet vor einer neuen Runde auf Tasteneingabe.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="214"/>
        <source>Print informations during game.</source>
        <translation>Gibt während des Spiels Informationen aus.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="215"/>
        <source>Show this help text.</source>
        <translation>Zeigt diese Hilfe an.</translation>
    </message>
</context>
</TS>
