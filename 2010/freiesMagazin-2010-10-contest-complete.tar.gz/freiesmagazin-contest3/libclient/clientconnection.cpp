/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "clientconnection.hh"
#include "trace.hh"

// Qt
////////
#include <QString>
 
// Sys
////////
#include <iostream>

// Constructor
ClientConnection::ClientConnection()
: QTcpSocket()
{
    Trace::print( MTP_CLIENTCONNECTION, STP_CC_STRUCTOR,
                  "Client::Client Start" );

    // signal when data can be read from client
    if ( !connect( this, SIGNAL(readyRead()),
                   this, SLOT(slot_receiveData()) ) )
    {
        std::cerr << "(EE) ClientConnection::ClientConnection "
                  << " Socket " << this
                  << " Connect 1 not possible!"
                  << std::endl;
    }

    // check for errors
    if ( !connect( this, SIGNAL(error(QAbstractSocket::SocketError)),
                   this, SLOT(slot_displayError(QAbstractSocket::SocketError)) ) )
    {
        std::cerr << "(EE) ClientConnection::ClientConnection "
                  << " Socket " << this
                  << " Connect 2 not possible!"
                  << std::endl;
    }

    Trace::print( MTP_CLIENTCONNECTION, STP_CC_STRUCTOR,
                  "Client::Client End" );
}

// Destructor.
ClientConnection::~ClientConnection()
{
    Trace::print( MTP_CLIENTCONNECTION, STP_CC_STRUCTOR,
                  "ClientConnection::~ClientConnection Start" );

    // nothing to do


    Trace::print( MTP_CLIENTCONNECTION, STP_CC_STRUCTOR,
                  "ClientConnection::~ClientConnection End" );
}
    
// Send some data.
bool ClientConnection::send( const QString& data, const int msecs )
{
    Trace::print( MTP_CLIENTCONNECTION, STP_CC_SEND,
                  "ClientConnection::send Start " + data );

    bool ok = false;

    if ( isWritable() )
    {
        write( (data + "|").toLatin1() );
        
#ifdef QT_DEBUG
        std::cout << "(II) ClientConnection::send "
                  << " Socket " << this
                  << " Send \"" << data.toStdString() << "\"."
                  << std::endl;        
#endif

#ifdef QT_DEBUG
        std::cout << "(II) ClientConnection::send "
                  << " Socket " << this
                  << " Waiting for " << bytesToWrite()
                  << " Bytes to be written."
                  << std::endl;        
#endif        

        // wait until bytes has been written
        ok = waitForBytesWritten( msecs );
        
        if ( !ok )
        {
            // we could not send the data, but (!) maybe we have
            // send them before
            // so we check if there is still data in the buffer
            // that has not been sent
            if ( bytesToWrite() > 0 )
            {
                std::cerr << "(EE) ClientConnection::send "
                          << " Socket " << this
                          << ", " << bytesToWrite()
                          << " Bytes not sent!"
                          << std::endl;
            }
            else
            {
                ok = true;
            }
        }

#ifdef QT_DEBUG
        std::cout << "(II) ClientConnection::send "
                  << " Socket " << this
                  << " Bytes written: " << ok << "."
                  << std::endl;        
#endif
    }
    else
    {
        std::cerr << "(EE) ClientConnection::send "
                  << " Socket " << this
                  << " is not writeable."
                  << std::endl;        
    }

    Trace::print( MTP_CLIENTCONNECTION, STP_CC_SEND,
                  "ClientConnection::send End " + QString::number((int)ok) );
    
    return ok;
}

// Data can be read from the connection.
void ClientConnection::slot_receiveData()
{
    Trace::print( MTP_CLIENTCONNECTION, STP_CC_RECEIVE,
                  "ClientConnection::slot_receiveData Start " );

    if ( isReadable() )
    {
        const QString data = readAll();

#ifdef QT_DEBUG
        std::cout << "(II) ClientConnection::slot_receiveData "
                  << " Socket " << this
                  << " Received \"" << data.toStdString() << "\"."
                  << std::endl;
#endif

        // send signal that connects this connection
        // to the client to receive and process the data
        emit sig_receiveData( data );
    }
    else
    {
        std::cerr << "(EE) ClientConnection::slot_receiveData "
                  << " Socket " << this
                  << " is not readable."
                  << std::endl;        
    }

    Trace::print( MTP_CLIENTCONNECTION, STP_CC_RECEIVE,
                  "ClientConnection::slot_receiveData End " );
}

// an error occured in the client connection
void ClientConnection::slot_displayError( QAbstractSocket::SocketError socketError )
{
    Trace::print( MTP_CLIENTCONNECTION, STP_CC_ERROR,
                  "ClientConnection::slot_displayError Start " + QString::number((int)socketError) );

    // ignore closing of connections
    // ignore timeouts 
    if ( QAbstractSocket::RemoteHostClosedError != socketError &&
         QAbstractSocket::SocketTimeoutError    != socketError )
    {
        std::cerr << "(EE) ClientConnection::slot_displayError "
                  << " Socket " << this
                  << " Error " << socketError
                  << std::endl;
    }

    Trace::print( MTP_CLIENTCONNECTION, STP_CC_ERROR,
                  "ClientConnection::slot_displayError End " );
}

