/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "client.hh"
#include "clientconnection.hh"
#include "trace.hh"

// Sys
////////
#include <iostream>

// Constructor.
Client::Client()
: m_parser(), m_socket(0), m_disconnect(false)
{
    Trace::print( MTP_CLIENT, STP_CLIENT_STRUCTOR,
                  "Client::Client Start" );

    bool ok = false;

    // create new "empty" server connerction
    m_socket = new ClientConnection();

    if ( m_socket )
    {
#ifdef QT_DEBUG
        std::cout << "(II) Client::Client "
                  << " Client " << std::hex << this << std::dec
                  << " set connection " << std::hex << m_socket << std::dec
                  << std::endl;
#endif
        ok = true;

        // after a connection is established wait for the client id
        if ( !connect( m_socket, SIGNAL(connected()),
                       this, SIGNAL(sig_connected()) ) )
        {
            std::cerr << "(EE) Client::Client "
                      << " Client " << std::hex << this << std::dec
                      << " Connect 1 not possible!"
                      << std::endl;
            ok = false;
        }
        
        // signal when the connection is cancelled
        if ( !connect( m_socket, SIGNAL(disconnected()),
                       this, SIGNAL(sig_disconnected()) ) )
        {
            std::cerr << "(EE) Client::Client "
                      << " Client " << std::hex << this << std::dec
                      << " Connect 2 not possible!"
                      << std::endl;
            ok = false;
        }
        
        // signal when data can be read from client
        if ( !connect( m_socket, SIGNAL(sig_receiveData(const QString&)),
                       this, SLOT(slot_receiveData(const QString&)) ) )
        {
            std::cerr << "(EE) Client::Client "
                      << " Client " << std::hex << this << std::dec
                      << " Connect 3 not possible!"
                      << std::endl;
            ok = false;
        }

        // signal when data can be read from client
        if ( !connect( &m_parser, SIGNAL(sig_receivedCommand(const QString&)),
                       this, SIGNAL(sig_receivedCommand(const QString&)) ) )
        {
            std::cerr << "(EE) Client::Client "
                      << " Client " << std::hex << this << std::dec
                      << " Connect 4 not possible!"
                      << std::endl;
            ok = false;
        }
    }
    else
    {
        std::cerr << "(EE) Client::Client "
                  << " Client " << std::hex << this << std::dec
                  << " Connection is NULL!"
                  << std::endl;
    }

    Trace::print( MTP_CLIENT, STP_CLIENT_STRUCTOR,
                  "Client::Client End " + QString::number((int)ok) );
}

// Destructor
Client::~Client()
{
    Trace::print( MTP_CLIENT, STP_CLIENT_STRUCTOR,
                  "Client::~Client Start" );

    // stop connection to server, if not done before
    stopConnection();
    disconnect();
    
    Trace::print( MTP_CLIENT, STP_CLIENT_STRUCTOR,
                  "Client::~Client End" );
}

// Connect to a server.
bool Client::connectToServer( const QHostAddress address, const quint16 port,
                              const int msecs )
{
    Trace::print( MTP_CLIENT, STP_CLIENT_CONNECTION,
                  "Client::connectToServer Start" );

    bool ok = false;

    if ( verifyServerConnection() )
    {
        // connect to the server
        m_socket->connectToHost( address, port );

        // wait for a connection, for 3 seconds
        if ( !m_socket->waitForConnected( msecs ) )
        {
            // connection could not be established

            std::cerr << "(EE) Client::connectToServer "
                      << " Client " << std::hex << this << std::dec
                      << " cannot connect on "
                      << address.toString().toStdString()
                      << ":" << port
                      << " error: " << m_socket->error()
                      << std::endl;
        }
        else
        {
            // check if we are still connected
            if ( isConnected() )
            {
                // connection could be established
                ok = true;

#ifdef QT_DEBUG
                std::cout << "(II) Client::connectToServer "
                          << " Client " << std::hex << this << std::dec
                          << " is connected on "
                          << address.toString().toStdString()
                          << ":" << port << "."
                          << std::endl;
#endif
            }
            else
            {
                std::cerr << "(EE) Client::connectToServer "
                          << " Client " << std::hex << this << std::dec
                          << " tried to connect on "
                          << address.toString().toStdString()
                          << ":" << port
                          << " but failed somehow."
                          << std::endl;
            }
        }
    }

    Trace::print( MTP_CLIENT, STP_CLIENT_CONNECTION,
                  "Client::connectToServer End" );

    return ok;
}

// Check if the connection to a client is established.
bool Client::isConnected() const
{
    return ( ( 0 != m_socket) && ( QAbstractSocket::ConnectedState == m_socket->state() ) );
}

// Wait until server kills connection.
void Client::waitUntilDisconnected()
{
    Trace::print( MTP_CLIENT, STP_CLIENT_CONNECTION,
                  "Client::waitUntilDisconnected Start" );

    if ( verifyServerConnection() )
    {
        while ( !m_disconnect && isConnected() )
        {
            // wait until the server cancels the connection
            // we will wait only for 1 second and check
            // if we should quit the client.
            m_socket->waitForDisconnected(100);

#ifdef QT_DEBUG1
            std::cout << "Disconnect: "
                      << " Client " << std::hex << this << std::dec
                      << " Disconnect: " << m_disconnect
                      << std::endl;
#endif
        }
    }
    
    Trace::print( MTP_CLIENT, STP_CLIENT_CONNECTION,
                  "Client::waitUntilDisconnected End" );
}

// Wait until some data has been received.
bool Client::waitForData( const int msecs )
{
    Trace::print( MTP_CLIENT, STP_CLIENT_CONNECTION,
                  "Client::waitForData Start" );

    bool ok = false;

    if ( verifyServerConnection() )
    {
        ok = m_socket->waitForReadyRead(msecs);
    }

    Trace::print( MTP_CLIENT, STP_CLIENT_CONNECTION,
                  "Client::waitForData End " + QString::number((int)ok) );

    return ok;
}
    
// Verify if connection is accessible.
bool Client::verifyServerConnection() const
{
    Trace::print( MTP_CLIENT, STP_CLIENT_CONNECTION,
                  "Client::verifyServerConnection Start" );

    bool ok = false;
    
    // check pointer
    if ( m_socket )
    {
        ok = true;
    }
    else
    {
        std::cerr << "(EE) Client::verifyServerConnection "
                  << " Client " << std::hex << this << std::dec
                  << " Socket " << std::hex << m_socket << std::dec
                  << " Connection is NULL!"
                  << std::endl;
    }

    Trace::print( MTP_CLIENT, STP_CLIENT_CONNECTION,
                  "Client::verifyServerConnection End " + QString::number((int)ok) );

    return ok;
}

// Stop connection to the server.
bool Client::stopConnection()
{
    Trace::print( MTP_CLIENT, STP_CLIENT_CONNECTION,
                  "Client::stopConnection Start" );

    bool ok = false;

    if ( isConnected() )
    {
        m_socket->disconnectFromHost();

#ifdef QT_DEBUG
        std::cout << "(II) Client::stopConnection "
                  << " Client " << std::hex << this << std::dec
                  << " connection to server stopped."
                  << std::endl;
#endif
        ok = true;
    }
    /*
    else
    {
        std::cerr << "(EE) Client::stopConnection "
                  << " Client " << std::hex << this << std::dec
                  << " already disconnected."
                  << std::endl;
    }
    */
    // We do not want to print an error, if we are already disconnected
    // because that's the common case.
    
    // disconnect and quit
    m_disconnect = true;

    Trace::print( MTP_CLIENT, STP_CLIENT_CONNECTION,
                  "Client::stopConnection End " + QString::number((int)ok) );

    return ok;
}

// Reset all client data.
void Client::reset()
{
    Trace::print( MTP_CLIENT, STP_CLIENT_SET,
                  "Client::reset Start" );

    // From Qt manual:
    // The socket is created as a child of the server, which means
    // that it is automatically deleted when the QTcpServer object
    // is destroyed. It is still a good idea to delete the object
    // explicitly when you are done with it, to avoid wasting memory.

#ifdef QT_DEBUG
        std::cout << "(II) Client::reset "
                  << " Client " << std::hex << this << std::dec
                  << " connection " << m_socket
                  << " resetted."
                  << std::endl;
#endif

    if ( m_socket )
    {
        // close connection first
        m_socket->close();
        
        delete m_socket;
        m_socket = NULL;
    }

    // reset all data and delete waiting commands in the queue
    m_parser.resetAll();

    Trace::print( MTP_CLIENT, STP_CLIENT_SET,
                  "Client::reset End" );
}

// Data can be read from server connection.
void Client::slot_receiveData( const QString& data )
{
    Trace::print( MTP_CLIENT, STP_CLIENT_RECEIVE,
                  "Client::slot_receiveData Start " + data );

    if ( isConnected() )
    {
#ifdef QT_DEBUG
    std::cout << "(II) Client::slot_receiveData "
              << " Client " << std::hex << this << std::dec
              << " data \"" << data.toStdString() << "\""
              << std::endl;
#endif

        // give the data to the parser
        // so that it can be parsed and split
        // The index -1 tells that the data comes from the server.
        m_parser.separate( data, -1 );
   
        // process all waiting commands
        processCommandQueue();
    }
    
    Trace::print( MTP_CLIENT, STP_CLIENT_RECEIVE,
                  "Client::slot_receiveData End" );
}

// Process all commands in the process queue.
void Client::processCommandQueue()
{
    Trace::print( MTP_CLIENT, STP_CLIENT_PROCESS,
                  "Client::processCommandQueue Start" );

    // static flag that should hinder to mess up the order
    // of the commands
    static bool queueProcessed = false;
    
    // check if queue is processed yet
    // if so, we do not do anything yet and wait for later
    if ( !queueProcessed )
    {
        queueProcessed = true;
        
        ClientParserCommand nextCommand = CPC_NO_COMMAND;
        while ( !m_parser.isCommandQueueEmpty() )
        {
            // the data has been send to the queue
            // so we can process the queue here
            nextCommand = m_parser.processNextCommand();

            // process the command
            // that means depending on the command index
            // we will get the data form the parser and copy it
            // to the client.
            emit sig_processCommand( nextCommand );

            // reset parser data to get the next command
            // even if the command could not be handled
            // correctly
            m_parser.reset();
        }

        queueProcessed = false;
    }
    
    Trace::print( MTP_CLIENT, STP_CLIENT_PROCESS,
                  "Client::processCommandQueue End" );
}
    
// Send some data to a client.
bool Client::send( const QString& data, const int msecs )
{
    Trace::print( MTP_CLIENT, STP_CLIENT_SEND,
                  "Client::send Start " + data );

    bool ok = false;

    if ( isConnected() )
    {
        ok = m_socket->send( data+'|', msecs );
    }
#ifdef QT_DEBUG
    else
    {
        std::cerr << "(EE) Client::send "
                  << " Client " << std::hex << this << std::dec
                  << " no connection " << m_socket
                  << std::endl;        
    }
#endif

    Trace::print( MTP_CLIENT, STP_CLIENT_SEND,
                  "Client::send End" );

    return ok;
}
