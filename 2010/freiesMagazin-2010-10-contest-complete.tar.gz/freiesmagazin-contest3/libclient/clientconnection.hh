/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef CLIENTCONNECTION_HH
#define CLIENTCONNECTION_HH

// Qt
////////
#include <QObject>
#include <QAbstractSocket>
#include <QTcpSocket>

// Forward declarations
///////////////////////////
class QString;

/// Client connection.
/**
 * This class represents a connection to a client.
 * It will receive all data and forward it to the client.
*/
class ClientConnection : public QTcpSocket
{
Q_OBJECT
    
public:
    /// Constructor.
    /**
     * Connects all signals and slots.
     */
    ClientConnection();

    /// Destructor.
    ~ClientConnection();

    /// Send some data to the TCP connection.
    /**
     * The data is send to the TCP socket. We will wait
     * 1 second till the data ist sent.
     * @param data to sent
     * @param msec time till timeout
     * @return true if data has been sent
     */
    bool send( const QString& data, const int msecs = 1000  );

signals:
    /// Signal when new data has been received.
    /**
     * The signal is given if new data has been received
     * and already read from the socket.
     * @param data received data
     */
    void sig_receiveData( const QString& data );

private slots:
    /// Data can be read from a client connection.
    /**
     * The client has received some data that can be read
     * from the TCP socket.
     */
    void slot_receiveData();
    
    /// An error occured in the client connection.
    /**
     * If an error occurred in the connection this method is called.
     * If the client has only closed the connection no error will
     * be printed.
     * @param socketError error id
     */
    void slot_displayError( QAbstractSocket::SocketError socketError );

private:

    /// Copy constructor.
    /**
     * This is not implemented because we do not want to copy it.
     */
    ClientConnection( const ClientConnection& socket );

    /// Assignment operator.
    /**
     * This is not implemented because we do not want to copy it.
     */
    ClientConnection& operator=( const ClientConnection& socket );
};

#endif // CLIENTCONNECTION_HH
