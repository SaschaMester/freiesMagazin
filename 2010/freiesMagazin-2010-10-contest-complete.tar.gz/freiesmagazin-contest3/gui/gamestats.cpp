/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
/////////
#include "gamestats.hh"
#include "gamemap.hh"
#include "playerlist.hh"
#include "player.hh"
#include "trace.hh"

// Qt
////////
#include <QLabel>
#include <QGridLayout>

// Sys
/////////
#include <iostream>

// Constructor.
GameStats::GameStats()
: QWidget(), m_map(0), m_players(0)
{
    // create new layout
    QVBoxLayout *layout = new QVBoxLayout();

    m_labelRound = new QLabel( tr("Round: ") + tr("not running") );
    layout->addWidget( m_labelRound );

    // create grid layout
    m_layout = new QGridLayout();
    layout->addLayout( m_layout );

    // set layout for the widget
    setLayout( layout );
}

// Destructor.
GameStats::~GameStats()
{
    // do not delete references
    m_map = 0;
    m_players = 0;
}

// Clear all stored data.
void GameStats::clear()
{
    // remove all widgets from layout
    for ( int ii = 0; ii < m_widgetList.count(); ii++ )
    {
        for ( int jj = 0; jj < m_widgetList[ii].count(); jj++ )
        {
            if ( m_layout )
            {
                m_layout->removeWidget( m_widgetList[ii][jj] );
                delete m_widgetList[ii][jj];
                m_widgetList[ii][jj] = 0;
            }
        }
    }
    m_widgetList.clear();
}

// Create table for showing layout.
void GameStats::createTable()
{
    if ( m_layout )
    {
        QLabel *labelPlayer   = new QLabel( tr("Id") );
        QLabel *labelTeam     = new QLabel( tr("Team") );
        QLabel *labelPosition = new QLabel( tr("Pos") );
        QLabel *labelView     = new QLabel( tr("View") );
        QLabel *labelLife     = new QLabel( tr("Life") );

        QPoint pos;
        pos = convertToPos(0,0);
        m_layout->addWidget( labelPlayer,   pos.x(), pos.y(), Qt::AlignLeft | Qt::AlignTop );
        pos = convertToPos(0,1);
        m_layout->addWidget( labelTeam,     pos.x(), pos.y(), Qt::AlignLeft | Qt::AlignTop );
        pos = convertToPos(0,2);
        m_layout->addWidget( labelPosition, pos.x(), pos.y(), Qt::AlignLeft | Qt::AlignTop );
        pos = convertToPos(0,3);
        m_layout->addWidget( labelView,     pos.x(), pos.y(), Qt::AlignLeft | Qt::AlignTop );
        pos = convertToPos(0,4);
        m_layout->addWidget( labelLife,     pos.x(), pos.y(), Qt::AlignLeft | Qt::AlignTop );

        // set stretch for last row and columns to a very high number
        m_layout->setRowStretch( pos.x(), 1000 );
        m_layout->setColumnStretch( pos.y(), 1000 );
    }
}

// Update the shown data.
void GameStats::update( const int round )
{
    if ( m_labelRound )
    {
        if ( round > 0 )
        {
            m_labelRound->setText( tr("Round: ") + QString::number(round) );
        }
        else
        {
            m_labelRound->setText( tr("Round: ") + tr("not running") );
        }
    }

    if ( m_players )
    {
        QPoint pos;

        // get list of player ids
        const QList<int> idList = m_players->getListOfIds();

        // check if the layout has enough room for all players
        if ( m_widgetList.count() < idList.count() )
        {
            // we do not have enough room, so we must add some more widgets
            for ( int ii = m_widgetList.count(); ii < idList.count(); ii++ )
            {
                QLabel *labelPlayer   = new QLabel( "-1" );
                QLabel *labelTeam     = new QLabel( tr("blue") );
                QLabel *labelPosition = new QLabel( "(-1,-1)" );
                QLabel *labelView     = new QLabel( "NW" );
                QLabel *labelLife     = new QLabel( "100.00" );

                pos = convertToPos(ii+1,0);
                m_layout->addWidget( labelPlayer,   pos.x(), pos.y(), Qt::AlignLeft | Qt::AlignTop );
                pos = convertToPos(ii+1,1);
                m_layout->addWidget( labelTeam,     pos.x(), pos.y(), Qt::AlignLeft | Qt::AlignTop );
                pos = convertToPos(ii+1,2);
                m_layout->addWidget( labelPosition, pos.x(), pos.y(), Qt::AlignLeft | Qt::AlignTop );
                pos = convertToPos(ii+1,3);
                m_layout->addWidget( labelView,     pos.x(), pos.y(), Qt::AlignLeft | Qt::AlignTop );
                pos = convertToPos(ii+1,4);
                m_layout->addWidget( labelLife,     pos.x(), pos.y(), Qt::AlignLeft | Qt::AlignTop );

                m_layout->setColumnStretch(ii+1,0);
                m_layout->setRowStretch(ii+1,0);

                // store widgets in list
                QList<QLabel*> playerStats;
                playerStats.append( labelPlayer );
                playerStats.append( labelTeam );
                playerStats.append( labelPosition );
                playerStats.append( labelView );
                playerStats.append( labelLife );
                m_widgetList.append( playerStats );
            }
        }

        // now update every widget
        for ( int ii = 0; ii < idList.count(); ii++ )
        {
            pos = m_players->getPosition( idList[ii] );

            // player id
            m_widgetList[ii][0]->setText( QString::number( idList[ii] ) );

            // team
            if ( TEAM_BLUE == m_players->getTeam( idList[ii] ) )
            {
                m_widgetList[ii][1]->setText( tr("blue") );
            }
            else if ( TEAM_RED == m_players->getTeam( idList[ii] ) )
            {
                m_widgetList[ii][1]->setText( tr("red") );
            }
            else
            {
                m_widgetList[ii][1]->setText( tr("unknown") );
            }

            // position
            m_widgetList[ii][2]->setText( "(" + QString::number( pos.x() ) + "," +
                                         QString::number( pos.y() ) + ")" );

            // view
            m_widgetList[ii][3]->setText( Player::toShortString( m_players->getView( idList[ii] ) ) );

            // life
            m_widgetList[ii][4]->setText( QString::number( m_players->getLife( idList[ii] ),'f',2 ) );

            // if player is invalid we will disable everything
            // If the game has not started yet we will disable it too
            if ( round > 0 && !m_players->isInvalid( idList[ii] ) )
            {
                m_widgetList[ii][0]->setEnabled(true);
                m_widgetList[ii][1]->setEnabled(true);
                m_widgetList[ii][2]->setEnabled(true);
                m_widgetList[ii][3]->setEnabled(true);
                m_widgetList[ii][4]->setEnabled(true);
            }
            else
            {
                m_widgetList[ii][0]->setEnabled(false);
                m_widgetList[ii][1]->setEnabled(false);
                m_widgetList[ii][2]->setEnabled(false);
                m_widgetList[ii][3]->setEnabled(false);
                m_widgetList[ii][4]->setEnabled(false);
            }
        }

        // set stretch for last row and columns to a very high number
        // the rest is 0
        for ( int ii = 0; ii < idList.count()+1; ii++ )
        {
            pos = convertToPos(ii,0);
            m_layout->setRowStretch( pos.x(), 0 );
            m_layout->setColumnStretch( pos.y(), 0 );
            pos = convertToPos(ii,1);
            m_layout->setRowStretch( pos.x(), 0 );
            m_layout->setColumnStretch( pos.y(), 0 );
            pos = convertToPos(ii,2);
            m_layout->setRowStretch( pos.x(), 0 );
            m_layout->setColumnStretch( pos.y(), 0 );
            pos = convertToPos(ii,3);
            m_layout->setRowStretch( pos.x(), 0 );
            m_layout->setColumnStretch( pos.y(), 0 );
            pos = convertToPos(ii,4);
            m_layout->setRowStretch( pos.x(), 0 );
            m_layout->setColumnStretch( pos.y(), 0 );
        }

        pos = convertToPos(idList.count()+1,4);
        m_layout->setRowStretch( pos.x(), 1000 );
        m_layout->setColumnStretch( pos.y(), 1000 );
    }
}
