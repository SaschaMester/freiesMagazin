/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
/////////
#include "gamestatsvertical.hh"

// Constructor.
GameStatsVertical::GameStatsVertical()
: GameStats()
{
}

// Destructor.
GameStatsVertical::~GameStatsVertical()
{
    // nothing to do
}

// Convert given data to a position for using it in a grid layout.
QPoint GameStatsVertical::convertToPos( const int id, const int object ) const
{
    return QPoint(id, object);
}

