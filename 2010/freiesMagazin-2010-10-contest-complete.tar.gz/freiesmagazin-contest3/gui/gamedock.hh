/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef GAMEDOCK_HH
#define GAMEDOCK_HH

// Qt
////////
#include <QDockWidget>

// Forward declarations
/////////////////////////
class GameStatsHorizontal;
class GameStatsVertical;
class PlayerList;
class GameMap;

/// Game dock widget.
/**
 * The dock widget contains the game statistic widget and can
 * be set to any border on the frame depending where it best
 * matches. Of course it can be closed or be kept floating.
 */
class GameDock : public QDockWidget
 {
     Q_OBJECT

public:

    /// Constructor.
    GameDock( const QString &title, QWidget* parent );

    /// Destructor.
    ~GameDock();

    /// Bind game map to area.
    void setMap( const GameMap* map );

    /// Bind players to area.
    void setPlayers( const PlayerList* players );

    /// Update statistic window.
    /**
     * @param round Current round to display.
     */
    void updateStats( const int round );

    /// Clear all stored data.
    void clear();
    
private slots:

    /// Slot when dock location has changed.
    void slot_dockLocationChanged( Qt::DockWidgetArea area );

private:

    /// game statistics for showing inside dock area at top and bottom.
    GameStatsHorizontal *m_gameStatsH;

    /// game statistics for showing inside dock area at left and right.
    GameStatsVertical *m_gameStatsV;

};

#endif // GAMEDOCK_HH
