/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef GAMESTATS_HH
#define GAMESTATS_HH

// Qt
////////
#include <QWidget>
#include <QList>
#include <QGridLayout>
#include <QPoint>

// Forward declarations
/////////////////////////
class PlayerList;
class GameMap;
class QLabel;

/// Game statistic widget
/**
 * Widget for showing the game statitics. This is usually
 * embedded into a dock widget.
 */
class GameStats : public QWidget
{
    Q_OBJECT
    
public:

    /// Constructor.
    GameStats();

    /// Destructor.
    ~GameStats();

    /// Bind game map to area.
    void setMap( const GameMap* map ) { m_map = map; }

    /// Bind players to area.
    void setPlayers( const PlayerList* players ) { m_players = players; }

    /// Update the shown data.
    /**
     * @param round Current round to display.
     */
    void update( const int round );

    /// Create table for showing stats in.
    void createTable();

    /// Clear all stored data.
    void clear();
    
private:

    /// Convert given data to a position for using it in a grid layout.
    /**
     * This method must be implemented by derived classes.
     * Depending if the layout is horizontal or vertical the
     * result should be QPoint(id,object) or
     * QPoint(object,id).
     */
    virtual QPoint convertToPos( const int id, const int object ) const = 0;

private:

    /// Reference to the game map, that was loaded outside.
    const GameMap* m_map;

    /// Reference to the list of players, that are connect to the game.
    const PlayerList* m_players;

    /// List of widgets added in the layout.
    /**
     * The list is important if we want to adress the correct widget
     * to change the informations in it. The first list parameter
     * is the player number, the second the option like id, team etc.
     */
    QList< QList< QLabel* > > m_widgetList;

    /// Layout of the widget.
    QGridLayout* m_layout;

    /// Label for showing the round number.
    QLabel *m_labelRound;

};

#endif // GAMESTATS_HH
