/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef GAMESTATSHORIZONTAL_HH
#define GAMESTATSHORIZONTAL_HH

// Own
////////
#include "gamestats.hh"

// Qt
///////
#include <QPoint>

/// Game statistic widget for horizontal display.
/**
 * Widget for showing the game statitics. This is usually
 * embedded into a dock widget.
 */
class GameStatsHorizontal : public GameStats
 {
public:

    /// Constructor.
    GameStatsHorizontal();

    /// Destructor.
    ~GameStatsHorizontal();

private:

    /// Convert given data to a position for using it in a grid layout.
    /**
     * This method must be implemented by derived classes.
     * Depending if the layout is horizontal or vertical the
     * result should be QPoint(id,object) or
     * QPoint(object,id).
     */
    virtual QPoint convertToPos( const int id, const int object ) const;


};

#endif // GAMESTATSHORIZONTAL_HH
