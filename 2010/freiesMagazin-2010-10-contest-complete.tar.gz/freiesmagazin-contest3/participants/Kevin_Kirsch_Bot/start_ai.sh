#!/bin/bash
java -cp bin de.starletp9.freiesMagazin.wettbewerb3.ConnectionManager

