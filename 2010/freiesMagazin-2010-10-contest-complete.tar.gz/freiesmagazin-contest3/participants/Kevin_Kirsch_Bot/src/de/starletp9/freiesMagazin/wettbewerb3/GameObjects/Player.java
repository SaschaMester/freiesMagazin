/*
 * 
 * Copyright (C) 2010 Kevin Kirsch
 * 
 * This file is part of a bot.
 * 
 * This bot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This bot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this bot.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.starletp9.freiesMagazin.wettbewerb3.GameObjects;

import de.starletp9.freiesMagazin.wettbewerb3.Constants;
import de.starletp9.freiesMagazin.wettbewerb3.GameObject;

public class Player extends GameObject {
	public int getType() {
		return Constants.Player;
	}

	public int id = -1;

	public int x = -1;

	public int y = -1;

	/*
	 * Angegeben wie beim Numpad:
	 *  7 8 9
	 *  4 5 6
	 *  1 2 3
	 */
	public int dir = -1;

	public boolean zombie = false;;

	public double life = 100;
}
