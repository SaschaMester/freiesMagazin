/*
 * 
 * Copyright (C) 2010 Kevin Kirsch
 * 
 * This file is part of a bot.
 * 
 * This bot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This bot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this bot.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.starletp9.freiesMagazin.wettbewerb3;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class ConnectionManager {
	private static int debugLevel = 0;

	public static int getDebugLevel() {
		return debugLevel;
	}

	private Socket socket;

	private Scanner in;

	private PrintWriter out;

	private Map map = new Map();

	private KI ki = new KI(this);

	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException {
		ConnectionManager cm = new ConnectionManager();
		cm.connect("localhost", 15000);
		cm.inputLoop();
	}

	public void connect(String host, int port) throws IOException {
		socket = new Socket(host, port);
		out = new PrintWriter(socket.getOutputStream());
		in = new Scanner(socket.getInputStream());
		in.useDelimiter("\\|");
	}

	public void inputLoop() throws IOException {
		while (true) {
			String input = in.next();
			if (debugLevel > 900)
				System.out.println("Server: " + input);
			if (input.equals("PING")) {
				// Das kommt SEHR SEHR SEHR oft und MUSS ignoriert werden, aber trotzdem sollte ich es
				// überprüfen, damit mein Bot nicht für jeden Ping die anderen equals-Dinger prüfen muss.
			} else {
				if (debugLevel <= 900 && debugLevel > 100) {
					System.out.println("Server: " + input);
				}
				String[] inputs = input.split(" ");
				if (inputs[0].equals("ID")) {
					try {
						int id = Integer.parseInt(inputs[1]);
						ki.setOwnId(id);
						write("ID_OKAY");
					} catch (NumberFormatException e) {
						write("ID_NOT_OKAY");
					}
				} else if (inputs[0].equals("CONNECTED")) {
					map.playerJoined(Integer.parseInt(inputs[1]));
				} else if (inputs[0].equals("DISCONNECTED")) {
					map.playerLeft(Integer.parseInt(inputs[1]));
				} else if (inputs[0].equals("DISCONNECT")) {
					socket.close();
					System.exit(0);
				} else if (inputs[0].equals("SEE_PLAYER")) {
					String[] pos = inputs[1].split(",");
					String direction = inputs[2];
					String player = inputs[3];
					map.playerSeen(Integer.parseInt(player), Integer.parseInt(pos[0]), Integer.parseInt(pos[1]), dirString2Int(direction));
				} else if (inputs[0].equals("SET")) {
					String[] pos = inputs[1].split(",");
					String direction = inputs[2];
					ki.setPosition(Integer.parseInt(pos[0]), Integer.parseInt(pos[1]), dirString2Int(direction));
				} else if (inputs[0].equals("SEE_KEY")) {
					String[] pos = inputs[1].split(",");
					map.keySeen(inputs[2], Integer.parseInt(pos[0]), Integer.parseInt(pos[1]));
				} else if (inputs[0].equals("GET_KEY")) {
					ki.gotKey(inputs[1]);
				} else if (inputs[0].equals("TOXIC")) {
					String[] pos = inputs[1].split(",");
					map.toxic(Integer.parseInt(pos[0]), Integer.parseInt(pos[1]), Double.parseDouble(inputs[2]));
				} else if (inputs[0].equals("LIFE")) {
					double life = Double.parseDouble(inputs[1]);
					int player = Integer.parseInt(inputs[2]);
					if (player == ki.getId()) {
						ki.setLife(life);
					} else {
						map.life(player, life);
					}
				} else if (inputs[0].equals("TEAMCHANGE")) {
					boolean zombie = false;
					if (inputs[1].equals("RED"))
						zombie = true;
					int player = Integer.parseInt(inputs[2]);
					if (player == ki.getId()) {
						ki.setZombie(zombie);
					} else {
						map.zombie(player, zombie);
					}
				} else if (inputs[0].equals("START"))
					ki.doRound(map);
				else if (inputs[0].equals("MAP"))
					map.load(inputs[1]);
				else if (debugLevel > 0)
					System.out.println("Unverarbeitete Zeile!!!");
			}
		}
	}

	private void write(String s) {
		if (debugLevel > 100)
			System.out.println("Bot: " + s);
		out.write(s + "|");
		out.flush();
	}

	public static int dirString2Int(String dir) {
		if (dir.equals("NORTH"))
			return 8;
		else if (dir.equals("NORTH_EAST"))
			return 9;
		else if (dir.equals("EAST"))
			return 6;
		else if (dir.equals("SOUTH_EAST"))
			return 3;
		else if (dir.equals("SOUTH"))
			return 2;
		else if (dir.equals("SOUTH_WEST"))
			return 1;
		else if (dir.equals("WEST"))
			return 4;
		else if (dir.equals("NORTH_WEST"))
			return 7;
		else
			return 5;
	}

	public static String dirInt2String(int dir) {
		if (dir == 8)
			return "NORTH";
		else if (dir == 9)
			return "NORTH_EAST";
		else if (dir == 6)
			return "EAST";
		else if (dir == 3)
			return "SOUTH_EAST";
		else if (dir == 2)
			return "SOUTH";
		else if (dir == 1)
			return "SOUTH_WEST";
		else if (dir == 4)
			return "WEST";
		else if (dir == 7)
			return "NORTH_WEST";
		else
			return "NONE";
	}

	public void move(int dir, int view) {
		move(dirInt2String(dir), dirInt2String(view));
	}

	public void move(String dir, String view) {
		write("MOVE " + dir + " " + view);
	}
}
