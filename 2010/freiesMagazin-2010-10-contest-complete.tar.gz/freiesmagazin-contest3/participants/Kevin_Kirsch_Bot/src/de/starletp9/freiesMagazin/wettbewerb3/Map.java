/*
 * 
 * Copyright (C) 2010 Kevin Kirsch
 * 
 * This file is part of a bot.
 * 
 * This bot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This bot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this bot.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.starletp9.freiesMagazin.wettbewerb3;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;

import de.starletp9.freiesMagazin.wettbewerb3.GameObjects.Door;
import de.starletp9.freiesMagazin.wettbewerb3.GameObjects.Key;
import de.starletp9.freiesMagazin.wettbewerb3.GameObjects.Player;
import de.starletp9.freiesMagazin.wettbewerb3.GameObjects.Wall;

public class Map {
	private Field[][] map;

	private ArrayList<Player> players = new ArrayList<Player>();

	private ArrayList<Key> keys = new ArrayList<Key>();

	public void playerJoined(int id) {
		Player p = new Player();
		p.id = id;
		players.add(p);
	}

	public void playerLeft(int id) {
		Player p = getPlayerById(id);
		if (p != null && p.x > -1 && p.y > -1) {
			map[p.x][p.y].remove(p);
			players.remove(p);
		}
	}

	public void playerSeen(int id, int x, int y, int dir) {
		Player p = getPlayerById(id);
		if (p != null) {
			if (p.x > -1 && p.y > -1) {
				map[p.x][p.y].remove(p);
			}
			p.x = x;
			p.y = y;
			p.dir = dir;
			map[p.x][p.y].add(p);
		}
	}

	public void keySeen(String id, int x, int y) {
		Field f = map[x][y];
		boolean knownKey = false;
		for (GameObject gameObject : f) {
			if (gameObject.getType() == Constants.Key)
				if (((Key) gameObject).id.equals(id))
					knownKey = true;
		}
		if (!knownKey) {
			Key k = new Key(id);
			k.x = x;
			k.y = y;
			f.add(k);
			keys.add(k);
		}
	}

	public void toxic(int x, int y, double value) {
		map[x][y].setToxic(value);
	}

	public void life(int id, double life) {
		getPlayerById(id).life = life;
	}

	public void zombie(int id, boolean zombie) {
		getPlayerById(id).zombie = zombie;
	}

	public void load(String s) throws IOException {
		char raute = "#".toCharArray()[0];
		RandomAccessFile raf = new RandomAccessFile(new File(s), "r");
		int xSize = raf.readLine().length();
		int ySize = (int) (raf.length() / (xSize + 1));
		map = new Field[xSize][ySize];
		for (int i = 0; i < ySize; i++) {
			raf.seek((xSize + 1) * i); // Wegen Zeilenumbrüchen
			for (int j = 0; j < xSize; j++) {
				Field f = new Field();
				map[j][i] = f;
				char c = (char) raf.readByte();
				if (Character.isWhitespace(c)) {
					// Leeres Feld, nix zu Tun
				} else if (c == raute) {
					f.add(new Wall());
				} else if (Character.isUpperCase(c)) {
					f.add(new Door(Character.toString(c)));
				} else if (Character.isLowerCase(c)) {
					// huch? die Schlüssel sollte ich doch eigentlich nicht bekommen, oder Leute?
					f.add(new Key(Character.toString(c)));
				} else if (ConnectionManager.getDebugLevel() > 0)
					System.out.println("Unbekanntes Zeichen in der Map: '" + Character.toString(c) + "'");
			}
		}
		if (ConnectionManager.getDebugLevel() > 890)
			dumpMap(null);
		raf.close();
	}

	public Player getPlayerById(int id) {
		for (Player p : players) {
			if (p.id == id)
				return p;
		}
		return null;
	}

	public void dumpMap(KI ki) {
		System.out.println("Mapdump:");
		for (int j = 0; j < map[0].length; j++) {
			for (int i = 0; i < map.length; i++) {
				if (ki != null && ki.getX() == i && ki.getY() == j) {
					System.out.print("!");
				} else {
					Field feld = map[i][j];
					if (feld.size() > 0)
						if (feld.get(0).getType() == Constants.Wall)
							System.out.print("#");
						else if (feld.get(0).getType() == Constants.Door)
							System.out.print(((Door) map[i][j].get(0)).id);
						else if (feld.get(0).getType() == Constants.Key)
							System.out.print(((Key) map[i][j].get(0)).id);
						else if (feld.get(0).getType() == Constants.Player)
							System.out.print(((Player) map[i][j].get(0)).id);
						else
							System.out.print("+"); // Unbekanntes Objekt
					else
						System.out.print(" ");
				}
			}
			System.out.println();
		}
	}

	public ArrayList<Player> getAllPlayers() {
		return players;
	}

	public Field getField(int x, int y) {
		return map[x][y];
	}

	public void rateFieldsICanNotWalkOn(KI ki) {
		for (int j = 0; j < map[0].length; j++)
			for (int i = 0; i < map.length; i++) {
				boolean isWalkable = true;
				Field f = map[i][j];
				for (int k = 0; k < f.size(); k++) {
					GameObject go = f.get(k);
					if (go.getType() == Constants.Wall)
						isWalkable = false;
					else if (go.getType() == Constants.Door && !ki.haveKey(((Door) go).id.toLowerCase()))
						isWalkable = false;
					else if (go.getType() == Constants.Player)
						isWalkable = false;
				}
				if (!isWalkable)
					f.setRating(-1000);
			}
	}

	public void rateBadField(int x, int y, int rating) {
		if (x >= 0 && y >= 0 && x < map.length && y < map[0].length) {
			Field f = map[x][y];
			if (f.getRating() < 0 || f.getRating() > rating) {
				boolean isWalkable = true;
				for (int i = 0; i < f.size(); i++) {
					GameObject go = f.get(i);
					if (go.getType() == Constants.Wall)
						isWalkable = false;
				}
				if (isWalkable) {
					f.setRating(rating);

					rateBadField(x + 1, y, rating + 1);
					// rateZombieField(x + 1, y + 1, rating + 1); //Diagonal rennen geht nicht
					rateBadField(x, y + 1, rating + 1);
					// rateZombieField(x - 1, y + 1, rating + 1); //Diagonal rennen geht nicht
					rateBadField(x - 1, y, rating + 1);
					// rateZombieField(x - 1, y - 1, rating + 1); //Diagonal rennen geht nicht
					rateBadField(x, y - 1, rating + 1);
					// rateZombieField(x + 1, y - 1, rating + 1); //Diagonal rennen geht nicht
				} else
					f.setRating(-1000); // Hier kann man nicht hingehen, daher ist es eine ganz schlechte Idee
				// es zu versuchen
			}
		}
	}

	public void rateGoodField(int x, int y, int rating, KI ki) {
		if (x >= 0 && y >= 0 && x < map.length && y < map[0].length && rating > 0) {
			Field f = map[x][y];
			if (f.getRating() < rating) {
				boolean isWalkable = true;
				for (int i = 0; i < f.size(); i++) {
					GameObject go = f.get(i);
					if (go.getType() == Constants.Wall)
						isWalkable = false;
					else if (go.getType() == Constants.Door && !ki.haveKey(((Door) go).id.toLowerCase())) {
						isWalkable = false;
						if (ConnectionManager.getDebugLevel() > 10000) {
							System.out.println("Verschlossene Tür " + ((Door) go).id + "erkannt");
						}
					}
				}
				if (isWalkable) {
					f.setRating(rating);

					rateGoodField(x + 1, y, rating - 1, ki);
					// rateZombieField(x + 1, y + 1, rating + 1); //Diagonal rennen geht nicht
					rateGoodField(x, y + 1, rating - 1, ki);
					// rateZombieField(x - 1, y + 1, rating + 1); //Diagonal rennen geht nicht
					rateGoodField(x - 1, y, rating - 1, ki);
					// rateZombieField(x - 1, y - 1, rating + 1); //Diagonal rennen geht nicht
					rateGoodField(x, y - 1, rating - 1, ki);
					// rateZombieField(x + 1, y - 1, rating + 1); //Diagonal rennen geht nicht
				} else
					f.setRating(-1000); // Hier kann man nicht hingehen, daher ist es eine ganz schlechte Idee
				// es zu versuchen
			}
		}
	}

	public void resetRating() {
		for (int j = 0; j < map[0].length; j++)
			for (int i = 0; i < map.length; i++)
				map[i][j].setRating(-100);
	}

	public int getRating(int x, int y) {
		if (x >= 0 && y >= 0 && x < map.length && y < map[0].length)
			return map[x][y].getRating();
		else
			return -1000; // Das Feld gibt es nicht, dahin ziehen ist eine ganz schlechte Idee
	}

	public ArrayList<Key> getAllKeys() {
		return keys;
	}
}
