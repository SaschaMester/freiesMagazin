/*
 * 
 * Copyright (C) 2010 Kevin Kirsch
 * 
 * This file is part of a bot.
 * 
 * This bot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This bot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this bot.  If not, see <http://www.gnu.org/licenses/>.
 */

package de.starletp9.freiesMagazin.wettbewerb3;

import java.util.ArrayList;

import de.starletp9.freiesMagazin.wettbewerb3.GameObjects.Key;
import de.starletp9.freiesMagazin.wettbewerb3.GameObjects.Player;

public class KI {
	private int id;

	private double life = 100;

	private boolean zombie = false;

	private int x;

	private int y;

	private int xold = 1;

	private int yold = 1;

	private int dir;

	private ConnectionManager cm;

	private ArrayList<String> keys = new ArrayList<String>();

	public KI(ConnectionManager cm) {
		this.cm = cm;
	}

	public void setPosition(int x, int y, int dir) {
		this.x = x;
		this.y = y;
		this.dir = dir;
	}

	public boolean haveKey(String id) {
		boolean haveKey = false;
		for (String key : keys)
			if (id.equals(key))
				haveKey = true;
		return haveKey;
	}

	public void gotKey(String id) {
		if (!haveKey(id))
			keys.add(id);
	}

	public void setOwnId(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setLife(double life) {
		this.life = life;
	}

	public void setZombie(boolean zombie) {
		this.zombie = zombie;
	}

	/*
	 * Die eigentliche KI-Funktion: Zuerst wird jedem Feld der Karte den Wert 100 zugewiesen, dann
	 * wird den Feldern eine Wertigkeit zugewiesen (nähe zu Gegnern/Schlüsseln) und am Ende ziehen wir
	 * in die Richtung des Feldes mit dem höchsten Wert.
	 */
	public void doRound(Map map) {
		if (life < map.getField(x, y).getToxic() * 2) // Wir sind so gut wie im Team rot, da können wir
			zombie = true; // schonmal zu den blauen Spielern gehen…
		map.resetRating();
		ArrayList<Player> players = map.getAllPlayers();
		for (Player player : players) {
			if (zombie == false && player.zombie == true) {
				map.rateBadField(player.x, player.y, 0);
			} else if (zombie == true && player.zombie == false) {
				map.rateGoodField(player.x, player.y, 2000, this);
			}
		}
		Field oldField = map.getField(xold, yold);
		oldField.setRating(oldField.getRating() - 5); // Das Feld, wo wir gerade herkommen wird
		// runtergewichtet, damit wir nicht ganz so viel im
		// Kreis rennen
		map.rateFieldsICanNotWalkOn(this);
		int[] result = getWalkingDirection(map);
		int highestRating = result[0];
		int highestWalkingDirection = result[1];
		if (!zombie) {
			if (highestRating < -90) { // Der Bot hat nix besseres zu tun
				rateKeys(map, 2000); // -> kann er sich ganz auf die Schlüssel konzentrieren
				result = getWalkingDirection(map);
				highestRating = result[0];
				highestWalkingDirection = result[1];
			} else if (highestRating > 20) { // alle Gefahren sind weit weg,
				rateKeys(map, highestRating - 5); // Schlüssel suchen ist ok
				result = getWalkingDirection(map);
				highestRating = result[0];
				highestWalkingDirection = result[1];
			}
		} else {
			if(highestRating < 1980)
			rateKeys(map, 2000 - highestRating); // Schlüssel suchen ist ok
			result = getWalkingDirection(map);
			highestRating = result[0];
			highestWalkingDirection = result[1];
		}
		int lookingDirection = 0; // Der Bot dreht sich ständig, damit er möglichst viele Gegner sieht.
		switch (dir) {
			case 1:
				lookingDirection = 8;
				break;
			case 2:
				lookingDirection = 7;
				break;
			case 3:
				lookingDirection = 4;
				break;
			case 6:
				lookingDirection = 1;
				break;
			case 9:
				lookingDirection = 2;
				break;
			case 8:
				lookingDirection = 3;
				break;
			case 7:
				lookingDirection = 6;
				break;
			case 4:
				lookingDirection = 9;
				break;
		}
		if (ConnectionManager.getDebugLevel() > 700) {
			map.dumpMap(this);
			System.out.println("Spieler:");
			for (Player player : players) {
				System.out.println("Player " + player.id + ": " + (player.zombie ? "rot" : "blau"));
			}
			System.out.println("Dieser Bot: " + (zombie ? "rot" : "blau"));
			System.out.print("Keys: ");
			for (String key : this.keys) {
				System.out.print(key + ", ");
			}
			System.out.println();
			System.out.println("Ratings:");
			System.out.println(map.getRating(x - 1, y - 1) + " - " + map.getRating(x, y - 1) + " - " + map.getRating(x + 1, y - 1));
			System.out.println(map.getRating(x - 1, y) + " - -2000 - " + map.getRating(x + 1, y));
			System.out.println(map.getRating(x - 1, y + 1) + " - " + map.getRating(x, y + 1) + " - " + map.getRating(x + 1, y + 1));
			System.out.println("Live: " + life);
			System.out.println("Wähle Richtung " + highestWalkingDirection + " mit Wertigkeit " + highestRating);
		}
		cm.move(highestWalkingDirection, lookingDirection);
		xold = x;
		yold = y; // wir merken uns, wo wir vor diesem Zug waren
		if (ConnectionManager.getDebugLevel() > 700) {
			boolean zombiesOnTheField = zombie;
			for (Player player : players) {
				if (player.zombie == true)
					zombiesOnTheField = true;
			}
			if (zombiesOnTheField)
				try {
					Thread.sleep(500);//Damit man gut zugucken kann…
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

	private int[] getWalkingDirection(Map map) {
		int highestRating = -2000; // Wir sollten wegen dieser Giftsteigerungsregel nicht stehen blieben
		int highestWalkingDirection = 0;
		if (map.getRating(x, y + 1) > highestRating) {
			highestRating = map.getRating(x, y + 1);
			highestWalkingDirection = 2;
		}
		/*
		 * if (map.getRating(x + 1, y + 1) > highestRating) { highestRating = map.getRating(x + 1, y +
		 * 1); highestDirection = 3; }
		 */// Diagonal gehen geht nicht
		if (map.getRating(x + 1, y) > highestRating) {
			highestRating = map.getRating(x + 1, y);
			highestWalkingDirection = 6;
		}
		/*
		 * if (map.getRating(x + 1, y - 1) > highestRating) { highestRating = map.getRating(x + 1, y -
		 * 1); highestDirection = 9; }
		 */// Diagonal gehen geht nicht
		if (map.getRating(x, y - 1) > highestRating) {
			highestRating = map.getRating(x, y - 1);
			highestWalkingDirection = 8;
		}
		/*
		 * if (map.getRating(x - 1, y - 1) > highestRating) { highestRating = map.getRating(x - 1, y -
		 * 1); highestDirection = 7; }
		 */// Diagonal gehen geht nicht
		if (map.getRating(x - 1, y) > highestRating) {
			highestRating = map.getRating(x - 1, y);
			highestWalkingDirection = 4;
		}
		/*
		 * if (map.getRating(x - 1, y + 1) > highestRating) { highestRating = map.getRating(x - 1, y +
		 * 1); highestDirection = 1; }
		 */// Diagonal gehen geht nicht
		int[] rvalue = { highestRating, highestWalkingDirection };
		return rvalue;
	}

	private void rateKeys(Map map, int KeySearchImportance) {
		ArrayList<Key> keys = map.getAllKeys();
		for (Key key : keys) {
			if (!haveKey(key.id)) {
				map.rateGoodField(key.x, key.y, KeySearchImportance, this);
			}
		}
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

}
