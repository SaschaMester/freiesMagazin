/**
    (C) Copyright 2010 Dominik Wagenfuehr
    (C) Copyright 2010 Harald Demel and Martin Keiblinger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
/////////
#include "aiengine.hh"
#include "aimode.hh"
#include "trace.hh"

// Qt
//////////
#include <QHostAddress>
#include <QCoreApplication>
#include <QTranslator>
#include <QLocale>

#include "fileparser.c"

// Sys
////////
#include <iostream>

AiEngine *AiEngine::instance = NULL;

int main( int argc, char *argv[] )
{
    int retValue = 255;

    // Create Qt application.
    QCoreApplication app( argc, argv );

    QTranslator appTranslator;
    if ( appTranslator.load( "ai_" + QLocale::system().name() ) )
    {
        app.installTranslator( &appTranslator );
    }

    // Trace::activate( MTP_GAMEMAP,           0x000F );
    // Trace::activate( MTP_FIELD,             0x0000 );
    // Trace::activate( MTP_PLAYER,            0x0003 );
    // Trace::activate( MTP_KEY,               0x0001 );
    // Trace::activate( MTP_COMMAND,           0x0003 );
    // Trace::activate( MTP_PARSER,            0x0003 );
    // Trace::activate( MTP_CLIENT,            0x003F );
    // Trace::activate( MTP_CLIENTCONNECTION,  0x0007 );
    // Trace::activate( MTP_CLIENTPARSER,      0x0007 );
    // Trace::activate( MTP_AI_ENGINE,         0x007F );

    // The ai mode defines how the ai should move.
    AiMode mode = AI_MODE_FICL;
    
    // The values below represent the index in the parameter
    // list. -1 means not set.
    int modeIndex = -1;
    
    // Flag if the ai should give any output like
    // connected players, set positions etc.
    bool showInfo = false;

    // Flag if help should be shown
    // This will override all other flags!
    bool showHelp = false;

    // iterate over all arguments
    // the first argument is the calling name.
    for ( int ii = 1; ii < argc; ii++ )
    {
        const QString param(argv[ii]);

        if ( param == "--info" || param == "-i" )
        {
            showInfo = true;
        }
        else if ( param == "--help" || param == "-h" )
        {
            showHelp = true;
        }
        else if ( param == "--mode" || param == "-m" )
        {
            // in this case the next argument must be the
            // ai mode
            if ( ii+1 < argc )
            {
                modeIndex = ii+1;
                // ignore next argument
                ii++;
            }
        }
        else
        {
            std::cerr << AiEngine::tr("Unknown option: ").toStdString()
                      << param.toStdString() << std::endl << std::endl;
            showHelp = true;
            break;
        }
    }

    if ( !showHelp )
    {
        // extract ai mode
        if ( -1 != modeIndex )
        {
            if ( 0 == QString( argv[modeIndex] ).compare( "NONE" ) )
            {
                mode = AI_MODE_NONE;
            }
            else if ( 0 == QString( argv[modeIndex] ).compare( "LOOK" ) )
            {
                mode = AI_MODE_LOOK;
            }
            else if ( 0 == QString( argv[modeIndex] ).compare( "RANDOM" ) )
            {
                mode = AI_MODE_RANDOM;
            }
            else if ( 0 == QString( argv[modeIndex] ).compare( "FICL" ) )
            {
                mode = AI_MODE_FICL;
            }
            else
            {
                std::cerr << "Unknown ai mode "
                          << argv[modeIndex]
                          << std::endl;
                showHelp = true;
            }
        }
    }

    if ( showHelp )
    {
        // we want to show the help or some important index
        // was not set
        std::cout << AiEngine::tr("Usage: ").toStdString() << argv[0] << AiEngine::tr(" [OPTIONS]").toStdString() << std::endl;
        std::cout << AiEngine::tr("Starts the example AI for the Right2Live-contest of freiesMagazin.").toStdString() << std::endl;
        std::cout << std::endl;
        std::cout << AiEngine::tr("Possible options: ").toStdString() << std::endl;
        std::cout << "  -m, --mode MODE     " << AiEngine::tr("Mode for moving of AI. Possible values:").toStdString() << std::endl;
        std::cout << "             NONE     " << AiEngine::tr("   AI does not move at all.").toStdString() << std::endl;
        std::cout << "             LOOK     " << AiEngine::tr("   AI will not move, but look around.").toStdString() << std::endl;
        std::cout << "             RANDOM   " << AiEngine::tr("   AI will move and look randomly (default).").toStdString() << std::endl;
        std::cout << "  -i, --info          " << AiEngine::tr("Print informations during game.").toStdString() << std::endl;
        std::cout << "  -h, --help          " << AiEngine::tr("Show this help text.").toStdString() << std::endl;
    }
    else
    {
        // create a new engine.
        AiEngine engine;

        // set flags
        engine.setMode( mode );
        engine.showGameInfo( showInfo );

        // connect to a server
        if ( engine.connectToServer( QHostAddress::LocalHost, 15000 ) )
        {
            // wait until server kills connection and game is over
            engine.waitUntilDisconnected();
            retValue = 0;
        }
    }

    return retValue;
}
