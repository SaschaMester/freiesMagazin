/**
    (C) Copyright 2010 Dominik Wagenfuehr
    (C) Copyright 2010 Harald Demel and Martin Keiblinger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "aiengine.hh"
#include "trace.hh"

// Sys
/////////
#include <cstdlib>
#include <ctime>
#include <iostream>

// Constructor
AiEngine::AiEngine()
: m_mode( AI_MODE_RANDOM ), m_showGameInfo(false)
{
    Trace::print( MTP_AI_ENGINE, STP_AI_STRUCTOR,
                  "AiEngine::AiEngine Start" );

    instance = this;
    system = NULL;

    /* initialize random seed: */
    srand ( time(NULL) );

    bool ok = true;

    // first we must connect all signals and slots
    if ( !connect( &m_client, SIGNAL(sig_connected()),
                   this, SLOT(slot_connected()) ) )
    {
        std::cerr << "(EE) AiEngine::AiEngine "
                  << " Connect 1 not possible!"
                  << std::endl;
        ok = false;
    }

    if ( !connect( &m_client, SIGNAL(sig_disconnected()),
                   this, SLOT(slot_disconnected()) ) )
    {
        std::cerr << "(EE) AiEngine::AiEngine "
                  << " Connect 2 not possible!"
                  << std::endl;
        ok = false;
    }

    if ( !connect( &m_client, SIGNAL(sig_processCommand(const ClientParserCommand)),
                   this, SLOT(slot_processCommand(const ClientParserCommand)) ) )
    {
        std::cerr << "(EE) AiEngine::AiEngine "
                  << " Connect 3 not possible!"
                  << std::endl;
        ok = false;
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_STRUCTOR,
                  "AiEngine::AiEngine End " + QString::number((int)ok) );

}

// Connect to a server.
bool AiEngine::connectToServer( const QHostAddress address, const quint16 port, const int msecs )
{
    return m_client.connectToServer(address,port,msecs);
}

// Wait until server kills connection.
void AiEngine::waitUntilDisconnected()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CONNECTION,
                  "AiEngine::waitUntilDisconnected Start" );

    m_client.waitUntilDisconnected();

    Trace::print( MTP_AI_ENGINE, STP_AI_CONNECTION,
                  "AiEngine::waitUntilDisconnected End" );
}

// Client has been connected to the server.
void AiEngine::slot_connected()
{
    // After the connection to the server is okay, we must wait until the id
    // for the player is set correctly.
    
    Trace::print( MTP_AI_ENGINE, STP_AI_CONNECTION,
                  "AiEngine::slot_connected Start" );

    // wait, if data have been sent from the server
    // this should call receiveData
    if ( m_client.waitForData() )
    {
        // I don't know better solution than to wait
        // again 1 second. In this time the client id
        // should have been extracted.
        m_client.waitForData( 1000 );

        if ( m_showGameInfo )
        {
            std::cout << "(II) AiEngine::slot_connected "
                      << " Player " << m_player.getIndex()
                      << std::endl;
        }
    }

    if ( m_player.getIndex() >= 0 )
    {
        m_client.send("ID_OKAY");
    }
    else
    {
        m_client.send("ID_NOT_OKAY");
        m_client.stopConnection();
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_CONNECTION,
                  "AiEngine::slot_connected End" );
}

// Client has been disconnected from the server.
void AiEngine::slot_disconnected()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CONNECTION,
                  "AiEngine::slot_disconnected Start" );

    // Nothing to do here

    Trace::print( MTP_AI_ENGINE, STP_AI_CONNECTION,
                  "AiEngine::slot_disconnected End" );
}

// Client has been disconnected from the server.
void AiEngine::slot_processCommand( const ClientParserCommand commandId )
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::slot_processCommand Start "+ QString::number((int)commandId) );

    switch ( commandId )
    {
    case CPC_NO_COMMAND:
        // nothing to do.
        break;
    case CPC_ERROR:
        // nothing to do.
        break;
    case CPC_PING:
        // nothing to do.
        break;
    case CPC_SET_ID:
        processCommandId();
        break;
    case CPC_CONNECT_OTHER:
        processCommandConnectOther();
        break;
    case CPC_DISCONNECT_OTHER:
        processCommandDisconnectOther();
        break;
    case CPC_DISCONNECT_SELF:
        processCommandDisconnect();
        break;
    case CPC_SET_PLAYER:
        processCommandSet();
        break;
    case CPC_SEE_PLAYER:
        processCommandSeePlayer();
        break;
    case CPC_SEE_KEY:
        processCommandSeeKey();
        break;
    case CPC_GET_KEY:
        processCommandGetKey();
        break;
    case CPC_TEAM_CHANGE:
        processCommandTeamChange();
        break;
    case CPC_LOAD_MAP:
        processCommandLoadMap();
        break;
    case CPC_START:
        // start calculation of next move
        processCommandStartCalculation();
        break;
    case CPC_LIFE:
        // we will not extract the life here because it's not important
        break;
    case CPC_TOXIC:
        // we will not extract the toxic value because it's not important
        break;
    default:
        std::cerr << "(EE) AiEngine::slot_processCommand "
                  << " Default case reached for command "
                  << commandId
                  << std::endl;
        break;
    }

    // delete processed command
    m_client.resetParser();

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::slot_processCommand End " );
}

// Get player id.
void AiEngine::processCommandId()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandId Start " );

    if ( !m_player.setIndex( m_client.getClientId() ) )
    {
        // id could not be set, disconnect client because not work
        // without a correct index
        m_client.stopConnection();
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandId End " );
}

// Connect another client.
void AiEngine::processCommandConnectOther()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandConnectOther Start " );

    const int id = m_client.getClientId();

    // first we must check if the id is not our id
    if ( id != m_player.getIndex() )
    {
        if ( !m_otherPlayers.contains( id ) )
        {
            // add new player
            m_otherPlayers.add( id );
        }
        else
        {
            std::cerr << "(EE) AiEngine::processCommandConnectOther "
                      << " Client "
                      << id
                      << " already connected."
                      << std::endl;
        }
    }
    // no error, we just ignore it

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandConnectOther End " + QString::number(id) );
}

// Disconnect another client.
void AiEngine::processCommandDisconnectOther()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandDisconnectOther Start " );

    const int id = m_client.getClientId();

    // first we must check if the id is not our id
    if ( id != m_player.getIndex() )
    {
        if ( m_otherPlayers.contains( id ) )
        {
            m_otherPlayers.remove(id);
        }
        else
        {
            std::cerr << "(EE) AiEngine::processCommandDisconnectOther "
                      << " Client "
                      << id
                      << " not connected."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "(EE) AiEngine::processCommandDisconnectOther "
                  << " Try to disconnect own client "
                  << id
                  << std::endl;
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandDisconnectOther End " + QString::number(id) );
}

// Disconnect the client.
void AiEngine::processCommandDisconnect()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandDisconnect Start " );

    m_client.stopConnection();

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandDisconnect End " );
}

// Set data of own player.
void AiEngine::processCommandSet()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandSet Start " );

    if ( m_showGameInfo )
    {
        std::cout << "(II) AiEngine::processCommandSet "
                  << " Player "
                  << m_player.getIndex()
                  << " Position ("
                  << m_client.getPosition().x() << ", " << m_client.getPosition().y()
                  << ")"
                  << " View "
                  << Player::toString( m_client.getView() ).toStdString()
                  << std::endl;
    }

    if ( !m_player.setPosition( m_client.getPosition() ) )
    {
        std::cerr << "(EE) AiEngine::processCommandSet "
                  << " Position ("
                  << m_client.getPosition().x() << ", " << m_client.getPosition().y()
                  << ") could not be set for player "
                  << m_player.getIndex()
                  << std::endl;
    }
        
    if ( !m_player.setView( m_client.getView() ) )
    {
        std::cerr << "(EE) AiEngine::processCommandSet "
                  << " View "
                  << Player::toString( m_client.getView() ).toStdString()
                  << " could not be set for player "
                  << m_player.getIndex()
                  << std::endl;
    }
    

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandSet End " );
}

// Set data of other player.
void AiEngine::processCommandSeePlayer()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandSeePlayer Start " );

    const int id = m_client.getClientId();

    if ( id >= 0 )
    {
        if ( m_showGameInfo )
        {
            std::cout << "(II) AiEngine::processCommandSeePlayer "
                      << " Player "
                      << m_player.getIndex()
                      << " Sees Player "
                      << id
                      << " Position ("
                      << m_client.getPosition().x() << ", " << m_client.getPosition().y()
                      << ")"
                      << " View "
                      << Player::toString( m_client.getView() ).toStdString()
                      << std::endl;
        }

        if ( !m_otherPlayers.setPosition( id, m_client.getPosition() ) )
        {
            std::cerr << "(EE) AiEngine::processCommandSeePlayer "
                      << " Position ("
                      << m_client.getPosition().x() << ", " << m_client.getPosition().y()
                      << ") could not be set for player "
                      << id
                      << std::endl;
        }

        if ( !m_otherPlayers.setPositionInfoOfRound( id, roundCount ) )
        {
            std::cerr << "(EE) AiEngine::processCommandSeePlayer "
                      << " PositionInfoOfRound ("
                      << m_client.getRound()
                      << ") could not be set for player "
                      << id
                      << std::endl;
        }
            
        if ( !m_otherPlayers.setView( id, m_client.getView() ) )
        {
            std::cerr << "(EE) AiEngine::processCommandSeePlayer "
                      << " View "
                      << Player::toString( m_client.getView() ).toStdString()
                      << " could not be set for player "
                      << id
                      << std::endl;
        }
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandSeePlayer End " + QString::number(id) );
}

// See a new key.
void AiEngine::processCommandSeeKey()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandSeeKey Start " );

    // create a new key field
    const Field field( m_client.getPosition(), m_client.getKey().get() );

    // check if key field is already known
    if ( !m_visibleKeys.contains( field ) )
    {
        // key is not known, so add it
        m_visibleKeys.append( field );

        if ( m_showGameInfo )
        {
            std::cout << "(II) AiEngine::processCommandSeeKey "
                      << " Player "
                      << m_player.getIndex()
                      << " Key "
                      << m_client.getKey().get().toAscii()
                      << " Position ("
                      << m_client.getPosition().x() << ", " << m_client.getPosition().y()
                      << ")"
                      << std::endl;
        }
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandSeeKey End " );
}

// Get a new key
void AiEngine::processCommandGetKey()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandGetKey Start " );

    // it doesn't matter if the player already has the key
    // The player will only add only keys that he does not have.
    if ( m_player.addKey( m_client.getKey() ) )
    {
        if ( m_showGameInfo )
        {
            std::cout << "(II) AiEngine::processCommandGetKey "
                      << " Player "
                      << m_player.getIndex()
                      << " Key "
                      << m_client.getKey().get().toAscii()
                      << std::endl;
        }
    }
                  
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandGetKey End " );
}

// change the team of a player
void AiEngine::processCommandTeamChange()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandTeamChange Start " );

    const int id = m_client.getClientId();

    if ( id >= 0 )
    {
        if ( m_showGameInfo )
        {
            std::cout << "(II) AiEngine::processCommandTeamChange "
                      << " Player "
                      << m_player.getIndex()
                      << " Change Player "
                      << id
                      << " Team "
                      << Player::toString( m_client.getTeam() ).toStdString()
                      << std::endl;
        }

        if ( id == m_player.getIndex() )
        {
            // the id is the id of the own player
            m_player.setTeam( m_client.getTeam(), false );
        }
        else if ( !m_otherPlayers.setTeam( id, m_client.getTeam(), false ) )
        {
            std::cerr << "(EE) AiEngine::processCommandTeamChange "
                      << " Team "
                      << Player::toString( m_client.getTeam() ).toStdString()
                      << " could not be set for player "
                      << id
                      << std::endl;
        }
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandTeamChange End " + QString::number(id) );
}

// Load new map.
void AiEngine::processCommandLoadMap()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandLoadMap Start " + m_client.getMapName() );

    if ( !m_map.load( m_client.getMapName() ) )
    {
        std::cerr << "(II) AiEngine::processCommandLoadMap "
                  << " Client " << m_player.getIndex()
                  << " Map "
                  << m_client.getMapName().toStdString()
                  << " could not be loaded."
                  << std::endl;
    }

    initFicl();

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandLoadMap End " );
}

// Start calculation of next move.
void AiEngine::processCommandStartCalculation()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandStartCalculation Start " );

    Direction move = DIRECTION_NONE;
    Direction view = DIRECTION_NORTH;

    calcNextMove( move, view );

    if ( m_showGameInfo )
    {
        std::cout << "(II) AiEngine::processCommandStartCalculation "
                  << " Player "
                  << m_player.getIndex()
                  << " Move "
                  << Player::toString( move ).toStdString()
                  << " View "
                  << Player::toString( view ).toStdString()
                  << std::endl;
    }

    if ( !m_client.send("MOVE " + Player::toString(move) + " " +  Player::toString(view) ) )
    {
        std::cerr << "(EE) AiEngine::processCommandStartCalculation "
                  << " Client " << m_player.getIndex()
                  << " Send failed!"
                  << std::endl;
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandStartCalculation End " );
}

// Calculate next move of player.
bool AiEngine::calcNextMove( Direction& move, Direction& view )
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine::calcNextMove Start " );

    bool ok = true;
    
    move = DIRECTION_NONE;
    view = DIRECTION_NORTH;

    // depending on the behaviour mode we move differently
    switch ( m_mode )
    {
    case AI_MODE_NONE:
        // do do nothing but stand still
        ok = true;
        break;
    case AI_MODE_LOOK:
        // look around
        view = m_player.getView();
        if ( view < DIRECTION_NORTH_EAST )
        {
            // Yeah, it's not nice to operate on
            // enumerators, but I'm lazy.
            view = (Direction)(view+1);
        }
        else
        {
            view = DIRECTION_NORTH;
        }
        ok = true;
        break;
    case AI_MODE_RANDOM:
        // What a fine dirty hack. ^^
        move = (Direction)(rand()%(DIRECTION_NORTH_EAST+1));
        view = (Direction)(rand()%(DIRECTION_NORTH_EAST)+1);
        ok = true;
        break;
    case AI_MODE_FICL:
        ok = ficlCalcNextMove(move, view);
        break;
    default:
        std::cerr << "(EE) AiEngine::calcNextMove "
                  << " Client " << m_player.getIndex()
                  << " Reached default case for mode "
                  << m_mode
                  << std::endl;
        break;
    }

#ifdef QT_DEBUG
        std::cout << "(II) AiEngine::calcNextMove "
                  << " Client " << m_player.getIndex()
                  << " Move move "
                  << m_mode
                  << " Move in dir "
                  << Player::toString(move).toStdString()
                  << " view "
                  << Player::toString(view).toStdString()
                  << std::endl;
#endif

    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine::calcNextMove End " + QString::number((int)ok) );

    return ok;
}

bool AiEngine::ficlCalcNextMove( Direction& move, Direction& view ) {
    ficlVmEvaluate(vm,(char*) "initCalc");
    ficlVmEvaluate(vm,(char*) "calcMove");
    ficlVmEvaluate(vm,(char*) "calcView");

    move = tmpMove;
    view = tmpView;

    this->roundCount++;

    return true;
}

static void noTextOut(ficlCallback *callback, char *text) {
    // do nothing
}

/**
 * init ficl for a specific map (done for each loadMap)
 */
void AiEngine::initFicl() {
    if( system != NULL ) {
        ficlSystemDestroy(system);
    }

    roundCount = 0;
    
    
    ficlSystemInformation fauxInfo;
    ficlSystemInformationInitialize(&fauxInfo);
    fauxInfo.dictionarySize = 104857600;
    fauxInfo.textOut = noTextOut;
    fauxInfo.errorOut = noTextOut;
    system = ficlSystemCreate(&fauxInfo);
    ficlSystemCompileExtras(system);
    vm = ficlSystemCreateVm(system);

    ficlDictionary *dict  = ficlSystemGetDictionary(system);

    // additional forth words
    ficlDictionaryAppendPrimitive(dict,(char*) "d>f", cb_dtof, 0);

    // C-Callback getter
    ficlDictionaryAppendPrimitive(dict,(char*) "getField", cb_getField, 0);
    ficlDictionaryAppendPrimitive(dict,(char*) "getToxic", cb_getToxic, 0);
    ficlDictionaryAppendPrimitive(dict,(char*) "canSeeField", cb_canSeeField, 0);
    ficlDictionaryAppendPrimitive(dict,(char*) "getPlayerTeam", cb_getPlayerTeam, 0);
    ficlDictionaryAppendPrimitive(dict,(char*) "getPlayersOfTeam", cb_getPlayersOfTeam, 0);

    ficlDictionaryAppendPrimitive(dict,(char*) "getOwnPos", cb_getOwnPos, 0);
    ficlDictionaryAppendPrimitive(dict,(char*) "getOwnTeam", cb_getOwnTeam, 0);

    ficlDictionaryAppendPrimitive(dict,(char*) "getLastView", cb_getLastView, 0);

    // C-Callback setter
    ficlDictionaryAppendPrimitive(dict,(char*) "setMove", cb_setMove, 0);
    ficlDictionaryAppendPrimitive(dict,(char*) "setView", cb_setView, 0);

    // Variables
    
    char buffer [256];
    ficlVmEvaluate(vm,(char*) "variable width");
    sprintf(buffer, "%d width !", m_map.getSize().width());
    ficlVmEvaluate(vm,(char*) buffer);

    ficlVmEvaluate(vm,(char*) "variable height");
    sprintf(buffer, "%d height !", m_map.getSize().height());
    ficlVmEvaluate(vm,(char*) buffer);

    ficlVmEvaluate(vm,(char*) getCommandString("ai.fr"));
}

void AiEngine::cb_getField(ficlVm *vm) { // : getField ( n1 n2 -- n )
// \ n1 = x-coord
// \ n2 = y-coord
// \ n  = field type (same as libgamemap/fieldtype.hh)
    int y = ficlStackPopInteger(vm->dataStack);
    int x = ficlStackPopInteger(vm->dataStack);

    const QPoint field( x, y );
    ficlStackPushInteger(vm->dataStack, instance->m_map[field].getType());
}

void AiEngine::cb_getToxic(ficlVm *vm) { // : getToxic ( n1 n2 -- r )
// \ n1 = x-coord
// \ n2 = y-coord
// \ r  = toxic value
    int y = ficlStackPopInteger(vm->dataStack);
    int x = ficlStackPopInteger(vm->dataStack);

    const QPoint field( x, y );
    ficlStackPushFloat(vm->floatStack, (float) instance->m_map[field].getToxicValue());
}

void AiEngine::cb_canSeeField(ficlVm *vm) { // : canSeeField ( n1 n2 -- f )
// \ n1 = x-coord
// \ n2 = y-coord
// \ f  = can see from current pos
    int y = ficlStackPopInteger(vm->dataStack);
    int x = ficlStackPopInteger(vm->dataStack);

    bool visible = false;
    QList<QPoint> addBlockedFields;

    QPointF corner[4];
    corner[0] = QPointF( x+0.0001, y+0.0001 );
    corner[1] = QPointF( x+0.9999, y+0.0001 );
    corner[2] = QPointF( x+0.9999, y+0.9999 );
    corner[3] = QPointF( x+0.0001, y+0.9999 );

    // "eyes" of origin = middle of field
    const QPointF originP( instance->m_player.getPosition().x() + 0.5, instance->m_player.getPosition().y() + 0.5 );

    // check for every corner if it's visible
    for ( int ii = 0; ii < 4; ii++ )
    {
        if ( instance->isPossibleVisible( corner[ii], originP, instance->m_player.getView() ) )
        {
            // Checking if one player (from otherPos) sees another one
            // (on pos) is a mathematical question. We will create a line
            // from otherPos to pos and check all intersections with
            // the walls and doors on the game map.
            if ( instance->m_map.isPositionVisible( corner[ii], originP, addBlockedFields ) )
            {
                // the corner is visible => so is the target
                visible = true;
                break;
            }
        }
    }

    ficlStackPushInteger(vm->dataStack, (visible ? -1 : 0 ) );
}

void AiEngine::cb_getPlayerTeam(ficlVm *vm) { // : getPlayerTeam ( n1 n2 -- n )
// \ n1 = x-coord
// \ n2 = y-coord
// \ n  = player status (blue=0, red=1, noplayer=-1)
    int y = ficlStackPopInteger(vm->dataStack);
    int x = ficlStackPopInteger(vm->dataStack);

    const QPoint field( x, y );
    const QList<int> idList = instance->m_otherPlayers.getListOfIds();
    for( int i = 0; i < idList.count(); i++) {
        int id = idList.at(i);
        if (instance->m_otherPlayers.getPosition(id) == field) {
            ficlStackPushInteger(vm->dataStack, (int) instance->m_otherPlayers.getTeam(id));
            return;
        }
    }

    ficlStackPushInteger(vm->dataStack, -1);
}

void AiEngine::cb_getPlayersOfTeam(ficlVm *vm) { // : getPlayersOfTeam ( n1 -- false ( n2 n3 n4 true )* )
// \ n1  = player status (blue=0, red=1, noplayer=-1)
// \ n2  = x
// \ n3  = y
// \ n4  = round
    int team = ficlStackPopInteger(vm->dataStack);
    ficlStackPushInteger(vm->dataStack, 0);

    const QList<int> idList = instance->m_otherPlayers.getListOfIds();
    for( int i = 0; i < idList.count(); i++) {
        int id = idList.at(i);
        if ((int) instance->m_otherPlayers.getTeam(id) == team ) {
            ficlStackPushInteger(vm->dataStack, instance->m_otherPlayers.getPosition(id).x());
            ficlStackPushInteger(vm->dataStack, instance->m_otherPlayers.getPosition(id).y());
            ficlStackPushInteger(vm->dataStack, instance->roundCount - instance->m_otherPlayers.getPositionInfoOfRound(id) );
            ficlStackPushInteger(vm->dataStack, -1);
        }
    }
}

void AiEngine::cb_getOwnPos(ficlVm *vm) { // : getOwnPos ( -- n1 n2 )
// \ n1 = x-coord
// \ n2 = y-coord
    ficlStackPushInteger(vm->dataStack, instance->m_player.getPosition().x());
    ficlStackPushInteger(vm->dataStack, instance->m_player.getPosition().y());
}

void AiEngine::cb_getOwnTeam(ficlVm *vm) { // : getOwnTeam ( -- n )
// \ n  = player status (blue=0, red=1, noplayer=-1)
    ficlStackPushInteger(vm->dataStack, (int) instance->m_player.getTeam());
}

void AiEngine::cb_getLastView(ficlVm *vm) { // : getLastView ( -- n )
// \ n  = the direction of last view (same as libplayer/direction.hh)
    ficlStackPushInteger(vm->dataStack, (int) instance->tmpView);
}

void AiEngine::cb_setMove(ficlVm *vm) { // : setMove ( n -- )
// \ n  = the direction to move (same as libplayer/direction.hh)
    instance->tmpMove = (Direction) ficlStackPopInteger(vm->dataStack);
}

void AiEngine::cb_setView(ficlVm *vm) { // : setView ( n -- )
// \ n  = the direction to view (same as libplayer/direction.hh)
    instance->tmpView = (Direction) ficlStackPopInteger(vm->dataStack);
}

void AiEngine::cb_dtof(ficlVm *vm) { // : d>f ( d -- r )
    int d = ficlStackPopInteger(vm->dataStack);
    ficlStackPushFloat(vm->floatStack, (float) d);
}

// Check if target position is possible visible from pos.
bool AiEngine::isPossibleVisible( const QPointF& targetPos, const QPointF& pos,
                                    const Direction view ) const
{
    bool visible = false;

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::isPossibleVisible Start " );

    // We can only see a span of 180 degree in the viewing
    // direction. Therefore everything that is "behind" a player is
    // not visible to him.

    // The algorithm is very easy:
    // 1. Calculate the view end point E.
    // 2. Calculate the viewing vector E-P.
    // 3. Calculate diff vector T-P.
    // 4. Calculate scalar product s = ( E-P, T-P ).
    // If s > 0 E and T lie on the same side and therefore T is visible
    // from P.
    // If s < 0 E and T lie on different sided and therefore T is not
    // visible from P.
    // If s == 0, we say that it's still visible.

    // Attention: Each field on the game map has a size of 1 in
    // both dimension. A player will only have "eyes" at the center
    // of it. So we do not calculate with positions but with
    // the center of each field!
    // The target at the other hand will have dimensions of 1x1
    // of the field he's standing on. So if we see at least one
    // of the four field cornes, the target is visible.

    // set target
    QPointF viewP( pos );

    if ( calcViewEndPoint( viewP, pos, view ) )
    {
#ifdef QT_DEBUG
        std::cout << "(II) GameEngine::isPossibleVisible "
                  << " To: "   << targetPos.x() << " " << targetPos.y()
                  << " From: " << pos.x() << " " << pos.y()
                  << " View: " << viewP.x() << " " << viewP.y()
                  << std::endl;
#endif

        // calcuate viewing vector
        const QPointF viewVec( viewP - pos );

        // calculate diff vector
        const QPointF diffVec( targetPos - pos );

        // calculate scalar product
        const qreal scalProd = viewVec.x() * diffVec.x() + viewVec.y() * diffVec.y();

#ifdef QT_DEBUG
        std::cout << "(II) GameEngine::isPossibleVisible "
                  << " viewVec: "  << viewVec.x() << " " << viewVec.y()
                  << " diffVec: "  << diffVec.x() << " " << diffVec.y()
                  << " scalProd: " << scalProd
                  << std::endl;
#endif

        // Check visibility by scalar product
        // Only one corner must be visible.
        visible = ( scalProd > 0.0 );
    }

    Trace::print( MTP_GAME_ENGINE, STP_GE_GAME,
                  "GameEngine::isPossibleVisible End " + QString::number(visible) );

    return visible;
}

// Calculate viewing end point.
bool AiEngine::calcViewEndPoint( QPointF& endPoint, const QPointF& pos,
                                   const Direction view ) const
{
    bool ok = true;
    endPoint = pos;

    switch ( view )
    {
    case DIRECTION_NORTH:
        endPoint = QPointF( endPoint.x(),     endPoint.y() - 1 );
        break;
    case DIRECTION_NORTH_WEST:
        endPoint = QPointF( endPoint.x() - 1, endPoint.y() - 1 );
        break;
    case DIRECTION_WEST:
        endPoint = QPointF( endPoint.x() - 1, endPoint.y() );
        break;
    case DIRECTION_SOUTH_WEST:
        endPoint = QPointF( endPoint.x() - 1, endPoint.y() + 1 );
        break;
    case DIRECTION_SOUTH:
        endPoint = QPointF( endPoint.x(),     endPoint.y() + 1 );
        break;
    case DIRECTION_SOUTH_EAST:
        endPoint = QPointF( endPoint.x() + 1, endPoint.y() + 1 );
        break;
    case DIRECTION_EAST:
        endPoint = QPointF( endPoint.x() + 1, endPoint.y() );
        break;
    case DIRECTION_NORTH_EAST:
        endPoint = QPointF( endPoint.x() + 1, endPoint.y() - 1 );
        break;
    default:
        std::cerr << "(EE) GameEngine::calcViewEndPoint "
                  << " Default case reached for view "
                  << Player::toString(view).toStdString()
                  << std::endl;
        ok = false;
        break;
    }

    return ok;
}

