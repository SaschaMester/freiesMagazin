
#ifndef FILEPARSER_H
#define	FILEPARSER_H

#include <stdio.h>
#include <malloc.h>

#define STRING_ALLOC_STEP 100
#define BAD_CHARS {12, 11, 9 }

#ifdef	__cplusplus
extern "C" {
#endif
    /**
     * Reads the content of a given ASCII file and returns it as string.
     * @param filePath 
     * @return The content of the file
     */
    char* getContent(const char*);

    char* filter(char*);

    char* getCommandString(const char*);

    char isValid(char);

#ifdef	__cplusplus
}
#endif

#endif	/* FILEPARSER_H */

