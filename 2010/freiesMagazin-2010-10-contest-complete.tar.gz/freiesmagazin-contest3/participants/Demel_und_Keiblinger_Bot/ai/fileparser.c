#include "fileparser.h"

char* getCommandString(const char* path) {
    char* txt = getContent(path);
    char* filtered = (char*)0;

    if(txt == NULL)
        return NULL;

    filtered = filter(txt);
    free(txt);
    return filtered;
}

char* getContent(const char* filePath) {
    FILE* fp = fopen(filePath, "r");

    if(fp == NULL)
        return NULL;

    // dimensioned as 10 forth screens (10 * 1K)
    // This should be big enough - not clean but functional ;-)
    char* content = (char*)malloc(sizeof(char) * 32000);
    int charCount = 0;

    while(!feof(fp)) {
        content[charCount] = fgetc(fp);
        charCount++;
        content[charCount] = '\0';
    }

    fclose(fp);
    return content;
}

char* filter(char* txt) {
    char* filtered = (char*)malloc(sizeof(char) * strlen(txt));
    int i = 0;
    int txtC = 0;

    for(; i < strlen(txt); i++) {
        if(isValid(txt[i])) {
            filtered[txtC] = txt[i];
            txtC++;
        } else {
            filtered[txtC] = ' ';
            txtC++;
        }
    }

    if(txtC == strlen(filtered))
        filtered[txtC - 1] = '\0';
    else
        filtered[txtC] = '\0';

    return filtered;
}

char isValid(char c) {
    return !(c == '\n' || c == '\t');
}
