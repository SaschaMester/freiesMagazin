/**
    (C) Copyright 2010 Dominik Wagenfuehr
    (C) Copyright 2010 Harald Demel and Martin Keiblinger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef PLAYER_HH
#define PLAYER_HH

// Own
////////
#include "direction.hh"
#include "team.hh"
#include "keylist.hh"

// Qt
////////
#include <QPoint>
#include <QString>

// Forward declarations.
//////////////////////////
class Key;

/// Player.
/**
 * This class represents the player on the battle field.
 * Each player has a unique id, a position and a viewing
 * direction. Further it has a list fo all known keys
 * so that the player can open and walk through corresponding
 * doors.
 */
class Player
{
public:

    /// Constructor
    Player();

    // No destructor or copy constructor needed because
    // we only have basic types.

    ///////////////////
    // Setter
    ///////////////////

    /// Reset everything of a player except the index.
    void reset();
        
    /// Set new index.
    /**
     * Set new index for this player.
     * It will only be set if no index was set before!
     * @param index client id
     * @return true if index could be set
     */
    bool setIndex( const int index );
    
    /// Set new player position.
    /**
     * If the player has not moved we will increase the
     * number of stand stills. Else the counter is reset.
     * @return true if position is non-negative.
     */
    bool setPosition( const QPoint& pos );

    void setPositionInfoOfRound(int positionInfoOfRound) {
        this->m_positionInfoOfRound = positionInfoOfRound;
    }
    
    /// Set new view direction.
    /**
     * @return true if view could be set.
     */
    bool setView( const Direction view );

    /// Set new team membership.
    /**
     * Even if the player becomes RED he will keep his life power!
     * @return true if team could be set.
     */
    bool setTeam( const Team team, const bool forced );

    /// Marks a player as invalid.
    /**
     * @param invalid If true player is invalid, else valid.
     */
    void setInvalid( const bool invalid ) { m_invalid = invalid; }
    
    /// Set life power.
    /**
     * If the life power will be less zero it will be set to 0.0.
     * Even if the life power is zero the player will not automatically
     * change the team!
     */
    void setLife( const double value );
    
    /// Subtract life power.
    /**
     * If the life power will be less zero it will be set to 0.0.
     * Even if the life power is zero the player will not automatically
     * change the team!
     */
    void decreaseLife( const double value );
    
    /// Add new key to the known keys.
    /**
     * @return true if key could be added or is already known
     */
    bool addKey( const Key& key );

    /// Add some points to current score.
    /**
     * @param points Points to add.
     */
    void addScore( const double points ) { m_score += points; }

    /// Increase the number of catches.
    /**
     * We count the number of players that this player has
     * catched and therefore converted to the own team. We
     * will separate the counter by team membership.
     * @param team Team of player that has been catched.
     * @return true if team is valid
     */
    bool increaseCatched( const Team team );

    ///////////////////
    // Getter
    ///////////////////

    /// Return index of the player.
    int getIndex() const { return m_id; }

    /// Return player position.
    const QPoint& getPosition() const { return m_position; }

    int getPositionInfoOfRound() const {
        return m_positionInfoOfRound;
    }
    
    /// Return view direction.
    Direction getView() const { return m_view; }

    /// Return team.
    Team getTeam() const { return m_team; }

    /// Return true if team change was forced.
    bool wasForcedTeamChange() const { return m_forcedTeamChange; }

    /// Get number of rounds the player was in team.
    /**
     * @return number or -1 if team is invalid
     */
    int getNumRoundsInTeam( const Team team ) const;

    /// Get number of players that has been catched of this team by the player.
    /**
     * @return number or -1 if team is invalid
     */
    int getNumCatchesOfTeam( const Team team ) const;
    
    /// Check if player is invalid.
    /**
     * Valid means that the player is still in the game and the
     * client has not quit the connection. We mark such players
     * as invalid.
     * @return true if player is invalid, else false
     */
    bool isInvalid() const {  return m_invalid; }

    /// Return the number of times in a row the player has not moved.
    int getNumStandStills() const { return m_numStandStills; }
    
    /// Return life power.
    double getLife() const { return m_lifePower; }

    /// Return true if player has no life power.
    bool hasNoLife() const { return ( m_lifePower <= 0.0 ); }
    
    /// Check if player has a key
    /**
     * @return true if key is known to the player
     */
    bool hasKey( const Key& key ) const;

    /// Return score.
    double getScore() const { return m_score; }

    ///////////////////
    // Static
    ///////////////////

    /// Convert a direction to a string.
    static QString toString( const Direction dir );

    /// Convert a direction to a string.
    static QString toShortString( const Direction dir );
    
    /// Convert a team to a string.
    static QString toString( const Team team );

    /// Move position from start to target by movement direction.
    /**
     * This will just return the reached position after the movement.
     * @param targetPos Target position that will be reached by movement
     * @param startPos Position to start.
     * @param movement Movement direction.
     * @return true, if everything is okay
     */
    static bool movePosition( QPoint& targetPos, const QPoint& startPos,
                              const Direction movement );
                       
private:

    /// Index of the player.
    /**
     * Each player has a unique index so that identifying
     * is easier.
     */
    int m_id;

    /// Player position on map.
    /**
     * The position must start at (0,0). If one value
     * is negative, this indicates this player has no
     * position yet.
     */
    QPoint m_position;
    int m_positionInfoOfRound;

    /// View direction of the player.
    /**
     * The view is important because a player can only
     * see the player on one half of the map (except
     * team members).
     */
    Direction m_view;
    
    /// Player team membership.
    Team m_team;

    /// Flag if player is invalid.
    /**
     * This is set to true if the client for this player disconnects
     * and leave a game while it's running.
     */
    bool m_invalid;

    /// Number of iterations the player has not moved.
    int m_numStandStills;
    
    /// Life power of a player.
    /**
     * As default a player will have a life power of 100 percent.
     * If he moves over toxic fields he will loose some of this power.
     * The weakest player will be converted to RED after some time.
     * If the life power is 0.0 he will be converted to.
     */
    double m_lifePower;
    
    /// List of known keys.
    /**
     * This list holds all known keys of the player
     * and therefore the doors he can walk through.
     */
    KeyList m_knownKeys;
    
    /// Number of rounds a player is in one team.
    /**
     * We will count how many rounds a player is in one team.
     * We assume that with each setPosition a round has ended.
     */
    int m_roundsInTeam[TEAM_MAX_NUM];

    /// Number of catches of one team.
    /**
     * Count number of catches from each team of this player.
     */
    int m_teamCatches[TEAM_MAX_NUM];

    /// Flag if the team change was forced.
    /**
     * This is important if we will count the points later.
     */
    bool m_forcedTeamChange;

    /// Player score.
    /**
     * The player with highest score will win the game.
     * The score is not an integer because we may need to add
     * comma values.
     */
    double m_score;

};

#endif // PLAYER_HH
