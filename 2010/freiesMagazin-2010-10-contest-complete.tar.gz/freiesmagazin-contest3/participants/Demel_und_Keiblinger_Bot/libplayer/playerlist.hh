/**
    (C) Copyright 2010 Dominik Wagenfuehr
    (C) Copyright 2010 Harald Demel and Martin Keiblinger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef PLAYERLIST_HH
#define PLAYERLIST_HH

// Own
/////////
#include "direction.hh"
#include "team.hh"

// Qt
///////
#include <QList>
#include <QPoint>

// Forward declarations
///////////////////////////
class Key;
class Player;

/// List of players.
/**
 * The list contains players. Each player in the list must have a
 * unqiue id. It's not possible to add players with the same id.
 */
class PlayerList
{
public:

    ////////////////////////////////
    // Constructor and Operators
    ////////////////////////////////

    /// Constructor
    PlayerList();

    /// Destructor.
    virtual ~PlayerList();
    
    ////////////////////////////////
    // Getting data
    ////////////////////////////////

    /// Return size of list = number of players.
    int count() const { return m_playerList.count(); }

    /// Check if player with id is in list.
    /**
     * @return true if player id was found
     */
    bool contains( const int playerId ) const;

    /// Return a list of all player ids.
    /**
     * We will create and return a list of all player ids.
     * @return list of player ids
     */
    QList<int> getListOfIds() const;
    
    /// Get team of some player.
    /**
     * @param playerId Id of player (not index in list!)
     * @return team, or BLUE if player id is not valid
    */
    Team getTeam( const int playerId ) const;

    /// Get viewing direction of some player.
    /**
     * @param playerId Id of player (not index in list!)
     * @return viewing direction, or NONE if player id is not valid
    */
    Direction getView( const int playerId ) const;

    /// Get position of some player.
    /**
     * @param playerId Id of player (not index in list!)
     * @return Position of player or (-1,-1) if player id is invalid
    */
    QPoint getPosition( const int playerId ) const;

    int getPositionInfoOfRound ( const int playerId ) const;

    /// Get life power of some player.
    /**
     * @param playerId Id of player (not index in list!)
     * @return Player life power or 0.0 if player id is invalid
    */
    double getLife( const int playerId ) const;

    /// Check if player is in one team.
    /**
     * This will also return false if the player does not exists.
     * @param playerId Id of player (not index in list!)
     * @param team Team to compare
     * @return true if player is in the checked team, else false
     */
    bool isTeam( const int playerId, const Team team ) const;

    /// Check if player has one key.
    /**
     * This will also return false if the player does not exists.
     * @param playerId Id of player (not index in list!)
     * @param key Key to compare
     * @return true if player has the key, else false
     */
    bool hasKey( const int playerId, const Key& key ) const;

    /// Check if player is invalid.
    /**
     * This will also return false if the player does not exists.
     * @param playerId Id of player (not index in list!)
     * @return true if player is invalid, else false
     */
    bool isInvalid( const int playerId ) const;

    /// Return the number of times in a row the player has not moved.
    /**
     * This will also return 0 if the player does not exists.
     * @param playerId Id of player (not index in list!)
     * @return number of noon-movements, if player is valid, else 0
     */    
    int getNumStandStills( const int playerId ) const;

    /// Return true if team change was forced.
    /**
     * This will also return false if the player does not exists.
     * @param playerId Id of player (not index in list!)
     * @return true if team change was forced
     */
    bool wasForcedTeamChange( const int playerId ) const;

    /// Get number of rounds the player was in team.
    /**
     * This will also return -1 if the player does not exists.
     * @param playerId Id of player (not index in list!)
     * @return number or -1 if team is invalid
     */
    int getNumRoundsInTeam( const int playerId, const Team team ) const;

    /// Get number of players that has been catched of this team.
    /**
     * This will also return -1 if the player does not exists.
     * @param playerId Id of player (not index in list!)
     * @return number or -1 if team is invalid
     */
    int getNumCatchesOfTeam( const int playerId, const Team team ) const;
    
    /// Return player score.
    /**
     * @param playerId Id of player (not index in list!)
     * @return score or 0.0 if player is invalid
     */
    double getScore( const int playerId ) const;

    ////////////////////////////////
    // Setting data
    ////////////////////////////////
    
    /// Create a new player with an id.
    /**
     * The player id must not exists in the list!
     * @param playerId Id of player.
     * @return true if player could be added
     */
    bool add( const int playerId );
    
    /// Remove player from list.
    /**
     * The player id must exists in the list!
     * @param playerId Id of player.
     * @return true if player was removed
     */
    bool remove( const int playerId );

    /// Reset all players.
    /**
     * The id of all players and the invalid mark
     * will be kept.
     */
    void resetAll();

    /// CLear whole list.
    void clear();
    
    /// Set new position for a player.
    /**
     * @return true if position is valid ( > -1 ) and the player was found
     */
    bool setPosition( const int playerId, const QPoint& position );

    bool setPositionInfoOfRound( const int playerId, int positionInfoOfRound);

    /// Set new view for a player.
    /**
     * @return true if view is valid ( != NONE ) and the player was found
     */
    bool setView( const int playerId, const Direction view );

    /// Set new team for a player.
    /**
     * @return true if the player was found
     */
    bool setTeam( const int playerId, const Team team, const bool forced );
    
    /// Set life power.
    /**
     * @return true if the player was found
     */
    bool setLife( const int playerId, const double value );
    
    /// Subtract life power.
    /**
     * @return true if the player was found
     */
    bool decreaseLife( const int playerId, const double value );

    /// Marks a player as invalid.
    /**
     * The player id must exists in the list!
     * @param playerId Id of player.
     * @param invalid If true player is invalid, else valid.
     * @return true if player was marked
     */
    bool setInvalid( const int playerId, const bool invalid );
    
    /// Add new key to the known keys.
    /**
     * @param playerId Id of player.
     * @param key Key to add.
     * @return true if keys was added or is already known
     */
    bool addKey( const int playerId, const Key& key );

    /// Add some points to player score.
    /**
     * @param playerId Id of player.
     * @param points Points to add.
     * @return true if player was found
     */
    bool addScore( const int playerId, const double points );

    /// Increase the number of catches.
    /**
     * We count the number of players that this player has
     * catched and therefore converted to the own team. We
     * will separate the counter by team membership.
     * @param playerId Id of player.
     * @param team Team of the player that has been catched.
     * @return true if player was found
     */
    bool increaseCatched( const int playerId, const Team team );
    
protected:

    /// Find player id.
    /**
     * @return index of player id in list or -1 if not found
     */
    int find( const int playerId ) const;

    /// List of players
    QList<Player*> m_playerList;

private:

    /// Create a new player.
    /**
     * The method should be reimplemented by all derivatives!
     */
    virtual Player* createNewPlayer() const;

};

#endif // PLAYERLIST_HH
