/**
    (C) Copyright 2010 Dominik Wagenfuehr
    (C) Copyright 2010 Harald Demel and Martin Keiblinger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
/////////
#include "playerlist.hh"
#include "player.hh"

// Sys
/////////
#include <iostream>

// Constructor
PlayerList::PlayerList()
{
    // nothing to do
}

// Destructor.
PlayerList::~PlayerList()
{
    // clear whole list 
    clear();
}

// Check if player with id is in list.
bool PlayerList::contains( const int playerId ) const
{
    return ( find( playerId ) >= 0 );
}

// Get team of some player.
Team PlayerList::getTeam( const int playerId ) const
{
    Team team = TEAM_BLUE;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        team = m_playerList[index]->getTeam();
    }

    return team;
}

// Get viewing direction of some player.
Direction PlayerList::getView( const int playerId ) const
{
    Direction view = DIRECTION_NONE;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        view = m_playerList[index]->getView();
    }

    return view;
}

// Get position of some player.
QPoint PlayerList::getPosition( const int playerId ) const
{
    QPoint pos(-1,-1);

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        pos = m_playerList[index]->getPosition();
    }

    return pos;
}

int PlayerList::getPositionInfoOfRound ( const int playerId ) const {
    int r = 0;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        r = m_playerList[index]->getPositionInfoOfRound();
    }

    return r;
}

// Get life power of some player.
double PlayerList::getLife( const int playerId ) const
{
    double life = 0.0;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        life = m_playerList[index]->getLife();
    }

    return life;
}

// Check if player is in one team.
bool PlayerList::isTeam( const int playerId, const Team team ) const
{
    bool ok = false;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        ok = ( team == m_playerList[index]->getTeam() );
    }

    return ok;
}

// Check if player has one key.
bool PlayerList::hasKey( const int playerId, const Key& key ) const
{
    bool ok = false;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        ok = m_playerList[index]->hasKey( key );
    }

    return ok;
}

// Check if player is invalid.
bool PlayerList::isInvalid( const int playerId ) const
{
    bool invalid = false;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        invalid = m_playerList[index]->isInvalid();
    }

    return invalid;
}

// Return the number of times in a row the player has not moved.
int PlayerList::getNumStandStills( const int playerId ) const
{
    int standStills = 0;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        standStills = m_playerList[index]->getNumStandStills();
    }

    return standStills;
}

// Return true if team change was forced.
bool PlayerList::wasForcedTeamChange( const int playerId ) const
{
    bool forced = false;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        forced = m_playerList[index]->wasForcedTeamChange();
    }

    return forced;
}

// Get number of rounds the player was in team.
int PlayerList::getNumRoundsInTeam( const int playerId, const Team team ) const
{
    int number = -1;
 
    const int index = find( playerId );
 
    if ( index >= 0 )
    {
        // player was found
        number = m_playerList[index]->getNumRoundsInTeam(team);
    }
 
    return number;
}

// Get number of players that has been catched of this team.
int PlayerList::getNumCatchesOfTeam( const int playerId, const Team team ) const
{
    int number = -1;
 
    const int index = find( playerId );
 
    if ( index >= 0 )
    {
        // player was found
        number = m_playerList[index]->getNumCatchesOfTeam(team);
    }
 
    return number;
}
    
// Return player score.
double PlayerList::getScore( const int playerId ) const
{
    double score = 0.0;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        score = m_playerList[index]->getScore();
    }

    return score;
}

// Return a list of all player ids.
QList<int> PlayerList::getListOfIds() const
{
    QList<int> idList;

    for ( int ii = 0; ii < m_playerList.count(); ii++ )
    {
        const int index = m_playerList[ii]->getIndex();
        if ( index >= 0 )
        {
            // only add valid player ids ( != -1 )
            idList.append( index );

            // but we will not check if the player is valid
        }
    }

    return idList;
}

// Create a new player.
Player* PlayerList::createNewPlayer() const
{
    return new Player();
}

// Create a new player with an id.
bool PlayerList::add( const int playerId )
{
    bool ok = false;
    
    if ( !contains( playerId ) )
    {
        // create new player
        Player *player = createNewPlayer();

        if ( player )
        {
            if ( player->setIndex( playerId ) )
            {
                // append new player
                m_playerList.append( player );
                ok = true;
            }
            else
            {
                delete player;
                player = 0;
            }
        }
    }

    return ok;
}

// Remove player from list.
bool PlayerList::remove( const int playerId )
{
    bool ok = false;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        delete m_playerList.takeAt(index);
        ok = true;
    }

    return ok;
}

// Set new position for a player.
bool PlayerList::setPosition( const int playerId, const QPoint& position )
{
    bool ok = false;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        ok = m_playerList[index]->setPosition( position );
    }

    return ok;
}

bool PlayerList::setPositionInfoOfRound(const int playerId, int positionInfoOfRound) {
    bool ok = false;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        m_playerList[index]->setPositionInfoOfRound(positionInfoOfRound);
        ok = true;
    }

    return ok;
}

// Set new view for a player.
bool PlayerList::setView( const int playerId, const Direction view )
{
    bool ok = false;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        ok = m_playerList[index]->setView( view );
    }

    return ok;
}

// Set new team for a player.
bool PlayerList::setTeam( const int playerId, const Team team, const bool forced )
{
    bool ok = false;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        ok = m_playerList[index]->setTeam( team, forced );
    }

    return ok;
}

// Subtract life power.
bool PlayerList::decreaseLife( const int playerId, const double value )
{
    bool ok = false;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        m_playerList[index]->decreaseLife( value );
        ok = true;
    }

    return ok;
}

// Set life power.
bool PlayerList::setLife( const int playerId, const double value )
{
    bool ok = false;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        m_playerList[index]->setLife( value );
        ok = true;
    }

    return ok;
}

// Marks a player as invalid.
bool PlayerList::setInvalid( const int playerId, const bool invalid )
{
    bool ok = false;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        m_playerList[index]->setInvalid( invalid );
        ok = true;
    }

    return ok;
}

// Add new key to the known keys.
bool PlayerList::addKey( const int playerId, const Key& key )
{
    bool ok = false;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        ok = m_playerList[index]->addKey( key );
    }

    return ok;
}

// Add some spoints to player score.
bool PlayerList::addScore( const int playerId, const double points )
{
    bool ok = false;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        m_playerList[index]->addScore( points );
        ok = true;
    }

    return ok;
}

// Increase the number of catches.
bool PlayerList::increaseCatched( const int playerId, const Team team )
{
    bool ok = false;

    const int index = find( playerId );

    if ( index >= 0 )
    {
        // player was found
        ok = m_playerList[index]->increaseCatched( team );
    }

    return ok;
}

// Reset all players.
void PlayerList::resetAll()
{
    for ( int ii = 0; ii < m_playerList.count(); ii++ )
    {
        m_playerList[ii]->reset();
    }
}

// Find player id.
int PlayerList::find( const int playerId ) const
{
    int index = -1;

    for ( int ii = 0; ii < m_playerList.count(); ii++ )
    {
        if ( playerId == m_playerList[ii]->getIndex() )
        {
            // player found
            index = ii;
            break;
        }
    }

    return index;
}

// Clear whole list.
void PlayerList::clear()
{
    while ( !m_playerList.isEmpty() )
    {
        delete m_playerList.takeFirst();
    }

}



