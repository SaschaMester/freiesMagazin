package Ki;

import java.io.InputStreamReader;
import java.io.PipedInputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import Network.NetworkHandler;
import Util.Koordinate;
import Util.LogWriter;

public class ki extends Thread 
{
	private Bot controlledBot;
	private Map map;
	private LogWriter log;
	private InputStreamReader pipeIn;
	private NetworkHandler networkInterface;
	private boolean running=true;
	public ki(PipedInputStream pis, NetworkHandler net)
	{
		this.pipeIn = new InputStreamReader(pis);
		this.networkInterface = net;
		this.map = new Map();
		this.log = new LogWriter(false, new Date());
	}
	@Override
	public void run()
	{
		Scanner in = new Scanner(pipeIn);
		String input = in.nextLine();
		input = input.substring(0, input.length()-1);
		if(input.startsWith("ID"))
		{
			String[] idparts = input.split(" ");
			String id = idparts[1];
			this.controlledBot = new Bot(Integer.parseInt(id));
			this.log.print("Eigene ID: "+id);
		}
		while(running)
		{
			input = in.nextLine();
			input = input.substring(0, input.length()-1);
			if(input.startsWith("START"))
			{
				long start = System.currentTimeMillis();
				String output = this.calcNextMove();
				long dauer = System.currentTimeMillis()-start;
				String [] s = input.split(" ");
				this.log.print("Runde: " + s[1]+ "Dauer für die Berechnung: "+dauer+"ms");
				this.networkInterface.write(output);
			}
			if(input.startsWith("SET"))
			{
				String [] s = input.split(" ");
				this.controlledBot.setPosition(s[1]);
				this.controlledBot.setView(s[2]);
			}
			if(input.startsWith("CONNECTED"))
			{
				String [] s = input.split(" ");
				this.map.addPlayer(s[1]);
				this.log.print(input);
			}
			if(input.startsWith("TOXIC"))
			{
				String [] s = input.split(" ");
				Koordinate k = new Koordinate(s[1]);
				double toxic = Double.parseDouble(s[2]);
				this.map.setToxic(k, toxic);
			}
			if(input.startsWith("MAP"))
			{
				String [] s = input.split(" ");
				this.map.parseMap(s[1]);
			}
			if(input.equals("DISCONNECT"))
			{
				this.running = false;
			}
			if(input.startsWith("SEE_PLAYER"))
			{
				String [] s = input.split(" ");
				Koordinate spieler = new Koordinate(s[1]);
				String id = s[3];
				Player p = this.map.getPlayer(id);
				if(p == null)
				{
					this.map.addPlayer(id);
				}
				p = this.map.getPlayer(id);
				p.setPosition(spieler);
			}
			if(input.startsWith("TEAMCHANGE"))
			{
				String [] s = input.split(" ");
				int id = Integer.parseInt(s[2]);
				boolean red = s[1].equals("RED");
				if(id == this.controlledBot.getID())
				{
					this.controlledBot.setRED(true);
					this.log.print("Wechsel in Team Rot");
				}
				else
				{
					Player p = this.map.getPlayer(s[2]);
					p.setRed(red);
				}

					
			}
		}
		this.log.print("KI angehalten");

	}
	
	private String calcNextMove()
	{
		ArrayList<Field> Af = this.map.getFieldsarround(this.controlledBot.getKoordinate());
		ArrayList<Player> player = this.map.getPlayers(!this.controlledBot.isRED());
		Field next = Af.get(0);
		for(Field f: Af)
		{
			int distance;
			if(player.size()>0)
			{
				Koordinate feld = f.getKoordinate();
				distance = Integer.MAX_VALUE;
				for(int i =0; i<player.size();i++)
				{
					Koordinate gegner = player.get(i).getPosition();
					if(gegner !=null)
					{
						int vergleich = feld.getDistanceTo(gegner);
						if(vergleich <= distance)
						{
							distance = vergleich;
						}
					}

				}
			}
			else
			{
				distance =0;
			}
			this.log.print("Feld: " + f.getKoordinate() +" Distance: "+ distance);
			if(this.controlledBot.isRED())
			{
				this.calcRedRating(f, distance);
				this.log.print("Rotes Bewertungsschema");
			}
			else
			{
				this.calcBlueRating(f, distance);	
				this.log.print("Blaues Bewertungsschema");
			}
			//this.log.print("RATING von Feld: "+f.getKoordinate()+ " ist "+ f.getRating());

		}
		double rating =Double.MAX_VALUE;
		for(Field f: Af)
		{
			if(f.getRating()<=rating && !f.equals(this.controlledBot.getLastdestination()))
			{
				rating = f.getRating();
			}
		}
		ArrayList<Field> potentialFields = new ArrayList<Field>();
		for(Field f: Af)
		{
			if(f.getRating() == rating)
			{
				potentialFields.add(f);
			}
		}
		int nextField = (int)(Math.random()*potentialFields.size());
		next = potentialFields.get(nextField);
		this.controlledBot.setLastdestination(next);
		Koordinate feld = this.controlledBot.getKoordinate();
		Field lastPosition = this.map.getField(feld);
		this.controlledBot.setLastPosition(lastPosition);
		this.log.print("Gehe zu Feld: "+ next.getX()+"|"+next.getY());
		String dir = map.getDir(this.controlledBot.getKoordinate(), next.getKoordinate());
		this.log.print("Bewege mich als nächstes in Richtung:"+ dir);
		return "MOVE "+ dir + " " + this.controlledBot.turnView(3)+"|";
	}
	
	private void calcRedRating(Field f, int distance)
	{
		//Idee: Gehe zu nächster Wand und dieser endlang 
		
		f.setRating(distance+f.getToxic());
		/*if(distance !=0)
		{
			f.setRating(distance+f.getToxic());
		}
		else
		{
			f.setRating(f.getToxic());
		}*/
	}
	private void calcBlueRating(Field f, int distance)
	{
		double reversedistance;
		if(distance !=0)
		{
			reversedistance = 1/distance;
		}
		else
		{
			reversedistance = 0;
		}
		if(f.equals(this.controlledBot.getLastPosition()))
		{
			Koordinate bot = this.controlledBot.getKoordinate();
			Field botField = this.map.getField(bot);
			if(botField.getToxic()>f.getToxic())
			{
				f.setRating(f.getToxic()-0.01+reversedistance);
			}
			else
			{
				f.setRating(f.getToxic()+reversedistance);
			}
		}
		else
		{
			if(distance !=0)
			{
				f.setRating(reversedistance+f.getToxic());
			}
			else
			{
				f.setRating(f.getToxic());
			}
		}

		
	}
}
