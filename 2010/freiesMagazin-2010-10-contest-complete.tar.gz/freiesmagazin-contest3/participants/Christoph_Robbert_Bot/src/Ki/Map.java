package Ki;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import Util.Koordinate;

public class Map 
{
	private Field[][] map;
	private HashMap<String,Player> player = new HashMap<String,Player>(20);
	
	public Map()
	{

		
	}
	public void parseMap(String path)
	{
		try 
		{
			FileInputStream fis = new FileInputStream(path);
			Scanner in = new Scanner(fis);
			ArrayList<String> lines = new ArrayList<String>();
			for(int i =0; in.hasNextLine();i++)
			{
				lines.add(in.nextLine());
			}
			map = new Field[lines.get(0).length()][lines.size()];
			for(int i =0; i<lines.size();i++)
			{
				String line = lines.get(i);
				for (int j=0; j<line.length();j++)
				{
					char typ = line.charAt(j);
					if(typ =='#')
					{
						map[j][i] = new Field(true,j,i);
					}
					else
					{
						map[j][i] = new Field(false,j,i);
					}
				}
			}
			for(int i =0; i<map.length;i++)
			{
				for(int j =0; j<map[i].length;j++)
				{
					char c =' ';
					if(map[i][j].isWall())
						c = '#';
					System.out.print(c);
				}
				System.out.println();
			}
			System.out.println("Map parse ready");
		} 
		catch (FileNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Koordinate getKoordinate(int x, int y)
	{
		Field f = map[x][y];
		return f.getKoordinate();
	}
	
	public boolean isWall(int x, int y)
	{
		Field f = map[x][y];
		return f.isWall();
	}
	
	public double getToxic(int x, int y)
	{
		Field f = map[x][y];
		return f.getToxic();
	}
	
	public void setToxic(Koordinate k, double toxic)
	{
		//System.out.println("Größe der Map in x-Richtung: " +map.length + "KoordinateX: "+k.getX());
		//System.out.println("Größe der Map in y-Richtung: " +map[0].length + "KoordinateX: "+k.getY());
		map[k.getX()][k.getY()].setToxic(toxic);
	}
	
	public ArrayList<Field> getFieldsarround(Koordinate k)
	{
		ArrayList<Field> fields = new ArrayList<Field>(8);
		if(this.getField(k.getX()+1,k.getY())!=null)
		{ 	// Feld south
			fields.add(this.getField(k.getX()+1,k.getY()));
		}
		if(this.getField(k.getX(),k.getY()+1)!=null)
		{	//Feld east
			fields.add(this.getField(k.getX(),k.getY()+1));
		}
		if(this.getField(k.getX()-1,k.getY())!=null)
		{	//Feld north
			fields.add(this.getField(k.getX()-1,k.getY()));
		}
		if(this.getField(k.getX(),k.getY()-1)!=null)
		{	//Feld west
			fields.add(this.getField(k.getX(),k.getY()-1));
		}
		if(this.getField(k.getX()-1,k.getY()-1)!=null)
		{	//Feld north_West
			Field north = this.getField(k.getX()-1,k.getY());
			Field west = this.getField(k.getX(),k.getY()-1);
			if(north !=null && west!= null && !north.isWall() && ! west.isWall())
			{
				fields.add(this.getField(k.getX()-1,k.getY()-1));
			}
		}
		if(this.getField(k.getX()-1,k.getY()+1)!=null)
		{	//Feld north_east
			Field north = this.getField(k.getX()-1,k.getY());
			Field east = this.getField(k.getX(),k.getY()+1);
			if(north !=null && east!= null && !north.isWall() && ! east.isWall())
			{
				fields.add(this.getField(k.getX()-1,k.getY()+1));
			}

		}
		if(this.getField(k.getX()+1,k.getY()-1)!=null)
		{	//Feld sout_west
			Field west = this.getField(k.getX(),k.getY()-1);
			Field south = this.getField(k.getX()+1,k.getY());
			if(south !=null && west!= null && !south.isWall() && !west.isWall())
			{
				fields.add(this.getField(k.getX()+1,k.getY()-1));
			}

		}
		if(this.getField(k.getX()+1,k.getY()+1)!=null)
		{	//Feld sout_east
			Field east = this.getField(k.getX(),k.getY()+1);
			Field south = this.getField(k.getX()+1,k.getY());
			if(south !=null && east!= null && !south.isWall() && ! east.isWall())
			{
				fields.add(this.getField(k.getX()+1,k.getY()+1));
			}
		}
		return fields;
	}
	
	public String getDir(Koordinate aktuell, Koordinate next)
	{
		int x = aktuell.getX() - next.getX();
		int y = aktuell.getY() - next.getY();
		//System.out.println("Differenzen: "+ x + " "+y);
		String s = "";
		if(y== -1)
			s = "SOUTH";
		if(y == 1)
			s = "NORTH";
		if(x !=0 && y!=0)
			s = s+"_";
		if(x == -1)
			s = s+"EAST";
		if(x == 1)
			s = s+"WEST";
		if(s.equals(""))
			s = "NONE";
		return s;
	}
	public Field getField(int x, int y)
	{
		Koordinate k = new Koordinate(x,y);
		return this.getField(k);
	}
	public Field getField(Koordinate k)
	{
		if(k.getX()<0 || k.getX()>=map.length || k.getY()<0 || k.getY()>=map.length)
		{
			return null;
		}
		else
		{
			return map[k.getX()][k.getY()];
		}
	}
	
	
	public void addPlayer(String id)
	{
		Player p = new Player(id);
		this.player.put(id, p);
	}
	
	public Player getPlayer(String id)
	{
		return this.player.get(id);
	}
	
	public ArrayList<Player> getPlayers(boolean red)
	{
		ArrayList<Player> players = new ArrayList<Player>();
		players.addAll(this.player.values());
		ArrayList<Player> retval = new ArrayList<Player>(players.size());
		for(Player p: players)
		{
			if(red = p.isRed())
			{
				retval.add(p);
			}
		}
		return retval;
	}
	
}
