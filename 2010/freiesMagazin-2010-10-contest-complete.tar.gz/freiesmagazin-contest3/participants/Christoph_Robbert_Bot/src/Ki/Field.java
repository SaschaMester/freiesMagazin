package Ki;

import Util.Koordinate;

public class Field 
{
	private double toxic =0.00;
	private final boolean wall;
	private final int x;
	private final int y;
	private double rating;
	
	public Field(boolean wall, int x, int y)
	{
		this.x = x;
		this.y = y;
		this.wall = wall;
		if(wall)
			toxic = 1;
	}
	
	public Koordinate getKoordinate()
	{
		return new Koordinate(this.x, this.y);
	}

	public double getToxic() {
		return toxic;
	}

	public void setToxic(double toxic) {
		this.toxic = toxic;
	}

	public boolean isWall() {
		return wall;
	}


	public int getX() {
		return x;
	}


	public int getY() {
		return y;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + x;
		result = prime * result + y;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Field other = (Field) obj;
		if (x != other.x)
			return false;
		if (y != other.y)
			return false;
		return true;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}
}
