package Ki;

import Util.Koordinate;

public class Player 
{
	private final String ID;
	private boolean red;
	private Koordinate position;
	private double life;
	public Player(String id) 
	{
		super();
		this.ID=id;
	}
	public boolean isRed() {
		return red;
	}
	public void setRed(boolean red) {
		this.red = red;
	}
	public Koordinate getPosition() {
		return position;
	}
	public void setPosition(Koordinate position) {
		this.position = position;
	}
	public double getLife() {
		return life;
	}
	public void setLife(double life) {
		this.life = life;
	}
	public String getID() {
		return ID;
	}
	
	
}
