package Ki;

import Util.Koordinate;

public class Bot
{
	private final int ID;
	private int lookAt = 0;
	private double lastToxic = 0.2;
	private int posX =0;
	private int posY =0;
	private Field lastdestination = null;
	private Field lastPosition = null;
	private Field lastlastPosition =null;
	private boolean isRED = false;
	private String[] directions = {"NORTH","NORTH_WEST","WEST","SOUTH_WEST","SOUTH","SOUTH_EAST","EAST","NORTH_EAST"}; 
	private double life;
	
	public Bot(int ID)
	{
		this.ID = ID;
	}
	
	
	public void setView(String lookAt)
	{
		this.lookAt = this.getIntDirection(lookAt);
	}
	
	public Koordinate getKoordinate()
	{
		return new Koordinate(posX, posY);
		
	}
	
	public void setKoordinate(Koordinate k)
	{
		this.posX = k.getX();
		this.posY = k.getY();
	}
	
	public void setPosition(String position)
	{
		String[] parts = position.split(",");
		posX = Integer.parseInt(parts[0]);
		posY = Integer.parseInt(parts[1]);
	}
	
	
	public int getIntDirection(String s)
	{
		if(s.equals("NORTH"))
			return 0;
		if(s.equals("NORTH_WEST"))
			return 1;
		if(s.equals("WEST"))
			return 2;
		if(s.equals("SOUTH_WEST"))
			return 3;
		if(s.equals("SOUTH"))
			return 4;
		if(s.equals("SOUTH_EAST"))
			return 5;
		if(s.equals("EAST"))
			return 6;
		else
			return 7;
	}
	
	public String turnView(int dir)
	{
		if(dir <0)
		{
			this.lookAt = (8+(this.lookAt-Math.abs(dir))%8)%8;
		}
		else
		{
			this.lookAt = (this.lookAt+dir)%8;
		}
		//System.out.println(this.directions[this.lookAt]);
		return this.directions[this.lookAt];
	}


	public Field getLastdestination() {
		return lastdestination;
	}


	public void setLastdestination(Field lastdestination) {
		this.lastdestination = lastdestination;
	}


	public boolean isRED() {
		return isRED;
	}


	public void setRED(boolean isRED) {
		this.isRED = isRED;
	}


	public double getLife() {
		return life;
	}


	public void setLife(double life) {
		this.life = life;
	}


	public int getID() {
		return ID;
	}


	public Field getLastPosition() {
		return lastPosition;
	}


	public void setLastPosition(Field lastPosition) {
		this.lastlastPosition = this.lastPosition;
		this.lastPosition = lastPosition;
	}


	public Field getLastlastPosition() {
		return lastlastPosition;
	}


}
