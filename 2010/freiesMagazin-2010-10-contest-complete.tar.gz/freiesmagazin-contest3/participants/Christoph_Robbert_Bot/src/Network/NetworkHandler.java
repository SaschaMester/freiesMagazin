package Network;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PipedOutputStream;
import java.io.Reader;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.util.regex.Pattern;

public class NetworkHandler extends Thread
{
	private Socket client;
	private InputStreamReader in;
	private OutputStreamWriter out;
	private boolean running = true;
	private OutputStreamWriter pipeToKi;
	public NetworkHandler(PipedOutputStream pipe) throws UnknownHostException, IOException
	{
		this.pipeToKi = new OutputStreamWriter(pipe);
		System.out.println("Baue Verbindung auf");
		this.client = new Socket("localhost",15000);
		System.out.println("Verbindung aufgebaut. Warte auf Antwort");
		in = new InputStreamReader(this.client.getInputStream());
		out = new OutputStreamWriter(this.client.getOutputStream());
	}
	
	public void write(String s)
	{
		try {
			out.write(s);
			out.flush();
			System.out.println("out: "+s);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override 
	public void run()
	{
		
		try {
			out.write("ID_OKAY|");
			out.flush();
			String buffer ="";
			while(running)
			{
				char in = ' ';
				char[]help = new char[1];
				StringBuilder input = new StringBuilder();
				do
				{
					this.in.read(help);
					in = help[0];
					input.append(in);
				}while(in !='|');
				if(input.toString().equals("DISCONNECT|"))
				{
					this.running = false;
				}
				this.pipeToKi.write(input.toString()+"\n");
				this.pipeToKi.flush();
				//if(!input.toString().startsWith("PING"))
					//System.out.println("in: "+input.toString());
				
			}
			this.client.close();
			System.out.println("Verbindung beendet");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
