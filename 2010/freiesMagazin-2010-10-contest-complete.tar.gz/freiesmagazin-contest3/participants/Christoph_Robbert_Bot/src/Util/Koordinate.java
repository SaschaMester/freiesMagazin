package Util;

public class Koordinate 
{
	private int x;
	private int y;
	
	public Koordinate(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
	
	public Koordinate(String s)
	{
		String[] in = s.split(",");
		this.x = Integer.parseInt(in[0]);
		this.y = Integer.parseInt(in[1]);
	}
	
	public int getDistanceTo(Koordinate other)
	{
		int difX = Math.abs(this.x - other.x);
		int difY = Math.abs(this.y - other.y);
		int nichtDiagonal = Math.abs(difX-difY);
		int diagonal = (Math.max(difX, difY)-nichtDiagonal);
		return diagonal + nichtDiagonal;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	@Override
	public String toString() {
		return  x + "|" + y;
	}
	
}
