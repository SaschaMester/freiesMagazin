package Util;
import java.util.Date;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

public class LogWriter
{
	Logger log;
	boolean verbose;
	
	// Einstellungen und co siehe http://openbook.galileocomputing.de/javainsel8/javainsel_25_001.htm#mjf2da30f508a50e5d36d95b86f6359b05
	public LogWriter(boolean verbose, Date date)
	{
		super();
		this.verbose = verbose;
		log = Logger.getLogger("Log Synch it!");
		log.info(date.toString());
		//BasicConfigurator.configure();
		
	}
	
	public void print(String logtext)
	{
		log.debug(logtext);
		if(verbose)
			System.out.println(logtext);
	
	}
	
	
	public void print(Exception e)
	{
		log.error("Exception",e);
		log.error(e.getStackTrace().toString());
		if(verbose)
			e.printStackTrace();
	}

	public void printInfo(String s) {
		log.info(s);
		if(verbose)
			System.out.println(s);
		
	}



}