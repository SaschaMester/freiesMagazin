// * This file is released under the GPLv3.
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.net.UnknownHostException;

import Ki.ki;
import Network.NetworkHandler;


public class main 
{
	public static void main(String args[]) throws UnknownHostException, IOException
	{
		PipedOutputStream pos = new PipedOutputStream(); 
		PipedInputStream  pis = new PipedInputStream();
		pos.connect(pis);
		NetworkHandler nw = new NetworkHandler(pos);
		new ki(pis,nw).start();
		nw.start();
	}
}
