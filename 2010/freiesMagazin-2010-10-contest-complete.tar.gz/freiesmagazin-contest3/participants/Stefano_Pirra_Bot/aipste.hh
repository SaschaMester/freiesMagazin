/**
    (C) Copyright 2010 Stefano Pirra

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef AIPSTE_HH
#define AIPSTE_HH

// Own
/////////
#include "../ai/aiengine.hh"

// Qt
///////
#include <QObject>


// I'll store some info when evaluating the map
class MapPos
{
public:
    MapPos(QPoint p, int rate, int dist, int tox, Direction dir)
    {
        pt = p;
        score = rate;
        distance = dist;
        toxic = tox;
        from = dir;
    };

public:
    QPoint 	pt;
    int         score;          //the cost to reach 'pt'
    int		distance;       //the distance in moves between me and 'pt'
    int         toxic;          //the normalized toxic value of 'pt'
    Direction 	from;           //how do I reached this 'pt' ?
};

// I'll store here the toxic values while I'm learning them
/*
class ToxicPos
{
public:
    ToxicPos(QPoint pt) {point = pt; toxic=0;};
    ToxicPos(QPoint pt, double tx) {point = pt; toxic=tx;};

    bool operator==(const ToxicPos &other) const { return point == other.point; };

public:
    QPoint point;
    double toxic;
};*/

// The engine
class AiPste : public AiEngine
{
Q_OBJECT

public:
    AiPste();

protected:
    void processCommandStoreToxicValue();

private:
    // the move
    bool calcNextMove( Direction& move, Direction& view );

private:
    int     weightEnemyRed;     // the repulsive weight of an enemy
    int     weightEnemyBlue;    // the repulsive weight of an enemy
    int     weightFriendRed;    // the repulsive weight of a friend
    int     weightFriendBlue;   // the repulsive weight of a friend
    int     weightDoor;         // the attractive weight of a door
    int     weightTox;          // repulsion of known toxic values

    int             seekRadius; // the radius where I'll seek others
    Direction       prevDir;    // I'll try to keep my actual direction
    Direction       prevView;   // I'll round my view (as a radar)

    // euristic
    Direction evalSquare(int sqrRadius);
};

#endif //AIPSTE_HH
