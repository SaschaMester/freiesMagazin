/**
    (C) Copyright 2010 Stefano Pirra

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
//#include "aiengine.hh"
#include "aipste.hh"
#include "trace.hh"

// Sys
/////////
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <QList>
#include <qdatetime.h>
#include <math.h>

/*#define PSTEDBG*/

#define MYDIFF(x,y) (x) > (y) ? (x-y) : (y-x)

// Copy Constructor
AiPste::AiPste() : AiEngine()
{
    // init
    weightEnemyBlue     = -100;
    weightEnemyRed      = 100;
    weightFriendBlue    = 50;
    weightFriendRed     = 10;
    weightDoor          = 5;
    weightTox           = 200;

    // init the radius
    seekRadius      = 50;

    // randomic start positioning
    prevDir = (Direction)(rand()%(DIRECTION_NORTH_EAST)+1);
    prevView = (Direction)(rand()%(DIRECTION_NORTH_EAST)+1);
}

/* ================================================================ */

// 
Direction _rightDir(Direction d)
{
	if (d == DIRECTION_NORTH_EAST)
		return DIRECTION_NORTH;
	return (Direction)(d+1);
}

Direction _leftDir(Direction d)
{
	if (d == DIRECTION_NORTH)
		return DIRECTION_NORTH_EAST;
	return (Direction)(d-1);
}

// get the direction from p1 to p2
Direction _getDirection(QPoint p1, QPoint p2)
{
	if (p2.x() == p1.x())
	{
		if (p2.y() == p1.y())
			return DIRECTION_NONE;
		else if (p2.y() < p1.y()) //y is inverted
			return DIRECTION_NORTH;
		else 
			return DIRECTION_SOUTH;
	}
	else if (p2.x() > p1.x())
	{
		if (p2.y() == p1.y())
			return DIRECTION_EAST;
		else if (p2.y() < p1.y()) //y is inverted
			return DIRECTION_NORTH_EAST;
		else
			return DIRECTION_SOUTH_EAST;
	}
	else //if (p2.x() < p1.x())
	{
		if (p2.y() == p1.y())
			return DIRECTION_WEST;
		else if (p2.y() < p1.y()) //y is inverted
			return DIRECTION_NORTH_WEST;
		else
			return DIRECTION_SOUTH_WEST;
	}
}

// given a reference point and a direction, returns the point in that direction
QPoint _getPoint(QPoint p, Direction dir)
{
	switch (dir)
    {
    case DIRECTION_NORTH:
		return QPoint(p.x(), p.y()-1);
    case DIRECTION_NORTH_WEST:
        return QPoint(p.x()-1, p.y()-1);
    case DIRECTION_WEST:
        return QPoint(p.x()-1, p.y());
    case DIRECTION_SOUTH_WEST:
        return QPoint(p.x()-1, p.y()+1);
    case DIRECTION_SOUTH:
        return QPoint(p.x(), p.y()+1);
    case DIRECTION_SOUTH_EAST:
        return QPoint(p.x()+1, p.y()+1);
    case DIRECTION_EAST:
        return QPoint(p.x()+1, p.y());
    case DIRECTION_NORTH_EAST:
        return QPoint(p.x()+1, p.y()-1);
    default:
        // ignore it
        return p;
    }
}

// calculate the 'distance' between two directions (I'll try to go straight)
int _distance(Direction d1, Direction d2)
{
	return (int)(MYDIFF(d1,d2));
}

double _pitagoricDistance(QPoint p1, QPoint p2)
{
    int x1 = MYDIFF(p1.x(), p2.x());
    int y1 = MYDIFF(p1.y(), p2.y());
    int a = MYDIFF((x1*x1), (y1*y1));
    return sqrt(a);
}

// searches if a point is contained in the given list of known (evaluated) points
int _find(QPoint p, QList<MapPos> l)
{
	for (int i=0; i < l.count(); i++)
                if (l[i].pt == p)
			return i;
	return -1;
}

bool _isNear(QPoint p1, QPoint p2)
{
	for (int dir=1; dir<=(int)DIRECTION_NORTH_EAST; dir++)
		if (_getPoint(p1,(Direction)dir) == p2)
			return true;
	return false;
}

// dbg stuff
void _dumpMap(const GameMap* gm, Player* myself, PlayerList* pl, QList<MapPos> markPoints)
{
	QSize sm = gm->getSize();
	QPoint myPos = myself->getPosition();
	QList<int> playerIds = pl->getListOfIds();
	QList<QPoint> playerPoints; //this is aligned with the playerIds (raw coding :)
        int yy;
	
        //
        for (yy = 0; yy < playerIds.count(); yy++)
	{
             QPoint pp = pl->getPosition(playerIds[yy]);
             playerPoints.append(pp);
	}
	 
	for (int i=0;i<sm.height(); i++)
	{
		for (int j=0;j<sm.width(); j++)
		{
			QPoint pp(j,i);
			
			// 
                        int enemyId = -1;
			Team enemyTeam = TEAM_BLUE;
                        int idx = playerPoints.indexOf(pp);
                        if (idx >= 0)
			{
                            enemyId = playerIds[idx];
                            enemyTeam = pl->getTeam(playerIds[idx]);
                        }
			
                        // print my cell
                        if (pp == myPos)
			{
                            printf("[%2d%c]", myself->getIndex(), (myself->getTeam() == TEAM_RED)?'R':'B');
			}
                        // print enemies
                        else if (enemyId != -1)
			{
                            printf("(%2d%c)", enemyId, (enemyTeam == TEAM_RED)?'R':'B');
			}
            /*else if ((yy = _find(pp,markPoints)) != -1)
			{
                                MapPos tmp = markPoints[yy];
                                printf("%2s.%-2d",Player::toShortString(tmp.from).toAscii().constData(), tmp.score);
                        }*/
                        // print blocks, score, gas ,...
                        else
			{
				int ii = -1;
				if (_isNear(pp,myself->getPosition()) && ((ii = _find(pp,markPoints)) != -1) )
				{
                                    //if ((ii = _find(pp,markPoints)) != -1)
                                    {
                                            MapPos tmp = markPoints[ii];
                                            printf("%-2s%3d",Player::toShortString(tmp.from).toAscii().constData(), tmp.score);
                                    }
				}
				else
				{
                                    Field fm = (*gm)[pp];
                                    double tx = fm.getToxicValue();
                                    if (fm.isType(FT_BLOCK))
                                            printf("#####");
                                    else
                                    {
                                            if (tx == 0.01)
                                                    printf("|___|");
                                            else if (tx>0)
                                            {
                                                    //default = 0.01; it must be a digit between 1 and 9 so the range is 0.02 to 0.18
                                                    int mx = (int)((tx*100)/2);
                                                    printf("|_%2d|", mx);
                                            }
                                            else
                                                    printf("_____");
                                    }
				}
			}
		}
		std::cout << "\n";
	}	
}

// is that position reachable? (inside the map, there's a wall, I can go there in myt next move)?
bool _canMove(GameMap* gm, QPoint from, QPoint to)
{	
	//is inside the map?
        if (gm->isValidPos(to))
	{
                Field f = (*gm)[to];
		//is not a wall?
		if (!f.isType(FT_BLOCK))
		{
			//is not a diagonal behind a wall?
			Direction d = _getDirection(from,to);
			
			bool checkDiagonal = false;
			QPoint tmp1(0,0);
			QPoint tmp2(0,0);
			if (d == DIRECTION_NORTH_EAST)
			{
				tmp1 = _getPoint(from, DIRECTION_NORTH);
				tmp2 = _getPoint(from, DIRECTION_EAST);
				checkDiagonal = true;
			}
			if (d == DIRECTION_NORTH_WEST)
			{
				tmp1 = _getPoint(from, DIRECTION_NORTH);
				tmp2 = _getPoint(from, DIRECTION_WEST);
				checkDiagonal = true;
			}
			if (d == DIRECTION_SOUTH_EAST)
			{
				tmp1 = _getPoint(from, DIRECTION_SOUTH);
				tmp2 = _getPoint(from, DIRECTION_EAST);
				checkDiagonal = true;
			}
			if (d == DIRECTION_SOUTH_WEST)
			{
				tmp1 = _getPoint(from, DIRECTION_SOUTH);
				tmp2 = _getPoint(from, DIRECTION_WEST);
				checkDiagonal = true;
			}
			
			if (checkDiagonal)
			{
                                if (gm->isValidPos(tmp1) && (*gm)[tmp1].isType(FT_BLOCK))
						return false;
                                if (gm->isValidPos(tmp2) && (*gm)[tmp2].isType(FT_BLOCK))
						return false;
			}
			
			//done :)
			return true;
		}
	}
	return false;
}

bool _isDoor(const GameMap* gm, QPoint p)
{	
	if (gm->isValidPos(p))
	{
		Field f;
		Field f1;
		Field f2;
		
		QPoint p1 = _getPoint(p, DIRECTION_NORTH);
		QPoint p2 = _getPoint(p, DIRECTION_SOUTH);
	
		f = (*gm)[p];
		if (gm->isValidPos(p1))
		{
			f1 = (*gm)[p1];
			
			if (gm->isValidPos(p2))
			{
				f2 = (*gm)[p2];
				
				// check
				if (!f.isType(FT_BLOCK) && f2.isType(FT_BLOCK) && f1.isType(FT_BLOCK))
					return true;
			}
		}
		
		p1 = _getPoint(p, DIRECTION_EAST);
		p2 = _getPoint(p, DIRECTION_WEST);
	
		f = (*gm)[p];
		if (gm->isValidPos(p1))
		{
			f1 = (*gm)[p1];
			
			if (gm->isValidPos(p2))
			{
				f2 = (*gm)[p2];
				
				// check
				if (!f.isType(FT_BLOCK) && f2.isType(FT_BLOCK) && f1.isType(FT_BLOCK))
					return true;
			}
		}
	}
	
	return false;
}

Direction _nearestDirection(GameMap* gm, QPoint p0, Direction dir)
{
    //
    QPoint p = _getPoint(p0, dir);
    Direction d = dir;
    if (_canMove(gm, p0, p))
        return dir;
    //
    d = _leftDir(dir);
    p = _getPoint(p, d);
    if (_canMove(gm, p0, p))
        return dir;
    //
    d = _rightDir(dir);
    p = _getPoint(p, d);
    if (_canMove(gm, p0, p))
        return dir;
    //
    d = _leftDir(_leftDir(dir));
    p = _getPoint(p, d);
    if (_canMove(gm, p0, p))
        return dir;
    //
    d = _rightDir(_rightDir(dir));
    p = _getPoint(p, d);
    if (_canMove(gm, p0, p))
        return dir;
    //
    d = _leftDir(_leftDir(_leftDir(dir)));
    p = _getPoint(p, d);
    if (_canMove(gm, p0, p))
        return dir;
    //
    d = _rightDir(_rightDir(_rightDir(dir)));
    p = _getPoint(p, d);
    if (_canMove(gm, p0, p))
        return dir;

    //
    return _leftDir(_leftDir(_leftDir(_leftDir(dir))));
}

/* ================================================================ */

void AiPste::processCommandStoreToxicValue()
{
    m_map[m_client.getPosition()].setToxicValue(m_client.getDoubleValue());

    //ToxicPos tp(m_client.getPosition(), m_client.getDoubleValue());
    //knownToxicValues.append(tp);

    //printf("(%d,%d)[%f]", m_client.getPosition().x(), m_client.getPosition().y(), tx);
}

bool AiPste::calcNextMove(Direction& move, Direction& view) // const
{
        Direction d1 = evalSquare(seekRadius);
        move = d1;
        prevDir = d1;

        prevView = _leftDir(_leftDir(prevView));//(Direction)((prevView+1) % (DIRECTION_NORTH_EAST+1));
        view = prevView;

        return true;
}

// Calculate an heuristic over each reachable point in a square
// surrounding the player.
Direction AiPste::evalSquare(int sqrRadius) // const
{
    QTime elaps;
    elaps.start();

    #ifdef PSTEDBG
    printf("************* PLAYER[%d] ROUND[%d] SEEKRADIUS[%d] LOOKING[%s]\n",
           m_player.getIndex(),
           m_player.getNumRoundsInTeam(TEAM_RED)+m_player.getNumRoundsInTeam(TEAM_BLUE),
           this->seekRadius,
           Player::toShortString(m_player.getView()).toAscii().constData()
           );
    #endif

    // init
    Direction rtn = DIRECTION_NONE;
    QPoint ref;

    // my infos
    QPoint myPoint = m_player.getPosition();
    Team myTeam = m_player.getTeam();
    #ifdef PSTEDBG 
    int myId = m_player.getIndex();
    #endif
    // double myLife = m_player.getLife();
    //Direction myDir = m_player.getView();

    // navigate the map to obtain a list of reachable points
    QList<MapPos> squareNav;

    /* SEEKING ENGINE */

    // get top-left
    ref = QPoint(myPoint.x() - 1, myPoint.y() - 1);
    int radiusExplored = 1;
    // navigate the 8 neighbours of me
    for (int h = 0; h < 3; h++)
    {
            for (int w = 0; w < 3; w++)
            {
                    if (!(h==radiusExplored && w==radiusExplored)) //avoid myself
                    {
                            QPoint hp(ref.x()+w, ref.y()+h);

                            if ( m_map.isValidPos(hp) )
                            {
                                    //normalize to toxic value (to be used with scores)
                                    int tox = (m_map[hp].getToxicValue() * weightTox);

                                    if (_canMove(&m_map, myPoint, hp))
                                    {
                                        Direction dir = _getDirection(myPoint, hp);
                                        int doorW = 0;
                                        if (_isDoor(&m_map, hp))
                                            doorW = (-1 * weightDoor);

                                        MapPos mp(hp, 1 + tox + doorW, 1, tox, dir);
                                        squareNav.append(mp);
                                    }
                            }
                    }
            }
    }
    radiusExplored++;

    // we continue to expand, till we meet the radius
    bool noMoreWork = false;
    while (radiusExplored <= sqrRadius && noMoreWork == false)
    {
            QList<MapPos> tmpNav;

            // navigate the 8 neighbours of every good point we have
            for (int i = 0; i < squareNav.count(); i++)
            {
                    MapPos mp = squareNav[i];
                    if (mp.distance == (radiusExplored-1))
                    {
                            ref = QPoint(mp.pt.x()-1, mp.pt.y()-1);

                            for (int h = 0; h < 3; h++)
                            {
                                    for (int w = 0; w < 3; w++)
                                    {
                                            if (!(h==radiusExplored && w==radiusExplored)) //avoid myself
                                            {
                                                    QPoint hp(ref.x()+w, ref.y()+h);
                                                    if (m_map.isValidPos(hp))
                                                    {
                                                        //normalize to toxic value (to be used with scores)
                                                        int tox = (m_map[hp].getToxicValue() * weightTox);

                                                        if (_canMove(&m_map, mp.pt, hp))
                                                        {
                                                                int doorW = 0;
                                                                if (_isDoor(&m_map, hp))
                                                                    doorW = (-1 * weightDoor);

                                                                int idx = _find(hp,squareNav);
                                                                if (idx == -1)
                                                                {
                                                                        MapPos mpNew(hp, (mp.distance+1) + tox + doorW, mp.distance+1, tox, mp.from);
                                                                        tmpNav.append(mpNew);
                                                                }
                                                        }
                                                    }
                                            }
                                    }
                            }
                    }
            }

            // add the new points
            for (int ii = 0; ii < tmpNav.count(); ii++)
                    if (tmpNav[ii].pt != myPoint && _find(tmpNav[ii].pt, squareNav) == -1)
                            squareNav.append(tmpNav[ii]);

            //
            radiusExplored++;
            if (tmpNav.count() == 0)
                noMoreWork = true;
    }

    /* SEEKING ENGINE END */

    // searching the other players over my good points to eval the final score
    int preyCount = 0;
    QList<int> playerIds = m_otherPlayers.getListOfIds();
    for (int ii = 0; ii < playerIds.count(); ii++)
    {
            // validity check
            if (!m_otherPlayers.isInvalid(playerIds[ii]))
            {
                    // seek another player
                    QPoint otherpos = m_otherPlayers.getPosition(playerIds[ii]);
                    Team otherteam = m_otherPlayers.getTeam(playerIds[ii]);
                    int idx = _find(otherpos, squareNav);
                    if (idx != -1)
                    {
                            // get the other player
                            MapPos mpEnemy = squareNav[idx];
                            double enemyDist = (double)(mpEnemy.distance/10);
                            if (enemyDist == 0)
                                enemyDist = 1;

                            // get my closest point that will bring me there:
                            QPoint tmp = _getPoint(myPoint, mpEnemy.from);
                            idx = _find(tmp, squareNav);
                            if (idx != -1)
                            {
                                // update the point's score
                                double incrHi = 0;
                                if (myTeam == TEAM_RED)
                                {
                                    if (otherteam != myTeam)
                                        incrHi = weightEnemyBlue;
                                    else
                                        incrHi = weightFriendRed;
                                }
                                else
                                {
                                    if (otherteam != myTeam)
                                        incrHi = weightEnemyRed;
                                    else
                                        incrHi = weightFriendBlue;
                                }

                                double incrMed = (incrHi * 0.66);
                                double incrLo = (incrHi * 0.33);

                                #ifdef PSTEDBG
                                printf("[%d] ENEMYFOUND[%d] DISTANCE[%f] DIR[%s] SCORE[%f]\n",
                                       myId,
                                       playerIds[ii],
                                       enemyDist,
                                       Player::toShortString(mpEnemy.from).toAscii().constData(),
                                       (incrHi/enemyDist)
                                       );
                                #endif
                                squareNav[idx].score += (incrHi/enemyDist);

                                // nearest left neighbour (magnetic attraction / repulsion to the other players)
                                Direction dNear = _leftDir(mpEnemy.from);
                                tmp = _getPoint(myPoint, dNear);
                                idx = _find(tmp, squareNav);
                                if (idx != -1)
                                        squareNav[idx].score += (incrMed/enemyDist);

                                // nearest right neighbour (magnetic attraction / repulsion to the other players)
                                dNear = _rightDir(mpEnemy.from);
                                tmp = _getPoint(myPoint, dNear);
                                idx = _find(tmp, squareNav);
                                if (idx != -1)
                                        squareNav[idx].score += (incrMed/enemyDist);

                                // far left neighbour (magnetic attraction / repulsion to the other players)
                                dNear = _leftDir(_leftDir(mpEnemy.from));
                                tmp = _getPoint(myPoint, dNear);
                                idx = _find(tmp, squareNav);
                                if (idx != -1)
                                        squareNav[idx].score += (incrLo/enemyDist);

                                // far right neighbour (magnetic attraction / repulsion to the other players)
                                dNear = _rightDir(_rightDir(mpEnemy.from));
                                tmp = _getPoint(myPoint, dNear);
                                idx = _find(tmp, squareNav);
                                if (idx != -1)
                                        squareNav[idx].score += (incrLo/enemyDist);
                            }
                    }
            }
    }

    // The blood thirst is increasing...
    if (myTeam == TEAM_RED)
    {
        // adaptative reducing seek cost
        if ((elaps.elapsed() > 4700) && (seekRadius > 10))
            seekRadius--;
        // no prey: increment seeking range
        else if (preyCount == 0)
            seekRadius+=2;
    }

    // dbg
    #ifdef PSTEDBG
    _dumpMap(&m_map, &m_player, &m_otherPlayers, squareNav);
    #endif

    // Get the lowest score between my 8 neighbours
    ref = QPoint(myPoint.x() - 1, myPoint.y() - 1);
    MapPos mpFinal(QPoint(0,0),1000000,1000000,100,DIRECTION_NONE);
    for (int h = 0; h < 3; h++)
    {
            for (int w = 0; w < 3; w++)
            {
                    if (!(h==1 && w==1)) //avoid myself
                    {
                            QPoint hp(ref.x()+w, ref.y()+h);
                            int idx = _find(hp, squareNav);
                            if (idx != -1)
                            {
                                    MapPos mpTmp = squareNav[idx];
                                    if ((mpTmp.score < mpFinal.score) ||
                                            ((mpFinal.from != DIRECTION_NONE) && (mpTmp.score == mpFinal.score) && (_distance(prevDir,mpTmp.from) < _distance(prevDir,mpFinal.from))))
                                    {
                                            mpFinal = squareNav[idx];
                                    }
                            }
                    }
            }
    }

    // I've got the lowest score: finally let's move!
    if (mpFinal.from != DIRECTION_NONE)
    {
            rtn = mpFinal.from;
    }
    // Just to avoid standing: taking the 1st good point
    else if (rtn == DIRECTION_NONE && squareNav.count() > 0)
    {
            rtn = squareNav[0].from;
    }

    // dbg
    #ifdef PSTEDBG
            printf("----------------[%d] Score:[%d] Final Decision: %s. Elapsed: [%d] ms.\n\n", myId, mpFinal.score, Player::toString(rtn).toAscii().constData(), elaps.elapsed());
    #endif

    return rtn;
}

