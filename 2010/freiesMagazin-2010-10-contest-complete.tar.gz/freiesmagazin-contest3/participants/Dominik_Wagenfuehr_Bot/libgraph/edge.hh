/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef EDGE_HH
#define EDGE_HH

#include "edgeenums.hh"

// Forward declaration.
class Node;

// An edge connects two nodes.
class Edge
{
public:
    // Default constructor.
    Edge() : m_neighbor(0), m_distance(0.0), m_oldDistance(0.0),
             m_isOldDistanceStored(false), m_state(EDGE_STATE_NONE) {}
    
    // Destructor, nothing to do.
    virtual ~Edge() {}

    // Set a neighbor and it's distance for traveling.
    void setNeighborAndDistance( Node* newNeighbor, const double dist )
    {
        m_neighbor = newNeighbor;
        m_distance = dist;
        m_isOldDistanceStored = false;
    }

    // Return neighbor.
    Node* getNeighbor() const
    {
        return m_neighbor;
    }

    // Return distance
    double getDistance() const
    {
        return m_distance;
    }

    // Reset stored distance if there is any.
    // Return true if old distance has been restored.
    bool restoreOldDistance()
    {
        if ( m_isOldDistanceStored )
        {
            m_distance = m_oldDistance;
            m_isOldDistanceStored = false;
            return true;
        }
        return false;
    }

    // Overwrite current distance with a new value, but
    // store the old one.
    // If we already have stored an old distance, we will
    // restore this first.
    void overwriteDistance( const double dist )
    {
        if ( m_isOldDistanceStored )
        {
            // restore first
            restoreOldDistance();
        }

        // store old distance
        m_oldDistance = m_distance;
        m_isOldDistanceStored = true;
        
        // set new distance
        m_distance = dist;
    }
    
    // get edge state
    EdgeState getState() const
    {
        return m_state;
    }
    
    // set new edge state
    void setState( const EdgeState state )
    {
        m_state = state;
    }
    
protected:
    // Neighbor for this edge.
    Node* m_neighbor;
    
    // Distance for this edge.
    double m_distance;
    
    // Some stored distance if we have overwritten the old one.
    double m_oldDistance;
    
    // Flag if old distance has been stored.
    bool m_isOldDistanceStored;

    // state for this edge in Dijkstra algorithm.
    EdgeState m_state;
};

#endif // EDGE_HH
