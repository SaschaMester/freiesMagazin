/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef DIJKSTRA_HH
#define DIJKSTRA_HH

// Own
/////////
#include "direction.hh"

// Qt
/////////
#include <QList>
#include <QPoint>

// Forward declarations
///////////////////////////
class Node;
class Graph;

typedef QList<Node*> NodePointerList;

// Class for calculating shortest path from a
// given position to the end pos in the graph
// using Dijsktra's algorithm.
class Dijkstra
{
public:
    // Constructor setting graph and start position
    Dijkstra( const Graph& graph, const QPoint& startPos, const QPoint& endPos );

    // Destructor.
    ~Dijkstra();

    // Get shortest path from start to finish if calculated.
    // Return true if everything is okay
    bool getShortestPath( QList<QPoint>& path );

    // print the whole path with all nodes and states
    void printGraph() const;

private:

    // Init algorithm with start position and check graph.
    // Return true if everything is okay.
    bool init( const Graph& graph, const QPoint& startPos, const QPoint& endPos );

    // Search shortest path from start element in list.
    // Return true if everything is okay.
    bool searchShortestPath();

    // search the nearest node form the start node in the
    // list with node and unknown neighbors
    // and remove it form the list.
    Node* searchAndRemoveNearestNodeFromStart();
    
    // check all neighbors of this node and add them to
    // our list if necessary.
    // Return true if everything is okay.
    bool checkNeighbors( Node* node );
    
    // Add a new neighbor to the list and mark edge.
    // Return true if everything is okay
    bool addNeighborAndMarkEdge( Node* node, Node *neighbor,
                                 const Direction view );

    // Mark the edges to a neighbor new.
    // Return true if everything is okay.
    bool markEdgesToNeighbor( Node* node, Node* neighbor,
                              const Direction view );

    // print the node and all edges
    void printGraph( Node* node, NodePointerList& printedNodes ) const;
    
    ///////////////
    // Members
    ///////////////
    
    // List of nodes that we have visited and know the neighbors.
    NodePointerList m_knownNodeNeighborList;
    
    // List of nodes that we we do not know the neighbors yet.
    NodePointerList m_unknownNodeNeighborList;
    
    // Flag that the end pos is reachable.
    // This will set during the algorithm.
    bool m_endPosReachable;

    // Start node for dijkstra algorithm.
    Node* m_startNode;

    // End node for dijkstra algorithm.
    Node* m_endNode;
};

#endif // DIJKSTRA_HH
