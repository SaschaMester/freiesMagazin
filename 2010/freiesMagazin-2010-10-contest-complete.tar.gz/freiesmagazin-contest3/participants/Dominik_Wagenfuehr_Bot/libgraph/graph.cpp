/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "graph.hh"
#include "node.hh"
#include "gamemap.hh"
#include "player.hh"

// Qt
/////////
#include <QFile>
#include <QTextStream>
#include <QString>

// Sys
/////////
#include <iostream>

// Default constructor.
Graph::Graph()
    : m_size(0,0), m_valid(false)
{
}

// Default constructor.
Graph::Graph( const GameMap& originalBoard  )
    : m_size(0,0), m_valid(false)
{
    init( originalBoard );
}

// Copy constructor.
Graph::Graph( const Graph& graph )
    : m_size(0,0), m_valid(false)
{
    // set new size
    m_size = graph.m_size;
    
    if ( getWidth() > 0 && getHeight() > 0 )
    {
        // allocate enough memory for the tiles
        m_board.resize( getWidth()*getHeight() );

        for ( int jj = 0; jj < getHeight(); jj++ )
        {
            for ( int ii = 0; ii < getWidth(); ii++ )
            {
                if ( graph.m_board[graph.aPos(ii,jj)] )
                {
                    m_board[aPos(ii,jj)] = new Node( *graph.m_board[graph.aPos(ii,jj)] );
                }
                else
                {
                    m_board[aPos(ii,jj)] = 0;
                }
            }
        }
        
        // set validity status
        m_valid = true;
    }
}

// Destructor.
Graph::~Graph()
{
    clear();
}

// delete graph
void Graph::clear()
{
    for ( int jj = 0; jj < getHeight(); jj++ )
    {
        for ( int ii = 0; ii < getWidth(); ii++ )
        {
            if ( 0 != m_board[aPos(ii,jj)] )
            {
                // free memory
                delete m_board[aPos(ii,jj)];
                m_board[aPos(ii,jj)] = 0;
            }
        }
    }
}

// access node element
// boundary check only in debug version
Node* Graph::operator[] ( const QPoint& pos ) const
{
    if ( pos.x() < getWidth() &&
         pos.y() < getHeight() )
    {
        return m_board[aPos(pos)];
    }

    std::cerr << "Graph::operator[] "
              << " Access from ("
              << pos.x() << "," << pos.y()
              << ") is out of bounds ("
              << getWidth()-1 << "," << getHeight()-1
              << ")."
              << std::endl;

    return NULL;
}

// Init graph with given game board.
// Return true if everything is okay.
bool Graph::init( const GameMap& originalBoard )
{
    bool ok = false;
    
    // clear old graph at the beginning
    clear();

    // set new size
    m_size = originalBoard.getSize();
    
    if ( getWidth() > 0 && getHeight() > 0 )
    {
        // allocate enough memory for the tiles
        m_board.resize( getWidth()*getHeight() );

        bool memoryError = false;

#ifdef QT_DEBUG
        std::cout << "Graph::init "
                  << " Info: Pointer memory allocated for "
                  << getWidth()*getHeight()
                  << " elements."
                  << std::endl; 
#endif

        // allocate memory for new tiles
        for ( int jj = 0; jj < getHeight(); jj++ )
        {
            for ( int ii = 0; ii < getWidth(); ii++ )
            {
                m_board[aPos(ii,jj)] = new Node( QPoint(ii,jj) );
                
                if ( 0 == m_board[aPos(ii,jj)] )
                {
                    // memory could not be allocated.
                    memoryError = true;
                    
                    std::cerr << "Graph::init(GameMap) "
                              << " Error: Could not allocate memory at"
                              << " (" << ii << "," << jj << ")."
                              << std::endl; 
                    break;
                }
            }
            
            if ( memoryError )
            {
                break;
            }
        }

        //std::cout << "Graph::init(GameMap) "
                  //<< " Info: Tile memory allocated: "
                  //<< memoryError
                  //<< std::endl; 
        
        // only connect neighbors if all nodes could be allocated
        if ( !memoryError )
        {
            // init neighbors
            if ( initNeighbors( originalBoard ) )
            {
                ok = true;
            }
        }
    }
    
    // set validity status
    m_valid = ok;
    
    return ok;
}

// Init all neighbors on the board.
// Return true if everything is okay.
bool Graph::initNeighbors( const GameMap& originalBoard )
{
    bool ok = false;
    
    // go through the game board and create information
    // for the neighbors
    for ( int jj = 0; jj < getHeight(); jj++ )
    {
        for ( int ii = 0; ii < getWidth(); ii++ )
        {
            // set this position
            QPoint pos1(ii,jj);

            //std::cout << "Graph::initNeighbors(GameMap) "
                      //<< " Info: Befor "
                      //<< " Pos: " << pos1.x() << " " << pos1.y()
                      //<< " " << m_board[aPos(pos1)]
                      //<< " " << m_board[aPos(pos1)]->getNeighbor( BE_DIRECTION_LEFT )
                      //<< " " << m_board[aPos(pos1)]->getNeighbor( BE_DIRECTION_RIGHT )
                      //<< " " << m_board[aPos(pos1)]->getNeighbor( BE_DIRECTION_UP )
                      //<< " " << m_board[aPos(pos1)]->getNeighbor( BE_DIRECTION_DOWN )
                      //<< std::endl;
            
            // tile to the north
            if ( jj > 0 )
            {
                Direction view = DIRECTION_NORTH;
                QPoint pos2( ii, jj-1 );
                if ( !initNeighbors( originalBoard, pos1, pos2, view ) )
                {
                    return ok;
                }
            }
            
            // tile to the north west
            if ( ii > 0 && jj > 0 )
            {
                Direction view = DIRECTION_NORTH_WEST;
                QPoint pos2( ii-1, jj-1 );
                if ( !initNeighbors( originalBoard, pos1, pos2, view ) )
                {
                    return ok;
                }
            }
            
            // tile to the west
            if ( ii > 0 )
            {
                Direction view = DIRECTION_WEST;
                QPoint pos2( ii-1, jj );
                if ( !initNeighbors( originalBoard, pos1, pos2, view ) )
                {
                    return ok;
                }
            }

            // tile to the south west
            if ( ii > 0 && jj < getHeight()-1 )
            {
                Direction view = DIRECTION_SOUTH_WEST;
                QPoint pos2( ii-1, jj+1 );
                if ( !initNeighbors( originalBoard, pos1, pos2, view ) )
                {
                    return ok;
                }
            }

            // tile to the south
            if ( jj < getHeight()-1 )
            {
                Direction view = DIRECTION_SOUTH;
                QPoint pos2( ii, jj+1 );
                if ( !initNeighbors( originalBoard, pos1, pos2, view ) )
                {
                    return ok;
                }
            }

            // tile to the south east
            if ( ii < getWidth()-1 && jj < getHeight()-1 )
            {
                Direction view = DIRECTION_SOUTH_EAST;
                QPoint pos2( ii+1, jj+1 );
                if ( !initNeighbors( originalBoard, pos1, pos2, view ) )
                {
                    return ok;
                }
            }

            // tile to the east
            if ( ii < getWidth()-1 )
            {
                Direction view = DIRECTION_EAST;
                QPoint pos2( ii+1, jj );
                if ( !initNeighbors( originalBoard, pos1, pos2, view ) )
                {
                    return ok;
                }
            }

            // tile to the north east
            if ( ii < getWidth()-1 && jj > 0 )
            {
                Direction view = DIRECTION_NORTH_EAST;
                QPoint pos2( ii+1, jj-1 );
                if ( !initNeighbors( originalBoard, pos1, pos2, view ) )
                {
                    return ok;
                }
            }

#ifdef QT_DEBUG
            std::cout << "Graph::initNeighbors "
                      << " Info: After "
                      << " Pos: " << pos1.x() << " " << pos1.y()
                      << " " << m_board[aPos(pos1)]
                      << " " << m_board[aPos(pos1)]->getNeighbor( DIRECTION_NORTH )
                      << " " << m_board[aPos(pos1)]->getNeighbor( DIRECTION_NORTH_WEST )
                      << " " << m_board[aPos(pos1)]->getNeighbor( DIRECTION_WEST )
                      << " " << m_board[aPos(pos1)]->getNeighbor( DIRECTION_SOUTH_WEST )
                      << " " << m_board[aPos(pos1)]->getNeighbor( DIRECTION_SOUTH )
                      << " " << m_board[aPos(pos1)]->getNeighbor( DIRECTION_SOUTH_EAST )
                      << " " << m_board[aPos(pos1)]->getNeighbor( DIRECTION_EAST )
                      << " " << m_board[aPos(pos1)]->getNeighbor( DIRECTION_NORTH_EAST )
                      << std::endl;
#endif
        }
    }
    
    ok = true;
    
    return ok;
}

// Connect the node on pos1 with the node on pos2 if possible.
// Return true if possible.
bool Graph::initNeighbors( const GameMap& originalBoard,
                           const QPoint& pos1,
                           const QPoint& pos2,
                           const Direction view)
{
#ifdef QT_DEBUG
    std::cout << "Graph::initNeighbors(GameMap,pos1,pos2,view) "
              << " Info: "
              << " Pos1: (" << pos1.x() << "," << pos1.y() << ")"
              << " " << m_board[aPos(pos1)]
              << " Pos2: (" << pos2.x() << "," << pos2.y() << ")"
              << " " << m_board[aPos(pos2)]
              << " Dir " 
              << Player::toString( view ).toStdString()
              << std::endl;
#endif

    bool ok = false;
    
    // check if tiles exists on board
    if ( 0 != m_board[aPos(pos1)] && 0 != m_board[aPos(pos2)] &&
         originalBoard.isValidPos(pos1) && originalBoard.isValidPos(pos2) )
    {
        // get opposite view
        const Direction oppView = getOppositeDirection( view );

        // we will only check tiles that do not have a neighbor yet
        // otherwise we would set many tiles doubled
        if ( 0 == m_board[aPos(pos1)]->getNeighbor( view ) &&
             0 == m_board[aPos(pos2)]->getNeighbor( oppView ) )
        {
            // We can only move from pos1 to pos2 (and back)
            // if both field are not blocked.
            if ( !originalBoard[pos1].isType( FT_BLOCK ) &&
                 !originalBoard[pos2].isType( FT_BLOCK ) )
            {
                // Further for diagonal movement we must check if some of
                // the neighbored field is blocked.
                if ( !isBlockedByDiagonalMovement( originalBoard, pos2, view ) )
                {
                    // associate both neighbors
                    double dist = 1.0;
                    
                    // diagonal movements his a little bit better
                    if ( DIRECTION_NORTH_WEST == view ||
                         DIRECTION_SOUTH_WEST == view ||
                         DIRECTION_SOUTH_EAST == view ||
                         DIRECTION_NORTH_EAST == view )
                    {
                        dist = 0.95;
                    }
                    
                    if ( m_board[aPos(pos1)]->setNeighborAndDistance(view, m_board[aPos(pos2)], dist ) &&
                         m_board[aPos(pos2)]->setNeighborAndDistance(oppView, m_board[aPos(pos1)], dist ) )
                    {
                        ok = true;
                    }
                }
                else
                {
                    ok = true;
                }
            }
            else
            {
                ok = true;
            }
        }
        else
        {
            ok = true;
        }
    }
    else
    {
        std::cout << "Graph::initNeighbors(GameMap,pos1,pos2,view) "
                  << " Error: Some board pointer is NULL "
                  << " " << m_board[aPos(pos1)]
                  << " " << m_board[aPos(pos2)]
                  << " " << originalBoard.isValidPos(pos1)
                  << " " << originalBoard.isValidPos(pos2)
                  << "." << std::endl;
    }
    
    return ok;
}

// Return true if movement is diagonal and blocked by something.
bool Graph::isBlockedByDiagonalMovement( const GameMap& originalBoard,
                                         const QPoint& reachedPos,
                                         const Direction movement ) const
{
    bool blocked = false;

    // check if move was diagonal
    QPoint nField1;
    QPoint nField2;

    // For diagonal movements we must check if one
    // of the two neighboring fields is blocked
    // by a wall or a door.
    // A door is valid if the player has the key
    // for it.
    if ( isDiagonalMovement( nField1, nField2,
                             reachedPos, movement ) )
    {
#ifdef QT_DEBUG
        std::cout << "(II) Graph::isBlockedByDiagonalMovement "
                  << " Field1 "
                  << nField1.x() << " " << nField1.y()
                  << " Field2 "
                  << nField2.x() << " " << nField2.y()
                  << " Reached "
                  << reachedPos.x() << " " << reachedPos.y()
                  << " Dir "
                  << Player::toString( movement ).toStdString()
                  << std::endl;
#endif

        // diagonal movement, check neighbor fields
        // they must be valid
        if ( originalBoard[nField1].isType( FT_BLOCK ) ||
             originalBoard[nField2].isType( FT_BLOCK ) )
        {
            // one of the two fields is blocked
            // and we could not move there
            blocked = true;
        }
    }

    return blocked;
}

// Check if movement is diagonal and return the neighbored positions for it.
bool Graph::isDiagonalMovement( QPoint& field1, QPoint& field2,
                                const QPoint& reachedPos,
                                const Direction movement )
{
    bool diagonal = false;
    
    switch ( movement )
    {
    case DIRECTION_NORTH_WEST:
        Player::movePosition( field1, reachedPos, DIRECTION_SOUTH );
        Player::movePosition( field2, reachedPos, DIRECTION_EAST );
        diagonal = true;
        break;
    case DIRECTION_NORTH_EAST:
        Player::movePosition( field1, reachedPos, DIRECTION_SOUTH );
        Player::movePosition( field2, reachedPos, DIRECTION_WEST );
        diagonal = true;
        break;
    case DIRECTION_SOUTH_WEST:
        Player::movePosition( field1, reachedPos, DIRECTION_NORTH );
        Player::movePosition( field2, reachedPos, DIRECTION_EAST );
        diagonal = true;
        break;
    case DIRECTION_SOUTH_EAST:
        Player::movePosition( field1, reachedPos, DIRECTION_NORTH );
        Player::movePosition( field2, reachedPos, DIRECTION_WEST );
        diagonal = true;
        break;
    default:
        diagonal = false;
        break;
    }

    return diagonal;
}                  

// Save graph to disc
// as graphviz dot-file
// return true if everything is okay
bool Graph::saveGraphviz( const QString& filename ) const
{
    static const QString shortestPathColor = "orange";
    
    bool ok = false;

    if ( !filename.isEmpty() )
    {
        QFile data( filename );
 
        if ( data.open(QFile::WriteOnly | QFile::Truncate) )
        {
            QTextStream outFile(&data);

            const Node *endNode = NULL;

            outFile << "digraph G {" << endl;
            outFile << "    overlap = scalexy;" << endl;

            // first we will print all nodes
            for ( int jj = 0; jj < getHeight(); jj++ )
            {
                for ( int ii = 0; ii < getWidth(); ii++ )
                {
                    const Node* node = m_board[aPos(ii,jj)];
                    
                    //std::cout << "Graph::saveGraphviz "
                              //<< " Info:"
                              //<< " Pos: " << ii << " " << jj
                              //<< " " << node
                              //<< std::endl;

                    if ( node )
                    {
                        if ( !node->hasNoNeighbors() )
                        {
                            // use color green for even edges and nodes
                            QString color = "blue";

                            //std::cout << "Graph::saveGraphviz "
                                      //<< " Info:"
                                      //<< " Color: " << color.toStdString()
                                      //<< " Start: " << node->isStartNode()
                                      //<< " End: "   << node->isEndNode()
                                       //<< std::endl;

                            // print single node first
                            const bool isStartOrEnd = node->isStartNode() ||
                                                      node->isEndNode();

                            // save end node for later
                            if ( node->isEndNode() )
                            {
                                endNode = node;
                            }

                            QString tempColor = color;
                            if ( isStartOrEnd )
                            {
                                color = shortestPathColor;
                            }
                            saveGraphvizNode( outFile, ii, jj, node->getDistanceFromStart(),
                                              color, isStartOrEnd );
                            color = tempColor;
                            
                            for ( int kk = 0; kk < 8; kk++ )
                            {
                                const Direction view = Node::convertIntToView(kk);
                                
                                Node *neighbor = node->getNeighbor( view );
                                
                                if ( 0 != neighbor )
                                {
                                    tempColor = color;
                                    // if this is the shortes path mark it as shortestPathColor
                                    if ( EDGE_STATE_SHORTEST == node->getEdgeState( view ) )
                                    {
                                        color = shortestPathColor;
                                    }
                                    
                                    // get position of neighbor node
                                    const QPoint pos = neighbor->getPosition();
                                    saveGraphvizEdge( outFile, ii, jj, pos.x(), pos.y(),
                                                      node->getDistance( view ), color );
                                    color = tempColor;
                                }
                            }
                        }
                    }
                    else
                    {
                        std::cerr << "Graph::saveGraphviz(string) "
                                  << "Error: Node at "
                                  << ii << "," << jj
                                  << " is NULL."
                                  << std::endl;
                        return ok;
                    }
                }
            }

            // write shortest path separately
            // We must go from end to start to get the shortest path.
            const Node *lastNode = NULL;
            while ( 0 != endNode )
            {
                const QPoint pos = endNode->getPosition();

                // mark start node
                if ( endNode->isStartNode() )
                {
                    outFile << "  S [ label=\"\",shape=plaintext ]"
                        << endl;
                    outFile << "  S ->"
                            << "  \"" << pos.x() << "_" << pos.y() << "\" "
                            << "[ color="
                            << shortestPathColor
                            << " ];"
                            << endl;
                }

                // mark end node
                if ( endNode->isEndNode() )
                {
                    outFile << "  E [ label=\"\",shape=plaintext ]"
                            << endl;
                    outFile << "  \"" << pos.x() << "_" << pos.y() << "\" "
                            << " -> E"
                            << "[ color="
                            << shortestPathColor
                            << " ];"
                            << endl;
                }

                // only reprint the nodes between start and end
                if ( !endNode->isStartNode() && !endNode->isEndNode() )
                {
                    saveGraphvizNode( outFile, pos.x(), pos.y(),
                                      endNode->getDistanceFromStart(),
                                      shortestPathColor, true );
                }
                lastNode = endNode;
                endNode = endNode->getShortestPathPredecessor();
            }

            outFile << "}" << endl;
            
            data.close();

            ok = true;
        }
        else
        {
            std::cerr << "Graph::saveGraphviz(string) "
                      << "Error: File "
                      << filename.toStdString()
                      << " could not be opened."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "Graph::saveGraphviz(string) "
                  << "Error: Filename is empty."
                  << std::endl;
    }

    return ok;
}

// Save single node to outstream in graphviz format.
void Graph::saveGraphvizNode( QTextStream& outFile,
                              const int x, const int y,
                              const double dist,
                              const QString& color,
                              const bool isEndNode ) const
{
    outFile << "  \"" << x << "_" << y << "\""
            << " [ "
            << " label=\"(" << x << "," << y << ") " << dist << "\","
            << "color=" << color << ",";
    
    // fill end node with color to see it better
    if ( !isEndNode )
    {
        outFile << "fontcolor=" << color;
    }
    else
    {
        outFile << "fontcolor=white,style=filled";
    }
            
    outFile << " ];" << endl;
}

// Save edge to outstream in graphviz format.
void Graph::saveGraphvizEdge( QTextStream& outFile,
                              const int x1, const int y1,
                              const int x2, const int y2,
                              const double dist,
                              const QString& color ) const
{
    outFile << "  \"" << x1 << "_" << y1 << "\" "
            << "->"
            << "  \"" << x2 << "_" << y2 << "\" "
            << "[ "
            << "label=\"" << dist << "\","
            << "color=" << color << ","
            << "fontcolor=" << color << ","
            << "fontsize=8"
            << " ];"
            << endl;
}

// Get opposite direction, if possible.
Direction Graph::getOppositeDirection( const Direction view )
{
    Direction newView = DIRECTION_NONE;

    switch ( view )
    {
    case DIRECTION_NONE:
        break;
    case DIRECTION_NORTH:
        newView = DIRECTION_SOUTH;
        break;
    case DIRECTION_NORTH_WEST:
        newView = DIRECTION_SOUTH_EAST;
        break;
    case DIRECTION_WEST:
        newView = DIRECTION_EAST;
        break;
    case DIRECTION_SOUTH_WEST:
        newView = DIRECTION_NORTH_EAST;
        break;
    case DIRECTION_SOUTH:
        newView = DIRECTION_NORTH;
        break;
    case DIRECTION_SOUTH_EAST:
        newView = DIRECTION_NORTH_WEST;
        break;
    case DIRECTION_EAST:
        newView = DIRECTION_WEST;
        break;
    case DIRECTION_NORTH_EAST:
        newView = DIRECTION_SOUTH_WEST;
        break;
    default:
        std::cerr << "(EE) Graph::getOppositeDirection "
                  << " Default case reached for view "
                  << view
                  << std::endl;
        break;
    }
    
    return newView;
}

// delete all data
void Graph::deleteOldPathData()
{
    for ( int jj = 0; jj < getHeight(); jj++ )
    {
        for ( int ii = 0; ii < getWidth(); ii++ )
        {
            Node* node = m_board[aPos(ii,jj)];
            
            if ( node )
            {
                // delete old start and end node flags
                if ( node->isStartNode() )
                {
                    node->setStartNode(false);
                }
                if ( node->isEndNode() )
                {
                    node->setEndNode(false);
                }

                // delete all edge states because we need to search again
                node->setAllEdgeStatesNone();

                // set distance to 0
                node->setDistanceFromStart(0);
                
                // delete shortest predecessor
                node->setShortestPathPredecessor(0);
            }
        }
    }
}

// Restore the old path weights if any is stored.
void Graph::restorePathWeights()
{
    for ( int jj = 0; jj < getHeight(); jj++ )
    {
        for ( int ii = 0; ii < getWidth(); ii++ )
        {
            Node* node = m_board[aPos(ii,jj)];
            
            if ( node )
            {
                node->restorePathWeights();
            }
        }
    }
}
