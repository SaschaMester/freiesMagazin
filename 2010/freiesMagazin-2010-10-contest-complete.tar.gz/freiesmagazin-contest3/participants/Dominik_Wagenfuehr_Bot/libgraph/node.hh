/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef NODE_HH
#define NODE_HH

// Own
/////////
#include "direction.hh"
#include "edge.hh"

// Qt
///////
#include <QPoint>

// A node in the graph that holds a pointer to the
// base tile and all neighbors.
// Attention: This node can only hold exactly eight edges/neighbors.
class Node 
{
public:
    // Default constructor.
    Node( const QPoint& pos );
    
    // Destructor.
    virtual ~Node();

    // Mark this node as end node.
    void setEndNode( const bool flag = true )
    {
        m_endNode = flag;
    }
    
    // Return true this is the end node.
    bool isEndNode() const
    {
        return m_endNode;
    }

    // Mark this node as start node.
    void setStartNode( const bool flag = true )
    {
        m_startNode = flag;
    }
    
    // Return true this is the start node.
    bool isStartNode() const
    {
        return m_startNode;
    }
    
    // set distance to start node
    void setDistanceFromStart( const double dist )
    {
        m_distanceFromStart = dist;
    }
    
    // return distance to start node
    double getDistanceFromStart() const
    {
        return m_distanceFromStart;
    }

    // Return position of this node on the game board.
    const QPoint& getPosition() const
    {
        return m_position;
    }
    
    // Return true if all neighbors are not set.
    bool hasNoNeighbors() const
    {
        return ( 0 == m_edge[0].getNeighbor() && 
                 0 == m_edge[1].getNeighbor() && 
                 0 == m_edge[2].getNeighbor() && 
                 0 == m_edge[3].getNeighbor() && 
                 0 == m_edge[4].getNeighbor() && 
                 0 == m_edge[5].getNeighbor() && 
                 0 == m_edge[6].getNeighbor() && 
                 0 == m_edge[7].getNeighbor() );
    }

    // delete all edge states because we need to search again
    void setAllEdgeStatesNone()
    {
        m_edge[0].setState( EDGE_STATE_NONE );
        m_edge[1].setState( EDGE_STATE_NONE );
        m_edge[2].setState( EDGE_STATE_NONE );
        m_edge[3].setState( EDGE_STATE_NONE );
        m_edge[4].setState( EDGE_STATE_NONE );
        m_edge[5].setState( EDGE_STATE_NONE );
        m_edge[6].setState( EDGE_STATE_NONE );
        m_edge[7].setState( EDGE_STATE_NONE );
    }

    // Restore the old path weights if any is stored.
    void restorePathWeights()
    {
        m_edge[0].restoreOldDistance();
        m_edge[1].restoreOldDistance();
        m_edge[2].restoreOldDistance();
        m_edge[3].restoreOldDistance();
        m_edge[4].restoreOldDistance();
        m_edge[5].restoreOldDistance();
        m_edge[6].restoreOldDistance();
        m_edge[7].restoreOldDistance();
    }

    // Overwrite the distance to a neighbor.
    // Return true if everything is okay.
    bool overwriteNeighborDistance( const Direction view,
                                    const double newDistance );

    
    // Set a neighbor and it's distance for this node.
    // Return true if everything is okay.
    bool setNeighborAndDistance( const Direction view,
                                 Node* newNeighbor,
                                 const double distance );

    // Get the neighbor in a direction.
    Node* getNeighbor( const Direction view ) const;

    // Get the distance in a direction (makes only sense if neighbor != 0).
    double getDistance( const Direction view ) const;

    // Get the edge state in a direction (makes only sense if neighbor != 0).
    EdgeState getEdgeState( const Direction view ) const;

    // Set some edge state in a direction.
    bool setEdgeState( const Direction view, const EdgeState state );

    // Check each neighbor and return the direction if it matches
    // the given node.
    Direction hasNeighbor( const Node* node ) const;

    // Get predecessor in shortest path.
    Node* getShortestPathPredecessor() const
    {
        return m_shortestPathPredecessor;
    }
    
    // Set predecessor node in shortest path.
    bool setShortestPathPredecessor( Node* pred );
    
    // Check if predecessor is a special node.
    // Return true if so.
    bool isShortestPathPredecessor( const Node* node ) const
    {
        return ( node == m_shortestPathPredecessor );
    }
    
    // Set this node as new predecessor in shortest path for the
    // neighbor node in direction view.
    // Return true if everything is okay.
    bool setShortestPathPredecessorNeighbor( const Direction view );

    // Convert view to integer value for array access.
    // Return -1 if not valid.
    static int convertViewToInt( const Direction view );

    // Convert integer to view.
    // Return NONE if not valid.
    static Direction convertIntToView( const int num );

private:

    // Pointer to all four edges.
    Edge m_edge[8];
    
    // This marks the last node in the graph
    // or better the goal we want to reach later.
    // It's exclusive to m_startNode.
    bool m_endNode;

    // This marks the first node in the graph
    // from which we start.
    // It's exclusive to m_endNode.
    bool m_startNode;
    
    // distance to start node in external graph
    double m_distanceFromStart;
    
    // Position of this node in the original game board.
    // We need this to get the shortest path later.
    QPoint m_position;
    
    // Pointer to the predecessor if you follow the shortest path.
    Node* m_shortestPathPredecessor;
};

#endif // NODE_HH
