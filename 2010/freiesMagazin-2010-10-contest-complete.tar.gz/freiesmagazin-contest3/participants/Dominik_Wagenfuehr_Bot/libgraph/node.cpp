/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "node.hh"

// Sys
////////
#include <iostream>

// Default constructor.
Node::Node( const QPoint& pos )
    : m_endNode( false ), m_startNode( false ), m_distanceFromStart(0.0),
      m_position(pos), m_shortestPathPredecessor(0)
{
}

// Destructor.
Node::~Node()
{
    // do not destruct anything, because we only have pointers
    // to real existing objects
    m_shortestPathPredecessor = 0;
}

// Overwrite the distance to a neighbor.
bool Node::overwriteNeighborDistance( const Direction view,
                                      const double newDistance )
{
    bool ok = false;

    // convert view to value for array access
    const int value = convertViewToInt( view );
    if ( 0 <= value && value < 8 )
    {
        m_edge[value].overwriteDistance( newDistance );
        ok = true;
    }
    return ok;
}

// Set a neighbor and it's distance for this node.
bool Node::setNeighborAndDistance( const Direction view,
                                   Node* newNeighbor,
                                   const double distance )
{
    //std::cout << "Node::setNeighborAndWeight(view,Node*,int) "
              //<< " Info:"
              //<< " " << this
              //<< " " << newNeighbor
              //<< " View: " << view
              //<< " Weight: " << weight
              //<< std::endl;

    bool ok = false;

    // convert view to value for array access
    const int value = convertViewToInt( view );
    if ( 0 <= value && value < 8 )
    {
        m_edge[value].setNeighborAndDistance( newNeighbor, distance );
        ok = true;
    }
    return ok;    
}

// Get the neighbor in a direction.
Node* Node::getNeighbor( const Direction view ) const
{
    Node *neighbor = 0;

    // convert view to value for array access
    const int value = convertViewToInt( view );
    if ( 0 <= value && value < 8 )
    {
        neighbor = m_edge[value].getNeighbor();
    }

    return neighbor;    
}

// Get the distance in a direction (makes only sense if neighbor != 0)
double Node::getDistance( const Direction view ) const
{
    double dist = 0.0;

    // convert view to value for array access
    const int value = convertViewToInt( view );
    if ( 0 <= value && value < 8 )
    {
        dist = m_edge[value].getDistance();
    }

    return dist;    
}

// Get the edge state in a direction (makes only sense if neighbor != 0).
EdgeState Node::getEdgeState( const Direction view ) const
{
    EdgeState state = EDGE_STATE_NONE;

    // convert view to value for array access
    const int value = convertViewToInt( view );
    if ( 0 <= value && value < 8 )
    {
        state = m_edge[value].getState();
    }

    return state; 
}

// Set next edge state in a direction.
bool Node::setEdgeState( const Direction view,
                         const EdgeState state )
{
    bool ok = false;

    // convert view to value for array access
    const int value = convertViewToInt( view );
    if ( 0 <= value && value < 8 )
    {
        //std::cout << "Node::setEdgeState(view,state) "
                  //<< " Info: "
                  //<< " " << this
                  //<< " View: " << view
                  //<< " State: " << m_edge[value].getState()
                  //<< " -> " << state
                  //<< " Neighbor: " << m_edge[value].getNeighbor()
                  //<< std::endl;

        m_edge[value].setState( state );
        
        // if we have the edge state shortest we should mark this
        // node as predeccessor of the neighbor.
        if ( EDGE_STATE_SHORTEST == state )
        {
            Node *neighbor = m_edge[value].getNeighbor();
            if ( 0 != neighbor )
            {
                if ( neighbor->setShortestPathPredecessor( this ) )
                {
                    ok = true;
                }
            }
            else
            {
                std::cerr << "Node::setEdgeState(view,state) "
                          << " Error: State set but neighbor is 0!"
                          << std::endl;
            }
        }
        else
        {
            ok = true;
        }
    }
    
    return ok;
}

// Check each neighbor and return the direction if it matches
// the given node.
Direction Node::hasNeighbor( const Node* node ) const
{
    Direction view = DIRECTION_NONE;

    if ( 0 != node )
    {
        for ( int ii = 0; ii < 8; ii++ )
        {
            if ( node == m_edge[ii].getNeighbor() )
            {
                view = convertIntToView(ii);
                break;
            }
        }
    }
    else
    {
        std::cerr << "Node::hasNeighbor "
                  << " Error: Node is 0!"
                  << std::endl;
    }

    return view;    
}

// Set predecessor node in shortest path.
bool Node::setShortestPathPredecessor( Node* pred )
{
    /*
    if ( 0 == pred )
    {
        std::cerr << "Node::setShortestPathPredecessor "
                  << " Error: Predecessor should not be 0!"
                  << std::endl;
    }
    */
    m_shortestPathPredecessor = pred;
    
    return ( 0 != m_shortestPathPredecessor );
}

// Set this node as new predecessor in shortest path for the
// neighbor node in direction view.
// Return true if everything is okay.
bool Node::setShortestPathPredecessorNeighbor( const Direction view )
{
    bool ok = false;
    
    // get neighbor node in this direction
    Node *neighbor = getNeighbor( view );

    //std::cout << "Node::setShortestPathPredecessorNeighbor(view) "
              //<< " " << this
              //<< " View: " << view
              //<< " " << neighbor
              //<< std::endl;
    
    if ( 0 != neighbor )
    {
        // suppose everything is ok
        ok = true;

        Node *pred = neighbor->getShortestPathPredecessor();
        if ( 0 != pred )
        {
            // get view direction for this predecessor
            const Direction view2 = pred->hasNeighbor( neighbor );

            if ( DIRECTION_NONE != view2 )
            {
                // mark edge as normal and not shortest anymore
                if ( !pred->setEdgeState( view2, EDGE_STATE_NORMAL ) )
                {
                    ok = false;
                }
            }
            else
            {
                std::cerr << "Node::setShortestPathPredecessorNeighbor(view) "
                          << " Error: Neighbor "
                          << neighbor
                          << " from predecessor "
                          << pred
                          << " not found."
                          << std::endl;
                ok = false;
            }
        }
        
        if ( ok )
        {
            ok = false;
            
            // set new predecessor for neighbor node
            if ( neighbor->setShortestPathPredecessor( this ) )
            {
                // mark this edge as shortest to neighbor
                if ( setEdgeState( view, EDGE_STATE_SHORTEST ) )
                {
                    ok = true;
                }
            }
        }
    }
    else
    {
        std::cerr << "Node::setShortestPathPredecessorNeighbor(view) "
                  << " Error: Neighbor from node "
                  << this
                  << " is 0: "
                  << view
                  << "."
                  << std::endl;
        ok = false;
    }

    return ok;
}

// Convert view to integer value for array access.
// Return -1 if not valid.
int Node::convertViewToInt( const Direction view )
{
    int value = -1;
    
    switch ( view )
    {
        case DIRECTION_NORTH:
            value = 0;
            break;
        case DIRECTION_NORTH_WEST:
            value = 1;
            break;
        case DIRECTION_WEST:
            value = 2;
            break;
        case DIRECTION_SOUTH_WEST:
            value = 3;
            break;
        case DIRECTION_SOUTH:
            value = 4;
            break;
        case DIRECTION_SOUTH_EAST:
            value = 5;
            break;
        case DIRECTION_EAST:
            value = 6;
            break;
        case DIRECTION_NORTH_EAST:
            value = 7;
            break;
        default:
            std::cerr << "Node::convertViewToInt(view) "
                      << " Error: Unknown case "
                      << view
                      << " in switch."
                      << std::endl;
            break;
    }
    return value;
}

// Convert integer to view.
// Return NONE if not valid.
Direction Node::convertIntToView( const int num )
{
    Direction value = DIRECTION_NONE;
    
    switch ( num )
    {
        case 0:
            value = DIRECTION_NORTH;
            break;
        case 1:
            value = DIRECTION_NORTH_WEST;
            break;
        case 2:
            value = DIRECTION_WEST;
            break;
        case 3:
            value = DIRECTION_SOUTH_WEST;
            break;
        case 4:
            value = DIRECTION_SOUTH;
            break;
        case 5:
            value = DIRECTION_SOUTH_EAST;
            break;
        case 6:
            value = DIRECTION_EAST;
            break;
        case 7:
            value = DIRECTION_NORTH_EAST;
            break;
        default:
            std::cerr << "Node::convertIntToView(int) "
                      << " Error: Unknown case "
                      << num
                      << " in switch."
                      << std::endl;
            break;
    }
    return value;
}
