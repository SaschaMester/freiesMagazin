/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef GRAPH_HH
#define GRAPH_HH

// Own
/////////
#include "direction.hh"

// Qt
////////
#include <QSize>
#include <QPoint>
#include <QVector>

// Forward declarations
//////////////////////////
class Node;
class GameMap;
class QTextStream;
class QString;

class BaseTile;

typedef QVector<Node*> NodePointerVector;

// Class for creating a path from robot position to game board finish.
class Graph
{
public:
    // Constructor.
    Graph();

    // Constructor, create graph.
    Graph( const GameMap& originalBoard );

    // Copy constructor.
    Graph( const Graph& graph );

    // Destructor.
    ~Graph();

    // return width of graph
    int getWidth() const
    {
        return m_size.width();
    }

    // return height of graph
    int getHeight() const
    {
        return m_size.height();
    }
    
    // return flag if graph is valid.
    bool isValid() const
    {
        return m_valid;
    }

    // delete some data
    void deleteOldPathData();

    // Restore the old path weights if any is stored.
    void setNewPathWeights( const double weights ); 

    // Restore the old path weights if any is stored.
    void restorePathWeights();

    // access node element
    Node* operator[] ( const QPoint& pos ) const;

    // Init graph with given game board.
    // Return true if everything is okay.
    bool init( const GameMap& originalBoard );

    // Save graph to disc
    // as graphviz dot-file
    // return true if everything is okay
    bool saveGraphviz( const QString& filename ) const;

    // Check if movement is diagonal and return the neighbored positions for it.
    static bool isDiagonalMovement( QPoint& field1, QPoint& field2,
                                    const QPoint& reachedPos,
                                    const Direction movement );

    // Get opposite direction, if possible.
    static Direction getOppositeDirection( const Direction view );

private:
    // delete graph
    void clear();

    // Init all neighbors on the board.
    // Return true if everything is okay.
    bool initNeighbors( const GameMap& originalBoard );

    // Connect the tile on pos1 with the tile on pos2 if possible.
    // Return true if possible.
    bool initNeighbors( const GameMap& originalBoard,
                        const QPoint& pos1, const QPoint& pos2,
                        const Direction view );

    // Return true if movement is diagonal and blocked by something.
    bool isBlockedByDiagonalMovement( const GameMap& originalBoard,
                                      const QPoint& reachedPos,
                                      const Direction movement ) const;

    // Save single node to outstream in graphviz format.
    void saveGraphvizNode( QTextStream& outFile,
                           const int x, const int y,
                           const double dist,
                           const QString& color,
                           const bool isEndNode ) const;

    // Save edge to outstream in graphviz format.
    void saveGraphvizEdge( QTextStream& outFile,
                           const int x1, const int y1,
                           const int x2, const int y2,
                           const double distance,
                           const QString& color ) const;

    // Return array position for easier access.
    int aPos( const QPoint& pos ) const
    {
        return pos.x()+pos.y()*getWidth();
    }

    int aPos( const int x, const int y ) const
    {
        return x+y*getWidth();
    }

    ////////////////
    // Members
    ///////////////
    
    // Pointer to all tiles in the game board with neighbors etc.
    NodePointerVector m_board;
    
    // Size of game board.
    QSize m_size;
    
    // Flag if constructed astar board is valid.
    bool m_valid;

};

#endif // GRAPH_HH
