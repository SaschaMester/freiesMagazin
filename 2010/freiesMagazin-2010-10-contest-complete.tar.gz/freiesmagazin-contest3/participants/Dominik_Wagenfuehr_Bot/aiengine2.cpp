/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "aiengine2.hh"
#include "trace.hh"
#include "dijkstra.hh"
#include "node.hh"

// Sys
/////////
#include <cstdlib>
#include <iostream>

// Constructor
AiEngine2::AiEngine2()
:  AiEngine(), m_pathPointCounter(-1), m_randomTarget(false),
   m_lastMovingDirection(DIRECTION_NONE), m_round(-1)
{
    Trace::print( MTP_AI_ENGINE, STP_AI_STRUCTOR,
                  "AiEngine2::AiEngine2 Start" );

    Trace::print( MTP_AI_ENGINE, STP_AI_STRUCTOR,
                  "AiEngine2::AiEngine2 End");    
}

// Connect another client.
void AiEngine2::processCommandConnectOther()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandConnectOther Start " );

    const int id = m_client.getClientId();

    // first we must check if the id is not our id
    if ( id != m_player.getIndex() )
    {
        if ( !m_otherPlayers.contains( id ) )
        {
            // add new player
            m_otherPlayers.add( id );

            while ( m_numRoundsLastSeenOtherPlayer.count() <= id )
            {
                // the list is not big enough for storing the id
                // so add new dummy elements
                m_numRoundsLastSeenOtherPlayer.append(0);
            }
        }
        else
        {
            std::cerr << "(EE) AiEngine2::processCommandConnectOther "
                      << " Client "
                      << id
                      << " already connected."
                      << std::endl;
        }
    }
    // no error, we just ignore it

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandConnectOther End " + QString::number(id) );
}

// Disconnect another client.
void AiEngine2::processCommandDisconnectOther()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandDisconnectOther Start " );

    const int id = m_client.getClientId();

    // first we must check if the id is not our id
    if ( id != m_player.getIndex() )
    {
        if ( m_otherPlayers.contains( id ) )
        {
            m_otherPlayers.remove(id);

            // We will not remove the id from m_numRoundsLastSeenOtherPlayer
            // because we do not want to reorganize the list.
            
        }
        else
        {
            std::cerr << "(EE) AiEngine2::processCommandDisconnectOther "
                      << " Client "
                      << id
                      << " not connected."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "(EE) AiEngine2::processCommandDisconnectOther "
                  << " Try to disconnect own client "
                  << id
                  << std::endl;
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandDisconnectOther End " + QString::number(id) );
}

// Set data of own player.
void AiEngine2::processCommandSet()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandSet Start " );

    if ( m_showGameInfo )
    {
        std::cout << "(II) AiEngine2::processCommandSet "
                  << " Player "
                  << m_player.getIndex()
                  << " Position ("
                  << m_client.getPosition().x() << ", " << m_client.getPosition().y()
                  << ")"
                  << " View "
                  << Player::toString( m_client.getView() ).toStdString()
                  << std::endl;
    }

    if ( !m_player.setPosition( m_client.getPosition() ) )
    {
        std::cerr << "(EE) AiEngine2::processCommandSet "
                  << " Position ("
                  << m_client.getPosition().x() << ", " << m_client.getPosition().y()
                  << ") could not be set for player "
                  << m_player.getIndex()
                  << std::endl;
    }
    else
    {
        // if we have reached our target, we must delete it
        if ( isTargetPositon( m_player.getPosition() ) )
        {
            deleteTargetPath();
            
            // further we must check if this position matches any
            // of the players and if so, we will mark the player
            // because we have lost sight of him.
            markPlayerAsLost( m_player.getPosition() );
        }
        
        if ( m_player.getNumStandStills() > 0 )
        {
            // This means we have not moved at all.
            // If this happens we probably bumbed against another
            // player.
            // In any case we could not use the current set path
            // because the movement does not match the path anymore.
            // So delete the current path.
            // Note: It would be possible that we just increase
            // the path counter to restart from the position
            // but it's not too bad to restart the path from here.
            deleteTargetPath();
        }
    }
        
    if ( !m_player.setView( m_client.getView() ) )
    {
        std::cerr << "(EE) AiEngine2::processCommandSet "
                  << " View "
                  << Player::toString( m_client.getView() ).toStdString()
                  << " could not be set for player "
                  << m_player.getIndex()
                  << std::endl;
    }
    

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandSet End " );
}

// Set data of other player.
void AiEngine2::processCommandSeePlayer()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandSeePlayer Start " );

    const int id = m_client.getClientId();

    if ( id >= 0 )
    {
        if ( m_showGameInfo )
        {
            std::cout << "(II) AiEngine2::processCommandSeePlayer "
                      << " Player "
                      << m_player.getIndex()
                      << " Sees Player "
                      << id
                      << " Position ("
                      << m_client.getPosition().x() << ", " << m_client.getPosition().y()
                      << ")"
                      << " View "
                      << Player::toString( m_client.getView() ).toStdString()
                      << std::endl;
        }

        if ( !m_otherPlayers.setPosition( id, m_client.getPosition() ) )
        {
            std::cerr << "(EE) AiEngine2::processCommandSeePlayer "
                      << " Position ("
                      << m_client.getPosition().x() << ", " << m_client.getPosition().y()
                      << ") could not be set for player "
                      << id
                      << std::endl;
        }
            
        if ( !m_otherPlayers.setView( id, m_client.getView() ) )
        {
            std::cerr << "(EE) AiEngine2::processCommandSeePlayer "
                      << " View "
                      << Player::toString( m_client.getView() ).toStdString()
                      << " could not be set for player "
                      << id
                      << std::endl;
        }

        // mark this player as seen in this round
        if ( id < m_numRoundsLastSeenOtherPlayer.count() )
        {
            m_numRoundsLastSeenOtherPlayer[id] = 0;
        }
        else
        {
            std::cerr << "(EE) AiEngine2::processCommandSeePlayer "
                      << " List for last seen players is not big enough "
                      << m_numRoundsLastSeenOtherPlayer.count()
                      << " for this player "
                      << id
                      << std::endl;

        }

        // Check if there are some players that stands on the same
        // positon. If so the player unequal the current one must
        // have left the positon, so we mark him as lost.
        // If we see him again later, we will get the command.
        markPlayerAsLost( m_client.getPosition(), id );
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandSeePlayer End " + QString::number(id) );
}

// See a new key.
void AiEngine2::processCommandSeeKey()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandSeeKey Start " );

    // create a new key field
    const Field field( m_client.getPosition(), m_client.getKey().get() );

    // check if key field is already known or stored by the player
    if ( !m_visibleKeys.contains( field ) &&
         !m_player.hasKey( m_client.getKey() ) )
    {
        // key is not known, so add it
        m_visibleKeys.append( field );

        if ( m_showGameInfo )
        {
            std::cout << "(II) AiEngine2::processCommandSeeKey "
                      << " Player "
                      << m_player.getIndex()
                      << " Key "
                      << m_client.getKey().get().toAscii()
                      << " Position ("
                      << m_client.getPosition().x() << ", " << m_client.getPosition().y()
                      << ")"
                      << std::endl;
        }
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandSeeKey End " );
}

// Get a new key
void AiEngine2::processCommandGetKey()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandGetKey Start " );

    // it doesn't matter if the player already has the key
    // The player will only add keys that he does not already have.
    if ( m_player.addKey( m_client.getKey() ) )
    {
        if ( m_showGameInfo )
        {
            std::cout << "(II) AiEngine2::processCommandGetKey "
                      << " Player "
                      << m_player.getIndex()
                      << " Key "
                      << m_client.getKey().get().toAscii()
                      << std::endl;
        }

        // remove key from visible list
        int ii = 0;
        while ( ii < m_visibleKeys.count() )
        {
            if ( m_client.getKey().get() == m_visibleKeys[ii].toAscii() )
            {
                m_visibleKeys.removeAt(ii);
            }
            else
            {
                ii++;
            }
        }
    }
                  
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandGetKey End " );
}

// change the team of a player
void AiEngine2::processCommandTeamChange()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandTeamChange Start " );

    const int id = m_client.getClientId();

    if ( id >= 0 )
    {
        if ( m_showGameInfo )
        {
            std::cout << "(II) AiEngine2::processCommandTeamChange "
                      << " Player "
                      << m_player.getIndex()
                      << " Change Player "
                      << id
                      << " Team "
                      << Player::toString( m_client.getTeam() ).toStdString()
                      << std::endl;
        }

        if ( id == m_player.getIndex() )
        {
            // the id is the id of the own player
            m_player.setTeam( m_client.getTeam(), false );
            
            // we have changed the team, so the target should be deleted
            deleteTargetPath();
        }
        else if ( !m_otherPlayers.setTeam( id, m_client.getTeam(), false ) )
        {
            std::cerr << "(EE) AiEngine2::processCommandTeamChange "
                      << " Team "
                      << Player::toString( m_client.getTeam() ).toStdString()
                      << " could not be set for player "
                      << id
                      << std::endl;
        }
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandTeamChange End " + QString::number(id) );
}

// Load new map.
void AiEngine2::processCommandLoadMap()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandLoadMap Start " + m_client.getMapName() );

    if ( !m_map.load( m_client.getMapName() ) )
    {
        std::cerr << "(II) AiEngine2::processCommandLoadMap "
                  << " Client " << m_player.getIndex()
                  << " Map "
                  << m_client.getMapName().toStdString()
                  << " could not be loaded."
                  << std::endl;
    }
    else
    {
        // Clear all default toxic values.
        // We use this as indicator which fields we already
        // have visited.
        QPoint pos(-1,-1);

        for ( int ii = 0; ii < m_map.getSize().width(); ii++ )
        {
            for ( int jj = 0; jj < m_map.getSize().height(); jj++ )
            {
                pos.setX(ii);
                pos.setY(jj);
                m_map[pos].setToxicValue(-0.2);
            }
        }

        // create graph
        m_graph.init( m_map );
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandLoadMap End " );
}

// Store toxic value in game map.
void AiEngine2::processCommandStoreToxicValue()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandStoreToxicValue Start ");

    const QPoint pos = m_client.getPosition();
    const double toxic = m_client.getDoubleValue();

    if ( m_map.isValidPos( pos ) )
    {
        // store toxic value
        m_map[pos].setToxicValue(toxic);
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandStoreToxicValue End " );
}

// Start calculation of next move.
void AiEngine2::processCommandStartCalculation()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandStartCalculation Start " );

#ifdef QT_DEBUG
    std::cout << std::endl
              << "---------------------------------------------------------------"
              << std::endl;
#endif

    // store round number
    m_round = m_client.getRound();

    Direction move = DIRECTION_NONE;
    Direction view = DIRECTION_NORTH;

    calcNextMove( move, view );

    if ( m_showGameInfo )
    {
        std::cout << "(II) AiEngine2::processCommandStartCalculation "
                  << " Player "
                  << m_player.getIndex()
                  << " Move "
                  << Player::toString( move ).toStdString()
                  << " View "
                  << Player::toString( view ).toStdString()
                  << std::endl;
    }
    
    // store new moving direction
    m_lastMovingDirection = move;

    if ( !m_client.send("MOVE " + Player::toString(move) + " " +  Player::toString(view) ) )
    {
        std::cerr << "(EE) AiEngine2::processCommandStartCalculation "
                  << " Client " << m_player.getIndex()
                  << " Send failed!"
                  << std::endl;
    }

    // Increase the not seen value for all players.
    // It will be set to 0 if we see this player at the end of the
    // round.
    for ( int ii = 0; ii < m_numRoundsLastSeenOtherPlayer.count(); ii++ )
    {
        if ( m_numRoundsLastSeenOtherPlayer[ii] >= 0 )
        {
            m_numRoundsLastSeenOtherPlayer[ii]++;
        }
        // If the value is negative, we have lost sight of this player
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine2::processCommandStartCalculation End " );
}

// Calculate next move of player.
bool AiEngine2::calcNextMove( Direction& move, Direction& view )
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::calcNextMove Start " );

    bool ok = false;
    
    move = DIRECTION_NONE;
    view = DIRECTION_NORTH;
    
    if ( TEAM_BLUE == m_player.getTeam() )
    {
        calcNextMoveHide( move, view );
        ok = true;
    }
    else if ( TEAM_RED == m_player.getTeam() )
    {
        calcNextMoveSeek( move, view );
        ok = true;
    }
    else
    {
        std::cout << "(EE) AiEngine2::calcNextMove "
                  << " Client "
                  << m_player.getIndex()
                  << " unknown team "
                  << Player::toString( m_player.getTeam() ).toStdString()
                  << std::endl;
    }

#ifdef QT_DEBUG
        std::cout << "(II) AiEngine2::calcNextMove "
                  << " Client " << m_player.getIndex()
                  << " Move move "
                  << m_mode
                  << " Move in dir "
                  << Player::toString(move).toStdString()
                  << " view "
                  << Player::toString(view).toStdString()
                  << std::endl;
#endif

    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::calcNextMove End " + QString::number((int)ok) );

    return ok;
}

// Calculate next move of player to hide somewhere.
bool AiEngine2::calcNextMoveHide( Direction& move, Direction& view )
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::calcNextMoveHide Start " );

    bool ok = false;
    
    move = DIRECTION_NONE;
    view = DIRECTION_NORTH;

    // ok = createRandomTargetPosition();

    // For each position that is reachable from out current position
    // we will calculate a number combined from distance of red
    // players and number of walls around.
    QPoint bestPos(-1,-1);
    double bestValue = 0.0;
    bool first = true;
    bool isHalfBlocked = false;

    QPoint pos;
    double value = 0.0;
    
    for ( int ii = (int)DIRECTION_NONE; ii <= (int)DIRECTION_NORTH_EAST; ii++ )
    {
        // move position in direction
        if ( Player::movePosition( pos, m_player.getPosition(), (Direction)ii ) )
        {
            if ( isReachablePos( pos, (Direction)ii, isHalfBlocked ) )
            {
                // calculate hidden value for this field
                if ( calculateHideValue( value, pos, (Direction)ii ) )
                {
                    if ( first || value > bestValue )
                    {
                        bestValue = value;
                        bestPos = pos;
                        first = false;
                    }
                }
                // no break, even if and error occured
            }
            // else the position is not reachable
            // no error and no check
        }
        // no error, just check the next direction
    }
    
    if ( !m_map.isValidPos( bestPos ) )
    {
        // fallback, do not move at all
        bestPos = m_player.getPosition();
    }
    
    // Now we must set a new path
    // that will only contain the new pos
    m_pathToTarget.clear();
    m_pathToTarget.append( bestPos );
    m_pathPointCounter = 0;
    m_randomTarget = false;
    ok = true;

    if ( ok )
    {
        // as blue player we will always look in the direction where
        // we can see the most
        ok = calculateMoveAndViewFromTarget( move, view, true );
        
        // Note: It's possible we bump into another player of the same
        // team and do not move at all. My idea was to check if
        // we try to move in the same direction as the round before
        // but have not moved at all (getNumberOfStandStills).
        // In this case I would look into the direction of movement
        // to see an unknown obstacle. But that is stupid because
        // If the player is in the same team, we know its position.
        // And if the player is in teh opposite one, we will convert
        // him or will be converted ourselve and then see him.
        // So: No need to reset the viewing direction.
        
        // But maybe it would be good, if we ran away from a red player
        // to look behind from time to time so that we see if he's
        // still following us. But I haven't a good idea how to.
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::calcNextMoveHide End " + QString::number((int)ok) );

    return ok;
}

// Calculate for this direction 
bool AiEngine2::calculateHideValue( double& value, QPoint& pos, const Direction move )
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::calculateHideValue Start " );

    bool ok = false;

    // as default the value is 0
    value = 0.0;
    
    if ( m_map.isValidPos( pos ) )
    {
        // 1. Count the middle value for the distance for all red players.
        // The lastSeen-Factor is important because the longer we haven't
        // seen the red player the less it will occur in the value.
        // 1 / numRed * Sum ( 10 * dist / (lastSeen+1) )
        const QList<int> playerIds = m_otherPlayers.getListOfIds();
    
        // number of red players in game
        int numRedPlayers = 0;
        int numBluePlayers = 0;

        // temp. variables
        QPoint redPos(-1,-1);
        QList<QPoint> path;
        int numSteps = -1;
        int lastSeen = 0;
        double distance = 0.0;
        
        // sum of all distances to red players
        double sumRedDistance = 0.0;
        double sumBlueDistance = 0.0;

        for ( int ii = 0; ii < playerIds.count(); ii++ )
        {
            if ( !m_otherPlayers.isInvalid( playerIds[ii] ) )
            {
                // check team
                const Team team = m_otherPlayers.getTeam( playerIds[ii] );

                if ( playerIds[ii] < m_numRoundsLastSeenOtherPlayer.count() )
                {
                    // get position of red player
                    redPos = m_otherPlayers.getPosition( playerIds[ii] );
                    lastSeen = m_numRoundsLastSeenOtherPlayer.at( playerIds[ii] );
                    
                    if ( lastSeen >= 0 )
                    {
                        // calculate distance to this position
                        numSteps = getNumberOfSteps( path, distance, redPos, pos );

                        if ( TEAM_RED == team )
                        {
                            // sum distances
                            sumRedDistance += distance * 25.0 / (lastSeen+1);

                            // add new red player
                            numRedPlayers++;
                        }
                        else if ( TEAM_BLUE == team )
                        {
                            // sum distances
                            sumBlueDistance += distance * 2.0 / (lastSeen+1);

                            // add new blue player
                            numBluePlayers++;
                        }
                    }
                    // else player is lost
                }
                else
                {
                    std::cerr << "(EE) AiEngine2::calculateHideValue "
                              << " List for last seen players is not big enough "
                              << m_numRoundsLastSeenOtherPlayer.count()
                              << " for this player "
                              << playerIds[ii]
                              << std::endl;

                    sumRedDistance = 0.0;
                    numRedPlayers = 0;
                    sumBlueDistance = 0.0;
                    numBluePlayers = 0;
                    break;
                }
            }
        }

        // calculate median distance
        if ( numRedPlayers > 0 )
        {
            sumRedDistance /= numRedPlayers;
        }
        if ( numBluePlayers > 0 )
        {
            sumBlueDistance /= numBluePlayers;
        }

        // 2. Count number of empty fields around positon.
        // We will not only count if they are empty but we will also
        // count if we could reach them directly or if we need two
        // movements (for diagonal free fields, that are blocked).
        
        // the value is double because there are "half free" fields
        // where we need two movements to reach them.
        double numFreeFields = getNumFreeFields( pos );

        // 3. Subtract toxic value if known. If the position is the same
        // as before, we must multiply with the stored number of stand
        // stills + 1 of the player.
        
        // Get toxic value for this position.
        // If we have not set it, it has been set to 0.01.
        double toxic = m_map[pos].getToxicValue();
        
        if ( pos == m_player.getPosition() )
        {
            // this is the same position as before
            toxic *= ( m_player.getNumStandStills() + 1 );
        }
        
        // multiply value with 10
        toxic *= 10.0;

        // Add a little bonus for diagonal movement, because
        // it's faster.
        double diagonalBonus = 0.0;
        
        if ( DIRECTION_NORTH_WEST == move ||
             DIRECTION_SOUTH_WEST == move ||
             DIRECTION_SOUTH_EAST == move ||
             DIRECTION_NORTH_EAST == move )
        {
            diagonalBonus = 0.5;
        }

        // We will give a little unknown bonus so that we try
        // to reach fields that we have not visited yet.
        // For this we have set all toxic fields to -0.2 at the start
        // of the game.
        
        // finally set the value
        value = sumRedDistance + sumBlueDistance + numFreeFields - toxic + diagonalBonus;

#ifdef QT_DEBUG
        std::cout << "(II) AiEngine2::calculateHideValue "
                  << " Pos: "
                  << "(" << pos.x() << "," << pos.y() << ")"
                  << " Dist R : " << sumRedDistance
                  << " Dist B: "  << sumBlueDistance
                  << " Free: "  << numFreeFields
                  << " Toxic: " << toxic
                  << " Diag: "  << diagonalBonus
                  << " Sum: "   << value
                  << std::endl;
#endif

        ok = true;
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::calculateHideValue End " + QString::number((int)ok) +
                  " " + QString::number(value) );

    return ok;
}

// Return number of free fields around the given field.
double AiEngine2::getNumFreeFields( const QPoint& pos ) const
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::getNumFreeFields Start " );

    double free = 0.0;
    
    // we need to check for every position around this one
    // if it is blocked
    if ( m_map.isValidPos(pos) )
    {
        // we suppose here that the current position is
        // not a door or blocked
        QPoint newPos(-1,-1);
        bool isHalfBlocked = false;
        
        for ( int ii = (int)DIRECTION_NORTH; ii <= (int)DIRECTION_NORTH_EAST; ii++ )
        {
            // move position in direction
            if ( Player::movePosition( newPos, pos, (Direction)ii ) )
            {
                if ( isReachablePos( newPos, (Direction)ii, isHalfBlocked ) )
                {
                    free += 1.0;
                }
                else if ( isHalfBlocked )
                {
                    // we could walk around an object,
                    // this gives only 0.33 points
                    free += 0.33;
                }
                // else the position is not reachable
                // no error and no check
            }
            // no error, just check the next direction
        }
    }
    
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::getNumFreeFields End " + QString::number(free) );

    return free;
}
    
// Return true if the position is reachable by the movement.
bool AiEngine2::isReachablePos( const QPoint& pos, const Direction move, bool& isHalfBlocked ) const
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::isReachablePos Start " );

    bool validPos = true;
    isHalfBlocked = false;

#ifdef QT_DEBUG
    std::cout << "(II) AiEngine2::isReachablePos "
              << " Pos: "
              << "(" << pos.x() << "," << pos.y() << ")"
              << " Valid: " << m_map.isValidPos(pos)
              << " BLOCK: " << m_map[pos].isType( FT_BLOCK )
              << " DOOR: " << m_map[pos].isType( FT_DOOR )
              << std::endl;
#endif

    if ( m_map.isValidPos(pos) &&
         !m_map[pos].isType( FT_BLOCK ) &&
         !m_map[pos].isType( FT_DOOR ) && 
         !isBlockedByOtherPlayer( pos ) )
    {
        // if we view diagonally we must also check if one of the
        // orthogonally to viewing direction fields are blocked
        QPoint nField1, nField2;
        
        if ( Graph::isDiagonalMovement( nField1, nField2, pos, move ) )
        {
            // check fields
            if ( m_map[nField1].isType( FT_BLOCK ) ||
                 m_map[nField1].isType( FT_DOOR )  ||
                 m_map[nField2].isType( FT_BLOCK ) ||
                 m_map[nField2].isType( FT_DOOR ) ||
                 isBlockedByOtherPlayer( nField1 ) ||
                 isBlockedByOtherPlayer( nField2 ) )
            {
                // We could not go through this fields.
                // (We could walk thorugh doors if we have the key,
                // but I will not check this.)
                validPos = false;
                isHalfBlocked = true;
            }
        }
        // else validPos stays true
    }
    else
    {
        validPos = false;
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::isReachablePos End " + QString::number((int)validPos) );

    return validPos;
}

// Check if some field is occupied by some player.
bool AiEngine2::isBlockedByOtherPlayer( const QPoint& pos, const bool absolute ) const
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::isBlockedByOtherPlayer Start " );

    bool blocked = false;

    const QList<int> playerIds = m_otherPlayers.getListOfIds();

    for ( int ii = 0; ii < playerIds.count(); ii++ )
    {
        if ( !m_otherPlayers.isInvalid( playerIds[ii] ) )
        {
            if ( pos == m_otherPlayers.getPosition( playerIds[ii] ) )
            {
                if ( absolute )
                {
                    if ( playerIds[ii] < m_numRoundsLastSeenOtherPlayer.count() )
                    {
                        if ( 0 == m_numRoundsLastSeenOtherPlayer.at( playerIds[ii] ) )
                        {
                            blocked = true;
                            break;
                        }
                    }
                    else
                    {
                        std::cerr << "(EE) AiEngine2::isBlockedByOtherPlayer "
                                  << " List for last seen players is not big enough "
                                  << m_numRoundsLastSeenOtherPlayer.count()
                                  << " for this player "
                                  << playerIds[ii]
                                  << std::endl;
                        break;
                    }
                }
                else
                {
                    // Even if we have seen this player
                    // a long time ago we will block this field.
                    blocked = true;
                    break;
                }
            }
        }
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::isBlockedByOtherPlayer End " + QString::number(blocked) );

    return blocked;
}

// Calculate next move of player to seek other players.
bool AiEngine2::calcNextMoveSeek( Direction& move, Direction& view )
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::calcNextMoveSeek Start " );

    bool ok = false;
    
    move = DIRECTION_NONE;
    view = DIRECTION_NORTH;

    const QList<int> playerIds = m_otherPlayers.getListOfIds();
    
    // List of way points to go nearest target.
    QPoint nearestTargetPos(-1,-1);
    double nearestDistance = -1.0;
    int nearestLastSeen = -1;
    QList<QPoint> nearestPath;

    QPoint pos(-1,-1);
    int lastSeen = -1;
    int numSteps = -1;
    double distance = 0.0;
    bool first = true;

    // m_graph.saveGraphviz( "/tmp/2.dot" );

    // match graph weights with actual player positions
    // this depends if player is in blue or red team
    overwriteGraphDistancesForSeeking();

    // m_graph.saveGraphviz( "/tmp/3.dot" );

    // first we check for each blue player we see/have seen, how
    // far away he is
    for ( int ii = 0; ii < playerIds.count(); ii++ )
    {
        if ( !m_otherPlayers.isInvalid( playerIds[ii] ) )
        {
            // check team
            const Team team = m_otherPlayers.getTeam( playerIds[ii] );

            if ( TEAM_BLUE == team )
            {
                if ( playerIds[ii] < m_numRoundsLastSeenOtherPlayer.count() )
                {
                    // we have found a blue player, check the pos we have
                    // last seen him
                    pos = m_otherPlayers.getPosition( playerIds[ii] );
                    lastSeen = m_numRoundsLastSeenOtherPlayer.at( playerIds[ii] );

                    if ( lastSeen >= 0 )
                    {
                        // If we have last seen this player X rounds ago,
                        // he may have moved on. He could maximally
                        // be X fields further away. So we will add this number
                        // to our calculation.
                        numSteps = getNumberOfSteps( nearestPath, distance,
                            pos, m_player.getPosition() );

#ifdef QT_DEBUG
                        std::cout << "(II) AiEngine2::calcNextMoveSeek TEST "
                                  << " Steps: " << numSteps
                                  << " Dist: " << distance
                                  << " Pos: " << pos.x() << "," << pos.y()
                                  << " Seen: " << lastSeen
                                  << " Path: " << nearestPath.count()
                                  << std::endl;
#endif

                        // Check if this number of steps is smaller than
                        // a previous stored number.
                        // If so we will set the position as our new goal.
                        if ( ( first ) ||
                             ( (distance+lastSeen) < nearestDistance ) ||
                             ( ( (distance+lastSeen) == nearestDistance ) &&
                               ( ( -1 == nearestLastSeen ) ||
                                 ( lastSeen <= nearestLastSeen ) ) ) )
                        {
#ifdef QT_DEBUG
                            std::cout << "(II) AiEngine2::calcNextMoveSeek TEST "
                                      << " Set new distance!"
                                      << std::endl;
#endif

                            nearestDistance = (distance+lastSeen);
                            nearestTargetPos = pos;
                            nearestLastSeen = lastSeen;
                            first = false;
                            
                            // we have a nearest path
                            // so store this new one
                            m_pathToTarget = nearestPath;
                            m_pathPointCounter = numSteps;
                            m_pathPointCounter--;
                            m_randomTarget = false;
                        }
                    }
                    // else we have lost this player
                }
                else
                {
                    std::cerr << "(EE) AiEngine2::calcNextMoveSeek "
                              << " List for last seen players is not big enough "
                              << m_numRoundsLastSeenOtherPlayer.count()
                              << " for this player "
                              << playerIds[ii]
                              << std::endl;
                }
            }
        }
    }

    // reset additional graph weights
    m_graph.restorePathWeights();

#ifdef QT_DEBUG
    std::cout << "(II) AiEngine2::calcNextMoveSeek "
              << " Dist: " << nearestDistance
              << " Pos: " << nearestTargetPos.x() << "," << nearestTargetPos.y()
              << " Seen: " << nearestLastSeen
              << " Path: " << m_pathToTarget.count()
              << " Counter: " << m_pathPointCounter;
    if ( 0 <= m_pathPointCounter && m_pathPointCounter < m_pathToTarget.count() )
    {
        std::cout << " Next: " << m_pathToTarget[m_pathPointCounter].x() << "," << m_pathToTarget[m_pathPointCounter].y();
    }
    std::cout << std::endl;
#endif


    if ( -1 == nearestTargetPos.x() || -1 == nearestTargetPos.y() )
    {
        ok = createRandomTargetPosition();
    }
    else
    {
        ok = true;
    }

    if ( ok )
    {
        ok = calculateMoveAndViewFromTarget( move, view );
    }
    
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::calcNextMoveSeek End " + QString::number((int)ok) );

    return ok;
}

// Calculate movement and view from a precalculated target.
bool AiEngine2::calculateMoveAndViewFromTarget( Direction& move,
                        Direction& view, const bool alwaysUseBestView )
{
    // Fallback mode = current position.
    QPoint targetPos = m_player.getPosition();

    if ( 0 <= m_pathPointCounter && m_pathPointCounter < m_pathToTarget.count() )
    {
        // now we must have a target path
        // so get the next step in the path
        targetPos = m_pathToTarget.at(m_pathPointCounter);
        m_pathPointCounter--;
    }

#ifdef QT_DEBUG    
    std::cout << "(II) AiEngine2::calculateMoveAndViewFromTarget "
              << " Cur: "
              << "(" << m_player.getPosition().x() << "," << m_player.getPosition().y() << ") "
              << " Next: "
              << "(" << targetPos.x() << "," << targetPos.y() << ") "
              << std::endl;
#endif

    // Calculate direction for movement
    move = calcMovementDirection( targetPos, m_player.getPosition() );

    // The viewing direction will be calculated a little bit different.
    if ( alwaysUseBestView || m_randomTarget || DIRECTION_NONE == move )
    {
        // If the target is random or if we do not move at all
        // we will choose the viewing direction with the best
        // viewing point.
        view = calcViewingDirection( targetPos );
    }
    else
    {
        // If we have a special target, we try to keep it in focus
        // and look in the direction of the movement.
        view = move;
    }
    
    return true;
}

// Get the number of steps we need to reach the target form origin.
int AiEngine2::getNumberOfSteps( QList<QPoint>& path,  double& distance,
                                const QPoint& target, const QPoint& origin )
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::getNumberOfSteps Start " );

    int numSteps = -1;
    distance = 0.0;
    
    if ( m_graph.isValid() )
    {
        // create a copy of the graph
        // Graph tempGraph( m_graph );

        // delete previous calculated data
        m_graph.deleteOldPathData();

        // tempGraph.saveGraphviz( "/tmp/0.dot" );

        // great dijkstra algorithm
        Dijkstra algorithm( m_graph, origin, target );

        // tempGraph.saveGraphviz( "/tmp/1.dot" );

        // calculate shortest path
        if ( algorithm.getShortestPath( path ) )
        {
            // we will have always one element
            numSteps = path.count()-1;
            
            if ( m_graph[target] )
            {
                // this node holds the distance to the origin
                distance = m_graph[target]->getDistanceFromStart();
            }
            
#ifdef QT_DEBUG
            std::cout << "Path: ";
            for ( int ii = 0; ii < path.count(); ii++ )
            {
                std::cout << "(" << path[ii].x() << "," << path[ii].y() << ")";
                if ( ii < path.count()-1 )
                {
                    std::cout << " -> ";
                }
            }
            std::cout << std::endl;
#endif
        }
        else
        {
            std::cerr << "(EE) AiEngine2::getNumberOfSteps "
                      << " No shortes path found!"
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "(EE) AiEngine2::getNumberOfSteps "
                  << " Graph is not valid!"
                  << std::endl;
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::getNumberOfSteps End "+ QString::number(numSteps) +
                  " " + QString::number(distance) );

    return numSteps;
}

// Calculate direction for movement when walking from origin to target.
Direction AiEngine2::calcMovementDirection( const QPoint& target,
                                           const QPoint& origin ) const
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::calcMovementDirection Start " );

    Direction move = DIRECTION_NONE;

    if ( m_map.isValidPos(target) && m_map.isValidPos(origin) )
    {
        // check if fields are neighbored
        const QPoint diff( target - origin );

        if ( std::abs( diff.x() ) <= 1 && std::abs( diff.y() ) <= 1 )
        {
            if ( diff.x() == -1 )
            {
                if ( diff.y() == -1 )
                {
                    move = DIRECTION_NORTH_WEST;
                }
                else if ( diff.y() == 1 )
                {
                    move = DIRECTION_SOUTH_WEST;
                }
                else
                {
                    move = DIRECTION_WEST;
                }
            }
            else if ( diff.x() == 1 )
            {
                if ( diff.y() == -1 )
                {
                    move = DIRECTION_NORTH_EAST;
                }
                else if ( diff.y() == 1 )
                {
                    move = DIRECTION_SOUTH_EAST;
                }
                else
                {
                    move = DIRECTION_EAST;
                }
            }
            else
            {
                // x == 0
                if ( diff.y() == -1 )
                {
                    move = DIRECTION_NORTH;
                }
                else if ( diff.y() == 1 )
                {
                    move = DIRECTION_SOUTH;
                }
                else
                {
                    move = DIRECTION_NONE;
                }
            }
        }
        else
        {
            std::cerr << "(EE) AiEngine2::calcMovementDirection "
                      << " Positions "
                      << "(" << origin.x() << "," << origin.y() << ") "
                      << "(" << target.x() << "," << target.y() << ") "
                      << " are not neighbored!"
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "(EE) AiEngine2::calcMovementDirection "
                  << " Positions "
                  << "(" << origin.x() << "," << origin.y() << ") "
                  << "(" << target.x() << "," << target.y() << ") "
                  << " are not valid!"
                  << std::endl;
    }
    
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::calcMovementDirection End " + Player::toString(move) );

    return move;
}

// Calculate new viewing direction.
Direction AiEngine2::calcViewingDirection( const QPoint& pos ) const
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::calcViewingDirection Start " );

    Direction view = DIRECTION_NORTH;

    // The principe is simple: We want to see as much as possible.
    // So we will look in the direction that offers the longest view.
    // Of course this is not optimal. The best way would be if we
    // mark the whole area we see and calculate its 2d-space. That's
    // way to complicated.
    
    double longestDist = -1.0;
    
    for ( int ii = 1; ii <= (int)DIRECTION_NORTH_EAST; ii++ )
    {
        const double dist = calcViewingDistance( pos, (Direction)ii );
        
        if ( ( longestDist < 0.0 ) ||
             ( longestDist < dist ) )
        {
            longestDist = dist;
            view = (Direction)ii;
        }
    }

    // we will alternately look in the other direction
    if ( m_round%2 )
    {
        view = Graph::getOppositeDirection(view);
    }
    
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::calcViewingDirection End " + Player::toString(view) );

    return view;
}

// Calculate viewing distance from a position.
double AiEngine2::calcViewingDistance( const QPoint& pos, const Direction dir ) const
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::calcViewingDistance Start " + Player::toString(dir) );
    
    double dist = 0.0;
    
    if ( DIRECTION_NONE != dir )
    {
        QPoint newPos = pos;

        // as default we can view to the boundary of a field
        int counter = 0; 

        bool validPos = true;
        bool isHalfBlocked = false;
        
        do
        {
            // move position in direction
            if ( Player::movePosition( newPos, newPos, dir) )
            {
                validPos = isReachablePos( newPos, dir, isHalfBlocked );
            }
            else
            {
                validPos = false;
            }
            
            if ( validPos )
            {
                counter++;
            }

        } while ( validPos );
        
        // Calculation distance.
        // we have a slightly greater distance value for
        // diagonal views.
        dist = (counter + 0.5) * getDirectionFactor(dir);
    }
    // else we will not move at all, that is not okay
    
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::calcViewingDistance End " + QString::number(dist) );

    return dist;
}

// Get special factor for this direction.
double AiEngine2::getDirectionFactor( const Direction dir ) const
{
    double dist = 0.0;

    switch ( dir )
    {
    case DIRECTION_NORTH:
    case DIRECTION_EAST:
    case DIRECTION_SOUTH:
    case DIRECTION_WEST:
        dist = 1.0;
        break;
    case DIRECTION_NORTH_EAST:
    case DIRECTION_NORTH_WEST:
    case DIRECTION_SOUTH_EAST:
    case DIRECTION_SOUTH_WEST:
        dist = 1.4142;
        break;
    default:
        std::cerr << "(EE) AiEngine2::getDirectionFactor "
                  << " Default case reached for viewing "
                  << Player::toString(dir).toStdString()
                  << std::endl;
        break;
    }

    return dist;
}

// Create random target position if not done before,
bool AiEngine2::createRandomTargetPosition()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::createRandomTargetPosition Start " );

    bool ok = false;

    // check if we already have a target
    if ( m_pathPointCounter == -1 )
    {
        // we need a new random target position
        QPoint targetPos(-1,-1);
        double distance = 0.0;
        
        if ( createRandomPosition( targetPos ) )
        {
            // calculate path to target
            m_pathPointCounter = getNumberOfSteps( m_pathToTarget, distance,
                                     targetPos, m_player.getPosition() );
                                     
            // we must set the counter to one before the last element
            // If the counter is -1 now 
            m_pathPointCounter--;
            m_randomTarget = true;

            ok = true;
        }
    }
    else
    {
        ok = true;
    }
    
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
              "AiEngine2::createRandomTargetPosition End " + QString::number(ok) );

    return ok;
}

// Create random target position if not done before
bool AiEngine2::createRandomPosition( QPoint& pos ) const
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine2::createRandomPosition Start " );

    bool ok = true;
    
    // we will randomly pick a position on the game board
    do
    {
        pos.setX( rand()%(m_map.getSize().width()) );
        pos.setY( rand()%(m_map.getSize().height()) );

        if ( m_map.isValidPos( pos ) )
        {
            if ( m_map[pos].isType( FT_BLOCK ) ||
                 m_map[pos].isType( FT_DOOR ) )
            {
                // we do not want to reach a block or a door
                // because we could never stop there
                pos = QPoint(-1,-1);
            }
        }
        else
        {
            // this should not happen
            std::cerr << "(EE) AiEngine2::createRandomPosition "
                      << " Position ("
                      << pos.x() << ","
                      << pos.y()
                      << ") is not valid on map."
                      << std::endl;
            ok = false;
            break;
        }
    } while ( -1 == pos.x() || -1 == pos.y() );

#ifdef QT_DEBUG
    std::cout << "(II) AiEngine2::createRandomPosition "
              << " Position ("
              << pos.x() << ","
              << pos.y()
              << ")"
              << std::endl;
#endif
    
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
              "AiEngine2::createRandomPosition End " + QString::number(ok) );

    return ok;
}

// Return true if target position is reached.
bool AiEngine2::isTargetPositon( const QPoint& pos ) const
{
    bool isTarget = false;
    
    if ( !m_pathToTarget.isEmpty() )
    {
        // the first value should hold the target position
        if ( pos == m_pathToTarget.front() )
        {
            isTarget = true;
        }
    }
    
    return isTarget;
}

// Delete target path.
void AiEngine2::deleteTargetPath()
{
    m_pathToTarget.clear();
    m_pathPointCounter = -1;
}

// Mark all players as lost that have the given position.
void AiEngine2::markPlayerAsLost( const QPoint& pos, const int exceptId )
{
    const QList<int> playerIds = m_otherPlayers.getListOfIds();

    for ( int ii = 0; ii < playerIds.count(); ii++ )
    {
        if ( exceptId != playerIds[ii] &&
             !m_otherPlayers.isInvalid( playerIds[ii] ) )
        {
            if ( pos == m_otherPlayers.getPosition( playerIds[ii] ) )
            {
                // we stand on the same field as another player
                // that is not possible, so we will mark this player
                // as lost.
                if ( playerIds[ii] < m_numRoundsLastSeenOtherPlayer.count() )
                {
                    m_numRoundsLastSeenOtherPlayer[ playerIds[ii] ] = -1;
                }
                else
                {
                    std::cerr << "(EE) AiEngine2::markPlayerAsLost "
                              << " List for last seen players is not big enough "
                              << m_numRoundsLastSeenOtherPlayer.count()
                              << " for this player "
                              << playerIds[ii]
                              << std::endl;
                }
            }
        }
    }
}

// Match graph weights with actual player positions.
bool AiEngine2::overwriteGraphDistancesForSeeking()
{
    bool ok = true;

    // Note: We suppose here that the actual paths have
    // the distances 1.0 for horizontal and vertical
    // and 0.95 for diagonal movement.

    // We will iterate over all players and will set new distances
    // for the fields the player is standing one and the fields around.
    // this will make some kind of mountains and valleys (if you think
    // of heights instead of distances). So it will be easier to go
    // into a valley (to a blue player) instead on top of a mountain
    // (red player).
    // We will set a value for 4*dist for the pos of red players
    // and 2*dist for the values around.
    // We will set a value of 0.25*dist for the pos of blue players
    // and 0.5*dist for the values around.
    // We will only set new values for blue player we have seen
    // this or the last round and for all red players.

    const QList<int> playerIds = m_otherPlayers.getListOfIds();

    int lastSeen = -1;
    QPoint pos(-1,-1);
    double dist = 0.0;
    Node* node = 0;
    Node* neighbor = 0;
    Direction dir = DIRECTION_NONE;
    Direction oppDir = DIRECTION_NONE;
    Direction dir2 = DIRECTION_NONE;

    for ( int ii = 0; ii < playerIds.count(); ii++ )
    {
        if ( !m_otherPlayers.isInvalid( playerIds[ii] ) )
        {
            // check team
            const Team team = m_otherPlayers.getTeam( playerIds[ii] );

            if ( playerIds[ii] < m_numRoundsLastSeenOtherPlayer.count() )
            {
                lastSeen = m_numRoundsLastSeenOtherPlayer.at( playerIds[ii] );

                if ( TEAM_RED == team ||
                     ( TEAM_BLUE == team && 0 <= lastSeen && lastSeen < 2 ) )
                {
                    // we have found a red or blue player
                    pos = m_otherPlayers.getPosition( playerIds[ii] );

                    // now we will overwrite the distances to this pos
                    node = m_graph[pos];

                    if ( node )
                    {
                        for ( int jj = (int)DIRECTION_NORTH; jj <= (int)DIRECTION_NORTH_EAST; jj++ )
                        {
                            dir = (Direction)jj;
                            dist = node->getDistance( dir );

                            if ( TEAM_RED == team )
                            {
                                dist *= 4;
                            }
                            else if ( TEAM_BLUE == team )
                            {
                                dist /= 4;
                            }

                            if ( node->overwriteNeighborDistance( dir, dist ) )
                            {
                                // now go into this direction and get the neighbor
                                neighbor = node->getNeighbor( dir );

                                if ( neighbor )
                                {
                                    // get the opposite direction
                                    oppDir = Graph::getOppositeDirection( dir );

                                    // overwrite way to pos
                                    if ( neighbor->overwriteNeighborDistance( dir, dist ) )
                                    {
                                        for ( int kk = (int)DIRECTION_NORTH; kk <= (int)DIRECTION_NORTH_EAST; kk++ )
                                        {
                                            dir2 = (Direction)kk;

                                            if ( dir2 != oppDir )
                                            {
                                                dist = neighbor->getDistance( dir2 );

                                                if ( TEAM_RED == team )
                                                {
                                                    dist *= 2;
                                                }
                                                else if ( TEAM_BLUE == team )
                                                {
                                                    dist /= 2;
                                                }

                                                if ( !neighbor->overwriteNeighborDistance( dir2, dist ) )
                                                {
                                                    ok = false;
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        ok = false;
                                        break;
                                    }
                                }
                                // else: it's possible that the neighbor is not set
                                // so no error here
                            }
                            else
                            {
                                ok = false;
                                break;
                            }
                        }
                    }
                    else
                    {
                        std::cerr << "(EE) AiEngine2::overwriteGraphDistancesForSeeking "
                                  << " Node is 0!"
                                  << std::endl;
                        ok = false;
                        break;
                    }
                }
            }
            else
            {
                std::cerr << "(EE) AiEngine2::overwriteGraphDistancesForSeeking "
                          << " List for last seen players is not big enough "
                          << m_numRoundsLastSeenOtherPlayer.count()
                          << " for this player "
                          << playerIds[ii]
                          << std::endl;
                ok = false;
                break;
            }
        }

        if ( !ok )
        {
            break;
        }
    } // for ii

    // Note: Man könnte auch überlegen, ob man die ganzen Daten
    // wegen Abstand zur Wand, Toxic etc. gleich in den Graph
    // einfließen lässt.

    return ok;
}


