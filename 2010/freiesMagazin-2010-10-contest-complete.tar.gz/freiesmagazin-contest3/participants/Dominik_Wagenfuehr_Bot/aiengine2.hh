/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef AIENGINE2_HH
#define AIENGINE2_HH

// Own
/////////
#include "aiengine.hh"
#include "graph.hh"

// Qt
///////
#include <QObject>
#include <QList>

/// Engine for artifical engine.
/**
 * The engine holds all data and client for receiving and sending
 * data. It must parse all data and calculate the next move of the ai.
 */
class AiEngine2 : public AiEngine
{
Q_OBJECT

public:
    /// Constructor
    /**
     * Create a new engine with a empty player and an empty map.
     */
    AiEngine2();
    
    /// Destructor
    virtual ~AiEngine2() { }

private:

    /// Connect another client.
    /**
     * Overloaded method.
     */
    virtual void processCommandConnectOther();

    /// Disconnect another client.
    /**
     * Overloaded method.
     */
    virtual void processCommandDisconnectOther();

    /// Set data of own player.
    /**
     * Overloaded method.
     */
    virtual void processCommandSet();

    /// Set data of other player.
    /**
     * Overloaded method.
     */
    virtual void processCommandSeePlayer();

    /// See a new key.
    /**
     * Overloaded method.
     */
    virtual void processCommandSeeKey();

    /// Get a new key
    /**
     * Overloaded method.
     */
    virtual void processCommandGetKey();

    /// change the team of a player
    /**
     * Overloaded method.
     */
    virtual void processCommandTeamChange();

    /// Load new map.
    /**
     * Overloaded method.
     */
    virtual void processCommandLoadMap();

    /// Store toxic value in game map.
    /**
     * Overloaded method.
     */
    virtual void processCommandStoreToxicValue();

    /// Start calculation of next move.
    /**
     * Overloaded method.
     */
    virtual void processCommandStartCalculation();

    /// Calculate next move of player.
    /**
     * Overloaded method.
     * Depending on the team the player will move
     * in some way over to field. A direction he moves
     * and a new viewing direction will be calculated.
     * @return true if everything is okay
     */
    virtual bool calcNextMove( Direction& move, Direction& view );

    /// Calculate next move of player to hide somewhere.
    /**
     * The player will try to hide somewhere.
     * @return true if everything is okay
     */
    bool calcNextMoveHide( Direction& move, Direction& view );

    /// Return true if the position is reachable by the movement.
    bool isReachablePos( const QPoint& pos, const Direction move, bool& isHalfBlocked ) const;

    /// Calculate for this direction 
    bool calculateHideValue( double& value, QPoint& pos, const Direction move );
    
    /// Return number of free fields around the given field.
    /**
     * If the field is freely accessable we add 1.0, if we need
     * to go around a corner we add 0.25.
     */
    double getNumFreeFields( const QPoint& pos ) const;

    /// Calculate next move of player to seek other players.
    /**
     * The player will search the next player of the other team
     * and follow him.
     * @return true if everything is okay
     */
    bool calcNextMoveSeek( Direction& move, Direction& view );

    /// Calculate movement and view from a precalculated target.
    bool calculateMoveAndViewFromTarget( Direction& move, Direction& view,
                                        const bool alwaysUseBestView = false );

    /// Get the number of steps we need to reach the target form origin.
    /**
     * @return -1 if there is no way
     */
    int getNumberOfSteps( QList<QPoint>& path, double& distance,
                          const QPoint& target, const QPoint& origin );

    /// Calculate direction for movement when walking from origin to target.
    /**
     * Both positions must be valid and neighbored!
     */
    Direction calcMovementDirection( const QPoint& target, const QPoint& origin ) const;

    /// Calculate new viewing direction.
    /**
     * The new viewing direction depends on the position and the
     * environment. We will choose a viewing direction where we can see
     * a long way.
     */
    Direction calcViewingDirection( const QPoint& pos ) const;
    
    /// Get special factor for this direction.
    double getDirectionFactor( const Direction dir ) const;
    
    /// Calculate viewing distance from a position.
    double calcViewingDistance( const QPoint& pos, const Direction dir ) const;

    /// Create random target position.
    bool createRandomPosition( QPoint& pos ) const;

    /// Create random target position if not done before,
    bool createRandomTargetPosition();

    /// Return true if target position is reached.
    bool isTargetPositon( const QPoint& pos ) const;

    /// Delete target path.
    void deleteTargetPath();

    /// Check if some field is occupied by some player.
    bool isBlockedByOtherPlayer( const QPoint& pos, const bool absolute = true ) const;

    /// Mark all players as lost that have the given position.
    void markPlayerAsLost( const QPoint& pos, const int exceptId = -1 );

    /// Match graph weights with actual player positions.
    bool overwriteGraphDistancesForSeeking();

private:
    
    /// Graph to loaded game map.
    Graph m_graph;

    /// Number of rounds we have last seen another player.
    /**
     * For each player we store how many round we not have seen
     * him. So we can decide if it's good to follow such a player.
     * E.g. if the player was seen last 10 rounds ago he can be
     * almost anywhere on the game board now. No need to follow
     * him.
     * The value will be set to 0 if a player is seen and increased
     * after a round.
     * It will be set to -1 if we totally have lost track of the
     * player.
     */
    QList<int> m_numRoundsLastSeenOtherPlayer;
    
    /// Path to next target.
    /**
     * This list stores the current target and it's path to it.
     * The list is backwards starting at the target and going to
     * the start position.
     * If the list is empty, no target is defined.
     */
    QList<QPoint> m_pathToTarget;
    
    /// Counter for current index in path target.
    /**
     * This is set to -1 if no target is defined.
     */
    int m_pathPointCounter;
    
    /// Flag if the current tag is a random target.
    bool m_randomTarget;
    
    /// Moving direction of last round.
    Direction m_lastMovingDirection;

    /// Current round.
    int m_round;
};

#endif // AIENGINE2_HH
