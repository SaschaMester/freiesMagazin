/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef CLIENTPARSER_H
#define CLIENTPARSER_H

// Own
////////
#include "parser.hh"
#include "clientparsercommand.hh"
#include "key.hh"
#include "team.hh"
#include "direction.hh"

// Qt
////////
#include <QPoint>
#include <QString>

// Forward declarations
//////////////////////////
class QStringList;

/// Class for parsing network commands on a client.
/**
 * This class receives data from its base class.
 * It checks the strings for the sender, commands and parameters.
 * If a data string has been parsed the command will
 * be stored inside a queue and can be processed later.
 * 
 * Note: ClientParser parses client connections that means
 * all data a client can receive from a server or from other clients.
 */
class ClientParser : public Parser
{

public:
    /// Constructor.
    ClientParser();

    /// Initializes/reset all variables with default values.
    /**
     * This method should be called after processNextCommand
     * and the caller has processed all variables outside.
     * If you do not call this method the variables will never
     * be set back and no further command can be processed.
     */
    void reset();
    
    /// Reset all data and deletes all commands in the command queue.
    /**
     * This is the same as reset() but will delete all commands in the
     * queue. So handle with care!
     */
    void resetAll();

    /// Process next command from command queue.
    /**
     * The next element from the command queue will be get and
     * processed if possible. The return value tell the caller
     * what command it is and what data he can get now.
     * Normally the other class should process or at least get and
     * reset all data. Otherwise it will come to an error.
     * @return command enum that tells which command has been processed
     */
    ClientParserCommand processNextCommand();
    
    //////////////////////
    // Getter-methods
    //////////////////////

    /// Return client id.
    /**
     * This variable is set for most commands.
     * @return client id
     */
    int getClientId() const { return m_clientId; }

    /// Return stored position.
    /**
     * This variable is set, if CPC_SET_PLAYER is the current command.
     * @return position
     */
    const QPoint& getPosition() const { return m_pos; }

    /// Return stored view.
    /**
     * This variable is set, if CPC_SET_PLAYER is the current command.
     * @return view
     */
    Direction getView() const { return m_view; }

    /// Return stored team.
    /**
     * This variable is set, if CPC_TEAM_CHANGE is the current command.
     * @return team
     */
    Team getTeam() const { return m_team; }

    /// Return stored key.
    /**
     * This variable is set, if CPC_SEE_KEY or CPC_GET_KEY is the current command.
     * @return key
     */
    const Key& getKey() const { return m_key; }
    
    /// Return filename of map.
    /**
     * This variable is set, if CPC_LOAD_MAP is the current command.
     * @return team
     */
    const QString& getMapName() const { return m_map; }

    /// Return double value.
    /**
     * This variable is set, if CPC_TOXIC or CPC_LIFE is the current command.
     * @return team
     */
    double getDoubleValue() const { return m_doubleValue; }

    /// Return round.
    /**
     * This variable is set, if CPC_START is the current command.
     * @return team
     */
    int getRound() const { return m_round; }
    
private:
    /// Process command.
    /**
     * Process all command parts in the given list.
     * It then stores the relevant parts inside variables.
     * Depending on the data given the return value
     * tells the caller what are the correct variables to get.
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ClientParserCommand processCommand( QStringList& commandParts );

    /// Process command that comes from the server.
    /**
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ClientParserCommand processServerCommand( QStringList& commandParts );

    /// Process server command that will set the id.
    /**
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ClientParserCommand processServerCommandId( QStringList& commandParts );

    /// Process server command that another client has connected.
    /**
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ClientParserCommand processServerCommandConnectClient( QStringList& commandParts );

    /// Process server command that another client has disconnected.
    /**
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ClientParserCommand processServerCommandDisconnectClient( QStringList& commandParts );

    /// Process server command to set properties of own player.
    /**
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ClientParserCommand processServerCommandSetOwnPlayer( QStringList& commandParts );
    
    /// Process server command to set properties of other players.
    /**
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ClientParserCommand processServerCommandSeePlayer( QStringList& commandParts );
    
    /// Process server command that a key is seen.
    /**
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ClientParserCommand processServerCommandSeeKey( QStringList& commandParts );
    
    /// Process server command that a key could be get.
    /**
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ClientParserCommand processServerCommandGetKey( QStringList& commandParts );
    
    /// Process server command that a player has changed the team.
    /**
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ClientParserCommand processServerCommandTeamChange( QStringList& commandParts );

    /// Process server command that a map should be loaded.
    /**
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ClientParserCommand processServerCommandLoadMap( QStringList& commandParts );
    
    /// Process server command that sets the life energy for a player.
    /**
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ClientParserCommand processServerCommandLife( QStringList& commandParts );
    
    /// Process server command that sets the toxic value for a field.
    /**
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ClientParserCommand processServerCommandToxic( QStringList& commandParts );
    
    /// Process server command that extracts the round number.
    /**
     * @param commandParts List with all command parts to process.
     *        The list should be empty after it has been processed.
     * @return command enum that tells which command has been processed
     */
    ClientParserCommand processServerCommandStartRound( QStringList& commandParts );


private:
    /// Check if all variables has been processed/resetted.
    /**
     * This method checks all variables if some is still set before
     * processing another command. If one is still set that means
     * that noone has get it outside.
     * @return true if all data has been processed or reset properly.
     */
    bool isAllVarsProcessed();

    /// Process a command that extracts an id.
    /**
     * @param commandParts List with all command parts to process.
     * @return true if no error has occured
     */
    bool processCommandId( QStringList& commandParts );

    /// Process a command that extracts a position.
    /**
     * @param commandParts List with all command parts to process.
     * @return true if no error has occured
     */
    bool processCommandPos( QStringList& commandParts );

    /// Process a command that extracts a direction.
    /**
     * @param commandParts List with all command parts to process.
     * @return true if no error has occured
     */
    bool processCommandDir( QStringList& commandParts );

    /// Process a command that extracts a key.
    /**
     * @param commandParts List with all command parts to process.
     * @return true if no error has occured
     */
    bool processCommandKey( QStringList& commandParts );

    /// Process a command that extracts a team.
    /**
     * @param commandParts List with all command parts to process.
     * @return true if no error has occured
     */
    bool processCommandTeam( QStringList& commandParts );

    /// Process a command that extracts a double value.
    /**
     * @param commandParts List with all command parts to process.
     * @return true if no error has occured
     */
    bool processCommandDoubleValue( QStringList& commandParts );

    /// Process a command that extracts the round number.
    /**
     * @param commandParts List with all command parts to process.
     * @return true if no error has occured
     */
    bool processCommandRound( QStringList& commandParts );

private:
    //////////////////////
    // members
    //////////////////////
    
    /// Current command that has been processed.
    /**
     * If there is no command, it will be set to CPC_NO_COMMAND (default).
     */
    ClientParserCommand m_commandId;
    
    /// The client id that has been processed from a command.
    /**
     * If there is no id, it will be set to NO_INDEX (default).
     * Necessary for all but CPC_PING, CPC_LOAD_MAP and CPC_SET_PLAYER.
     */
    int m_clientId;

    /// New position that should be set.
    /**
     * Only valid if the command is CPC_SEE_PLAYER, CPC_SET_PLAYER
     * or CPC_SEE_KEY.
     */
    QPoint m_pos;

    /// New direction that should be set.
    /**
     * Only valid if the command is CPC_SEE_PLAYER or CPC_SET_PLAYER.
     */
    Direction m_view;

    /// New team a player should change to.
    /**
     * Only valid if the command is CPC_TEAM_CHANGE.
     */
    Team m_team;

    /// Visible key.
    /**
     * Only valid if the command is CPC_SEE_KEY or CPC_GET_KEY.
     */
    Key m_key;

    /// Filename of the map that should be loaded.
    /**
     * Only valid if the command is CPC_LOAD_MAP.
     */
    QString m_map;

    /// Some double value.
    /**
     * Only valid if the command is CPC_TOXIC or CPC_LIFE.
     */
    double m_doubleValue;

    /// Round number.
    /**
     * Only valid if the command is CPC_START.
     */
    int m_round;  

    // Note: Even if some of the variables excludes each other I don't
    // use a union because we have enough memory - and unions are
    // devil's work.
};

#endif // CLIENTPARSER_H
