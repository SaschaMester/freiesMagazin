/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "clientparser.hh"
#include "trace.hh"

// Qt
////////
#include <QStringList>

// Sys
////////
#include <iostream>

// Constructor.
ClientParser::ClientParser()
: Parser()
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_STRUCTOR,
                  "ClientParser::ClientParser Start" );

    // initialize variables
    reset();

    Trace::print( MTP_CLIENTPARSER, STP_CP_STRUCTOR,
                  "ClientParser::ClientParser End" );
}

// Initializes/reset all variables with default values.
void ClientParser::reset()
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_SET,
                  "ClientParser::reset Start" );

    // no command given
    m_commandId = CPC_NO_COMMAND;
    
    // no client id
    m_clientId = -1;

    // no valid position
    m_pos.setX(-1);
    m_pos.setY(-1);

    // no view set
    m_view = DIRECTION_NONE;

    // team is not set (BLUE is default)
    m_team = TEAM_BLUE;

    // empty the filename of the map
    m_map.clear();

    // set double value
    m_doubleValue = 0.0;

    // reset round counter
    m_round = 0;

    Trace::print( MTP_CLIENTPARSER, STP_CP_SET,
                  "ClientParser::reset End" );
}

// Reset all data and deletes all commands in the command queue.
void ClientParser::resetAll()
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_SET,
                  "ClientParser::resetAll Start" );

    reset();
    
    // delete queue
    while ( !isCommandQueueEmpty() )
    {
        getNextCommand();
    }

    Trace::print( MTP_CLIENTPARSER, STP_CP_SET,
                  "ClientParser::resetAll End" );
}
    
// Process next command from command queue.
ClientParserCommand ClientParser::processNextCommand()
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processNextCommand Start" );

    ClientParserCommand nextCommand = CPC_NO_COMMAND;
    
    if ( !isCommandQueueEmpty() )
    {
        // there is one element in the queue

        // check for unprocessed variables
        if ( isAllVarsProcessed() )
        {
            // get next command
            const Command command = getNextCommand();

            // split the string by spaces into parts
            QStringList commandParts( Parser::split( command.getCommand() ) );
            
#ifdef QT_DEBUG
    std::cout << "(II) ClientParser::processNextCommand "
              << " Command "
              << " \"" << command.getCommand().toStdString() << "\""
              << " from sender " << command.getIndex()
              << " list count: " << commandParts.count()
              << std::endl;
#endif

            // Little hack:
            // If the first command is "SERV" I run the old server.
            // We will delete this word.
            if ( commandParts.count() > 0 )
            {
                if ( 0 == commandParts.first().compare( "SERV" ) )
                {
                    commandParts.removeFirst();
                }
            }

            // process all command parts
            nextCommand = processCommand( commandParts );

            if ( CPC_ERROR != nextCommand )
            {
                // if the command has not produced an error
                // the command part list should be empty
                
                if ( !commandParts.isEmpty() )
                {
                    std::cerr << "(EE) ClientParser::processNextCommand "
                              << " There are still "
                              << commandParts.count()
                              << " command parts in the list: "
                              << "\"" << commandParts.first().toStdString() << "\""
                              << std::endl;
 
                    reset();
                    nextCommand = CPC_ERROR;
                }
            }
            
            if ( CPC_ERROR != nextCommand )
            {
                // if the command has not produced an error
                // check if the index of the command is -1
                // because the command MUST come from the server.
                if ( -1 != command.getIndex() )
                {
                    std::cerr << "(EE) ClientParser::processNextCommand "
                              << " Sender index "
                              << command.getIndex()
                              << " does not equal -1 as expected."
                              << std::endl;
 
                    reset();
                    nextCommand = CPC_ERROR;
                }
            }
        }
        else
        {
            // else there are still variables that has not been processed
            // so we will wait till this is done.
            nextCommand = m_commandId;
        }
    }

    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processNextCommand End " + QString::number(nextCommand) );
    
    return nextCommand;
}

// Check if all variables has been processed/resetted.
bool ClientParser::isAllVarsProcessed()
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::isAllVarsProcessed Start " );

    bool processed = true;

    if ( CPC_NO_COMMAND != m_commandId )
    {
        processed = false;
    }

    // Note: It's enough to check if there is no command pending.
    // If none is, we can set a new command and only this variables
    // are valid.

#ifdef QT_DEBUG
    std::cout << "(II) ClientParser::isAllVarsProcessed "
              << " All processed: "   << processed
              << std::endl;
#endif

    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::isAllVarsProcessed End " + QString::number((int)processed) );

    return processed;
}

// Process command parts.
ClientParserCommand ClientParser::processCommand( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processCommand Start " + QString::number(commandParts.count()) );

    ClientParserCommand nextCommand = CPC_NO_COMMAND;

    // Check if there is a least one command part
    if ( commandParts.count() > 0 )
    {
        // process other command parts
        nextCommand = processServerCommand( commandParts );
    }
    else
    {
        std::cerr << "(EE) ClientParser::processCommand "
                  << " Command part list is empty."
                  << std::endl;
                  
        reset();
        nextCommand = CPC_ERROR;
    }
    
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processCommand End " + QString::number(nextCommand) );

    return nextCommand;
}

// Process command that comes from the server.
ClientParserCommand ClientParser::processServerCommand( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommand Start " + QString::number(commandParts.count()) );

    ClientParserCommand nextCommand = CPC_NO_COMMAND;

    // Check if there is a least one command part
    if ( commandParts.count() > 0 )
    {
#ifdef QT_DEBUG
        std::cout << "(II) ClientParser::processServerCommand "
                  << " Command"
                  << " \"" << commandParts.first().toStdString() << "\"."
                  << std::endl;
#endif

        if  ( 0 == commandParts.first().compare( "ID" ) )
        {
            // this is an id
            
            // delete first part that has been processed
            commandParts.removeFirst();              
            
            // process the id given from the server
            nextCommand = processServerCommandId( commandParts );
        }
        else if  ( 0 == commandParts.first().compare( "PING" ) )
        {
            // delete first part that has been processed
            commandParts.removeFirst();
            
            // this is just a ping
            nextCommand = CPC_PING;
        }
        else if  ( 0 == commandParts.first().compare( "CONNECTED" ) )
        {
            // delete first part that has been processed
            commandParts.removeFirst();
            
            // extrac client id that has connected
            nextCommand = processServerCommandConnectClient( commandParts );
        }
        else if  ( 0 == commandParts.first().compare( "DISCONNECTED" ) )
        {
            // delete first part that has been processed
            commandParts.removeFirst();
            
            // extrac client id that has disconnected
            nextCommand = processServerCommandDisconnectClient( commandParts );
        }
        else if  ( 0 == commandParts.first().compare( "DISCONNECT" ) )
        {
            // delete first part that has been processed
            commandParts.removeFirst();
            
            // extract client id that has disconnected
            nextCommand = CPC_DISCONNECT_SELF;
        }
        else if  ( 0 == commandParts.first().compare( "SET" ) )
        {
            // delete first part that has been processed
            commandParts.removeFirst();
            
            // extract new player data
            nextCommand = processServerCommandSetOwnPlayer( commandParts );
        }
        else if  ( 0 == commandParts.first().compare( "SEE_PLAYER" ) )
        {
            // delete first part that has been processed
            commandParts.removeFirst();

            // extract new player data
            nextCommand = processServerCommandSeePlayer( commandParts );
        }
        else if  ( 0 == commandParts.first().compare( "SEE_KEY" ) )
        {
            // delete first part that has been processed
            commandParts.removeFirst();

            // extract new key
            nextCommand = processServerCommandSeeKey( commandParts );
        }
        else if  ( 0 == commandParts.first().compare( "GET_KEY" ) )
        {
            // delete first part that has been processed
            commandParts.removeFirst();

            // extract new key
            nextCommand = processServerCommandGetKey( commandParts );
        }        
        else if  ( 0 == commandParts.first().compare( "TEAMCHANGE" ) )
        {
            // delete first part that has been processed
            commandParts.removeFirst();
            
            // a player should change the team
            nextCommand = processServerCommandTeamChange( commandParts );
        }        
        else if  ( 0 == commandParts.first().compare( "MAP" ) )
        {
            // delete first part that has been processed
            commandParts.removeFirst();

            // extract filename of map for loading
            nextCommand = processServerCommandLoadMap( commandParts );
        }
        else if  ( 0 == commandParts.first().compare( "START" ) )
        {
            // delete first part that has been processed
            commandParts.removeFirst();

            // extract round
            nextCommand = processServerCommandStartRound( commandParts );
        }
        else if  ( 0 == commandParts.first().compare( "LIFE" ) )
        {
            // delete first part that has been processed
            commandParts.removeFirst();

            // a players life energy has changed
            nextCommand = processServerCommandLife( commandParts );
        }
        else if  ( 0 == commandParts.first().compare( "TOXIC" ) )
        {
            // delete first part that has been processed
            commandParts.removeFirst();

            // the toxic value of the current field is set
            nextCommand = processServerCommandToxic( commandParts );
        }        
        else
        {
            // everything else is not understood!
            std::cerr << "(EE) ClientParser::processServerCommand "
                      << " Do not understand command"
                      << " \"" << commandParts.first().toStdString() << "\"."
                      << std::endl;

            reset();
            nextCommand = CPC_ERROR;
        }
    }
    else
    {
        std::cerr << "(EE) ClientParser::processServerCommand "
                  << " Command part list is empty."
                  << std::endl;
        
        reset();
        nextCommand = CPC_ERROR;
    }

    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommand End " + QString::number(nextCommand) );

    return nextCommand;
}

// Process server command that will set the id.
ClientParserCommand ClientParser::processServerCommandId( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandId Start " + QString::number(commandParts.count()) );

    ClientParserCommand nextCommand = CPC_NO_COMMAND;
    
    // extract the client id
    if ( processCommandId( commandParts ) )
    {
        nextCommand = CPC_SET_ID;
    }
    else
    {
        reset();
        nextCommand = CPC_ERROR;
    }
    
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandId End " + QString::number(nextCommand) );

    return nextCommand;
}

// Process server command that another client has connected.
ClientParserCommand ClientParser::processServerCommandConnectClient( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandConnectClient Start " + QString::number(commandParts.count()) );

    ClientParserCommand nextCommand = CPC_NO_COMMAND;
    
    // extract the client id
    if ( processCommandId( commandParts ) )
    {
        nextCommand = CPC_CONNECT_OTHER;
    }
    else
    {
        reset();
        nextCommand = CPC_ERROR;
    }
    
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandConnectClient End " + QString::number(nextCommand) );

    return nextCommand;
}

// Process server command that another client has disconnected.
ClientParserCommand ClientParser::processServerCommandDisconnectClient( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandDisconnectClient Start " + QString::number(commandParts.count()) );

    ClientParserCommand nextCommand = CPC_NO_COMMAND;
    
    // extract the client id
    if ( processCommandId( commandParts ) )
    {
        nextCommand = CPC_DISCONNECT_OTHER;
    }
    else
    {
        reset();
        nextCommand = CPC_ERROR;
    }
    
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandDisconnectClient End " + QString::number(nextCommand) );

    return nextCommand;
}

// Process server command to set properties of other players.
ClientParserCommand ClientParser::processServerCommandSetOwnPlayer( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandSetOwnPlayer Start " + QString::number(commandParts.count()) );

    ClientParserCommand nextCommand = CPC_NO_COMMAND;
    
    // Check if there is a least three command parts
    // first command is the position
    if ( processCommandPos( commandParts ) )
    {
        // second command is the viewing direction
        if ( processCommandDir( commandParts ) )
        {
            nextCommand = CPC_SET_PLAYER;
        }
        else
        {
            reset();
            nextCommand = CPC_ERROR;
        }
    }
    else
    {
        reset();
        nextCommand = CPC_ERROR;
    }

    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandSetOwnPlayer End " + QString::number(nextCommand) );

    return nextCommand;
}

// Process server command to set properties of other players.
ClientParserCommand ClientParser::processServerCommandSeePlayer( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandSeePlayer Start " + QString::number(commandParts.count()) );

    ClientParserCommand nextCommand = CPC_NO_COMMAND;
    
    // Check if there is a least three command parts
    // first command is the position
    if ( processCommandPos( commandParts ) )
    {
        // second command is the viewing direction
        if ( processCommandDir( commandParts ) )
        {
            // third is the player id
            if ( processCommandId( commandParts ) )
            {
                nextCommand = CPC_SEE_PLAYER;
            }
            else
            {
                reset();
                nextCommand = CPC_ERROR;
            }
        }
        else
        {
            reset();
            nextCommand = CPC_ERROR;
        }
    }
    else
    {
        reset();
        nextCommand = CPC_ERROR;
    }

    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandSeePlayer End " + QString::number(nextCommand) );

    return nextCommand;
}

// Process server command that a key is seen.
ClientParserCommand ClientParser::processServerCommandSeeKey( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandSeeKey Start " + QString::number(commandParts.count()) );

    ClientParserCommand nextCommand = CPC_NO_COMMAND;
    
    // Check if there is a least two command parts
    // first command is the position
    if ( processCommandPos( commandParts ) )
    {
        // second command is the key
        if ( processCommandKey( commandParts ) )
        {
            nextCommand = CPC_SEE_KEY;
        }
        else
        {
            reset();
            nextCommand = CPC_ERROR;
        }
    }
    else
    {
        reset();
        nextCommand = CPC_ERROR;
    }

    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandSeeKey End " + QString::number(nextCommand) );

    return nextCommand;
}
    
// Process server command that a key could be get.
ClientParserCommand ClientParser::processServerCommandGetKey( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandGetKey Start " + QString::number(commandParts.count()) );

    ClientParserCommand nextCommand = CPC_NO_COMMAND;
    
    // first command is the key
    if ( processCommandKey( commandParts ) )
    {
        nextCommand = CPC_GET_KEY;
    }
    else
    {
        reset();
        nextCommand = CPC_ERROR;
    }

    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandGetKey End " + QString::number(nextCommand) );

    return nextCommand;
}

// Process server command that a player has changed the team.
ClientParserCommand ClientParser::processServerCommandTeamChange( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandTeamChange Start " + QString::number(commandParts.count()) );

    ClientParserCommand nextCommand = CPC_NO_COMMAND;

    // first command is the team
    if ( processCommandTeam( commandParts ) )
    {
        // second is the player id
        if ( processCommandId( commandParts ) )
        {
            nextCommand = CPC_TEAM_CHANGE;
        }
        else
        {
            reset();
            nextCommand = CPC_ERROR;
        }
    }
    else
    {
        reset();
        nextCommand = CPC_ERROR;
    }

    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandTeamChange End " + QString::number(nextCommand) );

    return nextCommand;
}

// Process server command that a map should be loaded.
ClientParserCommand ClientParser::processServerCommandLoadMap( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandLoadMap Start " + QString::number(commandParts.count()) );

    ClientParserCommand nextCommand = CPC_NO_COMMAND;
    
    // Check if there is a least one command part
    if ( commandParts.count() > 0 )
    {
#ifdef QT_DEBUG
        std::cout << "(II) ClientParser::processServerCommandLoadMap "
                  << " Map"
                  << " \"" << commandParts.first().toStdString() << "\"."
                  << std::endl;
#endif

        // extract the file name of the map
        m_map = commandParts.first();

        // delete first part that has been processed
        commandParts.removeFirst();              

        if ( !m_map.isEmpty() )
        {
            // the map name is not empty
            nextCommand = CPC_LOAD_MAP;
        }
        else
        {
            std::cerr << "(EE) ClientParser::processServerCommandLoadMap "
                      << " Map name is empty."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "(EE) ClientParser::processServerCommandLoadMap "
                  << " Command part list is empty."
                  << std::endl;
    }
    
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandLoadMap End " + QString::number(nextCommand) );

    return nextCommand;
}

// Process server command that sets the life energy for a player.
ClientParserCommand ClientParser::processServerCommandLife( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandLife Start " + QString::number(commandParts.count()) );

    ClientParserCommand nextCommand = CPC_NO_COMMAND;
    
    // Check if there is a least two command parts
    // first command is the value
    if ( processCommandDoubleValue( commandParts ) )
    {
        // second command is the player id
        if ( processCommandId( commandParts ) )
        {
            nextCommand = CPC_LIFE;
        }
        else
        {
            reset();
            nextCommand = CPC_ERROR;
        }
    }
    else
    {
        reset();
        nextCommand = CPC_ERROR;
    }

    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandLife End " + QString::number(nextCommand) );

    return nextCommand;
}

// Process server command that sets the toxic value for a field.
ClientParserCommand ClientParser::processServerCommandToxic( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandToxic Start " + QString::number(commandParts.count()) );

    ClientParserCommand nextCommand = CPC_NO_COMMAND;
    
    // Check if there is a least two command parts
    // first command is the position
    if ( processCommandPos( commandParts ) )
    {
        // second command is the value
        if ( processCommandDoubleValue( commandParts ) )
        {
            nextCommand = CPC_TOXIC;
        }
        else
        {
            reset();
            nextCommand = CPC_ERROR;
        }
    }
    else
    {
        reset();
        nextCommand = CPC_ERROR;
    }

    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandToxic End " + QString::number(nextCommand) );

    return nextCommand;
}

    
// Process server command that extracts the round number.
ClientParserCommand ClientParser::processServerCommandStartRound( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandStartRound Start " + QString::number(commandParts.count()) );

    ClientParserCommand nextCommand = CPC_NO_COMMAND;
    
    // first command is the round
    if ( processCommandRound( commandParts ) )
    {
        nextCommand = CPC_START;
    }
    else
    {
        reset();
        nextCommand = CPC_ERROR;
    }

    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processServerCommandStartRound End " + QString::number(nextCommand) );

    return nextCommand;
}

// Process a command that extracts an id.
bool ClientParser::processCommandId( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processCommandId Start " + QString::number(commandParts.count()) );

    bool ok = false;

    // Check if there is a least one command part
    if ( commandParts.count() > 0 )
    {
#ifdef QT_DEBUG
        std::cout << "(II) ClientParser::processCommandId "
                  << " Command"
                  << " \"" << commandParts.first().toStdString() << "\"."
                  << std::endl;
#endif

        // the next command holds a client id
        if ( Parser::getId( m_clientId, commandParts.first() ) )
        {
            if ( m_clientId >= 0 )
            {
                // The id could be extracted.
                ok = true;
            }
            else
            {
                std::cerr << "(EE) ClientParser::processCommandId "
                          << " Client id "
                          << m_clientId
                          << " is negative."
                          << std::endl;
            }
        }

        // delete first part that has been processed
        commandParts.removeFirst();              

    }
    else
    {
        std::cerr << "(EE) ClientParser::processCommandId "
                  << " Command part list is empty."
                  << std::endl;
    }
    
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processCommandId End " + QString::number((int)ok) );

    return ok;
}

// Process a command that extracts a position.
bool ClientParser::processCommandPos( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processCommandPos Start " + QString::number(commandParts.count()) );

    bool ok = false;

    // Check if there is a least one command part
    if ( commandParts.count() > 0 )
    {
#ifdef QT_DEBUG
        std::cout << "(II) ClientParser::processCommandPos "
                  << " Command"
                  << " \"" << commandParts.first().toStdString() << "\"."
                  << std::endl;
#endif

        // the next command holds a position
        if ( Parser::getPos( m_pos, commandParts.first() ) )
        {
            if ( m_pos.x() >= 0 && m_pos.y() >= 0 )
            {
                // The pos could be extracted.
                ok = true;
            }
            else
            {
                std::cerr << "(EE) ClientParser::processCommandPos "
                          << " Client position "
                          << "( " << m_pos.x() << ", " << m_pos.y() << " )"
                          << " is negative."
                          << std::endl;
            }
        }

        // delete first part that has been processed
        commandParts.removeFirst();              
    }
    else
    {
        std::cerr << "(EE) ClientParser::processCommandPos "
                  << " Command part list is empty."
                  << std::endl;
    }
    
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processCommandPos End " + QString::number((int)ok) );

    return ok;
}

// Process a command that extracts a direction.
bool ClientParser::processCommandDir( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processCommandDir Start " + QString::number(commandParts.count()) );

    bool ok = false;

    // Check if there is a least one command part
    if ( commandParts.count() > 0 )
    {
#ifdef QT_DEBUG
        std::cout << "(II) ClientParser::processCommandDir "
                  << " Command"
                  << " \"" << commandParts.first().toStdString() << "\"."
                  << std::endl;
#endif

        // the next command holds a direction
        if ( Parser::getDir( m_view, commandParts.first() ) )
        {
            if ( m_view != DIRECTION_NONE )
            {
                // The direction could be extracted.
                ok = true;
            }
            else
            {
                std::cerr << "(EE) ClientParser::processCommandDir "
                          << " Client view "
                          << m_view
                          << " is not valid."
                          << std::endl;
            }
        }

        // delete first part that has been processed
        commandParts.removeFirst();              
    }
    else
    {
        std::cerr << "(EE) ClientParser::processCommandDir "
                  << " Command part list is empty."
                  << std::endl;
    }
    
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processCommandDir End " + QString::number((int)ok) );

    return ok;
}

// Process a command that extracts a key.
bool ClientParser::processCommandKey( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processCommandKey Start " + QString::number(commandParts.count()) );

    bool ok = false;

    // Check if there is a least one command part
    if ( commandParts.count() > 0 )
    {
#ifdef QT_DEBUG
        std::cout << "(II) ClientParser::processCommandKey "
                  << " Command"
                  << " \"" << commandParts.first().toStdString() << "\"."
                  << std::endl;
#endif

        // the next command holds a direction
        if ( Parser::getKey( m_key, commandParts.first() ) )
        {
            // The key could be extracted.
            ok = true;
        }

        // delete first part that has been processed
        commandParts.removeFirst();              
    }
    else
    {
        std::cerr << "(EE) ClientParser::processCommandKey "
                  << " Command part list is empty."
                  << std::endl;
    }
    
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processCommandKey End " + QString::number((int)ok) );

    return ok;
}

bool ClientParser::processCommandTeam( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processCommandTeam Start " + QString::number(commandParts.count()) );

    bool ok = false;

    // Check if there is a least one command part
    if ( commandParts.count() > 0 )
    {
#ifdef QT_DEBUG
        std::cout << "(II) ClientParser::processCommandTeam "
                  << " Command"
                  << " \"" << commandParts.first().toStdString() << "\"."
                  << std::endl;
#endif

        // the next command holds a client id
        if ( Parser::getTeam( m_team, commandParts.first() ) )
        {
            // The team could be extracted.
            ok = true;
        }

        // delete first part that has been processed
        commandParts.removeFirst();              
    }
    else
    {
        std::cerr << "(EE) ClientParser::processCommandTeam "
                  << " Command part list is empty."
                  << std::endl;
    }
    
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processCommandTeam End " + QString::number((int)ok) );

    return ok;
}

// Process a command that extracts a doubel value.
bool ClientParser::processCommandDoubleValue( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processCommandDoubleValue Start " + QString::number(commandParts.count()) );

    bool ok = false;

    // Check if there is a least one command part
    if ( commandParts.count() > 0 )
    {
#ifdef QT_DEBUG
        std::cout << "(II) ClientParser::processCommandDoubleValue "
                  << " Command"
                  << " \"" << commandParts.first().toStdString() << "\"."
                  << std::endl;
#endif

        // the next command holds a client id
        if ( Parser::getDouble( m_doubleValue, commandParts.first() ) )
        {
            // the value could be extracted
            ok = true;
        }

        // delete first part that has been processed
        commandParts.removeFirst();              

    }
    else
    {
        std::cerr << "(EE) ClientParser::processCommandDoubleValue "
                  << " Command part list is empty."
                  << std::endl;
    }
    
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processCommandDoubleValue End " + QString::number((int)ok) );

    return ok;
}

// Process a command that extracts the round number.
bool ClientParser::processCommandRound( QStringList& commandParts )
{
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processCommandRound Start " + QString::number(commandParts.count()) );

    bool ok = false;

    // Check if there is a least one command part
    if ( commandParts.count() > 0 )
    {
#ifdef QT_DEBUG
        std::cout << "(II) ClientParser::processCommandRound "
                  << " Command"
                  << " \"" << commandParts.first().toStdString() << "\"."
                  << std::endl;
#endif

        // the next command holds a client id
        if ( Parser::getId( m_round, commandParts.first() ) )
        {
            // the value could be extracted
            ok = true;
        }

        // delete first part that has been processed
        commandParts.removeFirst();              
    }
    else
    {
        std::cerr << "(EE) ClientParser::processCommandRound "
                  << " Command part list is empty."
                  << std::endl;
    }
    
    Trace::print( MTP_CLIENTPARSER, STP_CP_PROCESS,
                  "ClientParser::processCommandRound End " + QString::number((int)ok) );

    return ok;
}

