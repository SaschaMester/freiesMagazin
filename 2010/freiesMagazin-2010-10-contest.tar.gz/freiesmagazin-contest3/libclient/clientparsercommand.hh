/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef CLIENTPARSERCOMMAND_HH
#define CLIENTPARSERCOMMAND_HH

/// Enum for all commands that can be processed.
/**
 * Depending on this enum another class get the correct data it
 * needs after a command is processed.
 */
enum ClientParserCommand
{
    CPC_NO_COMMAND = 0,         // no command has been given
    CPC_ERROR,                  // there was an error processing a command
    CPC_PING,                   // the server has pinged the client
    CPC_SET_ID,                 // an id has been send and stored
    CPC_CONNECT_OTHER,          // another client has connected
    CPC_DISCONNECT_OTHER,       // another client has disconnected
    CPC_DISCONNECT_SELF,        // disconnect (and end) the client
    CPC_SET_PLAYER,             // set own player data (position and viewing dir)
    CPC_SEE_PLAYER,             // see other player (position and viewing dir)
    CPC_SEE_KEY,                // see key (position and id)
    CPC_GET_KEY,                // get key
    CPC_TEAM_CHANGE,            // a player has changed the team
    CPC_LOAD_MAP,               // load a given map
    CPC_START,                  // Start a new calculation for movement.
    CPC_LIFE,                   // Life energy set for a player.
    CPC_TOXIC,                  // Toxic value of a field.

    CPC_NUM_COMMANDS            // number of commands
                                // do not add new commands after this line!
};

#endif // CLIENTPARSERCOMMAND_HH
