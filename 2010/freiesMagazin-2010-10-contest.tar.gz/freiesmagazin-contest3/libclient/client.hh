/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef CLIENT_HH
#define CLIENT_HH

// Own
////////
#include "clientparser.hh"
#include "clientparsercommand.hh"
#include "team.hh"
#include "direction.hh"
#include "key.hh"

// Qt
////////
#include <QObject>
#include <QHostAddress>
#include <QPoint>
#include <QString>

// Forward declarations
/////////////////////////
class ClientConnection;

/// Client, that connects to a server.
/**
 * The client connects to a server and receives messages from
 * and send messages to it.
 * The class is derived from QObject to inherit the
 * signal/slot concept.
 * The class itself does NOT store any data, it's just for
 * communication. A signal is send if any new command has been
 * processed and could be get.
 */
class Client : public QObject
{
Q_OBJECT

public:

    ////////////////////////////////
    // Constructor and Operators
    ////////////////////////////////
    
    /// Constructor
    /**
     * Creates a new tcp socket to connect to a server.
     * All signals from the connection will be connected to
     * local methods.
     * All data will be resetted here.
     */
    Client();

    /// Copy constructor.
    /**
     * This is not implemented because I don't want a copy.
     */
    Client( const Client& client );
    
    /// Destructor
    /**
     * Stops the connection to a server explicitly and
     * then deletes the tcp socket.
     */
    ~Client();

    /// Assignment operator.
    /**
     * This is not implemented because I don't want a copy.
     */
    Client& operator=( const Client& client );

    ////////////////////////////////
    // Connections
    ////////////////////////////////

    /// Connect to a server.
    /**
     * This method is the most important function to connect to a
     * server. The adress and port of the server will be given from
     * outside.
     * The client tries to connect to the server for 3 seconds and
     * give an error if it times out.
     * @param address server adress for connection
     * @param port port the server listens for new connections
     * @param msecs time to try to establish a connection in milliseconds
     *        (default is 3 seconds).
     * @return true if connection could be established
     */
    bool connectToServer( const QHostAddress address, const quint16 port,
                          const int msecs = 3000 );

    /// Check if the connection is established.
    /**
     * Established means that the TCP socket pointer is not NULL,
     * and the socket connection
     * is in the state QAbstractSocket::ConnectedState.
     * @return true if connection is established
     */
    bool isConnected() const;
    
    /// Stop connection to the server.
    /**
     * If a connection is established to a server, it will be closed.
     * @return true if server is stopped
     */
    bool stopConnection();

    /// Wait until server kills connection.
    /**
     * The client will wait endlessly until the connection breaks.
     * This should be called after the client has been constructed
     * and connected to a server.
     */
    void waitUntilDisconnected();

    /// Wait until some data has been received.
    /**
     * We will wait for msec milliseconds, or endlessly
     * if it's -1.
     * @return true if some data has been received
     */
    bool waitForData( const int msecs = -1 );

    /// Send some data to the server.
    /**
     * The data is send to the TCP socket. We will wait
     * 1 second till the data must have been sent.
     * @param data to sent
     * @return true if data has been sent
     */
    bool send( const QString& data, const int msecs = 1000 );

    ////////////////////////////////
    // Getting data
    ////////////////////////////////

    /// Return client id.
    /**
     * This variable is set for most commands.
     * @return client id
     */
    int getClientId() const { return m_parser.getClientId(); }

    /// Return stored position.
    /**
     * This variable is set, if CPC_SET_PLAYER is the current command.
     * @return position
     */
    const QPoint& getPosition() const { return m_parser.getPosition(); }

    /// Return stored view.
    /**
     * This variable is set, if CPC_SET_PLAYER is the current command.
     * @return view
     */
    Direction getView() const { return m_parser.getView(); }

    /// Return stored team.
    /**
     * This variable is set, if CPC_TEAM_CHANGE is the current command.
     * @return team
     */
    Team getTeam() const { return m_parser.getTeam(); }

    /// Return stored key.
    /**
     * This variable is set, if CPC_SEE_KEY or CPC_GET_KEY is the current command.
     * @return key
     */
    Key getKey() const { return m_parser.getKey(); }

    /// Return filename of map.
    /**
     * This variable is set, if CPC_LOAD_MAP is the current command.
     * @return team
     */
    QString getMapName() const { return m_parser.getMapName(); }

    /// Return double value.
    /**
     * This variable is set, if CPC_TOXIC or CPC_LIFE is the current command.
     * @return team
     */
    double getDoubleValue() const { return m_parser.getDoubleValue(); }

    /// Return round number.
    /**
     * This variable is set, if CPC_START is the current command.
     * @return team
     */
    double getRound() const { return m_parser.getRound(); }
    
    ////////////////////////////////
    // Setting data
    ////////////////////////////////

    /// Reset parser so that a new command could be processed.
    /**
     * This must be done from outside, because otherwise we could
     * not decide if the outer process has processed a command.
     */
    void resetParser() { m_parser.reset(); }

signals:
    /// Signal when a client has been conntected to the server.
    /**
     * This method is called after a connection to a server has been
     * established and will stay in an endless loop until
     * the client id has been set in another method.
     * Handle with care! If the server does not send the id or the
     * client cannot recognize it the method will never be left.
     */
    void sig_connected();
    
    /// Signal when a client has been disconnected.
    void sig_disconnected();

    /// Signal that a new command has been processed.
    /**
     * The commandId tells the user of the class what for data it
     * can get (indirectly from the parser) so that it can handle
     * properly.
     */
    void sig_processCommand( const ClientParserCommand commandId );

    /// Signal that a command has been received.
    /**
     * The signal is send before anything has been processed
     */
    void sig_receivedCommand( const QString& command );

private slots:

    /// Data can be read from a client connection.
    /**
     * The client has sent some data that can be read
     * from the TCP socket and be given to the server.
     * @param data received data
     */
    void slot_receiveData( const QString& data );
    
private:
    /// Verify if connection is accessible.
    /**
     * That means that the tcp socket pointer is not NULL.
     * That normally should not happen of course!
     * @return true if socket is okay
     */
    bool verifyServerConnection() const;

    /// Disconnect from server.
    /**
     * Even if the connection has been allocated from outside
     * we are allowed to delete it here to break the connection.
     * Normally it has been closed before by the client or
     * the server.
     */
    void reset();

    /// Process all commands in the process queue.
    /**
     * This will send the signal sig_processCommand so that outside
     * the command could be processed.
     */
    void processCommandQueue();

private:
    ////////////////////
    // members
    ///////////////////

    /// Client parser.
    /**
     * The parser separates all commands and put them in queue
     * to be processed later.
     */
    ClientParser m_parser;

    /// TCP connection to client.
    ClientConnection *m_socket;
    
    /// Flag that the client should disconnect and quit.
    /**
     * The flag is set to true if the client receives a
     * DISCONNECT-Signal from the server or if the server
     * closes the connection.
     */
    bool m_disconnect;
};

#endif // CLIENT_HH
