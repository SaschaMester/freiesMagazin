/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef GAMEAREA_HH
#define GAMEAREA_HH

// Own
/////////
#include <direction.hh>

// Qt
/////////
#include <QWidget>
#include <QPainterPath>
#include <QFont>
#include <QPen>
#include <QBrush>
#include <QRectF>
#include <QPointF>
#include <QSizeF>
#include <QColor>

// Forward declarations
/////////////////////////
class PlayerList;
class GameMap;
class QPainter;
class QPaintEvent;

/// Game area for drawing game map.
/**
 * The game area will draw all given data additional
 * to the game map.
 */
class GameArea : public QWidget
{
Q_OBJECT

public:
    /// Constructor.
    GameArea(QWidget *parent = 0);

    /// Destructor.
    ~GameArea();

    /// Bind game map to area.
    void setMap( const GameMap* map ) { m_map = map; }

    /// Bind players to area.
    void setPlayers( const PlayerList* players ) { m_players = players; }
    
protected:
    /// The paint event will draw the given all data.
    void paintEvent(QPaintEvent *event);

private:

    /// Paint the game map.
    void paintMap( QPainter& painter );

    /// Paint single field of game map at pos.
    void paintField( QPainter& painter, const QPoint& pos );

    /// Paint the players.
    void paintPlayers( QPainter& painter );

    /// Paint single player.
    void paintPlayer( QPainter& painter, const int playerId, const bool updatePos = false );

    /// Calculate the correct square size for the field.
    /**
     * Depending on the size of the game map and the size of the
     * window we must scale the whole game map so that it fits
     * into the painting area.
     * The method calculates the size of a square and the factor
     * needed for scaling the default objects.
     * @return true if values could be calculated
     */
    bool calculateSquareSizeAndFactorFromMap();
    
    /// Calculate angle from view for rotating a player.
    /**
     * Depending on the viewing direction we must calculate the rotation
     * for the default player graphic. The default will point to EAST
     * and return a angle of 0.0.
     * @return angle for rotation
     */
    double calculateRotationAngleFromView( const Direction view ) const;
    
private:

    /// Reference to the game map, that was loaded outside.
    const GameMap* m_map;

    /// Reference to the list of players, that are connect to the game.
    const PlayerList* m_players;

    /// The default player for drawing.
    /**
     * This is the default player looking to the right.
     * It will be rotated and filled to use it for all players.
     */
    QPainterPath m_defaultPlayer;

    /// The default door for drawing.
    /**
     * This is the default door used for all doors.
     */
    QPainterPath m_defaultDoor;

    /// The default key for drawing.
    /**
     * This is the default key used for all keys.
     */
    QPainterPath m_defaultKey;

    /// Size of a square.
    /**
     * Everytime we get a paint event we will recalculate the square
     * size. It says how big each square will be.
     */
    QSizeF m_squareSize;

    /// Scaling factor.
    /**
     * Factor for scaling the default square with 10x10 pixels
     * to the current squareSize.
     */
    QPointF m_squareFactor;

    // general data
    QPen m_generalNoPen;
    QPen m_generalTextPen;
    QPen m_generalDarkPen;
    QBrush m_generalNoBrush;
    QBrush m_generalSolidBrush;
    QRectF m_generalRect;
    QFont m_generalFont;
    QRectF m_areaRect;

    // player data
    QPen m_playerPen;
    QBrush m_playerBrush;
    QRectF m_playerFontRect;
    QColor m_playerColor;
    
    // game board data (background)
    QColor m_toxicColor;

    // game board data (background)
    QBrush m_wallBrush;

    // game board data (door)
    QRectF m_doorFontRect;
    QBrush m_doorBrush;

    // game board data (key)
    QRectF m_keyFontRect;
    QBrush m_keyBrush;    
};

#endif // GAMEAREA_HH

