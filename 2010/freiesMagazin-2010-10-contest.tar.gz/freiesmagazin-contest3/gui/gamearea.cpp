/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
/////////
#include "gamearea.hh"
#include "gamemap.hh"
#include "field.hh"
#include "playerlist.hh"
#include "player.hh"
#include "team.hh"
#include "trace.hh"

// Qt
////////
#include <QList>
#include <QPoint>
#include <QPainter>

// Sys
////////
#include <iostream>

// Constructor.
GameArea::GameArea(QWidget *parent)
: QWidget(parent), m_map(0), m_players(0)
{
    Trace::print( MTP_GAME_AREA, STP_GA_STRUCTOR,
                  "GameArea::GameArea Start " );

    // create player
    m_defaultPlayer.moveTo(0,0);
    m_defaultPlayer.quadTo(8,0,10,5);
    m_defaultPlayer.quadTo(8,10,0,10);
    m_defaultPlayer.quadTo(4,5,0,0);

    // create door
    m_defaultDoor.moveTo(0,4);
    m_defaultDoor.lineTo(0,10);
    m_defaultDoor.lineTo(10,10);
    m_defaultDoor.lineTo(10,4);
    m_defaultDoor.quadTo(5,-3,0,4);

    // create key
    m_defaultKey.addEllipse( QRectF( 0, 0, 10, 10 ) );

    // general data
    const double fontFactor = 0.6;
    m_generalNoPen.setStyle( Qt::NoPen );
    m_generalTextPen.setColor( palette().text().color() );
    m_generalDarkPen.setColor( palette().dark().color() );
    m_generalNoBrush.setStyle( Qt::NoBrush );
    m_generalSolidBrush.setStyle( Qt::SolidPattern );
    m_generalRect.setRect( 0.0, 0.0, 10.0, 10.0 );
    m_generalFont = font();
    m_generalFont.setPointSize( m_generalFont.pointSize() * fontFactor );

    // Fonts are little bit tricky if you want to press
    // them into a single box. Often it happens that
    // there are parts missing of some characters (like
    // the lower part of the 'g').
    // So we must create a box that is greater than the
    // original box and set the correct position for it.
    // We use the the doubled size of the default rect.
    // Further the font is in comparison to the graphic
    // elements a little bit to big. So we will scale
    // it with some extra factor.

    // set player data
    m_playerPen.setColor( palette().dark().color() );
    m_playerFontRect.setRect( -5, -5, 20, 20 );
    m_playerBrush.setStyle( Qt::SolidPattern );
    
    // set game board data (background)
    m_toxicColor.setHsv( 120, 255, 255, 150 );

    // set game board data (wall)
    m_wallBrush.setColor( QColor(0,0,0) );
    m_wallBrush.setStyle( Qt::SolidPattern );

    // set game board data (door)
    m_doorFontRect.setRect( -5.0, -5.0, 20, 20 );
    m_doorBrush.setColor( QColor(210,120,0) );
    m_doorBrush.setStyle( Qt::SolidPattern );

    // set game board data (key)
    m_keyFontRect.setRect( -5.0, -5.0, 20.0, 20.0 );
    m_keyBrush.setColor( QColor(255,250,55) );
    m_keyBrush.setStyle( Qt::SolidPattern );

    // set default sizes
    m_squareSize = QSizeF( 10.0, 10.0 );
    m_squareFactor = QPointF( 1.0, 1.0 );
    
    // set background color as default white
    setBackgroundRole(QPalette::Base);
    setAutoFillBackground(true);

    // we should not resize the window below this values
    setMinimumSize( QSize( 100, 100 ) );

    Trace::print( MTP_GAME_AREA, STP_GA_STRUCTOR,
                  "GameArea::GameArea End " );
}

// Destructor.
GameArea::~GameArea()
{
    Trace::print( MTP_GAME_AREA, STP_GA_STRUCTOR,
                  "GameArea::~GameArea Start " );

    // do not delete references
    m_map = 0;
    m_players = 0;

    Trace::print( MTP_GAME_AREA, STP_GA_STRUCTOR,
                  "GameArea::~GameArea End " );
}

// The paint event will draw the given all data.
void GameArea::paintEvent(QPaintEvent* ) // event
{
    // We do not need the event, so we have commented it above.

    Trace::print( MTP_GAME_AREA, STP_GA_STRUCTOR,
                  "GameArea::paintEvent Start " );

    QPainter painter(this);
    painter.setRenderHints( painter.renderHints() | QPainter::Antialiasing );

    if ( calculateSquareSizeAndFactorFromMap() )
    {
        // first we will draw the map
        paintMap( painter );

        // and then the players
        paintPlayers( painter );
    }

    Trace::print( MTP_GAME_AREA, STP_GA_STRUCTOR,
                  "GameArea::paintEvent End " );
}

// Paint the game map.
void GameArea::paintMap( QPainter& painter )
{
    if ( m_map )
    {
        // get width and height of map
        const int mapWidth = m_map->getSize().width();
        const int mapHeight = m_map->getSize().height();

        QPoint pos;

         // write numbers
        for ( int ii = 0; ii < mapWidth; ii++ )
        {
            pos.setX(ii+1);
            pos.setY(0);

            painter.save();
                painter.translate( pos.x()*m_squareSize.width(),
                                   pos.y()*m_squareSize.height() );
                painter.scale( m_squareFactor.x(), m_squareFactor.y() );

                painter.setFont( m_generalFont );
                painter.setPen( m_generalTextPen );
                painter.setBrush( m_generalNoBrush );
                painter.drawText( m_playerFontRect, Qt::AlignCenter,
                                  QString::number( ii ) );
            painter.restore();
        }

        for ( int jj = 0; jj < mapHeight; jj++ )
        {
            pos.setX(0);
            pos.setY(jj+1);

            painter.save();
                painter.translate( pos.x()*m_squareSize.width(),
                                   pos.y()*m_squareSize.height() );
                painter.scale( m_squareFactor.x(), m_squareFactor.y() );

                painter.setFont( m_generalFont );
                painter.setPen( m_generalTextPen );
                painter.setBrush( m_generalNoBrush );
                painter.drawText( m_playerFontRect, Qt::AlignCenter,
                                  QString::number( jj ) );
            painter.restore();
        }

        painter.save();
        painter.translate( m_squareSize.width(), m_squareSize.height() );

        for ( int ii = 0; ii < mapWidth; ii++ )
        {
            for ( int jj = 0; jj < mapHeight; jj++ )
            {
                // create position
                pos.setX(ii);
                pos.setY(jj);

                // paint single field
                paintField( painter, pos );
            }
        }

        painter.restore();

        painter.setPen( m_generalDarkPen );
        painter.setBrush( m_generalNoBrush );
        painter.drawRect( m_areaRect );
    }
}

// Paint single field of game map at pos.
void GameArea::paintField( QPainter& painter, const QPoint& pos )
{
    if ( m_map && m_map->isValidPos( pos ) )
    {
        // get field
        const Field& field = m_map->operator[]( pos );

        // depending on the field type we must draw something
        if ( field.isType( FT_BLOCK ) )
        {
#ifdef QT_DEBUG1
            std::cout << "(II) GameArea::paintMap "
                      << " Block: " << pos.x()*m_squareSize.width()
                      << " " << pos.y()*m_squareSize.height()
                      << " " << m_squareSize.width()
                      << " " << m_squareSize.height()
                      << std::endl;
#endif

            // this is a block/wall
            painter.save();
                painter.translate( pos.x()*m_squareSize.width(),
                                   pos.y()*m_squareSize.height() );
                painter.scale( m_squareFactor.x(), m_squareFactor.y() );
                painter.setPen( m_generalNoPen );
                painter.setBrush( m_wallBrush );
                painter.drawRect( m_generalRect );
            painter.restore();

        }
        else
        {
            // get toxic value and convert it to int between minColor and maxColor
            // The toxic values should be between 0.01 and 0.20.
            // To map this in the range between 0 and 150, we must multiply
            // each value by 5, so that the result will be between
            // 0.01*5 = 0.05 and 0.20*5 = 1.0
            const int factor = 5;
            const int minColor = 0;
            const int maxColor = 200;
            const double realVal = (field.getToxicValue()-0.01)*factor;
            int toxicValue = minColor + (int)((maxColor-minColor)*realVal);
            if ( 255 < toxicValue )
            {
                toxicValue = 255;
            }
            else if ( toxicValue < 0 )
            {
                toxicValue = 0;
            }

            // set toxic color
            m_toxicColor.setHsv( m_toxicColor.hue(), toxicValue,
                                 m_toxicColor.value(), m_toxicColor.alpha() );

            // draw toxic grade
            painter.save();
                painter.translate( pos.x()*m_squareSize.width(),
                                   pos.y()*m_squareSize.height() );
                painter.scale( m_squareFactor.x(), m_squareFactor.y() );
                painter.setPen( m_generalNoPen );
                m_generalSolidBrush.setColor( m_toxicColor );
                painter.setBrush( m_generalSolidBrush );
                painter.drawRect( m_generalRect );
            painter.restore();
            
            if ( field.isType( FT_DOOR ) )
            {
#ifdef QT_DEBUG1
                std::cout << "(II) GameArea::paintMap "
                          << " Door: " << squareRect.x()
                          << " " << squareRect.y()
                          << " " << squareRect.width()
                          << " " << squareRect.height()
                          << field.toAscii()
                          << std::endl;
#endif
                // draw graphic
                painter.save();
                    painter.translate( pos.x()*m_squareSize.width(),
                                       pos.y()*m_squareSize.height() );
                    painter.scale( m_squareFactor.x(), m_squareFactor.y() );
                    painter.setPen( m_generalDarkPen );
                    m_doorBrush.setStyle( Qt::SolidPattern );
                    painter.setBrush( m_doorBrush );
                    painter.drawPath( m_defaultDoor );

                    painter.setFont( m_generalFont );
                    painter.setPen( m_generalTextPen );
                    painter.setBrush( m_generalNoBrush );
                    painter.drawText( m_doorFontRect, Qt::AlignCenter,
                                      QString( field.toAscii() ) );
                painter.restore();

            }
            else if ( field.isType( FT_KEY ) )
            {
#ifdef QT_DEBUG1
                std::cout << "(II) GameArea::paintMap "
                          << " Key: " << squareRect.x()
                          << " " << squareRect.y()
                          << " " << squareRect.width()
                          << " " << squareRect.height()
                          << field.toAscii()
                          << std::endl;
#endif
                // draw graphic
                painter.save();
                    painter.translate( pos.x()*m_squareSize.width(),
                                       pos.y()*m_squareSize.height() );
                    painter.scale( m_squareFactor.x(), m_squareFactor.y() );
                    painter.setPen( m_generalDarkPen );
                    painter.setBrush( m_keyBrush );
                    painter.drawPath( m_defaultKey );

                    painter.setFont( m_generalFont );
                    painter.setPen( m_generalTextPen );
                    painter.setBrush( m_generalNoBrush );
                    painter.drawText( m_keyFontRect, Qt::AlignCenter,
                                      QString( field.toAscii() ) );
                painter.restore();
            }
            // ignore everything else
        }
    }
}

// Paint the players.
void GameArea::paintPlayers( QPainter& painter )
{
    if ( m_players )
    {
        painter.save();
        painter.translate( m_squareSize.width(), m_squareSize.height() );

        // Get list of player ids (only one time).
        QList<int> playerIds = m_players->getListOfIds();
        
        for ( int ii = 0; ii < playerIds.count(); ii++ )
        {
            paintPlayer( painter, ii );
        }
        
        painter.restore();
    }
}

// Paint single player.
void GameArea::paintPlayer( QPainter& painter, const int playerId,
                            const bool updatePos )
{
    if ( m_players && m_players->contains( playerId ) )
    {
        // get data of each player
        const QPoint pos = m_players->getPosition( playerId );

        if ( m_map && m_map->isValidPos(pos) )
        {
            // set team color
            if ( TEAM_BLUE == m_players->getTeam( playerId ) )
            {
                m_playerColor.setRgb( 116,175,255 );
            }
            else if ( TEAM_RED == m_players->getTeam( playerId ) )
            {
                m_playerColor.setRgb( 255,125,125 );
            }
            else
            {
                // error
                m_playerColor.setRgb( 255,255,255 );
            }

            // set player transparent if he is invalid
            if ( m_players->isInvalid( playerId ) )
            {
                m_playerColor.setAlpha( 100 );
            }

            // get angle for rotation
            const double angle = calculateRotationAngleFromView( m_players->getView( playerId ) );

#ifdef QT_DEBUG1
            std::cout << "(II) GameArea::paintPlayer "
                      << " Player: " << pos.x()*m_squareSize
                      << " " << pos.y()*squareSize
                      << " " << squareRect.width()
                      << " " << squareRect.height()
                      << " " << playerIds[ii]
                      << std::endl;
#endif

            // if we want to update the position of the player we will
            // redraw the field he's standing on.
            if ( updatePos )
            {
                paintField( painter, pos );
            }

            // draw graphic
            painter.save();
                painter.translate( pos.x()*m_squareSize.width(),
                                   pos.y()*m_squareSize.height() );
                painter.scale( m_squareFactor.x(), m_squareFactor.y() );

                painter.setPen( m_generalDarkPen );
                m_playerBrush.setColor( m_playerColor );
                painter.setBrush( m_playerBrush );

                painter.save();
                    painter.translate( 5, 5 );
                    painter.rotate(angle);
                    painter.translate( -5, -5 );
                    painter.drawPath( m_defaultPlayer );
                painter.restore();

                painter.setFont( m_generalFont );
                painter.setPen( m_generalTextPen );
                painter.setBrush( m_generalNoBrush );
                painter.drawText( m_playerFontRect, Qt::AlignCenter,
                                  QString::number( playerId ) );
            painter.restore();
        }
    }
}

// Calculate the correct square size for the field.
bool GameArea::calculateSquareSizeAndFactorFromMap()
{
    bool ok = false;

    if ( m_map )
    {
        // get width and height of map
        const int mapWidth = m_map->getSize().width();
        const int mapHeight = m_map->getSize().height();

        if ( mapWidth > 0 && mapHeight > 0 &&
             width() > 0 && height() > 0 )
        {
            // if one of these values is 0 we would not see anything

            // Depending on the current dimension of the widget
            // we will calculate the least fitting square for the map.
            double numW = width() * 1.0 / (mapWidth+1);
            double numH = height() * 1.0 / (mapHeight+1);

            if ( numW < numH )
            {
                // the width is the limiting element
                numH = numW;
            }
            else
            {
                // the height is the limiting element
                numW = numH;
            }

            m_squareSize.setWidth( numW );
            m_squareSize.setHeight( numH );
            m_squareFactor.setX( numW / 10.0 );
            m_squareFactor.setY( numH / 10.0 );

            // set game area rectangle
            m_areaRect.setRect( m_squareSize.width(), m_squareSize.height(), ((mapWidth)*numW)-1, ((mapHeight)*numH)-1 );

            ok = true;
        }
    }

    return ok;
}

// Calculate angle from view for rotating a player.
double GameArea::calculateRotationAngleFromView( const Direction view ) const
{
    double angle = 0.0;
    
    switch ( view )
    {
    case DIRECTION_NORTH:
        angle = -90.0;
        break;
    case DIRECTION_NORTH_WEST:
        angle = -135.0;
        break;
    case DIRECTION_WEST:
        angle = 180.0;
        break;
    case DIRECTION_SOUTH_WEST:
        angle = 135.0;
        break;
    case DIRECTION_SOUTH:
        angle = 90.0;
        break;
    case DIRECTION_SOUTH_EAST:
        angle = 45.0;
        break;
    case DIRECTION_EAST:
        angle = 0.0;
        break;
    case DIRECTION_NORTH_EAST:
        angle = -45.0;
        break;
    default:
        // ignore it
        break;
    }

    return angle;
}
