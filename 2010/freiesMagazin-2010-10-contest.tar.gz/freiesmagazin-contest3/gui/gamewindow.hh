/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef GAMEWINDOW_HH
#define GAMEWINDOW_HH

// Own
////////
#include "gamemap.hh"
#include "playerlist.hh"
#include "client.hh"
#include "clientparsercommand.hh"

// Qt
////////
#include <QMainWindow>

// Forward declarations
//////////////////////////
class ClientParser;
class GameArea;
class GameDock;
class QAction;

/// Game window.
/**
 * This class gives a simple GUI for showing the game that is on
 * process. After connecting to the server it will be get the whole
 * game map (including keys) and will be informed about every player
 * and team change so that it can display everything correctly.
 */
class GameWindow : public QMainWindow
 {
     Q_OBJECT

public:

    /// Constructor.
    GameWindow();

    /// Destructor.
    ~GameWindow();

private slots:

    /// Connect to the server.
    /**
     * We will connect to the server and receive all data
     * to display the current game.
     */
    void slot_connectToServer();

    /// Client has been connected to the server.
    /**
     * From now on we can load the gamemap and set player data.
     */
    void slot_connected();

    /// Client has been disconnected from the server.
    void slot_disconnected();

    /// Process command.
    /**
     * This method processes the data from the client.
     */
    void slot_processCommand( const ClientParserCommand commandId );

    /// Received command.
    /**
     * This stores the command in the game data list so that we can
     * replay the game later.
     */
    void slot_receivedCommand( const QString command );

    /// Open a map without the server.
    void slot_openMap();

    /// Replay a saved game from disc.
    void slot_replaySavedGame();

    /// Save current game progress to disc.
    void slot_saveGame();

private:
    /// Disconnect the client.
    void processCommandDisconnect();

    /// Connect some player.
    void processCommandConnectPlayer();

    /// Disconnect some player.
    void processCommandDisconnectPlayer();

    /// Set data of some player.
    void processCommandSeePlayer();

    /// change the team of a player
    void processCommandTeamChange();

    /// Load new map.
    void processCommandLoadMap();

    /// Set life for a player.
    void processCommandSetLife();

    /// Start new round.
    void processCommandStartRound();

    /// Update game area and paint again.
    void updateGameArea( const bool immediate = false );

    /// Load new map.
    bool openMap( const QString& filename );

    /// Replay a game by given game data.
    bool replayGame( const QStringList& commands );

    /// Process a command for offline replay.
    /**
     * This method processes the data from a given separate parser.
     */
    void processReplayCommand( const ClientParserCommand commandId,
                               const ClientParser& parser );

    /// Disconnect the client.
    void processCommandDisconnect( const ClientParser& parser );

    /// Connect some player.
    void processCommandConnectPlayer( const ClientParser& parser );

    /// Disconnect some player.
    void processCommandDisconnectPlayer( const ClientParser& parser );

    /// Set data of some player.
    void processCommandSeePlayer( const ClientParser& parser );

    /// change the team of a player
    void processCommandTeamChange( const ClientParser& parser );

    /// Load new map.
    void processCommandLoadMap( const ClientParser& parser );

    /// Set life for a player.
    void processCommandSetLife( const ClientParser& parser );

    /// Start new round.
    void processCommandStartRound( const ClientParser& parser );

private:

    /// The game area for painting the game map and players.
    GameArea* m_gameArea;

    /// Dock area for showing game stats.
    GameDock* m_gameDock;

    /// Menu entry for server connection.
    QAction *m_menuConnection;

    /// Menu entry for loading a map.
    QAction *m_menuOpenMap;

    /// Menu entry for replaying a game.
    QAction *m_menuReplayGame;

    /// Menu entry for saving a game.
    QAction *m_menuSaveGame;

    /// Action for showing and hiding dock window.
    QAction *m_dockAction;

    /// The loaded map.
    /**
     * The map contains only walls, empty fields, doors and keys.
     */
    GameMap m_map;
    
    /// List of players.
    /**
     * For each client that connects to the server informs us
     * and we must create a new player so that we can track it's movement.
     */
    PlayerList m_players;

    /// Connection for receiving data.
    Client m_client;

    /// Number of rounds.
    int m_numRounds;

    /// List of commands for game.
    /**
     * The commands will be received from the client and can be stored
     * to save it later.
     */
    QStringList m_gameCommands;

};

#endif // GAMEWINDOW_HH
