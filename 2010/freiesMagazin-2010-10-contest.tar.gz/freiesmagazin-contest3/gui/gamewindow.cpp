/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "gamewindow.hh"
#include "gamearea.hh"
#include "gamedock.hh"
#include "player.hh"
#include "trace.hh"

// Qt
////////
#include <QAction>
#include <QKeySequence>
#include <QMenu>
#include <QMenuBar>
#include <QMessageBox>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QCoreApplication>

// Sys
////////
#include <iostream>

// Constructor.
GameWindow::GameWindow()
: QMainWindow(), m_gameArea(0), m_gameDock(0), m_menuConnection(0),
  m_menuOpenMap(0), m_menuReplayGame(0), m_menuSaveGame(0), m_numRounds(0)
{
    Trace::print( MTP_GAME_WINDOW, STP_GW_STRUCTOR,
                  "GameWindow::GameWindow Start " );

    // connect to client
    if ( !connect( &m_client, SIGNAL( sig_connected() ), this, SLOT( slot_connected() ) ) )
    {
        std::cerr << "(EE) GameWindow::GameWindow "
                  << " Connect 1 not possible!"
                  << std::endl;
    }

    if ( !connect( &m_client, SIGNAL( sig_disconnected() ), this, SLOT( slot_disconnected() ) ) )
    {
        std::cerr << "(EE) GameWindow::GameWindow "
                  << " Connect 2 not possible!"
                  << std::endl;
    }

    if ( !connect( &m_client, SIGNAL( sig_processCommand(const ClientParserCommand) ),
             this, SLOT( slot_processCommand(const ClientParserCommand) ) ) )
    {
        std::cerr << "(EE) GameWindow::GameWindow "
                  << " Connect 3 not possible!"
                  << std::endl;
    }

    // signal when data can be read from client
    if ( !connect( &m_client, SIGNAL(sig_receivedCommand(const QString&)),
                   this, SLOT(slot_receivedCommand(const QString&)) ) )
    {
        std::cerr << "(EE) GameWindow::GameWindow "
                  << " Connect 4 not possible!"
                  << std::endl;
    }
        
    // create graphic widget
    m_gameArea = new GameArea(this);

    // set gamemap and playerlist in game area for drawing
    if ( m_gameArea )
    {
        m_gameArea->setMap( &m_map );
        m_gameArea->setPlayers( &m_players );
    }

    // create dock widget for showing game stats
    m_gameDock = new GameDock( tr("Game stats"), this );

    if ( m_gameDock )
    {  
        m_gameDock->setMap( &m_map );
        m_gameDock->setPlayers( &m_players );
        m_dockAction = m_gameDock->toggleViewAction();
    }

    // create menu
    QMenu* filemenu = menuBar()->addMenu( tr("&File") );
    if ( filemenu )
    {
        m_menuConnection = filemenu->addAction( tr("&Connect to server"),
                               this, SLOT( slot_connectToServer() ),
                               QKeySequence(Qt::CTRL + Qt::Key_S) );
        if ( m_menuConnection )
        {
            m_menuConnection->setCheckable(true);
        }
        filemenu->addSeparator();
        
        m_menuOpenMap = filemenu->addAction( tr("&Open map"), this, SLOT( slot_openMap() ) );
        
        m_menuReplayGame = filemenu->addAction( tr("&Replay saved game"), this, SLOT( slot_replaySavedGame() ) );
        m_menuSaveGame = filemenu->addAction( tr("&Save game"), this, SLOT( slot_saveGame() ) );

        filemenu->addSeparator();
        filemenu->addAction( tr("E&xit"), this, SLOT( close() ) );
    }
    
    QMenu* viewmenu = menuBar()->addMenu( tr("&View") );
    if ( viewmenu )
    {
        if ( m_dockAction )
        {
            viewmenu->addAction( m_dockAction );
            // m_dockAction->setCheckable(true);
        }
    }

    // set painting area as central widget
    setCentralWidget(m_gameArea);

    // Set default size
    resize( QSize( 800, 600 ) );

    // set window title
    setWindowTitle( tr("freiesMagazin-Contest: Right2Live") );

    updateGameArea();

    Trace::print( MTP_GAME_WINDOW, STP_GW_STRUCTOR,
                  "GameWindow::GameWindow End " );
}

// Destructor.
GameWindow::~GameWindow()
{
    Trace::print( MTP_GAME_WINDOW, STP_GW_STRUCTOR,
                  "GameWindow::~GameWindow Start " );

    // nothing to do, because all created elements
    // are owned by some widgets
    m_menuConnection = 0;
    m_menuOpenMap = 0;
    m_menuReplayGame = 0;
    m_menuSaveGame = 0;
    m_gameArea = 0;

    Trace::print( MTP_GAME_WINDOW, STP_GW_STRUCTOR,
                  "GameWindow::~GameWindow End " );
}

// Connect to the server.
void GameWindow::slot_connectToServer()
{
    Trace::print( MTP_GAME_WINDOW, STP_GW_CONNECT,
                  "GameWindow::slot_connectToServer Start " );

    if ( m_menuConnection )
    {
        if ( m_menuConnection->isChecked() )
        {
            const QHostAddress address = QHostAddress::LocalHost;
            const quint16 port = 15001;
            if ( !m_client.connectToServer(address,port) )
            {
                m_menuConnection->setChecked( false );

                std::cerr << "(EE) GameWindow::slot_connectToServer "
                          << " Could not connect to server!"
                          << std::endl;

                QMessageBox::critical( this, "GameWindow::slot_connectToServer",
                                       tr("Could not connect to server!") );
            }
        }
        else
        {
            m_client.stopConnection();
        }
    }

    Trace::print( MTP_GAME_WINDOW, STP_GW_CONNECT,
                  "GameWindow::slot_connectToServer End " );
}

// Open a single map without server.
void GameWindow::slot_openMap()
{
    Trace::print( MTP_GAME_WINDOW, STP_GW_CONNECT,
                  "GameWindow::slot_openMap Start " );

    // show file dialog
    const QString filename = QFileDialog::getOpenFileName(this,
        tr("Open Map"), QString(), tr("Map Files (*.map)"));

    if ( !filename.isEmpty() )
    {
        // the user has selected a valid filename
        if ( openMap( filename ) )
        {
            // We will update the whole game board.
            updateGameArea();
        }
    }

    Trace::print( MTP_GAME_WINDOW, STP_GW_CONNECT,
                  "GameWindow::slot_openMap End " );
}

// Client has been connected to the server.
void GameWindow::slot_connected()
{
    Trace::print( MTP_GAME_WINDOW, STP_GW_CONNECT,
                  "GameWindow::slot_connected Start " );

    // set new menu text
    if ( m_menuConnection )
    {
        m_menuConnection->setText( tr("Dis&connect from server") );
    }

    // it's not allowed to save a game or open one
    if ( m_menuOpenMap )
    {
        m_menuOpenMap->setEnabled(false);
    }
    if ( m_menuReplayGame )
    {
        m_menuReplayGame->setEnabled(false);
    }
    if ( m_menuSaveGame )
    {
        m_menuSaveGame->setEnabled(false);
    }

    // delete game map and and delete playerlist to load something new
    m_map.clear();
    m_players.clear();
    m_numRounds = 0;

    // inform dock area that it should clear the widget list
    if ( m_gameDock )
    {
        m_gameDock->clear();
    }

    // delete the current game progress
    m_gameCommands.clear();

    // update game area
    updateGameArea();

    Trace::print( MTP_GAME_WINDOW, STP_GW_CONNECT,
                  "GameWindow::slot_connected End " );
}

// Client has been disconnected from the server.
void GameWindow::slot_disconnected()
{
    Trace::print( MTP_GAME_WINDOW, STP_GW_CONNECT,
                  "GameWindow::slot_disconnected Start " );

    if ( m_menuConnection )
    {
        m_menuConnection->setText( tr("&Connect to server") );
        m_menuConnection->setChecked( false );
    }

    // it's  allowed to save a game or open one again
    if ( m_menuOpenMap )
    {
        m_menuOpenMap->setEnabled(true);
    }
    if ( m_menuReplayGame )
    {
        m_menuReplayGame->setEnabled(true);
    }
    if ( m_menuSaveGame )
    {
        m_menuSaveGame->setEnabled(true);
    }
                
    // Note: We will not remove the data from the game area
    // because we still want to see the game after disconnecting!

    // But we will mark all players as invalid
    const QList<int> idList = m_players.getListOfIds();

    for ( int ii = 0; ii < idList.count(); ii++ )
    {
        m_players.setInvalid( idList[ii], true );
    }

    // update game area
    updateGameArea();

    Trace::print( MTP_GAME_WINDOW, STP_GW_CONNECT,
                  "GameWindow::slot_disconnected End " );
}

// Client has been disconnected from the server.
void GameWindow::slot_processCommand( const ClientParserCommand commandId )
{
    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::slot_processCommand Start " + QString::number(commandId) );

    switch ( commandId )
    {
    case CPC_NO_COMMAND:
        // nothing to do.
        break;
    case CPC_ERROR:
        // nothing to do.
        break;
    case CPC_PING:
        // nothing to do.
        break;
    case CPC_SET_ID:
        // nothing to do.
        break;
    case CPC_CONNECT_OTHER:
        processCommandConnectPlayer();
        break;
    case CPC_DISCONNECT_OTHER:
        processCommandDisconnectPlayer();
        break;
    case CPC_DISCONNECT_SELF:
        processCommandDisconnect();
        break;
    case CPC_SET_PLAYER:
        // nothing to do.
        break;
    case CPC_SEE_PLAYER:
        processCommandSeePlayer();
        break;
    case CPC_SEE_KEY:
        // nothing to do.
        break;
    case CPC_GET_KEY:
        // nothing to do.
        break;
    case CPC_TEAM_CHANGE:
        processCommandTeamChange();
        break;
    case CPC_LOAD_MAP:
        processCommandLoadMap();
        break;
    case CPC_START:
        processCommandStartRound();
        break;
    case CPC_LIFE:
        processCommandSetLife();
        break;
    case CPC_TOXIC:
        // we will not extract the toxic value, we already know them
        break;
    default:
        std::cerr << "(EE) GameWindow::slot_processCommand "
                  << " Default case reached for command "
                  << commandId
                  << std::endl;
        break;
    }

    // delete processed command
    m_client.resetParser();

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::slot_processCommand End " );
}

// Connect another client.
void GameWindow::processCommandConnectPlayer()
{
    const int id = m_client.getClientId();

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandConnectPlayer Start " + QString::number(id) );

    // check if the id is not stored yet
    if ( !m_players.contains(id) )
    {
        // add new player
        m_players.add( id );

        // Note: The player will not have a position at the beginning
        // so we do not need to update the game area.
    }
    else
    {
        // Note: If the player is already stored, we do not present an
        // error because it could be a reconnect of some client before
        // the game has started.
        // We will only mark the player as valid again.
        m_players.setInvalid( id, false );

        /*
        std::cerr << "(EE) GameWindow::processCommandConnectPlayer "
                  << " Client "
                  << id
                  << " already connected."
                  << std::endl;
        */
    }

    // update game area for this player
    updateGameArea();

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandConnectPlayer End " );
}

// Disconnect another client.
void GameWindow::processCommandDisconnectPlayer()
{
    const int id = m_client.getClientId();

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandDisconnectPlayer Start " + QString::number(id) );

    // check if the id is stored
    if ( m_players.contains(id) )
    {
        // mark player as invalid
        m_players.setInvalid( id, true );

        // update game area for this player
        updateGameArea();
    }
    else
    {
        std::cerr << "(EE) GameWindow::processCommandDisconnectPlayer "
                  << " Client "
                  << id
                  << " not connected."
                  << std::endl;
    }

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandDisconnectPlayer End " );
}

// Disconnect the client.
void GameWindow::processCommandDisconnect()
{
    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandDisconnect Start " );

    m_client.stopConnection();

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandDisconnect End " );
}

// Set data of other player.
void GameWindow::processCommandSeePlayer()
{
    const int id = m_client.getClientId();

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandSeePlayer Start " + QString::number(id) );

    // check if the id is stored
    if ( m_players.contains(id) )
    {
        if ( !m_players.setPosition( id, m_client.getPosition() ) )
        {
            std::cerr << "(EE) GameWindow::processCommandSeePlayer "
                      << " Position ("
                      << m_client.getPosition().x() << ", " << m_client.getPosition().y()
                      << ") could not be set for player "
                      << id
                      << std::endl;
        }

        if ( !m_players.setView( id, m_client.getView() ) )
        {
            std::cerr << "(EE) GameWindow::processCommandSeePlayer "
                      << " View "
                      << Player::toString( m_client.getView() ).toStdString()
                      << " could not be set for player "
                      << id
                      << std::endl;
        }

        // update game area for this player
        updateGameArea();
    }
    else
    {
        std::cerr << "(EE) GameWindow::processCommandSeePlayer "
                  << " Player "
                  << id
                  << " not found."
                  << std::endl;
    }

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandSeePlayer End " );
}

// change the team of a player
void GameWindow::processCommandTeamChange()
{
    const int id = m_client.getClientId();

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandTeamChange Start " + QString::number(id) );

    // check if the id is stored
    if ( m_players.contains(id) )
    {
        m_players.setTeam( id, m_client.getTeam(), false );

        // update game area for this player
        updateGameArea();
    }
    else
    {
        std::cerr << "(EE) GameWindow::processCommandTeamChange "
                  << " Player "
                  << id
                  << " not found."
                  << std::endl;
    }

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandTeamChange End " );
}

// Load new map.
void GameWindow::processCommandLoadMap()
{
    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandLoadMap Start " + m_client.getMapName() );

    if ( openMap( m_client.getMapName() ) )
    {
        if ( m_gameDock )
        {
            // only reorganize if the dock window was not added before
            if( Qt::NoDockWidgetArea == dockWidgetArea(m_gameDock) )
            {
                // change game map depending on the size of the game board
                // if the game board is more width we use bottom area
                // if it's more high we use right area
                // if it's the same we still use right
                if ( m_map.getSize().width() > m_map.getSize().height() )
                {
                    addDockWidget( Qt::BottomDockWidgetArea, m_gameDock );
                }
                else
                {
                    addDockWidget( Qt::RightDockWidgetArea, m_gameDock );
                }

                m_gameDock->show();
            }
        }
        
        // We will update the whole game board.
        updateGameArea();
    }

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandLoadMap End " );
}

// Load new map.
bool GameWindow::openMap( const QString& filename )
{
    bool ok = false;

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::openMap Start " + filename );
                  
    if ( !m_map.load( filename ) )
    {
        std::cerr << "(EE) GameWindow::processCommandLoadMap "
                  << " Map "
                  << filename.toStdString()
                  << " could not be loaded."
                  << std::endl;
    }
    else
    {
        ok = true;
    }

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::openMap End " + QString::number(ok) );

    return ok;
}

// Set life for a player.
void GameWindow::processCommandSetLife()
{
    const int id = m_client.getClientId();

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandSetLife Start " + QString::number(id) );

    // check if the id is stored
    if ( m_players.contains(id) )
    {
        if ( !m_players.setLife( id, m_client.getDoubleValue() ) )
        {
            std::cerr << "(EE) GameWindow::processCommandSetLife "
                      << " Life power "
                      << m_client.getDoubleValue()
                      << " could not be set for player "
                      << id
                      << std::endl;
        }

        // update game area for this player
        updateGameArea();
    }
    else
    {
        std::cerr << "(EE) GameWindow::processCommandSetLife "
                  << " Player "
                  << id
                  << " not found."
                  << std::endl;
    }

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandSetLife End " );
}

// Start new round.
void GameWindow::processCommandStartRound()
{
    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandStartRound Start " );

    // extract round number
    m_numRounds = m_client.getRound();

    // update game area for this player
    updateGameArea();

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandStartRound End " );

}
    
// Update game area and paint again.
void GameWindow::updateGameArea( const bool immediate )
{
    if ( m_gameArea )
    {
        if ( immediate )
        {
            // repaint area immediately
            m_gameArea->repaint();
        }
        else
        {
            m_gameArea->update();
        }
    }

    if ( m_gameDock )
    {
        m_gameDock->updateStats( m_numRounds );
    }

    // ping server if he is still active
    m_client.send( "PING" );

    // process other events
    QCoreApplication::processEvents();
}

// Replay a saved game from disc.
void GameWindow::slot_replaySavedGame()
{
    // show file dialog
    const QString filename = QFileDialog::getOpenFileName(this,
        tr("Load Game"), QString(), tr("Game Files (*.game)"));

    // block connecting to server during replay
    if ( m_menuConnection )
    {
        m_menuConnection->setEnabled(false);
    }
    if ( m_menuOpenMap )
    {
        m_menuOpenMap->setEnabled(false);
    }
    if ( m_menuReplayGame )
    {
        m_menuReplayGame->setEnabled(false);
    }
    if ( m_menuSaveGame )
    {
        m_menuSaveGame->setEnabled(false);
    }
    
    if ( !filename.isEmpty() )
    {
        // the user has a selected a file for opening
        QFile data( filename );

         if ( data.open(QFile::ReadOnly) )
         {
            QTextStream in(&data);
            m_gameCommands.clear();

            QString line = in.readLine();

            while ( !line.isNull() )
            {
                m_gameCommands.append( line );
                line = in.readLine();
            }

            data.close();
                
            // delete game map and and delete playerlist to load something new
            m_map.clear();
            m_players.clear();
            m_numRounds = 0;

            // inform dock area that it should clear the widget list
            if ( m_gameDock )
            {
                m_gameDock->clear();
            }
            
            // After loading the game data we can replay it.
            replayGame( m_gameCommands );
        }
        else
        {
            QMessageBox::critical( 0, tr("Error opening file"),
                tr("Error opening file \"") + filename + tr("\" for reading." ) );
        }
    }

    if ( m_menuConnection )
    {
        m_menuConnection->setEnabled(true);
    }
    if ( m_menuOpenMap )
    {
        m_menuOpenMap->setEnabled(true);
    }
    if ( m_menuReplayGame )
    {
        m_menuReplayGame->setEnabled(true);
    }
    if ( m_menuSaveGame )
    {
        m_menuSaveGame->setEnabled(true);
    }
}

// Save current game progress to disc.
void GameWindow::slot_saveGame()
{
    if ( !m_gameCommands.isEmpty() )
    {
        // show file dialog
        const QString filename = QFileDialog::getSaveFileName(this,
            tr("Save Game"), QString(), tr("Game Files (*.game)"));

        if ( !filename.isEmpty() )
        {
            // the user has a selected a file for saving
            QFile data( filename );

            if ( data.open(QFile::WriteOnly | QFile::Truncate) )
            {
                QTextStream out(&data);

                for ( int ii = 0; ii < m_gameCommands.count(); ii++ )
                {
                    out << m_gameCommands.at(ii) << endl;
                }

                data.close();
            }
            else
            {
                QMessageBox::critical( 0, tr("Error opening file"),
                tr("Error opening file \"") + filename + tr("\" for writing." ) );
            }
        }
    }
    else
    {
        QMessageBox::warning( 0, tr("No game data"),
            tr("There is no game data saved that could be saved to disc.") );
    }
}

// Replay a game by given game data.
bool GameWindow::replayGame( const QStringList& commands )
{
    bool ok = false;

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::replayGame Start " + QString::number(commands.count()) );

    // Note: The replay is very very fast, so you won't see anything
    // at all but the end result.

    // parser for parsing commands
    ClientParser parser;

    // iterate over all commands and interpret them
    for ( int ii = 0; ii < commands.count(); ii++ )
    {
        // give the data to the parser
        // so that it can be parsed and split
        // The index -1 tells that the data comes from the server.
        parser.separate( commands.at(ii) + "|", -1 );
        
        // process all waiting commands
        ClientParserCommand nextCommand = CPC_NO_COMMAND;
        while ( !parser.isCommandQueueEmpty() )
        {
            // the data has been send to the queue
            // so we can process the queue here
            nextCommand = parser.processNextCommand();

            // process the command
            // that means depending on the command index
            // we will get the data form the parser
            processReplayCommand( nextCommand, parser );

            // reset parser data to get the next command
            // even if the command could not be handled
            // correctly
            parser.reset();
        }
    }

    ok = true;

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::replayGame End " + QString::number(ok) );

    return ok;
}

// Client has been disconnected from the server.
void GameWindow::processReplayCommand( const ClientParserCommand commandId,
                                       const ClientParser& parser )
{
    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processReplayCommand Start " + QString::number(commandId) );

    switch ( commandId )
    {
    case CPC_NO_COMMAND:
        // nothing to do.
        break;
    case CPC_ERROR:
        // nothing to do.
        break;
    case CPC_PING:
        // nothing to do.
        break;
    case CPC_SET_ID:
        // nothing to do.
        break;
    case CPC_CONNECT_OTHER:
        processCommandConnectPlayer(parser);
        break;
    case CPC_DISCONNECT_OTHER:
        processCommandDisconnectPlayer(parser);
        break;
    case CPC_DISCONNECT_SELF:
        // ignore command because we already are offline
        break;
    case CPC_SET_PLAYER:
        // nothing to do.
        break;
    case CPC_SEE_PLAYER:
        processCommandSeePlayer(parser);
        break;
    case CPC_SEE_KEY:
        // nothing to do.
        break;
    case CPC_GET_KEY:
        // nothing to do.
        break;
    case CPC_TEAM_CHANGE:
        processCommandTeamChange(parser);
        break;
    case CPC_LOAD_MAP:
        processCommandLoadMap(parser);
        break;
    case CPC_START:
        processCommandStartRound(parser);
        break;
    case CPC_LIFE:
        processCommandSetLife(parser);
        break;
    case CPC_TOXIC:
        // we will not extract the toxic value, we already know them
        break;
    default:
        std::cerr << "(EE) GameWindow::processReplayCommand "
                  << " Default case reached for command "
                  << commandId
                  << std::endl;
        break;
    }

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processReplayCommand End " );
}
// Connect another client.
void GameWindow::processCommandConnectPlayer( const ClientParser& parser )
{
    const int id = parser.getClientId();

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandConnectPlayer Start " + QString::number(id) );

    // check if the id is not stored yet
    if ( !m_players.contains(id) )
    {
        // add new player
        m_players.add( id );

        // Note: The player will not have a position at the beginning
        // so we do not need to update the game area.
    }
    else
    {
        // Note: If the player is already stored, we do not present an
        // error because it could be a reconnect of some client before
        // the game has started.
        // We will only mark the player as valid again.
        m_players.setInvalid( id, false );

        /*
        std::cerr << "(EE) GameWindow::processCommandConnectPlayer "
                  << " Client "
                  << id
                  << " already connected."
                  << std::endl;
        */
    }

    // update game area for this player
    updateGameArea(true);

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandConnectPlayer End " );
}

// Disconnect another client.
void GameWindow::processCommandDisconnectPlayer( const ClientParser& parser )
{
    const int id = parser.getClientId();

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandDisconnectPlayer Start " + QString::number(id) );

    // check if the id is stored
    if ( m_players.contains(id) )
    {
        // mark player as invalid
        m_players.setInvalid( id, true );

        // update game area for this player
        updateGameArea(true);
    }
    else
    {
        std::cerr << "(EE) GameWindow::processCommandDisconnectPlayer "
                  << " Client "
                  << id
                  << " not connected."
                  << std::endl;
    }

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandDisconnectPlayer End " );
}

// Set data of other player.
void GameWindow::processCommandSeePlayer( const ClientParser& parser )
{
    const int id = parser.getClientId();

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandSeePlayer Start " + QString::number(id) );

    // check if the id is stored
    if ( m_players.contains(id) )
    {
        if ( !m_players.setPosition( id, parser.getPosition() ) )
        {
            std::cerr << "(EE) GameWindow::processCommandSeePlayer "
                      << " Position ("
                      << parser.getPosition().x() << ", " << parser.getPosition().y()
                      << ") could not be set for player "
                      << id
                      << std::endl;
        }

        if ( !m_players.setView( id, parser.getView() ) )
        {
            std::cerr << "(EE) GameWindow::processCommandSeePlayer "
                      << " View "
                      << parser.getView()
                      << " could not be set for player "
                      << id
                      << std::endl;
        }

        // update game area for this player
        updateGameArea(true);
    }
    else
    {
        std::cerr << "(EE) GameWindow::processCommandSeePlayer "
                  << " Player "
                  << id
                  << " not found."
                  << std::endl;
    }

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandSeePlayer End " );
}

// change the team of a player
void GameWindow::processCommandTeamChange( const ClientParser& parser )
{
    const int id = parser.getClientId();

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandTeamChange Start " + QString::number(id) );

    // check if the id is stored
    if ( m_players.contains(id) )
    {
        m_players.setTeam( id, parser.getTeam(), false );

        // update game area for this player
        updateGameArea(true);
    }
    else
    {
        std::cerr << "(EE) GameWindow::processCommandTeamChange "
                  << " Player "
                  << id
                  << " not found."
                  << std::endl;
    }

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandTeamChange End " );
}

// Load new map.
void GameWindow::processCommandLoadMap( const ClientParser& parser )
{
    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandLoadMap Start " + parser.getMapName() );

    if ( openMap( parser.getMapName() ) )
    {
        if ( m_gameDock )
        {
            // only reorganize if the dock window was not added before
            if( Qt::NoDockWidgetArea == dockWidgetArea(m_gameDock) )
            {
                // change game map depending on the size of the game board
                // if the game board is more width we use bottom area
                // if it's more high we use right area
                // if it's the same we still use right
                if ( m_map.getSize().width() > m_map.getSize().height() )
                {
                    addDockWidget( Qt::BottomDockWidgetArea, m_gameDock );
                }
                else
                {
                    addDockWidget( Qt::RightDockWidgetArea, m_gameDock );
                }

                m_gameDock->show();
            }
        }
        
        // We will update the whole game board.
        updateGameArea(true);
    }

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandLoadMap End " );
}

// Set life for a player.
void GameWindow::processCommandSetLife( const ClientParser& parser )
{
    const int id = parser.getClientId();

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandSetLife Start " + QString::number(id) );

    // check if the id is stored
    if ( m_players.contains(id) )
    {
        if ( !m_players.setLife( id, parser.getDoubleValue() ) )
        {
            std::cerr << "(EE) GameWindow::processCommandSetLife "
                      << " Life power "
                      << parser.getDoubleValue()
                      << " could not be set for player "
                      << id
                      << std::endl;
        }

        // update game area for this player
        updateGameArea(true);
    }
    else
    {
        std::cerr << "(EE) GameWindow::processCommandSetLife "
                  << " Player "
                  << id
                  << " not found."
                  << std::endl;
    }

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandSetLife End " );
}

// Start new round.
void GameWindow::processCommandStartRound( const ClientParser& parser )
{
    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandStartRound Start " );

    // extract round number
    m_numRounds = parser.getRound();

    // update game area for this player
    updateGameArea(true);

    Trace::print( MTP_GAME_WINDOW, STP_GW_PROCESS,
                  "GameWindow::processCommandStartRound End " );

}
    
// Received command.
void GameWindow::slot_receivedCommand( const QString command )
{
    // we will ignore pings
    if ( command != "PING" )
    {
        m_gameCommands.append( command );
    }
}
