/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
/////////
#include "gamedock.hh"
#include "gamestatshorizontal.hh"
#include "gamestatsvertical.hh"
#include "gamemap.hh"
#include "playerlist.hh"
#include "trace.hh"

// Sys
/////////
#include <iostream>

// Constructor.
GameDock::GameDock( const QString &title, QWidget* parent )
: QDockWidget(title, parent), m_gameStatsH(0), m_gameStatsV(0)
{
    // allow docking everyhwere
    setAllowedAreas( Qt::AllDockWidgetAreas );

    // set features of dock widget
    setFeatures( QDockWidget::AllDockWidgetFeatures );

    // connect signal if docking position is changed
    if ( !connect( this, SIGNAL( dockLocationChanged(Qt::DockWidgetArea) ),
                   this, SLOT( slot_dockLocationChanged(Qt::DockWidgetArea) ) ) )
    {
        std::cerr << "(EE) GameDock::GameDock "
                  << " Connect not possible!"
                  << std::endl;
    }

    // create horizontal layout
    m_gameStatsH = new GameStatsHorizontal();
    if ( m_gameStatsH )
    {
        m_gameStatsH->createTable();
    }
    else
    {
        std::cerr << "(EE) GameDock::GameDock "
                  << " Could not allocate memory for GameStatsHorizontal!"
                  << std::endl;
    }

    // create vertical layout
    m_gameStatsV = new GameStatsVertical();
    if ( m_gameStatsV )
    {
        m_gameStatsV->createTable();
    }
    else
    {
        std::cerr << "(EE) GameDock::GameDock "
                  << " Could not allocate memory for GameStatsVertical!"
                  << std::endl;
    }

    // as default we do not set any widget
}

// Destructor.
GameDock::~GameDock()
{
    // delete the vertical or horizontal layout
    setWidget(0);

    if ( m_gameStatsH )
    {
        delete m_gameStatsH;
        m_gameStatsH = 0;
    }
    
    if ( m_gameStatsV )
    {
        delete m_gameStatsV;
        m_gameStatsV = 0;
    }

}

// Clear all stored data.
void GameDock::clear()
{
    if ( m_gameStatsH )
    {
        m_gameStatsH->clear();
    }
    
    if ( m_gameStatsV )
    {
        m_gameStatsV->clear();
    }
}
    
// Slot when dock location has changed.
void GameDock::slot_dockLocationChanged( Qt::DockWidgetArea area )
{

    if ( Qt::LeftDockWidgetArea == area || Qt::RightDockWidgetArea == area )
    {
        setWidget( m_gameStatsV );
    }
    else if ( Qt::TopDockWidgetArea == area || Qt::BottomDockWidgetArea == area )
    {
        setWidget( m_gameStatsH );
    }
    else
    {
        std::cerr << "(EE) GameDock::slot_dockLocationChanged "
                  << " Unknown dock area "
                  << (int)area
                  << std::endl;
    }

}

// Bind game map to area.
void GameDock::setMap( const GameMap* map )
{
    if ( m_gameStatsH )
    {
        m_gameStatsH->setMap( map );
    }
    if ( m_gameStatsV )
    {
        m_gameStatsV->setMap( map );
    }
}

// Bind players to area.
void GameDock::setPlayers( const PlayerList* players )
{
    if ( m_gameStatsH )
    {
        m_gameStatsH->setPlayers( players );
    }
    if ( m_gameStatsV )
    {
        m_gameStatsV->setPlayers( players );
    }
}

// Update statistic window.
void GameDock::updateStats( const int round )
{
    if ( isVisible() )
    {
        // we will only update, if the dock is visible
        // and we will only update the visible stats
        if ( widget() )
        {
            ((GameStats*)widget())->update(round);
        }
    }
}
