<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>GameStats</name>
    <message>
        <location filename="gamestats.cpp" line="41"/>
        <location filename="gamestats.cpp" line="115"/>
        <location filename="gamestats.cpp" line="119"/>
        <source>Round: </source>
        <translation>Runde: </translation>
    </message>
    <message>
        <location filename="gamestats.cpp" line="41"/>
        <location filename="gamestats.cpp" line="119"/>
        <source>not running</source>
        <translation>nicht aktiv</translation>
    </message>
    <message>
        <location filename="gamestats.cpp" line="84"/>
        <source>Id</source>
        <translation>Id</translation>
    </message>
    <message>
        <location filename="gamestats.cpp" line="85"/>
        <source>Team</source>
        <translation>Team</translation>
    </message>
    <message>
        <location filename="gamestats.cpp" line="86"/>
        <source>Pos</source>
        <translation>Pos</translation>
    </message>
    <message>
        <location filename="gamestats.cpp" line="87"/>
        <source>View</source>
        <translation>Sicht</translation>
    </message>
    <message>
        <location filename="gamestats.cpp" line="88"/>
        <source>Life</source>
        <translation>Leben</translation>
    </message>
    <message>
        <location filename="gamestats.cpp" line="137"/>
        <location filename="gamestats.cpp" line="178"/>
        <source>blue</source>
        <translation>blau</translation>
    </message>
    <message>
        <location filename="gamestats.cpp" line="182"/>
        <source>red</source>
        <translation>rot</translation>
    </message>
    <message>
        <location filename="gamestats.cpp" line="186"/>
        <source>unknown</source>
        <translation>unbekannt</translation>
    </message>
</context>
<context>
    <name>GameWindow</name>
    <message>
        <location filename="gamewindow.cpp" line="92"/>
        <source>Game stats</source>
        <translation>Spielstatistik</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="102"/>
        <source>&amp;File</source>
        <translation>&amp;Datei</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="105"/>
        <location filename="gamewindow.cpp" line="279"/>
        <source>&amp;Connect to server</source>
        <translation>&amp;Verbinde zu Server</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="114"/>
        <source>&amp;Open map</source>
        <translation>Öffne &amp;Karte</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="116"/>
        <source>&amp;Replay saved game</source>
        <translation>&amp;Wiederhole gespeichertes Spiel</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="117"/>
        <source>&amp;Save game</source>
        <translation>&amp;Speichere Spiel</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="120"/>
        <source>E&amp;xit</source>
        <translation>&amp;Beenden</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="123"/>
        <source>&amp;View</source>
        <translation>&amp;Ansicht</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="140"/>
        <source>freiesMagazin-Contest: Right2Live</source>
        <translation>freiesMagazin-Wettbewerb: Right2Live</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="187"/>
        <source>Could not connect to server!</source>
        <translation>Konnte nicht zum Server verbinden!</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="208"/>
        <source>Open Map</source>
        <translation>Öffne Karte</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="208"/>
        <source>Map Files (*.map)</source>
        <translation>Kartendatei (*.map)</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="233"/>
        <source>Dis&amp;connect from server</source>
        <translation>&amp;Breche Verbindung zum Server ab</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="686"/>
        <source>Load Game</source>
        <translation>Lade Spiel</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="686"/>
        <location filename="gamewindow.cpp" line="746"/>
        <source>Game Files (*.game)</source>
        <translation>Spieldatei (*.game)</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="728"/>
        <location filename="gamewindow.cpp" line="764"/>
        <source>Error opening file</source>
        <translation>Fehler beim Öffnen der Datei</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="729"/>
        <location filename="gamewindow.cpp" line="765"/>
        <source>Error opening file &quot;</source>
        <translation>Fehler beim Öffnen der Datei &quot;</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="729"/>
        <source>&quot; for reading.</source>
        <translation>&quot; zum Lesen.</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="746"/>
        <source>Save Game</source>
        <translation>Speichere Spiel</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="765"/>
        <source>&quot; for writing.</source>
        <translation>&quot; zum Schreiben.</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="771"/>
        <source>No game data</source>
        <translation>Keine Spieldaten vorhanden</translation>
    </message>
    <message>
        <location filename="gamewindow.cpp" line="772"/>
        <source>There is no game data saved that could be saved to disc.</source>
        <translation>Es sind keine Spieldaten vorhanden, um diese auf Platte zu speichern.</translation>
    </message>
</context>
</TS>
