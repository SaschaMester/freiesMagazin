/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef TEAM_HH
#define TEAM_HH

/// Team membership of a player.
/**
 * There are two teams: BLUE and RED.
 * RED hunts BLUE and BLUE runs away.
 * As default all players are BLUE at
 * the start.
 */
enum Team
{
    TEAM_BLUE = 0,
    TEAM_RED,

    // Only add new teams before this line
    // But new teams could lead to problems!
    TEAM_MAX_NUM
};

#endif // TEAM_HH
