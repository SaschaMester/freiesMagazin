/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef KEY_HH
#define KEY_HH

// Qt
///////
#include <QChar>

class Key
{
public:
    /// Default constructor.
    Key() { }

    /// Constructor.
    Key( const QChar& id );

    /// Comparison operator.
    /**
     * @return true if key ids are the same
     */
    bool operator==( const Key& key ) const;

    /// Set new key.
    /**
     * @return true if key is valid and could be set
     */
    bool set( const QChar& id );

    /// Get key id.
    const QChar& get() const { return m_keyId; }

    /// Return true if key is set.
    bool isSet() const { return !m_keyId.isNull(); }

private:
    /// The key id.
    /**
     * This may be a lower case letter between
     * 'a' and 'z' or \0 if not set.
     */
    QChar m_keyId;
};

#endif // KEY_HH
