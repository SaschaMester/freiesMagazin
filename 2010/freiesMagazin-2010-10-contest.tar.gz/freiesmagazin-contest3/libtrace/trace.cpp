/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "trace.hh"

// Qt
////////
#include <QString>
#include <QTime>

// Sys
////////
#include <iostream>

// Bitmask which sub trace points are active.
int Trace::m_activeSubTracePoints[MTP_MAXNUM_TRACEPOINTS] = { 0 };

// Print information to STDOUT.
void Trace::print( const MainTracePoint tracePoint, const int subTracePoint,
                   const QString& line, const bool newline )
{
#ifdef TRACEON
    if ( 0 <= tracePoint && tracePoint < MTP_MAXNUM_TRACEPOINTS )
    {
        if ( ( m_activeSubTracePoints[tracePoint] & subTracePoint ) != 0 )
        {
            // trace is active
            std::cout << "(TT) "
                      << QTime::currentTime().toString("HH:mm:ss.zzz").toStdString() << " "
                      << line.toStdString() << " ";
            if ( newline )
            {
                std::cout << std::endl;
            }
        }
    }
    else
    {
        std::cerr << "(EE) Trace::print "
                  << " Trace point " << tracePoint
                  << " does not exists."
                  << std::endl;
    }
#endif
}

// Active some trace point.
void Trace::activate( const MainTracePoint tracePoint,
                      const int subTracePointBitMask )
{
    if ( 0 <= tracePoint && tracePoint < MTP_MAXNUM_TRACEPOINTS )
    {
        m_activeSubTracePoints[tracePoint] = subTracePointBitMask;
    }
    else
    {
        std::cerr << "(EE) Trace::activate "
                  << " Trace point " << tracePoint
                  << " does not exists."
                  << std::endl;
    }
}
