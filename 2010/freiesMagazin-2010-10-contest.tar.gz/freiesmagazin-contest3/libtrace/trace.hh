/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef TRACE_HH
#define TRACE_HH

// Own
////////
#include "traceenums.hh"

// Forward declarations
//////////////////////////
class QString;

/// Some tracing functionality
/**
 * This is a static class that prints some information to STDOUT or
 * STDERR.
 */
class Trace
{
public:
    /// Print information to STDOUT.
    /**
     * Note: Every output will have an additional space at the end.
     * @param line data to print
     * @param newline if true a newline will be printed
     *        after the line (default is true)
     */
    static void print( const MainTracePoint tracePoint, const int subTracePoint,
                       const QString& line, const bool newline = true );

    /// Active some trace point.
    /**
     * This method should be called in main at first for all trace
     * points, you want to activate.
     * @param tracePoint main trace point
     * @param subTracePointBitMask with all sub trace points you want to activate
     * */
    static void activate( const MainTracePoint tracePoint,
                          const int subTracePointBitMask );

private:
    /// Bitmask which sub trace points are active.
    /**
     * As default all trace points are inactive.
     */
    static int m_activeSubTracePoints[MTP_MAXNUM_TRACEPOINTS];
};

#endif // TRACE_HH
