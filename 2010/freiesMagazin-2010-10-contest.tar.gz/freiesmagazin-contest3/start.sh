#!/bin/bash

if [ $# -eq 3 ]
then
    for (( J=1; $J <= $3; J++ ))
    do
        echo "======== Durchlauf $J ==========="
        echo
        
        cd engine
        echo "Starte Engine $J"
        ./engine -m "../$1" -p $2 &> "../log$J.txt" &
        sleep 2
        cd ../ai
        for (( I=1; $I <= $2; I++ ))
        do
            echo "Starte AI $I in $J"
            ./ai & # &>> "../log$J.txt"
            sleep 1
        done
        cd ..

        echo "Warte auf Spielende"
        C=`ps -ef | grep engine | grep -v grep | wc -l`
        while [ $C -gt 0 ]
        do
            sleep 10
            C=`ps -ef | grep engine | grep -v grep | wc -l`
        done
    done
else
    echo "Syntax:  $0 MAP NUM_PLAYERS NUM_ITERATIONS"
    echo "Example: $0 maps/board2.map 20 2"
fi
