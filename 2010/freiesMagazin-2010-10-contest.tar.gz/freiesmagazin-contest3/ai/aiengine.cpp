/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "aiengine.hh"
#include "trace.hh"

// Sys
/////////
#include <cstdlib>
#include <ctime>
#include <iostream>

// Constructor
AiEngine::AiEngine()
: m_mode( AI_MODE_RANDOM ), m_showGameInfo(false)
{
    Trace::print( MTP_AI_ENGINE, STP_AI_STRUCTOR,
                  "AiEngine::AiEngine Start" );

    /* initialize random seed: */
    srand ( time(NULL) );

    bool ok = true;

    // first we must connect all signals and slots
    if ( !connect( &m_client, SIGNAL(sig_connected()),
                   this, SLOT(slot_connected()) ) )
    {
        std::cerr << "(EE) AiEngine::AiEngine "
                  << " Connect 1 not possible!"
                  << std::endl;
        ok = false;
    }

    if ( !connect( &m_client, SIGNAL(sig_disconnected()),
                   this, SLOT(slot_disconnected()) ) )
    {
        std::cerr << "(EE) AiEngine::AiEngine "
                  << " Connect 2 not possible!"
                  << std::endl;
        ok = false;
    }

    if ( !connect( &m_client, SIGNAL(sig_processCommand(const ClientParserCommand)),
                   this, SLOT(slot_processCommand(const ClientParserCommand)) ) )
    {
        std::cerr << "(EE) AiEngine::AiEngine "
                  << " Connect 3 not possible!"
                  << std::endl;
        ok = false;
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_STRUCTOR,
                  "AiEngine::AiEngine End " + QString::number((int)ok) );    
}

// Connect to a server.
bool AiEngine::connectToServer( const QHostAddress address, const quint16 port, const int msecs )
{
    return m_client.connectToServer(address,port,msecs);
}

// Wait until server kills connection.
void AiEngine::waitUntilDisconnected()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CONNECTION,
                  "AiEngine::waitUntilDisconnected Start" );

    m_client.waitUntilDisconnected();

    Trace::print( MTP_AI_ENGINE, STP_AI_CONNECTION,
                  "AiEngine::waitUntilDisconnected End" );
}

// Client has been connected to the server.
void AiEngine::slot_connected()
{
    // After the connection to the server is okay, we must wait until the id
    // for the player is set correctly.
    
    Trace::print( MTP_AI_ENGINE, STP_AI_CONNECTION,
                  "AiEngine::slot_connected Start" );

    // wait, if data have been sent from the server
    // this should call receiveData
    if ( m_client.waitForData() )
    {
        // I don't know better solution than to wait
        // again 1 second. In this time the client id
        // should have been extracted.
        m_client.waitForData( 1000 );

        if ( m_showGameInfo )
        {
            std::cout << "(II) AiEngine::slot_connected "
                      << " Player " << m_player.getIndex()
                      << std::endl;
        }
    }

    if ( m_player.getIndex() >= 0 )
    {
        m_client.send("ID_OKAY");
    }
    else
    {
        m_client.send("ID_NOT_OKAY");
        m_client.stopConnection();
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_CONNECTION,
                  "AiEngine::slot_connected End" );
}

// Client has been disconnected from the server.
void AiEngine::slot_disconnected()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CONNECTION,
                  "AiEngine::slot_disconnected Start" );

    // Nothing to do here

    Trace::print( MTP_AI_ENGINE, STP_AI_CONNECTION,
                  "AiEngine::slot_disconnected End" );
}

// Client has been disconnected from the server.
void AiEngine::slot_processCommand( const ClientParserCommand commandId )
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::slot_processCommand Start "+ QString::number((int)commandId) );

    switch ( commandId )
    {
    case CPC_NO_COMMAND:
        // nothing to do.
        break;
    case CPC_ERROR:
        // nothing to do.
        break;
    case CPC_PING:
        // nothing to do.
        break;
    case CPC_SET_ID:
        processCommandId();
        break;
    case CPC_CONNECT_OTHER:
        processCommandConnectOther();
        break;
    case CPC_DISCONNECT_OTHER:
        processCommandDisconnectOther();
        break;
    case CPC_DISCONNECT_SELF:
        processCommandDisconnect();
        break;
    case CPC_SET_PLAYER:
        processCommandSet();
        break;
    case CPC_SEE_PLAYER:
        processCommandSeePlayer();
        break;
    case CPC_SEE_KEY:
        processCommandSeeKey();
        break;
    case CPC_GET_KEY:
        processCommandGetKey();
        break;
    case CPC_TEAM_CHANGE:
        processCommandTeamChange();
        break;
    case CPC_LOAD_MAP:
        processCommandLoadMap();
        break;
    case CPC_START:
        // start calculation of next move
        processCommandStartCalculation();
        break;
    case CPC_LIFE:
        // this is not implemented here
        processCommandStoreLife();
        break;
    case CPC_TOXIC:
        // this is not implemented here
        processCommandStoreToxicValue();
        break;
    default:
        std::cerr << "(EE) AiEngine::slot_processCommand "
                  << " Default case reached for command "
                  << commandId
                  << std::endl;
        break;
    }

    // delete processed command
    m_client.resetParser();

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::slot_processCommand End " );
}

// Get player id.
void AiEngine::processCommandId()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandId Start " );

    if ( !m_player.setIndex( m_client.getClientId() ) )
    {
        // id could not be set, disconnect client because not work
        // without a correct index
        m_client.stopConnection();
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandId End " );
}

// Connect another client.
void AiEngine::processCommandConnectOther()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandConnectOther Start " );

    const int id = m_client.getClientId();

    // first we must check if the id is not our id
    if ( id != m_player.getIndex() )
    {
        if ( !m_otherPlayers.contains( id ) )
        {
            // add new player
            m_otherPlayers.add( id );
        }
        else
        {
            std::cerr << "(EE) AiEngine::processCommandConnectOther "
                      << " Client "
                      << id
                      << " already connected."
                      << std::endl;
        }
    }
    // no error, we just ignore it

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandConnectOther End " + QString::number(id) );
}

// Disconnect another client.
void AiEngine::processCommandDisconnectOther()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandDisconnectOther Start " );

    const int id = m_client.getClientId();

    // first we must check if the id is not our id
    if ( id != m_player.getIndex() )
    {
        if ( m_otherPlayers.contains( id ) )
        {
            m_otherPlayers.remove(id);
        }
        else
        {
            std::cerr << "(EE) AiEngine::processCommandDisconnectOther "
                      << " Client "
                      << id
                      << " not connected."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "(EE) AiEngine::processCommandDisconnectOther "
                  << " Try to disconnect own client "
                  << id
                  << std::endl;
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandDisconnectOther End " + QString::number(id) );
}

// Disconnect the client.
void AiEngine::processCommandDisconnect()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandDisconnect Start " );

    m_client.stopConnection();

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandDisconnect End " );
}

// Set data of own player.
void AiEngine::processCommandSet()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandSet Start " );

    if ( m_showGameInfo )
    {
        std::cout << "(II) AiEngine::processCommandSet "
                  << " Player "
                  << m_player.getIndex()
                  << " Position ("
                  << m_client.getPosition().x() << ", " << m_client.getPosition().y()
                  << ")"
                  << " View "
                  << Player::toString( m_client.getView() ).toStdString()
                  << std::endl;
    }

    if ( !m_player.setPosition( m_client.getPosition() ) )
    {
        std::cerr << "(EE) AiEngine::processCommandSet "
                  << " Position ("
                  << m_client.getPosition().x() << ", " << m_client.getPosition().y()
                  << ") could not be set for player "
                  << m_player.getIndex()
                  << std::endl;
    }
        
    if ( !m_player.setView( m_client.getView() ) )
    {
        std::cerr << "(EE) AiEngine::processCommandSet "
                  << " View "
                  << Player::toString( m_client.getView() ).toStdString()
                  << " could not be set for player "
                  << m_player.getIndex()
                  << std::endl;
    }
    

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandSet End " );
}

// Set data of other player.
void AiEngine::processCommandSeePlayer()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandSeePlayer Start " );

    const int id = m_client.getClientId();

    if ( id >= 0 )
    {
        if ( m_showGameInfo )
        {
            std::cout << "(II) AiEngine::processCommandSeePlayer "
                      << " Player "
                      << m_player.getIndex()
                      << " Sees Player "
                      << id
                      << " Position ("
                      << m_client.getPosition().x() << ", " << m_client.getPosition().y()
                      << ")"
                      << " View "
                      << Player::toString( m_client.getView() ).toStdString()
                      << std::endl;
        }

        if ( !m_otherPlayers.setPosition( id, m_client.getPosition() ) )
        {
            std::cerr << "(EE) AiEngine::processCommandSeePlayer "
                      << " Position ("
                      << m_client.getPosition().x() << ", " << m_client.getPosition().y()
                      << ") could not be set for player "
                      << id
                      << std::endl;
        }
            
        if ( !m_otherPlayers.setView( id, m_client.getView() ) )
        {
            std::cerr << "(EE) AiEngine::processCommandSeePlayer "
                      << " View "
                      << Player::toString( m_client.getView() ).toStdString()
                      << " could not be set for player "
                      << id
                      << std::endl;
        }
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandSeePlayer End " + QString::number(id) );
}

// See a new key.
void AiEngine::processCommandSeeKey()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandSeeKey Start " );

    // create a new key field
    const Field field( m_client.getPosition(), m_client.getKey().get() );

    // check if key field is already known
    if ( !m_visibleKeys.contains( field ) )
    {
        // key is not known, so add it
        m_visibleKeys.append( field );

        if ( m_showGameInfo )
        {
            std::cout << "(II) AiEngine::processCommandSeeKey "
                      << " Player "
                      << m_player.getIndex()
                      << " Key "
                      << m_client.getKey().get().toAscii()
                      << " Position ("
                      << m_client.getPosition().x() << ", " << m_client.getPosition().y()
                      << ")"
                      << std::endl;
        }
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandSeeKey End " );
}

// Get a new key
void AiEngine::processCommandGetKey()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandGetKey Start " );

    // it doesn't matter if the player already has the key
    // The player will only add only keys that he does not have.
    if ( m_player.addKey( m_client.getKey() ) )
    {
        if ( m_showGameInfo )
        {
            std::cout << "(II) AiEngine::processCommandGetKey "
                      << " Player "
                      << m_player.getIndex()
                      << " Key "
                      << m_client.getKey().get().toAscii()
                      << std::endl;
        }
    }
                  
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandGetKey End " );
}

// change the team of a player
void AiEngine::processCommandTeamChange()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandTeamChange Start " );

    const int id = m_client.getClientId();

    if ( id >= 0 )
    {
        if ( m_showGameInfo )
        {
            std::cout << "(II) AiEngine::processCommandTeamChange "
                      << " Player "
                      << m_player.getIndex()
                      << " Change Player "
                      << id
                      << " Team "
                      << Player::toString( m_client.getTeam() ).toStdString()
                      << std::endl;
        }

        if ( id == m_player.getIndex() )
        {
            // the id is the id of the own player
            m_player.setTeam( m_client.getTeam(), false );
        }
        else if ( !m_otherPlayers.setTeam( id, m_client.getTeam(), false ) )
        {
            std::cerr << "(EE) AiEngine::processCommandTeamChange "
                      << " Team "
                      << Player::toString( m_client.getTeam() ).toStdString()
                      << " could not be set for player "
                      << id
                      << std::endl;
        }
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandTeamChange End " + QString::number(id) );
}

// Load new map.
void AiEngine::processCommandLoadMap()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandLoadMap Start " + m_client.getMapName() );

    if ( !m_map.load( m_client.getMapName() ) )
    {
        std::cerr << "(II) AiEngine::processCommandLoadMap "
                  << " Client " << m_player.getIndex()
                  << " Map "
                  << m_client.getMapName().toStdString()
                  << " could not be loaded."
                  << std::endl;
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandLoadMap End " );
}

// Start calculation of next move.
void AiEngine::processCommandStartCalculation()
{
    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandStartCalculation Start " );

    Direction move = DIRECTION_NONE;
    Direction view = DIRECTION_NORTH;

    calcNextMove( move, view );

    if ( m_showGameInfo )
    {
        std::cout << "(II) AiEngine::processCommandStartCalculation "
                  << " Player "
                  << m_player.getIndex()
                  << " Move "
                  << Player::toString( move ).toStdString()
                  << " View "
                  << Player::toString( view ).toStdString()
                  << std::endl;
    }

    if ( !m_client.send("MOVE " + Player::toString(move) + " " +  Player::toString(view) ) )
    {
        std::cerr << "(EE) AiEngine::processCommandStartCalculation "
                  << " Client " << m_player.getIndex()
                  << " Send failed!"
                  << std::endl;
    }

    Trace::print( MTP_AI_ENGINE, STP_AI_PROCESS,
                  "AiEngine::processCommandStartCalculation End " );
}

// Calculate next move of player.
bool AiEngine::calcNextMove( Direction& move, Direction& view )
{
    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine::calcNextMove Start " );

    bool ok = true;
    
    move = DIRECTION_NONE;
    view = DIRECTION_NORTH;

    // depending on the behaviour mode we move differently
    switch ( m_mode )
    {
    case AI_MODE_NONE:
        // do do nothing but stand still
        ok = true;
        break;
    case AI_MODE_LOOK:
        // look around
        view = m_player.getView();
        if ( view < DIRECTION_NORTH_EAST )
        {
            // Yeah, it's not nice to operate on
            // enumerators, but I'm lazy.
            view = (Direction)(view+1);
        }
        else
        {
            view = DIRECTION_NORTH;
        }
        ok = true;
        break;
    case AI_MODE_RANDOM:
        // What a fine dirty hack. ^^
        move = (Direction)(rand()%(DIRECTION_NORTH_EAST+1));
        view = (Direction)(rand()%(DIRECTION_NORTH_EAST)+1);
        ok = true;
        break;
    default:
        std::cerr << "(EE) AiEngine::calcNextMove "
                  << " Client " << m_player.getIndex()
                  << " Reached default case for mode "
                  << m_mode
                  << std::endl;
        break;
    }

#ifdef QT_DEBUG
        std::cout << "(II) AiEngine::calcNextMove "
                  << " Client " << m_player.getIndex()
                  << " Move move "
                  << m_mode
                  << " Move in dir "
                  << Player::toString(move).toStdString()
                  << " view "
                  << Player::toString(view).toStdString()
                  << std::endl;
#endif

    Trace::print( MTP_AI_ENGINE, STP_AI_CALC,
                  "AiEngine::calcNextMove End " + QString::number((int)ok) );

    return ok;
}

