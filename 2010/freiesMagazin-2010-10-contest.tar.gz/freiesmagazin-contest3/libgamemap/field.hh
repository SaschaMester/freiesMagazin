/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef FIELD_HH
#define FIELD_HH

// Own
///////
#include "fieldtype.hh"

// Qt
///////
#include <QPoint>
#include <QChar>

/// Field on map.
/**
 * This is the class for a field on the map
 * It contains the position on the map (as two integers)
 * and the field type.
 */
class Field
{
public:
    /// Default constructor.
    Field();

    /// Constructor.
    /**
     * Depending on the character a new field type will be set.
     * The position must be non-negative.
     * @param pos new positon on game board
     * @param fieldChar character that represents field
     * @param toxicChar Toxic char for value of this field. 
     */
    Field ( const QPoint& pos, const QChar& fieldChar, const QChar& toxicChar = ' ' );
    
    /// Comparison operator.
    /**
     * Checks if this field is less than the other field.
     * Less than is defined first by the character and if this
     * is the same by the position (that never should be the same).
     */
    bool operator<( const Field& field ) const;

    /// Comparison operator.
    /**
     * Checks if this field is the same as another field.
     */
    bool operator==( const Field& field ) const;
        
    /// Unset field data.
    void unset();

    /// Set toxic value.
    /**
     * @return set toxic value of field.
     */
    void setToxicValue( const double toxic ) { m_toxicValue = toxic; }
    
    /// Check for field type.
    /**
     * @param type type type to check
     * @return true if this field has the given type
     */
    bool isType( const FieldType type ) const
    {
        return ( type == m_type );
    }
    
    /// Get position.
    /**
     * @return position of tile on game board.
     */
    const QPoint& getPos() const { return m_pos; }

    /// Get toxic value.
    /**
     * @return toxic value of field.
     */
    double getToxicValue() const { return m_toxicValue; }
        
    /// Get ascii character for this field.
    /**
     * For writing a map on disc each field must be converted
     * into a single ascii character.
     * For clients the keys are not allowed to be written on disc
     * so sometimes withoutKeys must be true.
     * @param withoutKeys if true keys will be handled as empty fields
     * @return corresponding ascii character for this field
     */
    char toAscii( const bool withoutKeys = false ) const;
    
    /// Check if a key opens a door.
    /**
     * The checked field must be a door field. If the
     * the door character is the upper case version of
     * the character of the given key char it opens
     * the door.
     * @param key Given char (must be a key char).
     * @return true if key opens door.
     */
    bool canOpen( const QChar key ) const;

    /// Convert a door to a key.
    /**
     * The field must be a door field!
     * @param keyField to create, the position of the door will be copied
     * @return true if conversion is okay
     */
    bool convertToKeyField( Field& keyField ) const;
    
    /// Check if character represents a valid field type.
    /**
     * @param fieldChar given character
     * @return true if character represents a field type
     */
    static bool isValidChar( const QChar& fieldChar );

    /// Check if character represents a valid toxic value.
    /**
     * The character could be a digit 0-9 or a space.
     * @param fieldChar given character
     * @return true if character represents a toxic value
     */
    static bool isValidToxicChar( const QChar& fieldChar );
    
    /// Check if character represents a valid key field type.
    /**
     * @param fieldChar given character
     * @return true if character represents a key field type
     */
    static bool isValidKeyChar( const QChar& fieldChar );
    
private:

    /// Position on game board.
    QPoint m_pos;
    
    /// Type of field (see above.)
    FieldType m_type;
    
    /// Door-/Key char.
    /**
     * Some fields on the game board contain characters
     * that tell that this field is a door (upper case)
     * or a key (lower case).
     * For empty or blocked tiles this character is not
     * important and contains a space.
     */
    QChar m_doorKey;

    /// Toxic value for this field.
    /**
    * The toxic value defines how dangerous it is to stand on some
    * field. The value should be between 0.01 and 1.0 percent. Each
    * round a player stands on such a field this value will be
    * subtracted from his health. If the health-value is 0 he will
    * change to another team.
    * As default each field will have a toxic value of 0.01. You should
    * not set the value to 0.0 because that could result in an endless
    * game.
    */
    double m_toxicValue;
};

#endif // BASEFIELD_HH
