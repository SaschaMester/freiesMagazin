/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef FIELDTYPE_HH
#define FIELDTYPE_HH

/// Field type.
/**
 * The field type defines what type of field
 * we have. There are only four valid types.
 */
enum FieldType
{
    FT_NONE = 0,        // field is not set/invalid
    FT_EMPTY,           // field is empty
    FT_BLOCK,           // field is blocked
    FT_DOOR,            // field contains a door
    FT_KEY,             // field contains a key

    FT_NUM_TYPES        // last type, do not add types after this line
};

#endif // FIELDTYPE_HH
