/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "field.hh"
#include "trace.hh"

// Qt
////////
#include <QRegExp>

// Sys
////////
#include <iostream>

// Constructor.
Field::Field()
: m_pos(-1,-1), m_type(FT_NONE), m_doorKey('\0'), m_toxicValue(0.01)
{
    Trace::print( MTP_FIELD, STP_FIELD_STRUCTOR,
                  "Field::Field Start " );

    Trace::print( MTP_FIELD, STP_FIELD_STRUCTOR,
                  "Field::Field End " );
}

// Constructor.
Field::Field( const QPoint& pos, const QChar& fieldChar, const QChar& toxicChar )
: m_pos(-1,-1), m_type(FT_NONE), m_doorKey('\0'), m_toxicValue(0.01)
{
    Trace::print( MTP_FIELD, STP_FIELD_STRUCTOR,
                  "Field::Field Start Pos: " + QString::number(pos.x()) + " " + QString::number(pos.y()) + " Char: " + QString(fieldChar) );

    // check position
    if ( pos.x() >= 0 && pos.y() >= 0 )
    {
        if ( isValidChar( fieldChar ) )
        {
            if ( isValidToxicChar( toxicChar ) )
            {
                bool ok = false;

                if ( fieldChar == ' ' )
                {
                    m_type = FT_EMPTY;
                    ok = true;
                }
                else if ( fieldChar == '#' )
                {
                    m_type = FT_BLOCK;
                    ok = true;
                }
                else // it must be a letter
                {
                    if ( fieldChar.isUpper() )
                    {
                        m_type = FT_DOOR;
                        ok = true;
                    }
                    else if ( fieldChar.isLower() )
                    {
                        m_type = FT_KEY;
                        ok = true;
                    }
                    else
                    {
                        // neither upper nor lower
                        // that is not possible
                        std::cerr << "(EE) Field::Field "
                                  << " Character '"
                                  << fieldChar.toAscii()
                                  << "' is neither upper case nor lower case."
                                  << std::endl;
                    }
                }

                // extract toxic value
                double toxicValue = 0.01;

                if ( toxicChar == ' ' )
                {
                    // We could not have a 0 value because that could
                    // lead to and endless game.
                    toxicValue = 0.01;
                }
                else if ( toxicChar == '0' || toxicChar == '#' )
                {
                    toxicValue = 0.2;
                }
                else
                {
                    // it must be a digit between 1 and 9
                    // so the range is 0.02 to 0.18
                    toxicValue = 0.02 * (toxicChar.digitValue());

                    if ( toxicValue <= 0.0 )
                    {
                        ok = false;
                    }
                }
            
                // if type is okay, set pos and char
                if ( ok )
                {
                    m_pos = pos;
                    m_doorKey = fieldChar;

                    // We do not check the toxic value because it may be
                    // possible in the future that I decide to implement
                    // some healing fields that will have a negative
                    // toxic value.
                    m_toxicValue = toxicValue;
                }
            }
            else
            {
                std::cerr << "(EE) Field::Field "
                          << " Character '"
                          << toxicChar.toAscii()
                          << "' is not a valid toxic character."
                          << std::endl;
            }
        }
        else
        {
            std::cerr << "(EE) Field::Field "
                      << " Character '"
                      << fieldChar.toAscii()
                      << "' is not a valid field character."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "(EE) Field::check "
                  << " Position "
                  << pos.x() << "/" << pos.y()
                  << " must not be negative."
                  << std::endl;
    }

    Trace::print( MTP_FIELD, STP_FIELD_STRUCTOR,
                  "Field::Field End " );
}

// Unset field data.
void Field::unset()
{
    Trace::print( MTP_FIELD, STP_FIELD_SET,
                  "Field::unset Start " );

    m_pos.setX(-1);
    m_pos.setY(-1);
    m_type = FT_NONE;
    m_doorKey = ' ';
    m_toxicValue = 0.01;

    Trace::print( MTP_FIELD, STP_FIELD_SET,
                  "Field::unset End " );
}

// Check if a key opens a door.
bool Field::canOpen( const QChar key ) const
{
    Trace::print( MTP_FIELD, STP_FIELD_CHECK,
                  "Field::canOpen Start " + QString(key) );

    bool open = false;
    
    if ( isType( FT_DOOR ) )
    {
        if ( isValidKeyChar( key ) )
        {
            if ( key.toUpper() == m_doorKey )
            {
                open = true;
            }
        }
        else
        {
            std::cerr << "(EE) Field::canOpen "
                      << " Key "
                      << key.toAscii()
                      << " is no valid key char."
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "(EE) Field::canOpen "
                  << " Door is not a door field: "
                  << m_type
                  << std::endl;
    }

    Trace::print( MTP_FIELD, STP_FIELD_CHECK,
                  "Field::canOpen End " + QString::number((int)open) );
    
    return open;
}

// Convert a door to a key.
bool Field::convertToKeyField( Field& keyField ) const
{
    Trace::print( MTP_FIELD, STP_FIELD_SET,
                  "Field::convertToKeyField Start " );

    bool ok = false;
    
    if ( isType( FT_DOOR ) )
    {
        keyField.m_pos = m_pos;
        keyField.m_type = FT_KEY;
        keyField.m_doorKey = m_doorKey.toLower();
        ok = true;
    }
    else
    {
        std::cerr << "(EE) Field::convertToKeyField "
                  << " Door is not a door field: "
                  << m_type
                  << std::endl;
    }

    Trace::print( MTP_FIELD, STP_FIELD_SET,
                  "Field::convertToKeyField End " + QString::number((int)ok) );
    
    return ok;
}

// Check if character represents a valid field type.
bool Field::isValidChar( const QChar& fieldChar )
{
    return QRegExp( "^[a-zA-Z #]$" ).exactMatch( fieldChar );
}

// Check if character represents a valid toxic value.
bool Field::isValidToxicChar( const QChar& fieldChar )
{
    return QRegExp( "^[0-9 #]$" ).exactMatch( fieldChar );
}
       
// Check if character represents a valid key field type.
bool Field::isValidKeyChar( const QChar& fieldChar )
{
    return QRegExp( "^[a-z]$" ).exactMatch( fieldChar );
}
    
// Get ascii character for this field.
char Field::toAscii( const bool withoutKeys ) const
{
    char retChar = ' ';

    if ( FT_NONE == m_type )
    {
        // The type is not set.
        // This should not happen.
        std::cerr << "(EE) Field::toAscii "
                  << " Type is not set. Could not get ascii char."
                  << std::endl;
    }
    else
    {
        if ( withoutKeys && FT_KEY == m_type )
        {
            // We want to ignore key fields
            // and return an empty field.
            retChar = ' ';
        }
        else
        {
            retChar = m_doorKey.toAscii();
        }
    }

    return retChar;
}

// Comparison operator.
bool Field::operator<( const Field& field ) const
{
    bool isLessThan = false;

    if ( m_doorKey < field.m_doorKey )
    {
        // char is less than
        isLessThan = true;
    }
    else if ( m_doorKey == field.m_doorKey )
    {
        // characters are the same

        if ( m_pos.x() < field.m_pos.x() )
        {
            isLessThan = true;
        }
        else if ( m_pos.x() == field.m_pos.x() )
        {
            // x position is the same

            if ( m_pos.y() < field.m_pos.y() )
            {
                isLessThan = true;
            }
#ifdef QT_DEBUG
            else if ( m_pos.y() == field.m_pos.y() )
            {
                // Position is the same. That should not happen!
                std::cerr << "(EE) Field::operator< "
                          << " Position "
                          << m_pos.x() << "," << m_pos.y()
                          << " is the same!"
                          << std::endl;
            }
#endif // QT_DEBUG
        }
    }
    
    return isLessThan;
}

// Comparison operator.
bool Field::operator==( const Field& field ) const
{
    return ( ( m_doorKey == field.m_doorKey ) && ( m_pos == field.m_pos ) );
}
