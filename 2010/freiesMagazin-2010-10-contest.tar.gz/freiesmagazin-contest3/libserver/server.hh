/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef SERVER_HH
#define SERVER_HH

// Own
////////
#include "direction.hh"
#include "serverclientlist.hh"
#include "serverparserlist.hh"
#include "serverparsercommand.hh"

// Qt
////////
#include <QObject>
#include <QTcpServer>
#include <QAbstractSocket>

// Forward declarations
///////////////////////////
class QHostAddress;
class QTcpSocket;

/// Server that connects to all clients.
/**
 * The server stores the connections to all clients.
 * Each client will have an own parser (so that they don't
 * talk mixed up.
 * The server itself does not store any game data that
 * must be done outside. A signal is send if any new
 * command from a client has been processed and could be get.
 */
class Server : public QObject
{
Q_OBJECT

public:

    ////////////////////////////////
    // Constructor and Operators
    ////////////////////////////////

    /// Constructor
    /**
     * Creates a new tcp socket to connect for listining.
     */
    Server();

    /// Destructor
    /**
     * All clients will receive the DISCONNECT-command automatically.
     * The the connections to the clients are stopped.
     */
    ~Server();

    ////////////////////////////////
    // Connections
    ////////////////////////////////

    /// Start server so that it listens to connection.
    /**
     * This method is the most important function so that clients
     * can connect to the server. The adress and port will be given
     * from outside.
     * @param address server adress for connection
     * @param port port the server listens for new connections
     * @return true if server is listening
     */
    bool startListening( const QHostAddress& address, const quint16 port );
    
    /// Stops the server and kills all connections.
    /**
     * This method should be called when the game is finished.
     * All clients will receive the DISCONNECT-command automatically.
     * @return true if server does not listen anymore
     */
    bool stopListening();
    
    /// Ignore some client or liste to it.
    /**
     * Sometimes it's necessary that the commands a client sends
     * will not be processed for example if the game is not running
     * yet or there is no round. For these case we can ignore
     * a client.
     * @param clientId Client to ignore/listen to.
     * @param ignore If true client is ignored else we will listen to it.
     */
    void ignoreClient( const int clientId, const bool ignore );

    /// Send some data to a client.
    /**
     * The data is send to the TCP socket. We will wait
     * 1 second till the data must have been sent.
     * @param index Client connection that should receive the data.
     * @param data to sent
     * @return true if data has been sent
     */
    bool send( const int clientId, const QString& data, const int msecs = 1000 );

    /// Send a PING to all clients we are waiting for.
    /**
     * Each client that has not accepted it's id yet, will receive
     * a ping.
     * @return true if at least one client has received a ping.
     */
    bool pingWaitingClients();

    /// Send a PING to all clients.
    /**
     * Each client will receive a ping.
     * @return true if at least one client has received a ping.
     */
    bool pingAllClients();

    /// Wait for a new connection.
    /**
     * @param msecs Milliseconds to wait till timeout.
     * @return true if a new connection is available
     */
    bool waitForNewConnection( const int msec = 1000 );

    /// Decline new connections.
    /**
     * Even if a new client connects we will ignore it.
     */
    void declineNewConnections();

    /// Decline all new connections.
    /**
     * New client connections will be accepted again.
     */
    void acceptNewConnections();

    ////////////////////////////////
    // GUI server
    ////////////////////////////////

    /// Send some data to a GUI client.
    /**
     * The data is send to the TCP socket. We will wait
     * 1 second till the data must have been sent.
     * @param data to sent
     * @return true if data has been sent
     */
    bool sendGui( const QString& data, const int msecs = 1000 );

    /// Send some data to a GUI client.
    /**
     * The data is send to the TCP socket. We will wait
     * 1 second till the data must have been sent.
     * We will attach the number of each client to the
     * data!
     * @param data to sent
     * @return true if data has been sent
     */
    bool sendAllGui( const QString& data, const int msecs = 1000 );

    /// Wait for a new gui connection.
    /**
     * @param msecs Milliseconds to wait till timeout.
     * @return true if a new connection is available
     */
    bool waitForNewGuiConnection( const int msec = 1000 );

    ////////////////////////////////
    // Setting data
    ////////////////////////////////
    
    /// Reset parser so that a new command could be processed.
    /**
     * This must be done from outside, because otherwise we could
     * not decide if the outer process has processed a command.
     * @param clientId Index of parser that should be reset
     * @return true if parser could be reset
     */
    bool resetParser( const int clientId );

signals:
    /// Signal that a new client has connected and accepted it's id.
    /**
     * After connecting to the server the client will receive a
     * real id and must accept it. If he does so, all other clients
     * will be informed that a new client is available. This signal
     * is send so that someone outside can create a new player
     * with this clientId.
     * @param clientId Assign client id for the client.
     */
    void sig_clientConnected( const int clientId );

    /// Signal when a client has been disconnected.
    /**
     * Outside the corresponding player must be deleted.
     * The other clients are automatically informed about the
     * disconnection.
     * @param clientId Client that has disconnected.
     */
    void sig_clientDisconnected( const int clientId );

    /// Signal that a client wants to move.
    /**
     * If a client moves (after the game engine) has told it so
     * we will send this signal so that the engine can store the
     * movement.
     * @param clientId Id of new client.
     */
    void sig_clientMovement( const int clientId, const Direction movement, const Direction view );

    ////////////////////////////////
    // GUI server
    ////////////////////////////////

    /// Signal that a new gui has connected.
    /**
     * Outside the application should send all relevant game data
     * like game map and players to the GUI.
     */
    void sig_guiConnected();
    
private slots:

    /// Accept connection from a client.
    /**
     * This method is called everytime a new client has connected
     * to the server. The server must add the connection
     * to its list and create a server parser for the client
     * to understand it's commands. Therefore the server creates
     * a new unique id for the client and sends it to the client.
     * If the client accepts the id the signal sig_clientConnected
     * is given, so that outside someone can create a new player.
     */
    void slot_acceptConnection();

    /// A client has disconnected.
    /**
     * This method is called when a client has closed the connection.
     * The client connection must the be deleted from the
     * list. All other clients will be informed that this client
     * has quit. The signal sig_clientDisconnected is given.
     * @param clientId Client that has disconnected.
     */
    void slot_clientDisconnected( const int clientId );

    /// Receive data from a client connection.
    /**
     * New data has been to the client connection who already
     * has received the data. The ServerParser must then parse
     * the data and the server must process the command queue.
     * @param data received data
     * @param clientId Client connection that has received the data
     */
    void slot_receiveData( const QString& data, const int clientId );

    ////////////////////////////////
    // GUI server
    ////////////////////////////////

    /// Accept connection from a gui.
    /**
     * This method is called everytime a new gui has connected
     * to the server. Only one GUI can be connected at a time.
     * another GUI will receive a DISCONNECT signal.
     */
    void slot_acceptGuiConnection();

    /// A gui has disconnected.
    /**
     * This method is called when a gui has closed the connection.
     * The GUI server will then be available for another connection.
     */
    void slot_guiDisconnected();

    /// An error occured in the gui connection.
    void slot_displayError( QAbstractSocket::SocketError socketError );

private:

    /// Process all commands in the process queues.
    /**
     * Iterate over all process queues of the parsers.
     * @return true if everything is okay
     */
    bool processCommandQueues();

    /// Process all commands in one process queue.
    /**
     * @param parserId Parser id (not list index)
     * @return true if everything is okay
     */
    bool processCommandQueue( const int parserId );

    /// Process single command.
    /**
     * @param parserId Parser id (not list index)
     */
    void processCommand( const ServerParserCommand command, const int parserId );

    /// The client has accepted it's id.
    /**
     * All other clients will be informed about the new client
     * and the signal sig_clientConnected is given.
     * Note: Before the client has not accepted it's id
     * not other command will be processed but ignored.
     * @param parserId Parser that holds the data.
     */
    void acceptId( const int parserId );

    /// The client has not accepted it's id.
    /**
     * In such a case the client will receive the DISCONNECT-signal
     * and the connection will be cut.
     * @param parserId Parser that holds the data.
     */
    void declineId( const int parserId );

    /// The client wants to move.
    /**
     *
     * The signal sig_clientMovement will be given if the movement
     * is valid and the client will receive the MOVE_OKAY signal.
     * If it's not valid, the client will receive the MOVE_NOT_OKAY
     * signal.
     * @param parserId Parser that holds the data.
     */
    void moveClient( const int parserId );

    ////////////////////////////////
    // GUI server
    ////////////////////////////////

    /// Init server for GUI client.
    /**
     * The server will listen on a new port and waits for
     * a connection.
     */
    void initGuiServer();
    
private:

    /// Copy constructor.
    /**
     * This is not implemented because I don't want a copy.
     */
    Server( const Server& server );

    /// Assignment operator.
    /**
     * This is not implemented because I don't want a copy.
     */
    Server& operator=( const Server& server );

private:

    /// The real tcp server.
    QTcpServer m_serverConnection;

    /// A list of parsers for each client connection.
    /**
     * The parser separates all commands and put them in queue
     * to be processed later.
     * Each client has it's own parser to interpreter the commands.
     * The list DOES NOT correspond with the client list in
     * ordering or size. You can only the correct client by the
     * clientId stored in the parser.
     */
    ServerParserList m_parsers;

    /// List of clients.
    /**
     * This list contains all client connections. This member will
     * also generate the unique ids for the clients.
     */
    ServerClientList m_clients;

    /// List with all client ids that should be ignored.
    /**
     * Usually we do not want to listen to the clients anytime
     * but only if the game engine expects it. So you can set
     * from outside when you want to ignore some clients.
     * If the clientId is in the list, the commands of the clients
     * will be processed but no signal will be send to the outside
     * world.
     */
    QList<int> m_ignoreList;

    /// List with all client ids that has not accepted their id yet.
    /**
     * After sending the id to the client it must accept or decline it.
     * If the client sends a signal and he's not in the list, the
     * signal will be ignored.
     */
    QList<int> m_needsIdAcceptionList;

    /// Flag if connections should be accepted or declined.
    /**
     * If true all clients that try to connect will receive a DISCONNECT
     * signal immediately.
     */
    bool m_declineConnections;

    /// The tcp server for the GUI client.
    QTcpServer m_guiServerConnection;

    /// Socket to GUI client.
    QTcpSocket *m_guiClient;

};

#endif // SERVER_HH
