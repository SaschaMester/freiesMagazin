/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "server.hh"
#include "trace.hh"

// Qt
////////
#include <QHostAddress>
#include <QTcpSocket>

// Sys
////////
#include <iostream>

Server::Server()
: m_declineConnections(false), m_guiClient(0)
{
    Trace::print( MTP_SERVER, STP_SERV_STRUCTOR,
                  "Server::Server Start" );

    // connect signal that a new connection should be
    // accepted
    if ( !connect( &m_serverConnection, SIGNAL(newConnection()),
                   this, SLOT(slot_acceptConnection()) ) )
    {
        std::cerr << "(EE) Server::Server "
                  << " Connect not possible!"
                  << std::endl;
    }

    // connect client to server to receive data
    if ( !connect( &m_clients, SIGNAL(sig_receiveData(const QString&,const int)), this, SLOT(slot_receiveData(const QString&,const int)) ) )
    {
        std::cerr << "(EE) Server::Server "
                  << " Connect 1 not possible!"
                  << std::endl;
    }

    // connect client to server when it disconnects
    if ( !connect( &m_clients, SIGNAL(sig_clientDisconnected(const int)), this, SLOT(slot_clientDisconnected(const int)) ) )
    {
        std::cerr << "(EE) Server::Server "
                  << " Connect 2 not possible!"
                  << std::endl;
    }

    // inti gui server
    initGuiServer();

    Trace::print( MTP_SERVER, STP_SERV_STRUCTOR,
                  "Server::Server End" );
}

Server::~Server()
{
    Trace::print( MTP_SERVER, STP_SERV_STRUCTOR,
                  "Server::~Server Start" );

    // stop all connections
    stopListening();

    Trace::print( MTP_SERVER, STP_SERV_STRUCTOR,
                  "Server::~Server End" );
}

// Decline new connections.
void Server::declineNewConnections()
{
    Trace::print( MTP_SERVER, STP_SERV_CONNECTION,
                  "Server::declineNewConnections Start" );

    // disconnect signal that a new connection should be
    // accepted, so we will ignore it
    //disconnect( &m_serverConnection, SIGNAL(newConnection()),
    //            this, SLOT(slot_acceptConnection()) );
    m_declineConnections = true;

    Trace::print( MTP_SERVER, STP_SERV_CONNECTION,
                  "Server::declineNewConnections End" );
}

// Decline all new connections.
void Server::acceptNewConnections()
{
    Trace::print( MTP_SERVER, STP_SERV_CONNECTION,
                  "Server::acceptNewConnections Start" );

    // before we connect the signal, we will disconnect it
    // so we are sure to have no multiple signal-connections
    // declineNewConnections();

    // connect signal that a new connection should be
    // accepted
    //if ( !connect( &m_serverConnection, SIGNAL(newConnection()),
    //               this, SLOT(slot_acceptConnection()) ) )
    //{
    //    std::cerr << "(EE) Server::acceptNewConnections "
    //              << " Connect not possible!"
    //              << std::endl;
    //}
    m_declineConnections = false;

    Trace::print( MTP_SERVER, STP_SERV_CONNECTION,
                  "Server::acceptNewConnections End" );
}
    
// start server so that it listens to connection
bool Server::startListening( const QHostAddress& address, const quint16 port )
{
    Trace::print( MTP_SERVER, STP_SERV_CONNECTION,
                  "Server::startListening Start" );

    bool ok = false;

    // stop all connections if server is already started
    if ( stopListening() )
    {
        // listen again to adress and port
        if ( !m_serverConnection.listen( address, port ) )
        {
            std::cerr << "(EE) Server::startListening "
                      << " Server cannot listen on "
                      << address.toString().toStdString()
                      << ":" << port << "."
                      << std::endl;
        }
        else
        {
#ifdef QT_DEBUG
            std::cout << "(II) Server::startListening "
                      << " Server is listening on "
                      << address.toString().toStdString()
                      << ":" << port << "."
                      << std::endl;
#endif
            ok = true;
        }
    }

    Trace::print( MTP_SERVER, STP_SERV_CONNECTION,
                  "Server::startListening End " + QString::number(ok) );

    return ok;
}

// stop all connections to the server
bool Server::stopListening()
{
    Trace::print( MTP_SERVER, STP_SERV_CONNECTION,
                  "Server::stopListening Start" );

    bool ok = false;

    // check if server is still listing
    if ( m_serverConnection.isListening() )
    {
        // send all clients the command that they should close
        // the connection
        m_clients.sendAll( "DISCONNECT" );

        // close connections
        m_serverConnection.close();

        // send signal to the gui that all clients disconnect
        sendAllGui( "DISCONNECTED" );

        // reset connections to clients
        m_clients.clear();

        // reset parsers
        m_parsers.clear();

        // Clear ignore list.
        m_ignoreList.clear();

        // Clear acception list
        m_needsIdAcceptionList.clear();
        
#ifdef QT_DEBUG
        std::cout << "(II) Server::stopListening "
                  << " Server connection stopped."
                  << std::endl;
#endif
    }

    // check if server is still listening
    if ( m_serverConnection.isListening() )
    {
        // this should not happen
        std::cerr << "(EE) Server::stopListening "
                  << " Server is still listening!"
                  << std::endl;
    }
    else
    {
        ok = true;
    }

    Trace::print( MTP_SERVER, STP_SERV_CONNECTION,
                  "Server::stopListening End " + QString::number(ok) );

    return ok;
}

// Ignore some client or liste to it.
void Server::ignoreClient( const int clientId, const bool ignore )
{
    Trace::print( MTP_SERVER, STP_SERV_CONNECTION,
                  "Server::ignoreClient Start " + QString::number(clientId) + " " + QString::number(ignore) );

    // ignore some client, all data that will be send to the
    // client will not be processed by the server!

    if ( !ignore && m_ignoreList.contains( clientId ) )
    {
        // We do not want to ignore the client anymore
        // and it's in the ignore list.
        m_ignoreList.removeAll( clientId );
    }

    if ( ignore && !m_ignoreList.contains( clientId ) )
    {
        // We do want to ignore the client and it's not
        // in the ignore list yet.
        m_ignoreList.append( clientId );
    }
    
    Trace::print( MTP_SERVER, STP_SERV_CONNECTION,
                  "Server::ignoreClient End" );
}

// Send some data to a client.
bool Server::send( const int clientId, const QString& data, const int msecs )
{
    Trace::print( MTP_SERVER, STP_SERV_SEND,
                  "Server::send Start " + QString::number(clientId) + " " + data );

    const bool ok = m_clients.send( clientId, data, msecs );

    Trace::print( MTP_SERVER, STP_SERV_SEND,
                  "Server::send End " + QString::number(ok) );

    return ok;
}

// Send a PING to all clients we are waiting for.
bool Server::pingWaitingClients()
{
    // No trace points here because we will call this method way too much.

    bool ok = false;

    std::cout << "m_needsIdAcceptionList: " << m_needsIdAcceptionList.count() << std::endl;

    for ( int ii = 0; ii < m_needsIdAcceptionList.count(); ii++ )
    {
        // we do not check if the ping was successfull!
        send( m_needsIdAcceptionList.at(ii), "PING" );
        ok = true;
    }

    // we will also ping the GUI
    sendGui( "PING" );

    return ok;
}

// Send a PING to all clients.
bool Server::pingAllClients()
{
    // No trace points here because we will call this method way too much.

    bool ok = false;

    if ( m_clients.getNumConnectedClients() > 0 )
    {
        m_clients.sendAll( "PING" );
        ok = true;
    }

    // we will also ping the GUI
    sendGui( "PING" );

    return ok;
}
  
// Wait for a new connection.
bool Server::waitForNewConnection( const int msec )
{
    return m_serverConnection.waitForNewConnection( msec );
}

// Wait for a new gui connection.
bool Server::waitForNewGuiConnection( const int msec )
{
    return m_guiServerConnection.waitForNewConnection( msec );
}

// Reset parser so that a new command could be processed.
bool Server::resetParser( const int clientId )
{
    Trace::print( MTP_SERVER, STP_SERV_SET,
                  "Server::resetParser Start " + QString::number(clientId) );

    const bool ok = m_parsers.reset( clientId );

    Trace::print( MTP_SERVER, STP_SERV_SET,
                  "Server::resetParser End " + QString::number(ok) );

    return ok;
}

// accept connection from a client
void Server::slot_acceptConnection()
{
    Trace::print( MTP_SERVER, STP_SERV_CONNECTION,
                  "Server::slot_acceptConnection Start" );

    QTcpSocket* socket = m_serverConnection.nextPendingConnection();

    if ( socket )
    {
        if ( !m_declineConnections )
        {
            // add pending connection to list of clients
            const int clientId = m_clients.add( socket );

            if ( clientId >= 0 )
            {
    #ifdef QT_DEBUG
                std::cout << "(II) Server::slot_acceptConnection "
                          << " New connection " << socket
                          << " for client id "  << clientId
                          << " has been established."
                          << std::endl;
    #endif

                bool ok = false;
                
                // create a parser for the client
                if ( m_parsers.add( clientId ) )
                {
                    // add clientId to acceptions list
                    m_needsIdAcceptionList.append( clientId );

                    // Note: We must first add the client to the list
                    // and then send the ID. Otherwise it's possible
                    // that a client accept its ID before it's inserted
                    // into the m_needsIdAcceptionList and therefor
                    // it will not be recognized by the server as valid
                    // client.

                    // send index to client to identify himself
                    if ( send( clientId, "ID " + QString::number( clientId ) ) )
                    {
                        // Note: The client must accept the ID before
                        // any further data will be sent.

                        ok = true;
                    }
                    else
                    {
                        // sending has failed, remove the ID from
                        // the acception list
                        if ( 0 == m_needsIdAcceptionList.removeAll( clientId ) )
                        {
                            // nothing could be removed?
                            std::cerr << "(EE) Server::slot_acceptConnection "
                                      << " Client id "
                                      << clientId
                                      << " is not found in list."
                                      << std::endl;
                        }
                    }
                }

                if ( !ok )
                {
                    std::cout << "Remove ..." << std::endl;

                    // somehow there was an error
                    // we will remove the client again
                    m_clients.remove( clientId );
                }
            }
        }
        else
        {
            // otherwise we will send a DISCONNECT to the client
            if ( socket->isWritable() )
            {
                const QString data( "DISCONNECT" );
                
                socket->write( (data + "|").toLatin1() );
                
#ifdef QT_DEBUG
                std::cout << "(II) Server::slot_acceptConnection "
                          << " Socket " << socket
                          << " Send \"" << data.toStdString() << "\"."
                          << std::endl;        
#endif

#ifdef QT_DEBUG
                std::cout << "(II) Server::slot_acceptConnection "
                          << " Socket " << socket
                          << " Waiting for " << socket->bytesToWrite()
                          << " Bytes to be written."
                          << std::endl;        
#endif        

                // wait until bytes has been written
                socket->waitForBytesWritten( 1000 );
            }
        }
    }
    else
    {
        // connection pointer is NULL
        std::cerr << "(EE) Server::slot_acceptConnection "
                  << " Connection pointer is NULL!"
                  << std::endl;
    }

    Trace::print( MTP_SERVER, STP_SERV_CONNECTION,
                  "Server::slot_acceptConnection End" );
}

// a client has been disconnected
void Server::slot_clientDisconnected( const int clientId )
{
    Trace::print( MTP_SERVER, STP_SERV_CONNECTION,
                  "Server::slot_clientDisconnected Start " + QString::number(clientId) );

#ifdef QT_DEBUG
    std::cout << "(II) Server::slot_clientDisconnected "
              << " Client " << clientId
              << " disconnected "
              << " sender " << sender()
              << std::endl;
#endif

    // before we send any signals, we check if the client has
    // already disconnected. This could happen!
    if ( m_clients.exists( clientId ) )
    {
        // send command to all clients that this client has disconnected
        // We will of course do not send the signal to the disconnected client
        // and we will not send it to the clients we are still waiting for.
        m_clients.sendAllExcept( "DISCONNECTED " + QString::number(clientId), clientId, m_needsIdAcceptionList );

        // send to gui
        sendGui( "DISCONNECTED "+ QString::number(clientId) );

        // delete client that has disconnected
        m_clients.remove( clientId );

        // delete server parser
        m_parsers.remove( clientId );

        // send signal to outside world
        emit sig_clientDisconnected( clientId );
    }

    Trace::print( MTP_SERVER, STP_SERV_CONNECTION,
                  "Server::slot_clientDisconnected End" );
}

// Receive data from a client connection.
void Server::slot_receiveData( const QString& data, const int clientId )
{
    Trace::print( MTP_SERVER, STP_SERV_RECEIVE,
                  "Server::slot_receiveData Start " + QString::number(clientId) + " " + data );

#ifdef QT_DEBUG
    std::cout << "(II) Server::slot_receiveData "
              << " Received \"" << data.toStdString() << "\""
              << " from " << clientId
              << std::endl;
#endif

    // give the data to the parser
    // so that it can be parsed and split
    if ( m_parsers.separate( data, clientId ) )
    {
        // process all waiting commands
        processCommandQueues();
    }

    Trace::print( MTP_SERVER, STP_SERV_RECEIVE,
                  "Server::slot_receiveData End" );
}

// Process all commands in the process queues.
bool Server::processCommandQueues()
{
    bool ok = true;

    Trace::print( MTP_SERVER, STP_SERV_PROCESS,
                  "Server::processCommandQueues Start" );

    for ( int ii = 0; ii < m_parsers.count(); ii++ )
    {
        const int parserId = m_parsers.getParserId( ii );
        ok = processCommandQueue( parserId ) && ok;
    }

    Trace::print( MTP_SERVER, STP_SERV_PROCESS,
                  "Server::processCommandQueues End " + QString::number(ok) );

    return ok;
}

// Process all commands in the process queue.
bool Server::processCommandQueue( const int parserId )
{
    bool ok = false;

    Trace::print( MTP_SERVER, STP_SERV_PROCESS,
                  "Server::processCommandQueue Start " + QString::number(parserId) );

    // check if queue is processed yet
    // if so, we do not do anything yet and wait for later
    if ( !m_parsers.isProcessed(parserId) )
    {
        Trace::print( MTP_SERVER, STP_SERV_PROCESS,
                      "Server::processCommandQueue Start Queue" );

        if ( m_parsers.setProcessed(parserId, true) )
        {
            while ( !m_parsers.isCommandQueueEmpty(parserId) )
            {
                // the data has been send to the queue
                // so we can process the queue here
                const ServerParserCommand nextCommand = m_parsers.processNextCommand(parserId);

                // process the command
                // that means depending on the command index
                // we will get the data from the parser and copy it
                // to the client.
                if ( !m_ignoreList.contains( parserId ) )
                {
                    // we do not want to ignore the client
                    processCommand( nextCommand, parserId );
                }

                // reset parser data to get the next command
                // even if the command could not be handled
                // correctly
                m_parsers.reset(parserId);
            }

            Trace::print( MTP_SERVER, STP_SERV_PROCESS,
                          "Server::processCommandQueue End Queue" );

            if ( m_parsers.setProcessed(parserId, false) )
            {
                ok = true;
            }
        }
    }

    Trace::print( MTP_SERVER, STP_SERV_PROCESS,
                  "Server::processCommandQueue End " + QString::number(ok) );

    return ok;
}

// Process single command.
void Server::processCommand( const ServerParserCommand command, const int parserId )
{
    Trace::print( MTP_SERVER, STP_SERV_PROCESS,
                  "Server::processCommand Start " + QString::number(parserId) + " " + QString::number(command) );

    switch ( command )
    {
    case SPC_NO_COMMAND:
    case SPC_ERROR:
    case SPC_PING:
    case SPC_ID_OKAY:
        acceptId( parserId );
        break;
    case SPC_ID_NOT_OKAY:
        declineId( parserId );
        break;
    case SPC_MOVE:
        moveClient( parserId );
        break;
    default:
        break;
    }

    Trace::print( MTP_SERVER, STP_SERV_PROCESS,
                  "Server::processCommand End" );
}

// The client has accepted it's id.
void Server::acceptId( const int parserId )
{
    Trace::print( MTP_SERVER, STP_SERV_PROCESS,
                  "Server::acceptId Start " + QString::number(parserId) );

    // check if this client really needs to accept the id
    if ( m_needsIdAcceptionList.contains( parserId ) )
    {
        // we must send the signal to all clients that a new client
        // has accepted it's id
        // We will of course do not send the signal to the connected client
        // and we will not send it to the clients we are still waiting for.
        m_clients.sendAllExcept( "CONNECTED " + QString::number(parserId), parserId, m_needsIdAcceptionList );

        // send to gui
        sendGui( "CONNECTED "+ QString::number(parserId) );

        // send the new client all informations about connected clients
        QList<int> connectedClients;
        m_clients.getConnectedClients( connectedClients );

        // the list could be empty!
        for ( int ii = 0; ii < connectedClients.count(); ii++ )
        {
            // get id of connected client
            const int clientId = connectedClients.at(ii);
            
            // only if the clientId is not the same as the current
            // and we are not waiting for accepting the id of it
            // we may send the ID to the new client
            if ( clientId != parserId &&
                 !m_needsIdAcceptionList.contains( clientId ) )
            {
                m_clients.send( parserId, "CONNECTED " + QString::number(clientId) );
            }
        }

        // send signal to outside world
        emit sig_clientConnected( parserId );

        // remove client id from list because we have it's id
        m_needsIdAcceptionList.removeAll( parserId );
    }
    // else we will ignore the message

    Trace::print( MTP_SERVER, STP_SERV_PROCESS,
                  "Server::acceptId End" );
}

// The client has not accepted it's id.
void Server::declineId( const int parserId )
{
    Trace::print( MTP_SERVER, STP_SERV_PROCESS,
                  "Server::declineId Start " + QString::number(parserId) );

    // check if this client really needs to accept the id
    if ( m_needsIdAcceptionList.contains( parserId ) )
    {
        // The client has not accepted it's id, so we will kick it.

        m_clients.send( parserId, "DISCONNECT" );
        m_clients.remove( parserId );

        // remove client id from list because we have it's id
        m_needsIdAcceptionList.removeAll( parserId );
    }
    // else we will ignore the message

    Trace::print( MTP_SERVER, STP_SERV_PROCESS,
                  "Server::declineId End" );
}

// The client wants to move.
void Server::moveClient( const int parserId )
{
    Trace::print( MTP_SERVER, STP_SERV_PROCESS,
                  "Server::moveClient Start " + QString::number(parserId) );

    // so the client wants to move
    Direction move = DIRECTION_NONE;
    Direction view = DIRECTION_NONE;

    if ( m_parsers.getMovement( move, parserId ) &&
         m_parsers.getView( view, parserId ) )
    {
        // send signal with movement
        emit sig_clientMovement( parserId, move, view );

        // Note: Outside we must check if the movement
        // is valid and a send a signal to the client.
    }
    // else ignore it

    Trace::print( MTP_SERVER, STP_SERV_PROCESS,
                  "Server::moveClient End" );
}

////////////////////////////////
// GUI server
////////////////////////////////

// Init server for GUI client.
void Server::initGuiServer()
{
    Trace::print( MTP_SERVER, STP_SERV_GUI,
                  "Server::initGuiServer Start" );

    // connect signal that a new connection should be
    // accepted
    if ( !connect( &m_guiServerConnection, SIGNAL(newConnection()),
                   this, SLOT(slot_acceptGuiConnection()) ) )
    {
        std::cerr << "(EE) Server::initGuiServer "
                  << " Connect not possible!"
                  << std::endl;
    }

    // listen to GUI to address and port
    const QHostAddress address = QHostAddress::LocalHost;
    const quint16 port = 15001;
    if ( !m_guiServerConnection.listen( address, port ) )
    {
        std::cerr << "(EE) Server::initGuiServer "
                  << " GUI Server cannot listen on "
                  << address.toString().toStdString()
                  << ":" << port << "."
                  << std::endl;
    }
    else
    {
#ifdef QT_DEBUG
        std::cout << "(II) Server::initGuiServer "
                  << " GUI Server is listening on "
                  << address.toString().toStdString()
                  << ":" << port << "."
                  << std::endl;
#endif
    }

    Trace::print( MTP_SERVER, STP_SERV_GUI,
                  "Server::initGuiServer End" );
}

// Send some data to a GUI client.
bool Server::sendGui( const QString& data, const int msecs )
{
    bool ok = false;

    if ( m_guiClient )
    {
        Trace::print( MTP_SERVER, STP_SERV_GUI,
                    "Server::sendGui Start" );

        if ( QAbstractSocket::ConnectedState == m_guiClient->state() )
        {
            if ( m_guiClient->isWritable() )
            {
                m_guiClient->write( (data + "|").toLatin1() );
                
#ifdef QT_DEBUG
                std::cout << "(II) Server::sendGui "
                          << " Socket " << m_guiClient
                          << " Send \"" << data.toStdString() << "\"."
                          << std::endl;        
#endif

#ifdef QT_DEBUG
                std::cout << "(II) Server::sendGui "
                          << " Socket " << m_guiClient
                          << " Waiting for " << m_guiClient->bytesToWrite()
                          << " Bytes to be written."
                          << std::endl;        
#endif        

                // wait until bytes has been written
                ok = m_guiClient->waitForBytesWritten( msecs );
                
#ifdef QT_DEBUG
                std::cout << "(II) Server::sendGui "
                          << " Socket " << m_guiClient
                          << " Bytes written: " << ok << "."
                          << std::endl;        
#endif
            }
            else
            {
                std::cerr << "(EE) Server::sendGui "
                          << " Socket " << m_guiClient
                          << " is not writeable."
                          << std::endl;        
            }
        }
    #ifdef QT_DEBUG
        else
        {
            std::cerr << "(EE) Server::sendGui "
                      << " No connection " << m_guiClient
                      << std::endl;        
        }
    #endif

        Trace::print( MTP_SERVER, STP_SERV_GUI,
                      "Server::sendGui End" );
    }

    return ok;
}

// Send some data to a GUI client.
bool Server::sendAllGui( const QString& data, const int msecs )
{
    bool ok = false;

    if ( m_guiClient )
    {
        Trace::print( MTP_SERVER, STP_SERV_GUI,
                      "Server::sendAllGui Start" );

        ok = true;

        // get list of all client ids.
        QList<int> idList;
        m_clients.getConnectedClients( idList );

        for ( int ii = 0; ii < idList.count(); ii++ )
        {
            ok = sendGui( data + " " + QString::number(idList[ii]), msecs ) && ok;
        }
        
        Trace::print( MTP_SERVER, STP_SERV_GUI,
                      "Server::sendAllGui End" );
    }

    return ok;
}

// accept connection from a gui
void Server::slot_acceptGuiConnection()
{
    Trace::print( MTP_SERVER, STP_SERV_GUI,
                  "Server::slot_acceptGuiConnection Start" );

    QTcpSocket* socket = m_guiServerConnection.nextPendingConnection();

    if ( socket )
    {
        // check if there is already a GUI
        if ( !m_guiClient )
        {
            // set GUI client
            m_guiClient = socket;

            // connect gui client signals to slots

            // check for errors
            if ( !connect( m_guiClient, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(slot_displayError(QAbstractSocket::SocketError)) ) )
            {
                std::cerr << "(EE) Server::slot_acceptGuiConnection  "
                          << " Connect 1 not possible!"
                          << std::endl;
            }

            // signal when the connection is cancelled
            if ( !connect( m_guiClient, SIGNAL(disconnected()), this, SLOT(slot_guiDisconnected()) ) )
            {
                std::cerr << "(EE) Server::slot_acceptGuiConnection "
                          << " Connect 2 not possible!"
                          << std::endl;
            }

            sendAllGui( "CONNECTED" );

            // We must inform the outside application that a new GUI
            // as connected. The application must then send all
            // relevant GUI data.
            emit sig_guiConnected();
        }
        else
        {
            // otherwise we will send a DISCONNECT to the client
            if ( socket->isWritable() )
            {
                const QString data( "DISCONNECT" );
                
                socket->write( (data + "|").toLatin1() );
                
#ifdef QT_DEBUG
                std::cout << "(II) Server::slot_acceptGuiConnection "
                          << " Socket " << socket
                          << " Send \"" << data.toStdString() << "\"."
                          << std::endl;        
#endif

#ifdef QT_DEBUG
                std::cout << "(II) Server::slot_acceptGuiConnection "
                          << " Socket " << socket
                          << " Waiting for " << socket->bytesToWrite()
                          << " Bytes to be written."
                          << std::endl;        
#endif

                // wait until bytes has been written
                socket->waitForBytesWritten( 1000 );
            }
        }
    }
    else
    {
        // connection pointer is NULL
        std::cerr << "(EE) Server::slot_acceptGuiConnection "
                  << " Connection pointer is NULL!"
                  << std::endl;
    }

    Trace::print( MTP_SERVER, STP_SERV_GUI,
                  "Server::slot_acceptGuiConnection End" );
}

// an error occured in the gui connection
void Server::slot_displayError( QAbstractSocket::SocketError socketError )
{
    // ignore closing of connections
    // ignore timeouts 
    if ( QAbstractSocket::RemoteHostClosedError != socketError &&
         QAbstractSocket::SocketTimeoutError    != socketError )
    {
        std::cerr << "(EE) Server::slot_displayError "
                  << " Socket " << m_guiClient
                  << " Error " << socketError
                  << std::endl;
    }
}

// The gui client has been disconnected.
void Server::slot_guiDisconnected()
{
    Trace::print( MTP_SERVER, STP_SERV_GUI,
                  "Server::slot_guiDisconnected Start " );

#ifdef QT_DEBUG
    std::cout << "(II) Server::slot_guiDisconnected "
              << " Disconnected " << m_guiClient
              << std::endl;
#endif

    // delete client
    if ( m_guiClient )
    {
        // do not delete client connection because Qt does take care of it.
        m_guiClient = 0;
    }

    Trace::print( MTP_SERVER, STP_SERV_GUI,
                  "Server::slot_guiDisconnected End " );
}



