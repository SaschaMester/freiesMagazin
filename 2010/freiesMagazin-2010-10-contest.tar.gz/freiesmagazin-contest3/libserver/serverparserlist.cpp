/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "serverparserlist.hh"
#include "serverparser.hh"
#include "trace.hh"

// Sys
////////
#include <iostream>

// Constructor
ServerParserList::ServerParserList()
{
    Trace::print( MTP_SERVERPARSERLIST, STP_SPL_STRUCTOR,
                  "ServerParserList::ServerParserList Start" );

    // nothing to do

    Trace::print( MTP_SERVERPARSERLIST, STP_SPL_STRUCTOR,
                  "ServerParserList::ServerParserList End" );
}
    
// Destructor.
ServerParserList::~ServerParserList()
{
    Trace::print( MTP_SERVERPARSERLIST, STP_SPL_STRUCTOR,
                  "ServerParserList::~ServerParserList Start" );

    clear();

    Trace::print( MTP_SERVERPARSERLIST, STP_SPL_STRUCTOR,
                  "ServerParserList::~ServerParserList End" );
}

/// Delete all elements
void ServerParserList::clear()
{
    Trace::print( MTP_SERVERPARSERLIST, STP_SPL_SET,
                  "ServerParserList::clear Start" );

    // remove all pointers
    while ( !m_list.isEmpty() )
    {
        delete m_list.takeFirst();
    }

    Trace::print( MTP_SERVERPARSERLIST, STP_SPL_SET,
                  "ServerParserList::clear End" );
}

// Create and add new parser.
bool ServerParserList::add( const int parserId )
{
    Trace::print( MTP_SERVERPARSERLIST, STP_SPL_ADDREMOVE,
                  "ServerParserList::add Start" );

    bool ok = true;

    if ( parserId >= 0 )
    {
        // check if parser with such id is already stored
        if ( !contains(parserId) )
        {
            // create new parser
            ServerParser *parser = new ServerParser( parserId );

            if ( parser )
            {
#ifdef QT_DEBUG
                        std::cout << "(II) ServerParserList::add "
                                  << " Add parser " << parserId
                                  << " at index " << m_list.count()
                                  << std::endl;
#endif

                // add it to the list
                m_list.push_back( parser );
                ok = true;
            }
            else
            {
                std::cerr << "(EE) ServerParserList::add "
                          << " Parser for client index "
                          << parserId
                          << " is NULL!"
                          << std::endl;
            }
        }
        else
        {
            std::cerr << "(EE) ServerParserList::add "
                      << " Client index "
                      << parserId
                      << " already stored as parser!"
                      << std::endl;
        }
    }
    else
    {
        std::cerr << "(EE) ServerParserList::add "
                  << " Client index is negative!"
                  << std::endl;
    }

    Trace::print( MTP_SERVERPARSERLIST, STP_SPL_ADDREMOVE,
                  "ServerParserList::add End " + QString::number(ok) );

    return ok;
}

// Remove a parser from the list.
bool ServerParserList::remove( const int parserId )
{
    Trace::print( MTP_SERVERPARSERLIST, STP_SPL_ADDREMOVE,
                  "ServerParserList::remove Start " + QString::number(parserId) );

    bool ok = false;

    // get index in list for this id
    const int index = find(parserId);

    if ( index >= 0 )
    {
#ifdef QT_DEBUG
        std::cout << "(II) ServerParserList::remove "
                  << " Remove parser " << parserId
                  << " at index " << index
                  << std::endl;
#endif

        delete m_list.takeAt(index);
        ok = true;
    }

    Trace::print( MTP_SERVERPARSERLIST, STP_SPL_ADDREMOVE,
                  "ServerParserList::remove End " + QString::number(ok) );

    return ok;
}

/// Reset a parser.
bool ServerParserList::reset( const int parserId )
{
    Trace::print( MTP_SERVERPARSERLIST, STP_SPL_SET,
                  "ServerParserList::reset Start " + QString::number(parserId) );

    bool ok = false;

    // get index in list for this id
    const int index = find(parserId);

    if ( index >= 0 )
    {
        m_list[index]->reset();
        ok = true;
    }

    Trace::print( MTP_SERVERPARSERLIST, STP_SPL_SET,
                  "ServerParserList::reset End " + QString::number(ok) );

    return ok;
}

// Separate data and extract command as new string.
bool ServerParserList::separate( const QString& data, const int parserId,
               const QChar& separator )
{
    bool ok = false;

    // get index in list for this id
    const int index = find(parserId);

    if ( index >= 0 )
    {
        m_list[index]->separate( data, parserId, separator );
        ok = true;
    }

    return ok;
}

// Find a client id in the parser list.
int ServerParserList::find( const int parserId ) const
{
    int index = -1;

    for ( int ii = 0; ii < m_list.count(); ii++ )
    {
        if ( parserId == m_list.at(ii)->getId() )
        {
            index = ii;
            break;
        }
    }

    return index;

}

// Check if parserId is already stored.
int ServerParserList::contains( const int parserId ) const
{
    return ( -1 != find(parserId) );
}
   
// Return stored movement.
bool ServerParserList::getMovement( Direction& move, const int parserId ) const
{
    bool ok = false;

    // get index in list for this id
    const int index = find(parserId);

    if ( index >= 0 )
    {
        move = m_list[index]->getMovement();
        ok = true;
    }

    return ok;
}

// Return stored view.
bool ServerParserList::getView( Direction& view, const int parserId ) const
{
    bool ok = false;

    // get index in list for this id
    const int index = find(parserId);

    if ( index >= 0 )
    {
        view = m_list[index]->getView();
        ok = true;
    }

    return ok;
}

// Return parser id of some parser.
int ServerParserList::getParserId( const int index ) const
{
    int parserId = -1;

    if ( 0 <= index && index < m_list.count() )
    {
        parserId = m_list.at(index)->getId();
    }

    return parserId;
}

// Set flag if processing of commands is active.
bool ServerParserList::setProcessed( const int parserId, const bool active ) const
{
    bool ok = false;

    // get index in list for this id
    const int index = find(parserId);

    if ( 0 <= index )
    {
        m_list[index]->setProcessed(active);
        ok = true;
    }
    
    return ok;
}

// Return true if processing of commands is active.
bool ServerParserList::isProcessed( const int parserId ) const
{
    bool active = false;

    // get index in list for this id
    const int index = find(parserId);

    if ( 0 <= index )
    {
        active = m_list.at(index)->isProcessed();
    }
    
    return active;
}

// Return true if command queue is empty.
bool ServerParserList::isCommandQueueEmpty( const int parserId ) const
{
    bool empty = true;

    // get index in list for this id
    const int index = find(parserId);

    if ( 0 <= index )
    {
        empty = m_list.at(index)->isCommandQueueEmpty();
    }
    
    return empty;
}

// Process next command from command queue.
ServerParserCommand ServerParserList::processNextCommand( const int parserId )
{
    ServerParserCommand command = SPC_NO_COMMAND;

    // get index in list for this id
    const int index = find(parserId);

    if ( 0 <= index )
    {
        command = m_list[index]->processNextCommand();
    }
    
    return command;
}

