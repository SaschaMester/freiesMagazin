/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Own
////////
#include "command.hh"
#include "trace.hh"

// Sys
////////
#include <iostream>

// Constructor.
Command::Command()
: m_command(), m_index(-1)
{
    Trace::print( MTP_COMMAND, STP_COMMAND_STRUCTOR,
                  "Command::Command Start" );
    
    Trace::print( MTP_COMMAND, STP_COMMAND_STRUCTOR,
                  "Command::Command End" );
}

// Constructor
Command::Command( const QString& command, const int index )
: m_command(command), m_index(index)
{
    Trace::print( MTP_COMMAND, STP_COMMAND_STRUCTOR,
                  "Command::Command Start" );
    
    Trace::print( MTP_COMMAND, STP_COMMAND_STRUCTOR,
                  "Command::Command End" );
}

// Set a new command.
bool Command::setCommandAndCheckIndex( const QString& command, const int index )
{
    bool ok = true;

    Trace::print( MTP_COMMAND, STP_COMMAND_SET_ADD,
              "Command::setCommandAndCheckIndex Start " + command + " " + QString::number(index) );
                  
    // check if indices match
    if ( index == m_index )
    {
        m_command = command;
    }
    else
    {
        std::cerr << "(EE) Command::setCommandAndCheckIndex "
                  << " New index " << index
                  << " does not match old index " << m_index
                  << " for command \"" << command.toStdString() << "\""
                  << std::endl;
    }

    Trace::print( MTP_COMMAND, STP_COMMAND_SET_ADD,
              "Command::setCommandAndCheckIndex End " + QString::number((int)ok) );
    
    return ok;
}

// Add a new command to a existing command part.
bool Command::add( const Command& commandToAdd )
{
    bool ok = true;

    Trace::print( MTP_COMMAND, STP_COMMAND_SET_ADD,
              "Command::add Start " + commandToAdd.getCommand() + " " + QString::number(commandToAdd.getIndex())  );
    
    // check if indices match
    if ( commandToAdd.m_index == m_index )
    {
        m_command = commandToAdd.m_command;
    }
    else
    {
        std::cerr << "(EE) Command::add "
                  << " New index " << commandToAdd.m_index
                  << " does not match old index " << m_index
                  << " for command \"" << commandToAdd.m_command.toStdString() << "\""
                  << std::endl;
    }

    Trace::print( MTP_COMMAND, STP_COMMAND_SET_ADD,
              "Command::add End " + QString::number((int)ok)  );
    
    return ok;
}

// Add a new command to a existing command part.
bool Command::add( const QString& command, const int index )
{
    bool ok = true;

    Trace::print( MTP_COMMAND, STP_COMMAND_SET_ADD,
              "Command::add Start " + command + " " + QString::number(index) );
    
    // check if indices match
    if ( index == m_index )
    {
        m_command += command;
    }
    else
    {
        std::cerr << "(EE) Command::add "
                  << " New index " << index
                  << " does not match old index " << m_index
                  << " for command \"" << command.toStdString() << "\""
                  << std::endl;
    }

    Trace::print( MTP_COMMAND, STP_COMMAND_SET_ADD,
              "Command::add End " + QString::number((int)ok) );
    
    return ok;
}
