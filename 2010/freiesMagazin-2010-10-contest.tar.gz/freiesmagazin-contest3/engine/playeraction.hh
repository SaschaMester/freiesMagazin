/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef PLAYERACTION_HH
#define PLAYERACTION_HH

// Own
////////
#include "direction.hh"

/// Player action.
/**
 * This struct will just store some minimal information
 * of an action a layer wants to perform. So we just store
 * some player id, a movement dir and a view dir.
 * Because that are just plain data types, we will not
 * use a class.
 */
struct PlayerAction
{
    /// Index of the player.
    int id;

    /// Movement direction.
    Direction movement;

    /// View direction.
    Direction view;
};

#endif // PLAYERACTION_HH
