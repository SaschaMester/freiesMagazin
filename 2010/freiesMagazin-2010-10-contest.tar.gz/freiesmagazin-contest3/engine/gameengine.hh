/**
    (C) Copyright 2010 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef GAMEENGINE_HH
#define GAMEENGINE_HH

// Own
////////
#include "server.hh"
#include "playerlist.hh"
#include "playeractionlist.hh"
#include "gamemap.hh"
#include "teamchangelist.hh"
#include "fieldlist.hh"
#include "direction.hh"
#include "team.hh"

// Qt
////////
#include <QObject>
#include <QString>
#include <QList>
#include <QFile>

// Forward declarations
//////////////////////////
class Field;
class QHostAddress;
class QPoint;
class QPointF;
class QStringList;

/// Game engine.
/**
 * This game engine holds everything together and handles the game.
 * It contains the server, the map and all players and can start
 * and end each round.
 */
class GameEngine : public QObject
{
Q_OBJECT

public:
    /// Constructor;
    GameEngine();

    /// Destructor.
    ~GameEngine();

    /// Load a map and save it without keys in some file.
    /**
     * @return true if map could be loaded and saved
     */
    bool loadAndSaveMap( const QString& filename );

    /// Start server so that it listens to connection.
    /**
     * @param address server adress for connection
     * @param port port the server listens for new connections
     * @return true if server is listening
     */
    bool startListening( const QHostAddress& address, const quint16 port );

    /// Wait until some number of players are available to start game.
    /**
     * This method will wait until we have enough players to start a
     * game. If there won't be enough players we will never leave the
     * method. So handle with care!
     * @param number Number of players for game.
     * @return true if we have enough players, false in case of an error
     */
    bool waitUntilNumberOfPlayers( const int number );

    /// Start a new game.
    /**
     * Before starting the game, you should have waited for some
     * players with waitUntilNumberOfPlayers(int).
     * @return true if the game ended correctly
     */
    bool startGame();

    /// Wait before new round for pressed key.
    void waitForKeyPressed( const bool wait ) { m_waitForKey = wait; }

    /// Show game information during game like players, moves etc.
    void showGameInfo( const bool show ) { m_showGameInfo = show; }

    /// Set filename for saving game progress to.
    /**
     * We will not store the data received by the clients
     * but the data sent to a possible client!
     */
    bool saveGame( const QString& saveFilename );

private slots:

    /// Add a new player.
    /**
     * A new player has connected to the game.
     * @param playerId Player index.
     */
    void slot_addPlayer( const int playerId );

    /// Remove player.
    /**
     * A player has left the game.
     * @param playerId Removed player.
     */
    void slot_removePlayer( const int playerId );

    /// Move player.
    /**
     * A player wants to move. We will store the movement
     * until all player have moved. Then we will check which
     * movement can be done and inform all players.
     * The movement is only stored if 
     * @param playerId Player index.
     * @param movement The direction in which the player wants to move (even NONE).
     * @param view The direction in which the player wants to look (not NONE).
     */
    void slot_movePlayer( const int playerId, const Direction movement, const Direction view );

    /// The time has run out for the clients to move their player.
    /**
     * If this slot is called, we will end the round and all non
     * move clients will receive a pseudo movement.
     */
    void slot_timesUpForMovement();

    /// Slot that a new gui has connected.
    /**
     * We should send all relevant game data
     * like game map and players to the GUI.
     */
    void slot_guiConnected();

private:

    /// Init a new game.
    /**
     * We will send the used map to all clients. Then we will
     * create random start positions for all players. The team
     * will be set to BLUE for everyone.
     */
    bool initGame();

    /// Set random start position for all players.
    /**
     * This will set a random position for all valid players.
     * @return true if everything is okay
     */
    bool setRandomStartPositions();

    /// Get single random position on empty field on map.
    /**
     * The map should have at least one empty field. Otherwise
     * this method will stay in an endless loop.
     * @param position Position to set.
     */
    void getRandomPositionOnMap( QPoint& position ) const;

    /// Start rounds.
    /**
     * This will be and endless loop until all (valid) players
     * are RED.
     * @return true if everything is okay
     */
    bool startRounds();

    /// Start a new round.
    /**
     * A valid clients will receive the move command. Then a timer
     * is started and we will wait until the timer has run out.
     * All clients that have not move their player will not move.
     * @return true of everything is okay
     */
    bool startNewRound();

    /// Set new life power for each player.
    /**
     * Each player will loose some life energy depending on the
     * toxic value of the field he is standing one. The value will
     * be multiplied with the number of non moved iterations.
     */
    bool setLifeForPlayers();

    /// Check if all players are in one team.
    /**
     * Invalid players will not be checked.
     * @param team The team to check.
     * @return true if all players are in one team
     */
    bool areAllPlayers( const Team team ) const;

    /// Send all team changes to all clients.
    /**
     * The team changes that we have stored will be sent to all
     * valid clients. The sending or the content
     * of the team change list will not be checked, so it should
     * be done before! The list will be cleared after sending.
     * @return true if everything is okay
     */
    bool sendTeamChanges();

    /// Check if players change the team and set the result.
    /**
     * We will check which player stands near the one
     * of the opponent team and is "badly influenced".
     * If noone changes the team, we count it. After some counts
     * one player will automatically change the team.
     * If there is a result we will set it.
     * @return true if everything is okay
     */
    bool checkAndApplyTeamChanges();

    /// Get list of all neighbors of some team to this position.
    /**
     * Neighbored means that the player of the team may only be
     * one field away (in all directions). Doors do not count!
     * @param neighbors List of neighbors at the end.
     * @param pos Position of player.
     * @param team Team of players to check.
     * @return true if list could be calculated
     */
    bool getListOfNeighbors( QList<int>& neighbors, const QPoint& pos, const Team team ) const;

    /// Check if two positions are neighbored.
    /**
     * The absolute difference of both positions must be < 1,1
     * @param targetPos Target position to reach.
     * @param startPos Position to start.
     * @return true if the positions are next to each other
     */
    bool areNeighboredPos( const QPoint& targetPos, const QPoint& startPos ) const;

    /// Move player (position) from start to target by movement direction.
    /**
     * This will NOT move the player, it will just return the reached
     * position after the movement.
     * @param targetPos Target position that will be reached by movement
     * @param startPos Position to start.
     * @param movement Movement direction.
     * @param playerId Id of checked player
     * @param ignoreOtherPlayers If true it's possible that the player
     * stand on a position where another player stands.
     * @return true, if everything is okay
     */
    bool movePosition( QPoint& targetPos, const QPoint& startPos,
                       const Direction movement, const int playerId,
                       const bool ignoreOtherPlayers  ) const;

    /// Move all players depending on the planned moves.
    /**
     * We will move all players in the order of the planned moves.
     * If somethings blocks a movement (like a wall, door, other player)
     * the player is not moved at all.
     * Note: This will only move the players, but will not inform the
     * clients about it.
     * @return true if everything is okay
     */
    bool movePlayers();

    /// Give each player its key.
    /**
     * If a player stands on a field with a key on it, the player
     * will get the key.
     * @return true if everything is okay
     */
    bool setGetKeys();

    /// Get all players with least life.
    /**
     * We will check which players on the map in a specific team
     * has the least life value and return their ids.
     * If there is no player of one team, the list will be empty.
     * @param leastLifePlayers List of player ids.
     * @param team Only players from this team will be checked
     * @return true if everything is okay
     */
    bool getPlayersWithLeastLife( QList<int>& leastLifePlayers, const Team team ) const;

    /// Check if some player is visible from another position.
    /**
     * We will check if the other player faces the correct direction
     * (he has no eyes at it's back) and if no wall or door
     * blocks the view. Also other players can block the view.
     * @param targetPos Position of player that should be looked at
     * @param pos Position of player that should look.
     * @param view Viewing direction of other player.
     * @return true if player is visible by other one
     */
    bool isVisible( const QPoint& targetPos, const QPoint& pos,
                    const Direction view ) const;
                    
    /// Check if target position is possible visible from pos.
    /**
     * A player can only see a 180 degree span in his viewing
     * direction. So we check if the targetPos is in fron of him
     * or behind.
     * @param targetPos One corner of player pos that should be looked at
     * @param pos Middle position of player that should look.
     * @param view Viewing direction of other player.
     * @return true if targetPos is possible visible by other one
     */
    bool isPossibleVisible( const QPointF& targetPos, const QPointF& pos,
                            const Direction view ) const;

    /// Calculate viewing end point.
    /**
     * Calculate the "end point" if we stand on pos and look
     * in direction view. Of course we could see endlessly but we
     * just need some point on this endless viewing line.
     * @param endPoint End point of looking.
     * @param pos Position
     * @param view Viewing direction
     * @return true if everything is okay
     */
    bool calcViewEndPoint( QPointF& endPoint, const QPointF& pos,
                           const Direction view ) const;

    /// Get maximum number of rounds left fot the game.
    /**
     * The maximum number of rounds to go depend on the number
     * of blue players left and the current round. After these rounds
     * all players MUST be converted to the other team.
     * @return number of rounds that will maximally be left
     */
    int getMaxRoundsToGo() const;

    /// Count number of players in some team.
    /**
     * Invalid players will not be counted!
     * @param team Team to check
     * @return number of players in this team
     */
    int getNumPlayersInTeam( const Team team ) const;

    /// Ignore or listen to all clients.
    /**
     * Only before the game starts and when a move round is active
     * we may listen to the clients. Otherwise we may get
     * too much information.
     * @param ignore If true clients will be ignored, else listen to
     */
    void ignoreClients( const bool ignore );

    /// Create string with own movement for sending.
    /**
     * @param playerId Player id of which the position should be sent.
     * @return string with text for sending
     */
    QString createTextForSendingOwnPos( const int playerId ) const;

    /// Create string with movement of other player for sending.
    /**
     * @param playerId Player id of which the position should be sent.
     * @return string with text for sending
     */
    QString createTextForSendingOtherPos( const int playerId ) const;

    /// Create string with key for sending.
    /**
     * @param keyField Visible key to sent.
     * @return string with text for sending
     */
    QString createTextForSendingSeeKey( const Field& keyField ) const;

    /// Create string with key for sending.
    /**
     * @param keyField Get key to sent.
     * @return string with text for sending
     */
    QString createTextForSendingGetKey( const Field& keyField ) const;
    
    /// Create texts with movements of other players for sending.
    /**
     * @param texts Texts with messages to sent.
     * @param playerId Player that should receive messages.
     * @return true if everything is fine.
     */
    bool createTextForSendingPlayers( QStringList& texts, const int playerId ) const;

    /// Create texts which keys are visible for sending.
    /**
     * @param texts Texts with messages to sent.
     * @param keyFields List of keys.
     * @param playerId Player that should receive messages.
     * @return true if everything is fine.
     */
    bool createTextForSendingKeys( QStringList& texts, const FieldList& keyFields,
                                   const int playerId ) const;

    /// Send all necessary data to the clients.
    /**
     * We send the own position, the other positions of the players,
     * the visible keys and the team changes.
     * @return true if everything is okay
     */
    bool sendGameData();

    /// Inform all clients about their own position.
    /**
     * @return true if everything is okay
     */
    bool sendOwnPosition();

    /// Inform all clients about the positions of other players.
    /**
     * Only the positions of players in the same team or visible
     * players will be sent.
     * @return true if everything is okay
     */
    bool sendOtherPositions();

    /// Inform all clients about the positions of the keys.
    /**
     * Only the positions of visible keys will be sent.
     * @return true if everything is okay
     */
    bool sendKeyPositions();

    /// Send current life power to clients.
    /**
     * @return true if everything is okay
     */
    bool sendLifePower();

    /// Send toxic value of player position to clients.
    /**
     * @return true if everything is okay
     */
    bool sendToxicValue();

    /// Print game information at end of game.
    void printGameInfo() const;

    /// Check if some player has the key to a door.
    /**
     * The doorField must be a door field and the player
     * must exists (but not necessarily valid).
     * @param doorField Field with door value.
     * @param playerId Player to check.
     * @return true if player has the right key for that door.
     */
    bool hasPlayerKeyToDoor( const Field& doorField, const int playerId ) const;

    /// Check if movement is diagonal and return the neighbored positions for it.
    /**
     * The method will check if the movement is diagonal (NW, NE,
     * SW, SE) and will then set the neighbored positions when
     * standing on reachedPos after the movement.
     * @param field1 First neighbored field
     * @param field2 Second neighbored field
     * @param reachedPos Reached position after movement.
     * @param movement Move direction
     * @return true if movement is diagonal
     */
    bool isDiagonalMovement( QPoint& field1, QPoint& field2,
                             const QPoint& reachedPos,
                             const Direction movement ) const;

    /// Return true if movement is diagonal and blocked by something.
    bool isBlockedByDiagonalMovement( const QPoint& reachedPos,
                                      const Direction movement,
                                      const QList<QPoint> addBlockedFields,
                                      const int playerId ) const;

private:

    /// The server that handles all client connections.
    Server m_server;

    /// List of all players.
    PlayerList m_players;

    /// List of player ids.
    /**
     * It does cost too much time to get this list for every operation.
     * So we will create the list only one time after the game has
     * begun (it cannot change after this) and use it in every method.
     */
    QList<int> m_playerIds;

    /// Loaded game map.
    GameMap m_map;

    /// Filename of map with keys.
    /**
     * This filename is given to the GUI.
     */
    QString m_mapName;

    /// Filename of map without keys.
    /**
     * This filename is given to all clients that connect so that
     * they can load the map without any keys.
     * Maybe we can set this name later from outside ...
     */
    QString m_mapNameWithoutKeys;

    /// Flag if game has started.
    /**
     * If the game has started, it's not allowed to add players,
     * change the server or the game or anything else at all. ;)
     */
    bool m_gameStarted;

    /// Flag if a round has been started.
    /**
     * If a round has started, we wait until all players have made
     * a movement. If no round has started, we will not recognize
     * such movements.
     */
    bool m_roundStarted;

    /// Number of current round.
    int m_numRounds;

    /// Number of rounds without any team change.
    /**
     * This is important because after several rounds we will
     * change the team for someone to get the game going.
     */
    int m_numRoundsWithoutTeamChange;

    /// List of planned moves of each player.
    /**
     * This list must contain the planned movements at the
     * end of each round.
     * The order of the list is important because first come
     * first serve.
     */
    PlayerActionList m_plannedMoves;

    /// List of team changes.
    /**
     * After the movement we will check which player must
     * change the team. The list will be send to every player
     * because team changes should be known by everybody.
     */
    TeamChangeList m_teamChanges;

    /// Wait before each new round that return is pressed.
    /**
     * For debugging reasons it's helpful if we could start each round
     * by it's own. So if the flag is set we must press ENTER before
     * each round. If you hit 'c' and ENTER the game will not wait
     * anymore.
     * As default it's disabled.
     */
    bool m_waitForKey;

    /// Show game informations during game like players, moves etc.
    /**
     * As default it's disabled.
     */
    bool m_showGameInfo;

    /// File handle for saving game progress during game.
    QFile m_saveGameFile;
};

#endif // GAMEENGINE_HH
