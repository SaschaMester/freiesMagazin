/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "server.hh"
#include "engine.hh"

#include <iostream>
#include <sstream>
#include <cstdlib>

/// Hauptroutine.
/**
 * Dem Server muss jeweils der Eingabe- und Ausgabestroms
 * eines Clients angegeben werden. Die Reihenfolge ist dabei:
 * instream1, outstream1, instream2, outstream2, ...
 * Die Anzahl der Argumente muss daher immer gerade sein,
 * da das erste Argument immer der Programmname selbst ist
 * und das zweite Argument die Anzahl an Runden, die zu spielen sind.
 * Die Idee für die Client-Verarbeitung kam von Frank Staehr:
 * http://www.freiesmagazin.de/mobil/freiesMagazin-2011-03.html
 * @param argc Anzahl der Argumente (immer > 0)
 * @param argv Die einzelnen Argumente.
 */
int main( int argc, char* argv[] )
{
#ifdef DEBUG
    for ( int kk = 0; kk < argc; kk++ )
    {
        std::ostringstream out;
        out << "(DD) main"
                  << " Arg " << kk << ": "
                  << argv[kk]
                  << std::endl;
        std::clog << out.str();
    }
#endif

    // Rueckgabewert 0 = alles okay
    int retValue = 0;
    
    if ( argc >= 2 && argc%2 == 0 )
    {
        // Wir haben eine gerade Anzahl an Argumenten.
        // Das erste Argument ist die Anzahl der Runden,
        // die zu spielen sind.
        const int numRounds = atoi(argv[1]);
        
        // Wir koennen daher davon ausgehen, dass es sich
        // bei den restlichen Argumenten um
        // jeweils einen Eingabe- und Ausgabestrom per Client
        // handelt.
        const int numClients = (argc-2)/2;

#ifdef DEBUG
        std::ostringstream out;
        out << "(DD) main"
                  << " Anzahl Runde: "
                  << numRounds
                  << " Anzahl Clients: "
                  << numClients
                  << std::endl;
        std::clog << out.str();
#endif

        // Erstellt das Server-Objekt, welches die Kommunikation
        // mit den Clients uebernimmt.
        Server server;

        // Erstellt die GameEngine, welche die Verwaltung des
        // Spiels übernimmt.
        // Der Server wird als Referenz uebergeben und die Clients
        // darueber dann von der Engine gesteuert.
        Engine engine( server );

        bool errorOccured = false;

        // extrahiere alle Clients
        for ( int ii = 0; ii < numClients; ii++ )
        {
            // Die Kommunikation mit dem Client findet
            // ueber einen Eingabe- und einen Ausgabestrom statt.
            if ( !server.createAndAddClient( argv[2*ii+2], argv[2*ii+3] ) )
            {
                // Irgendwas ging bei der Erstellung des Clients.
                // Verlasse Schleife.
                errorOccured = true;
                break;
            }
        }

        if ( !errorOccured )
        {
            // Alles okay, das Spiel kann starten.
            if ( engine.startMatch(numRounds) )
            {
                // Gib Spielende mit Ergebnis aus.
                engine.printResults();
            }
            else
            {
                // Ein Fehler sollte schon zuvor ausgegeben worden sein.
                retValue = 3;
            }
        }
        else
        {
            // Ein Fehler sollte schon zuvor ausgegeben worden sein.
            retValue = 2;
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) main"
                  << " Anzahl der Ein- und Ausgabestroeme "
                  << (argc-1)
                  << " muss gerade sein."
                  << std::endl;
        std::cerr << out.str();

        retValue = 1;
    }

#ifdef DEBUG
        std::ostringstream out;
        out << "(DD) main"
                  << " Ende " << retValue
                  << std::endl;
        std::clog << out.str();
#endif

    return retValue;
}
