/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef MESSAGEID_HH
#define MESSAGEID_HH

/// Identifikator einer Nachricht.
enum MessageId
{
    MESSAGE_ID_IGNORE,      // Nachricht soll ignoriert werden.
    MESSAGE_ID_ROUNDS,      // Anzahl der zu spielenden Runden (value ist gesetzt)
    MESSAGE_ID_ACT_ROUND,   // Aktuelle Runde (value ist gesetzt)
    MESSAGE_ID_START,       // Neue Runde starten
    MESSAGE_ID_EXIT,        // Gesamtes Spiel beenden
    MESSAGE_ID_OFFER,       // Angebot des Gegners (value ist gesetzt)
    MESSAGE_ID_ACCEPTED,    // Gegner hat eigenes Angebot angenommen
    MESSAGE_ID_DECLINED,    // Gegner hat eigenes Angebot abgelehnt
    MESSAGE_ID_POINTS,      // Erhaltene Punkte (value ist gesetzt)

    // Neue IDs vor dieser Zeile einfuegen.
    MESSAGE_ID_INVALID
};

#endif // MESSAGEID_HH
