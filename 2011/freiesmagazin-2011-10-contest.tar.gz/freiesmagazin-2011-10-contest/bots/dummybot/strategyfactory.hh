/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef STRATEGYFACTORY_HH
#define STRATEGYFACTORY_HH

#include <string>

// Vorwaertsdeklarationen.
class BaseStrategy;

/// Erstellt eine bestimmte Strategie.
/**
 * Dies ist eine sehr simple Factory, welche eine bestimmte
 * Strategie erstellt, je nachdem welcher String als Identifier
 * uebergeben wird.
 * Die Factory ist dabei so erstellt, dass sie die konkreten
 * Strategien kennt. Eine allgemeine Factory, welche ohen Wissen
 * der konkreten Strategien auskommt, waere natuerlich besser.
 */
class StrategyFactory
{
  public:
    /// Erstellt eine bestimmte Strategie.
    /**
     * @param[in] strategyStr String als Identifikator, welche
     * Strategie erstellt werden soll.
     * @return konkrete Strategie als Basis-Pointer oder 0 bei
     * einem Fehler
     */
    static BaseStrategy* create( const std::string& strategyStr );

    /// Fragt ab, ob eine bestimmte Strategie bekannt ist.
    /**
     * @return true, wenn die Strategie bekannt ist und
     * erstellt werden kann
     */
    static bool isKnownStrategy(  const std::string& strategyStr );

    /// Gibt einen String mit allen moeglichen Strategien samt Hilfetext zurueck.
    /**
     * Die Methode befindet sich in der Factory-Klasse, damit bei
     * einer Erweiterung auf andere Strategien nur die Factory
     * geaendert werden muss und nicht die Ausgabe der Hilfe.
     * @return Hilfetext mit moeglichen Strategien (bereits korrekt
     * formatiert).
     */
    static std::string getStrategyHelp();

private:
    /// Liefert die Anzahl der bekannten Strategien zurueck.
    /**
     * Dies ist die Zahl der Strategiebeschreibungen, die im
     * Array mStrategyDescriptions gespeichert und somit nutzbar sind.
     */
    static int getNumKnownStrategies();

    /// Hilfsklasse fuer die Beschreibung einer Strategie.
    /**
     * Die Klasse enthaelt einen Basis-Pointer auf eine zuvor
     * angelegte Strategie, sowie die Erkennungs-Id zur Erstellung
     * und einen Hilfetext zur Ausgabe.
     */
    struct StrategyDescription
    {
        /// Pointer auf Basisklasse, muss echtes Objekt sein.
        /**
         * Der Pointer wird nicht destruiert und lebt somit solange
         * wie die Anwendung lebt, was auch beabsichtigt ist.
         */
        BaseStrategy* mBaseP;

        /// Erkennungs-Id.
        /**
         * Anhand dieser Id wird beim Aufruf von create entschieden,
         * welche Strategie man wirklich erstellen muss.
         */
        std::string mId;

        /// Hilfstext zur Ausgabe.
        std::string mHelp;
    };

    /// Array mit allen moeglichen Strategien.
    /**
     * Das Array wird in der Implementierung befuellt und muss
     * bei neuen Strategien einfach nur erweitert werden.
     */
    static StrategyDescription mStrategyDescriptions[];
};

#endif // STRATEGYFACTORY_HH
