/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef MESSAGEHANDLER_HH
#define MESSAGEHANDLER_HH

#include "messageid.hh"

#include <string>

/// Klasse zur Verarbeitung der Nachrichten.
/**
 * Die Klasse empfaengt, sendet und verarbeitet Nachrichten.
 * Der Empfang geschieht dabei ueber STDIN, das Senden ueber
 * STDOUT.
 */
class MessageHandler
{
  public:
    /// Empfaengt und prueft eine Nachricht.
    /**
     * @param[out] value Ein optionaler empfangener Wert.
     * @param[in] message Empfangene Nachricht.
     * @return ID der empfangenen Nachricht.
     */
    MessageId getAndCheckMessage( int& value ) const;

    /// Sendet eine Nachricht nach STDOUT.
    /**
     * @param[in] message Zu sendende Nachricht.
     */
    void sendMessage( const std::string& message ) const;

private:

    /// Hole eine Nachricht vom STDIN ab.
    /**
     * @param[out] message Empfangene Nachricht.
     */
    void getMessage( std::string& message ) const;

    /// Prueft eine Nachricht.
    /**
     * @param[out] value Ein optionaler empfangener Wert.
     * @param[in] message Empfangene Nachricht.
     * @return ID der empfangenen Nachricht.
     */
    MessageId checkMessage( int& value, const std::string& message ) const;
};

#endif // MESSAGEHANDLER_HH
