/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "bot.hh"
#include "basestrategy.hh"
#include "strategyfactory.hh"

#include <iostream>
#include <sstream>

int main( int argc, char* argv[] )
{
    int retValue = 0;

    if ( argc == 2 )
    {
        if ( StrategyFactory::isKnownStrategy( argv[1] ) )
        {
            // Das erste Argument gibt die Strategie des Bots an.
            BaseStrategy* strategy = StrategyFactory::create( argv[1] );

            if ( 0 != strategy )
            {
                // Erstelle neuen Bot und setze Strategie.
                Bot bot( strategy );

                // Starte ein neues Spiel.
                if ( !bot.startGame() )
                {
                    retValue = 10;
                }
            }
            else
            {
                std::ostringstream out;
                out << "(EE)"
                          << " Strategie ist 0."
                          << std::endl;
                std::cerr << out.str();
                retValue = 20;
            }
        }
        else
        {
            std::ostringstream out;
            out << "(EE)"
                      << " Strategie '"
                      << argv[1]
                      << "' nicht verstanden."
                      << std::endl;
            std::cerr << out.str();
            retValue = 2;
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE)"
                  << " Genau zwei Argumente erwartet."
                  << std::endl;
        std::cerr << out.str();

        retValue = 1;
    }

    if ( 0 < retValue && retValue < 10 )
    {
        // Sicherheitshalber die Hilfe ausdrucken.
        std::ostringstream out;
        out << "Aufruf:   " << argv[0] << " STRATEGIE" << std::endl
                  << "Beispiel: " << argv[0] << " simple " << std::endl
                  << std::endl;
        out << StrategyFactory::getStrategyHelp();
        std::cerr << out.str();
    }

    if ( 0 != retValue )
    {
        std::ostringstream out;
        out << "(EE)"
                  << " Irgendwo gab es einen Fehler!"
                  << std::endl;
        std::cerr << out.str();
    }
    
    return retValue;
}
