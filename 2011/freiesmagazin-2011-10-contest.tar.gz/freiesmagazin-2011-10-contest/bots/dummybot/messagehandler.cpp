/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "messagehandler.hh"

#include <iostream>
#include <sstream>

// Empfaengt und prueft eine Nachricht.
MessageId MessageHandler::getAndCheckMessage( int& value ) const
{
    // Hole Nachricht ab.
    std::string message;
    getMessage( message );

    // Konvertiere Nachricht in Id und extrahiere ggf. den Wert.
    return checkMessage( value, message );
}

// Hole eine Nachricht vom STDIN ab.
void MessageHandler::getMessage( std::string& message ) const
{
    // Sobald der Bot gestartet wird, wartet er auf eine Eingabe
    // auf STDIN vom Server.
    getline( std::cin, message );

#ifdef DEBUG
    if ( !message.empty() )
    {
        std::ostringstream out;
        out << "(DD) " << this << " MessageHandler::getMessage"
            << " Empfangen: '" << message << "'" << std::endl;
        std::clog << out.str();
    }
#endif // DEBUG
}

// Sendet eine Nachricht nach STDOUT.
void MessageHandler::sendMessage( const std::string& message ) const
{
#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) " << this << " MessageHandler::sendMessage"
        << " Sende: '" << message << "'" << std::endl;
    std::clog << out.str();
#endif // DEBUG

    std::cout << message << std::endl;
}

// Prueft eine Nachricht.
MessageId MessageHandler::checkMessage( int& value, const std::string& message ) const
{
    MessageId id = MESSAGE_ID_INVALID;

    // Provisiorisch den Wert auf 0 setzen.
    value = 0;

    if ( message.compare(0, 6, "RUNDEN") == 0 )
    {
        // Anzahl der zu spielenden Runden
        std::istringstream in( message.substr( 6, std::string::npos ) );
        in >> value;

        id = MESSAGE_ID_ROUNDS;
    }
    else if ( message.compare(0, 5, "RUNDE") == 0 )
    {
        // Aktuelle Runde.
        std::istringstream in( message.substr( 5, std::string::npos ) );
        in >> value;

        id = MESSAGE_ID_ACT_ROUND;
    }
    else if ( message.compare("START") == 0 )
    {
        // Bot soll etwas anbieten (neue Runde).
        id = MESSAGE_ID_START;
    }
    else if ( message.compare("ENDE") == 0 )
    {
        // Bot soll verlassen werden.
        id = MESSAGE_ID_EXIT;
    }
    else if ( message.compare(0, 7, "ANGEBOT") == 0 )
    {
        // Uns wird ein bestimmter Betrag angeboten.
        // Den wandeln wir erst in eine Zahl.
        std::istringstream in( message.substr( 7, std::string::npos ) );
        in >> value;

        id = MESSAGE_ID_OFFER;
    }
    else if ( message.compare(0, 6, "PUNKTE") == 0 )
    {
        // Der Server teilt uns mit, wie viele Punkte wir
        // wirklich erhalten.
        std::istringstream in( message.substr( 6, std::string::npos ) );
        in >> value;

        id = MESSAGE_ID_POINTS;
    }
    else if ( message.compare("JA") == 0 )
    {
        // Angebot wurde angenommen.
        id = MESSAGE_ID_ACCEPTED;
    }
    else if ( message.compare("NEIN") == 0 )
    {
        // Angebot wurde abgelehnt.
        id = MESSAGE_ID_DECLINED;
    }
    else if ( message.empty() )
    {
        // Leerstrings ignorieren wir einfach.
        id = MESSAGE_ID_IGNORE;
    }
    else
    {
        // Kommando nicht verstanden!
        std::ostringstream out;
        out << "(EE) " << this << " MessageHandler::processMessage"
                  << " Befehl '"
                  << message
                  << "' nicht verstanden."
                  << std::endl;
        std::cerr << out.str();
    }

    return id;
}
