/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef BASESTRATEGY_HH
#define BASESTRATEGY_HH

// Vorwaertsdeklarationen.
class BotData;

/// Basisklasse fuer die verschiedenen Strategien.
/**
 * Ueber das Strategy-Pattern kann ein Bot eine bestimmte
 * Strategy zur Laufzeit wechseln, falls seine aktuelle ihm
 * nicht mehr gefaellt. Die konkrete Strategie hat Methoden,
 * um zu entscheiden, welchen Wert man anbietet oder ob man
 * einen angebotenen Wert annimmt.
 */
class BaseStrategy
{
  public:
    /// Konstruktor
    BaseStrategy();

    /// Destructor.
    virtual ~BaseStrategy();

    /// Setzt die aktuellen Daten eines Bots.
    /**
     * Der Pointer auf die Bot-Daten muss gesetzt sein, damit
     * eine konkrete Strategie spaeter darauf zugreifen kann.
     * @param botDataP Pointer auf die Bot-Daten.
     */
    void setBotData( BotData const* botDataP );

  public:
    /// Erstellt eine Kopie des Elements.
    /**
     * Wenn man abgeleitete Klassen von einer Basis-Klasse hat
     * und nur mit einem Pointer auf die Basis-Klasse arbeitet,
     * lassen sich Objekte nicht so einfach per Zuweisung kopieren
     * da man ja die exakte Klassen benötigt. In dem Fall arbeitet
     * man mit einer virtuellen copy-Methode, welche in jeder
     * abgeleiteten Klasse implementiert werden muss.
     * @return Pointer auf die Kopie des Objekt.
     */
    virtual BaseStrategy* copy() const = 0;

    /// Akzeptiert oder lehnt ein Angebot ab.
    /**
     * Die Operation bestimmt, ob der angebotene Wert angenommen wird
     * oder nicht. Der angebotene Wert muss zwischen 0 und 1000 liegen.
     * Die Operation muss von der konkreten Strategie implementiert
     * werden.
     * @param value Der angebotene Wert.
     * @return true, wenn das Angebot angenommen wurde, ansonsten false
     */
    virtual bool acceptOrDeclineOffer( const int value ) = 0;

    /// Berechnet die angebotenen Punkte.
    /**
     * Die Operation berechnet die angebotene Punktzahl. Der
     * Angebotswert muss zwischen 0 und 1000 liegen.
     * Die Operation muss von der konkreten Strategie implementiert
     * werden.
     * @return Wert, den man anbieten will, zwischen 0 und 1000.
     */
    virtual int calculateOfferedPoints() = 0;

protected:

    /// Zustandsdaten des Bots.
    /**
     * Damit die Strategie eine Entscheidung treffen kann, welchen
     * Betrag sie anbietet bzw. ob sie ein Angebot animmt oder ablehnt,
     * benoetigt sie alle relevanten Spieldaten. Diese werden
     * als Zustandsdaten des Bots gehalten.
     * Darin befinden sich Informationen ueber die aktuelle Runde
     * sowie ueber alle Entscheidungen aller vorherigen Runden
     * und natuerlich die aktuellen Punkte.
     * Mit den Daten sollte die Strategie korrekt arbeiten zu
     * koennen. Weitere Daten kann man sich natuerlich in der
     * konkreten Ableitung speichern.
     * Das Attribut ist als const deklariert, damit man nicht
     * "aus Versehen" etwas darin aendert.
     */
    BotData const* mBotDataP;
};

#endif // BASESTRATEGY_HH
