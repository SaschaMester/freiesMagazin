#!/bin/bash

NUMROUNDS=$1

BOTS=( \
        "bots/dummybot/bot simple" \
        "bots/dummybot/bot more" \
        "bots/dummybot/bot random" \
        "bots/dummybot/bot semirandom"
      )

for BOT1 in "${BOTS[@]}"
do
    for BOT2 in "${BOTS[@]}"
    do
        if [ "$BOT1" != "$BOT2" ]
        then
            echo "(II) BOT1: $BOT1   BOT2: $BOT2"
            echo "(II) START `date`"
            ./start.sh $NUMROUNDS "$BOT1" "$BOT2"
            echo "(II) ENDE `date`"
        fi
    done
done



