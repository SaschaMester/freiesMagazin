/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "engine.hh"
#include "server.hh"

#include <iostream>
#include <sstream>
#include <string>
#include <cstdlib>

// Konstruktor
Engine::Engine( Server& server )
: mServerR(server), mNumRounds(0)
{
}

// Destruktor.
Engine::~Engine()
{
}

// Startet ein Match.
bool Engine::startMatch( const int numRounds )
{
    bool retValue = false;

    // Pruefe, ob am Server die korrekte Anzahl von Spieler
    // angemeldet ist.
    if ( 2 == mServerR.getNumClients() )
    {
        if ( 0 < numRounds && numRounds < 100000 )
        {
            // initialisiere Spiel
            if ( initMatch() )
            {
                retValue = true;

                mNumRounds = numRounds;

                // Sende Rundenanzahl an beide Bots.
                std::ostringstream roundStr;
                roundStr << mNumRounds;
                mServerR.send( 0, "RUNDEN " + roundStr.str() );
                mServerR.send( 1, "RUNDEN " + roundStr.str() );

                for ( int ii = 0; ii < mNumRounds; ii++ )
                {
                    if ( !startRound( ii+1 ) )
                    {
                        // Es gab einen Fehler in der Runde.
                        // Wir brechen hier ab.
                        retValue = false;
                        break;
                    }
                }
            }
            // else we already have printed an error
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Engine::startGame"
                      << " Anzahl der Runden "
                      << numRounds
                      << " falsch."
                      << " Wert sollte zwischen 1 und 99999 liegen."
                      << std::endl;
            std::cerr << out.str();
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Engine::startGame"
                  << " Anzahl der angemeldeten Clients "
                  << mServerR.getNumClients()
                  << " falsch. Es werden 2 Spieler erwartet."
                  << std::endl;
        std::cerr << out.str();
    }

    // Das Spiel ist vorbei, sende ENDE an beide Clients.
    // Wir nehmen hier in Kauf, dass die Anzahl vielleicht nicht
    // stimmt oder der String nicht gesendet wird.
    mServerR.send( 0, "ENDE" );
    mServerR.send( 1, "ENDE" );

    return retValue;
}

// Initialisiere Match.
bool Engine::initMatch()
{
    bool retValue = false;

    // Loesche die Liste der aktuellen Spieler
    // (falls welche eingetragen waren).
    mPlayers.clear();

    // Fuege so viele Spieler hinzu, wie es Clients
    // im Server gibt.
    mPlayers.resize( mServerR.getNumClients() );
    retValue = true;

    return retValue;
}

// Starte eine einzelne Runde.
bool Engine::startRound( const int numRound )
{
#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) Engine::startRound"
              << " Runde: " << numRound
              << std::endl;
    std::clog << out.str();
#endif

    // Jede Runde besteht aus zwei separaten Spielen,
    // bei denen einmal Spieler 1 anfaengt und einmal Spieler 2.
    bool retValue = false;

    // Sende Rundenanzahl an beide Bots.
    std::ostringstream roundStr;
    roundStr << numRound;
    mServerR.send( 0, "RUNDE " + roundStr.str() );
    mServerR.send( 1, "RUNDE " + roundStr.str() );

    if (startGame( numRound, 0, 1 ) &&
        startGame( numRound, 1, 0 ) )
    {
        retValue = true;
    }

#ifdef DEBUG
    std::ostringstream out1;
    out1 << "(DD) Engine::startRound"
              << " Ergebnis: " << retValue
              << std::endl;
    std::clog << out1.str();
#endif

    return retValue;
}

// Startet ein einzelnes Spiel
bool Engine::startGame( const int numRound, const int index1, const int index2 )
{
    // In einem Spiel laeuft das wie folgt ab:
    // 1. Sende "START" an Client 1.
    // 2. Empfange Wert von Client 1.
    // 3. Sende Wert an Client 2.
    // 4. Empfange Antwort ("JA" oder "NEIN") von Client 2.
    // 5. Sende Antwort von Client 2 an Client 1.
    // 6. Addiere Punkte zu beiden Spielern.

#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) Engine::startGame"
              << " Runde: " << numRound
              << " Index1: " << index1
              << " Index2: " << index2
              << std::endl;
    std::clog << out.str();
#endif

    bool retValue = false;

    // Frage ersten Spieler nach seinem Angebot und leite
    // dieses an Spieler 2 weiter und sende dessen Antwort
    // an Spieler 1 zurueck.
    int value = 0;
    bool accepted = false;
    if ( receiveValue( value, index1 ) &&
         receiveAnswer( accepted, value, index2 ) &&
         sendAnswer( accepted, index1 ) )
    {
        if ( accepted )
        {
            // Angebot wurde angenommen.
            // Fuege Punkte hinzu.
            if ( addPoints( value, index2 ) &&
                 addPoints( 1000-value, index1 ) )
            {
                retValue = true;
            }
        }
        else
        {
            // Angebot wurde abgelehnt.
            // Beide gehen leer aus.
            if ( addPoints( 0, index2 ) &&
                 addPoints( 0, index1 ) )
            {
                retValue = true;
            }
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Engine::startGame"
                  << " Fehler bei der Bearbeitung!"
                  << std::endl;
        std::cerr << out.str();
    }
#ifdef DEBUG
    std::ostringstream out1;
    out1 << "(DD) Engine::startGame"
              << " Ergebnis: " << retValue
              << std::endl;
    std::clog << out1.str();
#endif
    return retValue;
}

// Empfange Wert nach Spielstart von einem Client.
bool Engine::receiveValue( int& value, const int index )
{
    bool retValue = false;

#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) Engine::receiveValue"
              << " Sende 'START' an Client "
              << index
              << "."
              << std::endl;
    std::clog << out.str();
#endif

    if ( mServerR.send( index, "START" ) )
    {
        // Senden hat geklappt.

        // Empfange Wert
        std::string answer;
        if ( mServerR.receive( index, answer ) )
        {
            // Empfangen hat geklappt

#ifdef DEBUG
            std::ostringstream out;
            out << "(DD) Engine::receiveValue"
                      << " Empfange '"
                      << answer
                      << "' von Client "
                      << index
                      << "."
                      << std::endl;
            std::clog << out.str();
#endif

            // Konvertiere Wert zu Zahl.
            value = atoi( answer.c_str() );

            // Der Wert muss zwischen 0 und 1000 liegen
            // (einschließlich).
            // Wenn er ausserhalb liegt, geben wir eine Warnung
            // aus und setzen den Wert automatisch auf 1000.

            if ( value < 0 || 1000 < value )
            {
                std::ostringstream out;
                out << "(EE) Engine::receiveValue"
                          << " Empfangener Wert "
                          << value
                          << " ausserhalb der Grenzen [0,1000]"
                          << std::endl;
                std::cerr << out.str();

                value = 1000;
            }

            retValue = true;
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Engine::receiveValue"
                      << " Fehler beim Empfangen von Client "
                      << index
                      << std::endl;
            std::clog << out.str();
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Engine::receiveValue"
                  << " Fehler beim Senden an Client "
                  << index
                  << std::endl;
        std::cerr << out.str();
    }

#ifdef DEBUG
    std::ostringstream out1;
    out1 << "(DD) Engine::receiveValue"
              << " Ergebnis: " << retValue
              << std::endl;
    std::clog << out1.str();
#endif

    return retValue;
}

// Sende angebotenen Wert und empfange Antwort von einem Client.
bool Engine::receiveAnswer( bool& accepted, const int value, const int index )
{
    bool retValue = false;

    // Konvertiere Wert in einen String.
    std::ostringstream converter;
    converter << value;
    const std::string message = std::string("ANGEBOT ") + converter.str();

#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) Engine::receiveAnswer"
              << " Sende '"
              << message
              << "' an Client "
              << index
              << "."
              << std::endl;
    std::clog << out.str();
#endif

    if ( mServerR.send( index, message ) )
    {
        // Senden hat geklappt.

        // Empfange Wert
        std::string answer;
        if ( mServerR.receive( index, answer ) )
        {
            // Empfangen hat geklappt
#ifdef DEBUG
            std::ostringstream out;
            out << "(DD) Engine::receiveAnswer"
                      << " Empfange '"
                      << answer
                      << "' von Client "
                      << index
                      << "."
                      << std::endl;
            std::clog << out.str();
#endif

            if ( answer.compare("JA") == 0 ) // || answer == "YES" )
            {
                // Angebot wurde akzeptiert.
                accepted = true;
                retValue = true;
            }
            else if ( answer.compare("NEIN") == 0 ) // || answer == "NO" )
            {
                // Angebot wurde abgelehnt.
                accepted = false;
                retValue = true;
            }
            else
            {
                std::ostringstream out;
                out << "(EE) Engine::receiveAnswer"
                          << " Antwort '"
                          << answer
                          << "' von Client "
                          << index
                          << " nicht verstanden."
                          << std::endl;
                std::cerr << out.str();
            }
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Engine::receiveAnswer"
                      << " Fehler beim Empfangen von Client "
                      << index
                      << std::endl;
            std::clog << out.str();
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Engine::receiveAnswer"
                  << " Fehler beim Senden an Client "
                  << index
                  << std::endl;
        std::cerr << out.str();
    }
    
#ifdef DEBUG
    std::ostringstream out1;
    out1 << "(DD) Engine::receiveAnswer"
              << " Ergebnis: " << retValue
              << std::endl;
    std::clog << out1.str();
#endif

    return retValue;
}

// Sende Antwort zum Angebot des einen Clients zum anderen.
bool Engine::sendAnswer( const bool accepted, const int index )
{
    // Konvertiere Antwort in string.
    std::string answer = "NEIN";
    if ( accepted )
    {
        answer = "JA";
    }

#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) Engine::sendAnswer"
              << " Sende '"
              << answer
              << "' an Client "
              << index
              << "."
              << std::endl;
    std::clog << out.str();
#endif

    const bool retValue = mServerR.send( index, answer );

    if ( !retValue )
    {
        std::ostringstream out;
        out << "(EE) Engine::sendAnswer"
                  << " Fehler beim Senden an Client "
                  << index
                  << std::endl;
        std::cerr << out.str();
    }

#ifdef DEBUG
    std::ostringstream out1;
    out1 << "(DD) Engine::sendAnswer"
              << " Ergebnis: " << retValue
              << std::endl << std::endl;
    std::clog << out1.str();
#endif

    return retValue;    
}

// Sende erhaltene Punkte an Client und addiere diese beim Spieler.
bool Engine::addPoints( const int value, const int index )
{
    // Konvertiere Wert in einen String.
    std::ostringstream converter;
    converter << value;
    const std::string message = std::string("PUNKTE ") + converter.str();

#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) Engine::addPoints"
              << " Sende '"
              << message
              << "' an Client "
              << index
              << "."
              << std::endl;
    std::clog << out.str();
#endif

    // addiere Punkte
    mPlayers[index].addPoints( value );

    const bool retValue = mServerR.send( index, message );

    if ( !retValue )
    {
        std::ostringstream out;
        out << "(EE) Engine::sendAnswer"
                  << " Fehler beim Senden an Client "
                  << index
                  << std::endl;
        std::cerr << out.str();
    }
    
#ifdef DEBUG
    std::ostringstream out1;
    out1 << "(DD) Engine::addPoints"
              << " Ergebnis: " << retValue
              << std::endl;
    std::clog << out1.str();
#endif

    return retValue;    
}

// Gib Spielende mit Ergebnis aus.
void Engine::printResults() const
{
    std::ostringstream out;
    out << "(II)"
              << " Runden: " << mNumRounds
              << " Spieler 1: " << mPlayers[0].getPoints()
              << " Spieler 2: " << mPlayers[1].getPoints()
              << std::endl;
    std::cout << out.str();
}
