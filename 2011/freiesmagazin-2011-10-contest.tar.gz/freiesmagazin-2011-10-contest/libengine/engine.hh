/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef ENGINE_HH
#define ENGINE_HH

#include "player.hh"

#include <vector>
#include <string>

/// Vorwaertsdeklaration
class Server;

/// Basis für eine Spieleengine
class Engine
{
  public:
    /// Konstruktor
    /**
     * @param server Referenz auf Server, der die Kommunikation uebernimmt.
     */
    Engine( Server& server );

    /// Destructor.
    ~Engine();

    /// Startet ein Match.
    /**
     * Dies startet das Match und iteriert die gewuenschte Anzahl
     * an Runden.
     * @param numRounds Anzahl der zu spielenden Runden.
     * @return true, falls das Spiel korrekt beendet wurde.
     */
    bool startMatch( const int numRounds );

    /// Gib Spielende mit Ergebnis aus.
    void printResults() const;

  private:

    /// Initialisiere Match.
    /**
     * Alle Werte werden auf ihren Ursprung gesetzt und ein Match
     * fuer die Anzahl der im Server hinterlegten Spieler
     * erstellt.
     * @return true, falls alles okay ist.
     */
    bool initMatch();

    /// Starte eine einzelne Runde.
    /**
     * @param numRound Die Nummer der aktuellen Runde (sollte > 0 sein).
     * @return true, falls alles okay ist.
     */
    bool startRound( const int numRound );

    /// Startet ein einzelnes Spiel
    /**
     * @param numRound Die Nummer der aktuellen Runde (sollte > 0 sein).
     * @param index1 Index des ersten Spielers.
     * @param index2 Index dex zweiten Spielers.
     * @return true, falls alles okay ist.
     */
    bool startGame( const int numRound, const int index1, const int index2 );

    /// Empfange Wert nach Spielstart von einem Client.
    /**
     * Dies sendet ein Kommando an den Client, damit dieser
     * ein Angebot zwischen 0 und 1000 anbietet. Die Antwort
     * wird danach empfangen.
     * @param[out] value Angebot, das vom Spieler kommt.
     * @param index Index des Clients
     * @return true, falls alles korrekt gesendet/empfangen wurde.
     */
    bool receiveValue( int& value, const int index );

    /// Sende angebotenen Wert und empfange Antwort von einem Client.
    /**
     * Das vom anderen Client abgegebene Gebot wird gesendet und
     * auf eine Antwort (JA oder NEIN) gewartet.
     * @param[out] accepted Ist true, falls das Angebot akzeptiert wurde.
     * @param value Der angebotete Wert vom anderen Client.
     * @param index Index des Clients
     * @return true, falls alles korrekt gesendet/empfangen wurde.
     */
    bool receiveAnswer( bool& accepted, const int value, const int index );

    /// Sende Antwort zum Angebot des einen Clients zum anderen.
    /**
     * Das Angebot vom anderen Client wurde angenommen oder abgelehnt.
     * Die Nachricht soll nur den Client informieren und hat sonst
     * keine Bedeutung.
     * @param accepted Antwort vom anderen Client.
     * @param index Index des Clients
     * @return true, falls alles korrekt gesendet wurde.
     */
    bool sendAnswer( const bool accepted, const int index );

    /// Sende erhaltene Punkte an Client und addiere diese beim Spieler.
    /**
     * Jedem Client wird mitgeteilt, wie viele Punkte er erhaelt.
     * Diese koennten sich das zwar auch selbst ausrechnen, so kann
     * der Client aber besser synchronieren und weiss auch, dass das
     * Spiel hier vorbei ist.
     * @param value Die Punkte, die der Spieler erhaelt.
     * @param index Index des Clients/Spielers.
     * @return true, falls alles korrekt gesendet wurde.
     */
    bool addPoints( const int value, const int index );

  private:

    /// Server, der die Kommunikation uebernimmt.
    /**
     * Der Server muss als Referenz von aussen uebergeben werden.
     */
    Server& mServerR;

    /// Liste der teilnehmenden Spieler.
    /**
     * Die Liste muss genauso gross sein, wie die
     * Liste der im Server registrierten Clients.
     */
    std::vector<Player> mPlayers;

    /// Anzahl der zu spielenden Runden.
    int mNumRounds;

};

#endif // ENGINE_HH
