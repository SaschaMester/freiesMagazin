/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "server.hh"
#include "engine.hh"

#include <iostream>
#include <sstream>
#include <cstdlib>
#include <string>

/// Pruefe die uebergebenen Parameter.
bool checkParameters( int argc, char* argv[], bool& activateLogging )
{
    bool retValue = false;
    activateLogging = false;

    // Wir brauchen mindestens 5 Parameter:
    // 0. Name der Binaerdatei
    // 1. Anzahl Runden
    // 2.-5 Clientdaten

    if ( argc >= 5 )
    {
        // Die Anzahl der Parameter-2 muss durch 3 mit Rest 0 oder 1
        // teilbar sein.
        if ( (argc-2)%3 == 0 )
        {
            // alles okay
            retValue = true;
        }
        else if ( (argc-2)%3 == 1 )
        {
            // Das letzte Argument muss das optionale "--rlog" sein.
            if ( std::string( argv[argc-1] ) == "--rlog" )
            {
                retValue = true;
                activateLogging = true;
            }
        }
    }

    return retValue;
}

/// Hauptroutine.
/**
 * Dem Server muss jeweils der Eingabe- und Ausgabestroms
 * eines Clients angegeben werden. Die Reihenfolge ist dabei:
 * instream1, outstream1, name1, instream2, outstream2, name2, ...
 * Die Idee für die Client-Verarbeitung kam von Frank Staehr:
 * http://www.freiesmagazin.de/mobil/freiesMagazin-2011-03.html
 * @param argc Anzahl der Argumente (immer > 0)
 * @param argv Die einzelnen Argumente.
 */
int main( int argc, char* argv[] )
{
#ifdef DEBUG
    for ( int kk = 0; kk < argc; kk++ )
    {
        std::ostringstream out;
        out << "(DD) main"
                  << " Arg " << kk << ": "
                  << argv[kk]
                  << std::endl;
        std::clog << out.str();
    }
#endif

    // Rueckgabewert 0 = alles okay
    int retValue = 0;

    bool activateRLog = false;
    if ( checkParameters(argc, argv, activateRLog) )
    {
        if ( activateRLog )
        {
            argc--;
        }

        // Das erste Argument ist die Anzahl der Runden,
        // die zu spielen sind.
        const int numRounds = atoi(argv[1]);

        // Wir koennen daher davon ausgehen, dass es sich
        // bei den restlichen Argumenten um
        // jeweils einen Eingabe-, Ausgabestrom und Name
        // per Client handelt.
        const int numClients = (argc-2)/3;

#ifdef DEBUG
        std::ostringstream out;
        out << "(DD) main"
                  << " Anzahl Runde: "
                  << numRounds
                  << " Anzahl Clients: "
                  << numClients
                  << std::endl;
        std::clog << out.str();
#endif

        // Erstellt das Server-Objekt, welches die Kommunikation
        // mit den Clients uebernimmt.
        Server server;

        // Erstellt die GameEngine, welche die Verwaltung des
        // Spiels übernimmt.
        // Der Server wird als Referenz uebergeben und die Clients
        // darueber dann von der Engine gesteuert.
        Engine engine( server );
        engine.activateRLogging( activateRLog );

        bool errorOccured = false;

        // extrahiere alle Clients
        for ( int ii = 0; ii < numClients; ii++ )
        {
            // Die Kommunikation mit dem Client findet
            // ueber einen Eingabe- und einen Ausgabestrom statt.
            if ( !server.createAndAddClient( argv[3*ii+2], argv[3*ii+3], argv[3*ii+4] ) )
            {
                // Irgendwas ging bei der Erstellung des Clients.
                // Verlasse Schleife.
                errorOccured = true;
                break;
            }
        }

        if ( !errorOccured )
        {
            // Alles okay, das Spiel kann starten.
            if ( engine.startMatch(numRounds) )
            {
                // Gib Spielende mit Ergebnis aus.
                engine.printResults();
            }
            else
            {
                // Ein Fehler sollte schon zuvor ausgegeben worden sein.
                retValue = 3;
            }
        }
        else
        {
            // Ein Fehler sollte schon zuvor ausgegeben worden sein.
            retValue = 2;
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) main"
                  << " Anzahl der Argumente "
                  << (argc-1)
                  << " ist nicht korrekt."
                  << std::endl;
        std::cerr << out.str();

        retValue = 1;
    }

#ifdef DEBUG
        std::ostringstream out;
        out << "(DD) main"
                  << " Ende " << retValue
                  << std::endl;
        std::clog << out.str();
#endif

    return retValue;
}
