#!/bin/bash

# Aufruf:
# ./start.sh RUNDEN BOT1 BOT2

if [ ! $# -eq 3 ]
then
    if [ ! $# -eq 4 ]
    then
        echo "Fehler: Es werden drei oder vier Argumente erwartet!"
        echo "Aufruf:   $0 RUNDEN BOT1 BOT2 [--rlog]"
        echo "Beispiel: $0 2500 \"bots/dummybot/bot simple\" \"bots/dummybot/bot random\" --rlog"
        exit 1
    fi
fi

RUNDEN=$1
BOT1=$2
BOT2=$3
RLOG=
if [ $# -eq 4 ]
then
    RLOG=$4
fi

#RAWBOT1=`echo "$BOT1" | awk '{ print $1 }'`
#RAWBOT2=`echo "$BOT2" | awk '{ print $1 }'`

# Pruefe, ob die Bots existieren
#if [ ! -e $RAWBOT1 ]
#then
#    echo "Fehler: Bot1 '$RAWBOT1' existiert nicht!"
#    exit 2
#fi
#if [ ! -e $RAWBOT2 ]
#then
#    echo "Fehler: Bot2 '$RAWBOT2' existiert nicht!"
#    exit 2
#fi

# Loesche alte Pipes (wirklich nur Pipes)
if [ -p pipe1 ]
then
    rm pipe1 || exit $?
fi
if [ -p pipe2 ]
then
    rm pipe2 || exit $?
fi

# Erstelle neue Pipes
mkfifo pipe1 pipe2 || exit $?

# Pipes muessen nun existieren
if [ ! -p pipe1 ]
then
    echo "Fehler: Pipe 1 existieren nicht!"
    exit 3
fi
if [ ! -p pipe2 ]
then
    echo "Fehler: Pipe 2 existieren nicht!"
    exit 3
fi

# Starte Match
if [ "$RLOG" = "--rlog" ]
then
    ./game.bin $RUNDEN <(<pipe1 $BOT1) pipe1 "$BOT1" <(<pipe2 $BOT2) pipe2 "$BOT2" "$RLOG" || exit $?
else
    ./game.bin $RUNDEN <(<pipe1 $BOT1) pipe1 "$BOT1" <(<pipe2 $BOT2) pipe2 "$BOT2" || exit $?
fi
