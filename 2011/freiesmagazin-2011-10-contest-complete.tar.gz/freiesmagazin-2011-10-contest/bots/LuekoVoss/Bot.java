/**
 * Ultimatum-Gamebot, This is a Bot that can play the Ultimatum game.
 * Copyright (C) 2011  Lüko Voß
 * 
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by the 
 * Free Software Foundation; either version 3 of the License, or 
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License 
 * for more details.
 * 
 * You should have received a copy of the GNU General Public License along 
 * with this program; if not, see <http://www.gnu.org/licenses/>.
 */

import java.io.*;
import java.util.Random;

public class Bot {

    private BufferedReader reader = new BufferedReader(new InputStreamReader(
	    System.in));

    // das W hinter den Variablen bedeutet: Wert
    // Anzahl der zu spielenden Runden
    private int roundsW = 2500;
    // aktuelle Runde
    private int roundW;
    // mein Angebot an den Gegner
    private int myOfferW = 200;
    // das Angebot vom Gegner
    private int offerW;
    // Punkte die man in der aktuellen Runde gewonnen hat
    private int rPointsW;
    // Gesamtpunktzahl
    private int pointsW;

    /*
     * Zum Überprüfen des eingelesenen Kommandos.
     */
    private final String rounds = "RUNDEN";
    private final String round = "RUNDE";
    private final String offer = "ANGEBOT";
    private final String rPoints = "PUNKTE";
    private final String start = "START";
    private final String end = "ENDE";
    private final String yes = "JA";
    private final String no = "NEIN";

    private String commando = "";
    
    private int strategy = 1;
    private boolean yesOrNo = false;
    private Random random = new Random();
    private int noNum;

    /*
     * Ließt die aktuelle Zeile in der Konsole und gibt sie zurück.
     */
    public String getInput() {
	try {
	    return reader.readLine();
	} catch (IOException ex) {
	    return ex.getMessage();
	}
    }

    /*
     * Berechnet das Angebot, welches man dem Gegner vorschlagen will.
     */
    public int myOffer() {
	if (noNum >= 5 && myOfferW < 400) {
	    myOfferW += 20;
	    noNum = 0;
	}
	return myOfferW;
    }

    /*
     * Die erste Strategie.
     */
    public boolean firstS(int offer) {
	if (offer >= 250 || random.nextInt(100) == 5) {
	    if (offer < 300 && random.nextInt(10) != 5) {
		return true;
	    } else if (offer >= 350) {
		return true;
	    } else {
		return false;
	    }
	} else {
	    return false;
	}
    }

    //Die zweite Strategie.
    public boolean secondS(int offer) {
	if (offer >= 200) {
	    return true;
	} else {
	    return false;
	}
    }

    /*
     * Setzt die verschiedenen Strategien.
     */
    public void setStrategy() {
//	if (roundW >= roundsW / 2 && pointsW <= roundsW * 500) {
//	    if (strategy == 1) {
//		strategy = 2;
//	    } else {
//		strategy = 1;
//	    }
//	}
	if (random.nextInt(3) != 1) {
	    strategy = 1;
	} else {
	    strategy = 2;
	}
    }
    
    /*
     * Entscheidet über die Annahme des angebotenen Wertes vom Gegner.
     */
    public boolean makeOffer(int offer) {
	setStrategy();
	switch (strategy) {
	    case 1:
		yesOrNo = firstS(offer);
		break;
	    case 2:
		yesOrNo = secondS(offer);
		break;
	}
	return yesOrNo;
    }

    /*
     * In diesem Teil des Programmabschnittes wird festgelegt was gemacht
     * werden muss. Hier werden die eingehenden Befehle verarbeitet und
     * ausgehende Kommandos verschickt. Das Programm wird geschlossen, sobald
     * die Schleife zuende ist oder der Befehl "ENDE" eingelesen wurde.
     */
    public void starteSchleife() {
	commando = getInput();
	while (roundW != roundsW + 1) {
	    String[] words = commando.split(" ");
	    if (words[0].compareTo(yes) == 0) {
	    } else if (words[0].compareTo(no) == 0) {
		noNum++;
	    } else if (words[0].compareTo(end) == 0) {
		System.exit(0);
	    } else if (words[0].compareTo(round) == 0) {
		roundW = Integer.parseInt(words[1]);
	    } else if (words[0].compareTo(start) == 0) {
		System.out.println(myOffer());
	    } else if (words[0].compareTo(rounds) == 0) {
		roundsW = Integer.parseInt(words[1]);
	    } else if (words[0].compareTo(rPoints) == 0) {
		rPointsW = Integer.parseInt(words[1]);
		pointsW += rPointsW;
	    } else if (words[0].compareTo(offer) == 0) {
		offerW = Integer.parseInt(words[1]);
		if (makeOffer(offerW)) {
		    System.out.println(yes);
		} else {
		    System.out.println(no);
		}
	    }
	    System.out.flush();
	    commando = getInput();
	}
    }

    /*
     * Erzeugt automatisch ein Objekt vom Typ Bot und startet die Schleife.
     */
    public static void main(String[] args) {
	Bot bot = new Bot();
	bot.starteSchleife();
    }
}
