/*
 *  Copyright (C) 2011  Jan Bastian

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>. 
 */

import java.io.BufferedReader;  
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class Bot {
	
	private final int LIMIT			= 1000;

	private int maxRound			= -1;
	private int currentRound		= -1;	
	private int pointsBot			=  0;
	private int pointsOpponent		=  0;

	private BufferedReader reader	= null;
	private BufferedWriter writer	= null;	
	
	private int minValue			= 250;
	private int maxValue			= 499;
	private int lastValue			= -1;
	private String lastAnswer		= "";
	
	public Bot(){
		reader	= new BufferedReader(new InputStreamReader(System.in));
		writer	= new BufferedWriter(new OutputStreamWriter(System.out));
		lastValue	= minValue;
	}
	
	/**
	 * 
	 * @param message
	 */
	private void writeMessage(String message){		
		try {
			writer.write(message);
			writer.newLine();
			writer.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	/**
	 * 
	 * @return
	 */
	private String readMessage(){
		String message	= "";
		
		try {
			message	 = reader.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return message;
	}
	
	/**
	 * 
	 * @param offer
	 * @return
	 */
	private String readOffer(int offer){
		
		lastValue		= offer;
		
		if (offer <  minValue){
			return "NEIN";			
		}else{
			return "JA";
		}
	}
	
	/**
	 * 
	 * @return
	 */
	private int sendOffer(){
		
		if (lastAnswer.equals("")== true){
			return minValue;
		}
		
		if (lastAnswer.equals("JA")){
			return lastValue;
		}else{
			if (minValue < maxValue){
				minValue++;
			}
			lastValue	= minValue;				
		}		
		
		return lastValue;
	}
	
	/**
	 * 
	 * @return
	 */
	private int getMinValue(){
		return 250	+ currentRound;
	}
	
	/**
	 * 
	 */
	public void startBot(){
		String message		= "";
		String msgArray[]	= null;
		boolean stopBot		= false;
		
		while (stopBot == false){
			message		= readMessage();
			msgArray	= message.split(" ");
			
			// parse the message
			if (msgArray.length >= 1){
				
				if (msgArray[0].equals("RUNDEN")){
					// read max round
					maxRound		= Integer.parseInt(msgArray[1]);			
				}
				
				if (msgArray[0].equals("RUNDE")){
					// read current round
					currentRound	= Integer.parseInt(msgArray[1]);
				}
				
				if (msgArray[0].equals("START")){
					// read the offer
					writeMessage(Integer.toString(sendOffer()));	
				}
				
				if (msgArray[0].equals("ANGEBOT")){
					// send an offer
					writeMessage(readOffer(Integer.parseInt(msgArray[1])));
					
				}
				
				if (msgArray[0].equals("JA")){
					lastAnswer	= "JA";
					
					if (currentRound < 250){
						minValue	= getMinValue();	
					}					
				}
				
				if (msgArray[0].equals("NEIN")){
					lastAnswer	= "NEIN";
				}
				
				if (msgArray[0].equals("PUNKTE")){
					
					int tmpValue	= Integer.parseInt(msgArray[1]);
					if (tmpValue > 0){
						pointsBot		+= tmpValue;
						pointsOpponent 	+= LIMIT - tmpValue;	
					}
				}
				
				if (msgArray[0].equals("ENDE")){
					stopBot	= true;
				}			
			}
		}
	}
	
	public static void main(String arg[]){
		Bot b 	= new Bot();
		b.startBot();

	}	
}

