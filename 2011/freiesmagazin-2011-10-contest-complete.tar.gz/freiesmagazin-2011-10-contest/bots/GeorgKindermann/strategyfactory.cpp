/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "strategyfactory.hh"
#include "basestrategy.hh"
#include "gkstrategy.hh"

#include <iostream>
#include <sstream>

// Array mit allen moeglichen Strategien.
// Hier kann man einfach neue am Anfang einfuegen.
StrategyFactory::StrategyDescription StrategyFactory::mStrategyDescriptions[] =
{
    { new GKStrategy(), "gk", "Angebot: fair; Annahme: fair" }
};

// Erstellt eine bestimmte Strategie.
// static
BaseStrategy* StrategyFactory::create( const std::string& strategyStr )
{
#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) StrategyFactory::create"
        << " Strategie: '" << strategyStr << "'" << std::endl;
    std::clog << out.str();
#endif // DEBUG

    BaseStrategy* strategyP = 0;

    if ( isKnownStrategy( strategyStr ) )
    {
        for ( int ii = 0; ii < getNumKnownStrategies(); ii++ )
        {
            if ( strategyStr.compare( mStrategyDescriptions[ii].mId ) == 0 )
            {
                // Achtung: Wir duerfen nicht einfach den Pointer
                // kopieren, da wir sonst immer das gleiche Objekt
                // nach aussen geben wuerden. Daher muessen wir ein
                // komplett neues Objekt erstellen.
                if ( mStrategyDescriptions[ii].mBaseP )
                {
                    strategyP = mStrategyDescriptions[ii].mBaseP->copy();
                }
                else
                {
                    std::ostringstream out;
                    out << "(EE) StrategyFactory::create"
                              << " Strategie-Basis-Pointer ist 0."
                              << std::endl;
                    std::cerr << out.str();
                }
                break;
            }
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) StrategyFactory::create"
                  << " Strategie '"
                  << strategyStr
                  << "' nicht verstanden."
                  << std::endl;
        std::cerr << out.str();
    }

    return strategyP;
}

// Fragt ab, ob eine bestimmte Strategie bekannt ist.
bool StrategyFactory::isKnownStrategy(  const std::string& strategyStr )
{
    bool ok = false;

    // Id suchen.
    for ( int ii = 0; ii < getNumKnownStrategies(); ii++ )
    {
        if ( strategyStr.compare( mStrategyDescriptions[ii].mId ) == 0 )
        {
            // Element gefunden.
            ok = true;
            break;
        }
    }

    return ok;
}

// Gibt einen String mit allen moeglichen Strategien samt Hilfetext zurueck.
// static
std::string StrategyFactory::getStrategyHelp()
{
    std::ostringstream out;

    out << "Gueltige Strategien: " << std::endl;

    int width = 0;

    // Zuerst das groesste Elemente wegen Ausrichtung finden.
    for ( int ii = 0; ii < getNumKnownStrategies(); ii++ )
    {
        const int sizeOfElement = mStrategyDescriptions[ii].mId.size();
        if ( sizeOfElement > width )
        {
            width = sizeOfElement;
        }
    }

    // 4 Zeichen fuer Abstand addieren.
    width += 4;

    // Jetzt die einzelnen Werte ausgeben.
    for ( int ii = 0; ii < getNumKnownStrategies(); ii++ )
    {
        const int sizeOfElement = mStrategyDescriptions[ii].mId.size();

        // Richtige Anzahl an Leerzeichen ausgeben.
        const int numSpaces = width - sizeOfElement;
        for ( int jj = 0; jj < numSpaces; jj++ )
        {
            out << " ";
        }

        // Id und Hilfe ausgeben.
        out << mStrategyDescriptions[ii].mId
            << " - " << mStrategyDescriptions[ii].mHelp
            << std::endl;
    }

    return out.str();
}

// Liefert die Anzahl der bekannten Strategien zurueck.
int StrategyFactory::getNumKnownStrategies()
{
    return ( sizeof( mStrategyDescriptions) / sizeof(StrategyDescription) );
}
