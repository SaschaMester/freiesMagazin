/**
    (C) Copyright 2011 Dominik Wagenfuehr, Georg Kindermann

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "gkstrategy.hh"
#include <cmath>
#include <cstdlib>
#include <ctime>

// Konstruktor
GKStrategy::GKStrategy() :
BaseStrategy(), lastOfferOther(0),
  lastofferOtherWasAcceped(true), totalBilanz(0),
  stage(0), roundsToHandover(2), lastTargetProfit(0),
  maxProfit(1000), baseline(0), myOfferWasNeverAccepted(true),
stopperMyOffer(0), myOfferRejectionInARow(0), playerMode(false)
{
  srand(time(0));  //Zufallszahlen initialisieren
  for(int i=0; i<498; ++i) {
    stopper0[i] = 0; stopper1[i] = 0;
  }
  for(int i=0; i<2001; ++i) {profit[i] = 0;
    maxNtimesThisLevel[i] = 3;}
  nextOfferMe = 167 + rand()%334;
  lastOfferMe = nextOfferMe;
  nTimesToFollow = rand()%7;
}

// Destructor.
GKStrategy::~GKStrategy()
{
}

// Erstellt eine Kopie des Elements.
BaseStrategy* GKStrategy::copy() const
{
    return (BaseStrategy*)(new GKStrategy(*this));
}

// Akzeptiert oder lehnt ein Angebot ab.
bool GKStrategy::acceptOrDeclineOffer( const int offerOther )
{
  bool acceptOffer = false;
  bool adaptOffer=true;
  if(offerOther < lastOfferMe && offerOther < lastOfferOther && nTimesToFollow < 1 && playerMode==false) {
    int decide = (offerOther + rand()%501)/2;
    if(decide > 333) {playerMode=true;}
    else if(decide > 166) {nTimesToFollow = 1;}
  }
  int bilanzMe = 0;
  if(mBotDataP->wasMyLastOfferWasAccepted()) {bilanzMe = 500-lastOfferMe;}
  totalBilanz += bilanzMe;
  int bilanzOther0 = 0;
  if(lastofferOtherWasAcceped) {bilanzOther0 = lastOfferOther-500;}
  int bilanzOther1 = offerOther-500;
  if(mBotDataP->wasMyLastOfferWasAccepted()) {myOfferRejectionInARow=0;
  } else if(lastOfferMe < lastOfferOther) {++myOfferRejectionInARow;}
  if(myOfferRejectionInARow > 13) {stage=0;
    myOfferRejectionInARow=0;
    roundsToHandover=2;}
  if(offerOther > 0) {
    if(stage==0 && playerMode==false) { //Starter
      int minOfferOther = 40+rand()%250;
      if((bilanzMe+bilanzOther0 > -4 || bilanzMe+bilanzOther1 > -4 ||
	  totalBilanz > -1) && offerOther >= minOfferOther) {
	acceptOffer=true;}
      if(offerOther < minOfferOther) {nextOfferMe = minOfferOther;
      } else {nextOfferMe = offerOther;}
      --roundsToHandover;
      if(roundsToHandover<1) {stage=1; roundsToHandover=rand()%33;
      } else {adaptOffer=false;}
    } else { //Worker
      if(myOfferWasNeverAccepted && mBotDataP->wasMyLastOfferWasAccepted()) {
	myOfferWasNeverAccepted=false;}
      int bilanz = bilanzMe + bilanzOther1;
      if(bilanz < 0) {
	if(totalBilanz > -1 && offerOther > 84+rand()%167) {acceptOffer=true;
	} else if(playerMode==false && nTimesToFollow > 0 && 
		  (bilanz + rand()%20 > 0 || offerOther > 84 + rand()%167) ) {
	  acceptOffer=true;
	  nextOfferMe = offerOther;
	  adaptOffer=false;
	  --nTimesToFollow;
	} else {
	  int index = -1 -bilanz;
	  if(bilanzMe < 0) {index += bilanzMe;}
	  if(index > 497) {index = 497;}
	  if(index > -1) {
	    stopper0[index] -= index+1;
	    stopper1[index] -= index+1;
	    if(stopper0[index] > 0) {acceptOffer=true;
	    } else {
	      stopper0[index] += rand()%(1333/(index+1));
	      if(stopper1[index] > 0) {acceptOffer=true;
	      } else {stopper1[index] += rand()%(1333/(index+1));}
	    }
	  }
	}
      } else {
	acceptOffer=true;
	if(bilanz > 20 && nextOfferMe > -7) {nextOfferMe -= 7;
	  adaptOffer = false;}
      }
      if(!myOfferWasNeverAccepted) {--roundsToHandover;}
      if(roundsToHandover<1 && nextOfferMe>0 && acceptOffer == true &&
	 lastofferOtherWasAcceped == true && playerMode == false &&
	 mBotDataP->wasMyLastOfferWasAccepted()== true) {playerMode=true;
	if(bilanz > -1) {baseline=bilanz; lastTargetProfit=bilanz+1;
	} else {baseline=0; lastTargetProfit=1;}
      }
    }
  }
  if(playerMode) { //Player
    if(lastTargetProfit < -1000) {lastTargetProfit = -1000;}
    if(lastTargetProfit > 1000) {lastTargetProfit = 1000;}
    int targetProfit = lastTargetProfit;
    int bilanz = bilanzMe + bilanzOther1;
    int gvk = -1000;
    if(mBotDataP->wasMyLastOfferWasAccepted()) {gvk += 1000-lastOfferMe;}
    if(acceptOffer) {gvk += offerOther;}
    profit[1000+lastTargetProfit] += gvk;
    if(bilanz <= 0) {--maxNtimesThisLevel[1000+lastTargetProfit];}
    if(maxNtimesThisLevel[1000+lastTargetProfit] < 0 ||
       profit[1000+lastTargetProfit] < -1000) {maxProfit = targetProfit-1;
    } else if(profit[1000+lastTargetProfit] > 0) {++targetProfit;}
    if(targetProfit > offerOther) {targetProfit = offerOther;}
    if(targetProfit > maxProfit) {targetProfit = maxProfit;}
    nextOfferMe = offerOther - targetProfit;
    if(nextOfferMe > 500) {nextOfferMe = 500;}
    lastTargetProfit = targetProfit;
    adaptOffer=false;
    if(targetProfit < baseline) {playerMode = false;
      nextOfferMe = offerOther;
      if(stage==0) {roundsToHandover = 2;
      } else {roundsToHandover=mBotDataP->getNumRounds();}
      nTimesToFollow = rand()%4;
      maxProfit = 1000; lastTargetProfit=1; baseline=0;
      for(int i=0; i<2001; ++i) {profit[i] = 0; maxNtimesThisLevel[i] = 3;}
    }
  }
  if(adaptOffer && mBotDataP->wasMyLastOfferWasAccepted()==false) {
    ++nextOfferMe;
  }
  if(adaptOffer && (nextOfferMe > 500 || nextOfferMe > offerOther)) {
    int fairOffer = 500;
    if(fairOffer > offerOther) {fairOffer = offerOther;}
    stopperMyOffer -= nextOfferMe-fairOffer;
    while(stopperMyOffer < 0) {--nextOfferMe;
      stopperMyOffer += rand()%(666);}
  }
  if(offerOther > 499) {acceptOffer = true;}
  lastOfferOther = offerOther;
  lastofferOtherWasAcceped = acceptOffer;
  if(acceptOffer) {totalBilanz += bilanzOther1;}
return acceptOffer;
}

// Berechnet die angebotenen Punkte und sendet sie an den Server.
int GKStrategy::calculateOfferedPoints()
{
  int myOffer = nextOfferMe;
  if(myOffer < 0) {myOffer = 0;}
  if(myOffer > 1000) {myOffer = 1000;}
  lastOfferMe = myOffer;
  return myOffer;
}
