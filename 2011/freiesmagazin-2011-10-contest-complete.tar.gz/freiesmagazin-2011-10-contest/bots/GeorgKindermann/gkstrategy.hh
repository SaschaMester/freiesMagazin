/**
    (C) Copyright 2011 Dominik Wagenfuehr, Georg Kindermann

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef GKSTRATEGY_HH
#define GKSTRATEGY_HH

#include "botdata.hh"
#include "basestrategy.hh"

// Vorwaertsdeklarationen.
//class BotData;

/// Einfache Strategie
/**
 * Die Strategie bietet immer 250 Punkte an und akzeptiert
 * wiederum jedes Angebot groesser gleich 250 Punkten.
 */
class GKStrategy : public BaseStrategy
{
  public:
    /// Konstruktor
    GKStrategy();

    /// Destructor.
    virtual ~GKStrategy();

    /// Erstellt eine Kopie des Elements.
    /**
     * Wenn man abgeleitete Klassen von einer Basis-Klasse hat
     * und nur mit einem Pointer auf die Basis-Klasse arbeitet,
     * lassen sich Objekte nicht so einfach per Zuweisung kopieren
     * da man ja die exakte Klassen benötigt. In dem Fall arbeitet
     * man mit einer virtuellen copy-Methode, welche in jeder
     * abgeleiteten Klasse implementiert werden muss.
     * @return Pointer auf die Kopie des Objekt.
     */
    virtual BaseStrategy* copy() const;
    
    /// Akzeptiert oder lehnt ein Angebot ab.
    virtual bool acceptOrDeclineOffer( const int offerOther );

    /// Berechnet die angebotenen Punkte.
    virtual int calculateOfferedPoints();

private:
  int lastOfferMe;
  int lastOfferOther;
  bool lastofferOtherWasAcceped;
  long totalBilanz;
  int nextOfferMe;
  int stage;
  int roundsToHandover;
  int nTimesToFollow;
  int stopper0[498];
  int stopper1[498];
  int profit[2001];
  int maxNtimesThisLevel[2001];
  int lastTargetProfit;
  int maxProfit;
  int baseline;
  int myOfferWasNeverAccepted;
  int stopperMyOffer;
  int myOfferRejectionInARow;
  bool playerMode;
};

#endif // GKSTRATEGY_HH
