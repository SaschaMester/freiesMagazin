/*
  foxybot.h

  Copyright 2011 by Michael Munzert (Foxyam[at]web.de).

  This file is part of Foxybot.

  Foxybot is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Foxybot is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with Foxybot.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ========================================================================== */
/*  Defines                                                                   */
/* ========================================================================== */

#define OK           0
#define NOTOK        -1
#define EQUAL        0

#ifndef TRUE
#define TRUE         (1)
#endif
#ifndef FALSE
#define FALSE        (0)
#endif

#define CMD_LEN      8
#define WERT_LEN     10
#define BUF_LEN      20

#define MIN_POINTS   0
#define MAX_POINTS   1000

/* -------------------------------------------------------------------------- */
/*  Kommandos                                                                 */
/* -------------------------------------------------------------------------- */

#define ROUNDS    "RUNDEN"
#define ROUND     "RUNDE"
#define OFFER     "ANGEBOT"
#define POINTS    "PUNKTE"
#define START     "START"
#define END       "ENDE"
#define YES       "JA"
#define NO        "NEIN"

#define ID_IGNORE    0
#define ID_ROUNDS    1
#define ID_ROUND     2
#define ID_OFFER     3
#define ID_POINTS    4
#define ID_START     5
#define ID_END       6
#define ID_YES       7
#define ID_NO        8

/* ========================================================================== */
/*  Typdefinitionen                                                           */
/* ========================================================================== */

/* -------------------------------------------------------------------------- */
/*  Statistik: Enthaelt die Informationen ueber die Punkte und die letzten    */
/*             Angebote                                                       */
/* -------------------------------------------------------------------------- */

typedef struct {
   int anzahlRunden;
   int aktRunde;
   long gesamtPunkte;
   long gesamtPunkteG;
   int erwartetePunkte;
   int letztesAngebot;
   int aktAngebot;
   int letzteAntwort;
   int meineAntwort;
} Statistik;

/* -------------------------------------------------------------------------- */
/*  InputData: Enthaelt die empfangene Eingabe                                */
/* -------------------------------------------------------------------------- */

typedef struct {
   char buffer [BUF_LEN + 1];
   char kommando [CMD_LEN + 1];
   char wert [WERT_LEN + 1];
   int iwert;
} InputData;

/* ========================================================================== */
/*  Prototypen                                                                */
/* ========================================================================== */

void calcOffer(Statistik *stat);
void decide(Statistik *stat);

/* =================================== EOF ================================== */
