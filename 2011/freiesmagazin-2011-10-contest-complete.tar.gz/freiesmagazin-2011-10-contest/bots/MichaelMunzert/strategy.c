/*
  strategy.c

  Copyright 2011 by Michael Munzert (Foxyam[at]web.de).

  This file is part of Foxybot.

  Foxybot is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Foxybot is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with Foxybot.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "foxybot.h"

/* -------------------------------------------------------------------------- */
/*  decide: Entscheidet, ob Angebot angenommen werden soll oder nicht         */
/* -------------------------------------------------------------------------- */

void decide(Statistik *stat)
{
   if (stat->letzteAntwort == ID_NO &&
       stat->aktAngebot <= stat->letztesAngebot) {
      stat->meineAntwort = ID_NO;
   } else if (stat->gesamtPunkte < stat->gesamtPunkteG &&
              (stat->aktAngebot >= (MAX_POINTS / 3) ||
              (stat->aktAngebot > stat->letztesAngebot + 50))) {
      stat->meineAntwort = ID_YES;
   } else if (stat->gesamtPunkte >= stat->gesamtPunkteG &&
              stat->aktAngebot > ((MAX_POINTS * stat->gesamtPunkteG) /
                                  (MAX_POINTS + 2 * stat->gesamtPunkteG))) {
      stat->meineAntwort = ID_YES;
   } else {
      stat->meineAntwort = ID_NO;
   }
}

/* -------------------------------------------------------------------------- */
/*  calcOffer: Berechnet das naechste Angebot                                 */
/* -------------------------------------------------------------------------- */

void calcOffer(Statistik *stat)
{
   if (stat->aktRunde == 1) {
      stat->aktAngebot = 400;
   } else if (stat->gesamtPunkte <= stat->gesamtPunkteG) {
      stat->aktAngebot = MAX_POINTS / 3;
   } else if (stat->letzteAntwort == ID_NO) {
      stat->aktAngebot = (stat->letztesAngebot + 50) % 500;
   } else {
      stat->aktAngebot = ((MAX_POINTS * stat->gesamtPunkteG) /
                         (MAX_POINTS + 2 * stat->gesamtPunkteG)) % 500;
   }
}

/* =================================== EOF ================================== */
