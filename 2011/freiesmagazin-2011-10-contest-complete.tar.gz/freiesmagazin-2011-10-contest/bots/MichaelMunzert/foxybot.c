/*
  foxybot.c

  Copyright 2011 by Michael Munzert (Foxyam[at]web.de).

  This file is part of Foxybot.

  Foxybot is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Foxybot is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with Foxybot.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "foxybot.h"

/* ========================================================================== */
/*  Private Funktionen                                                        */
/* ========================================================================== */

/* -------------------------------------------------------------------------- */
/*  doNext: Macht den naechsten Schritt abhaengig vom Kommando                */
/* -------------------------------------------------------------------------- */

static int doNext(Statistik *stat, int cmd, int wert)
{
   int rc = OK;

   switch (cmd) {
      case ID_ROUNDS:
         stat->anzahlRunden = wert;
         break;
      case ID_ROUND:
         stat->aktRunde = wert;
         break;
      case ID_OFFER:
         stat->aktAngebot = wert;
         decide(stat);
         if (stat->meineAntwort == ID_YES) {
            stat->erwartetePunkte = wert;
            fprintf(stdout, "%s\n", YES);
            fflush(stdout);
         } else {
            stat->erwartetePunkte = 0;
            fprintf(stdout, "%s\n", NO);
            fflush(stdout);
         }
         stat->letztesAngebot = stat->aktAngebot;
         break;
      case ID_POINTS:
         if (wert != stat->erwartetePunkte) {
            fprintf(stderr, "FEHLER: %d != %d (erwartet)\n", wert,
                    stat->erwartetePunkte);
            fflush(stderr);
            rc = NOTOK;
         } else {
            stat->gesamtPunkte += wert;
            stat->gesamtPunkteG += (MAX_POINTS - wert);
         }
         break;
      case ID_START:
         calcOffer(stat);
         stat->erwartetePunkte = (MAX_POINTS - stat->aktAngebot);
         stat->letztesAngebot = stat->aktAngebot;
         fprintf(stdout, "%d\n", stat->aktAngebot);
         fflush(stdout);
         break;
      case ID_YES:
         stat->letzteAntwort = ID_YES;
         break;
      case ID_NO:
         stat->letzteAntwort = ID_NO;
         stat->erwartetePunkte = 0;
         break;
      default:
         fprintf(stderr, "FEHLER: Ungueltiges Kommando {%d}\n", cmd);
         fflush(stderr);
         rc = NOTOK;
         break;
   }

   return rc;
}

/* -------------------------------------------------------------------------- */
/*  processInput: Wertet das eingelesene Kommando aus                         */
/* -------------------------------------------------------------------------- */

static int processInput(InputData *data)
{
   int cmd = ID_IGNORE;

   if (strcmp(data->kommando, ROUNDS) == EQUAL) {
      cmd = ID_ROUNDS;
   } else if (strcmp(data->kommando, ROUND) == EQUAL) {
      cmd = ID_ROUND;
   } else if (strcmp(data->kommando, OFFER) == EQUAL) {
      cmd = ID_OFFER;
   } else if (strcmp(data->kommando, POINTS) == EQUAL) {
      cmd = ID_POINTS;
   } else if (strcmp(data->kommando, START) == EQUAL) {
      cmd = ID_START;
   } else if (strcmp(data->kommando, END) == EQUAL) {
      cmd = ID_END;
   } else if (strcmp(data->kommando, YES) == EQUAL) {
      cmd = ID_YES;
   } else if (strcmp(data->kommando, NO) == EQUAL) {
      cmd = ID_NO;
   } else {
      fprintf(stderr, "FEHLER: Kommando '%s' unbekannt\n", data->kommando);
      fflush(stderr);
   }

   return cmd;
}

/* -------------------------------------------------------------------------- */
/*  readInput: Liest eine Zeile von der Standardeingabe                       */
/* -------------------------------------------------------------------------- */

static int readInput(InputData *data)
{
   int rc = OK;

   char *posBlank = NULL;

   if (!data) {
      fprintf(stderr, "FEHLER: Parameter 'data' ist NULL\n");
      fflush(stderr);
      rc = NOTOK;
   } else {
      fgets(data->buffer, BUF_LEN + 1, stdin);
      int len = strlen(data->buffer);
      data->buffer[--len] = '\0';

      if (!(posBlank = strstr(data->buffer, " "))) {
         strncpy(data->kommando, data->buffer, CMD_LEN);
         data->iwert = -1;
      } else {
         *posBlank++ = '\0';
         strncpy(data->kommando, data->buffer, CMD_LEN);
         strncpy(data->wert, posBlank, WERT_LEN);
         data->iwert = atoi(data->wert);
      }
   }

   return rc;
}

/* -------------------------------------------------------------------------- */
/*  startGame: Enthaelt die Spielschleife und fuehrt die Einzelschritte durch */
/*             Aufruf der entsprechenden Funktionen aus                       */
/* -------------------------------------------------------------------------- */

static int startGame()
{
   int rc = OK;

   Statistik stat;
   InputData data;
   int cmd;

   /* Strukturen initialisieren */
   memset(&stat, 0, sizeof(Statistik));
   memset(&data, 0, sizeof(InputData));

   while (1) {
      if (readInput(&data)) {
         fprintf(stderr, "FEHLER: readInput\n");
         rc = NOTOK;
         break;
      } else if ((cmd = processInput(&data)) == ID_END) {
         break;
      } else if (doNext(&stat, cmd, data.iwert)) {
         fprintf(stderr, "FEHLER: doNext\n");
         rc = NOTOK;
         break;
      } else {
         memset(&data, 0, sizeof(InputData));
      }
   }

   return rc;
}

/* ========================================================================== */
/*  Oeffentliche Funktion                                                     */
/* ========================================================================== */

/* -------------------------------------------------------------------------- */
/*  main: Hauptprogram                                                        */
/* -------------------------------------------------------------------------- */

int main(void)
{
   int rc = OK;

   rc = startGame();

   return rc;
}

/* =================================== EOF ================================== */
