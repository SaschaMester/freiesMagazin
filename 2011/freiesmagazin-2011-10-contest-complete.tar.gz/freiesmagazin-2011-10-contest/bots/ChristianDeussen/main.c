/**
    (C) Copyright 2011 Christian Deussen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "stdio.h"
#include "string.h"
#include <stdlib.h>

#define MAX_CMD_LENGTH  70
#define MAX_VAL 	1000

#define DECREASE_OFFER_STEP 5
#define INCREASE_OFFER_STEP 50
#define START_OFFER 352

char buffer[MAX_CMD_LENGTH];
void get_word(); // copy one word from stdin to buffer[]

int main() {
	int end = 0;
	int crrnt_offer = START_OFFER;

	while(!end) {
		get_word();
		if(!strcmp(buffer,"RUNDEN")) {
			get_word();
		}
		else if(!strcmp(buffer,"RUNDE")) {
			get_word();
		}
		else if(!strcmp(buffer,"ANGEBOT")) {
			get_word();
			int offer = atoi(buffer);
			if(offer > 100 ) {
				printf("JA\n");
			}
			else {
				printf("NEIN\n");
			}
		}
		else if(!strcmp(buffer,"PUNKTE")) {
			get_word();
		}
		else if(!strcmp(buffer,"START")) {
			sprintf(buffer,"%d",crrnt_offer);
			printf("%s\n",buffer);
		}
		else if(!strcmp(buffer,"ENDE")) {
			end = 1;
		}
		else if(!strcmp(buffer,"JA")) {
			if(crrnt_offer >100 && crrnt_offer >DECREASE_OFFER_STEP)
				crrnt_offer -= DECREASE_OFFER_STEP;
		}
		else if(!strcmp(buffer,"NEIN")) {
			if(crrnt_offer < MAX_VAL-INCREASE_OFFER_STEP)
				crrnt_offer += INCREASE_OFFER_STEP;
		}
		else{
			perror("unknown cmd!");
		}
		fflush(NULL);
	}
}

void get_word()
{
	char tmp;
	int i = 0;
	while(i < MAX_CMD_LENGTH-1) {
		scanf("%c",&tmp);
		if(tmp == ' ' || tmp == '\n' || 
			tmp == '\0' || tmp == '\r'|| 
				tmp == '\b' || tmp == '\f') {

			if(i > 0) {
				buffer[i] = 0x00;
				return;
			}
		}
		else { 
			buffer[i++] = tmp; 
		}
	}
	buffer[i] = 0x00;
}
