/*
    Copyright (C) 2011 Nick Frank

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation; either version 2 of
    the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

    General Public License: http://www.gnu.org
*/

#include <string>

//der Bot sucht nach Schwachstellen des Gegners um diese zu benutzen (wirksam gegen annehmen wenn >=XXX Bots)
//die Antworten werden mit einer Formel berechnet die sicher geht,dass der Bot in F�hrung bleibt sofern das
//angebot unter 250 liegt

class AI{
private:
	std::string answer;
	int offer;
public:
	AI(){
		answer="NEIN";
		offer=200;
	}

	void save_yes(){
		if(answer=="NEIN"){
			answer="JA";
		}
	}

	void retry(){
		answer="NEIN";
		if(offer<=350){
			offer=offer+50;
		}
	}

	bool accept(int enemy,int punkte_eigen,int punkte_geg){
		//berechne Antwort auf das Angebot des Gegners
		if(enemy>=250){
			return true;
		}
		else if(punkte_eigen+enemy>=(punkte_geg+(1000-enemy))+50){
			return true;
		}
		else{
			return false;
		}
	}
	
	int whatToDo(){
		return offer;
	}
};
