/*
    Copyright (C) 2011 Nick Frank

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation; either version 2 of
    the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

    General Public License: http://www.gnu.org
*/

#include <iostream>
#include <string>
#include <sstream>
#include "ai.h"

class Bot :AI{
private:
	//neuster Befehl
	std::string message;
	std::string own_message;
	
	//Werte-Transporter f�r StringStream
	std::stringstream value_buffer;
	
	//empfangene Werte
	unsigned int runden;
	unsigned int runde;
	unsigned int angebot;
	unsigned int punkte;

	unsigned int angebot_eigen;
	unsigned int punkte_gegner;

	//soll die Schleife weiter laufen?
	bool loop;

	//welcher Bot ist an der Reihe?
	int turn;//0=keiner;1=dieser;2=gegner
public:
	Bot(){
		//Werte vorsichtshalber auf 0 setzen
		this->runden=0;
		this->runde=0;
		this->angebot=0;
		this->punkte=0;

		this->angebot_eigen=0;
		this->punkte_gegner=0;

		this->own_message="";
		this->turn=0;
		this->loop=true;
	}

	void send(){
		//lege Nachricht fest
		if(turn==1){
			value_buffer<<whatToDo();
			value_buffer>>own_message;
			value_buffer.clear();

			value_buffer<<whatToDo();
			value_buffer>>angebot_eigen;
			value_buffer.clear();
		}
		else if(this->turn==2 && accept(angebot,punkte,punkte_gegner)){
			value_buffer<<"JA";
			value_buffer>>own_message;
			value_buffer.clear();
		}
		else if(this->turn==2){
			value_buffer<<"NEIN";
			value_buffer>>own_message;
			value_buffer.clear();
		}
		//gebe Nachricht aus
		if(this->turn!=0){
			std::cout<<this->own_message<<std::endl;
		}
	}
	
	void get(){
		//lese Nachricht aus
		std::getline(std::cin,this->message);
	}

	void clear_message(){
		this->own_message="";
	}

	std::string checkSTARTorEND(){
		if(this->message=="START"){
			this->turn=1;
			return "START";
		}
		else if(this->message=="ENDE"){
			this->loop=false;
			return "ENDE";
		}
		else{
			return "COUNTINUE";
		}
	}
	
	void save_values(){
		if(message.compare(0,6,"RUNDEN")==0){
			value_buffer<<message.substr(7,4);
			value_buffer>>runden;
			value_buffer.clear();
		}
		else if(message.compare(0,5,"RUNDE")==0){
			value_buffer<<message.substr(6,4);
			value_buffer>>runde;
			value_buffer.clear();
		}
		else if(message.compare(0,7,"ANGEBOT")==0){
			this->turn=2;
			value_buffer<<message.substr(8,4);
			value_buffer>>angebot;
			value_buffer.clear();
		}
		else if(message.compare(0,6,"PUNKTE")==0){
			value_buffer<<message.substr(7,4);
			value_buffer>>punkte;
			value_buffer.clear();
		}
		else if(message=="JA"){
			save_yes();
			punkte_gegner=punkte_gegner+angebot_eigen;
		}
		else if(message=="NEIN"){
			retry();
		}
	}

	void loop_one_time(){
		this->turn=0;
		this->get();
		this->save_values();
		this->checkSTARTorEND();

		this->send();

		//std::cout<<runden<<std::endl;
		//std::cout<<runde<<std::endl;  //nur f�r
		//std::cout<<angebot<<std::endl;//Test-Zwecke!!!
		//std::cout<<punkte<<std::endl;
		//std::cout<<angebot_eigen<<std::endl;
		//std::cout<<punkte_gegner<<std::endl;

		clear_message();
	}

	void run(){
		while(this->loop){
			this->loop_one_time();
		}
	}
};
