"""
(c) 2011 Mario Fuest

This file is part of keba-bot3.

keba-bot3 is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

keba-bot3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with keba-bot3If not, see <http://www.gnu.org/licenses/>.
"""
class Player(object):
    def __init__(self):
        self.strategy = None
        self.round = 0
        self.points = 0
        self.opp = None
        self.last_offered_amt = 0
        self.accepted_last = None
        self.last_accepted_amt = 0

    def offer(self, *args):
        amt = self.strategy.offer(self, self.opp, *args)
        self.last_offered_amt = amt
        return amt

    def check(self, amt, *args):
        accepted = self.strategy.check(self, self.opp, amt, *args)
        self.accepted_last = accepted
        if accepted:
            self.last_accepted_amt = amt
        return accepted

