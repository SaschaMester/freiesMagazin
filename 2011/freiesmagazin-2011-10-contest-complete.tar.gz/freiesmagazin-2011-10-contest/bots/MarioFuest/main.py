#!/usr/bin/env python
"""
(c) 2011 Mario Fuest

This file is part of keba-bot3.

keba-bot3 is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

keba-bot3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with keba-bot3If not, see <http://www.gnu.org/licenses/>.
"""
from sys import stdin, stdout, stderr
import time
# import logging

from players import Player
from strategies import *

# Use logging as printing will not work.
# logging.basicConfig(filename='keba.log',level=logging.DEBUG)

def main():
    line = stdin.readline()
    line = line.strip('\n')
    # logging.debug('Getting: %s' % line)

    if 'RUNDEN' in line:
        # Start a new game, so init same values
        # But who cares.
        pass

    elif 'RUNDE' in line:
        round = int(line.lstrip('RUNDE '))
        for ply in plys:
            ply.round = round

    elif 'ANGEBOT' in line:
        amt = int(line.lstrip('ANGEBOT '))
        if you.check(amt):
            stdout.write('JA\n')
        else:
            stdout.write('NEIN\n')
        opp.offer(amt)
        stdout.flush()

    elif 'PUNKTE' in line:
        y_points = int(line.lstrip('PUNKTE '))
        you.points += y_points
        opp.points += (1000 - y_points)

    elif 'START' in line:
        amt = you.offer()
        stdout.write('%i\n' % amt)
        stdout.flush()

    elif 'ENDE' in line:
        return 'exit'

    elif 'JA' in line:
        opp.check(you.last_offered_amt, True)

    elif 'NEIN' in line:
        opp.check(you.last_offered_amt, False)

    else:
        # logging.error('Unknown cmd: %s' % line)
        return 'exit'


if __name__ == '__main__':
    strategy = Teamwork()

    # It *is* dirty to put that here.
    # Do not read that code.
    opp = Player()
    you = Player()
    you.strategy = strategy
    opp.strategy = Dummy()
    you.opp = opp
    opp.ppp = you
    plys = (opp, you)

    while True:
        if main() == 'exit': break

