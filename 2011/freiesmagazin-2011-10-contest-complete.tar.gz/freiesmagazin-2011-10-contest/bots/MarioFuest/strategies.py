"""
(c) 2011 Mario Fuest

This file is part of keba-bot3.

keba-bot3 is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

keba-bot3 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with keba-bot3If not, see <http://www.gnu.org/licenses/>.
"""
from random import randint

class Strategy(object):
    max_offer = 1000

    def offer(self, you, opp):
        return 300

    def check(self, you, opp, amt):
        return False

# More strategies planned...

class Dummy(Strategy):
    """
    The other player.
    """
    def offer(self, you, opp, amt):
        return amt

    def check(self, you, opp, amt, accepted):
        return accepted

class Teamwork(Strategy):
    """
    A *very* cooperative player.
    """
    s_offer = (442, 500)
    max_fails = 10

    def __init__(self):
        Strategy.__init__(self)
        self.fails = 0

        self.offer_range = self.s_offer
        # so could try to start assuming our strategy -> use random
        self.min_offer = randint(290, 340)
        self.min_level = randint(200, 242)

    def offer(self, you, opp):
        if self.fails < self.max_fails and opp.accepted_last == True:
            if self.offer_range[0]-2 >= self.min_offer:
                self.offer_range = (self.offer_range[0]-2,
                                    self.offer_range[1]-2)
        else:
            self.fails += 1
            self.offer_range = self.s_offer

        return randint(self.offer_range[0], self.offer_range[1])

    def check(self, you, opp, amt):
        return amt >= self.min_level and amt >= opp.last_offered_amt

