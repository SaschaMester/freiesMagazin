/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef MORESTRATEGY_HH
#define MORESTRATEGY_HH

#include "basestrategy.hh"

// Vorwaertsdeklarationen.
class BotData;

/// Stratgie auf Gleichheit basierend.
/**
 * Bei dieser Strategie wird immer die Hälfte der 1000 Punkte
 * angeboten und um ein angebotener Wert muss ebenfalls groesser
 * oder gleich 500 sein, damit er angenommen wird.
 */
class MoreStrategy : public BaseStrategy
{
  public:
    /// Konstruktor
    MoreStrategy();

    /// Destructor.
    virtual ~MoreStrategy();

    /// Erstellt eine Kopie des Elements.
    /**
     * Wenn man abgeleitete Klassen von einer Basis-Klasse hat
     * und nur mit einem Pointer auf die Basis-Klasse arbeitet,
     * lassen sich Objekte nicht so einfach per Zuweisung kopieren
     * da man ja die exakte Klassen benötigt. In dem Fall arbeitet
     * man mit einer virtuellen copy-Methode, welche in jeder
     * abgeleiteten Klasse implementiert werden muss.
     * @return Pointer auf die Kopie des Objekt.
     */
    virtual BaseStrategy* copy() const;
    
    /// Akzeptiert oder lehnt ein Angebot ab.
    /**
     * Ist der angebotene Wert groesser als 500, wird
     * das Angebot angenommen, sonst abgelehnt.
     * @param value Der angebotene Wert.
     * @return true, wenn das Angebot angenommen wurde, ansonsten false
     */
    virtual bool acceptOrDeclineOffer( const int value );

    /// Berechnet die angebotenen Punkte.
    /**
     * Es wird immer der Wert 499 angeboten.
     * @return 499
     */
    virtual int calculateOfferedPoints();
};

#endif // MORESTRATEGY_HH
