/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "simplestrategy.hh"

// Konstruktor
SimpleStrategy::SimpleStrategy()
: BaseStrategy()
{
}

// Destructor.
SimpleStrategy::~SimpleStrategy()
{
}

// Erstellt eine Kopie des Elements.
BaseStrategy* SimpleStrategy::copy() const
{
    return (BaseStrategy*)(new SimpleStrategy(*this));
}

// Akzeptiert oder lehnt ein Angebot ab.
bool SimpleStrategy::acceptOrDeclineOffer( const int value )
{
    bool acceptOffer = false;

    // Ist der Wert >= 250 akzeptieren wir.
    // Ist der Wert kleiner, lehnen wir ab.
    if ( value >= 250 )
    {
        acceptOffer = true;
    }
                
    return acceptOffer;
}

// Berechnet die angebotenen Punkte und sendet sie an den Server.
int SimpleStrategy::calculateOfferedPoints()
{
    // Immer 250 anbieten.
    return 250;
}
