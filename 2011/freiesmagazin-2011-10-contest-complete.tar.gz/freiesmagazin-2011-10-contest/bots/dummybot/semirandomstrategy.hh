/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef SEMIRANDOMSTRATEGY_HH
#define SEMIRANDOMSTRATEGY_HH

#include "basestrategy.hh"

// Vorwaertsdeklarationen.
class BotData;

/// Halbe Zufallsstrategie
/**
 * Bei dieser Strategie wird einfach zufaellig ein Wert zwischen
 * 0 und 500 angeboten und das Angebot entsprechend zufaellig
 * angenommen oder abgelehnt (solange es nicht ueber 500 liegt).
 */
class SemiRandomStrategy : public BaseStrategy
{
  public:
    /// Konstruktor
    SemiRandomStrategy();

    /// Destructor.
    virtual ~SemiRandomStrategy();

    /// Erstellt eine Kopie des Elements.
    /**
     * Wenn man abgeleitete Klassen von einer Basis-Klasse hat
     * und nur mit einem Pointer auf die Basis-Klasse arbeitet,
     * lassen sich Objekte nicht so einfach per Zuweisung kopieren
     * da man ja die exakte Klassen benötigt. In dem Fall arbeitet
     * man mit einer virtuellen copy-Methode, welche in jeder
     * abgeleiteten Klasse implementiert werden muss.
     * @return Pointer auf die Kopie des Objekt.
     */
    virtual BaseStrategy* copy() const;
    
    /// Akzeptiert oder lehnt ein Angebot ab.
    /**
     * Es wird zufaellig bestimmt, ob das Angebot angenommen
     * oder abgelehnt wird.
     * @param value Der angebotene Wert.
     * @return true, wenn das Angebot angenommen wurde, ansonsten false
     */
    virtual bool acceptOrDeclineOffer( const int value );

    /// Berechnet die angebotenen Punkte.
    /**
     * Es wird zufaellig ein Wert zwischen 0 und 1000 angeboten.
     * @return Wert zwischen 0 und 1000.
     */
    virtual int calculateOfferedPoints();
};

#endif // SEMIRANDOMSTRATEGY_HH
