/**
Copyright (c) 2011, Sebastian Wagner <szebi@gmx.at>

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

#include "sebix.hh"
#include "botdata.hh"


// Konstruktor
SebixStrategy::SebixStrategy()
: BaseStrategy()
{
}

// Destructor.
SebixStrategy::~SebixStrategy()
{
}

// Erstellt eine Kopie des Elements.
BaseStrategy* SebixStrategy::copy() const
{
    return (BaseStrategy*)(new SebixStrategy(*this));
}

// Akzeptiert oder lehnt ein Angebot ab.
bool SebixStrategy::acceptOrDeclineOffer( const int value )
{
	SebixStrategy::last = value;
    if (value < 250) {
    	return false;
    } else {
    	return true;
    }
}

// Berechnet die angebotenen Punkte und sendet sie an den Server.
int SebixStrategy::calculateOfferedPoints()
{
	if (mBotDataP->getRound() > 0) {
		if (mBotDataP->getOpponentPoints() % 250 <= 10) {	// zu einfacher/wenig variabler Bot
			return 250;
		}
		if (mBotDataP->getOpponentPoints() > mBotDataP->getPoints() && mBotDataP->getRound()%5 == 0) {	// intelligenter Bot..
			return 290-(mBotDataP->getRound()/10);
		}
		return SebixStrategy::last;
	} else {
		return 250;
	}
}
