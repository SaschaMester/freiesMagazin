/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef BOTDATA_HH
#define BOTDATA_HH

/// Bot-Daten eines Spiels.
/**
 * Die Klasse enthaelt die Rundenanzahl und die
 * erreichten Punkte der beteiligten Bots.
 */
class BotData
{
  public:
    /// Konstruktor.
    BotData();

    /// Setzt alle Daten zurueck.
    void reset();

    /// Speichere Anzahl an Runden.
    void setRounds( const int value );
      
    /// Eine neue Runde wird gestartet.
    /**
     * Der Rundenzaehler wird entsprechend erhoeht.
     */
    void startNewRound();

    /// Fuegt erreichte Punktzahl hinzu.
    void addPoints( const int points );
    
    /// Fuegt erreichte Punktzahl des Gegners hinzu.
    void addOpponentPoints( const int points );
    
  bool wasMyLastOfferWasAccepted(bool x);

  public:
    /// Gibt die Anzahl der zu spielenden Runden zurueck.
    int getNumRounds() const
    {
        return mNumMaxRounds;
    }
  
    /// Gibt die aktuelle Runde zurueck.
    int getRound() const
    {
        return mRound;
    }

    /// Gibt die eigene Punktzahl zurueck.
    int getPoints() const
    {
        return mPoints;
    }

    /// Gibt die Punktzahl des Gegners zurueck.
    int getOpponentPoints() const
    {
        return mOpponentPoints;
    }

  bool wasMyLastOfferWasAccepted() const {
    return(myLastOfferWasAccepted);
  }

  private:
    /// Gesamtzahl an Runden.
    int mNumMaxRounds;

    /// Rundennummer.
    /**
     * Mit jedem Start wird die Rundennummer erhoeht.
     * Die Nummer gibt auch an, auf wie viele Daten aus
     * vergangenen Runden man zugreifen kann.
     */
    int mRound;

    /// Eigene bereits erreichte Punktzahl.
    int mPoints;

    /// Punktzahl des Gegners.
    int mOpponentPoints;

  //Wurde mein letztes Angebot angenommen
  bool myLastOfferWasAccepted;

};

#endif // BOTDATA_HH
