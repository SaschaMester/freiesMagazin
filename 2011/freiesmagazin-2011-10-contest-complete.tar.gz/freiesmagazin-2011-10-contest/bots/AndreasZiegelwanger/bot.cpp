/**
(C) Copyright 2011 Andreas Ziegelwanger

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as
published by the Free Software Foundation; either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this program. If not, see
<http://www.gnu.org/licenses/>.
*/
#include "bot.hh"

#include <cstdlib>
#include <ctime>

Bot::Bot(){
    runden = 0;
    runde = 0;
    punkte = 0;
    srand(time(0));
}

void Bot::setRunden(int r){runden = r;}
//Runde hat sich geändert
void Bot::setRunde(int r){runde = r;}
void Bot::setPunkte(int p){punkte = p;}

int Bot::calculateOfferedPoints(){
    return 400 + rand()%101;
}

bool Bot::acceptOrDeclineOffer(const int value){
    bool acceptOffer = false;
    
    if(value>300)
        acceptOffer = true;
    
    return acceptOffer;
}