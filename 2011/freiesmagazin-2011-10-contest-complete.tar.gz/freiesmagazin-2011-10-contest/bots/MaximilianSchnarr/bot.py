#!/usr/bin/env python3
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
# Copyright (C) 2011 Maximilian Schnarr <Maximilian.Schnarr@gmx.de>

import sys

#########
# Runde #
#########
class Runde(object):
	def __init__(self, nr):
		self.nr = nr
		self.eigAngebot = 0
		self.gegAngebot = 0
		self.eigAntwort = None
		self.gegAntwort = None
		self.eigGewinn = 0
		self.gegGewinn = 0
		self.verlust = 0

	def getNr(self):
		return self.nr

	def setEigAngebot(self, angebot):
		self.eigAngebot = angebot
	def getEigAngebot(self):
		return self.eigAngebot
	
	def setGegAngebot(self, angebot):
		self.gegAngebot = angebot
	def getGegAngebot(self):
		return self.gegAngebot
	
	def setEigAntwort(self, antwort):
		self.eigAntwort = antwort
	def getEigAntwort(self):
		return self.eigAntwort
	
	def setGegAntwort(self, antwort):
		self.gegAntwort = antwort
	def getGegAntwort(self):
		return self.gegAntwort
	
	def addPunkte(self, punkte):
		if punkte > 0:
			self.eigGewinn += punkte
			self.gegGewinn += 1000 - punkte
		else:
			self.verlust += 1000
	def getEigGewinn(self):
		return self.eigGewinn
	def getGegGewinn(self):
		return self.gegGewinn
	def getVerlust(self):
		return self.verlust

#############
# Statistik #
#############
class Statistik(object):
	def __init__(self, runden=[]):
		self.minEigAngebot = 1001
		self.maxEigAngebot = -1
		self.minGegAngebot = 1001
		self.maxGegAngebot = -1
		self.eigGewinn = 0
		self.gegGewinn = 0
		self.verlust = 0

		for runde in runden:
			self.update(runde)
	
	def update(self, runde):
		self.minEigAngebot = min(self.minEigAngebot, runde.getEigAngebot())
		self.maxEigAngebot = max(self.maxEigAngebot, runde.getEigAngebot())
		self.minGegAngebot = min(self.minGegAngebot, runde.getGegAngebot())
		self.maxGegAngebot = max(self.maxGegAngebot, runde.getGegAngebot())

		self.eigGewinn += runde.getEigGewinn()
		self.gegGewinn += runde.getGegGewinn()
		self.verlust += runde.getVerlust()
	
	def getMinEigAngebot(self):
		return self.minEigAngebot
	def getMaxEigAngebot(self):
		return self.maxEigAngebot
	def getMinGegAngebot(self):
		return self.minGegAngebot
	def getMaxGegAngebot(self):
		return self.maxGegAngebot
	
	def getEigGewinn(self):
		return self.eigGewinn
	def getGegGewinn(self):
		return self.gegGewinn
	def getVerlust(self):
		return self.verlust

########
# Main #
########
if __name__ == "__main__":
	# maximale Rundenzahl
	maxRunden = 0
	# Liste mit dem Verlauf aller bisherigen Runden
	runden = list()

	# Runde-Object der aktuellen Runde
	aktRunde = Runde(0)
	# Runde-Object der letzten Runde
	lastRunde = Runde(0)

	# Gesamtstatistik
	stat = Statistik()

	# gibt an, ob ich der erste Spieler bin
	binErster = None

	# speichert erkannte Eigenschaften ueber den Gegner
	gegner = dict()
	gegner["hat_untergrenze"] = 0	# Es gibt ein Angebot ab dem er immer zustimmt
	gegner["untergrenze"] = 1000	# Die moegliche Untergrenze des Gegners
	gegner["bleibt_vorne"] = 0		# Er nimmt nur Angebote an wenn er vorne bleibt

	# Parameter
	param = dict()
	param["start_angebot"] = 450	# Erstes Angebot an den Gegner
	param["delta_angebot"] = 25		# Wert, um den das Angebot erhoeht bzw. verringert wird
	param["untergrenze"] = 200		# Angebote <= diesem Wert werden nicht angenommen
	param["obergrenze"] = 475		# Angebote ab diesem Wert werden immer angenommen
	param["max_rel_verlust"] = 20	# maximaler Verlust in Prozent
	param["max_diff/runde"] = 400	# maximaler Punkteunterschied pro Runde (wird auf Spiel hochgerechnet)

	# maximaler Punkteunterschied im ganzen Spiel
	max_diff = None

	# das Angebot, welches als naechstes abgegeben wird
	angebot = param["start_angebot"] - param["delta_angebot"]

	# Hauptschleife
	while True:
		line = sys.stdin.readline()

		if line.startswith('RUNDEN'):
			maxRunden = int(line.split(' ')[1])

			max_diff = maxRunden * param["max_diff/runde"]
		elif line.startswith('RUNDE'):
			value = int(line.split(' ')[1])

			if value > 1:
				lastRunde = aktRunde
				stat.update(lastRunde)
			aktRunde = Runde(value)
			runden.append(aktRunde)

			# Antwortverhalten des Gegners erkennen
			if aktRunde.getNr() > 1:
				# Werte der letzten Runde, die zum interpretieren erforderlich sind
				# Punktestand bei der Entscheidungsfindung des Gegners
				gegPunkte = stat.getGegGewinn() - lastRunde.getGegGewinn()
				eigPunkte = stat.getEigGewinn() - lastRunde.getEigGewinn()

				if not binErster and lastRunde.getEigAntwort():
					gegPunkte += 1000 - lastRunde.getGegAngebot()
					eigPunkte += lastRunde.getGegAngebot()

				# eigenes Angebot und die Antwort des Gegners darauf
				eigAngebot = lastRunde.getEigAngebot()
				gegAntwort = lastRunde.getGegAntwort()

				# Unterschied = geg. Punkte - eig. Punkte (nach Annahme des Angebots)
				Punkteunterschied = gegPunkte + eigAngebot - (eigPunkte + 1000 - eigAngebot)
				# Unterschied > 0 => geg. Punkte > eig. Punkte => Gegner ist vorne
				# Unterschied < 0 => geg. Punkte < eig. Punkte => Ich bin vorne

				# Will der Gegner unter allen Umstaenden in Fuehrung bleiben?
				if Punkteunterschied > 0 and gegAntwort is True:
					# Angebot wurde angenommen, weil er vorne bleibt
					gegner["bleibt_vorne"] += 1
				elif Punkteunterschied < 0 and gegAntwort is False:
					# Angebot wurde abgelehnt, weil er sonst nicht mehr vorne ist
					gegner["bleibt_vorne"] += 1
				elif Punkteunterschied == 0: 
					# es bleibt alles gleich, es kann keine Aussage getroffen werden
					pass
				else:
					# will nicht vorne bleiben
					if eigAngebot < gegner["untergrenze"] and gegAntwort is False:
						# Gegner hat vielleicht abgelehnt weil wir eine Untergrenze erreicht haben
						pass
					else:
						gegner["bleibt_vorne"] = 0

				# Gibt es eine Untergrenze?
				if eigAngebot < gegner["untergrenze"] and gegAntwort is True:
					# Gegner hat kleineres Angebot angenommen => neue Untergrenze
					gegner["untergrenze"] = eigAngebot
					gegner["hat_untergrenze"] = 0
				elif eigAngebot >= gegner["untergrenze"] and gegAntwort is False:
					# Gegner hat hoeheres Angebot abgelehnt => keine Untergrenze
					if Punkteunterschied < 0:
						# Gegner hat vielleicht abgelehnt um vorne zu bleiben
						pass
					elif Punkteunterschied > 0: # Punkteunterschied == 0 wird nicht behandelt
						gegner["untergrenze"] = 1000
						gegner["hat_untergrenze"] = 0
				elif gegner["untergrenze"] != 1000:
					# Gegner hat Untergrenze "bestaetigt"
					gegner["hat_untergrenze"] += 1
		elif line.startswith('ANGEBOT'):
			if binErster == None:
				binErster = False

			value = int(line.split(' ')[1])
			aktRunde.setGegAngebot(value)

			# erforderlicher Gewinn pro Runde zum Sieg
			erfGewinn = 0
			if stat.getEigGewinn() < stat.getGegGewinn():
				erfGewinn = (stat.getGegGewinn() - stat.getEigGewinn()) / (maxRunden - aktRunde.getNr() + 1)

			# Entscheidung treffen
			antwort = True

			if value < param["untergrenze"]:
				antwort = False
			elif value >= param["obergrenze"]:
				antwort = True
			elif gegner["hat_untergrenze"] >= 6 and gegner["untergrenze"] > 500:
				# Ziel: geringster Punkteunterschied
				# Alles annehmen ...
				antwort = True

				# ... aber maximale Punktedifferenz einhalten.
				if stat.getGegGewinn() - stat.getEigGewinn() > max_diff:
					antwort = False
			elif gegner["bleibt_vorne"] >= 14:
				# Ziel: geringster Punkteunterschied
				antwort = True # geringster Unterschied wird hauptsaechlich vom eigenen Angebot umgesetzt

				if aktRunde.getNr() == maxRunden and binErster:
					# allerletztes Angebot nicht annehmen um einen Punkteunterschied von 2 Punkten zu haben
					antwort = False
			else:
				# Ziel: Spiel gewinnen (eigene Punkte > gegnerische Punkte)
				if binErster:
					vorsprungBisher = aktRunde.getEigGewinn() - aktRunde.getGegGewinn()
					vorsprungGesamt = vorsprungBisher + (value - (1000 - value))
					# vorsprungGesamt < vorsprungBisher, da value < 500 !

					# Gewinn in dieser Runde gemacht?
					if vorsprungGesamt >= erfGewinn:
						antwort = True
					elif vorsprungBisher >= erfGewinn and erfGewinn > 0:
						antwort = False
					# elif eigene Punktzahl > gegnerische Punktzahl nach annehmen dieses Angebots
					elif stat.getEigGewinn() + aktRunde.getEigGewinn() + value >= stat.getGegGewinn() + aktRunde.getGegGewinn() + 1000 - value:
						antwort = True
					else:
						antwort = False
				else:
					unterschiedJetzt = value - (1000 - value)

					# Moeglichen Gewinn schaetzen
					if gegner["hat_untergrenze"] >= 6:
						gewinnMoeglich = 1000 - 2 * gegner["untergrenze"]
					else:
						# Hier nur die wahrscheinlichen Werte (schlechte Bestimmung aber auch eher unwichtig)
						if lastRunde.getGegAntwort():
							# Gewinn unwahrscheinlich, da er letzte Runde angenommen hat und das Angebot deshalb verringert wurde
							gewinnMoeglich = 0
						else:
							# Gewinn wahrscheinlich, da mein Angebot gestiegen ist
							gewinnMoeglich = 1000 - 2 * (angebot + param["delta_angebot"])

					# Entscheidung treffen
					if unterschiedJetzt + gewinnMoeglich >= erfGewinn:
						antwort = True
					elif gewinnMoeglich >= erfGewinn and erfGewinn > 0:
						antwort = False
					# elif eigene Punktzahl > gegnerische Punktzahl nach annehmen dieses Angebots
					elif stat.getEigGewinn() + value >= stat.getGegGewinn() + 1000 - value:
						antwort = True
					else:
						antwort = False

				# prozentualer Verlust
				if aktRunde.getNr() > 1:
					relVerlust = stat.getVerlust() / (aktRunde.getNr() * 20 - 20)

					if relVerlust >= param["max_rel_verlust"]:
						antwort = True

			# Antwort senden
			if antwort:
				print('JA')
				aktRunde.setEigAntwort(True)
			else:
				print('NEIN')
				aktRunde.setEigAntwort(False)
		elif line.startswith('PUNKTE'):
			value = int(line.split(' ')[1])

			aktRunde.addPunkte(value)
		elif line.startswith('START'):
			if binErster == None:
				binErster = True

			# Angebot ermitteln
			if gegner["bleibt_vorne"] >= 14:
				# min_angebot ist Angebot bei dem der Gegner gerade so zustimmt, weil er noch
				# vorne bleibt
				# Formel: min_angebot > (eigene Punktzahl + 1000 - gegnerische Punktzahl) / 2
				min_angebot  = stat.getEigGewinn() + aktRunde.getEigGewinn()
				min_angebot += 1000
				min_angebot -= (stat.getGegGewinn() + aktRunde.getGegGewinn())
				min_angebot /= 2
				min_angebot += 1 # wegen '>'-Zeichen
				min_angebot  = int(min_angebot) # Angebot hat kein Komma

				if gegner["hat_untergrenze"] >= 6:
					min_angebot = max(gegner["untergrenze"], min_angebot)
				else:
					min_angebot = max(200, min_angebot)

				if min_angebot == angebot and lastRunde.getGegAntwort() is False:
					# Nicht erkannte untere Grenze
					angebot = min_angebot + param["delta_angebot"]
				else:
					angebot = min_angebot
			elif gegner["hat_untergrenze"] >= 6:
				angebot = gegner["untergrenze"]
			else:
				if lastRunde.getGegAntwort():
					angebot -= param["delta_angebot"]
				else:
					angebot += param["delta_angebot"]

			# 100 <= Angebot <= 501
			angebot = max(100, angebot)
			angebot = min(angebot, 501)

			# Angebot senden
			print(str(angebot))
			aktRunde.setEigAngebot(angebot)
		elif line.startswith('ENDE'):
			# DEBUG: Rundenverlauf aller Runden in Datei schreiben
			#FILE = open("runden.txt", "w")

			# Aufbau: | RundenNr | eigAngebot gegAntwort | gegAngebot eigAntwort | eigGewinn gegGewinn | Verlust |
			#for runde in runden:
			#	text = "| {:>4} | {:>5}{:>3} | {:>5}{:>3} | {:>5}{:>5} | {:>5} |\n".format(runde.getNr(), runde.getEigAngebot(), runde.getGegAntwort(), runde.getGegAngebot(), runde.getEigAntwort(), runde.getEigGewinn(), runde.getGegGewinn(), runde.getVerlust())
			#	FILE.write(text)

			#FILE.close()

			# Das wars, Schleife abbrechen das Spiel ist zuende
			break	
		elif line.startswith('JA'):
			aktRunde.setGegAntwort(True)
		elif line.startswith('NEIN'):
			aktRunde.setGegAntwort(False)
		else:
			pass

		sys.stdout.flush()
