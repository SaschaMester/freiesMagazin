#!/usr/bin/python3


#    (C) Copyright 2011 Manuel Unglaub
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as
#    published by the Free Software Foundation; either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with this program. If not, see
#    <http://www.gnu.org/licenses/>.



import random

class Strategy:
	def __init__(self):
		self.points = 0
		self.roundNumber = 0

		self.o100c = 0
		self.o200c = 0
		self.o300c = 0
		self.o400c = 0

		self.setRundenValues(2500)

		self.answer = True
		self.lastAnswer = True
		self.lastOffer = 200
		self.lastOffers = [0, 0, 0, 200]
		self.maxOffer = 350

		self.numberOfRejections = 0

		self.oponentsOffers = [0, 0]
		self.stepsize = 5
		self.hasfallen = False

	def setRundenValues(self, runden):
		self.runden = runden
		self.o100cMax = int(self.runden*0.05)
		self.o200cMax = int(self.runden*0.10)
		self.o300cMax = int(self.runden*0.25)
		self.o400cMax = int(self.runden*0.50)
	
	def addPoints(self, points):
		self.points += points
	
	def setRound(self, roundNumber):
		self.roundNumber = roundNumber

	def takeOffer(self, offer):
		if offer < 50:
			return False
		if offer > 400:
			return True
		
		self.oponentsOffers.append(offer)
		falling = True
		allEqual = True
		last = self.oponentsOffers[0]
		for o in self.oponentsOffers:
			if o > last:
				falling = False
			if o != last:
				allEqual = False
			last = o
		self.oponentsOffers.pop(0)
		if falling and not allEqual:
			self.hasfallen = True
			return False

		if offer < 100:
			if self.o100c < self.o100cMax:
				self.o100c += 1
				return True
		elif offer < 200:
			if self.o200c < self.o200cMax:
				self.o200c += 1
				return True
		elif offer < 300:
			if self.o300c < self.o300cMax:
				self.o300c += 1
				return True
		elif offer < 400:
			if self.o400c < self.o400cMax:
				self.o400c += 1
				return True
		if self.points <= 0 or (self.roundNumber-self.numberOfRejections) <= 0 or self.points/(self.roundNumber - self.numberOfRejections) <= offer:
			return True
		
		if self.hasfallen:
			return False
		else:
			return True
	
	def provideAnswer(self, answer):
		if not answer:
			self.numberOfRejections += 1
		self.lastAnswer = self.answer
		self.answer = answer
		
	def generateOffer(self):
		if self.lastAnswer and self.answer:
			if self.lastOffers[1] != (self.lastOffer - self.stepsize):
				self.lastOffer -= self.stepsize
			return self.lastOffer
		elif self.answer:
			self.lastOffers.pop(0);
			self.lastOffers.append(self.lastOffer)
			return self.lastOffer
		else:
			if self.lastOffer < self.maxOffer:
				self.lastOffer += self.stepsize
			self.lastOffers.pop(0);
			self.lastOffers.append(self.lastOffer)
			return self.lastOffer


def getValue(s):
	return int(s.split(" ")[1])

strategy = Strategy()

run=True
while run:
	message = input("")
	
	if message.startswith("RUNDEN "):
		strategy.setRundenValues(getValue(message))
	if message.startswith("RUNDE "):
		runde=getValue(message)
		strategy.setRound(runde)
	if message.startswith("ANGEBOT "):
		if strategy.takeOffer(getValue(message)):
			print("JA")
		else:
			print("NEIN")
	if message.startswith("PUNKTE "):
		strategy.addPoints(getValue(message))
	if message.startswith("START"):
		print(strategy.generateOffer())
	if message.startswith("JA"):
		strategy.provideAnswer(True)
	if message.startswith("NEIN"):
		strategy.provideAnswer(False)

	if message == "ENDE":
		run = False



