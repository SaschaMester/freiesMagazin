/**
    (C) Copyright 2011 Felix Passenberg

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <sstream>
#include <string.h>
#include "messageid.hh"

int Runden;
int Runde;
int Punkte;
int PunkteGegner;
int Angebot;

int	LastAcceptedOffer = 1; // letztes akzeptiertes angebot
int	PreLastAcceptedOffer = 1; // vorletztes akzeptiertes angebot
bool AcceptedLastOffer = false; // hat das letzte angebot angenommen?
bool AcceptedPreLastOffer = false; // hat das vorletzte angebot angenommen?
bool Rise = true; // steige mit dem angebot?
int	LastOffer = 1; // letztes angebot
int	LowestAcceptedOffer = 499; // nidrigstes akzeptiertes angebot
int	LastOffered = 0; // zuletzt angeboten bekommen
int AcceptFrom = 450; // akzeptiere ab
int	offer = 1; // das Angebot

void sende(std::string message )
{
    std::cout << message << std::endl;
}


void lese(int & VALUE, MessageId & ID){
	std::string message;
	//std::cin >> message;
	
	int value;
	MessageId id;
	
	
	getline( std::cin, message );
	
	//==========================================================================
	// Provisiorisch den Wert auf 0 setzen.
	id = MESSAGE_ID_INVALID;

    // Provisiorisch den Wert auf 0 setzen.
    value = 0;

    if ( message.compare(0, 6, "RUNDEN") == 0 )
    {
        // Anzahl der zu spielenden Runden
        std::istringstream in( message.substr( 6, std::string::npos ) );
        in >> value;

        id = MESSAGE_ID_ROUNDS;
    }
    else if ( message.compare(0, 5, "RUNDE") == 0 )
    {
        // Aktuelle Runde.
        std::istringstream in( message.substr( 5, std::string::npos ) );
        in >> value;

        id = MESSAGE_ID_ACT_ROUND;
    }
    else if ( message.compare("START") == 0 )
    {
        // Bot soll etwas anbieten (neue Runde).
        id = MESSAGE_ID_START;
    }
    else if ( message.compare("ENDE") == 0 )
    {
        // Bot soll verlassen werden.
        id = MESSAGE_ID_EXIT;
    }
    else if ( message.compare(0, 7, "ANGEBOT") == 0 )
    {
        // Uns wird ein bestimmter Betrag angeboten.
        // Den wandeln wir erst in eine Zahl.
        std::istringstream in( message.substr( 7, std::string::npos ) );
        in >> value;

        id = MESSAGE_ID_OFFER;
    }
    else if ( message.compare(0, 6, "PUNKTE") == 0 )
    {
        // Der Server teilt uns mit, wie viele Punkte wir
        // wirklich erhalten.
        std::istringstream in( message.substr( 6, std::string::npos ) );
        in >> value;

        id = MESSAGE_ID_POINTS;
    }
    else if ( message.compare("JA") == 0 )
    {
        // Angebot wurde angenommen.
        id = MESSAGE_ID_ACCEPTED;
    }
    else if ( message.compare("NEIN") == 0 )
    {
        // Angebot wurde abgelehnt.
        id = MESSAGE_ID_DECLINED;
    }
    else if ( message.empty() )
    {
        // Leerstrings ignorieren wir einfach.
        id = MESSAGE_ID_IGNORE;
    }
    else
    {
        // Kommando nicht verstanden!
        std::ostringstream out;
        out << "(EE) " << " MessageHandler::processMessage"
                  << " Befehl '"
                  << message
                  << "' nicht verstanden."
                  << std::endl;
        std::cerr << out.str();
    }
	//==========================================================================
	VALUE = value;
	ID = id;
	
//	return in;
}

bool calculateAndOfferPoints()
{
	if(Rise == true){ 				// solange anheben bis der gegner akzeptiert
		offer = LastOffer + 1 ;
	}else if(AcceptedLastOffer){ 	// wenn er akzeptierte dann noch mal das angebot machen
		offer = LastAcceptedOffer;
	}else if (AcceptedLastOffer == false && AcceptedPreLastOffer == false){
		offer = LowestAcceptedOffer;	// falls er das letzte ablehnte das tiefste bekannte angebo machen
	}
	
	
	if(offer > 400)	offer = 400;		// nie mehr als 400 anbieten
	if(offer > LowestAcceptedOffer)	offer = LowestAcceptedOffer; //nicht mehr als nötig abgeben
	if(offer < 1) offer = 1; // nicht unter 1 anbieten
	
	LastOffer = offer;//letztes angebot speichern
	
	std::stringstream offerString;	// ausgabe des Angebots
	offerString << offer;
	std::string message = offerString.str();
	sende(message);				
	//std::cerr <<"(EE) " << offer << std::endl; // ausgabe zum fehler finden
	return true;
}

bool acceptOrDeclineOffer( int value )
{
	bool acceptOffer = false; // provisorisch ablehnen
	
	if ( value >= 500 ) // wenn mehr als 500 annehmen
    {
		acceptOffer = true;
		AcceptFrom = value; // höchster gegebenre wert speichern
	}else if( value >= AcceptFrom){//  drunter nehme ich nicht mehr an
		acceptOffer = true;
		AcceptFrom = value;	
    }else if(value > LastOffered){
    	//tue nichts, warte bis das angebot des anderen steigt
    }else{
    	AcceptFrom -= 1; // wenn er mir nicht entgegenkommt
    	if(AcceptFrom < 300) AcceptFrom = 332; //nehme ich mit der zeit auch ab 300 an.
    }
     
    LastOffered = value;
    
    // nur annehmen wenn ich mindestens 2/3 von den Punkten des gegners habe sonst wird sein vorsprung zu groß
    if( (Punkte + value) < (Punkte +(1000-value) * 0.66 ) ){
    	acceptOffer = false;
    }
    
    
    if(acceptOffer){// ausgabe
        // Akzeptiere Angebot.
        sende( "JA" );
    }else{
		// Lehne Angebot an.
		sende( "NEIN" );
    
    }
    
    return true;
}

void otherBotAcceptedOffer()
{
	Rise = false;	// sobald der gegner annahm angebot nicht weiter erhöhen.
	AcceptedPreLastOffer = AcceptedLastOffer; // weiterschiebern der letzten ergebnisse
	AcceptedLastOffer = true;
	PreLastAcceptedOffer = LastAcceptedOffer;
	LastAcceptedOffer = LastOffer;
	if(LastAcceptedOffer < LowestAcceptedOffer) // wenn das letzte akzeptierte angebot kleiner war als das niedrigste akzeptierte angebot
		LowestAcceptedOffer = LastAcceptedOffer; // dann setze es als das nidrigste.
	
}

void otherBotDeclinedOffer()
{	
	AcceptedPreLastOffer = AcceptedLastOffer; // weiter schieben der lezten ergebnisse
	AcceptedLastOffer = false;
	
	if( (!AcceptedLastOffer) && (!AcceptedPreLastOffer)){ // wenn er 2 mal hinter einander ablehnte dann steige weiter.
						// besser doch nicht
	//	Rise = true;  
	}
}

void addPoints(int  value )
{
	Punkte += value;
	PunkteGegner += (1000-value);		
	
}


void switchaction(MessageId id, int value)
{
	int retValue = 0;
	switch (id)
	{
		case MESSAGE_ID_IGNORE:
		{
			// Nachricht soll ignoriert werden.
			retValue = true;
			break;
       	}
		case MESSAGE_ID_ROUNDS:
		{
			// Anzahl der Runden (value ist gesetzt)
			Runden = value;
			retValue = true;
			break;
		}
        case MESSAGE_ID_ACT_ROUND:
        {
			Runde++;

			// Wir pruefen noch, ob die aktuelle Rundenanzahl
			// der uebermittelten entspricht.
			// assert ( Runde == value );
			retValue = ( Runde == value );
            break;
        }
        case MESSAGE_ID_START:
        {
            retValue = calculateAndOfferPoints();
            break;
        }
        case MESSAGE_ID_EXIT:
        {
            // Gesamtes Spiel beenden.
            retValue = true;
            break;
        }
        case MESSAGE_ID_OFFER:
        {
            // Angebot des Gegners (value ist gesetzt)
            retValue = acceptOrDeclineOffer( value );
            break;
        }
        case MESSAGE_ID_ACCEPTED:
        {
            // Gegner hat eigenes Angebot angenommen
            otherBotAcceptedOffer();
            retValue = true;
            break;
        }
        case MESSAGE_ID_DECLINED:
        {
            // Gegner hat eigenes Angebot abgelehnt
            otherBotDeclinedOffer();
            retValue = true;
            break;
        }
        case MESSAGE_ID_POINTS:
        {
            // Erhaltene Punkte (value ist gesetzt)
            addPoints( value );
            retValue = true; 
            break;
        }
        case MESSAGE_ID_INVALID:
        {
            // Ungueltige Nachricht
            std::ostringstream out;
            out << "(EE) " << " Bot::processMessage"
                      << " Empfangene Nachricht ist ungueltig."
                      << std::endl;
            std::cerr << out.str();
            retValue = false;
            break;
        }
        default:
        {
            // Kommando nicht verstanden!
            std::ostringstream out;
            out<< "(EE) "  << " Bot::processMessage"
                      << " Nachricht "
                      << " nicht verstanden."
                      << std::endl;
            std::cerr << out.str();
            retValue = false;
            break;
		}
	}
	//return retValue
}

int main(void){
	int retValue = 0;
	
	MessageId id = MESSAGE_ID_IGNORE;
	int value = 0;
	//int * val = 0;
	
	do{
		lese(value, id); // lesen der daten speichern in value und id
		//value = *val;
		switchaction(id, value);
		
	}while(id != MESSAGE_ID_EXIT);
	

	return retValue;
}
