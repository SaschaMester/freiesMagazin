#!/usr/bin/env python
#------------------------------------------------------------------
#    (C) Copyright 2011 Tom Richter
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as
#    published by the Free Software Foundation; either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public
#    License along with this program. If not, see
#    <http://www.gnu.org/licenses/>.
#------------------------------------------------------------------

import sys
import logging
import numpy as np
from random import seed, random, randint

LOGGING = False
log = logging.getLogger('ultimatum')

HIS_MARGINS = np.array((
        0, 50, 100, 150, 200, 250, 300, 350, 400, 450, 495, 500, 1001))
ANSWER_GUIDE = np.array((
        0., 0.02, 0.1, 0.25, 0.4, 0.45, 0.52, 0.6, 0.82, 0.93, 0.993, 1.0))
MY_MARGINS = np.array((
        0, 50, 100, 150, 200, 250, 275, 300, 325, 350, 375, 400, 425, 450,
        475, 490, 500, 501, 510, 600))
OFFER_GUIDE = np.array((
        0., 0.0001, 0.001, 0.01, 0.05, 0.08, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5,
        0.65, 0.8, 0.9, 1.5, 2.0, 3.0))


def random_bool(prop=0.5):
    if random() < prop:
        return True
    else:
        return False


class TestBot(object):
    def __init__(self, rounds):
        self.rounds = rounds
        self.round = None
        self.my_points = 0
        self.his_points = 0
    def answer(self, offer):
        return True
    def offer(self):
        return 500
    def process_answer(self, answer):
        return

class AcceptBot(TestBot):
    pass

class RandomBot(TestBot):
    def answer(self, offer):
        return random_bool()
    def offer(self):
        return randint(0, 1000)

class DeclineBot(TestBot):
    def answer(self, offer):
        return False

class Offer800Bot(TestBot):
    def offer(self):
        return 800

class Offer200Bot(TestBot):
    def offer(self):
        return 200

class Offer200SeldomBot(TestBot):
    def offer(self):
        return 800 - random_bool(0.01) * 600


class MyBot(object):
    def __init__(self, rounds):
        seed()
        self.rounds = rounds
        self.round = None
        self.my_points = 0
        self.his_points = 0
        self.my_offers = np.empty(rounds, 'int')
        self.his_offers = np.empty(rounds, 'int')
        self.my_answers = np.empty(rounds, 'bool')
        self.his_answers = np.empty(rounds, 'bool')

        self.his_margins = HIS_MARGINS
        self.answer_guide = ANSWER_GUIDE.copy()
        self.answer_occurrences = np.zeros(len(self.answer_guide))
        self.my_margins = MY_MARGINS
        self.offer_guide = OFFER_GUIDE.copy()
        self.offer_expectations = np.zeros(len(self.offer_guide))
        self.counter = 0

    def answer(self, offer):
        # at first 20% of the rounds and in the middle use defined answer_guide 
        if (self.round < 0.2 * self.rounds or
            (0.58 * self.rounds < self.round < 0.60 * self.rounds)):
            self.answer_guide[:] = ANSWER_GUIDE
        # at 88% of game increase chance of accepting offers above 100
        elif (0.88 * self.rounds < self.round < 0.90 * self.rounds):
            self.answer_guide[:] = ANSWER_GUIDE
            self.answer_guide[3:] += 0.2
        # adapt answer_guide:
        # if other bot prefers offers accept them more often
        # if other bot neglects small offers decline them more often            
        elif int(0.05 * self.rounds) > 0 and self.round % int(0.05 * self.rounds):
            if self.round < 0.60 * self.rounds:
                factor = 2.1 - 0.1 * (self.round // int(0.05 * self.rounds) - 3)
            else:
                factor = 2.2 - 0.2 * (self.round // int(0.05 * self.rounds) - 12)
            if factor < 1.3:
                factor = 1.3
            if self.round < 0.90 * self.rounds:
                self.analyse_answer_expectations(factor, 2.)
            else:
                self.analyse_answer_expectations(factor, 100.)
        # answer according to data in answer_guide and his_margins
        prop = self.answer_guide[self.his_margins[:-1] <= offer][-1]
        answer = random_bool(prop)
        if answer:
            self.my_points += offer
            self.his_points += 1000 - offer
        self.his_offers[self.round] = offer
        self.my_answers[self.round] = answer
        return answer

    def offer(self):
        offer_determined = False
        # at first 5% of the rounds and in the middle use defined answer_guide 
        if (self.round < 0.05 * self.rounds or
            (0.51 * self.rounds < self.round < 0.53 * self.rounds)):
            self.counter = 0
            self.offer_guide[:] = OFFER_GUIDE

        else:
            self.analyse_offer_expectations()
            # return offer with highest expected gain (>490)
            if 490 < np.max(self.offer_expectations) or self.counter > 10:
                ind = np.argmax(self.offer_expectations)
                offer = randint(self.my_margins[ind],
                                self.my_margins[ind + 1] - 1)
                offer_determined = True
            # try to offer even more than 500 for uncooperative bots
            else:
                self.counter += 1
                if 440 < np.max(self.offer_expectations) <= 490:
                    self.offer_guide[:] = OFFER_GUIDE - 0.5
                elif 350 < np.max(self.offer_expectations) <= 440:
                    self.offer_guide[:] = OFFER_GUIDE - 1.
                elif np.max(self.offer_expectations) <= 350:
                    self.offer_guide[:] = OFFER_GUIDE - 2.
        # return offer according to data in offer_guide and my_margins                    
        if not offer_determined:
            ind = (np.nonzero(random() < self.offer_guide))[0][0]
            offer = randint(self.my_margins[ind], self.my_margins[ind + 1] - 1)
        self.my_offers[self.round] = offer
        return offer

    def process_answer(self, answer):
        self.his_answers[self.round] = answer
        if answer:
            self.my_points += 1000 - self.my_offers[self.round]
            self.his_points += self.my_offers[self.round]
        if LOGGING and self.round > 1:
            self.log_things()

    def analyse_offer_expectations(self):
    # calculate from previous rounds what can be expected to gain when offering
        my_offers = self.my_offers[:self.round - 1]
        his_answers = self.his_answers[:self.round - 1]
        for i in range(len(self.offer_guide)):
            ind = np.nonzero(np.logical_and(self.my_margins[i] <= my_offers,
                                            my_offers < self.my_margins[i + 1]))
            if np.sum(his_answers[ind]) > 0 and len(ind[0]) > 1:
                self.offer_expectations[i] = np.sum(
                        1000. - my_offers[ind][his_answers[ind]]) / len(ind[0])

    def analyse_answer_expectations(self, factor=2., factor2=5.):
        round = self.round - 1
        my_answers = self.my_answers[:round]
        his_offers = self.his_offers[:round]
        N = len(self.answer_guide)
        theo_answer_occurence = np.zeros(N)
        # sum up occurrences of offers made by other bot
        for i in range(N):
            ind = np.nonzero(np.logical_and(self.his_margins[i] <= his_offers,
                                        his_offers < self.his_margins[i + 1]))
            if len(ind[0]) > 0:
                self.answer_occurrences[i] = 1. * len(ind[0]) / round
        # if some offers are preferred by the other bot, accept them more often
        for i in range(N):
            if self.answer_occurrences[i] > factor * self.answer_guide[i]:
                self.answer_guide[i:] += ((0.95 * factor - 1.) *
                                          self.answer_guide[i])
        # if small offers are neglected by the other bot, decline them more often
        for i in range(N):
            if (self.his_margins[i + 1] < 350 and
                self.answer_occurrences[i] < self.answer_guide[i] / factor2):
                self.answer_guide[i] /= 0.4 * factor2

    def log_things(self):
        round = self.round - 1
        my_offers = self.my_offers[:round ]
        his_answers = self.his_answers[:round ]
        his_offers = self.his_offers[:round ]
        my_answers = self.my_answers[:round ]
        log.info('        cumulated probability vs expected gain for my offer')
        for i in range(len(self.my_margins) - 1):
            log.info('my offer<%d: %.2f  %d' %
                     (self.my_margins[i + 1], self.offer_guide[i],
                      self.offer_expectations[i]))
        log.info('occurrence vs probability of acceptance vs expected answer'
                 'gain for his offer')
        for i in range(len(self.his_margins) - 1):
            answer_expectations = self.answer_guide[i] * (1000 - 0.5 * (
                            self.his_margins[i + 1] + self.his_margins[i] - 1))
            log.info('his offer<%d: %.2f   %.2f  %d' %
                     (self.his_margins[i + 1], self.answer_occurrences[i],
                      self.answer_guide[i], answer_expectations))
        log.info('Gain per round      He  I')
        log.info('My offer           %d   %d' %
                 (np.sum(my_offers[his_answers]) / round,
                  (np.sum(1000 - my_offers[his_answers]) / round)))
        log.info('His offer          %d   %d' %
                 (np.sum(1000 - his_offers[my_answers]) / round,
                  (np.sum(his_offers[my_answers]) / round)))


def run(Bot):
    """Init Bot instance and communicate with game script."""
    log.info('START')
    while(True):
        current_line = raw_input()
        log.info(current_line)
        parts = current_line.split()
        com = parts[0]
        if len(parts) == 2:
            value = int(parts[1])
        if com == 'RUNDEN':
            bot = Bot(value)
        elif com == 'RUNDE':
            bot.round = value - 1
        elif com == 'START':
            offer = bot.offer()
            log.info('BOT ANGEBOT: %d' % offer)
            print(offer)
            sys.stdout.flush()
        elif com in 'ANGEBOT':
            answer = bot.answer(value)
            answer = 'JA' if answer else 'NEIN'
            log.info('BOT ANTWORT: %s' % answer)
            print(answer)
            sys.stdout.flush()
        elif com in ('JA', 'NEIN'):
            bot.process_answer(com == 'JA')
        elif com == 'PUNKTE':
            pass
        elif com == 'ENDE':
            log.info('RESULT: %d VS %d' % (bot.my_points, bot.his_points))
            break


if __name__ == '__main__':
    try:
        arg = sys.argv[1]
    except IndexError:
        arg = 'MyBot'
    if LOGGING:
        logging.basicConfig(filename='log_%s.txt' % arg, filemode='w',
                            level=logging.DEBUG)
    run(eval(arg))
