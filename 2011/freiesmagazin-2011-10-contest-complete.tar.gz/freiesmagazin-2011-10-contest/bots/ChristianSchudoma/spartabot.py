#!/usr/bin/env python

import re
import sys

'''
 spartabot.py -- A very short and simple bot submitted to
 the 4th freiesmagazin.de programming challenge 
 
 Copyright (C) 2011 Christian Schudoma (chris@darkjade.net)

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>. 
'''

LOWEST_OFFER_ACCEPTED = 300
MY_OFFER = 300
OFFER_REGEX = re.compile('ANGEBOT [0-9]{1,4}')

REPLY_REFUSE_OFFER = 'NEIN'
REPLY_ACCEPT_OFFER = 'JA'

def main(argv):
    
    while True:
        
        command = sys.stdin.readline()
        if not command:
            break
        command = command.strip()
        
        if OFFER_REGEX.search(command):
            offer = int(command.split()[1])
            reply = REPLY_REFUSE_OFFER
            if offer >= LOWEST_OFFER_ACCEPTED:
                reply = REPLY_ACCEPT_OFFER
            sys.stdout.write('%s\n' % reply)
            sys.stdout.flush()
        elif 'START' in command:
            offer = MY_OFFER
            sys.stdout.write('%s\n' % offer)
            sys.stdout.flush()
        elif 'ENDE' in command:
            break
        else:
            """ We don't care for the the other commands. """
            continue
        
        
    return None
                

if __name__ == '__main__': main(sys.argv)
