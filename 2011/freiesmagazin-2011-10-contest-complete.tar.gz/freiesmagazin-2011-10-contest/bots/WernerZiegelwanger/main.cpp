/**
 (C) Copyright 2011 Werner Ziegelwanger, MSc
 
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU Lesser General Public License as
 published by the Free Software Foundation; either version 3 of the
 License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 GNU Lesser General Public License for more details.
 
 You should have received a copy of the GNU Lesser General Public
 License along with this program. If not, see
 <http://www.gnu.org/licenses/>.
 */
#include "bot.hh"

#include <iostream>
#include <sstream>

LOG_DECLARE;

int main( int argc, char* argv[] )
{
    int retValue = 0;
    int value = 0;
    
    std::string message;
    bool exit = true;
    
    Bot b;
    
    //init Logging
    if(debug){
        LOG_INIT("unibot.csv");
        LOG_MSG("Bot gestartet");
    }
    
    do{
        getline(std::cin, message);
        
        if(message.compare(0,6, "RUNDEN")==0){
            // Anzahl der zu spielenden Runden
            std::istringstream in(message.substr(6, std::string::npos));
            in >> value;
            b.setRunden(value);
        }
        else if(message.compare(0,5, "RUNDE") == 0){
            // Aktuelle Runde.
            std::istringstream in( message.substr( 5, std::string::npos ) );
            in >> value;
            b.setRunde(value);
        }
        else if ( message.compare("START") == 0 )
        {
            // Bot soll etwas anbieten (neue Runde).
            std::cout << b.calculateOfferedPoints() << std::endl;
        }
        else if ( message.compare("ENDE") == 0 )
        {
            // Bot soll verlassen werden.
            exit = false;
        }
        else if ( message.compare(0, 7, "ANGEBOT") == 0 )
        {
            // Uns wird ein bestimmter Betrag angeboten.
            // Den wandeln wir erst in eine Zahl.
            int value;
            
            std::istringstream in( message.substr( 7, std::string::npos ) );
            in >> value;
            
            if(b.acceptOrDeclineOffer(value))
                std::cout << "JA" << std::endl;
            else
                std::cout << "NEIN" << std::endl;
        }
        else if ( message.compare(0, 6, "PUNKTE") == 0 )
        {
            // Der Server teilt uns mit, wie viele Punkte wir
            // wirklich erhalten.
            std::istringstream in( message.substr( 6, std::string::npos ) );
            in >> value;
            b.setPunkte(value);
        }
        else if ( message.compare("JA") == 0 )
        {
            // Angebot wurde angenommen.
            b.acceptOffer(true);
        }
        else if ( message.compare("NEIN") == 0 )
        {
            // Angebot wurde abgelehnt.
            b.acceptOffer(false);
        }
    }while(exit);
    
    if(debug)
        LOG_MSG("Bot beendet");
        
    return retValue;
}
