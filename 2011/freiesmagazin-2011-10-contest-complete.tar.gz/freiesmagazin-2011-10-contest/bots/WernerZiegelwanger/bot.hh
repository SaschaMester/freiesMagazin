/**
 (C) Copyright 2011 Werner Ziegelwanger, MSc
 
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU Lesser General Public License as
 published by the Free Software Foundation; either version 3 of the
 License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 GNU Lesser General Public License for more details.
 
 You should have received a copy of the GNU Lesser General Public
 License along with this program. If not, see
 <http://www.gnu.org/licenses/>.
 */
#ifndef BOT_HH
#define BOT_HH

#include "globals.hh"
#include "botinfo.hh"

class Bot{
private:
    //Variablen
    int runden;
    int runde;
    int punkte;
    
    int schrittweite;
    int rundenIndexAnnahme;
    int rundenIndexAngebot;
    int bestAngebot;
    
    //Angebot
    int aktuellesAngebot;       //das von mir aktuell getätigte Angebot
    Botinfo info;
    
    //Annahme
    int aenderungAnnahme;
    int minA;
    bool bminA;
public:
    //Konstruktor
    Bot();
    
    int calculateOfferedPoints();
    bool acceptOrDeclineOffer(const int value);
    
    void acceptOffer(bool value);
    
    //get und setter
    void setRunden(int r);
    void setRunde(int r);
    void setPunkte(int p);
};

#endif // BOT_HH
