/**
 (C) Copyright 2011 Werner Ziegelwanger, MSc
 
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU Lesser General Public License as
 published by the Free Software Foundation; either version 3 of the
 License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 GNU Lesser General Public License for more details.
 
 You should have received a copy of the GNU Lesser General Public
 License along with this program. If not, see
 <http://www.gnu.org/licenses/>.
 */
#ifndef BOTINFO_HH
#define BOTINFO_HH

#include "counter.hh"
#include <list>
#include <algorithm>

class Botinfo{
        
public:
    //Konstruktor
    Botinfo(){}
    
    void sortAngebotListWert(){angebotList.sort(nachWert);}
    void sortAngebotListCountJa(){angebotList.sort(nachJa);}
    void sortAngebotListCountNein(){angebotList.sort(nachNein);}
    
    void sortAngebotListGewichtet(){angebotList.sort(gewichtet);}
    int summeAbgelehnt(){
        int ret=0;
        for(std::list<Counter>::iterator it = angebotList.begin(); it!=angebotList.end(); it++)
            ret += (*it).counterNein;
        return ret;
    };
    int summeAngenommen(){
        int ret=0;
        for(std::list<Counter>::iterator it = angebotList.begin(); it!=angebotList.end(); it++)
            ret += (*it).counterJa;
        return ret;
    };

    std::list<Counter> angebotList;
private:
    //Sortiermethoden
    //gewichtet
    static bool gewichtet (Counter first, Counter second){
        if(first.wert + first.counterJa * gewichtungJa - first.counterNein * gewichtungNein < second.wert + first.counterJa * gewichtungJa + first.counterNein * gewichtungNein)
            return false;
        else
            return true;
    }
    
    //nach Wert
    static bool nachWert (Counter first, Counter second)
    {
        if(first.wert < second.wert)
            return true;
        else return false;
    }
    
    //nach Anzahl
    static bool nachJa (Counter first, Counter second)
    {  
        if(first.wert < second.wert)
            return false;
        else
            return true;
       /* bool ret = false;
        
        if((first.counterJa == 0) && (second.counterJa > 0))
            ret = true;
        else{
            if((first.counterJa > second.counterJa) && 
               (first.wert < second.wert))
                    ret = true;
            if((first.counterJa == second.counterJa) &&
               (first.wert > second.wert))
                    ret = true;
        }

        return !ret;*/
    }
    
    static bool nachNein (Counter first, Counter second)
    {
        if(first.counterNein == second.counterNein)
        {
            if(first.wert < second.wert)
                return true;
            else
                return false;
        }
        else{
            if(first.counterNein < second.counterNein)
                return true;
            else 
                return false;
        }
    }
};

#endif