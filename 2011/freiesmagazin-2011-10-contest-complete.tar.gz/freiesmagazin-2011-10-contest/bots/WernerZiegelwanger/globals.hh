/**
 (C) Copyright 2011 Werner Ziegelwanger, MSc
 
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU Lesser General Public License as
 published by the Free Software Foundation; either version 3 of the
 License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 GNU Lesser General Public License for more details.
 
 You should have received a copy of the GNU Lesser General Public
 License along with this program. If not, see
 <http://www.gnu.org/licenses/>.
 */
#ifndef GLOBALS_HH
#define GLOBALS_HH

#include "Log.h"

//Annahme
const static int minAnnahme = 450;
const static int streuungAnnahme = 51;

//Angebot lernen
const static int minAngebot = 499;
const static int angebotStreuung = 51;
const static int lern1 = 50;
const static int lern2 = 200;
const static int lern3 = 400;
const static int lern4 = 350;
const static int lern5 = 450;
const static int lern6 = 300;
const static int lern7 = 150;
const static int lern8 = 250;
const static int lern9 = 100;
const static int streuung = 50;
const static int gewichtungJa  = 60;
const static int gewichtungNein = -100;

const static bool debug = false;
#endif