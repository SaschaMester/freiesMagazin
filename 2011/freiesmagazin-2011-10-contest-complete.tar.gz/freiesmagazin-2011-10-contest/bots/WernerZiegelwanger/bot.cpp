/**
 (C) Copyright 2011 Werner Ziegelwanger, MSc
 
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU Lesser General Public License as
 published by the Free Software Foundation; either version 3 of the
 License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 GNU Lesser General Public License for more details.
 
 You should have received a copy of the GNU Lesser General Public
 License along with this program. If not, see
 <http://www.gnu.org/licenses/>.
 */
#include "bot.hh"
#include <string>

LOG_USE();

Bot::Bot(){
    runden = 0;
    runde = 0;
    punkte = 0;
    schrittweite = 50;
    rundenIndexAnnahme = -1;
    rundenIndexAngebot = -1;
    bestAngebot = 0;
    aenderungAnnahme = 0;
    minA = minAnnahme;
    bminA = false;
}

//Anzahl an Runden setzen
void Bot::setRunden(int r){
    info.angebotList.clear();
    runden = r;
}

//Runde hat sich geändert
void Bot::setRunde(int r){
    runde = r;
    rundenIndexAnnahme = runde - 1;
    rundenIndexAngebot = runde -1;
}

//Eigene Punkte aktualisieren
void Bot::setPunkte(int p){punkte = p;}


//Wird das eigene Angebot angenommen oder abgelehnt???
void Bot::acceptOffer(bool value){
    bminA = value;
    char buffer[50];
    char cvalue = 'N';
    if(value)
        cvalue = 'J';
    
    //ist die Liste leer einfach das Element einfügen.
    if(info.angebotList.empty()){
        if(debug){
            sprintf(buffer, "erstes Angebot: %d %c", aktuellesAngebot, cvalue);
            LOG_ANGEBOT(buffer);
        }
        Counter c;
        c.wert = aktuellesAngebot;
        if(value)
            c.counterJa++;
        else
            c.counterNein++;
        info.angebotList.insert(info.angebotList.end(), c);
    }
    else{
        //Liste durchgehen und nach aktuellem Wert suchen
        std::list<Counter>::iterator iter;
        bool ok = false;
        
        for(std::list<Counter>::iterator list_iter = info.angebotList.begin(); 
            list_iter != info.angebotList.end(); list_iter++)
        {
            if((*list_iter).wert == aktuellesAngebot){
                iter = list_iter;
                ok = true;
                break;
            }
        }
        
        //gibt es diesen Wert schon
        if(ok){
            if(value)
                (*iter).counterJa++;
            else
                (*iter).counterNein++;
        }
        //nein, neuen Wert einfügen
        else{
            Counter c;
            c.wert = aktuellesAngebot;
            if(value)
                c.counterJa++;
            else
                c.counterNein++;
            info.angebotList.insert(info.angebotList.end(), c);
        }
        if(debug){
            sprintf(buffer, "%d. Angebot Bot: %d %c", runde, aktuellesAngebot, cvalue);
            LOG_ANGEBOT(buffer);
        }
    }
}

//Eigenes Angebot abgeben
int Bot::calculateOfferedPoints(){
    //in der ersten Runde ein Angebot machen
    if(runde == 1){
        aktuellesAngebot = minAngebot;
        return aktuellesAngebot;
    }
    //lernen mit sinnvollen Testwerten
    if(runde==2){aktuellesAngebot = lern1;return aktuellesAngebot;}
    if(runde==3){aktuellesAngebot = lern2;return aktuellesAngebot;}
    if(runde==4){aktuellesAngebot = lern3;return aktuellesAngebot;}
    if(runde==5){aktuellesAngebot = lern4;return aktuellesAngebot;}
    if(runde==6){aktuellesAngebot = lern5;return aktuellesAngebot;}
    if(runde==7){aktuellesAngebot = lern6;return aktuellesAngebot;}
    if(runde==8){aktuellesAngebot = lern7;return aktuellesAngebot;}
    if(runde==9){aktuellesAngebot = lern8;return aktuellesAngebot;}
    if(runde==10){aktuellesAngebot = lern9;return aktuellesAngebot;}
    if(runde>10){
        //bei den anderen Runden ergibt sich das Angebot an die vorangegangegen Angebote
        info.sortAngebotListWert();
        aktuellesAngebot = -1;
        for(std::list<Counter>::iterator list_iter = info.angebotList.begin(); 
            list_iter != info.angebotList.end(); list_iter++)
        {
            if(((*list_iter).counterJa > 0) && ((*list_iter).counterNein < (*list_iter).counterJa)){
                aktuellesAngebot = (*list_iter).wert;
                break;
            }
        }

        if(debug){
            char buffer[50];
            sprintf(buffer, "%d. Angebot: Bot best: %d", runde, aktuellesAngebot);
            LOG_ANNAHME(buffer);
        }
        //den am häufigsten angenommenen besten Wert nehmen
        /*if(aktuellesAngebot > 0)
            //in jeder 4. Runde einen Zufallswert in diesem Bereich nehmen
            if(runde%50==0 && runde < 400){
                aktuellesAngebot -= (rand()%streuung);
                //bei Zufallsbots kann man ins Negative rutschen, also immer 0 bieten
                if(aktuellesAngebot < 0)
                    aktuellesAngebot = 0;
                if(aktuellesAngebot > 499)
                    aktuellesAngebot = 499;
            }*/
        //falls noch keiner angenommen wurde: Zufallswert!
        if(aktuellesAngebot < 0 || aktuellesAngebot > minAngebot){
            aktuellesAngebot = minAngebot;
        }
    }
    
    return aktuellesAngebot;
}

//Fremdes Angebot annehmen oder Ablehnen
bool Bot::acceptOrDeclineOffer(const int value){
    bool acceptOffer = false;
    
    if(value > minA)
        acceptOffer = true;
    else
        if(value > aktuellesAngebot && bminA)
            acceptOffer = true;
    
    if(debug){
        char buffer[50];
        char cvalue = 'N';
        if(acceptOffer)
            cvalue = 'J';
        sprintf(buffer, "%d. Annehmen: %d %c", runde, value, cvalue);
        LOG_ANNAHME(buffer);
    }
    
    return acceptOffer;
}