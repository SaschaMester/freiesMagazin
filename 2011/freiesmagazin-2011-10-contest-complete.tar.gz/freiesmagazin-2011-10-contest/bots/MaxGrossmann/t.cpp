//		MGBot 1.0, written for http://freiesmagazin.de/vierter_programmierwettbewerb
//		(c) Max R. P. Grossmann, 2011. Version: 2011-10-23, 12:17
//
//      Redistribution and use in source and binary forms, with or without
//      modification, are permitted provided that the following conditions are
//      met:
//      
//      * Redistributions of source code must retain the above copyright
//        notice, this list of conditions and the following disclaimer.
//      * Redistributions in binary form must reproduce the above
//        copyright notice, this list of conditions and the following disclaimer
//        in the documentation and/or other materials provided with the
//        distribution.
//      * Neither the name of the  nor the names of its
//        contributors may be used to endorse or promote products derived from
//        this software without specific prior written permission.
//      
//      THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
//      "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
//      LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
//      A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
//      OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//      SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//      LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
//      DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
//      THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//      (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//      OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//      


#include <iostream>

class MGBot {
	public:
	 MGBot();
	 ~MGBot();
	 bool Offered(const int val);
	 int Offer(const unsigned char goodbot);
	 void RenewMoney(const int val);
	 int MuchMoney(void);
	 int bonus;
	 
	private:
	 int money;
};

MGBot::MGBot() {
	// do nothing
	bonus = 0;
}

MGBot::~MGBot() {
	// when you say nothing at all
}

bool MGBot::Offered(const int val) {
	if (val > 295) {
		return true;
	}
	else {
		return false;
	}
}

int MGBot::Offer(const unsigned char goodbot) {
	return (goodbot%2 == 1) ? 306+goodbot+bonus : 300+bonus;
}

void MGBot::RenewMoney(const int val) {
	money += val;
}

int MGBot::MuchMoney(void) {
	return money;
}

using namespace std;

int main(void) {
	MGBot fbot;
	string command;
	int x, r=1, r_max=2500;
	unsigned char good=0;
	
	while (r <= r_max) {
		cin >> command;
		
		if (command == "RUNDEN" || command == "RUNDE"
		    || command == "ANGEBOT" || command == "PUNKTE") {
				cin >> x;
		}
		
		if (command == "RUNDEN") r_max = x;
		else if (command == "RUNDE") {
			// do nothing
		}
		else if (command == "ANGEBOT") {
			if (fbot.Offered(x) == true) {
				cout << "JA" << endl;
			}
			else {
				cout << "NEIN" << endl;
			}
		}
		else if (command == "PUNKTE") {
			fbot.RenewMoney(x);
			// cerr << fbot.MuchMoney() << endl;
		}
		else if (command == "START") {
			cout << fbot.Offer(good) << endl;
		}
		else if (command == "ENDE") {
			break;
		}
		else if (command == "JA") {
			// very nice
		}
		else if (command == "NEIN") {
			if (fbot.bonus > -200) fbot.bonus -= 8;
			else fbot.bonus = 0;
		}
		
		good += 3;
	}
}
