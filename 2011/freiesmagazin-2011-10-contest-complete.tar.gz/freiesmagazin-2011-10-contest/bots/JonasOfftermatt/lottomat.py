#!/usr/bin/python3
# Bot fuer Freies Magazin Wettbewerb Nr. 4
# Bot bekommt Nachricht ueber std in und std out

##    (C) Copyright 2011 Jonas Offtermatt
##
##    This program is free software; you can redistribute it and/or modify
##    it under the terms of the GNU Lesser General Public License as
##    published by the Free Software Foundation; either version 3 of the
##    License, or (at your option) any later version.
##
##    This program is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
##    GNU Lesser General Public License for more details.
##
##    You should have received a copy of the GNU Lesser General Public
##    License along with this program. If not, see
##    <http://www.gnu.org/licenses/>.
##


import random
   


# einfache Funktion die message sendet
# kann nur Ja oder Nein
# alles andere wird direkt ausgegeben
def send_message(message):
    if message=='yes':
        print('JA')
    elif message=='no':
        print('NEIN')
    else:
        print(message)


# funktion die ein Angebot erstellt
# in den ersten 30 Runden wird der Gegner gelernt
# danach anhand seiner decision boundary ein Angebot unterbreitet
def make_offer(data):
    # die ersten 30 Runden einfach zufallsangebote
    if data.act_round <= 30:
        i=data.act_round-1
        offer=data.inputs[i]
    else:
        # decision boundary des gegners bestimmen
        d=data.calc_dec_bound(data)
        d+=100 #konstante addieren um mehr angenommene angebote zu erhalten
        # mehr wie 600 + varianz gibt es nicht!
        if d > 600:
            d=600
        if (len(data.inputs) >= 50):
            del data.inputs[0]
            del data.outputs[0]
        var=int(30*(1-(data.accepts/data.act_round))*(1-(data.accepts/data.act_round)))
        a=max(0,(int(d)-var))
        b=min(1000,(int(d)+var))
        offer=random.randint(a,b)
        data.inputs.append(offer)
    send_message(offer)
    

# funktion verarbeitet erhaltenes angebot
def check_offer(message,data):
    value=int(message[1])
    # alle 15 runden schauen, ob wir weniger oder doch
    # mehr verlangen sollen
    if (data.act_round%15==0):
        if (sum(data.decisions[-15:])>=10) and (data.own_bound < 600):
            data.own_bound+=25
        if (data.act_round%15==0) and (data.own_bound > 200):
            if (sum(data.decisions[-15:])<=5):
                data.own_bound-=25
    # weniger wie 200 nehmen wir grundsaetzlich nicht an        
    if  (value <200):
        data.decisions.append(0)
        data.declines+=1
        send_message('no')
        return
    # falls der Gegner mehr wie 490 bietet und wir das schon 27 mal
    # angenommen haben, wollen wir mehr
    elif (value<data.own_bound) and (value> 490) and (sum(data.decisions[-30:])>=27):
        send_message('no')
        data.declines+=1
        data.decisions.append(0)
        return
    # der Gegner bietet zu wenig
    elif (value<data.own_bound) and (value < 490):
        data.decisions.append(0)
        data.declines+=1
        send_message('no')
        return
    # alles andere nehmen wir gerne
    else:
        send_message('yes')
        data.decisions.append(1)
        return


# verarbeitet den Eingabe Prompt so dass wir ihn verstehen    
def process_message(prompt):
    message=['exit',0]
    prompt=prompt.split()
    if (prompt[0]=='RUNDEN'):
        message=['rounds',prompt[1]]
    elif (prompt[0]=='ENDE'):
        message=['exit',0]
    elif (prompt[0]=='START'):
        message=['start',0]
    elif (prompt[0]=='RUNDE'):
        message=['round',prompt[1]]
    elif (prompt[0]=='ANGEBOT'):
        message=['offer',prompt[1]]
    elif (prompt[0]=='PUNKTE'):
        message=['points',prompt[1]]
    elif (prompt[0]=='JA'):
        message=['yes',0]
    elif (prompt[0]=='NEIN'):
        message=['no',0]
    else:
        print('Message:',prompt,'verstehe ich nicht')

    return(message)

# fuehrt handlungen entsprechend der message aus
def handle_message(message,data):
    # message enthaelt die Nachricht vom Server
    # data ist Klasse mit allen verfuegbaren Spieldaten
    if message[0] == 'rounds':
        data.max_rounds = int(message[1])
    elif message[0] == 'exit':
        # falls am Ende die aktuellen Spieldaten gespeichert
        # werden sollen, naechste Zeile auskommentieren
        #data.save(data,'datendecbound.txt')
        pass
    elif message[0] == 'start':
        make_offer(data)
        # falls nach jeder Runde gespeichert werden soll
        # naechste Zeile auskommentieren
        #data.save(data,'daten.txt')
    elif message[0] == 'round':
        data.act_round = int(message[1]);
    elif message[0] == 'offer':
        if len(data.decisions)>=50:
            del data.decisions[0]
            del data.offers[0]
        data.offers.append(int(message[1]))
        check_offer(message,data)
    elif message[0] == 'points':
        data.points+=int(message[1])
    elif message[0] == 'yes':
        data.outputs.append(1)
        data.accepts+=1
    elif message[0] == 'no':
        data.outputs.append(0)
    else:
        pass
        


# hier kommt jetzt der eigentliche Bot
def main(message='1'):
    # daten klasse um aktuellen Spielverlauf zu speichern
    class Daten(object):
        max_rounds=0
        act_round=0
        points=0
        # angebote an gegner
        inputs=list(range(100,610,17))
        # entscheidungen des Gegners
        outputs=[]
        #Angebote an mich
        offers=[]
        # meine Entscheidungen
        decisions=[]
        # decision boundary des gegners
        dec_bound= 0
        # eigene decision boundary
        own_bound= 250
        # gegner akzeptiert angebot
        accepts=0
        # ich lehne angebot ab
        declines=0
        # klassenfunktion um daten zu speichern
        def save(self,file,newline=None):
            target=open(file,'a')
            print('Aktuelle Runde:',self.act_round,file=target)
            print('Gespielte Runden',self.max_rounds,file=target)
            print('Erreichte Punkte:',self.points,file=target)
            print('Gegner nimmt Angebot an',self.accepts,file=target)
            print('Ich lehne Angebot ab',self.declines,'\n',file=target)
            print('Aktuelle Decision Boundary:',self.dec_bound,file=target)
            print('Aktuelle Varianz:',int(30*(1-(data.accepts/data.act_round))),file=target)
            print('Meine aktuelle Decision Boundary:',self.own_bound,'\n',file=target)
            print('Die letzten 50 Angebote an den Gegner\n',self.inputs,'\n',file=target)
            print('Die letzten 50 Entscheidungen des Gegner\n',self.outputs,'\n',file=target)
            print('Die letzten 50 Angebote an mich\n',self.offers,'\n',file=target)
            print('Die letzten 50 Entscheidungen von mir\n',self.decisions,'\n',file=target)
            target.close()
        # klassen funktion um decision boundary zu berechnen
        # ganz simpel mit least squares fit
        def calc_dec_bound(self):
            x2=[]
            xty=[]
            ind=0
            for i in self.inputs:
                x2.append(i*i)
                xty.append(self.inputs[ind]*self.outputs[ind])
                ind+=1
            if (sum(x2)!= 0) and (sum(xty)!=0):
                beta=(1/sum(x2))*sum(xty)
                self.dec_bound=0.5/beta
            else:
                # alle Angebote wurden abgelehnt xty=0
                # oder x2 = 0, nur 0 angeboten
                self.dec_bound=500
            
            return self.dec_bound
    #daten Objekt erzeugen    
    data=Daten
    # die ersten 50 Angebote mischen, damit der Gegner uns nicht so schnell
    # durchschaut
    #muss wohl hier gemacht werden da in class def nicht moeglich
    random.shuffle(data.inputs) 
    #jetzt kommt die haupt schleife, wo die message abgefragt 
    # und antwort gegeben wird
    while (message[0] != 'exit'):
        prompt=input()
        # message uebersetzen+verarbeiten
        message=process_message(prompt)
        # message in handlungen umsetzen
        handle_message(message,data)

# keine Ahnung was die naechsten zwei Zeilen machen, aber ohne sie geht garnix 
if __name__=="__main__":
    main()
