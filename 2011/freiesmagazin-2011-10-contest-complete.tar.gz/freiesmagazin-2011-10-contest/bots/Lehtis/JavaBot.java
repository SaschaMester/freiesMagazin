/**
    (C) Copyright 2011 Lehtis

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class JavaBot {

  public static void main(String[] args) {
    // TODO code application logic here
    int runden = 0; //Anzahl der insgesamt zu spielenden Runden. 
    int runde = 0; //Eine neue Runde startet. Der Rundenzähler beginnt bei 1. 
    int punkte = 0; //Die Engine teilt mit, wie viele Punkte man erhält. 
    int gib = 300; //Der Wert der Angeboten wird.
    int buffer = 0;
    Map<Integer,Integer> bot1 = new LinkedHashMap<Integer,Integer>(); //Bot + Wert
    Scanner scanner = new Scanner(System.in);
    String[] str = null;
            
    do{
      String input = scanner.nextLine();
      str = input.split(" ");
      
      if(str[0].equals("RUNDEN")){
        runden = Integer.parseInt(str[1]);
      }
      if(str[0].equals("RUNDE")){
        runde = Integer.parseInt(str[1]);
      }
      
      if(!bot1.containsKey(runde)) {
        bot1.put(runde,300);
    }
      
      if(str[0].equals("ANGEBOT")){
        int angebotswert = Integer.parseInt(str[1]);
        //Angebot annehmen oder ablehnen
        if(angebotswert > 500)
          System.out.println("JA");
        else
          System.out.println("NEIN");
      }
      if(str[0].equals("PUNKTE")){
        punkte = Integer.parseInt(str[1]);
      }
      if(str[0].equals("START")){
        //Angebot abgeben
        buffer = bot1.get(runde);
        System.out.println(buffer);
      }
      if(str[0].equals("JA")){
        buffer = bot1.get(runde);
        buffer += 10;
        bot1.put(runde,buffer);
      }
      if(str[0].equals("NEIN")){
        buffer = bot1.get(runde);
        buffer -= 50;
        bot1.put(runde,buffer);
      }
    }while(!str[0].equals("ENDE"));
  }
}
