{-

    (C) Copyright 2011 Mathias Nerce <m.nerce@gmail.com> <twitter:@devecce>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

-}


module Main where

import System.IO (hFlush, stdout, withFile, hPutStr, IOMode (WriteMode))
import System.Exit (exitSuccess)
import Control.Monad.State

import GameData
import BotManager


-------------------- impure stuff: IO

main :: IO ()
main = communicate Ready

communicate :: Phase -> IO ()
communicate phase = do
  msg <- getLine
  (\st -> do
      -- uncomment next line to write log file on exit
      -- if (fst st == (Just "bye")) then writelog "transaction.log" (snd st) else return ()
      send $ fst st
      communicate $ snd st
    ) $ runState (process $ parse msg) phase

send :: Reply -> IO ()
send (Just "bye") = exitSuccess
send (Just s) = do { putStrLn s ; hFlush stdout }
send Nothing = return ()

writelog :: String -> Phase -> IO ()
writelog filename ph = withFile filename WriteMode (\handle -> do
                                                       case ph of
                                                         (End gf) -> do
                                                           hPutStr handle (show gf)
                                                           hPutStr handle (show (strategyGains gf) ++ "\n")
                                                   )
