{-

    (C) Copyright 2011 Mathias Nerce <m.nerce@gmail.com> <twitter:@devecce>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

-}


module BotManager where

import Control.Monad.State

import GameData
import BotStrategies


-- parse the server's utterances
parse :: String -> InMessage
parse s = case head $ words s of
  "RUNDEN"  -> Turns turn
  "RUNDE"   -> Turn turn
  "ANGEBOT" -> WantDecision offer
  "START"   -> WantOffer
  "JA"      -> NotifyDecision Yes
  "NEIN"    -> NotifyDecision No
  "PUNKTE"  -> NotifyPoints offer
  "ENDE"    -> Bye
  _         -> error "Protocol violation: Cannot parse message."
  where
    turn = (read (last $ words s) :: Int)
    offer = (read (last $ words s) :: Offer)

-- process incoming messages
process :: InMessage -> State Phase Reply
process (Turns totalTurns) = State $ \ph -> case ph of
  (Ready) -> (Nothing, Go (initGameFacts totalTurns))
  _ -> error "Protocol violation: Unexpected Turns message."
process (Turn turn) = State $ \ph ->
  (Nothing, ph) -- ignore this signal
process (WantOffer) = State $ \ph -> case ph of
  (Go gf) -> (Just (show offer), Pending gf Self offer strategy)
    where strategy = getStrategy gf
          offer = makeOffer gf strategy
  _ -> error "Protocol violation: Unexpected WantOffer message."
process (WantDecision offer) = State $ \ph -> case ph of
  (Go gf) -> (Just (show decision), Wait gf Opponent offer decision strategy)
    where strategy = getStrategy gf
          decision = makeDecision gf offer strategy
  _ -> error "Protocol violation: Unexpected WantDecision message."
process (NotifyDecision decision) = State $ \ph -> case ph of
  (Pending gf src offer strategy) -> (Nothing, Wait gf src offer decision strategy)
  _ -> error "Protocol violation: Unexpected NotifyDecision message."
process (NotifyPoints pts) = State $ \ph -> case ph of
  (Wait gf src offer decision strategy) -> (Nothing, Go (nextTurn gf src offer decision strategy))
  _ -> error "Protocol violation: Unexpected NotifyPoints message."
process (Bye) = State $ \ph -> case ph of
  (Go gf) -> (Just "bye", End gf)
  _ -> error "Protocol violation: Unexpected Bye message."

-- initialize GameFacts: set total turns
initGameFacts :: Int -> GameFacts
initGameFacts turns = (GameFacts [] turns)

-- add newly completed transaction to GameFacts
nextTurn :: GameFacts -> Source -> Offer -> Decision -> Strategy -> GameFacts
nextTurn (GameFacts trs tt) src offer decision strategy = GameFacts trsNew tt
  where trsNew = ((Transaction src offer decision strategy):trs)
