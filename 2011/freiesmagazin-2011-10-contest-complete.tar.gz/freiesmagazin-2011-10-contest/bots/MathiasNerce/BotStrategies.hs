{-

    (C) Copyright 2011 Mathias Nerce <m.nerce@gmail.com> <twitter:@devecce>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

-}


module BotStrategies (getStrategy, makeDecision, makeOffer) where

import GameData


--------------------  strategy manager

getStrategy :: GameFacts -> Strategy
getStrategy gf | firstTurn gf     = StaticGreedy
               | nrTurns gf == 20 = FindEquilibrium
               | nrTurns gf == 50 = TitForTat
               | nrTurns gf == 80 = findBestStrategy gf
               | nrTurns gf == 350 = StatisticsBased
               | (nrTurns gf `mod` 200) == 0 = findBestStrategy gf
               | otherwise = lastStrategy gf

-- return strategy with highest average point gain per turn
findBestStrategy :: GameFacts -> Strategy
findBestStrategy gf = head [ s | (s,g) <- strategyGains gf, g == maximum (map snd $ strategyGains gf) ]


-------------------- reply manager

makeOffer :: GameFacts -> Strategy -> Offer
makeOffer gf strgy = if (firstTurn gf) then oFirst
                     else case strgy of
                       TitForTat -> oTitForTat gf
                       FindEquilibrium -> oFindEquilibrium gf
                       StaticGreedy -> oStaticGreedy gf
                       StatisticsBased -> oStatisticsBased gf

makeDecision :: GameFacts -> Offer -> Strategy -> Decision
makeDecision gf offer strgy = if (firstTurn gf) then dFirst offer
                              else case strgy of
                                TitForTat -> dTitForTat gf offer
                                FindEquilibrium -> dFindEquilibrium gf offer
                                StaticGreedy -> dStaticGreedy gf offer
                                StatisticsBased -> dStatisticsBased gf offer


-------------------- offer strategies

oFirst :: Offer
oFirst = 400

-- blindly repeat the opponent's previous offer
oTitForTat :: GameFacts -> Offer
oTitForTat = lastOffer

-- offer a static value
oStaticGreedy :: GameFacts -> Offer
oStaticGreedy gf = 300

-- offer the smallest value that got accepted in the past (detection by binary search)
-- only makes sense with bots that have a static acceptance threshold
oFindEquilibrium :: GameFacts -> Offer
oFindEquilibrium gf | (maxNo gf) < (minYes gf) = (((maxNo gf) + (minYes gf)) `div` 2) + 1
                    | otherwise = minYes gf

-- offer the smallest value (steps of 10 from minYes) that has no rejection bias
oStatisticsBased :: GameFacts -> Offer
oStatisticsBased gf = head $ filter (\v -> (diffYesNo v gf >= 0)) $ scanl (+) (minYes gf) (repeat 10)


-------------------- decision strategies

-- always accept the first offer
dFirst :: Offer -> Decision
dFirst offer = Yes

-- blindly repeat the opponent's previous decision
dTitForTat :: GameFacts -> Offer -> Decision
dTitForTat gf offer = if lastStrategy gf == TitForTat then lastDecision gf else dFirst offer

-- accept if offer is above some static threshold
dStaticGreedy :: GameFacts -> Offer -> Decision
dStaticGreedy gf offer = if offer >= 399 then Yes else No

-- accept if opponent's offer is at least as high as our last offer
-- or if we have more points in total than the opponent
dFindEquilibrium :: GameFacts -> Offer -> Decision
dFindEquilibrium gf offer = if offer >= lastOffer gf then Yes
                            else if ptsSelf gf >= ptsOpponent gf then Yes
                                 else No

-- like dFindEquilibrium, but handle "stupid" (i.e. non-learning) bots
dStatisticsBased :: GameFacts -> Offer -> Decision
dStatisticsBased gf offer = if offer >= lastOffer gf then Yes
                            else if ptsSelf gf >= ptsOpponent gf then Yes
                                 else if (offer > 199) && (offerNotChangedSince 102 gf) then Yes
                                      else No
