{-

    (C) Copyright 2011 Mathias Nerce <m.nerce@gmail.com> <twitter:@devecce>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

-}

module GameData where


-------------------- data types

type Offer = Int

type Reply = Maybe String

data Source = Self | Opponent deriving (Eq, Show)

data Decision = No | Yes deriving (Eq, Ord)
instance Show Decision where
  show No = "NEIN"
  show Yes = "JA"

data InMessage = Turns Int
               | Turn Int
               | WantDecision Offer
               | WantOffer
               | NotifyDecision Decision
               | NotifyPoints Offer
               | Bye
               deriving (Show)

data Strategy = TitForTat
              | FindEquilibrium
              | StaticGreedy
              | StatisticsBased
              deriving (Eq, Show)

data Phase = Ready
           | Go GameFacts
           | Pending GameFacts Source Offer Strategy
           | Wait GameFacts Source Offer Decision Strategy
           | End GameFacts
           deriving (Show)

data Transaction = Transaction { source :: Source
                               , offer :: Offer
                               , decision :: Decision
                               , strategy :: Strategy
                               } deriving (Eq)
instance Show Transaction where
  show (Transaction src off dec stg) = foldr1 (\w s -> w ++ ',':s) [show src, show off, show dec, show stg]

data GameFacts = GameFacts { transactions :: [Transaction]
                           , totalTurns :: Int
                           } deriving (Eq)
instance Show GameFacts where
  show (GameFacts ts tt) = unlines $ map show ts


-------------------- game constants

minoffer,maxoffer :: Offer
minoffer = 0
maxoffer = 1000


-------------------- utility functions

-- test for availability of transaction history
firstTurn :: GameFacts -> Bool
firstTurn gf = nrTurns gf == 0

-- get number of completed turns (two turns are one round)
nrTurns :: GameFacts -> Int
nrTurns = length . transactions

-- offer of previous transaction
lastOffer :: GameFacts -> Offer
lastOffer = offer . head . transactions

-- strategy of previous transaction
lastStrategy :: GameFacts -> Strategy
lastStrategy = strategy . head . transactions

-- decision of previous transaction
lastDecision :: GameFacts -> Decision
lastDecision = decision . head . transactions

-- minimum offer accepted by opponent
minYes :: GameFacts -> Offer
minYes gf = case offers of
  [] -> maxoffer -- fallback if no offers accepted at all
  _ -> minimum offers
  where offers = map offer $ (transactions . trYes . trSelf) gf

-- maximum offer rejected by opponent
maxNo :: GameFacts -> Offer
maxNo gf = case offers of
  [] -> minoffer -- fallback if no offers rejected at all
  _ -> maximum offers
  where offers = map offer $ (transactions . trNo . trSelf) gf

-- for input offer calculate opponent's Yes minus No replies (positive if more Yes replies)
diffYesNo :: Offer -> GameFacts -> Int
diffYesNo o gf = sum $ map (\v -> if v==Yes then 1 else -1) alldecisions
  where alldecisions = map decision $ (transactions . trSelf . trOffer o) gf

-- opponent did not change his offer since n-many turns?
offerNotChangedSince :: Int -> GameFacts -> Bool
offerNotChangedSince n gf = if nrTurns gf < n then False
                            else all (== (head offers)) $ take n offers
  where offers = map offer ((transactions . trOpponent) gf)

-- calculate total game points
ptsSelf,ptsOpponent :: GameFacts -> Int
ptsSelf gf = sum oppTurns + sum ownTurns
  where oppTurns = map offer $ (transactions . trYes . trOpponent) gf
        ownTurns = map ((1000-) . offer) $ (transactions . trYes . trSelf) gf
ptsOpponent gf = sum oppTurns + sum ownTurns
  where oppTurns = map ((1000-) . offer) $ (transactions . trYes . trOpponent) gf
        ownTurns = map offer $ (transactions . trYes . trSelf) gf

-- calculate point gains by strategy
strategyGains :: GameFacts -> [(Strategy, Int)]
strategyGains gf = zip strgyList gainList
  where gainTitForTat       = (\g -> (ptsSelf g `div` nrTurns g)) $ trTitForTat gf
        gainFindEquilibrium = (\g -> (ptsSelf g `div` nrTurns g)) $ trFindEquilibrium gf
        gainStaticGreedy    = (\g -> (ptsSelf g `div` nrTurns g)) $ trStaticGreedy gf
        gainStatisticsBased = if firstTurn (trStatisticsBased gf) then 0
                              else (\g -> (ptsSelf g `div` nrTurns g)) $ trStatisticsBased gf
        gainList  = [gainStatisticsBased, gainStaticGreedy, gainFindEquilibrium, gainTitForTat]
        strgyList = [StatisticsBased, StaticGreedy, FindEquilibrium, TitForTat]

-- filters on transactions
trOpponent,trSelf,trYes,trNo :: GameFacts -> GameFacts
trOpponent (GameFacts ts tt) = GameFacts (filter (\t -> (source t == Opponent)) ts) tt
trSelf     (GameFacts ts tt) = GameFacts (filter (\t -> (source t == Self)) ts) tt
trYes      (GameFacts ts tt) = GameFacts (filter (\t -> (decision t == Yes)) ts) tt
trNo       (GameFacts ts tt) = GameFacts (filter (\t -> (decision t == No)) ts) tt

trTitForTat,trFindEquilibrium,trStaticGreedy,trStatisticsBased :: GameFacts -> GameFacts
trTitForTat       (GameFacts ts tt) = GameFacts (filter (\t -> (strategy t == TitForTat)) ts) tt
trFindEquilibrium (GameFacts ts tt) = GameFacts (filter (\t -> (strategy t == FindEquilibrium)) ts) tt
trStaticGreedy    (GameFacts ts tt) = GameFacts (filter (\t -> (strategy t == StaticGreedy)) ts) tt
trStatisticsBased (GameFacts ts tt) = GameFacts (filter (\t -> (strategy t == StatisticsBased)) ts) tt

trOffer :: Offer -> GameFacts -> GameFacts
trOffer o (GameFacts ts tt) = GameFacts (filter (\t -> (offer t == o)) ts) tt
