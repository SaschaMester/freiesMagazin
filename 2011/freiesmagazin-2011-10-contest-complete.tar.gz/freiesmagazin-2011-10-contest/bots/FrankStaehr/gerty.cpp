// Copyright 2011 Frank Stähr

// This file is part of Gerty.
// Gerty is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
// Gerty is distributed in the know that it will probably not be useful and WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
// You should have received a copy of the GNU General Public License along with Gerty. If not, see <http://www.gnu.org/licenses/>.

#include <iostream>
#include <string>
#include <boost/algorithm/string.hpp>
#include <vector>
#include <utility>
#include <map>

using namespace std;

enum messagetype {RUNDEN, RUNDE, ANGEBOT, START, ENDE, JA, NEIN, NOTHING};

map<messagetype, string> code;

pair<messagetype, int> getMessage(istream& inputstr)
{
	vector<string> strvalues;
	string line;
	getline(inputstr, line, '\n');
	boost::split(strvalues, line, boost::is_any_of("\t "));

	messagetype msg = NOTHING;
//	boost::algorithm::to_upper(strvalues[0]); // optional für Tests!
	int value = 0;
	if (strvalues.size() == 2)
		value = atoi(strvalues[1].c_str());

	for (map<messagetype, string>::iterator it = code.begin(); it != code.end(); ++it)
	{
		if (strvalues[0] == it->second)
		{
			msg = it->first;
			break;
		}
	}
	return pair<messagetype, int>(msg, value);
}

int main()
{
	code[RUNDEN] = "RUNDEN";
	code[RUNDE] = "RUNDE";
	code[ANGEBOT] = "ANGEBOT";
	code[START] = "START";
	code[ENDE] = "ENDE";
	code[JA] = "JA";
	code[NEIN] = "NEIN";
	
	istream& input = cin;
	ostream& output = cout;
	pair<messagetype, int> message;
	int lastOffer = 510;
	while ((message = getMessage(input)).first != ENDE)
	{
		switch (message.first)
		{
			case START:
			{
				output << lastOffer << endl;
				break;
			}
			case ANGEBOT:
			{
				lastOffer = message.second;
				output << code[JA] << endl;
				break;
			}
		}
	}
}

