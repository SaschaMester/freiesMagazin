/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "bot.hh"
#include "basestrategy.hh"

#include <iostream>
#include <sstream>
#include <cstdio>
#include <assert.h>

// Konstruktor.
Bot::Bot( BaseStrategy* strategyP )
: mStrategyP(0), mBotData(), mBotDataCurrent(), mMessageHandler()
{
    // Strategie festlegen
    setStrategy( strategyP );
}

// Destructor.
Bot::~Bot()
{
    // Genutzte Strategie loeschen.
    if ( mStrategyP )
    {
        delete mStrategyP;
        mStrategyP = 0;
    }

#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) " << this << " Bot::~Bot"
              << std::endl;
    std::clog << out.str();
#endif // DEBUG
}

// Setzt die Strategie fuer einen Bot.
void Bot::setStrategy( BaseStrategy* strategyP )
{
    // Alte Strategie loeschen.
    if ( mStrategyP )
    {
        delete mStrategyP;
        mStrategyP = 0;
    }

    // Neue Strategie setzen.
    mStrategyP = strategyP;

    // Bot-Daten in der Strategie setzen, damit diese
    // darauf zugreifen kann.
    if ( mStrategyP )
    {
        mStrategyP->setBotData( &mBotData );
    }
}

// Starte ein Spiel.
bool Bot::startGame()
{
    bool retValue = false;

    if ( mStrategyP )
    {
        // Setze alle Werte zurueck.
        mBotData.reset();

        // Empfangene Nachricht und optionaler Wert bei jedem Durchlauf.
        MessageId message = MESSAGE_ID_IGNORE;
        int value = 0;

        do
        {
            // Empfange und verarbeite Nachricht.
            message = mMessageHandler.getAndCheckMessage( value );

#ifdef DEBUG
            if ( MESSAGE_ID_IGNORE != message )
            {
                std::ostringstream out;
                out << "(DD) " << this << " Bot::startGame"
                          << " Message: " << message
                          << " Value: "   << value
                          << " Return: "  << retValue
                          << std::endl;
                std::clog << out.str();
            }
#endif

            retValue = processMessage( message, value );

#ifdef DEBUG
            if ( MESSAGE_ID_IGNORE != message )
            {
                std::ostringstream out;
                out << "(DD) " << this << " Bot::startGame"
                          << " Return: "  << retValue
                          << std::endl;
                std::clog << out.str();
            }
#endif

        } while ( retValue && ( message != MESSAGE_ID_EXIT ) );
    }
    else
    {
        std::ostringstream out;
        out << "(EE) " << this << " Bot::startGame"
                  << " Keine Strategie gewaehlt."
                  << std::endl;
        std::cerr << out.str();
    }

    if ( !retValue )
    {
        std::ostringstream out;
        out << "(EE) " << this << " Bot::startGame"
                  << " Irgendwo gab es einen Fehler!"
                  << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

/////////////////////////////////////////////////////
// Alles rund um die gewaehlte Strategie
/////////////////////////////////////////////////////

// Verarbeitet eine Nachricht und fuehrt entsprechende Aktionen aus.
bool Bot::processMessage( const MessageId message, const int value )
{
    bool retValue = false;

    switch ( message )
    {
        case MESSAGE_ID_IGNORE:
        {
            // Nachricht soll ignoriert werden.
            retValue = true;
            break;
        }
        case MESSAGE_ID_ROUNDS:
        {
            // Anzahl der Runden (value ist gesetzt)
            mBotData.setRounds( value );
            retValue = true;
            break;
        }
        case MESSAGE_ID_ACT_ROUND:
        {
            // Neue Runde starten.
            mBotData.startNewRound();

            // Wir pruefen noch, ob die aktuelle Rundenanzahl
            // der uebermittelten entspricht.
            assert ( mBotData.getRound() == value );
            retValue = ( mBotData.getRound() == value );
            break;
        }
        case MESSAGE_ID_START:
        {
            retValue = calculateAndOfferPoints();
            break;
        }
        case MESSAGE_ID_EXIT:
        {
            // Gesamtes Spiel beenden.
            retValue = true;
            break;
        }
        case MESSAGE_ID_OFFER:
        {
            // Angebot des Gegners (value ist gesetzt)
            retValue = acceptOrDeclineOffer( value );
            // Angebot des Gegners als sein letztes Angebot speichern
            mBotData.setOpponentLastOffer(value);
            break;
        }
        case MESSAGE_ID_ACCEPTED:
        {
            // Gegner hat eigenes Angebot angenommen
            otherBotAcceptedOffer();
            // Diese Tatsache speichern.
            mBotData.setOpponentLastAccepted(true);
            mBotData.setOpponentLast2Rejected(false);
            mBotData.addOpponentAccept(mBotData.getMyLastOffer());
            retValue = true;
            break;
        }
        case MESSAGE_ID_DECLINED:
        {
            // Gegner hat eigenes Angebot abgelehnt
            otherBotDeclinedOffer();
            // Diese Tatsache speichern.
            if(!mBotData.getOpponentLastAccepted()) {
            	mBotData.setOpponentLast2Rejected(true);
            }
            mBotData.setOpponentLastAccepted(false);
            retValue = true;
            break;
        }
        case MESSAGE_ID_POINTS:
        {
            // Erhaltene Punkte (value ist gesetzt)
            retValue = addPoints( value );
            break;
        }
        case MESSAGE_ID_INVALID:
        {
            // Ungueltige Nachricht
            std::ostringstream out;
            out << "(EE) " << this << " Bot::processMessage"
                      << " Empfangene Nachricht ist ungueltig."
                      << std::endl;
            std::cerr << out.str();
            retValue = false;
            break;
        }
        default:
        {
            // Kommando nicht verstanden!
            std::ostringstream out;
            out<< "(EE) " << this << " Bot::processMessage"
                      << " Nachricht "
                      << message
                      << " nicht verstanden."
                      << std::endl;
            std::cerr << out.str();
            retValue = false;
            break;
        }
    }

    if ( !retValue )
    {
        std::ostringstream out;
        out << "(EE) " << this << " Bot::processMessage"
                  << " Irgendwo gab es einen Fehler!"
                  << std::endl;
        std::cerr << out.str();
    }
    
    return retValue;
}

// Berechnet die angebotenen Punkte und gibt diese aus.
bool Bot::calculateAndOfferPoints()
{
    bool retValue = false;

    // Pruefe, ob eine Strategie festgelegt wurde.
    if ( mStrategyP )
    {
        const int offeredPoints = mStrategyP->calculateOfferedPoints();

        // Punkte muessen zwischen 0 und 1000 liegen.
        if ( 0 <= offeredPoints && offeredPoints <= 1000 )
        {
            // Angebotenen Wert speichern.
            mBotDataCurrent.mOfferedPoints = offeredPoints;
            mBotData.setMyLastOffer(offeredPoints);

            // Angebotene Wert in String wandeln und senden.
            std::ostringstream offeredString;
            offeredString << offeredPoints;
            const std::string message = offeredString.str();

#ifdef DEBUG
            std::ostringstream out;
            out << "(DD) " << this << " Bot::calculateAndOfferPoints"
                      << " Wert: " << offeredPoints
                      << std::endl;
            std::clog << out.str();
#endif // DEBUG
            
            mMessageHandler.sendMessage(message);
        
            retValue = true;
        }
        else
        {
            std::ostringstream out;
            out << "(EE) " << this << " Bot::calculateAndOfferPoints"
                      << " Angebotener Wert "
                      << offeredPoints
                      << " liegt nicht zwischen 0 und 1000."
                      << std::endl;
            std::cerr << out.str();
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) " << this << " Bot::calculateAndOfferPoints"
                  << " Keine Strategie gewaehlt."
                  << std::endl;
        std::cerr << out.str();
    }

    if ( !retValue )
    {
        std::ostringstream out;
        out << "(EE) " << this << " Bot::calculateAndOfferPoints"
                  << " Irgendwo gab es einen Fehler!"
                  << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

// Akzeptiert oder lehnt ein Angebot ab.
bool Bot::acceptOrDeclineOffer( const int value )
{
    bool retValue = false;

#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) " << this << " Bot::acceptOrDeclineOffer"
              << " Wert: " << value << std::endl;
    std::clog << out.str();
#endif // DEBUG

    // Pruefe, ob eine Strategie festgelegt wurde.
    if ( mStrategyP )
    {
        // Der Wert muss zwischen 0 und 1000 liegen.
        if ( 0 <= value && value <= 1000 )
        {
            const bool acceptOffer = mStrategyP->acceptOrDeclineOffer( value );

            // Alles okay, wir koennen nun angeben, ob wir das Angebot
            // ablehnen oder annehmen.
            if ( acceptOffer )
            {
                // Speichere angebotenen Wert kurz zwischen.
                mBotDataCurrent.mExpectedPoints = value;
                mBotDataCurrent.mExpectedOpponentPoints = 1000-value;

                // Speichere angenommenen Wert im Vector
                mBotData.addMyAccept(value);

                // Akzeptiere Angebot.
                mMessageHandler.sendMessage( "JA" );
            }
            else
            {
                // Da wir das Angebot ablehnen, gehen alle leer aus.
                // Die spaeter erhaltenen Punkte sind also Null.
                mBotDataCurrent.mExpectedPoints = 0;
                mBotDataCurrent.mExpectedOpponentPoints = 0;

                // Lehne Angebot an.
                mMessageHandler.sendMessage( "NEIN" );
            }

            retValue = true;
        }
        else
        {
            std::ostringstream out;
            out << "(EE) " << this << " Bot::acceptOrDeclineOffer"
                  << " Angebotener Wert "
                  << value
                  << " liegt nicht zwischen 0 und 1000."
                  << std::endl;
            std::cerr << out.str();
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) " << this << " Bot::acceptOrDeclineOffer"
              << " Keine Strategie gewaehlt."
              << std::endl;
        std::cerr << out.str();
    }

    if ( !retValue )
    {
        std::ostringstream out;
        out << "(EE) " << this << " Bot::calculateAndOfferPoints"
                  << " Irgendwo gab es einen Fehler!"
                  << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

/////////////////////////////////////////////////////
// Punkte verwalten
/////////////////////////////////////////////////////

// Addiere erhaltene Punktzahl zum Konto.
bool Bot::addPoints( const int value )
{
    bool retValue = false;

#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) " << this << " Bot::addPoints"
              << " Wert: " << value << std::endl;
    std::clog << out.str();
#endif // DEBUG

    // Kleine Sicherheitspruefung, ob die empfangenen Punkte
    // auch den erwarteten entsprechen.
    if ( value == mBotDataCurrent.mExpectedPoints )
    {
        // Addiere Punktezahl.
        mBotData.addPoints( mBotDataCurrent.mExpectedPoints );
        mBotData.addOpponentPoints( mBotDataCurrent.mExpectedOpponentPoints );
        retValue = true;
    }
    else
    {
        // Die Werte stimmen nicht ueberein.
        std::ostringstream out;
        out << "(EE) " << this << " Bot::addPoints"
                  << " Empfangener Wert"
                  << value
                  << " entspricht nicht berechnetem Wert "
                  << mBotDataCurrent.mExpectedPoints
                  << "."
                  << std::endl;
        std::cerr << out.str();
    }

    // Setze aktuelle Daten zurueck.
    mBotDataCurrent.reset();

    return retValue;
}

// Das Angebot wurde vom Gegner angenommen.
void Bot::otherBotAcceptedOffer()
{
#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) " << this << " Bot::otherBotAcceptedOffer"
              << " Angebot vom anderen Bot angenommen."
              << std::endl;
    std::clog << out.str();
#endif // DEBUG

    // Wir erhalten eine gewisse Punktzahl, die wir
    // speichern.
    mBotDataCurrent.mExpectedPoints = 1000-mBotDataCurrent.mOfferedPoints;

    // Der Gegner erhaelt den von uns angebotenen
    // Wert, wenn er akzeptiert hat.
    mBotDataCurrent.mExpectedOpponentPoints = mBotDataCurrent.mOfferedPoints;

    // Die Werte werden aber erst spaeter verrechnet, wenn
    // der Server sich entsprechend meldet.
    mBotDataCurrent.mOfferedPoints = 0;
}

// Das Angebot wurde vom Gegner abgelehnt.
void Bot::otherBotDeclinedOffer()
{
#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) " << this << " Bot::otherBotDeclinedOffer"
              << " Angebot vom anderen Bot abgelehnt."
              << std::endl;
    std::clog << out.str();
#endif // DEBUG

    // Niemand erhaelt Punkte.
    mBotDataCurrent.mExpectedPoints = 0;
    mBotDataCurrent.mExpectedOpponentPoints = 0;
    mBotDataCurrent.mOfferedPoints = 0;
}
