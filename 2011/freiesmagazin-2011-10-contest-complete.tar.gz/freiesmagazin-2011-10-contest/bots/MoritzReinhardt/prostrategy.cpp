/**
    (C) Copyright 2011 Moritz Reinhardt

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "prostrategy.hh"
#include <vector>

// Konstruktor
ProStrategy::ProStrategy()
: BaseStrategy()
{
}

// Destructor.
ProStrategy::~ProStrategy()
{
}

// Erstellt eine Kopie des Elements.
BaseStrategy* ProStrategy::copy() const
{
    return (BaseStrategy*)(new ProStrategy(*this));
}

// Akzeptiert oder lehnt ein Angebot ab.
bool ProStrategy::acceptOrDeclineOffer( const int value )
{
    bool acceptOffer = false;

	// if opponen offers more than 500 always accept
	if(value > 500) {
		return true;
	}

	int round = mBotDataP->getRound();
	if(round <= 100) {
	//tit-for-tat
	//-------------

		//TODO if opponent zuerst - reject everything <= 500
		//per default accept the first offer: opponentLastAccepted is initialized to true, myLastOffer is initialized to 0
		if(mBotDataP->getOpponentLastAccepted()) {
			if(value >= mBotDataP->getMyLastOffer()) {
				acceptOffer = true;
			}
		}
	} else {
	// average strategy for rounds 101 - end
	//-------------
		if(value >= mBotDataP->getMyAcceptAvg()) {
			acceptOffer = true;
		}
	}

    return acceptOffer;
}

// Berechnet die angebotenen Punkte und sendet sie an den Server.
int ProStrategy::calculateOfferedPoints()
{
	int offer = 0;
	int round = mBotDataP->getRound();
	if(round <= 100) {
		//tit-for-tat
		//-------------

		// check if I am first to offer in the whole match
		if(mBotDataP->getMyLastOffer() == 0 && mBotDataP->getRound() == 1) {
			offer = 300;
		} else {
			int opponentLastOffer = mBotDataP->getOpponentLastOffer();
			if(opponentLastOffer <= 500) {
				offer = opponentLastOffer;
			} else {
				offer = 499;
			}
		}
	} else {
	// average strategy for rounds 101 - end
	//-------------
		int averageOpponentAccept = mBotDataP->getOpponentAcceptAvg();
		if(!mBotDataP->getOpponentLastAccepted()) {
		//my last offer rejected
			offer = averageOpponentAccept;
			if(mBotDataP->getOpponentLast2Rejected()) {
			//my last 2 offers rejected
				offer = averageOpponentAccept + 5;
			}
		} else {
		//my last offer accepted
		//-> increase win amount
			offer = averageOpponentAccept -1;
		}

		//safety checks -> offer has to be between 0 and 499
		if(offer > 499)
			offer = 499;
		if(offer < 0)
			offer = 0;
	}

	return offer;
}
