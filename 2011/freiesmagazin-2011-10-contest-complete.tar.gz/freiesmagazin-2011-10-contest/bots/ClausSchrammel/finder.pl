#!/usr/bin/perl -w

###########################################################################
## Copyright (C) 2011 Claus Schrammel                                    ##
##                                                                       ##
## This program is free software: you can redistribute it and/or modify  ##
## it under the terms of the GNU General Public License as published by  ##
## the Free Software Foundation, either version 3 of the License, or     ##
## (at your option) any later version.                                   ##
##                                                                       ##
## This program is distributed in the hope that it will be useful,       ##
## but WITHOUT ANY WARRANTY; without even the implied warranty of        ##
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         ##
## GNU General Public License for more details.                          ##
##                                                                       ##
## You should have received a copy of the GNU General Public License     ##
## along with this program.  If not, see <http://www.gnu.org/licenses/>. ##
###########################################################################

use warnings;

########################################################################
## autoflush
########################################################################

$| = 1;

########################################################################
## global vars
########################################################################

# number of rounds
my $_rounds;

# this round
my $_round;

# total points scored
my $_total = 0;

########################################################################

# debug mode
my $_DEBUG = 0;

########################################################################

# my offer for checking whether opponent accepts or rejects
my $this_offer;

# what has been rejected by opponent
my $max_rejected = 0;

# what has been accepted by opponent
my $min_accepted = 500;

# strategy: "min" accepted, "max" rejected, "avg" average
my $strategy = 'max';

########################################################################
## options
########################################################################

if (scalar(@ARGV) > 0 && $ARGV[0] eq "-d")
{
  $_DEBUG = 1;
  print STDERR "-- DEBUG enabled\n";
  shift @ARGV;
}

if (scalar(@ARGV) > 0 && $ARGV[0] =~ m/^(max|avg|min)$/)
{
  $strategy = $ARGV[0];
  print STDERR "-- strategy: $strategy\n" if ($_DEBUG);
  shift @ARGV;
}

if (scalar(@ARGV) > 0)
{
  &usage() if ($ARGV[0] !~ m/^\d+$/);
  $max_rejected = $ARGV[0];
  print STDERR "-- max_rejected: $max_rejected\n" if ($_DEBUG);
  shift @ARGV;
}

if (scalar(@ARGV) > 0)
{
  &usage() if ($ARGV[0] !~ m/^\d+$/);
  $min_accepted = $ARGV[0];
  print STDERR "-- min_accepted: $min_accepted\n" if ($_DEBUG);
  shift @ARGV;
}

if (scalar(@ARGV) > 0)
{
  &usage();
}

sub usage
{
  die "usage: $0 [-d] [first offer] [initial reject]";
}

########################################################################
## workers
########################################################################

sub rounds
{
  my $rounds = shift;
}

sub round
{
  my $round = shift;
}

sub start
{
  $this_offer = $min_accepted;
  if ($max_rejected < $min_accepted)
  {
    $this_offer = int(($max_rejected + $min_accepted) / 2 + 0.5)
  }
  return $this_offer;
}

sub offer
{
  my $offer = shift;

  my $threshold = $min_accepted;
  if ($strategy eq 'max') {
    $threshold = $max_rejected;
  }
  elsif ($strategy eq 'avg' and $max_rejected < $min_accepted)
  {
    $threshold = int(($max_rejected + $min_accepted) / 2 + 0.5)
  }

  print STDERR "-- threshold: $threshold\n" if ($_DEBUG);

  return 1 if ($offer >= $threshold);
  return 0;
}

sub accepted
{
  $min_accepted = $this_offer if ($min_accepted > $this_offer);
}

sub rejected
{
  $max_rejected = $this_offer if ($max_rejected < $this_offer);
  print STDERR "-- max_rejected: $max_rejected\n" if ($_DEBUG);
}

sub points
{
  my $points = shift;
}

sub end
{
}

########################################################################
## event loop
########################################################################

sub loop
{
  while (<STDIN>)
  {
    print STDERR "<- $_" if ($_DEBUG);
    if (m/^RUNDEN\s+(\d+)$/)
    {
      $_rounds = $1;
      &rounds($rounds);
    }
    elsif (m/^RUNDE\s+(\d+)$/)
    {
      $_round = $1;
      &round($round);
    }
    elsif (m/^START$/)
    {
      my $offer = &start();
      print STDOUT "$offer\n";
      print STDERR "-> $offer\n" if ($_DEBUG);
    }
    elsif (m/^ANGEBOT\s+(\d+)$/)
    {
      $offer = $1;
      my $decision = &offer($offer) ? "JA" : "NEIN";
      print STDOUT "$decision\n";
      print STDERR "-> $decision\n" if ($_DEBUG);
    }
    elsif (m/^JA$/)
    {
      &accepted();
    }
    elsif (m/^NEIN$/)
    {
      &rejected();
    }
    elsif (m/^PUNKTE\s+(\d+)$/)
    {
      my $points = $1;
      $_total += $points;
      &points($points);
    }
    elsif (m/^ENDE$/)
    {
      &end();
      return;
    }
    else
    {
      die "invalid command: $_";
    }
  }
}

# start the event loop
&loop();
exit 0;
