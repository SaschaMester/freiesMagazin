/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "deestrategy.hh"
#include "botdata.hh"

#include <iostream>
#include <sstream>

// Konstruktor
DeeStrategy::DeeStrategy()
: BaseStrategy()
{
    mOppBorders[0] = 0;
    mOppBorders[1] = 500;
}

// Destructor.
DeeStrategy::~DeeStrategy()
{
}

// Erstellt eine Kopie des Elements.
BaseStrategy* DeeStrategy::copy() const
{
    return (BaseStrategy*)(new DeeStrategy(*this));
}

// Akzeptiert oder lehnt ein Angebot ab.
bool DeeStrategy::acceptOrDeclineOffer( const int value )
{
    bool acceptOffer = false;

    // Ueber 500 nehmen wir immer an.
    const int maxOffer = 500;

    // Unter 100 lehnen wir immer ab.
    const int minOffer = 100;

    // Bis zu welcher Runde (in Prozent) akzeptieren wir auch
    // niedrigere Angebote?
    const int acceptStartRoundPercent = 6;

    // Bis zu welchem Prozentwert akzeptieren wir in der Startphase
    // ein schlechtes Angebot.
    const int acceptStartPercent = 10;

    // Wann senken wir unsere Erwartungen, den Vorsprung auszubauen?
    // In Promille von den Gesamtrunden!
    const int lowerExpectStep1 = 5;

    // Wann senken wir unsere Erwartungen, den Vorsprung zu halten?
    // In Promille von den Gesamtrunden!
    const int lowerExpectStep2 = 20;

    // Wenn wir auf der niedrigsten Erwartungsstufe sind, wie viel
    // wollen wir dann mindestens haben?
    const int lowestExpectMin = 250;

#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) " << this << " DeeStrategy::acceptOrDeclineOffer"
              << " Offer: " << value
              << std::endl;
    std::clog << out.str();
#endif // DEBUG

    if ( value > maxOffer )
    {
#ifdef DEBUG
        std::ostringstream out;
        out << "(DD) " << this << " DeeStrategy::acceptOrDeclineOffer"
                  << " Accept because > " << maxOffer
                  << std::endl;
        std::clog << out.str();
#endif // DEBUG

        // Ist das Angebot > 500, nehmen wir immer an, da wir besser
        // dastehen als der Gegner. Das wird wohl eher selten passieren.
        acceptOffer = true;
    }
    else if ( value < minOffer )
    {
#ifdef DEBUG
        std::ostringstream out;
        out << "(DD) " << this << " DeeStrategy::acceptOrDeclineOffer"
                  << " Decline because < " << minOffer
                  << std::endl;
        std::clog << out.str();
#endif // DEBUG

        // Ist das Angebot < minOffer, lehnen wir ab, da das zu wenig ist.
        // Dann gehen lieber alle leer aus.
        acceptOffer = false;
    }
    else
    {
        // Das Angebot liegt zwischen minOffer und maxOffer.

        // Es hat sich bei zahlreichen Tests gezeigt, dass es besser
        // ist ein schlechtes Angebot anzunehmen, als abzulehnen,
        // wenn andere Bots sich bereits so verhalten. Dann blocken
        // sich die anderen gegenseitig und der, der alles annimmt,
        // hat die besten Chance. Wenn man natürlich wirklich alles
        // annimmt und es gibt viele Bots mit dieser Taktik, dann
        // ist das auch schlecht.

#ifdef DEBUG
        std::ostringstream out;
        out << "(DD) " << this << " DeeStrategy::acceptOrDeclineOffer"
                  << " Offer between " << minOffer
                  << " and " << maxOffer << "."
                  << " Round " << mBotDataP->getRound()
                  << " of "    << mBotDataP->getNumRounds()
                  << std::endl;
        std::clog << out.str();
#endif // DEBUG

        // Am Anfang des Spiels lassen wir es auch zu, dass wir
        // kleinere Betraege annehmen.
        // Das ist aber abhaengig von der aktuellen Runde und dem
        // Betrag. Das heißt, je eher im Spiel, desto eher nehmen
        // wir einen geringen Betrag an. Je spaeter im Spiel, desto
        // eher lehnen wir ihn ab.
        if ( mBotDataP->getRound() <=
                 mBotDataP->getNumRounds()*acceptStartRoundPercent/100 )
        {
            // Berechne Wert zwischen 0 und 1 fuer Runde.
            // Wert nahe 0 bedeutet wir sind am Ende der Anfangsphase
            // wo wir noch niedrigere Werte akzeptieren.
            // Wert nahe 1 bedeutet wir sind noch ganz am Anfang des
            // Spiels.
            const double roundP = 1.0 - (mBotDataP->getRound() * 1.0 / (mBotDataP->getNumRounds()*acceptStartRoundPercent/100));

            // Berechne Wert zwischen 0 und 1 fuer Angebot.
            // Wert nahe 0 bedeutet sehr geringes Angebot.
            // Wert nahe 1 bedeutet sehr hohes Angebot.
            const double valueP = (value-minOffer)*1.0/maxOffer;

            // Wenn beide Prozentwerte groesser als eine Grenze sind,
            // akzeptieren wir. Das bedeutet, je naeher wir am
            // Startphasenende sind und je kleiner das Angebot, desto
            // eher lehnen wir ab.
            // Beispiel (2500 Runden, Startphase 5%, Akzeptanz 20%):
            // Runde 1, Angebot 200
            //     => valueP = 0.2, roundP = 0.992
            //     => 0.2*0.992*100 = 19.84 < 20
            //     => Angebot abgelehnt
            // Runde 1, Angebot 250
            //     => valueP = 0.3, roundP = 0.992
            //     => 0.3*0.992*100 = 29.76 < 20
            //     => Angebot angenommen
            // Runde 50, Angebot 250
            //     => valueP = 0.3, roundP = 0.992
            //     => 0.3*0.992*100 = 29.76 < 20
            //     => Angebot angenommen

            const double allP = roundP*valueP*100;
            if ( allP >= acceptStartPercent )
            {
#ifdef DEBUG
                std::ostringstream out;
                out << "(DD) " << this << " DeeStrategy::acceptOrDeclineOffer"
                          << " Accept because early in game and "
                          << allP << " >= " << acceptStartPercent
                          << std::endl;
                std::clog << out.str();
#endif // DEBUG
                acceptOffer = true;
            }
            else
            {
#ifdef DEBUG
                std::ostringstream out;
                out << "(DD) " << this << " DeeStrategy::acceptOrDeclineOffer"
                          << " Decline although early in game but "
                          << allP << " < " << acceptStartPercent
                          << std::endl;
                std::clog << out.str();
#endif // DEBUG
                acceptOffer = false;
            }
        }
        else
        {
            // Wir haben die Anfangsphase ueberstanden.
            // Wir muessen aufpassen, dass wir nicht zu oft ablehnen.
            // Aus dem Grund waehlen wir eine variable Strategie.

            // Pro Runde sollten wir immer mindestens x Punkte
            // vorne liegen. Das heißt, nach 2500 Runden mindestens
            // 2500*x Punkte. Falls nicht, lehnen wir das Angebot ab,
            // weil der Abstand zum Gegner sonst nur größer wird.
            static const int advPointsPerRound = 10;

            const int expectedAdvPoints = mBotDataP->getRound()*advPointsPerRound;
            const int expectedPoints = mBotDataP->getPoints()+value;
            const int expectedOppPoints = mBotDataP->getOpponentPoints()+(1000-value);

#ifdef DEBUG
            std::ostringstream out;
            out << "(DD) " << this << " DeeStrategy::acceptOrDeclineOffer"
                      << " Expected: "     << expectedPoints
                      << " Expected Opp: " << expectedOppPoints
                      << " Expected Adv: " << expectedAdvPoints
                      << std::endl;
            std::clog << out.str();
#endif // DEBUG

            if ( expectedPoints-expectedAdvPoints > expectedOppPoints )
            {
                acceptOffer = true;
            }
            else
            {
                // Wir lehnen das Angebot ab. Es kann nun gut sein,
                // dass wir ab Runde 100 nur noch ablehnen. Das waere
                // nicht gut, da ja das Gesamtergebnis gegen alle
                // anderen Bots zaehlt und nicht nur diese eine.
                // Daher pruefen wir, wie oft wir nacheinander
                // abgelehnt haben.
                // Bei mehr als X Ablehnungen nacheinander, schrauben
                // wir unsere Erwartungen etwas herunter.
                int criticalRound = mBotDataP->getNumRounds()*lowerExpectStep1/1000;
                bool lowerExpectations = ( mBotDataP->getNumOfDeclinedOffersInARow() > criticalRound );

                if ( lowerExpectations )
                {
#ifdef DEBUG
                    std::ostringstream out;
                    out << "(DD) " << this << " DeeStrategy::acceptOrDeclineOffer"
                              << " Lowered expectations: " << criticalRound
                              << std::endl;
                    std::clog << out.str();
#endif // DEBUG

                    if ( expectedPoints > expectedOppPoints )
                    {
                        // Wir haben zwar nicht mehr den gewuenschten
                        // Vorsprung, stehen aber immer noch besser da
                        acceptOffer = true;
                    }
                    else
                    {
                        // Es passt immer noch nicht. Geht das nun schon
                        // Y Runden so, dann muessen wir wohl oder uebel
                        // unseren Vorsprung aufgeben bzw. die Aufholjagd
                        // beenden.
                        criticalRound = mBotDataP->getNumRounds()*lowerExpectStep2/1000;
                        lowerExpectations = ( mBotDataP->getNumOfDeclinedOffersInARow() > criticalRound );

                        if ( lowerExpectations )
                        {
#ifdef DEBUG
                            std::ostringstream out;
                            out << "(DD) " << this << " DeeStrategy::acceptOrDeclineOffer"
                                      << " Lowered expectations: " << criticalRound
                                      << std::endl;
                            std::clog << out.str();
#endif // DEBUG

                            if ( expectedPoints > expectedOppPoints-expectedAdvPoints )
                            {
                                // Je laenger das Spiel dauert, desto eher lassen wir eine große Luecke zu.
                                acceptOffer = true;
                            }
                            else
                            {
                                // Es passt immer noch nicht.
                                // Ehe wir ablehnen, nehmen wir mindestens Z Punkte mit.
                                if ( value >= lowestExpectMin )
                                {
                                    acceptOffer = true;
                                }
                                else
                                {
                                    
                                    acceptOffer = false;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

#ifdef DEBUG
        std::ostringstream out1;
        out1 << "(DD) " << this << " DeeStrategy::acceptOrDeclineOffer"
                  << " Accept: " << acceptOffer
                  << std::endl;
        std::clog << out1.str();
#endif // DEBUG

    return acceptOffer;
}

// Berechnet die angebotenen Punkte und sendet sie an den Server.
int DeeStrategy::calculateOfferedPoints()
{
    int offeredPoints = 0;

    // Als Taktik versuchen wir herauszubekommen, wo die Schmerzgrenze
    // des gegnerischen Bots liegt. Das heißt, ab wo er ein Angebot
    // annimmt und wo er ablehnt. (Hinweis: Wenn der andere Bot
    // zufaellig entscheidet, ergibt das hier auch nur Zufallswerte.)

    if ( mBotDataP->getRound() > 1 )
    {
        // Hole Daten der vorherigen Runde.
        const int accepted = mBotDataP->hasOpponentAccepted( mBotDataP->getRound()-1 );
        const int points = mBotDataP->getOfferedPointsToOpponent( mBotDataP->getRound()-1 );

#ifdef DEBUG
        std::ostringstream out;
        out << "(DD) " << this << " DeeStrategy::calculateOfferedPoints"
                  << " Round: "    << mBotDataP->getRound()
                  << " Accepted: " << accepted
                  << " Points: "   << points
                  << std::endl;
        std::clog << out.str();
#endif // DEBUG

        if ( accepted )
        {
#ifdef DEBUG
            std::ostringstream out;
            out << "(DD) " << this << " DeeStrategy::calculateOfferedPoints"
                      << " Set upper border from " << mOppBorders[1]
                      << " to " << points
                      << std::endl;
            std::clog << out.str();
#endif // DEBUG

            // Der Gegner hat unser vorheriges Angebot akzeptiert.
            // Wir setzen die obere Grenze also weiter nach unten.
            mOppBorders[1] = points;
        }
        else
        {
            if ( mOppBorders[0] < mOppBorders[1] )
            {
#ifdef DEBUG
                std::ostringstream out;
                out << "(DD) " << this << " DeeStrategy::calculateOfferedPoints"
                          << " Set lower border from " << mOppBorders[0]
                          << " to " << points+1
                          << std::endl;
                std::clog << out.str();
#endif // DEBUG

                // Der Gegner hat unser vorheriges Angebot abgelehnt.
                // Wir setzen die untere Grenze also weiter nach oben.
                mOppBorders[0] = points+1;
            }
            else
            {
#ifdef DEBUG
                const int oldBorder = mOppBorders[0];
#endif // DEBUG

                // Sonderfall: Wenn der Gegner zufaellig entscheidet,
                // oder ein festes Schema hat, dann kann es sein, dass
                // die Grenzen zusammenfallen (es also nur einen
                // moeglichen Wert gibt), der Gegner aber ablehnt.
                // Wir vergroessern den aktuellen Bereich daher wieder
                // um 100 Punkte in beide Richtungen und iterieren
                // neu.
                mOppBorders[0] -= 100;
                mOppBorders[1] += 100;

                // Grenzabfrage
                if ( mOppBorders[0] < 0 )
                {
                    mOppBorders[0] = 0;
                }
                
                if ( mOppBorders[1] > 500 )
                {
                    mOppBorders[1] = 500;
                }

#ifdef DEBUG
                std::ostringstream out;
                out << "(DD) " << this << " DeeStrategy::calculateOfferedPoints"
                          << " Borders reached " << oldBorder
                          << " Set borders to "
                          << mOppBorders[0] << " / " << mOppBorders[1]
                          << std::endl;
                std::clog << out.str();
#endif // DEBUG
            }
        }
    }

    // Das naechste Angebot suchen wir in der Mitte aus
    offeredPoints = ( mOppBorders[0] + mOppBorders[1] ) / 2;

    return offeredPoints;
}
