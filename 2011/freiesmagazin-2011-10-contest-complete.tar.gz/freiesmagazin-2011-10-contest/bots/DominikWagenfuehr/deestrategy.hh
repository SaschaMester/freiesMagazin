/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef DEESTRATEGY_HH
#define DEESTRATEGY_HH

#include "basestrategy.hh"

// Vorwaertsdeklarationen.
class BotData;

/// Eigene Strategie
class DeeStrategy : public BaseStrategy
{
  public:
    /// Konstruktor
    DeeStrategy();

    /// Destructor.
    virtual ~DeeStrategy();

    /// Erstellt eine Kopie des Elements.
    /**
     * Wenn man abgeleitete Klassen von einer Basis-Klasse hat
     * und nur mit einem Pointer auf die Basis-Klasse arbeitet,
     * lassen sich Objekte nicht so einfach per Zuweisung kopieren
     * da man ja die exakte Klassen benötigt. In dem Fall arbeitet
     * man mit einer virtuellen copy-Methode, welche in jeder
     * abgeleiteten Klasse implementiert werden muss.
     * @return Pointer auf die Kopie des Objekt.
     */
    virtual BaseStrategy* copy() const;
    
    /// Akzeptiert oder lehnt ein Angebot ab.
    /**
     * Ist der angebotene Wert groesser oder gleich 250, wird
     * das Angebot angenommen, sonst abgelehnt.
     * @param value Der angebotene Wert.
     * @return true, wenn das Angebot angenommen wurde, ansonsten false
     */
    virtual bool acceptOrDeclineOffer( const int value );

    /// Berechnet die angebotenen Punkte.
    /**
     * Es wird immer der Wert 250 angeboten.
     * @return 250
     */
    virtual int calculateOfferedPoints();

  private:
    /// Grenzen fuer Angebote des Gegners.
    /**
     * Wir nehmen an, dass der Gegner einen Wertebereich hat,
     * in dem er Gebote annimmt. Außerhalb davn wird er ablehnen.
     * Mit jedem neuen Angebot pruefen wir das vorherige Ergebnis
     * und versuchen so die Grenzen auszuloten. Damit koennen wir
     * dann die Gewinnspanne maximieren.
     */
    int mOppBorders[2];
  
};

#endif // DEESTRATEGY_HH
