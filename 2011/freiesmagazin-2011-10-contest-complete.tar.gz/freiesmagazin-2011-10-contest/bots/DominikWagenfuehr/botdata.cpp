/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "botdata.hh"

#include <iostream>
#include <sstream>
#include <assert.h>

// Konstruktor.
BotData::BotData()
: mNumMaxRounds(0), mRound(0), mPoints(0), mOpponentPoints(0),
  mNumDeclOffers(0), mNumDeclOffersByOpponent(0)  
{
}

// Setzt alle Daten zurueck.
void BotData::reset()
{
    mNumMaxRounds = 0;
    mRound = 0;
    mPoints = 0;
    mOpponentPoints = 0;
    mNumDeclOffers = 0;
    mNumDeclOffersByOpponent = 0;
}

// Speichere Anzahl an Runden.
void BotData::setRounds( const int value )
{
    mNumMaxRounds = value;

#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) " << this << " BotData::setRounds"
              << " Resize: " << value
              << std::endl;
    std::clog << out.str();
#endif // DEBUG

    // setze Vektorgroesse
    mLastDecisions.resize( value );
    mLastOpponentDecisions.resize( value );
}

// Eine neue Runde wird gestartet.
void BotData::startNewRound()
{
    // Rundenzaehler erhoehen.
    mRound++;
}

// Fuegt erreichte Punktzahl hinzu.
void BotData::addPoints( const int points )
{
    mPoints += points;
}

// Fuegt erreichte Punktzahl des Gegners hinzu.
void BotData::addOpponentPoints( const int points )
{
    mOpponentPoints += points;
}

// Eigener Bot akzeptiert ein Angebot.
void BotData::acceptOffer( const bool accept, const int points )
{
#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) " << this << " BotData::acceptOffer"
              << " Accept: " << accept
              << " Points: " << points
              << " Round: "  << mRound
              << " Size: "   << mLastDecisions.size()
              << std::endl;
    std::clog << out.str();
#endif // DEBUG

    assert( mRound > 0 );
    assert( mLastDecisions.at(mRound-1).value == -1 );
    
    mLastDecisions.at(mRound-1).accept = accept;
    mLastDecisions.at(mRound-1).value = points;

    if ( accept )
    {
        mNumDeclOffers = 0;
    }
    else
    {
        mNumDeclOffers++;
    }
}

// Der gegnerischer Bot akzeptiert das Angebot.
void BotData::opponentAcceptOffer( const bool accept, const int points )
{
#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) " << this << " BotData::opponentAcceptOffer"
              << " Accept: " << accept
              << " Points: " << points
              << " Round: "  << mRound
              << " Size: "   << mLastOpponentDecisions.size()
              << std::endl;
    std::clog << out.str();
#endif // DEBUG

    assert( mRound > 0 );
    assert( mLastOpponentDecisions.at(mRound-1).value == -1 );
    
    mLastOpponentDecisions.at(mRound-1).accept = accept;
    mLastOpponentDecisions.at(mRound-1).value = points;

    if ( accept )
    {
        mNumDeclOffersByOpponent = 0;
    }
    else
    {
        mNumDeclOffersByOpponent++;
    }
}

// Prueft, ob der Gegner ein Angebot aus einer Runde akzeptiert hat.
bool BotData::hasOpponentAccepted( const int round ) const
{
#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) " << this << " BotData::hasOpponentAccepted"
              << " Value: " << round
              << " Round: "  << mRound
              << " Size: "   << mLastOpponentDecisions.size()
              << std::endl;
    std::clog << out.str();
#endif // DEBUG

    assert( 0 < round && round <= (int)mLastOpponentDecisions.size() );
    assert( round <= mRound );

#ifdef DEBUG
    std::ostringstream out1;
    out1 << "(DD) " << this << " BotData::hasOpponentAccepted"
              << " Accepted: " << mLastOpponentDecisions.at(round-1).accept
              << " Value: "    << mLastOpponentDecisions.at(round-1).value
              << std::endl;
    std::clog << out1.str();
#endif // DEBUG

    assert( mLastOpponentDecisions.at(round-1).value != -1 );

    return mLastOpponentDecisions.at(round-1).accept;
}

// Gibt die angebotenen Punkte aus einer Runde zurueck.
int BotData::getOfferedPointsToOpponent( const int round ) const
{
#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) " << this << " BotData::getOfferedPointsToOpponent"
              << " Value: " << round
              << " Round: "  << mRound
              << " Size: "   << mLastOpponentDecisions.size()
              << std::endl;
    std::clog << out.str();
#endif // DEBUG

    assert( 0 < round && round <= (int)mLastOpponentDecisions.size() );
    assert( round <= mRound );

#ifdef DEBUG
    std::ostringstream out1;
    out1 << "(DD) " << this << " BotData::getOfferedPointsToOpponent"
              << " Accepted: " << mLastOpponentDecisions.at(round-1).accept
              << " Value: "    << mLastOpponentDecisions.at(round-1).value
              << std::endl;
    std::clog << out1.str();
#endif // DEBUG

    assert( mLastOpponentDecisions.at(round-1).value != -1 );

    return mLastOpponentDecisions.at(round-1).value;
}
