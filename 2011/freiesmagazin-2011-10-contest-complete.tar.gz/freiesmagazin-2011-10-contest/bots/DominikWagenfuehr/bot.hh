/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef BOT_HH
#define BOT_HH

#include "botdata.hh"
#include "botdatacurrent.hh"
#include "messageid.hh"
#include "messagehandler.hh"

#include <string>

// Vorwärtsdeklaration
class BaseStrategy;

/// Der Bot.
/**
 * Der Bot wartet auf das Startsignal vom Server auf STDIN und
 * gibt sein Angebot auf STDOUT ab. Umgekehrt erwartet er ein
 * Angebot vom Gegner und nimmt dieses an oder lehnt es ab.
 * Die Strategie wird von aussen vorgegeben muss zum Start des
 * Spiels definiert sein.
 */
class Bot
{
public:
    /// Konstruktor, setzt auch gleich die Strategy.
    /**
     * Die Strategie bestimmt, wie der Bot sich verhaelt und
     * anbietet bzw. wann er Angebote annimmt/ablehnt.
     * Ohne Strategie kann der Bot nicht korrekt funktionieren.
     * Die Strategie sollte vor dem Start definiert sein.
     * Achtung: Das Objekt geht in den Besitz des Bots ueber
     * und wird von diesem destruiert.
     * @param strategyP Die zu verwendende Strategie.
     */
    Bot( BaseStrategy* strategyP = 0 );

    /// Destructor.
    ~Bot();

    /// Setzt die Strategie (nachtraeglich) fuer einen Bot.
    /**
     * Die Strategie bestimmt, wie der Bot sich verhaelt und
     * anbietet bzw. wann er Angebote annimmt/ablehnt.
     * Ohne Strategie kann der Bot nicht korrekt funktionieren.
     * Die Strategie sollte vor dem Start definiert sein.
     * Achtung: Das Objekt geht in den Besitz des Bots ueber
     * und wird von diesem destruiert.
     * @param strategyP Die zu verwendende Strategie.
     */
    void setStrategy( BaseStrategy* strategyP );

    /// Starte ein Spiel.
    /**
     * Es wird solange iteriert, bis der Server ein EXIT sendet.
     * @return true, falls alles okay ist
     */
    bool startGame();

private:
    /////////////////////////////////////////////////////
    // Alles rund um die gewaehlte Strategie
    /////////////////////////////////////////////////////
    
    /// Verarbeitet eine Nachricht und fuehrt entsprechende Aktionen aus.
    /**
     * Je nach dem, was in den Nachricht steht, wird beispielsweise
     * ein Angebot berechnet und abgegeben oder entschieden, ob man
     * ein anderes Angebot annimmt.
     * @param message Id der empfangenen Nachricht.
     * @param value Optionaler Wert, der zur Nachricht gehoert.
     * @return false, wenn es einen Fehler gab und/oder abgebrochen werden soll
     */
    bool processMessage( const MessageId message, const int value );

    /// Berechnet die angebotenen Punkte und gibt diese aus.
    /**
     * Diese Methode ist essentiell und berechnet anhand der
     * Strategie die angebotene Punktzahl. Der Angebotswert
     * muss zwischen 0 und 1000 liegen. Das Angebot wird
     * dann auf STDOUT ausgegeben.
     * @return true, wenn alles okay ist
     */
    bool calculateAndOfferPoints();

    /// Akzeptiert oder lehnt ein Angebot ab.
    /**
     * Diese Methode ist essentiell und berechnet anhand der
     * Strategie, ob der Wert angenommen. Der angebotene Wert
     * muss zwischen 0 und 1000 liegen.
     * @param value Der angebotene Wert.
     * @return true, wenn alles okay ist
     */
    bool acceptOrDeclineOffer( const int value );

private:
    /////////////////////////////////////////////////////
    // Punkte verwalten
    /////////////////////////////////////////////////////

    /// Addiere erhaltene Punktzahl zum Konto.
    /**
     * @param Punkte, die man erhaelt.
     */
    bool addPoints( const int value );

    /// Das Angebot wurde vom Gegner angenommen.
    void otherBotAcceptedOffer();

    /// Das Angebot wurde vom Gegner abgelehnt.
    void otherBotDeclinedOffer();

private:
    /////////////////////////////////////////////////////
    // Memberdaten
    /////////////////////////////////////////////////////
    
    /// Die zu verwendende Strategie bei jedem Spiel.
    /**
     * Theoretisch kann die Strategie von aussen waehrend des
     * Spiels geaendert werden, was aber nicht vorgesehen ist.
     * In einer spaeteren Version soll es moeglich sein,
     * dass je nach Situation eine Strategie automatisch durch
     * eine andere ersetzt wird.
     */
    BaseStrategy* mStrategyP;

    /// Die Bot-Daten eines gesamten Spiels.
    /**
     * Dazu zaehlen die Rundenanzahl und die bereits gewonnenen
     * Punkte.
     */
    BotData mBotData;

    /// Die Bot-Daten der aktuellen Runde.
    /**
     * Dazu zaehlen unter anderem die angebotenen Punkte.
     */
    BotDataCurrent mBotDataCurrent;

    /// Message-Handler zum Senden und Empfangen.
    /**
     * Der Message-Handler empfaengt die Nachrichten vom
     * Server und verarbeitet diese auch gleich, sodass als
     * Rueckgabewert ein Enum steht, welches bestimmt,
     * welche Aktion der Bot nun durchfuehren muss.
     * Daneben ist der Message-Handler auch fuers Senden
     * zustaendig.
     */
    MessageHandler mMessageHandler;
};

#endif // BOT_HH
