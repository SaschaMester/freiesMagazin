#!/usr/bin/env Rscript

# (C) Copyright 2011 Mathias Nerce, Dominik Wagenfuehr
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as
# published by the Free Software Foundation; either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this program. If not, see
# <http://www.gnu.org/licenses/>.

library(lattice)

# Kommandozeilenparameter auslesen
# args[1] = Logdatei mit Werten zum Auslesen (transaction.log)
# args[2] = png-Bildatei zur Ausgabe mit Dateiendung (out.png)
# args[3] = Anzahl der Runden (2500) (oder "all" fuer alle Runden in Log-Datei)
# args[4] = Bildueberschrift
args <- commandArgs(TRUE)
if (length(args) != 4)
  stop("Fehlerhafte Anzahl von Kommandozeilenparametern.")

# Daten von der Log-Datei einlesen
gamedata <- read.csv(args[1], header=FALSE, col.names=c("Source","Offer","Decision"))

# Festlegen, wie viele Runden visualisiert werden sollen
nrRounds <- if (args[3] == "all") length(gamedata$Offer)/2 else as.numeric(args[3])

# PNG-Datei erzeugen
png(args[2], width=1200, height=900)
xyplot(Offer~(ceiling(1:(nrRounds*2)/2)) | Source * Decision,
  data=gamedata,
  par.settings=list(grid.pars=list(fontfamily="sans", cex=2)),
  scales=(list(x=list(alternating=1),y=list(alternating=3))),
  xlab="Runde", xlim=c(0,nrRounds+1),  # Achsenbeschriftungen
  ylab="Angebot", ylim=c(0,1000),
  main=args[4],                    # Bildueberschrift; Untertitel mit sub="..."
  type=c("p","g"),                 # p : Punkte zeichnen, g : mit Gitter (grid)
  pch=21,                          # Art des Punkt-Symbols, z.B. 21 Kreis, 23 Diamant
  cex=.6,                          # Groesse der Punkte (Faktor)
  col=4,                           # Farben der Punkte
  aspect="fill")
dev.off()
