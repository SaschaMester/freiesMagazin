#!/bin/bash

NUMROUNDS=$1

#        "bots/dummybot/bot simple" \
#        "bots/dummybot/bot more" \
#        "bots/dummybot/bot random" \
#        "bots/dummybot/bot semirandom" \

BOTS=( \
        "bots/AndreasZiegelwanger/smartbot" \
        "bots/ChristianDeussen/bot" \
        "python bots/ChristianSchudoma/spartabot.py" \
        "python bots/ChristophThieme/cjtbot1.py" \
        "bots/ClausSchrammel/finder.pl" \
        "bots/DominikWagenfuehr/bot dee" \
        "bots/FelixPassenberg/bot-FeLUX" \
        "bots/FrankStaehr/gerty" \
        "bots/GeorgKindermann/bot gk" \
        "bots/IngoSteiniger/CashGrabber" \
        "java -classpath bots/JanBastian Bot" \
        "bots/JonasOfftermatt/lottomat.py" \
        "java -classpath bots/Lehtis JavaBot" \
        "java -classpath bots/LuekoVoss Bot" \
        "bots/ManuelUnglaub/greybot.py" \
        "python bots/MarioFuest/main.py" \
        "bots/MathiasNerce/UltimatumGameBot" \
        "bots/MaxGrossmann/bot" \
        "bots/MaximilianSchnarr/bot.py" \
        "bots/MichaelMunzert/foxybot" \
        "bots/MichaelSchulz/wyatt.py" \
        "bots/MoritzReinhardt/bot pro" \
        "bots/NickFrank/bot" \
        "bots/StefanMorgenthaler/masterexploder.pl" \
        "bots/SebastianWagner/bot sebix" \
        "bots/TomRichter/ultimatum.py" \
        "bots/WernerZiegelwanger/unibot" \
      )

for BOT1 in "${BOTS[@]}"
do
    for BOT2 in "${BOTS[@]}"
    do
        if [ "$BOT1" != "$BOT2" ]
        then
            echo "(II) BOT1: $BOT1   BOT2: $BOT2"
            echo "(II) START `date`"
            ./start.sh $NUMROUNDS "$BOT1" "$BOT2"
            echo "(II) ENDE `date`"
        fi
    done
done



