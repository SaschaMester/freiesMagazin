/**
    (C) Copyright 2011 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef PLAYER_HH
#define PLAYER_HH

class Player
{
  public:
    /// Konstruktor.
    /**
     * Erstellt einen neuen Spieler mit 0 Punkten.
     */
    Player();

    /// Fuegt eine gewisse Anzahl Punkte hinzu.
    /**
     * Der Wert der Punkte darf negativ sein, wenn man
     * Negativpunkte verteilen will.
     * @param points Punkte, die zu addieren sind.
     */
    void addPoints( const int points );

    /// Gibt die Anzahl an Punkten zurueck.
    /**
     * @return Anzahl der aktuellen Punkte.
     */
    int getPoints() const;

  private:

    /// Anzahl des erspielten Punkte/Geldes.
    int mPoints;
};

#endif // PLAYER_HH
