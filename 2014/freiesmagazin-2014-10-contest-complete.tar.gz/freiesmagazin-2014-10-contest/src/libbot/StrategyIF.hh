/**
    (C) Copyright 2012,2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef STRATEGYIF_HH
#define STRATEGYIF_HH

#include "MessageOperatorIF.hh"

#include <string>

/// Interface fuer eine Strategie.
/**
 * Die konkrete Strategie muss sowohl die Kommandos berechnen,
 * als auch alle konkreten Nachrichten als Operator verarbeiten.
 * Dies realisiert das Strategy-Pattern.
 */
class StrategyIF : public MessageOperatorIF
{
  public:
    /// Destruktor.
    virtual ~StrategyIF() { };

    /// Fragt ab, ob ein Kommando zur Verfuegung steht.
    /**
     * Die Methode wird vom Bot nach dem Empfang jeder (!)
     * Nachricht gerufen. In der Regel stoesst die Start-Nachricht
     * die Berechnung an. Stehen Kommandos zur Verfuegung, muessen
     * diese gleich in die cmdList eingetragen werden.
     * @param[out] cmd Das Kommando, das der Bot ausfuehren soll.
     * @return false, falls keine Kommandos abgeholt werden konnten
     */
    virtual bool isCommandAvailable( std::string& cmd ) = 0;

    /// Gibt zurueck, ob das Spiel zu Ende sein soll.
    /**
     * Die Methode wird vom Bot nach dem Empfang jeder (!)
     * Nachricht gerufen. In der Regel wird true geliefert, nachdem
     * die Ende-Nachricht empfangen wurde. Ggf. aber auch, wenn es
     * zu einem internen Fehler kam und der Bot die Abarbeitung
     * abbrechen soll.
     * @return true, wenn der Bot stoppen soll
     */
    virtual bool isEnd() const = 0;
};

#endif
