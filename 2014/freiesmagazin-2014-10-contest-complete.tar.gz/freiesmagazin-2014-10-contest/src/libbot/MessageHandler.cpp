/**
    (C) Copyright 2011,2012,2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "MessageHandler.hh"
#include "EndMessage.hh"
#include "GameboardEndMessage.hh"
#include "GameboardLineMessage.hh"
#include "GameboardStartMessage.hh"
#include "TextStreamIF.hh"
#include "PlayerMessage.hh"
#include "PlayerOutMessage.hh"
#include "PlayerSetMessage.hh"
#include "StartMessage.hh"
#include "TextMessage.hh"
#include "Player.hh"

#include <iostream>
#include <sstream>

// Konstuktor.
MessageHandler::MessageHandler( TextStreamIF * textStream )
  : mGameboardStarted(false), mTextStream(textStream)
{
    if ( 0 == mTextStream )
    {
#ifdef DEBUG
        std::ostringstream out;
        out << "(EE) MessageHandler::MessageHandler "
            << std::hex << this << std::dec
            << " Pointer to stream is 0."
            << std::endl;
        std::cerr << out.str();
#endif
    }
}

// Empfaengt und prueft eine Nachricht.
bool MessageHandler::receiveMessage( MessageIF*& msgPR )
{
    bool retValue = false;
    msgPR = 0;

#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) MessageHandler::receiveMessage "
        << std::hex << this << std::dec
        << std::endl;
    std::clog << out.str();
#endif

    // Hole Nachricht ab.
    std::string message;
    if ( getTextStdin( message ) )
    {
        // Konvertiere Text in echte Nachricht.
        retValue = createMessage( msgPR, message );
    }

#ifdef DEBUG

    std::ostringstream out2;
    out2 << "(DD) MessageHandler::receiveMessage "
         << std::hex << this << std::dec
         << " Message: " << msgPR
         << " Return: "  << retValue
         << std::endl;
    std::clog << out2.str();
#endif

    return retValue;
}

// Sendet eine Nachricht nach STDOUT.
void MessageHandler::sendTextMessage( const std::string& message ) const
{
    if ( mTextStream )
    {
#ifdef DEBUG
        std::ostringstream out;
        out << "(DD) MessageHandler::sendTextMessage "
            << std::hex << this << std::dec
            << " '" << message << "'" << std::endl;
        std::clog << out.str();
#endif // DEBUG

        mTextStream->writeline( message );
    }
}

// Hole eine Nachricht vom STDIN ab.
bool MessageHandler::getTextStdin( std::string& message ) const
{
    bool retValue = false;

    if ( mTextStream )
    {
/*
#ifdef DEBUG
        std::ostringstream out;
        out << "(DD) MessageHandler::getTextStdin "
            << std::hex << this << std::dec
            << std::endl;
        std::clog << out.str();
#endif // DEBUG
* */

        // Sobald der Bot gestartet wird, wartet er auf eine Eingabe
        // auf STDIN vom Server.
        mTextStream->getline( message );

        if ( !message.empty() )
        {
#ifdef DEBUG
            std::ostringstream out;
            out << "(DD) MessageHandler::getTextStdin "
             << std::hex << this << std::dec
                << " '" << message << "'" << std::endl;
            std::clog << out.str();
#endif // DEBUG

            retValue = true;
        }
    }

    return retValue;
}

// Erstellt eine Nachricht aus einer Textnachricht.
bool MessageHandler::createMessage( MessageIF*& msgPR, const std::string& message )
{
    bool retValue = false;
    msgPR = 0;

#ifdef DEBUG
    if ( !message.empty() )
    {
        std::ostringstream out;
        out << "(DD) MessageHandler::createMessage "
            << std::hex << this << std::dec
            << " create message '" << message << "'" << std::endl;
        std::clog << out.str();
    }
#endif // DEBUG

    if ( message.compare(0, 4, "(DD)") == 0 ||
         message.compare(0, 4, "(II)") == 0 )
    {
        // Debugging-Nachricht
        retValue = createTextMessage( msgPR, message );
    }
    else if ( message.compare(0, 5, "ROUND") == 0 )
    {
        // Start-Nachricht
        retValue = createStartMessage( msgPR, message.substr( 6 ) );
    }
    else if ( message.compare("END") == 0 )
    {
        // Ende-Nachricht
        retValue = createEndMessage( msgPR );
    }
    else if ( message.compare(0, 3, "SET") == 0 )
    {
        // Spieler-Setzen-Nachricht
        retValue = createPlayerSetMessage( msgPR, message.substr( 4 ) );
    }
    else if ( message.compare(0, 3, "POS") == 0 )
    {
        // Spieler-Position-Nachricht
        retValue = createPlayerPosMessage( msgPR, message.substr( 4 ) );
    }
    else if ( message.compare(0, 3, "OUT") == 0 )
    {
        // Spieler-Ausgeschieden-Nachricht
        retValue = createPlayerOutMessage( msgPR, message.substr( 4 ) );
    }
    else if ( message.compare(0, 14, "GAMEBOARDSTART") == 0 )
    {
        // Spielbrett-Start-Nachricht
        retValue = createGameboardStartMessage( msgPR, message.substr( 15 ) );
    }
    else if (  message.compare(0, 12, "GAMEBOARDEND") == 0 )
    {
        // Spielbrett-Ende-Nachricht
        retValue = createGameboardEndMessage( msgPR );
    }
    else if ( mGameboardStarted )
    {
        // Alle Zeilen zwischen Spielbrett-Start und -Ende werden
        // als Spielbrettzeilen interpretiert.
        retValue = createGameboardLineMessage( msgPR, message );
    }
    else
    {
        // Kommando nicht implementiert. Wir erstellen
        // eine Textnachricht, so dass der Client ggf.
        // entstprechend darauf reagieren kann.
        retValue = createTextMessage( msgPR, message );
    }

    if ( 0 == msgPR )
    {
        std::ostringstream out;
        out << "(EE) MessageHandler::createMessage "
            << std::hex << this << std::dec
            << " Pointer to message is 0."
            << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

// Erstellt eine Start-Nachricht.
bool MessageHandler::createStartMessage( MessageIF*& msgPR, const std::string& param ) const
{
    bool retValue = false;
    msgPR = 0;

    // Aktuelle Runde.
    unsigned int round = 0;
    std::istringstream in( param );
    in >> round;

    if ( round > 0 )
    {
        msgPR = new StartMessage( round );
        if ( 0 != msgPR )
        {
            retValue = true;
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) MessageHandler::createStartMessage "
            << std::hex << this << std::dec
            << " Round " << round
            << " is 0."
            << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

// Erstellt eine Ende-Nachricht.
bool MessageHandler::createEndMessage( MessageIF*& msgPR ) const
{
    bool retValue = false;
    msgPR = 0;

    // Bot soll beendet werden.
    msgPR = new EndMessage();
    if ( 0 != msgPR )
    {
        retValue = true;
    }

    return retValue;
}

// Erstellt eine Spieler-Setzen-Nachricht.
bool MessageHandler::createPlayerSetMessage( MessageIF*& msgPR, const std::string& param ) const
{
#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) MessageHandler::createPlayerSetMessage "
        << std::hex << this << std::dec
        << " parameter '" << param << "'" << std::endl;
    std::clog << out.str();
#endif // DEBUG
    
    bool retValue = false;
    msgPR = 0;

    // Spielernummer, Position und Blickrichtung
    unsigned int playerNo = 0;

    // Der erste Wert ist die Spielernummer
    std::istringstream in( param );
    in >> playerNo;

    if ( playerNo > 0 )
    {
        msgPR = new PlayerSetMessage( playerNo );
    }
    else
    {
        std::ostringstream out;
        out << "(EE) MessageHandler::createPlayerSetMessage "
            << std::hex << this << std::dec
            << " Player number " << playerNo
            << " is 0."
            << std::endl;
        std::cerr << out.str();
    }    
    
    if ( 0 != msgPR )
    {
        retValue = true;
    }

    return retValue;
}

// Erstellt eine Spieler-Position-Nachricht.
bool MessageHandler::createPlayerPosMessage( MessageIF*& msgPR, const std::string& param ) const
{
#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) MessageHandler::createPlayerPosMessage "
        << std::hex << this << std::dec
        << " parameter '" << param << "'" << std::endl;
    std::clog << out.str();
#endif // DEBUG
    
    // Die Syntax ist '1 2,3 N'
    bool retValue = false;
    msgPR = 0;

    // Spielernummer, Position und Blickrichtung
    unsigned int playerNo = 0;
    unsigned int x = 0, y = 0;
    std::string dirStr;

    size_t pos = param.find(' ');

    if ( ( std::string::npos != pos ) &&
         ( 0 != pos ) &&
         ( param.length()-1 != pos ) )
    {
        // Der erste Wert ist die Spielernummer
        std::istringstream in( param.substr( 0, pos ) );
        in >> playerNo;

        std::string cmdString = param.substr( pos+1 );

        pos = cmdString.find(' ');
        
        if ( ( std::string::npos != pos ) &&
             ( 0 != pos ) &&
             ( cmdString.length()-1 != pos ) )
        {
            std::string posStr = cmdString.substr( 0, pos );
            dirStr = cmdString.substr( pos+1 );
            
            pos = posStr.find(',');

            if ( ( std::string::npos != pos ) &&
                 ( 0 != pos ) &&
                 ( posStr.length()-1 != pos ) )
            {
                // Danach folgen x- und y-Position eines Feldes.
                std::istringstream in2( posStr.substr( 0, pos ) );
                in2 >> x;

                std::istringstream in3( posStr.substr( pos+1 ) );
                in3 >> y;
            }
            else
            {
                std::ostringstream out;
                out << "(EE) MessageHandler::createPlayerPosMessage "
                    << std::hex << this << std::dec
                    << " Cannot interpret line '"
                    << posStr
                    << "'. Should be in format '3,5'."
                    << std::endl;
                std::cerr << out.str();
            }
        }
        else
        {
            std::ostringstream out;
            out << "(EE) MessageHandler::createPlayerPosMessage "
                << std::hex << this << std::dec
                << " Cannot interpret line '"
                << cmdString
                << "'. Should be in format '3,5 N'."
                << std::endl;
            std::cerr << out.str();
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) MessageHandler::createPlayerPosMessage "
            << std::hex << this << std::dec
            << " Cannot interpret line '"
            << param
            << "'. Should be in format '1 2,3 N'."
            << std::endl;
        std::cerr << out.str();
    }

    if ( playerNo > 0 )
    {
        if ( ( x > 0 ) && ( y > 0 ) )
        {
            if ( Player::isKnownDirection(dirStr) )
            {
                msgPR = new PlayerMessage( playerNo, Position(x, y), dirStr );
            }
            else
            {
                std::ostringstream out;
                out << "(EE) MessageHandler::createPlayerPosMessage "
                    << std::hex << this << std::dec
                    << " Direction '" << dirStr
                    << "' unknown."
                    << std::endl;
                std::cerr << out.str();
            }
        }
        else
        {
            std::ostringstream out;
            out << "(EE) MessageHandler::createPlayerPosMessage "
                << std::hex << this << std::dec
                << " Position (" << x << "," << y << ")"
                << " is 0."
                << std::endl;
            std::cerr << out.str();
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) MessageHandler::createPlayerPosMessage "
            << std::hex << this << std::dec
            << " Player number " << playerNo
            << " is 0."
            << std::endl;
        std::cerr << out.str();
    }    
    
    if ( 0 != msgPR )
    {
        retValue = true;
    }

    return retValue;
}

// Erstellt eine Spieler-Ausgeschieden-Nachricht.
bool MessageHandler::createPlayerOutMessage( MessageIF*& msgPR, const std::string& param ) const
{
#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) MessageHandler::createPlayerOutMessage "
        << std::hex << this << std::dec
        << " parameter '" << param << "'" << std::endl;
    std::clog << out.str();
#endif // DEBUG
    
    bool retValue = false;
    msgPR = 0;

    // Spielernummer, Position und Blickrichtung
    unsigned int playerNo = 0;

    // Der erste Wert ist die Spielernummer
    std::istringstream in( param );
    in >> playerNo;

    if ( playerNo > 0 )
    {
        msgPR = new PlayerOutMessage( playerNo );
    }
    else
    {
        std::ostringstream out;
        out << "(EE) MessageHandler::createPlayerOutMessage "
            << std::hex << this << std::dec
            << " Player number " << playerNo
            << " is 0."
            << std::endl;
        std::cerr << out.str();
    }    
    
    if ( 0 != msgPR )
    {
        retValue = true;
    }

    return retValue;
}

// Erstellt eine Spielbrett-Start-Nachricht.
bool MessageHandler::createGameboardStartMessage( MessageIF*& msgPR, const std::string& param )
{
    bool retValue = false;
    msgPR = 0;

    // Feld-Position.
    unsigned int x = 0, y = 0;

    size_t pos = param.find(',');

    if ( ( std::string::npos != pos ) &&
         ( 0 != pos ) &&
         ( param.length()-1 != pos ) )
    {
        // Danach folgen x- und y-Position eines Feldes.
        std::istringstream in2( param.substr( 0, pos ) );
        in2 >> x;

        std::istringstream in3( param.substr( pos+1 ) );
        in3 >> y;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) MessageHandler::createGameboardStartMessage "
            << std::hex << this << std::dec
            << " Cannot interpret line '"
            << param
            << "'. Should be in format '3,5'."
            << std::endl;
        std::cerr << out.str();
    }

    if ( ( x > 0 ) && ( y > 0 )  )
    {
        // Spielbrettuebertragung startet
        mGameboardStarted = true;
        msgPR = new GameboardStartMessage( Position(x,y) );
        if ( 0 != msgPR )
        {
            retValue = true;
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) MessageHandler::createGameboardStartMessage "
            << std::hex << this << std::dec
            << " Size (" << x << "," << y << ")"
            << " is 0."
            << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

// Erstellt eine Spielbrett-Zeilen-Nachricht.
bool MessageHandler::createGameboardLineMessage( MessageIF*& msgPR, const std::string& param ) const
{
    bool retValue = false;
    msgPR = 0;

    msgPR = new GameboardLineMessage( param );
    if ( 0 != msgPR )
    {
        retValue = true;
    }

    return retValue;
}

// Erstellt eine Spielbrett-Ende-Nachricht.
bool MessageHandler::createGameboardEndMessage( MessageIF*& msgPR )
{
    bool retValue = false;
    msgPR = 0;

    // Spielbrett-Uebertragung ist zu Ende.
    mGameboardStarted = false;
    msgPR = new GameboardEndMessage();
    if ( 0 != msgPR )
    {
        retValue = true;
    }

    return retValue;
}

// Erstellt eine Textnachricht.
bool MessageHandler::createTextMessage( MessageIF*& msgPR, const std::string& param ) const
{
    bool retValue = false;
    msgPR = 0;

    msgPR = new TextMessage( param );
    if ( 0 != msgPR )
    {
        retValue = true;
    }

    return retValue;
}
