/**
    (C) Copyright 2011,2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "Engine.hh"

#include "CommandProcessor.hh"
#include "GameIF.hh"
#include "ServerIF.hh"
#include "Player.hh"

#include <iostream>
#include <sstream>
#include <vector>

// Konstruktor
Engine::Engine( GameIF& game, ServerIF& server, const EngineConfig& config )
: mGameR(game), mServerR(server), mConfig(config), mRounds(0)
{
}

// Destruktor.
Engine::~Engine()
{
}

// Gibt Anzahl gespielter Runden zurueck.
unsigned int Engine::getNumRounds() const
{
    return mRounds;
}

// Startet ein Spiel.
bool Engine::startGame()
{
    bool retValue = false;

    // Pruefe, ob am Server die korrekte Anzahl von Spieler
    // angemeldet ist.
    if ( mServerR.getNumClients() == 2 )
    {
#ifdef DEBUG
        std::ostringstream out3;
        out3 << "(DD) Engine::startGame "
             << std::hex << this << std::dec
             << " Send gameboard."
             << std::endl;
        std::clog << out3.str();
#endif

        mRounds = 0;

        // Sende zuerst das Spielbrett an die Clients.
        // Sende Spielernummern an Clients.
        retValue = sendGameboard() &&
                   sendPlayerNumbers();

        if ( retValue )
        {
#ifdef DEBUG
            std::ostringstream out2;
            out2 << "(DD) Engine::startGame "
                 << std::hex << this << std::dec
                 << " Start game loop."
                 << std::endl;
            std::clog << out2.str();
#endif

            writePlayerDataToLog();

            // Wiederhole, bis das Spiel zu Ende ist.
            while ( !mGameR.isGameEnd() )
            {
                // Starte neue Runde.
                if ( !startRound() )
                {
                    retValue = false;
                    break;
                }
                
                writePlayerDataToLog();
                
                // Pruefe, welcher Spieler ueberlebt hat.
                checkForDeadPlayers();
            }
        }

        // Das Spiel ist vorbei, sende END an alle Clients.
        sendClients( "END" );
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Engine::startGame "
            << std::hex << this << std::dec
            << " Number of clients "
            << mServerR.getNumClients()
            << " must be 2."
            << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

// Starte eine einzelne Runde.
bool Engine::startRound()
{
    bool retValue = true;

    // Erhoehe Rundezaehler.
    mRounds++;

    // Setze neue Spielrunde.
    mGameR.setRound(mRounds);

#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) Engine::startRound "
        << std::hex << this << std::dec
        << " Round: " << mRounds
        << std::endl;
    std::clog << out.str();
#endif

    if ( mConfig.isLog() )
    {
        std::ostringstream roundStr;
        roundStr << "ROUND " << mRounds;
        writeLog( roundStr.str() );
    }

    if ( sendActivePlayerDataToAllPlayers() )
    {
        for ( size_t ii = 0; ii < mServerR.getNumClients(); ii++ )
        {
            if ( !startRoundClient( ii ) )
            {
                retValue = false;
            }
        }
    }
    else
    {
        retValue = false;
    }

#ifdef DEBUG
    std::ostringstream out2;
    out2 << "(DD) Engine::startRound "
         << std::hex << this << std::dec
         << " Return " << retValue
         << std::endl;
    std::clog << out2.str();
#endif

    return retValue;
}

// Schreibe die aktuellen Spielerdaten ins Log
void Engine::writePlayerDataToLog() const
{
    // Logging
    if ( mConfig.isLog() )
    {
        for ( size_t ii = 0; ii < mServerR.getNumClients(); ii++ )
        {
            const PlayerData& player = mGameR.getPlayerData(ii);
            std::ostringstream playerStr;
            playerStr << "POS " << (ii+1) << " "
                      << player.pos.x()
                      << ","
                      << player.pos.y()
                      << " "
                      << player.dir;
            writeLog( playerStr.str() );
        }
    }
}

// Starte eine Runde fuer einen Client.
bool Engine::startRoundClient( const unsigned int index )
{
    bool retValue = true;
    
    // Spieler ignorieren, wenn er nicht mehr lebt.
    if ( !mGameR.getPlayerData(index).isDead )
    {
        // Sende START an Client.
        if ( sendStartCommand(index) )
        {
            // Empfange Antwort vom Client.
            std::string commandStr;
            if ( receiveClientCommand( index, commandStr ) )
            {
#ifdef DEBUG
                // Empfang per Logging ausgeben.
                if ( mConfig.isLog() )
                {
                    std::ostringstream out;
                    out << "(II) P" << index+1 << "< " << commandStr;
                    writeLog( out.str() );
                }
#endif

                // Kommando verarbeiten und auf das Spiel anwenden.
                retValue = mCommandProc.processCommand( index, commandStr, mGameR );
            }
            else
            {
                retValue = false;
            }
        }
        else
        {
            retValue = false;
        }
    }

    return retValue;
}

// Sende Start-Kommando an Client.
bool Engine::sendStartCommand( const unsigned int index )
{
    bool retValue = true;
    
    std::ostringstream roundStr;
    roundStr << mRounds;

    if ( !sendClient( index, "ROUND " + roundStr.str() ) )
    {
        retValue = false;
    }
    
    return retValue;
}

// Sende alle Spielerinformationen an alle aktiven Spieler.
bool Engine::sendActivePlayerDataToAllPlayers()
{
    bool retValue = true;
    
    for ( size_t ii = 0; ii < mServerR.getNumClients(); ii++ )
    {
        const PlayerData& player = mGameR.getPlayerData(ii);

        if ( !player.isDead )
        {
            // Sende Daten aller aktiven Spieler an einen Client.
            retValue = sendActivePlayerData(ii);
        }
    }

    return retValue;
}

// Sende Daten aller aktiven Spieler an einen Client.
bool Engine::sendActivePlayerData( const unsigned int index )
{
    bool retValue = true;
    
    for ( size_t ii = 0; ii < mServerR.getNumClients(); ii++ )
    {
        const PlayerData& player = mGameR.getPlayerData(ii);

        if ( !player.isDead )
        {
            // Nur die Daten nicht ausgeschiedener Spieler senden.
            std::ostringstream playerStr;
            playerStr << "POS " << (ii+1) << " "
                      << player.pos.x()
                      << ","
                      << player.pos.y()
                      << " "
                      << player.dir;

            if ( !sendClient( index, playerStr.str() ) )
            {
                retValue = false;
            }
        }
    }
    
    return retValue;
}

// Empfange Antwort mit dem Befehl der Clients.
bool Engine::receiveClientCommand( const unsigned index, std::string& commandStr )
{
    bool retValue = true;

    if ( !mServerR.receive( index, commandStr ) )
    {
        retValue = false;
    }

#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) Engine::receiveClientCommand "
        << std::hex << this << std::dec
        << " Receiving command '"
        << commandStr
        << "' from client "
        << index << " (" << retValue << ")."
        << std::endl;
    std::clog << out.str();
#endif

    return retValue;
}

// Sende eigene Spielenummer an Client.
bool Engine::sendPlayerNumbers()
{
    bool retValue = true;

    for ( size_t ii = 0; ii < mServerR.getNumClients(); ii++ )
    {
        std::ostringstream message;
        message << "SET " << (ii+1);
        writeLog( message.str() );

        if ( !mServerR.send( ii, message.str() ) )
        {
            retValue = false;
            // kein break, damit alle Clients die Nachricht bekommen
        }
    }

    return retValue;    
}
    
// Sende Spielbrett an Client.
bool Engine::sendGameboard()
{
    bool retValue = false;

    std::vector<std::string> gameboardStrings;
    Position size;

    if ( mGameR.getGameboardInfo( size, gameboardStrings ) )
    {
        std::ostringstream stringStart;
        stringStart << "GAMEBOARDSTART "
                    << size.x() << "," << size.y();

        std::ostringstream stringEnd;
        stringEnd << "GAMEBOARDEND";

        if ( sendClients( stringStart.str() ) )
        {
            retValue = true;

            for ( size_t ii = 0; ii < gameboardStrings.size(); ii++ )
            {
                if ( !sendClients( gameboardStrings[ii] ) )
                {
                    retValue = false;
                    break;
                }
            }

            if ( retValue )
            {
                if ( sendClients( stringEnd.str() ) )
                {
                    retValue = true;
                }
            }
        }
    }

    return retValue;
}

// Sende Nachricht an alle Clients.
bool Engine::sendClients( const std::string& message )
{
    writeLog( message );
    
    bool retValue = true;
    
    for ( size_t ii = 0; ii < mServerR.getNumClients(); ii++ )
    {
        if ( !mServerR.send( ii, message ) )
        {
            retValue = false;
            // kein break, damit alle Clients die Nachricht bekommen
        }
    }
    
    return retValue;
}

// Prueft, welche Spieler neu ausgeschieden sind.
bool Engine::checkForDeadPlayers()
{
    bool retValue = true;
    
    for ( size_t ii = 0; ii < mServerR.getNumClients(); ii++ )
    {
        // check if player would be out of game
        if ( mGameR.checkForDeadPlayer(ii) )
        {
            std::ostringstream playerStr;
            playerStr << "OUT " << (ii+1);

            if ( !sendClients( playerStr.str() ) )
            {
                retValue = false;
            }
            
            std::ostringstream out;
            out << "(II) ROUNDS P" << (ii+1) << ": " << getNumRounds() << std::endl;
            std::clog << out.str();
        }
    }
    
    return retValue;
}
    
// Sende Nachricht an einen Client.
bool Engine::sendClient( const size_t index, const std::string& message )
{
#ifdef DEBUG
    std::ostringstream out;
    out << "(II) P" << index+1 << "> " << message;
    writeLog( out.str() );
#endif

    return mServerR.send( index, message );
}

// Schreibe Log-Nachricht (falls aktiv).
void Engine::writeLog( const std::string& message ) const
{
    if ( mConfig.isLog() )
    {
        // Logging ist aktiv.
        std::ostringstream out;
        out << message << std::endl;
        std::clog << out.str();
    }
}
