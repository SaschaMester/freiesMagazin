/**
    (C) Copyright 2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "OccupiedTile.hh"
#include "TileContextIF.hh"
#include "TileType.hh"

#include <iostream>
#include <sstream>

// Konstruktor.
OccupiedTile::OccupiedTile( TileContextIF * contextP )
  : BaseTile(contextP), mId(0)
{
}

// Kopiert das Feld.
TileIF* OccupiedTile::copy( TileContextIF * contextP ) const
{
    return new OccupiedTile(contextP);
}

// Besetzt ein Feld.
bool OccupiedTile::occupy( const unsigned int id )
{
#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) OccupiedTile::occupy "
         << std::hex << this << std::dec
         << " " << id
         << std::endl;
    std::cerr << out.str();
#endif

    mId = id;
    return true;
}

// Prueft, ob das Feld besetzt ist.
bool OccupiedTile::isOccupied( unsigned int& occupyId ) const
{
    occupyId = mId;
    return true;
}

// Gibt Zeichen zur Ausgabe des Feldes zurueck.
char OccupiedTile::print() const
{
    return '#';
}
