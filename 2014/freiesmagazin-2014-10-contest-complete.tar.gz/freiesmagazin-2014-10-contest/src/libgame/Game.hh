/**
    (C) Copyright 2012,2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef GAME_HH
#define GAME_HH

#include "Gameboard.hh"
#include "GameIF.hh"
#include "Player.hh"

#include <string>
#include <vector>

/// Spieldaten eines Spiels.
class Game : public GameIF
{
  public:
    /// Konstruktor.
    Game();

    /// Destruktor.
    virtual ~Game();

    /// Initialisiert das Spiel.
    /**
     * Dies laedt ein Spielbrett und initialisiert alle Daten,
     * sodass das Spiel stattfinden kann.
     * @param filename Name des zu ladenden Spielbretts
     * @param numPlayers Anzahl Spieler
     * @return true, wenn alles initialisiert werden konnte.
     */
    bool init( const std::string& filename, const unsigned int numPlayers );

    /// Gibt TRUE zurueck, wenn das Spiel vorbei ist.
    virtual bool isGameEnd() const;

    /// Setzt die aktuelle gespielte Runde.
    virtual void setRound( const unsigned int numRounds );

    /// Gibt aktuelle Spielerdaten zurueck.
    /**
     * @param index Spieler-Index (startet bei 0).
     * @return Spielerdaten
     */
    virtual const PlayerData& getPlayerData( const unsigned int index ) const;

    /**
     * Prueft, ob ein Spieler die Runde nicht ueberlebt hat.
     * @param index Spieler-Index (startet bei 0).
     * @return true, wenn der Spieler in der Runde gestorben ist
     */
    virtual bool checkForDeadPlayer( const unsigned int index );

    /// Holt die Informationen zum Spielbrett.
    /**
     * @param size Groesse des Spielbretts.
     * @param stringVector Die einzelnen Zeilen des
     * Spielbretts.
     * @return true, wenn das Spielbrett valide ist
     */
    virtual bool getGameboardInfo( Position& size,
                                   std::vector<std::string>& stringVector ) const;

    /// Dreht den Spieler nach links und geht ein Feld geradeaus.
    virtual bool movePlayerLeft( const unsigned int index );

    /// Dreht den Spieler nach rechts und geht ein Feld geradeaus.
    virtual bool movePlayerRight( const unsigned int index );

    /// Geht ein Feld geradeaus.
    virtual bool movePlayerAhead( const unsigned int index );

  private:
    /**
     *  Liest die Spielerstartposition aus Datei aus.
     * @param filename Filename, der Positionen mittels SET enthaelt.
     * @return true, wenn alles okay war (auch wenn die Datei gar keine
     * Positionen enthielt!)
     */
    bool readPlayStartPosition( const std::string& filename );
  
    /**
     * Extrahiert Spielerposition aus einer Zeile.
     * @param line Eingabezeile, Syntax ist "SET 1 4,5 N"
     * @return true, wenn Position korrekt extrahiert wurde
     */
    bool extractPlayerPosition( const std::string& line );

    /// Setzt eine sinnvolle Spielerposition abhaengig vom Spielbrett.
    /**
     * @return true, wenn ein Feld gefunden wurde
     */
    bool setPlayerStartPosition();

    /**
     * Bewegt den Spieler ein Feld in Blickrichtung.
     * @return TRUE, wenn er bewegt werden konnte.
     */
    bool movePlayer( const unsigned int index );

  private:
    /// Spielbrett.
    Gameboard mGameBoard;

    /// Vektor mit den Spieler.
    std::vector<Player> mPlayers;
};

#endif // GAME_HH
