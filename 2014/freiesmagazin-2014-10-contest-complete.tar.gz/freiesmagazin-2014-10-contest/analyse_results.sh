#!/bin/bash

declare -A SUMPOINTS
declare -A POSROUNDS
declare -A NEGROUNDS

for FILE in "$@"
do
    BOT1=`basename "$FILE" | sed 's/^\([^_]*\)_\([^_]*\)_\([^.]*\)\.txt$/\1/'`
    BOT2=`basename "$FILE" | sed 's/^\([^_]*\)_\([^_]*\)_\([^.]*\)\.txt$/\2/'`
    FIELD=`basename "$FILE" | sed 's/^\([^_]*\)_\([^_]*\)_\([^.]*\)\.txt$/\3/'`
    ROUNDS1=`egrep "SUM-ROUNDS1" "$FILE" | awk '{ print $NF }'`
    ROUNDS2=`egrep "SUM-ROUNDS2" "$FILE" | awk '{ print $NF }'`
    POINTS1=0
    POINTS2=0
    if [ $ROUNDS1 -eq $ROUNDS2 ]
    then
        POINTS1=1
        POINTS2=1
    elif [ $ROUNDS1 -gt $ROUNDS2 ]
    then
        POINTS1=3
        POINTS2=0
    else
        POINTS1=0
        POINTS2=3
    fi

    # echo "$BOT1 $BOT2 $FIELD $ROUNDS1 $ROUNDS2 $POINTS1 $POINTS2"
    
    SUMPOINTS[$BOT1]=$(( ${SUMPOINTS[$BOT1]} + $POINTS1 ))
    SUMPOINTS[$BOT2]=$(( ${SUMPOINTS[$BOT2]} + $POINTS2 ))
    POSROUNDS[$BOT1]=$(( ${POSROUNDS[$BOT1]} + $ROUNDS1 ))
    POSROUNDS[$BOT2]=$(( ${POSROUNDS[$BOT2]} + $ROUNDS2 ))
    NEGROUNDS[$BOT1]=$(( ${NEGROUNDS[$BOT1]} + $ROUNDS2 ))
    NEGROUNDS[$BOT2]=$(( ${NEGROUNDS[$BOT2]} + $ROUNDS1 ))
done


echo "Name,Points,Rounds"
for BOT in ${!SUMPOINTS[@]}
do
    echo "$BOT,${SUMPOINTS[$BOT]},${POSROUNDS[$BOT]}:${NEGROUNDS[$BOT]}"
done

