#!/bin/bash

if [ ! $# -eq 1 -a ! $# -eq 2 ]
then
    echo "Fehler: Es werden ein oder zwei Argument erwartet!"
    echo ""
    echo "Aufruf:   $0 ANZAHL [OPTIONS]"
    echo ""
    echo "Beispiel: $0 1"
    echo "          $0 1 --log"
    echo ""
    echo "Erklaerung: Alle bekannten Bots (im Skript hinterlegt)"
    echo "            werden auf allen vorhandene Spielfeldern"
    echo "            die gewuenschte <ANZAHL> Mal getestet. Das"
    echo "            Ergebnis wird als Logfile im Ordner 'results'"
    echo "            gespeichert."
    exit 1
fi

NUMITER="$1"
OPTIONS="$2"

BOTS=( \
       "bots/Bock/bot"                       \
       "bots/Burow/FalkBot"                  \
       "java -jar bots/Demel/target/HaraldTronBot-1.0.jar" \
       "bots/Knof/src/tronbot"               \
       "bots/Maraun/bot"                     \
       "java -jar bots/Rochefort/edrbot.jar" \
       "java -jar bots/Scharm/target/FM14BFBot-0.5-jar-with-dependencies.jar" \
       "java -jar bots/Schmidhuber/build/Bot.jar" \
       "bots/StaudingerC/bot.py"             \
       "bots/StaudingerP/run_bot.sh"         \
       "bots/Wagenfuehr/bot"                 \
      )

BOTNAMES=( \
           "Bock"        \
           "Burow"       \
           "Demel"       \
           "Knof"        \
           "Maraun"      \
           "Rochefort"   \
           "Scharm"      \
           "Schmidhuber" \
           "StaudingerC" \
           "StaudingerP" \
           "Wagenfuehr"  \
          )

if [ ${#BOTS[@]} != ${#BOTNAMES[@]} ]
then
    echo "Error: Size of BOTS and BOTNAMES does not match!"
    exit 1
fi

FIELDS=`ls fields/*.txt | grep -v "simple\.txt"`
echo $FIELDS

# Verzeichnis für Ergebnisse ablegen
mkdir -p results || exit 1

for INDEX1 in "${!BOTS[@]}"
do
    BOT1="${BOTS[$INDEX1]}"
    BOTNAME1="${BOTNAMES[$INDEX1]}"
    for INDEX2 in "${!BOTS[@]}"
    do
        BOT2="${BOTS[$INDEX2]}"
        BOTNAME2="${BOTNAMES[$INDEX2]}"
        
        #if [ $BOTNAME1 == "Knof" ]
        #then
        
        if [ $BOTNAME1 != $BOTNAME2 ]
        then
            for FIELD in $FIELDS
            do        
                FIELDNAME=`basename "$FIELD"`
                LOGFILE="results/${BOTNAME1}_${BOTNAME2}_${FIELDNAME}"
                #echo -e "\rFIELD $FIELDNAME"

                echo "(II) BOTS: $BOT1 vs. $BOT2" > $LOGFILE
                echo "(II) START `date`" >> $LOGFILE
                for NUM in `seq 1 $NUMITER`
                do
                    #echo -ne "\rGame $NUM of $NUMITER"
                    ./start.sh "$FIELD" "$BOT1" "$BOT2" "$OPTIONS" >> "$LOGFILE" 2>&1 
                done
                echo "(II) END `date`" >> "$LOGFILE"
                #echo -e ""
                
                # do some statistics
                SUMROUNDS1=$(grep "ROUNDS P1:" "$LOGFILE" | awk "{ all += \$4 } END { print all }")
                AVGROUNDS1=$(grep "ROUNDS P1:" "$LOGFILE" | awk "{ all += \$4 } END { print all/$NUMITER }")
                SUMROUNDS2=$(grep "ROUNDS P2:" "$LOGFILE" | awk "{ all += \$4 } END { print all }")
                AVGROUNDS2=$(grep "ROUNDS P2:" "$LOGFILE" | awk "{ all += \$4 } END { print all/$NUMITER }")
                STARTTIME=`grep "^(II) START" "$LOGFILE" | awk '{print $6}'`
                ENDTIME=`grep "^(II) END" "$LOGFILE" | awk '{print $6}'`
                SUMTIME=`echo $STARTTIME $ENDTIME 1 | awk -f subtract_time.awk`
                AVGTIME=`echo $STARTTIME $ENDTIME $NUMITER | awk -f subtract_time.awk`
                echo "(II) SUM-ROUNDS1: $SUMROUNDS1" >> "$LOGFILE"
                echo "(II) SUM-ROUNDS2: $SUMROUNDS2" >> "$LOGFILE"
                echo "(II) SUM-TIME:    $SUMTIME s"  >> "$LOGFILE"
                echo "(II) AVG-ROUNDS1: $AVGROUNDS1" >> "$LOGFILE"
                echo "(II) AVG-ROUNDS2: $AVGROUNDS2" >> "$LOGFILE"
                echo "(II) AVG-TIME:    $AVGTIME s"  >> "$LOGFILE"
            done
        fi
        #fi
    done
done
