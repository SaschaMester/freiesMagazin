/**
    (C) Copyright 2012,2014 Dominik Wagenfuehr
    (C) Copyright 2014 Momme Maraun

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "Strategy.hh"

#include "EndMessage.hh"
#include "GameboardEndMessage.hh"
#include "GameboardLineMessage.hh"
#include "GameboardStartMessage.hh"
#include "PlayerMessage.hh"
#include "PlayerOutMessage.hh"
#include "PlayerSetMessage.hh"
#include "StartMessage.hh"
#include "TextMessage.hh"

#include <iostream>
#include <sstream>
#include <ctime>
#include <cstdlib>

// Konstruktor.
Strategy::Strategy()
  : mData(), mIsFinished(false), mGameboardStarted(false)
{ }

// Destruktor.
Strategy::~Strategy()
{ }

// Werte zuruecksetzen.
void Strategy::reset()
{
}
    
// Behandelt eine Start-Nachricht.
bool Strategy::operate( const StartMessage& message )
{
    mData.numRound = message.getNumRound();
    std::ostringstream out;
//    for (int y=0; y<mData.mapsizey; y++) {
//        out << "(EE) Strategy::operate PlayerMessage" << mData.map[y] << std::endl;
//    }
    std::cerr << out.str();
    // Hier muss nun die Berechnung des Befehls, der an
    // den Server gesendet werden sollen, starten.
    return calcCommand();
}

// Behandelt eine Ende-Nachricht.
bool Strategy::operate( const EndMessage& /* message */ )
{
    mIsFinished = true;
    return true;
}

// Behandelt eine Spieler-Daten-Nachricht.
bool Strategy::operate( const PlayerMessage& message )
{
    bool retValue = false;
    
    if ( mData.playerNo > 0 )
    {
        const unsigned int playerNo = message.getPlayerNo();
        if ( playerNo > 0 ) 
        {
	    // Feld als markiert anzeigen
            int x = message.getPosition().x()-1;
            int y = message.getPosition().y()-1;
            mData.map[y][x] = '#';
            const Position& pos = message.getPosition();
            const Direction dir = message.getDirection();

            if ( playerNo == mData.playerNo )
            {
                mData.position = pos;
                mData.direction = dir;
                retValue = true;
            }
            else
            {
                mData.positionother = pos;
                mData.directionother = dir;
                // Speichere den Wert auch fuer die Gegner.
                retValue = true;
            }
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Strategy::operate PlayerMessage"
                << std::hex << this << std::dec
                << " Player number is not set!"
                << std::endl;
            std::cerr << out.str();
            retValue = false;
        }        
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate PlayerMessage"
            << std::hex << this << std::dec
            << " Own player number is not set yet!"
            << std::endl;
        std::cerr << out.str();
        retValue = false;
    }
    
    return retValue;
}

// Behandelt eine Spieler-Todes-Nachricht.
bool Strategy::operate( const PlayerOutMessage& message )
{
    bool retValue = false;
    
    if ( mData.playerNo > 0 )
    {
        const unsigned int playerNo = message.getPlayerNo();
        if ( playerNo > 0 ) 
        {
            if ( playerNo == mData.playerNo )
            {
                // Man selbst ist ausgeschieden ...
                retValue = true;
            }
            else
            {
                // Speichere den Wert auch fuer die Gegner.
                retValue = true;
            }
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Strategy::operate PlayerOutMessage"
                << std::hex << this << std::dec
                << " Player number is not set!"
                << std::endl;
            std::cerr << out.str();
            retValue = false;
        }        
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate PlayerOutMessage"
            << std::hex << this << std::dec
            << " Own player number is not set yet!"
            << std::endl;
        std::cerr << out.str();
        retValue = false;
    }
    
    return retValue;
}

// Behandelt eine Spieler-Setzen-Nachricht.
bool Strategy::operate( const PlayerSetMessage& message )
{
    bool retValue = false;
    
    if ( 0 == mData.playerNo )
    {
        const unsigned int playerNo = message.getPlayerNo();
        if ( playerNo > 0 ) 
        {
            mData.playerNo = playerNo;
            retValue = true;
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Strategy::operate PlayerSetMessage"
                << std::hex << this << std::dec
                << " Player number is not set!"
                << std::endl;
            std::cerr << out.str();
            retValue = false;
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate PlayerSetMessage"
            << std::hex << this << std::dec
            << " Player number is set a second time!"
            << std::endl;
        std::cerr << out.str();
        retValue = false;
    }
    
    return retValue;
}

// Behandelt eine Spielbrett-Start-Nachricht.
bool Strategy::operate( const GameboardStartMessage& message )
{
    std::srand(std::time(0));
    mData.mapsizex = message.getSize().x();
    mData.mapsizey = message.getSize().y();
    if (mData.mapsizex > 100 || mData.mapsizey > 100) {
        std::ostringstream out;
        out << "(EE) Strategy::operate GameboardStartMessage, Feld größer 100x100 " << std::endl;
        std::cerr << out.str();
    	return false;
    }
    mapline = 0;
    mGameboardStarted = true;
    return true;
}

// Behandelt eine Spielbrett-Zeile-Nachricht.
bool Strategy::operate( const GameboardLineMessage& message )
{
    bool retValue = false;

    if ( mGameboardStarted )
    {
	for (int x=0; x<mData.mapsizex; x++) {
		mData.map[mapline][x] = message.getLine()[x];
	}
        retValue = true;
        mapline++;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate GameboardLineMessage"
            << std::hex << this << std::dec
            << " Gameboard transfer has not been started yet!"
            << std::endl;
        std::cerr << out.str();
        retValue = false;
    }
    
    return retValue;
}

// Behandelt eine Spielbrett-Ende-Nachricht.
bool Strategy::operate( const GameboardEndMessage& message )
{
    mGameboardStarted = false;
    return true;
}

// Behandelt eine Textnachricht.
bool Strategy::operate( const TextMessage& message  )
{
    std::ostringstream out;
    out << "(EE) " << "Strategy::operate TextMessage "
        << std::hex << this << std::dec
        << "'" << message.getText() << "'."
        << " Cannot operate on text messages!"
        << std::endl;
    std::cerr << out.str();
    
    return false;
}

// Fragt ab, ob Kommandos zur Verfuegung stehen.
bool Strategy::isCommandAvailable( std::string& cmd )
{
    bool isAvail = false;

    cmd.clear();
    if ( !mCommand.empty() )
    {
        // Nur, wenn wir ein Kommando haben, wird dieses
        // uebermittelt.
        cmd = mCommand;
        isAvail = true;

        // Nach dem Kopieren sollte man das Kommando unbedingt
        // loeschen, damit bei der naechsten Abfrage nicht aus
        // Versehen noch ein Kommando ansteht.
        mCommand.clear();
    }

    return isAvail;
}

// Gibt zurueck, ob das Spiel zu Ende sein soll.
bool Strategy::isEnd() const
{
    return mIsFinished;
}

// Freie Blöcke um das Feld berechnen
int Strategy::getBlock(int x, int y) {
    int anzahl = 0;
    if (getField(x,y) == '#') return 0;
    if (getField(x-1,y-1) == '.') anzahl++;
    if (getField(x-1,y) == '.') anzahl++;
    if (getField(x-1,y+1) == '.') anzahl++;
    if (getField(x,y-1) == '.') anzahl++;
    if (getField(x,y+1) == '.') anzahl++;
    if (getField(x+1,y-1) == '.') anzahl++;
    if (getField(x+1,y) == '.') anzahl++;
    if (getField(x+1,y+1) == '.') anzahl++;
    return anzahl; 
}
char Strategy::getField(int x, int y) {
    if (x < 0 || x >= mData.mapsizex || y < 0 || y >= mData.mapsizey) {
    	return '#';
    }	
    return mData.map[y][x];
}

char Strategy::getArea(int x, int y) {
    if (x < 0 || x >= mData.mapsizex || y < 0 || y >= mData.mapsizey) {
    	return ' ';
    }	
    return mData.calc[y][x];
}

int Strategy::setField(int x, int y ,char area) {
    int anzahl = 0;
    if (x < 0 || x >= mData.mapsizex || y < 0 || y >= mData.mapsizey) {
    	return 0;
    }	
    if (mData.map[y][x] == '.' && mData.calc[y][x] == ' ') {
        mData.calc[y][x] = area;
    	anzahl++;
	anzahl += setField(x + 1, y, area);
	anzahl += setField(x - 1, y, area);
	anzahl += setField(x, y + 1, area);
	anzahl += setField(x, y - 1, area);
    }
    return anzahl;
}
// Hier wird die Route ermittelt.
bool Strategy::setRoute(int x, int y ,int diff, int endx, int endy) {
    bool reset = false;
    if (x < 0 || x >= mData.mapsizex || y < 0 || y >= mData.mapsizey) {
    	return false;
    }	
    if (mData.route[y][x] == diff) {
	if (x>0 && ((endx == x-1 && endy == y ) || mData.map[y][x-1] == '.' )&& mData.route[y][x-1] == -1) { mData.route[y][x-1] = diff+1; reset = true;}
	if (y>0 && ((endx == x && endy == y-1 ) || mData.map[y-1][x] == '.' )&& mData.route[y-1][x] == -1) { mData.route[y-1][x] = diff+1; reset = true;}
	if (x+1<mData.mapsizex && ((endx == x+1 && endy == y ) || mData.map[y][x+1] == '.') && mData.route[y][x+1] == -1) { mData.route[y][x+1] = diff+1; reset = true;}
	if (y+1<mData.mapsizey && ((endx == x && endy == y+1 ) || mData.map[y+1][x] == '.' )&& mData.route[y+1][x] == -1) { mData.route[y+1][x] = diff+1; reset = true;}
    }
    return reset;
}
// Weg zum Gegner berechnen
bool Strategy::calcRoute() {
    for (int y=0; y<mData.mapsizey; y++) {
        for (int x=0; x<mData.mapsizex; x++) {
	    mData.route[y][x] = -1;
	}
    }	
    int posx = mData.positionother.x()-1;
    int posy = mData.positionother.y()-1;
    int endx = mData.position.x()-1;
    int endy = mData.position.y()-1;
    mData.route[posy][posx] = 0;
    setRoute(posx, posy, 0, endy, endy);
    bool again = true;
    int diff = 0;
    while (again) {
        again = false;
	diff++;
        for (int y=0; y<mData.mapsizey; y++) {
            for (int x=0; x<mData.mapsizex; x++) {
                again |= setRoute(x, y, diff, endx, endy);
    	    }
        }	
    }
//    for (int y=0; y<mData.mapsizey; y++) {
//        std::cerr << "(DD) ";
//        for (int x=0; x<mData.mapsizex; x++) {
//	    std::cerr << "." << char(mData.route[y][x] +64);
//	}
//        std::cerr << std::endl;
//    }	
    return true;
}
//Durchrechnen wieviel Flächen vorhanden sind
bool Strategy::calcField()
{
    for (int y=0; y<mData.mapsizey; y++) {
        for (int x=0; x<mData.mapsizex; x++) {
	    mData.calc[y][x] = ' ';
	}
    }	
    char area = 'A';
    int posx = mData.position.x();
    int posy = mData.position.y();
    mData.fieldcount[0] = setField(posx-1, posy-2, area++);
    mData.field[0] = getArea(posx-1,  posy-2);
    mData.fieldcount[1] = setField(posx, posy-1, area++);
    mData.field[1] = getArea(posx,  posy-1);
    mData.fieldcount[2] = setField(posx-1, posy, area++);
    mData.field[2] = getArea(posx-1,  posy);
    mData.fieldcount[3] = setField(posx-2, posy-1, area++);
    mData.field[3] = getArea(posx-2,  posy-1);
    mData.fieldcount[4] = setField(mData.positionother.x()-1, mData.positionother.y()-2, area++);
    mData.field[4] = getArea(mData.positionother.x()-1,  mData.positionother.y()-2);
    mData.fieldcount[5] = setField(mData.positionother.x(), mData.positionother.y()-1, area++);
    mData.field[5] = getArea(mData.positionother.x(),  mData.positionother.y()-1);
    mData.fieldcount[6] = setField(mData.positionother.x()-1, mData.positionother.y(), area++);
    mData.field[6] = getArea(mData.positionother.x()-1,  mData.positionother.y());
    mData.fieldcount[7] = setField(mData.positionother.x()-2, mData.positionother.y()-1, area++);
    mData.field[7] = getArea(mData.positionother.x()-2,  mData.positionother.y()-1);

    std::ostringstream out;
#ifdef DEBUG
    out << "(DD) " << mData.playerNo << "calcField ";
#endif
    for (int i=0; i<= 7; i++) {
        if (mData.fieldcount[i] == 0 && mData.field[i] >= 'A') {
	    mData.fieldcount[i] = mData.fieldcount[mData.field[i] - 'A'];
	}
#ifdef DEBUG
        out << mData.field[i] << ':' << mData.fieldcount[i] << "   ";
#endif
    }
#ifdef DEBUG
    out << std::endl;
    std::cerr << out.str();
#endif
    return true;
}

std::string Strategy::command(Direction dir, Direction dirnew) {
    if (dir == dirnew) return "AHEAD";
    if ((dir == NORTH && dirnew == EAST) || (dir == EAST && dirnew ==SOUTH) 
        || (dir == SOUTH && dirnew == WEST) || ( dir == WEST && dirnew == NORTH)) return "RIGHT";
    if ((dir == NORTH && dirnew == WEST) || (dir == WEST && dirnew ==SOUTH) 
        || (dir == SOUTH && dirnew == EAST) || ( dir == EAST && dirnew == NORTH)) return "LEFT";
    // Hier sollte vielleicht ein Fehler geschmissen werden.	
    return "AHEAD";
}
// Berechne die drei Aktionen, die spaeter ausgegeben werden sollen.
bool Strategy::calcCommand()
{
    int x = mData.position.x()-1;
    int y = mData.position.y()-1;
    char north = '#';
    char south = '#';
    char west = '#';
    char east = '#';
    if (y > 0) { north=mData.map[y-1][x]; }
    if (x > 0) { west=mData.map[y][x-1]; }
    if (y+1 < mData.mapsizey ) { south=mData.map[y+1][x]; }
    if (x+1 < mData.mapsizex ) { east=mData.map[y][x+1]; }
    int chance = 0;
    if ( north == '.' ) chance++;
    if ( south == '.' ) chance++;
    if ( west == '.' ) chance++;
    if ( east == '.' ) chance++;
    if (chance == 0) {
    	mCommand = "AHEAD";
#ifdef DEBUG
        std::cerr << "(DD) Nichts möglich " << std::endl;
#endif
    	return true;
    }
    // Bei nur einer Möglichkeit gibt es wohl nicht viel zu überlegen.
    if (chance == 1) {
    	if ( north == '.' ) mCommand = command(mData.direction, NORTH);
    	if ( south == '.' ) mCommand = command(mData.direction, SOUTH);
    	if ( west == '.' ) mCommand = command(mData.direction, WEST);
    	if ( east == '.' ) mCommand = command(mData.direction, EAST);
#ifdef DEBUG
        std::cerr << "(DD) " << " 1. Chance " << mCommand << std::endl;
#endif
	return true;
    }
    calcField();
    // Hier wird kontrolliert ob man auf gleichen Flächen unterwegs ist
    bool samearea=false;
    for (int i=4; i<8; i++) {
    	if (mData.fieldcount[i]>0 && mData.field[i] >= 'A' && mData.field[i] <= 'D') {
	    samearea=true;
	    i=8;
	}    
    }
    if (samearea) {
        int abstand = abs(x-mData.positionother.x()-1);
        abstand += abs(y-mData.positionother.y()-1);
	calcRoute();
#ifdef DEBUG
	std::cerr << "(DD) Wegdiff: " << abstand << " -- " << x << "," << y << ":" << char(64+mData.route[y][x]) << std::endl;
#endif
	int min = 99999;
	Direction direction = NORTH;
	if (!(mData.direction == NORTH) && south == '.') { min = mData.route[y+1][x]; direction = SOUTH; }
	if (!(mData.direction == SOUTH) && north == '.') { if (min > mData.route[y-1][x]) {min = mData.route[y-1][x]; direction = NORTH; }}
	if (!(mData.direction == EAST) && west == '.') { if (min > mData.route[y][x-1]) {min = mData.route[y][x-1]; direction = WEST; }}
	if (!(mData.direction == WEST) && east == '.') { if (min > mData.route[y][x+1]) {min = mData.route[y][x+1]; direction = EAST; }}
	mCommand = command(mData.direction, direction);
	return true;
   } 


    // Checken ob ein Weg eine größere Fläche hat
    int maxnew = 0;
    int maximal = 0;
    for (int i=0; i<4; i++) {
        if (maximal == 0 && mData.fieldcount[i] > 0) { maximal = mData.fieldcount[i]; }
	else if (maximal > mData.fieldcount[i] && mData.fieldcount[i] > 0) { maxnew = 1; }
	else if (maximal < mData.fieldcount[i]) { maxnew = 1 ; maximal = mData.fieldcount[i]; }
    }
    if (maxnew == 1) {
        for (int i=0; i<4; i++) {
		if (maximal == mData.fieldcount[i]) {
		    if (i == 0) mCommand = command(mData.direction, NORTH); 
		    if (i == 1) mCommand = command(mData.direction, EAST); 
		    if (i == 2) mCommand = command(mData.direction, SOUTH); 
		    if (i == 3) mCommand = command(mData.direction, WEST); 
#ifdef DEBUG
                    std::cerr << "(DD) " << " Feldtrenner erkannt " << i << ":" << maximal << "-" << mCommand << std::endl;
#endif
		    return true;
		}
        }
    }
	
    // Mal sehen ob wir erst die kleinen füllen
    int b1 = getBlock(x,y-1);
    int b2 = getBlock(x+1,y);
    int b3 = getBlock(x,y+1);
    int b4 = getBlock(x-1,y);
    int min = 99;
    if (b1 > 0) { mCommand = command(mData.direction, NORTH); min = b1; }
    if (b2 > 0 && min>b2) { mCommand = command(mData.direction, EAST); min = b2; }
    if (b3 > 0 && min>b3) { mCommand = command(mData.direction, SOUTH); min = b3; }
    if (b4 > 0 && min>b4) { mCommand = command(mData.direction, WEST); min = b4; }
#ifdef DEBUG
    std::cerr << "(DD) " << "Blöcke zeigen " << b1 << b2 << b3 << b4 << ":" << std::endl;
#endif
    if (min < 99) { 
#ifdef DEBUG
        std::cerr << "(DD) " << " Lückenfüeller " << mCommand << std::endl;
#endif
	return true; 
    } 
    


    int random_variable = (std::rand() & 15 ) + 1;
    while (random_variable > 0) {
        if ( north == '.' && random_variable > 0) { mCommand = command(mData.direction, NORTH); random_variable--; }
        if ( south == '.' && random_variable > 0) { mCommand = command(mData.direction, SOUTH); random_variable--; }
        if ( west == '.' && random_variable > 0) { mCommand = command(mData.direction, WEST); random_variable--; }
        if ( east == '.' && random_variable > 0) { mCommand = command(mData.direction, EAST); random_variable--; }
    }

    // Bei einer echten Strategy findet hier natuerlich eine ganz
    // komplizierte Berechnung statt ...
#ifdef DEBUG
    std::cerr << "(DD) " << "Einfach nur irgendetwas nehmen " << north << east << south << west << ":"<< mCommand << std::endl;
#endif

    return true;
}
