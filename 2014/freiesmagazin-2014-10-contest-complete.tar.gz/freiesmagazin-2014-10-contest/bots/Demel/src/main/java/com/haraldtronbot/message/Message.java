/*
 * Copyright (c) 2014, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */

package com.haraldtronbot.message;

import java.util.List;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * @author hdemel
 */
@Slf4j
@Value
public class Message {
    String command;
    List<String> arguments;
    
    public String getArgument(int index) {
        return arguments.get(index);
    }
    
    public int getIntgerArguemtn(int index) {
        return Integer.valueOf(arguments.get(index));
    }
}
