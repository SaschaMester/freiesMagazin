/*
 * Copyright (c) 2014, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */

package com.haraldtronbot.calculations;

import com.haraldtronbot.board.Board;
import com.haraldtronbot.board.FieldState;
import com.haraldtronbot.board.Pos;
import com.haraldtronbot.game.Action;
import com.haraldtronbot.game.Direction;
import com.haraldtronbot.game.Player;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * @author hdemel
 */
@Slf4j
public class PlanAlone {
    @Getter @Setter static private DistMap d = new DistMap();
    
    private List<Pos> plan = null;

    public Action getAction(Board<FieldState> board, Player player) {
        if(plan==null) {
            plan = getLongestPlan(board, player);
        }
        if(plan.isEmpty()) {
            log.error("No positions left in plan");
            return Action.AHEAD;
        }
        Pos nextPos = plan.remove(0);
        Action action = player.getActionToPos(nextPos);
        if(action==null) {
            log.error("No action found to get " + player + " to " + nextPos);
            return Action.AHEAD;
        }
        return action;
    }
    
    static public List<Pos> getLongestPlan(Board<FieldState> board, Player player) {
        List<Pos> newplan = new ArrayList<>(0);
        for (Action myFirstAction : Action.values()) {
            Pos pos = player.getOneStep(myFirstAction).getPos();
            if(board.isFree(pos)) {
                List<Pos> planCandidate = getLongestPlanStartingWith(board, pos);
                if(planCandidate.size()>newplan.size()) {
                    newplan = planCandidate;
                }
            }
        }
        return newplan;
    }
    
    static public List<Pos> getLongestPlanStartingWith(Board<FieldState> board, Pos startpos) {
        List<Pos> newplan = d.getPathToFurthestPoint(board, startpos);
        newplan.add(0, startpos);
        boolean expanded;
        do {
            expanded = false;
            expanded |= expandInPlace(newplan, board, true);
            expanded |= expandInPlace(newplan, board, false);
        } while(expanded);
        
        return newplan;
    }
    
    static public boolean expandInPlace(List<Pos> plan, Board<FieldState> board, boolean horizontally) {
        boolean expanded = false;
        for (int i = plan.size()-1; i > 0; i--) {
            boolean expansionfound;
            Pos p4 = plan.get(i);
            Pos p1 = plan.get(i-1);
            do {
                expansionfound = false;
                if((horizontally && p1.isVerticalNeighbor(p4))
                        || (!horizontally && p1.isHorziontalNeighbor(p4))) {
                    Pos p3 = p4.getNeighbor(horizontally?Direction.E:Direction.N);
                    Pos p2 = p1.getNeighbor(horizontally?Direction.E:Direction.N);
                    if(board.isFree(p3) && !plan.contains(p3)
                            && board.isFree(p2) && !plan.contains(p2)) {
                        expansionfound = true;
                        expanded = true;
                        plan.add(i, p3);
                        plan.add(i, p2);
                        p4 = p3;
                        p1 = p2;
                        i++;
                    } else {
                        p3 = p4.getNeighbor(horizontally?Direction.W:Direction.S);
                        p2 = p1.getNeighbor(horizontally?Direction.W:Direction.S);
                        if(board.isFree(p3) && !plan.contains(p3)
                            && board.isFree(p2) && !plan.contains(p2)) {
                            expansionfound = true;
                            expanded = true;
                            plan.add(i, p3);
                            plan.add(i, p2);
                            p4 = p3;
                            p1 = p2;
                            i++;
                        }
                    }
                }
            } while(expansionfound);
        }
        
        return expanded;
    }
}
