/*
 * Copyright (c) 2014, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */
package com.haraldtronbot.game;

/**
 *
 * @author hdemel
 */
public enum Action {
    AHEAD, RIGHT, LEFT
}
