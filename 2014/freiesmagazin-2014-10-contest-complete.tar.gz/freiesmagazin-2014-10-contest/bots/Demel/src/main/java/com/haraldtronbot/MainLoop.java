/*
 * Copyright (c) 2014, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */

package com.haraldtronbot;

import com.haraldtronbot.board.Board;
import com.haraldtronbot.board.FieldState;
import com.haraldtronbot.board.Pos;
import com.haraldtronbot.game.Action;
import com.haraldtronbot.game.Direction;
import com.haraldtronbot.game.Game;
import com.haraldtronbot.message.Message;
import com.haraldtronbot.message.MessageParser;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * @author hdemel
 */
@Slf4j
public class MainLoop {
    
    private final BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    private final MessageParser messageParser;
    private Game game = null;

    public MainLoop() {
        messageParser = new MessageParser();
        messageParser.addMessagePattern("(GAMEBOARDSTART)\\s+(\\d+),\\s*(\\d+)");
        messageParser.addMessagePattern("(GAMEBOARDEND)");
        messageParser.addMessagePattern("(SET)\\s+(\\d+)");
        messageParser.addMessagePattern("(POS)\\s+(\\d+)\\s+(\\d+),\\s*(\\d+)\\s+(N|E|S|W)");
        messageParser.addMessagePattern("(ROUND)\\s+(\\d+)");
        messageParser.addMessagePattern("(OUT)\\s+(\\d+)");
        messageParser.addMessagePattern("(END)");
    }    
    
    private String receiveMessage() {
        try {
            return in.readLine();
        } catch (IOException ex) {
            log.error(ex.getMessage(), ex);
            return null;
        }
    }
    
    private void sendMessage(String message) {
        log.info("Sending message: " + message);
        System.out.println(message);
    }
    
    public void loop() {
        String messageString;
        
        Board<FieldState> board = null;
        int transmittedBoardRows = 0;
        boolean gameBoardTransmissionMode = false;
        
        boolean exit=false;
        while(!exit && (messageString=receiveMessage())!=null) {
            log.info("Receiving message: " + messageString);
            try {
                if(gameBoardTransmissionMode) {
                    char[] fields = messageString.toCharArray();
                    for (int i = 0; i < fields.length; i++) {
                        char field = fields[i];
                        if('#'==field) {
                            board.set(new Pos(i, transmittedBoardRows), FieldState.blocked);
                        }
                    }
                    transmittedBoardRows++;
                }
                Message message = messageParser.parseMessage(messageString);
                if(message==null) {
                    if(!gameBoardTransmissionMode) {
                        log.error("Could not parse message: " + messageString);
                    }
                } else {
                    switch(message.getCommand()) {
                        case "GAMEBOARDSTART":
                            board = new Board<>(message.getIntgerArguemtn(0), message.getIntgerArguemtn(1), FieldState.free);
                            gameBoardTransmissionMode = true;
                            break;
                        case "GAMEBOARDEND":
                            gameBoardTransmissionMode = false;
                            game = new Game(board);
                            break;
                        case "SET":
                            game.setMyPlayerNumber(message.getIntgerArguemtn(0));
                            break;
                        case "POS":
                            game.setPlayerPos(message.getIntgerArguemtn(0), message.getIntgerArguemtn(1)-1, message.getIntgerArguemtn(2)-1, Direction.valueOf(message.getArgument(3)));
                            break;
                        case "ROUND":
                            long start = System.currentTimeMillis();
                            Action action = game.calculateAction(message.getIntgerArguemtn(0));
                            log.info("Calc time: " + (System.currentTimeMillis()-start));
                            sendMessage(action.toString());
                            break;
                        case "OUT":
                            game.removePlayer(message.getIntgerArguemtn(0));
                            break;
                        case "END":
                            exit=true;
                            break;
                        default:
                            log.error("Could not process message: " + message);
                    }
                }
            } catch (Exception ex) {
                log.error(ex.toString(), ex);
            }
        }
    }
}
