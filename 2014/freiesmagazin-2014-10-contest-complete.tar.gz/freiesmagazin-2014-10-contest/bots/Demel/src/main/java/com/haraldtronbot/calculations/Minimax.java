/*
 * Copyright (c) 2014, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */

package com.haraldtronbot.calculations;

import com.haraldtronbot.board.Board;
import com.haraldtronbot.board.FieldState;
import com.haraldtronbot.game.Action;
import com.haraldtronbot.game.Player;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * @author hdemel
 */
@Slf4j
public class Minimax {
    @Getter @Setter private DistMap d = new DistMap();
    
    @Value public static class MinimaxAnswerList{
       MinimaxAnswer bestAnswer;
       Set<Action> neutralanswers;
    }
    @Value public static class MinimaxAnswer{
        Action action;
        int score;
        }
    public MinimaxAnswerList calculateMinimax(Board<FieldState> board, Player me, Player opponent, int lookFurther) {
        if(lookFurther<=0) {
            return new MinimaxAnswerList(new MinimaxAnswer(null, calculateScore(board, me, opponent)), null);
        }
        
        Set<Action> neutralanswers = new HashSet<>(3);
        MinimaxAnswer bestAction = new MinimaxAnswer(Action.AHEAD, Integer.MIN_VALUE);
        
        for (Action myAction : Action.values()) {
            Player newMe = me.getOneStep(myAction);
            if(board.isFree(newMe.getPos())) {
                board.set(newMe.getPos(), FieldState.blocked);
                
                int minScoreAfterOpponentMove = Integer.MAX_VALUE;
                
                for (Action opponentAction : Action.values()) {
                    Player newOpponent = opponent.getOneStep(opponentAction);
                    if(board.isFree(newOpponent.getPos())) {
                        board.set(newOpponent.getPos(), FieldState.blocked);
                        
                        int score = calculateMinimax(board, newMe, newOpponent, lookFurther-1).getBestAnswer().getScore();
                        // DEBUG OUT
//                        log.info(lookFurther+": " + score);
//                        log.info(myAction + " " + newMe.toString());
//                        log.info(opponentAction + " " + newOpponent.toString());
//                        log.info(board.toString());
                        // DEBUG OUT END
                        if ( score < minScoreAfterOpponentMove) {
                            minScoreAfterOpponentMove = score;
                        }
                        
                        board.set(newOpponent.getPos(), FieldState.free);
                    } else if (newOpponent.getPos().equals(newMe.getPos())) { // if opponent moves onto same Pos, it's a draw --> score = 0
                        // DEBUG OUT
//                        log.info(lookFurther+": " + 0);
//                        log.info(myAction + " " + newMe.toString());
//                        log.info(opponentAction + " " + newOpponent.toString());
//                        log.info(board.toString());
                        // DEBUG OUT END
                        if ( 0 < minScoreAfterOpponentMove) {
                            minScoreAfterOpponentMove = 0;
                        }
                    }
                }
                
                if(minScoreAfterOpponentMove==0) {
                    neutralanswers.add(myAction);
                }
                
                if(minScoreAfterOpponentMove>bestAction.getScore()) {
                    bestAction = new MinimaxAnswer(myAction, minScoreAfterOpponentMove);
                }

                board.set(newMe.getPos(), FieldState.free);
            }
        }
        
        return new MinimaxAnswerList(bestAction, neutralanswers);
    }
    
    public int calculateScore(Board<FieldState> board, Player me, Player opponent) {
        if(d.canReach(board, me.getPos(), opponent.getPos())) {
            return 0;
        }
        return PlanAlone.getLongestPlan(board, me).size()-PlanAlone.getLongestPlan(board, opponent).size();
    }
}
