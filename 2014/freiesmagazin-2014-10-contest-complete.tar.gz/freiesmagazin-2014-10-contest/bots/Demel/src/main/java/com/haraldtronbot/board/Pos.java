/*
 * Copyright (c) 2014, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */

package com.haraldtronbot.board;

import com.haraldtronbot.game.Direction;
import lombok.Value;

@Value
public class Pos {
    int col;
    int row;

    public Pos getNeighbor(Direction newDirection) {
        int newCol = this.getCol();
        int newRow = this.getRow();
        
        switch(newDirection) {
            case N:
                newRow--;
                break;
            case E:
                newCol++;
                break;
            case S:
                newRow++;
                break;
            case W:
                newCol--;
                break;
            default:
                throw new RuntimeException("unreachable default case of switch");
        }
        return new Pos(newCol, newRow);
    }
    
    public Direction getDirectionTo(Pos to) {
        if(to.getRow() < getRow()) {
            return Direction.N;
        }
        if(to.getCol() > getCol()) {
            return Direction.E;
        }
        if(to.getRow() > getRow()) {
            return Direction.S;
        }
        if(to.getCol() < getCol()) {
            return Direction.W;
        }
        return null;
    }
    
    public boolean isHorziontalNeighbor(Pos to) {
        return getRow()==to.getRow() && Math.abs(getCol()-to.getCol())==1;
    }
    
    public boolean isVerticalNeighbor(Pos to) {
        return getCol()==to.getCol() && Math.abs(getRow()-to.getRow())==1;
    }
}
