/*
 * Copyright (c) 2014, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */

package com.haraldtronbot.calculations;

import com.haraldtronbot.board.Board;
import com.haraldtronbot.board.Pos;
import com.haraldtronbot.board.FieldState;
import com.haraldtronbot.game.Action;
import com.haraldtronbot.game.Direction;
import com.haraldtronbot.game.Player;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import lombok.Value;

public class DistMap {
    
    public static final Integer UNREACHABLE = Integer.MAX_VALUE;
    
    public Board<Integer> generateDistMap(Board<FieldState> board, Pos startpos) {
        return generateDistMapAndMaxDist(board, startpos).getDistMap();
    }
    
    @Value public static class DistMapAndMaxDist {
        Board<Integer> distMap;
        int maxDist;
        Pos maxDistPos;
    }
    public  DistMapAndMaxDist generateDistMapAndMaxDist(Board<FieldState> board, Pos startpos) {
        int maxDist = 0;
        Pos maxDistPos = startpos;
        Board<Integer> ret = new Board<>(board.getCols(), board.getRows(), UNREACHABLE);
        ret.set(startpos, 0);
        Queue<Pos> queue = new ArrayDeque<>();
        queue.add(startpos);
        
        Pos currPos;
        while((currPos=queue.poll())!=null) {
            int dist = ret.get(currPos);
            for (Pos neighbor : ret.getNeighborsWithoutValidityCheck(currPos)) {
                if(ret.get(neighbor, 0)>dist+1 && board.isFreeWithoutValidityCheck(neighbor)) {
                    maxDist = dist+1;
                    maxDistPos = neighbor;
                    ret.set(neighbor, dist+1);
                    queue.add(neighbor);
                }
            }
        }
        return new DistMapAndMaxDist(ret, maxDist, maxDistPos);
    }
    
    public int getReachableFieldsWithBestMove(Board<FieldState> board, Player me) {
        int best = -1;
        for (Action myAction : Action.values()) {
            Player newMe = me.getOneStep(myAction);
            if(board.isFree(newMe.getPos())) {
                int reachableFields = getReachableFields(board, newMe.getPos());
                if (reachableFields > best) {
                    best = reachableFields;
                }
            }
        }
        return best+1;
    }
    
    public int getReachableFields(Board<FieldState> board, Pos startpos) {
        Board<Integer> distMap = generateDistMap(board, startpos);
        return distMap.getNumberOfNonFreeCells();
    }
    
    public boolean canReach(Board<FieldState> board, Pos startpos, Pos destPos) {
        FieldState oldstate = board.get(destPos);
        board.set(destPos, FieldState.free);
        Board<Integer> distMap = generateDistMap(board, startpos);
        if(oldstate!=null) {
            board.set(destPos, oldstate);
        }
        return !distMap.isFree(destPos);
    }
    
    public Map<Integer, List<Pos>> generateDistSequence(Board<FieldState> board, Pos startpos) {
        Board<Integer> ret = new Board<>(board.getCols(), board.getRows(), UNREACHABLE);
        ret.set(startpos, 0);
        Map<Integer, List<Pos>> distSequence = new HashMap<>();
        Queue<Pos> queue = new ArrayDeque<>();
        distSequence.put(0, new ArrayList<>(Arrays.asList(startpos)));
        queue.add(startpos);
        
        Pos currPos;
        while((currPos=queue.poll())!=null) {
            int dist = ret.get(currPos);
            List<Pos> neighbors = ret.getNeighbors(currPos);
            for (Pos neighbor : neighbors) {
                if(board.isFree(neighbor) && ret.get(neighbor)>dist+1) {
                    ret.set(neighbor, dist+1);
                    if(distSequence.containsKey(dist+1)) {
                        distSequence.get(dist+1).add(neighbor);
                    } else {
                        distSequence.put(dist+1, new ArrayList<>(Arrays.asList(neighbor)));
                    }
                    
                    queue.add(neighbor);
                }
            }
        }
        return distSequence;
    }
    
    public List<Pos> getPathToFurthestPoint(Board<FieldState> board, Pos startpos) {
        DistMapAndMaxDist distMapAndMaxDist = generateDistMapAndMaxDist(board, startpos);
        Board<Integer> distMap = distMapAndMaxDist.getDistMap();
        int maxDist = distMapAndMaxDist.getMaxDist();
        Pos farthestPos = distMapAndMaxDist.getMaxDistPos();
        
        List<Pos> ret = new ArrayList<>(maxDist);
        ret.add(0, farthestPos);
        Pos secondFarthestPos = getShorterDistNeighborPos(distMap, maxDist, farthestPos);
        if(secondFarthestPos!=null) {
            ret.add(0, secondFarthestPos);
            while((--maxDist)>1) {
                Direction lastStepDirection = farthestPos.getDirectionTo(secondFarthestPos);
                farthestPos = secondFarthestPos;
                secondFarthestPos = getShorterDistNeighborPosPreferablyAhaed(distMap, maxDist, secondFarthestPos, lastStepDirection);
                ret.add(0, secondFarthestPos);
            }
        }
        return ret;
    }
    
    private Pos getShorterDistNeighborPos(Board<Integer> distMap, int maxDist, Pos maxDistPos) {
        for (Pos neighbor : distMap.getNeighbors(maxDistPos)) {
            if(distMap.get(neighbor) < maxDist) {
                return neighbor;
            }
        }
        return null;
    }
    
    private Pos getShorterDistNeighborPosPreferablyAhaed(Board<Integer> distMap, int maxDist, Pos maxDistPos, Direction direction) {
        for (Action action : Action.values()) {
            Pos neighbor = (new Player(maxDistPos, direction)).getOneStep(action).getPos();
            if(distMap.get(neighbor) < maxDist) {
                return neighbor;
            }
        }
        return null;
    }
}
