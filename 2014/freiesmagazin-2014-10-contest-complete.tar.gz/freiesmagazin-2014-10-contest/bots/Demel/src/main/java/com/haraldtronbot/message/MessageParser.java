/*
 * Copyright (c) 2014, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */

package com.haraldtronbot.message;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * @author hdemel
 */
@Slf4j
public class MessageParser {
    
    private final List<Pattern> messagePatterns = new ArrayList<>();

    public boolean addMessagePattern(String messageRegex) {
        return messagePatterns.add(Pattern.compile(messageRegex));
    }
    
    public Message parseMessage(String messageString) {
        for (Pattern messagePattern : messagePatterns) {
            Matcher matcher = messagePattern.matcher(messageString);
            if(matcher.find()) {
                List<String> arguments = new ArrayList<>();
                for (int i = 2; i <= matcher.groupCount(); i++) {
                    arguments.add(matcher.group(i));
                }
                return new Message(matcher.group(1), arguments);
            }
        }
        return null;
    }
}
