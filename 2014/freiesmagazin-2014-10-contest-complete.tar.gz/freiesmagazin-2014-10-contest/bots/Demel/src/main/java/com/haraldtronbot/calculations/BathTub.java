/*
 * Copyright (c) 2014, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */

package com.haraldtronbot.calculations;

import com.haraldtronbot.board.Board;
import com.haraldtronbot.board.FieldState;
import com.haraldtronbot.board.Pos;
import com.haraldtronbot.game.Action;
import com.haraldtronbot.game.Player;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * @author hdemel
 */
@Slf4j
public class BathTub {
    
    @Getter private final Board<FieldState> board;
    @Getter private final Player drain;
    private final Map<Integer, List<Pos>> sequence;
    private final Board<Double> tub;
    @Getter private final Action action;

    public BathTub(Board<FieldState> board, Player drain, Action action) {
        this.board = board;
        this.drain = drain;
        this.action = action;
        sequence = new DistMap().generateDistSequence(board, drain.getPos());
        tub = new Board<>(board.getCols(), board.getRows(), 1.0d);
    }
    
    public double getBathTubScore() {        
        List<Pos> freeCells = board.getFreeCells();
        double sum = 0.0d;
        for (Pos freeCell : freeCells) {
            sum += tub.get(freeCell);
        }
        return sum/freeCells.size();
    }
    
    public Board<Double> doBathTubIteration() {
        tub.set(drain.getPos(), 0.0d);
        for (List<Pos> sameDistancePostions : sequence.values()) {
            Map<Pos, Double> changes = new HashMap<>();
            for (Pos pos : sameDistancePostions) {
                List<Pos> neighbors = board.getNeighbors(pos);
                double sum = tub.get(pos);
                for (Iterator<Pos> iterator = neighbors.iterator(); iterator.hasNext();) {
                    Pos neighbor = iterator.next();
                    if(!board.isFree(neighbor) || tub.get(neighbor)<=tub.get(pos)) {
                        iterator.remove();
                    } else {
                        sum += tub.get(neighbor);
                    }
                }

                double avg = sum / (neighbors.size()+1);
                changes.put(pos, avg-tub.get(pos));
                for (Pos neighbor : neighbors) {
                    if(changes.containsKey(neighbor)) {
                        changes.put(neighbor, changes.get(neighbor)+avg-tub.get(neighbor));
                    } else {
                        changes.put(neighbor, avg-tub.get(neighbor));
                    }
                }
            }
            for (Map.Entry<Pos, Double> e : changes.entrySet()) {
                tub.set(e.getKey(), tub.get(e.getKey())+e.getValue());
            }
        }
    
        return tub;
    }
    
//    public Board<Double> calculateBathTub(Board<FieldState> board, Pos drain, Integer maxIterations) {
//        Map<Integer, List<Pos>> sequence = new DistMap().generateDistSequence(board, drain);
//        Board<Double> tub = new Board<>(board.getCols(), board.getRows(), 0.0d);
//        tub.set(drain, 1.0e-20d);
//        int iterations = 10;
//        for (int i = 0; i < iterations; i++) {
//            for (List<Pos> sameDistancePostions : sequence.values()) {
//                for (Pos pos : sameDistancePostions) {
//                    List<Pos> neighbors = board.getNeighbors(pos);
//                    
//                    for (Iterator<Pos> iterator = neighbors.iterator(); iterator.hasNext();) {
//                        Pos neighbor = iterator.next();
//                        if(!board.isFree(neighbor)) {
//                            iterator.remove();
//                        }
//                    }
//                    
//                    for (Pos neighbor : neighbors) {
//                        tub.set(neighbor, tub.get(neighbor)+tub.get(pos)/neighbors.size());
//                    }
//                }
//            }
//        }
//    
//        return tub;
//    }
}
