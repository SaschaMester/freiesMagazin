/*
 * Copyright (c) 2014, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */

package com.haraldtronbot.board;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@EqualsAndHashCode
@Getter
public class Board<V> {
    private final int cols;
    private final int rows;
    private final Object cells[][];
    private final V initialCellValue;

    public Board(int cols, int rows, V initialCellValue) {
        this.cols = cols;
        this.rows = rows;
        cells = new Object[cols][rows];
        for (int c = 0; c < cols; c++) {
            for (int r = 0; r < rows; r++) {
                cells[c][r] = initialCellValue;
            }
        }
        this.initialCellValue = initialCellValue;
    }
    
    public Board(Board<V> board) {
        this.cols = board.getCols();
        this.rows = board.getRows();
        cells = new Object[cols][];
        for (int c = 0; c < cols; c++) {
            cells[c] = new Object[rows];
            System.arraycopy(board.getCells()[c], 0, cells[c], 0, rows);
        }
        this.initialCellValue = board.getInitialCellValue();
    }

    public void set(Pos key, V value) {
        cells[key.getCol()][key.getRow()] = value;
    }

    public V get(Pos key) {
//        return isValid(key) ? (V) cells[key.getCol()][key.getRow()] : initialCellValue;
        try {
            return (V) cells[key.getCol()][key.getRow()];
        } catch (Exception ex) {
            return initialCellValue;
        }
    }
    
    public V get(Pos key, V defaultValue) {
//        return isValid(key) ? (V) cells[key.getCol()][key.getRow()] : initialCellValue;
        try {
            return (V) cells[key.getCol()][key.getRow()];
        } catch (Exception ex) {
            return defaultValue;
        }
    }
    
    public Object[][] getStateCopy() {
        Object[][] ret = new Object[cells.length][];
        for (int i = 0; i < cells.length; i++) {
            Object[] aMatrix = cells[i];
            int aLength = aMatrix.length;
            ret[i] = new Object[aLength];
            System.arraycopy(aMatrix, 0, ret[i], 0, aLength);
        }
        return ret;
    }
    
    public List<Pos> getNeighbors(Pos p) {
        List<Pos> ret = new ArrayList<>(4);
        Pos neighbor = new Pos(p.getCol()-1, p.getRow());
        if(isValid(neighbor)) {
            ret.add(neighbor);
        }
        neighbor = new Pos(p.getCol()+1, p.getRow());
        if(isValid(neighbor)) {
            ret.add(neighbor);
        }
        neighbor = new Pos(p.getCol(), p.getRow()-1);
        if(isValid(neighbor)) {
            ret.add(neighbor);
        }
        neighbor = new Pos(p.getCol(), p.getRow()+1);
        if(isValid(neighbor)) {
            ret.add(neighbor);
        }
        return ret;
    }
    
    public Pos[] getNeighborsWithoutValidityCheck(Pos p) {
        return new Pos[]{
            new Pos(p.getCol()-1, p.getRow()),
            new Pos(p.getCol()+1, p.getRow()),
            new Pos(p.getCol(), p.getRow()-1),
            new Pos(p.getCol(), p.getRow()+1)
        };
    }
    
    public boolean isValid(Pos p) {
        return p.getRow()>=0 && p.getRow()<getRows()
                && p.getCol()>=0 && p.getCol()<getCols();
    }
    
    public boolean isFree(Pos p) {
        return isValid(p) && initialCellValue.equals(get(p));
    }
    
    public boolean isFreeWithoutValidityCheck(Pos p) {
        return initialCellValue.equals(get(p));
    }
    
    public List<Pos> getFreeCells() {
        List<Pos> ret = new ArrayList<>();
        for (int row = 0; row < getRows(); row++) {
            for (int col = 0; col < getCols(); col++) {
                Pos pos = new Pos(col, row);
                if(isFree(pos)) {
                    ret.add(pos);
                }
            }
        }
        return ret;
    }
    
    public int getNumberOfNonFreeCells() {
        int ret = 0;
        for (int row = 0; row < getRows(); row++) {
            for (int col = 0; col < getCols(); col++) {
                if(!initialCellValue.equals(cells[col][row])) {
                    ++ret;
                }
            }
        }
        
        return ret;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Board(cols=").append(cols).append(", rows=").append(rows).append(", initialCellValue=").append(initialCellValue).append(")\n");
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                sb.append(get(new Pos(c, r))).append(" ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}
