/*
 * Copyright (c) 2014, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */

package com.haraldtronbot.game;

import com.haraldtronbot.board.Board;
import com.haraldtronbot.board.FieldState;
import com.haraldtronbot.board.Pos;
import com.haraldtronbot.calculations.BathTub;
import com.haraldtronbot.calculations.DistMap;
import com.haraldtronbot.calculations.Minimax;
import com.haraldtronbot.calculations.PlanAlone;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Game {
    @Getter @Setter private DistMap d = new DistMap();
    @Getter @Setter private Minimax m = new Minimax();
    @Getter @Setter private PlanAlone planAlone = new PlanAlone();
    
    private final Board<FieldState> board;
    @Setter private int myPlayerNumber;
    private final Map<Integer, Player> players = new HashMap<>();

    public Game(Board<FieldState> board) {
        this.board = board;
    }
    
    public void setPlayerPos(int playernumber, int col, int row, Direction direction) {
        Pos pos = new Pos(col, row);
        board.set(pos, FieldState.blocked);
        Player player = new Player(pos, direction);
        players.put(playernumber, player);
    }

    public Player removePlayer(int playernumber) {
        return players.remove(playernumber);
    }
    
    public Action calculateAction(int round) {
        Player me = getMe();
        
        if(players.size()>2) { // muli opponent strategy
            double bestScore = 0.0d;
            Action besteAction = Action.AHEAD;
            for (Action action : Action.values()) {
                Player newMe = me.getOneStep(action);
                if(board.isFree(newMe.getPos())) {
                    board.set(newMe.getPos(), FieldState.blocked);

                    BathTub bathTub = new BathTub(board, newMe, action);
                    bathTub.doBathTubIteration();
                    bathTub.doBathTubIteration();
                    double score = 
                            d.getReachableFieldsWithBestMove(board, newMe)
                            - bathTub.getBathTubScore();
                    if(score > bestScore) {
                        bestScore = score;
                        besteAction = action;
                    }

                    board.set(newMe.getPos(), FieldState.free);
                }
            }
            return besteAction;
        } else { // single opponent strategy
            Player opponent = getSingleOpponent();
        
            if(opponent!=null && d.canReach(board, me.getPos(), opponent.getPos())) {
                long mmstart = System.currentTimeMillis();
                
                Minimax.MinimaxAnswerList minimaxAnswerList;
                int recursion = 2;
                long mmlaststart;
                do {
                    mmlaststart = System.currentTimeMillis();
                    minimaxAnswerList = m.calculateMinimax(board, me, opponent, recursion++);
                    if(minimaxAnswerList.getBestAnswer().getScore()>0) {
                        return minimaxAnswerList.getBestAnswer().getAction();
                    }
                    log.info("MMCalc time "+(recursion-1)+": " + (System.currentTimeMillis()-mmstart));
                } while((System.currentTimeMillis()-mmlaststart)*9+(System.currentTimeMillis()-mmstart) < 400);
                log.info("MM Score: " + minimaxAnswerList.getBestAnswer().getAction());
                
                
                
                long btstart = System.currentTimeMillis();

                List<List<BathTub>> myBathTubs = new ArrayList<>(3);
                List<BathTub> opponentBathTubs = new ArrayList<>(3);
                int optimalIterations = 2;

                for (Action myAction : Action.values()) {
                    Player newMe = me.getOneStep(myAction);
                    if(board.isFree(newMe.getPos())
                            && (minimaxAnswerList.getNeutralanswers().isEmpty() || minimaxAnswerList.getNeutralanswers().contains(myAction))) {
                        Board<FieldState> bathTubBoard = new Board<>(board);                            
                        bathTubBoard.set(newMe.getPos(), FieldState.blocked);

//                        for (Action opponentAction : Action.values()) {
//                            Player newOpponent = opponent.getOneStep(opponentAction);
//                            if(bathTubBoard.isFree(newOpponent.getPos())) {
//                                bathTubBoard.set(newOpponent.getPos(), FieldState.blocked);
//                            }
//                        }
                        
                        List<BathTub> tubs = new ArrayList<>(3);
                        for (Action secMyAction : Action.values()) {
                            Player secNewMe = newMe.getOneStep(secMyAction);
                            if(bathTubBoard.isFree(secNewMe.getPos())) {
                                BathTub bathTub = new BathTub(bathTubBoard, secNewMe, myAction);
                                bathTub.doBathTubIteration();
                                tubs.add(bathTub);
                            }
                        }
                        myBathTubs.add(tubs);

                        BathTub bathTub = new BathTub(bathTubBoard, opponent, myAction);
                        bathTub.doBathTubIteration();
                        opponentBathTubs.add(bathTub);

                        int maxDist = d.generateDistMapAndMaxDist(bathTubBoard, newMe.getPos()).getMaxDist()+1;
                        if(maxDist>optimalIterations) {
                            optimalIterations = maxDist;
                        }
                        maxDist = d.generateDistMapAndMaxDist(bathTubBoard, opponent.getPos()).getMaxDist()+1;
                        if(maxDist>optimalIterations) {
                            optimalIterations = maxDist;
                        }
                    }
                }

                log.info("BTCalc first iteration time: " + (System.currentTimeMillis()-btstart));

                int i = 1;
                for (; i < optimalIterations && 
                        ((float)(System.currentTimeMillis()-btstart))*(i+2)/(i+1)<(980.0f-(btstart-mmstart))
                        ; i++) {
                    for (List<BathTub> myBathTubList : myBathTubs) {
                        for (BathTub myBathTub : myBathTubList) {
                            myBathTub.doBathTubIteration();
                        }
                    }
                    for (BathTub bathTub : opponentBathTubs) {
                        bathTub.doBathTubIteration();
                    }
                }

                log.info("BTCalc iterations: " + i + "/" + optimalIterations);

                Action bestAction = Action.AHEAD;
                double bestScore = Double.NEGATIVE_INFINITY;
                for (int bti = 0; bti < myBathTubs.size(); bti++) {
                    List<BathTub> myBathTubList = myBathTubs.get(bti);
                    Action action = Action.AHEAD;
                    double myBathtubScore = Double.POSITIVE_INFINITY;
                    for (BathTub myBathTub : myBathTubList) {
                        myBathtubScore = Math.min(myBathtubScore, myBathTub.getBathTubScore());
                        action = myBathTub.getAction();
                    }
                    
                    int reachScore = 0;
                    if(!myBathTubList.isEmpty()) {
                        reachScore = d.getReachableFieldsWithBestMove(myBathTubList.get(0).getBoard(), myBathTubList.get(0).getDrain());
                    }
                    
                    BathTub opponentBathTub = opponentBathTubs.get(bti);
                    double score = reachScore
                            - myBathtubScore + opponentBathTub.getBathTubScore();
                    if(score > bestScore) {
                        bestAction = action;
                        bestScore = score;
                    }
                }

                return bestAction;
            } else {
                return planAlone.getAction(board, me);
            }            
        }
    }
    
    public Player getMe() {
        return players.get(myPlayerNumber);
    }
    
    public Player getSingleOpponent() {
        ArrayList<Integer> playersnumbers = new ArrayList<>(players.keySet());
        playersnumbers.remove((Integer) myPlayerNumber);
        if(playersnumbers.size()==1) {
            return players.get(playersnumbers.get(0));
        } else {
            return null;
        }
    }
    
    public boolean amIOut() {
        return !players.containsKey(myPlayerNumber);
    }
}
