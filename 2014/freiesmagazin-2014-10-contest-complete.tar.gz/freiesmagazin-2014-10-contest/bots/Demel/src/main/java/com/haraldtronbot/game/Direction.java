/*
 * Copyright (c) 2014, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */
package com.haraldtronbot.game;

/**
 *
 * @author hdemel
 */
public enum Direction {
    N, E, S, W; 

    public Direction getTurned(Action action) {
        int ordinal = this.ordinal();
        if(Action.RIGHT.equals(action)) {
            ordinal++;
        } else if(Action.LEFT.equals(action)) {
            ordinal--;
        }
        return Direction.values()[(ordinal+Direction.values().length)%Direction.values().length];
    }
}
