/*
 * Copyright (c) 2014, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */

package com.haraldtronbot.board;

public enum FieldState {
    free, blocked;
    
    @Override    
    public String toString() {
        if(free.equals(this)) {
            return "_";
        }
        if(blocked.equals(this)) {
            return "x";
        }
        return super.toString(); //To change body of generated methods, choose Tools | Templates.
    }
}
