/*
 * Copyright (c) 2014, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */

package com.haraldtronbot;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Main {
    
    public static void main(String [] args) {
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {

            @Override
            public void uncaughtException(Thread t, Throwable ex) {
                log.error(ex.toString(), ex);
            }
        });
        
        MainLoop mainLoop = new MainLoop();
        mainLoop.loop();
    }
}
