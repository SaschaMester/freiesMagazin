/*
 * Copyright (c) 2014, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */

package com.haraldtronbot.game;

import com.haraldtronbot.board.Pos;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * @author hdemel
 */
@Slf4j
@Value
public class Player {
    Pos pos;
    Direction direction;

    public Player getOneStep(Action action) {
        Direction newDirection = getDirection().getTurned(action);
        Pos newPos = getPos().getNeighbor(newDirection);
        return new Player(newPos, newDirection);
    }
    
    public Action getActionToPos(Pos pos) {
        for (Action action : Action.values()) {
            if(pos.equals(getOneStep(action).getPos())) {
                return action;
            }
        }
        return null;
    }
}
