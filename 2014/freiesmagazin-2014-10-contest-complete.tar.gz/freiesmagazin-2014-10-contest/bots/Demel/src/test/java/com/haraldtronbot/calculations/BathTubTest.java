/*
 * Copyright (c) 2014, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */

package com.haraldtronbot.calculations;

import com.haraldtronbot.board.Board;
import com.haraldtronbot.board.FieldState;
import com.haraldtronbot.board.Pos;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hdemel
 */
public class BathTubTest {
    
    public BathTubTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

//    @Test
//    public void testCalculateBathTubOneIt() {
//        Board<FieldState> board = new Board<>(3, 3, FieldState.free);
//        Pos drain = new Pos(0, 0);
//        Board<Double> tub = new BathTub().calculateBathTub(board, drain, 1);
//        System.out.println(tub);
//        System.out.println(new BathTub().calculateBathTubScore(board, drain, 1));
//        System.out.println("");
//    }
//    
//    @Test
//    public void testCalculateBathTubMaxIt() {
//        Board<FieldState> board = new Board<>(3, 3, FieldState.free);
//        Pos drain = new Pos(0, 0);
//        Board<Double> tub = new BathTub().calculateBathTub(board, drain, Integer.MAX_VALUE);
//        System.out.println(tub);
//        System.out.println(new BathTub().calculateBathTubScore(board, drain, Integer.MAX_VALUE));
//        System.out.println("");
//    }
//    
//    @Test
//    public void testCalculateBathTubWithBlocksMaxIt() {
//        Board<FieldState> board = new Board<>(3, 3, FieldState.free);
//        board.set(new Pos(1, 0), FieldState.blocked);
//        board.set(new Pos(1, 1), FieldState.blocked);
//        Pos drain = new Pos(0, 0);
//        Board<Double> tub = new BathTub().calculateBathTub(board, drain, Integer.MAX_VALUE);
//        System.out.println(tub);
//        System.out.println(new BathTub().calculateBathTubScore(board, drain, Integer.MAX_VALUE));
//        System.out.println("");
//    }
//    
//    @Test
//    public void testCalculateBathTubWithBlocksMaxIt2() {
//        Board<FieldState> board = new Board<>(3, 3, FieldState.free);
//        board.set(new Pos(1, 0), FieldState.blocked);
//        board.set(new Pos(1, 2), FieldState.blocked);
//        Pos drain = new Pos(0, 0);
//        Board<Double> tub = new BathTub().calculateBathTub(board, drain, Integer.MAX_VALUE);
//        System.out.println(tub);
//        System.out.println(new BathTub().calculateBathTubScore(board, drain, Integer.MAX_VALUE));
//        System.out.println("");
//    }
    
//    @Test
//    public void testCalculateBathTubWithBlockst1() {
//        System.out.println("T1");
//        Board<FieldState> board = new Board<>(3, 4, FieldState.free);
//        board.set(new Pos(1, 0), FieldState.blocked);
//        board.set(new Pos(1, 1), FieldState.blocked);
//        board.set(new Pos(1, 3), FieldState.blocked);
//        Pos drain = new Pos(0, 0);
//        Board<Double> tub = new BathTub().calculateBathTub(board, drain, 2);
//        System.out.println(tub);
//        System.out.println(new BathTub().calculateBathTubScore(board, drain, 2));
//        System.out.println("");
//    }
//    
//    @Test
//    public void testCalculateBathTubWithBlockst2() {
//        System.out.println("T2");
//        Board<FieldState> board = new Board<>(3, 4, FieldState.free);
//        board.set(new Pos(1, 0), FieldState.blocked);
//        board.set(new Pos(1, 1), FieldState.blocked);
//        board.set(new Pos(1, 3), FieldState.blocked);
//        Pos drain = new Pos(0, 3);
//        Board<Double> tub = new BathTub().calculateBathTub(board, drain, 2);
//        System.out.println(tub);
//        System.out.println(new BathTub().calculateBathTubScore(board, drain, 2));
//        System.out.println("");
//    }
}
    
