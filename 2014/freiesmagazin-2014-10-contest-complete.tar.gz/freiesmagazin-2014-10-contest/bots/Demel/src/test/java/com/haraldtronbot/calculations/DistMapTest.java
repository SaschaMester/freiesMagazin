/*
 * Copyright (c) 2014, Harald Demel
 * This program is released under the FreeBSD License.
 * You should have received a copy of the FreeBSD License along with this program.
 */

package com.haraldtronbot.calculations;

import com.haraldtronbot.board.Board;
import com.haraldtronbot.board.FieldState;
import com.haraldtronbot.board.Pos;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hdemel
 */
public class DistMapTest {
    
    public DistMapTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testGenerateDistMap() {
        Board<FieldState> board = new Board<>(3, 3, FieldState.free);
        Board<Integer> distMap = new DistMap().generateDistMap(board, new Pos(0, 0));
        
        System.out.println(board);
        System.out.println();
        System.out.println();
        System.out.println(distMap);
        assertEquals(4, (long) distMap.get(new Pos(2, 2)));
    }
    
    @Test
    public void testPathToFurthestPoint() {
        Board<FieldState> board = new Board<>(4, 4, FieldState.free);
        board.set(new Pos(1, 0), FieldState.blocked);
        board.set(new Pos(2, 0), FieldState.blocked);
        board.set(new Pos(3, 0), FieldState.blocked);
        board.set(new Pos(0, 1), FieldState.blocked);
        board.set(new Pos(2, 1), FieldState.blocked);
        List<Pos> pathToFurthestPoint = new DistMap().getPathToFurthestPoint(board, new Pos(3, 3));
        
        assertEquals(4, pathToFurthestPoint.size());
    }
}
    
