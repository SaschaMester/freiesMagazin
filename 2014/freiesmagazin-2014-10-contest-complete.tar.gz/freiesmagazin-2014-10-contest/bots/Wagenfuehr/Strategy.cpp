/**
    (C) Copyright 2012,2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "Strategy.hh"

#include "EndMessage.hh"
#include "GameboardEndMessage.hh"
#include "GameboardLineMessage.hh"
#include "GameboardStartMessage.hh"
#include "PlayerMessage.hh"
#include "PlayerOutMessage.hh"
#include "PlayerSetMessage.hh"
#include "StartMessage.hh"
#include "TextMessage.hh"

#include <cassert>
#include <iostream>
#include <queue>
#include <sstream>

// Konstruktor.
Strategy::Strategy()
  : mData(), mIsFinished(false), mGameboardStarted(false), mGameboardSize(0,0)
{ }

// Destruktor.
Strategy::~Strategy()
{ }

// Werte zuruecksetzen.
void Strategy::reset()
{
}
    
// Behandelt eine Start-Nachricht.
bool Strategy::operate( const StartMessage& message )
{
    mData.numRounds = message.getNumRound();

    // Hier muss nun die Berechnung des Befehls, der an
    // den Server gesendet werden sollen, starten.
    return calcCommand();
}

// Behandelt eine Ende-Nachricht.
bool Strategy::operate( const EndMessage& /* message */ )
{
    mIsFinished = true;
    return true;
}

// Behandelt eine Spieler-Daten-Nachricht.
bool Strategy::operate( const PlayerMessage& message )
{
    bool retValue = false;
    
    if ( mData.playerNo > 0 )
    {
        const unsigned int playerNo = message.getPlayerNo();
        if ( playerNo > mData.players.size() )
        {
            mData.players.resize(playerNo);
        }
        if ( playerNo > 0 ) 
        {
            const Position& pos = message.getPosition();
            const Direction dir = message.getDirection();

            mData.gameBoard.occupy( pos );

            mData.players[playerNo-1].setPosition(pos);

            // Das Interface laesst ein direktes Setzen der Richtung nicht zu.
            while ( dir != mData.players[playerNo-1].getData().dir )
            {
                mData.players[playerNo-1].turnRight();
            }
            assert( dir == mData.players[playerNo-1].getData().dir );
            retValue = true;
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Strategy::operate PlayerMessage"
                << std::hex << this << std::dec
                << " Player number is not set!"
                << std::endl;
            std::cerr << out.str();
            retValue = false;
        }        
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate PlayerMessage"
            << std::hex << this << std::dec
            << " Own player number is not set yet!"
            << std::endl;
        std::cerr << out.str();
        retValue = false;
    }
    
    return retValue;
}

// Behandelt eine Spieler-Todes-Nachricht.
bool Strategy::operate( const PlayerOutMessage& message )
{
    bool retValue = false;
    
    if ( mData.playerNo > 0 )
    {
        const unsigned int playerNo = message.getPlayerNo();
        if ( playerNo > mData.players.size() )
        {
            mData.players.resize(playerNo);
        }
        if ( playerNo > 0 ) 
        {
            mData.players[playerNo-1].setDead();
            retValue = true;
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Strategy::operate PlayerOutMessage"
                << std::hex << this << std::dec
                << " Player number is not set!"
                << std::endl;
            std::cerr << out.str();
            retValue = false;
        }        
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate PlayerOutMessage"
            << std::hex << this << std::dec
            << " Own player number is not set yet!"
            << std::endl;
        std::cerr << out.str();
        retValue = false;
    }
    
    return retValue;
}

// Behandelt eine Spieler-Setzen-Nachricht.
bool Strategy::operate( const PlayerSetMessage& message )
{
    bool retValue = false;
    
    if ( 0 == mData.playerNo )
    {
        const unsigned int playerNo = message.getPlayerNo();
        if ( playerNo > mData.players.size() )
        {
            mData.players.resize(playerNo);
        }
        if ( playerNo > 0 )
        {
            mData.playerNo = playerNo;
            retValue = true;
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Strategy::operate PlayerSetMessage"
                << std::hex << this << std::dec
                << " Player number is not set!"
                << std::endl;
            std::cerr << out.str();
            retValue = false;
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate PlayerSetMessage"
            << std::hex << this << std::dec
            << " Player number is set a second time!"
            << std::endl;
        std::cerr << out.str();
        retValue = false;
    }
    
    return retValue;
}

// Behandelt eine Spielbrett-Start-Nachricht.
bool Strategy::operate( const GameboardStartMessage& message )
{
    mGameboardStarted = true;
    mGameboardStrings.clear();
    mGameboardSize = message.getSize();
    return true;
}

// Behandelt eine Spielbrett-Zeile-Nachricht.
bool Strategy::operate( const GameboardLineMessage& message )
{
    bool retValue = false;

    if ( mGameboardStarted )
    {
        mGameboardStrings.push_back( message.getLine() );
        retValue = true;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate GameboardLineMessage"
            << std::hex << this << std::dec
            << " Gameboard transfer has not been started yet!"
            << std::endl;
        std::cerr << out.str();
    }
    
    return retValue;
}

// Behandelt eine Spielbrett-Ende-Nachricht.
bool Strategy::operate( const GameboardEndMessage& message )
{
    bool retValue = false;
    
    if ( mGameboardStarted )
    {
        retValue = mData.gameBoard.create( mGameboardSize,
                                           mGameboardStrings );
                                             
        mGameboardStarted = false;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate GameboardEndMessage"
            << std::hex << this << std::dec
            << " Gameboard transfer has not been started yet!"
            << std::endl;
        std::cerr << out.str();
    }

#ifdef DEBUG
    {
        std::ostringstream out;
        out << "(DD) Strategy::operate(GameboardEndMessage) "
            << std::hex << this << std::dec
            << " Return: " << retValue
            << std::endl;
        std::cerr << out.str();
     }
#endif

    return retValue;
}

// Behandelt eine Textnachricht.
bool Strategy::operate( const TextMessage& message  )
{
    std::ostringstream out;
    out << "(EE) " << "Strategy::operate TextMessage "
        << std::hex << this << std::dec
        << "'" << message.getText() << "'."
        << " Cannot operate on text messages!"
        << std::endl;
    std::cerr << out.str();
    
    return false;
}

// Fragt ab, ob Kommandos zur Verfuegung stehen.
bool Strategy::isCommandAvailable( std::string& cmd )
{
    bool isAvail = false;

    cmd.clear();
    if ( !mCommand.empty() )
    {
        // Nur, wenn wir ein Kommando haben, wird dieses
        // uebermittelt.
        cmd = mCommand;
        isAvail = true;

        // Nach dem Kopieren sollte man das Kommando unbedingt
        // loeschen, damit bei der naechsten Abfrage nicht aus
        // Versehen noch ein Kommando ansteht.
        mCommand.clear();
    }

    return isAvail;
}

// Gibt zurueck, ob das Spiel zu Ende sein soll.
bool Strategy::isEnd() const
{
    return mIsFinished;
}

static const unsigned int numCommands = 3;
static const char* const possibleCommands[numCommands] = { "AHEAD", "RIGHT", "LEFT" };

// Berechne die Aktion, die spaeter ausgegeben werden sollen.
bool Strategy::calcCommand()
{
    bool isValid = true;
    
    mCommand = "";

    int numPoints = -2;

    for ( unsigned int ii = 0; ii < numCommands; ii++ )
    {
        // Daten kopieren
        StrategyData data = mData;
        int tempNumPoints = 0;
        
        // Modifiziert die Spieldaten entsprechend des Kommandos.
        if ( !modifyData( data, data.playerNo, possibleCommands[ii] ) )
        {
            mCommand = "AHEAD";
            isValid = false;
            break;
        }
        /*
        const unsigned int otherPlayerNo = data.playerNo%2+1;
        if ( !modifyData( data, otherPlayerNo, possibleCommands[jj] ) )
        {
            mCommand = "AHEAD";
            isValid = false;
            break;
        }
        */

        // Bewertung des Zuges!
        tempNumPoints = calculateMovementPoints( data );
    
#ifdef DEBUG
        {
            std::ostringstream out;
            out << "(DD) Strategy::calcCommand "
                << std::hex << this << std::dec
                << " Command: " << possibleCommands[ii]
                << " Position: " << data.players[data.playerNo-1].getData().pos
                << " Points: " << tempNumPoints
                << std::endl;
            std::cerr << out.str();
         }
#endif

        if ( tempNumPoints > numPoints )
        {
#ifdef DEBUG
            {
                std::ostringstream out;
                out << "(DD) Strategy::calcCommand "
                    << std::hex << this << std::dec
                    << " " << tempNumPoints
                    << " > " << numPoints
                    << " => " << possibleCommands[ii]
                    << std::endl;
                std::cerr << out.str();
             }
#endif
            numPoints = tempNumPoints;
            mCommand = possibleCommands[ii];
        }
    } // for ii

    return isValid;
}

// Modifiziert die Spieldaten anhand des Kommandos.
bool Strategy::modifyData( StrategyData& data,
                           const unsigned int playerNo,
                           const std::string& command )
{
    bool isValid = true;

    assert( 0 < playerNo);
    assert( playerNo <= data.players.size() );

    if ( data.players[playerNo-1].getData().isCrashed )
    {
        // Bot ist bereits gegen etwas gefahren.
        // Dann veraendern wir die Daten nicht.
    }
    else
    {
#ifdef DEBUG
        const Direction oldDir = data.players[playerNo-1].getData().dir;
#endif
        
        if ( command.compare( "AHEAD" ) == 0 )
        {
        }
        else if ( command.compare( "RIGHT" ) == 0 )
        {
            data.players[playerNo-1].turnRight();
        }
        else if ( command.compare( "LEFT" ) == 0 )
        {
            data.players[playerNo-1].turnLeft();
        }
        else
        {
            std::ostringstream out;
            out << "(EE) " << "Strategy::modify "
                << std::hex << this << std::dec
                << "Unknown command: '"
                << command
                << "'."
                << std::endl;
            std::cerr << out.str();
            isValid = false;  
        }

        // Bot bewegen.
        const Position newPos = data.players[playerNo-1].tryMove();
        
#ifdef DEBUG
        {
            std::ostringstream out;
            out << "(DD) Strategy::modify "
                << std::hex << this << std::dec
                << " Old Pos: " << data.players[playerNo-1].getData().pos
                << " Old Dir: " << oldDir
                << " => "
                << " New Dir: " << data.players[playerNo-1].getData().dir
                << " New Pos: " << newPos
                << std::endl;
            std::cerr << out.str();
         }
#endif

        data.players[playerNo-1].setPosition( newPos );

        if ( !data.gameBoard.isValidPos( newPos, true ) ||
              data.gameBoard.isOccupied( newPos ) )
        {
            // Bot ist gegen etwas gefahren.
            data.players[playerNo-1].markCrashed();
        }

        // Markiere Feld als besetzt.
        if ( data.gameBoard.isValidPos( newPos, true ) )
        {
            data.gameBoard.occupy( newPos );
        }
    }
    
    return isValid;
}

// Berechnet die Anzahl an moeglichen Bewegungspunkten.
int Strategy::calculateMovementPoints( StrategyData& data ) const
{
    int numPoints = 0;
    
    if ( data.players[data.playerNo-1].getData().isCrashed )
    {
        // Bot ist gegen etwas gefahren.
        numPoints = -1;
    }
    else
    {
        // Die Spielerstartposition ist die Initialposition, von wo aus man sucht.
        std::queue<Position> positionsToCheck;
        positionsToCheck.push( data.players[data.playerNo-1].getData().pos );
        data.gameBoard.setChecked( data.players[data.playerNo-1].getData().pos );
        
        Position checkPos[5];
        while ( !positionsToCheck.empty() )
        {
            checkPos[0] = positionsToCheck.front();
            positionsToCheck.pop();
            checkPos[1].setPosition( checkPos[0].x(), checkPos[0].y()-1 );
            checkPos[2].setPosition( checkPos[0].x()+1, checkPos[0].y() );
            checkPos[3].setPosition( checkPos[0].x(), checkPos[0].y()+1 );
            checkPos[4].setPosition( checkPos[0].x()-1, checkPos[0].y() );
            
            for ( unsigned int ii = 1; ii < 5; ii++ )
            {
                if ( data.gameBoard.isValidPos( checkPos[ii], true ) )
                {
                    if ( !data.gameBoard.isOccupied( checkPos[ii] ) &&
                         !data.gameBoard.isChecked( checkPos[ii] ) )
                    {
                        // Das Feld ist nicht besetzt und wurde auch noch
                        // nicht geprueft, also fuegen wir es hinzu.
                        positionsToCheck.push( checkPos[ii] );
                        data.gameBoard.setChecked( checkPos[ii] );
                        numPoints++;
                    }
                }
            }
        }
    }

    return numPoints;
}
