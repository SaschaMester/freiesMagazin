/**
    (C) Copyright 2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "MinimalGameboard.hh"

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>

// Konstruktor.
MinimalGameboard::MinimalGameboard()
  : mSize(0,0)
{
}

// Destruktor.
MinimalGameboard::~MinimalGameboard()
{
    clear();
}

// Kopierkonstruktor.
MinimalGameboard::MinimalGameboard( const MinimalGameboard& board )
  : mSize(0,0)
{
    operator=(board);
}

// Zuweisungsoperator.
MinimalGameboard& MinimalGameboard::operator=( const MinimalGameboard& board )
{
    if ( this != &board )
    {
        clear();
        mSize = board.mSize;
        mTiles = board.mTiles;
    }
    return *this;
}

// Loescht alle Spielbrettdaten.
void MinimalGameboard::clear()
{
    mTiles.clear();
}

// Erzeugt ein Spielbrett aus einer Stringliste.
bool MinimalGameboard::create( const Position& size,
                               const std::vector<std::string>& lines )
{
    bool retValue = false;

#ifdef DEBUG
    {
        std::ostringstream out;
        out << "(DD) MinimalGameboard::create "
            << std::hex << this << std::dec
            << " Size: "
            << size
            << std::endl;
        std::cerr << out.str();
     }
#endif

    if ( lines.size() == size.y() )
    {
        if ( setSize( size ) )
        {
            retValue = true;
            for ( unsigned int jj = 0; jj < size.y(); jj++ )
            {
                if ( lines[jj].length() == size.x() )
                {
                    if ( !extractAndSetTiles( jj+1, lines[jj] ) )
                    {
                        retValue = false;
                        break;
                    }
                }
                else
                {
                    std::ostringstream out;
                    out << "(EE) MinimalGameboard::create "
                        << std::hex << this << std::dec
                        << " Line "
                        << jj
                        << " has length "
                        << lines[jj].length()
                        << "; differs from board with "
                        << size.x()
                        << "."
                        << std::endl;
                    std::cerr << out.str();
                    retValue = false;
                    break;
                }
            } // for jj
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) MinimalGameboard::create "
            << std::hex << this << std::dec
            << " Height of game board "
            << size.y()
            << " does not equal number of lines "
            << lines.size()
            << "."
            << std::endl;
        std::cerr << out.str();
    }

#ifdef DEBUG
    std::ostringstream out2;
    out2 << "(DD) MinimalGameboard::create "
         << std::hex << this << std::dec
         << " Return: "
         << retValue
         << std::endl;
    std::cerr << out2.str();
#endif
    
    return retValue;
}

// Besetzt ein Feld.
bool MinimalGameboard::occupy( const Position& pos )
{
    if ( isValidPos( pos ) )
    {
        mTiles[ getIntPos(pos) ].occupied = true;
        return true;
    }
    return false;
}

// Prueft, ob das Feld besetzt ist.
bool MinimalGameboard::isOccupied( const Position& pos ) const
{
    if ( isValidPos( pos ) )
    {
        return mTiles[ getIntPos(pos) ].occupied;
    }
    return false;
}

// Prueft, ob die Position fuer das Spielbrett valide ist.
bool MinimalGameboard::isValidPos( const Position& pos, const bool noError ) const
{
    bool valid = false;

    // Achtung: Position faengt bei (1,1) an.
    if ( pos.isValid() && pos <= mSize )
    {
        valid = true;
    }
    else if ( !noError )
    {
        std::ostringstream out;
        out << "(EE) MinimalGameboard::isValidPos "
            << std::hex << this << std::dec
            << " Invalid position "
            << pos
            << " for boardsize "
            << mSize
            << "."
            << std::endl;
        std::cerr << out.str();
    }
    
    return valid;
}

// Markiert ein Feld als geprueft.
bool MinimalGameboard::setChecked( const Position& pos )
{
    if ( isValidPos( pos ) )
    {
        mTiles[ getIntPos(pos) ].checked = true;
        return true;
    }
    return false;
}

// Prueft, ob das Feld geprueft wurde.
bool MinimalGameboard::isChecked( const Position& pos) const
{
    if ( isValidPos( pos ) )
    {
        return mTiles[ getIntPos(pos) ].checked;
    }
    return false;
}

// Liefert Position in interner Datenstruktur.
unsigned int MinimalGameboard::getIntPos( const Position& pos ) const
{
    // Achtung: Position faengt bei (1,1) an.
    return getIntPos( pos.x(), pos.y() );
}

// Liefert Position in interner Datenstruktur.
unsigned int MinimalGameboard::getIntPos( const unsigned int x,
                                   const unsigned int y ) const
{
    // Achtung: Position faengt bei (1,1) an.
    return (y-1)*(mSize.x()) + (x-1);
}

// Setzt neue Spielbrettgroesse und allokiert Speicher dafuer.
bool MinimalGameboard::setSize( const Position& newSize )
{
    bool valid = false;

    if ( newSize.isValid() )
    {
        clear();

        // Neue Groesse setzen.
        mSize = newSize;
        mTiles.resize( mSize.x() * mSize.y() );

        for ( unsigned int ii = 0; ii < mSize.x() * mSize.y(); ii++ )
        {
            mTiles[ii].occupied = false;
            mTiles[ii].checked = false;
        }

        valid = true;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) MinimalGameboard::setSize "
            << std::hex << this << std::dec
            << " Invalid size "
            << newSize
            << "."
            << std::endl;
        std::cerr << out.str();        
        valid = false;
    }

    return valid;
}

// Extrahiert eine zweidimensionale Groesse aus der Zeile.
bool MinimalGameboard::extractSize( Position& size, const std::string& line ) const
{
    bool valid = false;
    
    size.setPosition(0,0);

    // Feld-Position.
    unsigned int x = 0, y = 0;

    size_t pos = line.find(',');

    if ( ( std::string::npos != pos ) &&
         ( 0 != pos ) &&
         ( line.length()-1 != pos ) )
    {
        // Danach folgen x- und y-Position eines Feldes.
        std::istringstream in2( line.substr( 0, pos ) );
        in2 >> x;

        std::istringstream in3( line.substr( pos+1 ) );
        in3 >> y;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) MinimalGameboard::extractSize "
            << std::hex << this << std::dec
            << " Cannot interpret line '"
            << line
            << "'. Should be in format '3,5,?'."
            << std::endl;
        std::cerr << out.str();
    }

#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) MinimalGameboard::extractSize "
        << std::hex << this << std::dec
        << " Size: "
        << "(" << x << "," << y << ")"
        << "."
        << std::endl;
    std::clog << out.str();        
#endif // DEBUG

    if ( ( x > 0 ) && ( y > 0 )  )
    {
        size.setPosition( (unsigned int)x, (unsigned int)y );
        valid = true;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) MinimalGameboard::extractSize "
            << std::hex << this << std::dec
            << " Size: "
            << "(" << x << "," << y << ")"
            << " must be positive."
            << " From line: '"
            << line
            << "'."
            << std::endl;
        std::cerr << out.str();
        valid = false;
    }

    return valid;
}

// Extrahiere Felder aus einer Zeiler.
bool MinimalGameboard::extractAndSetTiles( const unsigned int lineCounter,
                                           const std::string& line )
{
    bool valid = false;

    if ( ( 1 <= lineCounter ) && ( lineCounter <= mSize.y() ) )
    {
        if ( line.length() == mSize.x() )
        {
            valid = true;
            Position pos;
            
            for ( size_t ii = 0; ii < line.length(); ii++ )
            {
                pos.setPosition( ii+1, lineCounter );
                if ( isValidPos(pos) )
                {
                    const unsigned int tPos = getIntPos(pos);
                    mTiles[tPos].checked = false;
                    switch ( line[ii] ) {
                        case '.':
                        {
                            mTiles[tPos].occupied = false;
                            break;
                        }
                        case '#':
                        {
                            mTiles[tPos].occupied = true;
                            break;
                        }
                        default:
                        {
                            std::ostringstream out;
                            out << "(EE) MinimalGameboard::extractAndSetTiles "
                                << std::hex << this << std::dec
                                << " Unknown character: "
                                << line[ii]
                                << std::endl;
                            std::cerr << out.str();
                            valid = false;
                            break;
                        }
                    }
                }
                else
                {
                    valid = false;
                    break;
                }
            }
        }
        else
        {
            std::ostringstream out;
            out << "(EE) MinimalGameboard::extractAndSetTiles "
                << std::hex << this << std::dec
                << " Line length "
                << line.length()
                << " does not equal board with "
                << mSize.x()
                << " in line "
                << lineCounter+1
                << ": '"
                << line
                << "'."
                << std::endl;
            std::cerr << out.str();
            valid = false;
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) MinimalGameboard::extractAndSetTiles "
            << std::hex << this << std::dec
            << " Invalid line counter "
            << lineCounter
            << " for board height "
            << mSize.y()
            << "."
            << std::endl;
        std::cerr << out.str();
        valid = false;
    }

    return valid;
}
