/**
    (C) Copyright 2014 Marco Bock

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <sstream>
#include <iomanip> 
#include <string>
#include <algorithm>

#include "GameboardBot.hh"


// Konstruktor.
GameboardBot::GameboardBot()
{
    nr_rows = 0;
    nr_columns = 0;
    length_board = 0;
    nrPlayer = 0;
    
    // Element 0 des Vektors belegen, damit die Spielfelder ab 1 beginnen!
    Tile tile_1;
    tile_1.player_number = 0;
    tile_1.round_occupied = 0;
    tile_1.way_to_tile = -1;
    tiles.push_back(tile_1);

}


bool GameboardBot::setTile(unsigned int number_field, int number_player, int round_occupied)
{
    Tile tile_1;
    tile_1.player_number = number_player;
    tile_1.round_occupied = round_occupied;
    tile_1.way_to_tile = -1;
    tiles[number_field] = tile_1;
    return true;
}


bool GameboardBot::setTile(unsigned int n, unsigned int m, int number_player, int round_occupied)
{
    setTile((m-1)*nr_rows+n,number_player,round_occupied);
    return true;
}


void GameboardBot::printBoard()
{
    std::ostringstream out;
    out << getPrefix("Bot1") << "Das aktuelle Spielfeld ist: " << std::endl;
    std::cerr << out.str();
    
    for(int i=1; i<=(int) nr_rows; i++)
    {
        out.str("");
        out.clear();
        out << getPrefix("Bot1") << " | ";
        for(int j=1; j<=(int) nr_columns; j++)
        {
            out << std::setw(2) << tiles[(i-1)*nr_rows + j].player_number
                << "_"
                << std::setw(4) << tiles[(i-1)*nr_rows + j].round_occupied
                << "_"
                << std::setw(4) << tiles[(i-1)*nr_rows + j].way_to_tile
                << " | ";
        }
        out <<  std::endl;
        std::cerr << out.str();
    }
}


int GameboardBot::appendTile(bool obstacle)
{
    length_board++;
    int number_player = 0;
    if (obstacle)
    {
        number_player = -1;
    }
    
    Tile tile_1;
    tile_1.player_number = number_player;
    tile_1.round_occupied = 0;
    tile_1.way_to_tile = -1;
    tiles.push_back(tile_1);
    
    return 0;
}


void GameboardBot::checkWays(Pos start)
{
    std::vector<Pos> v1;
    std::vector<Pos> v2;
    
    nr_tiles_reachable = 0;
    unsigned int anz_steps = 1;

    
    // mGameboardBot durchlaufen und die Felder, die im vorherigen 
    // Durchlauf erreichbar waren initialisieren
    for (int i=1;i<=(int)tiles.size();i++)
    {
        tiles[i].way_to_tile = -1;
    }
    
    v1.push_back(start);
    unsigned int n; 
    bool nothing_free = 0;
    
    tiles[getPosAbsolute(start.m,start.n)].way_to_tile = 0;


    // In in jedem Durchlauf der while-Schleife wird v1 durchlaufen
    // und seine leeren Nachbarfelder in v2 geschrieben. v1 besteht zu 
    // Beginn nur aus dem Feld start.
    while (nothing_free==0)
    {
        v2.clear();
        n = v1.size();
        
        for(int i=0; i<(int)n; i++)
        {
            // Durchlaufe alle 4 Nachbaren und sehe, ob dieses Feld frei ist
            unsigned int m1 = v1[i].m;
            unsigned int n1 = v1[i].n;
            
            for (int j=1; j<=4; j++)
            {
                
                bool add_point = false;
                switch (j)
                {
                    case 1:
                    {
                        // Nach oben (NORTH)
                        m1 = v1[i].m-1;
                        n1 = v1[i].n;
                        add_point = (m1>=1);
                        break;
                    }        
                    case 2:
                    {
                        // Nach rechts (EAST)
                        m1 = v1[i].m;
                        n1 = v1[i].n+1;
                        add_point = (n1<=nr_columns);
                        break;
                    }
                    case 3:
                    {
                        // Nach unten (SOUTH)
                        m1 = v1[i].m+1;
                        n1 = v1[i].n;
                        add_point = (m1<=nr_rows);
                        break;
                    }
                    case 4:
                    {
                        // Nach links (WEST)
                        m1 = v1[i].m;
                        n1 = v1[i].n-1;
                        add_point = (n1>=1);
                        break;
                    }
                }
                
                if (add_point)
                {
                    // Der Punkt lag nicht außerhalb des Spielfeldes und kann
                	// hinzugefügt werden.
                    int pos_abs = getPosAbsolute(m1,n1);
                    if ( (tiles[pos_abs].way_to_tile==-1) &&
                         (tiles[pos_abs].player_number==0) )
                    {
                        // Das Feld ist noch frei.
                        // Punkt kann zu v2 hinzugefügt werden.
                        tiles[pos_abs].way_to_tile = anz_steps;
                        Pos p1;
                        p1.m = m1;
                        p1.n = n1;
                        v2.push_back(p1);
                        nr_tiles_reachable++;

/*
#ifdef DEBUG
                        std::ostringstream out;
                        out << getPrefix("Bot1") << "Punkt angehaengt m1=" << m1 << " n1=" << n1 << std::endl;
                        std::cerr << out.str();
#endif                        
*/
                        
                    }
                }
            }
        }
        
        if (v2.empty())
        {
            // Keine neuen Punkte, while-Schleife kann beendet werden.
            nothing_free = true;
        }
        else
        {
            // v2 in v1 schreiben:
            v1.clear();
            v1.swap(v2);
        }
        
        // Schritte hochzählen
        anz_steps++;

    }

#ifdef DEBUG
    std::ostringstream out;
    out << getPrefix("Bot1") << "Anzahl erreichbarer Felder: " << nr_tiles_reachable << std::endl;
    std::cerr << out.str();
#endif         
    
}


bool GameboardBot::wayPossible(Pos p)
{
    if (tiles[getPosAbsolute(p.m,p.n)].way_to_tile>=0)
    {
        return true;
    }
    return false;
}


void GameboardBot::setSize(int nr_rows1, int nr_columns1)
{
    nr_columns = nr_columns1;
    nr_rows = nr_rows1;
}


int GameboardBot::getPosAbsolute(unsigned int m, unsigned int n)
{
    unsigned int k = (m-1)*nr_columns + n;

#ifdef DEBUG
    if (k>length_board)
    {
        std::ostringstream out;
        out << getPrefix("Bot1") << "m=" << m << ", n=" << n << ", nr_rows=" << nr_rows << std::endl;
        out << getPrefix("Bot1") << "Fehler in getPosAbsolute, k zu groß: k=" << k 
            << " length_board= " << length_board << std::endl;
        std::cerr << out.str();            
    }
#endif
    
    return k;
}


GameboardBot::Pos GameboardBot::getPos(unsigned int p_abs)
{
	Pos p;
	p.m = (unsigned int) ( ( (p_abs-1) / nr_columns ) + 1 );
	p.n = (unsigned int) ( ( (p_abs-1) % nr_columns ) + 1 );
	return p;
}


GameboardBot::Pos GameboardBot::getHeadAct()
{
    return head_act;
}


GameboardBot::Pos GameboardBot::getHeadEnemyAct()
{
    return head_act_enemy;
}


void GameboardBot::setHeadAct(unsigned int m, unsigned int n) 
{
    head_act.m = m;
    head_act.n = n;
/*    
#ifdef DEBUG
    std::ostringstream out;
    out << getPrefix("Bot1") << "Kopf setzen m=" << m << " n=" << n << std::endl;
    std::cerr << out.str();
#endif    
*/  
}


void GameboardBot::setHeadEnemyAct(unsigned int m, unsigned int n)
{
    head_act_enemy.m = m;
    head_act_enemy.n = n;
}


bool GameboardBot::posInBoard(Pos p) 
{
    if ( (p.m>=1) && (p.m<=nr_rows) && 
         (p.n>=1) && (p.n<=nr_columns) )
    { 
        return true;
    }
    return false;
}


bool GameboardBot::tileEmpty(Pos p)
{
    
    if (tiles[getPosAbsolute(p.m,p.n)].player_number==0)
    {
        return true;
    }
    return false;
}


std::string GameboardBot::getPrefix(std::string s1)
{
    std::ostringstream s;
    s << "(DD) (" << s1 << "_" << nrPlayer << ") ";
    return s.str();
}


void GameboardBot::setPlayerNumber(unsigned int n)
{
    nrPlayer = n;
}


bool GameboardBot::isHole(Pos p, Dir d)
{
    Pos p1 = p;
    Pos p2 = p;
    
    
    switch (d)
    {
        case NORTH:
        case SOUTH:
            p1.n--;
            p2.n++;
            break;
        case EAST:
        case WEST:
        default:
            p1.m--;
            p2.m++;
            break;
    }
    
    bool h1=false;
    bool h2=false;
    
    if (posInBoard(p1))
    {
        if (!tileEmpty(p1))
        {
            h1=true;
        }
    }
    else
    {
        h1=true;
    }
    
    if (posInBoard(p2))
    {
        if (!tileEmpty(p2))
        {
            h2=true;
        }
    }
    else
    {
        h2=true;
    }
    
    return (h1 && h2);
    
}


bool GameboardBot::dirPoints(Pos p1, Pos p2, Dir* d)
{
    *d = D_NORTH;
    
    if (p1.m==p2.m)
    {
        // EAST oder WEST
        *d = (p2.n>=p1.n)?D_EAST:D_WEST;
        return true;
    }
    else if (p1.n==p2.n)
    {
        *d = (p2.m>=p1.m)?D_SOUTH:D_NORTH;
        return true;
    }
    else
    {
        return true;
    }
    
}


bool GameboardBot::containsPos(std::vector<Pos>* pway,Pos p)
{
    int i_max = (int)pway->size();
    bool return_value = false;

/*
#ifdef DEBUG        
    {
    std::ostringstream out;
    out << getPrefix("Bot1") << "Rek: containsPos i_max=" << i_max << std::endl;
    std::cerr << out.str();
    }
#endif           
*/
    
    for (int i=0; i<i_max; i++)
    {
        if ( ( (*pway)[i].m==p.m ) && 
             ( (*pway)[i].n==p.n ) )
        { 
            return_value=true;
            
        }
    }
    
/*
#ifdef DEBUG        
    {
    std::ostringstream out;
    out << getPrefix("Bot1") << "Rek: containsPos erfolgreich, return " << return_value << std::endl;
    std::cerr << out.str();
    }
#endif           
*/    
    return return_value;
}


GameboardBot::Dir GameboardBot::getNewDirAbs(Dir dir_abs, DirRel dir_rel)
{
    Dir d_new = D_NORTH;

	switch (dir_abs)
    {
        case D_NORTH:
            if (dir_rel==LEFT) {
                d_new=D_WEST;
            } else if (dir_rel==AHEAD) {
                d_new=D_NORTH;
            } else {
                d_new=D_EAST;
            }
            break;
        case D_EAST:
            if (dir_rel==LEFT) {
                d_new=D_NORTH;
            } else if (dir_rel==AHEAD) {
                d_new=D_EAST;
            } else {
                d_new=D_SOUTH;
            }
            break;
        case D_SOUTH:
            if (dir_rel==LEFT) {
                d_new=D_EAST;
            } else if (dir_rel==AHEAD) {
                d_new=D_SOUTH;
            } else {
                d_new=D_WEST;
            }
            break;
        case D_WEST:
        default:
            if (dir_rel==LEFT) {
                d_new=D_SOUTH;
            } else if (dir_rel==AHEAD) {
                d_new=D_WEST;
            } else {
                d_new=D_NORTH;
            }
            break;
    }
	return d_new;
}


GameboardBot::DirRel GameboardBot::getDirRel(Pos p, Dir d_act, Dir d_new)
{

	if (d_act==d_new)
	{
		return AHEAD;
	}

	DirRel d_return = RIGHT;
	switch (d_act)
	{
		case D_NORTH:
			d_return = (d_new==D_EAST)?RIGHT:LEFT;
			break;
		case D_EAST:
			d_return = (d_new==D_SOUTH)?RIGHT:LEFT;
			break;
		case D_SOUTH:
			d_return = (d_new==D_WEST)?RIGHT:LEFT;
			break;
		case D_WEST:
		default:
			d_return = (d_new==D_NORTH)?RIGHT:LEFT;
			break;
	}

	return d_return;
}


bool GameboardBot::getNewPoint(Pos p, Dir d_old, DirRel dr_new, Pos* p_new, Dir* pd_new)
{
    Pos p1 = p;

    Dir d_new = D_NORTH;
    
/*
#ifdef DEBUG        
    std::ostringstream out;
    out << getPrefix("Bot1") << "Rek: Start getNewPoint" << std::endl;
    std::cerr << out.str();
#endif  
*/
    
    d_new = getNewDirAbs(d_old,dr_new);
    *pd_new = d_new;
    
/*
#ifdef DEBUG        
    // std::ostringstream out;
    out << getPrefix("Bot1") << "Rek: Neue Ri. gefunden." << std::endl;
    std::cerr << out.str();
#endif           
*/    
    
    switch (d_new)
    {
        case D_NORTH:
            p1.m--;
            break;
        case D_EAST:
            p1.n++;
            break;
        case D_SOUTH:
            p1.m++;
            break;
        case D_WEST:
        default:
            p1.n--;
            break;
    }
    
    if (!posInBoard(p1))
    {
        *p_new = p;
        return false;
    }
    else
    {
        *p_new = p1;
    }
    return true;
}


GameboardBot::DirRel GameboardBot::getOptDirection(Pos p, Dir d,DirRel prio, unsigned int* p_anz_aufrufe_rek)
{
    std::vector<Pos> way;
    way.clear();
    way.push_back(p);
    
    std::vector<Pos>* pway = &way;
    
    DirRel dr=LEFT;
    DirRel *pdr = &dr;

    anz_aufrufe_rek = 0;

#ifdef DEBUG        
        std::ostringstream out;
        out << getPrefix("Bot1") << "Rekursive Suche gestartet!" << std::endl;
        std::cerr << out.str();
#endif

    getOptDirectionRec(pway,d,pdr,std::min((int)nr_tiles_reachable,50),prio);
    
    *p_anz_aufrufe_rek = anz_aufrufe_rek;

    return *pdr;
}


bool GameboardBot::CheckDepthDirection(Pos p, Dir d, unsigned int depth, DirRel prio)
{
    std::vector<Pos> way;
    way.clear();
    way.push_back(p);

    std::vector<Pos>* pway = &way;

    DirRel dr=LEFT;
    DirRel *pdr = &dr;

    unsigned int depth1 = 0;

    depth1 = getOptDirectionRec(pway,d,pdr,std::min((unsigned int)nr_tiles_reachable,depth),prio);

#ifdef DEBUG
        std::ostringstream out;
        out << getPrefix("Bot1") << "depth=" << depth << " depth1=" << depth1 << std::endl;
        std::cerr << out.str();
#endif

    if (depth1==depth)
    {
    	return true;
    }
    return false;
}


GameboardBot::Pos GameboardBot::getNeighbor(Pos p, Dir d)
{
	Pos p1 = p;
	switch (d)
	{
	case D_NORTH:
		p1.m--;
		break;
	case D_EAST:
		p1.n++;
		break;
	case D_SOUTH:
		p1.m++;
		break;
	case D_WEST:
	default:
		p1.n--;
		break;
	}
	return p1;
}


bool GameboardBot::wayToHeadEnemyPossible()
{
	Pos p = getHeadEnemyAct();
	Pos p1;
	Dir dirs[4] = { D_NORTH, D_EAST, D_SOUTH, D_WEST };

	for (int i=0; i<4; i++)
	{
		p1 = getNeighbor(p,dirs[i]);
		if ( (posInBoard(p1)) &&
		     (tiles[getPosAbsolute(p1.m,p1.n)].way_to_tile>=0) )
		{
			return true;
		}
	}

	return false;
}


void GameboardBot::distances(DirRel* order, int* dist, Pos* p, Dir direction)
{
	// Die Elemente von dist haben die Reihenfolge LEFT, AHEAD, RIGHT;

	Pos p_enemy;
	p_enemy = getHeadEnemyAct();


	// Für die drei Richtungen die Folgeschritte berechnen (p[]) und die Distanz
	// zum Kopf des Gegners berechnen (distance[])
	for ( int dirInt=LEFT;dirInt!=NO_DIR;dirInt++)
	{
		DirRel dir = static_cast<DirRel>(dirInt);
		p[dir] = getNeighbor(getHeadAct(),getNewDirAbs(direction,dir));
		if ( (posInBoard(p[dir])) && (wayPossible(p[dir])) )
		{
			// Nur wenn die Position im Feld und erreichbar ist, soll die
			// Distanz zum Kopf des Gegners berechnet werden.
			dist[dir] = ((int)p_enemy.m-(int)p[dir].m)*((int)p_enemy.m-(int)p[dir].m) +
					         ((int)p_enemy.n-(int)p[dir].n)*((int)p_enemy.n-(int)p[dir].n);
		}
	}

	// Distanzen der Größe nach sortieren und im Array order abspeichern
	if ( (dist[0]>=dist[1]) && (dist[0]>=dist[2]) )
	{
		if (dist[1]>=dist[2])
		{
			order[0] = LEFT;		// LEFT
			order[1] = AHEAD;		// AHEAD
			order[2] = RIGHT;		// RIGHT
		}
		else
		{
			order[0] = LEFT;
			order[1] = RIGHT;
			order[2] = AHEAD;
		}
	}
	else
	{
		if ( (dist[1]>=dist[0]) && (dist[1]>=dist[2]) )
		{
			if (dist[0]>=dist[2])
			{
				order[0] = AHEAD;
				order[1] = LEFT;
				order[2] = RIGHT;
			}
			else
			{
				order[0] = AHEAD;
				order[1] = RIGHT;
				order[2] = LEFT;
			}
		}
		else
		{
			if (dist[0]>=dist[1])
			{
				order[0] = RIGHT;
				order[1] = LEFT;
				order[2] = AHEAD;
			}
			else
			{
				order[0] = RIGHT;
				order[1] = AHEAD;
				order[2] = LEFT;
			}
		}
	}
}


GameboardBot::Dir GameboardBot::goToTarget(Pos target)
{
	Pos pos_act = target;

	std::vector<Pos> way_back;
	way_back.push_back(target);
	Pos p_tmp;
	Dir dir = D_NORTH;

	// Schleife, bis man am Kopf des Spielers angekommen ist.
	// Man startet an der Zielposition.
	unsigned int counter=1;
	while ( (tiles[getPosAbsolute(pos_act.m,pos_act.n)].way_to_tile!=0) &&
			(counter<=nr_columns*nr_rows) )
	{
		bool step_back = false;
		for (int dirInt=D_NORTH;dirInt!=D_NODIR;dirInt++)
		{
			dir = static_cast<Dir>(dirInt);
			p_tmp = getNeighbor(pos_act,dir);
			if (posInBoard(p_tmp))
			{
				unsigned int p_abs_tmp = getPosAbsolute(p_tmp.m,p_tmp.n);
				if ( (tiles[p_abs_tmp].way_to_tile<tiles[getPosAbsolute(pos_act.m,pos_act.n)].way_to_tile) &&
					 (tiles[p_abs_tmp].way_to_tile>=0) )
				{
					// Diese Richtung führt einen näher zu der akt. Position des Bots
					pos_act = p_tmp;
					way_back.push_back(pos_act);
					step_back = true;
					break;
				}
			}
		}
		if (step_back==false)
		{
			step_back = false;
#ifdef DEBUG
			std::ostringstream out;
			out << getPrefix("Bot1") << "Kein Schritt zurück" << std::endl;
			std::cerr << out.str();
#endif
		}
#ifdef DEBUG
			std::ostringstream out;
			out << getPrefix("Bot1") << "TO_TARGET " << step_back << ",  " << tiles[getPosAbsolute(pos_act.m,pos_act.n)].way_to_tile << "  p_tmp.m = " << p_tmp.m << "  p_tmp.n = " << p_tmp.n << std::endl;
			std::cerr << out.str();
#endif

		counter++;

	}

	if (counter>nr_columns*nr_rows)
	{
#ifdef DEBUG
		std::ostringstream out;
		out << getPrefix("Bot1") << "Schleife übergelaufen!" << std::endl;
		std::cerr << out.str();
#endif
	}

	// Entgegengesetzte Richtung soll gegangen werden:
	switch (dir)
	{
		case D_NORTH:
			dir = D_SOUTH;
			break;
		case D_SOUTH:
			dir = D_NORTH;
			break;
		case D_EAST:
			dir = D_WEST;
			break;
		case D_WEST:
		default:
			dir = D_EAST;
			break;
	}

	return dir;

}

GameboardBot::Dir GameboardBot::directionToDir(Direction d)
{
	Dir d1 = D_NORTH;
	switch (d)
	{
		case NORTH:
			d1 = D_NORTH;
			break;
		case EAST:
			d1 = D_EAST;
			break;
		case SOUTH:
			d1 = D_SOUTH;
			break;
		case WEST:
		default:
			d1 = D_WEST;
			break;
	}
	return d1;
}




//========================================================================================================
// Private Methoden


unsigned int GameboardBot::getOptDirectionRec(std::vector<Pos>* pway,Dir d,DirRel* d_opt, unsigned int depth, DirRel prio)
{
    Pos p_new[3]; 
    Dir d_new = D_NORTH;
    Dir *pd_new = &d_new;
    unsigned int v[3] = {0,0,0};
    unsigned int v_max = 0;
    DirRel dirs[3];

    anz_aufrufe_rek++;

/*
#ifdef DEBUG
	std::ostringstream out;
	out << getPrefix("Bot1") << "Rek: Zähler anz_aufrufe_rek=" << anz_aufrufe_rek << std::endl;
	std::cerr << out.str();
#endif
*/

    // Abbruch der Rekursion, damit die Rechenzeit nicht zu
    // grp wird
    if (anz_aufrufe_rek>=4000000)
    {
    	*d_opt = LEFT;
    	return 0;
    }

    switch (prio)
    {
    	case LEFT:
    		dirs[0] = LEFT;
    		dirs[1] = AHEAD;
    		dirs[2] = RIGHT;
    		break;
    	case RIGHT:
    		dirs[0] = RIGHT;
    		dirs[1] = AHEAD;
    		dirs[2] = LEFT;
			break;
    	default:
    		dirs[0] = LEFT;
    		dirs[1] = AHEAD;
    		dirs[2] = RIGHT;
    }

/*    
#ifdef DEBUG        
    std::ostringstream out;
    out << getPrefix("Bot1") << "Rek: In Stufe depth=" << depth << " angekommen." << std::endl;
    std::cerr << out.str();
#endif
*/    
    if (depth==0)
    {
        return 0;
    }
    
    // Rekursiv in alle drei Richtungen reingehen
    for (int i=0; i<3; i++)
    {

/*
#ifdef DEBUG        
        std::ostringstream out;
        out << getPrefix("Bot1") << "Rek: Rekursionsschleife i=" << i << std::endl;
        std::cerr << out.str();
#endif           
*/

        Pos *pp_step = &(p_new[i]);       // Position, auf die in dem rekursiven Schritt gegegangen werden soll.
        Pos p_start = (*pway)[pway->size()-1];  // Aktueller Punkt in rekursiver Suche
        
        if (getNewPoint(p_start,d,dirs[i],pp_step,pd_new))
        {
            // Der neue Punkt wurde bestimmt und liegt im Board
/*
#ifdef DEBUG        
            std::ostringstream out;
            out << getPrefix("Bot1") << "Rek: Neuer Punkt gefunden, liegt im Board!" << std::endl;
            std::cerr << out.str();
#endif
*/
            if ( (!containsPos(pway,*pp_step)) && (wayPossible(*pp_step)) )            
            {
                // Der neue Punkt ist nicht in den gesammelten Punkten der rekursiven Suche enthalten 
                // und er gehört zu den erreichbaren Punkten.
/*
#ifdef DEBUG        
                std::ostringstream out;
                out << getPrefix("Bot1") << "Rek: Neuer Punkt gefunden, ist erreichbar und nicht in rek. Speicher." << std::endl;
                std::cerr << out.str();
#endif           
*/                
/*
#ifdef DEBUG
                std::ostringstream out;
                out << getPrefix("Bot1") << "Tiefe Rek. = " << depth << "  Laenge pway = " << pway->size() << std::endl;
                std::cerr << out.str();
#endif
*/

            	(*pway).push_back(*pp_step);
                DirRel dr_bas=LEFT;
                DirRel *pdr_bas=&dr_bas;
                // Rekursionsschritt:
                v[i] = getOptDirectionRec(pway,*pd_new,pdr_bas,depth-1,prio) + 1;
                pway->pop_back();
                if (v[i]>v_max)
                {
                    // Die Richtung dirs[i] liefert einen längeren Weg als
                    // alle anderen zuvor, daher nehme diese-
                    v_max=v[i];
                    *d_opt=dirs[i];
                }
                if (v[i]==depth)
                {
                    // Wenn aus dem letzten Rekursionsaufruf zurückkommt, 
                    // dass man schon bis in die maximale Tiefe hinein ist, 
                    // kann man aus for-Schleife raus.
                    // Das steigert die Performance enorm!
                    break;
                }
            }
            else
            {
                v[i]=0;
            }
        } 
        else
        {
            v[i]=0;
        }
    }
    
    return v_max;
}

