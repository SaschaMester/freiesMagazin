/**
    (C) Copyright 2014 Marco Bock

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef GAMEBOARDBOT_HH
#define	GAMEBOARDBOT_HH

#include <string>
#include <vector>

#include<time.h>

#include "StrategyData.hh"

/*
 * Hilfsklasse, die das Spielfeld mit weiteren Informationen und 
 * darauf basierenden Operationen enthält.
 */
class GameboardBot
{
    public:

        // Position auf dem Spielfeld
        struct Pos
        {
            unsigned int m;
            unsigned int n;
        };        
        
        enum DirRel { LEFT=0, AHEAD, RIGHT, NO_DIR };
        enum Dir { D_NORTH=0, D_EAST, D_SOUTH, D_WEST, D_NODIR };
        
        
        // Konstruktor
        GameboardBot();
        
        // Daten eines Feldes setzen (Absolut auf eindimensionalen Vektor bezogen)
        bool setTile(unsigned int number_field, int number_player, int round_occupied);
        
        // Daten eines Feldes setzen (n,m Koordinaten)
        bool setTile(unsigned int n, unsigned int m, int number_player, int round_occupied);
        
        // Spielfeld auf Konsole ausgeben
        void printBoard();
        
        // Feld anhängen (am Ende)
        int appendTile(bool obstacle);
        
        // Feststellen, welche Felder vom Spieler erreichbar sind
        void checkWays(Pos start);
        
        // Der Spieler kann diese Position erreichen
        bool wayPossible(Pos p);
        
        // Größe des Feldes festlegen
        void setSize(int nr_rows, int nr_columns);

        // Absolute (eindimensionale) Position im tiles-Vektor
        int getPosAbsolute(unsigned int m, unsigned int n);
        
        // Position (zweidim.) in eine eindimensionale umwandeln
        Pos getPos(unsigned int p_abs);

        // Wo ist der Kopf des Spielers?
        Pos getHeadAct();

        // Wo ist der Kopf des Gegners?
        Pos getHeadEnemyAct();
        
        // Kopf des Spielers setzen
        void setHeadAct(unsigned int m, unsigned int n);

        // Kopf des Gegners setzen
        void setHeadEnemyAct(unsigned int m, unsigned int n);
        
        // Ist die Position innerhalb des Spielfeldes?
        bool posInBoard(Pos p);
        
        // Ist die Zelle leer?
        bool tileEmpty(Pos p);
        
        // String-Prefix für die Debug-Ausgabe
        std::string getPrefix(std::string s);
        
        // Nummer des Spielers im Objekt speichern
        void setPlayerNumber(unsigned int n);
        
        // Diese Position ist eine art Loch, das heisst, 
        // links und rechts davon sind belegte Felder
        bool isHole(Pos p, Dir d);
        
        // Richtung von p1 nach p2
        bool dirPoints(Pos p1, Pos p2, Dir* d);
        
        // Enthält der Vector mit Positionen *pway die Position p?
        bool containsPos(std::vector<Pos>* pway,Pos p);
        
        // Bestimme eine absolute Richtung
        Dir getNewDirAbs(Dir dir_abs, DirRel dir_rel);

        // Bestimmt relative Richtung
        DirRel getDirRel(Pos p, Dir d_act, Dir d_new);

        // Position p hat absolute Richtung d_old. Funktion bestimmt die absolute Richtung zur relativen 
        // Richtung dr_new und den dazugehörigen Punkt *p_new und die dazugehörige absolute Richtung *pd_new.
        bool getNewPoint(Pos p, Dir d_old, DirRel dr_new, Pos* p_new, Dir* pd_new);
        
        // Richtung zurückgeben, die rekursiv ermittelt wurde und für eine
        // Anzahl von Runden am weitesten kommt.
        DirRel getOptDirection(Pos p, Dir d, DirRel prio, unsigned int* p_anz_aufrufe_rek);
        
        // Schaut, ob man einen Weg mit dieser Anzahl an Schritten gehen kann
        bool CheckDepthDirection(Pos p, Dir d, unsigned int depth, DirRel prio);

        // Nachbar in zur angegebenen Richtung berechnen
        Pos getNeighbor(Pos p, Dir d);

        // Gibt es einen Weg für den Bot zum Kopf des Gegners?
        bool wayToHeadEnemyPossible();
        
        // Berechnet für alle drei möglichen Bewegungsrichtungen die dann
        // vorhandene Distanz zum Kopf des Gegners und sortiert sie
        // nach der Reihenfolge.
        void distances(DirRel* order, int* dist, Pos* p, Dir direction);
        
        // Welche Richtung muss man gehen, um möglichst schnell zu Ziel
        // target zu kommen?
        Dir goToTarget(Pos target);

        // Konvertiere zwischen den beiden Typen.
        Dir directionToDir(Direction d);

        // Zelle auf Spielfeld
        struct Tile
        {
            int player_number;      //  0 -> Zelle leer
                                    // -1 -> Hindernis
            int round_occupied;     //  0 -> Zelle leer
            int way_to_tile;        //  -1  -> Kein Weg für den Spieler zu dieser Zelle vorhanden
            						//  >=0 -> Anzahl Schritte vom aktuellen Kopf des Spielers
        };
        
        // DirRel dirs[3] = { LEFT, AHEAD, RIGHT };
        // static DirRel dirs[3]= { LEFT, AHEAD, RIGHT };

    private:
        
        //
        unsigned int getOptDirectionRec(std::vector<Pos>* pway,Dir d,DirRel* d_opt, unsigned int depth, DirRel prio);
        

        std::vector<Tile> tiles;       // Spielfeld, zeilenweise
        
        Pos head_act;                  // Aktuelle Position, wo sich der "Kopf" des Spielers befindet
        Pos head_act_enemy;			   // aktuelle Kopfposition des Gegners
                
        unsigned int nr_rows;                   // Anzahl Zeilen Spielfeld
        unsigned int nr_columns;                // Anzahl Spalten Spielfeld
        
        unsigned int length_board;     // Anzahl der Elemente des Spielfeldes
        unsigned int nrPlayer;         // Nummer des Spielers 
        
        unsigned int nr_tiles_reachable;  // Anzahl der Felder, die com Bot erreicht werden können.

        unsigned int anz_aufrufe_rek;	// Anzahl der Aufrufe von
    
};


#endif	/* GAMEBOARDBOT_HH */

