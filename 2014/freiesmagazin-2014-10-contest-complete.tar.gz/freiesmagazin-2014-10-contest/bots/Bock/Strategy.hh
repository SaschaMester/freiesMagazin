/**
    (C) Copyright 2012,2014 Dominik Wagenfuehr, Marco Bock

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef STRATEGY_HH
#define STRATEGY_HH

#include "StrategyIF.hh"
#include "StrategyData.hh"
#include "GameboardBot.hh"

#include <string>
#include <vector>

// Vorwaertsdeklarationen.
class EndMessage;
class GameboardEndMessage;
class GameboardLineMessage;
class GameboardStartMessage;
class PlayerMessage;
class PlayerOutMessage;
class PlayerSetMessage;
class StartMessage;
class TextMessage;

/// Die konkrete Strategie.
/**
 * Fuer eine echte Strategie muessen die Methoden in der
 * Implementierung entsprechend angepasst werden.
 */
class Strategy : public StrategyIF
{
  public:

	enum StatesStategy { JUST_SURVIVE, TO_ENEMY };


    /// Konstruktor.
    Strategy();
  
    /// Destruktor.
    virtual ~Strategy();

    /// Werte zuruecksetzen.
    virtual void reset();
    
    /// Behandelt eine Start-Nachricht.
    // Entspricht der Zeile 
    //     ROUND R
    // in der Readme, d.h. eine Runde beginnt. Hier muss die Richtung des Zuges berechnet werden
    /**
     * @param message Zu verarbeitende Nachricht.
     * @return true, wenn die Nachricht korrekt verarbeitet wurde
     */
    virtual bool operate( const StartMessage& message );

    /// Behandelt eine Ende-Nachricht.
    /**
     * @param message Zu verarbeitende Nachricht.
     * @return true, wenn die Nachricht korrekt verarbeitet wurde
     */
    virtual bool operate( const EndMessage& message );

    /// Behandelt eine Spieler-Daten-Nachricht.
    // Entspricht der Zeile 
    //     POS P N,M DIR 
    // in der Readme, d.h., die Startpositionen für die Bots werden übergeben.
    /**
     * @param message Zu verarbeitende Nachricht.
     * @return true, wenn die Nachricht korrekt verarbeitet wurde
     */
    virtual bool operate( const PlayerMessage& message );

    /// Behandelt eine Spieler-Todes-Nachricht.
    /**
     * @param message Zu verarbeitende Nachricht.
     * @return true, wenn die Nachricht korrekt verarbeitet wurde
     */
    virtual bool operate( const PlayerOutMessage& message );

    /// Behandelt eine Spieler-Setzen-Nachricht.
    // Entspricht der Zeile 
    //     SET P
    // in der Readme.
    /**
     * @param message Zu verarbeitende Nachricht.
     * @return true, wenn die Nachricht korrekt verarbeitet wurde
     */
    virtual bool operate( const PlayerSetMessage& message );
    
    /// Behandelt eine Spielbrett-Start-Nachricht.
    /**
     * @param message Zu verarbeitende Nachricht.
     * @return true, wenn die Nachricht korrekt verarbeitet wurde
     */
    virtual bool operate( const GameboardStartMessage& message );

    /// Behandelt eine Spielbrett-Zeile-Nachricht.
    /**
     * @param message Zu verarbeitende Nachricht.
     * @return true, wenn die Nachricht korrekt verarbeitet wurde
     */
    virtual bool operate( const GameboardLineMessage& message );

    /// Behandelt eine Spielbrett-Ende-Nachricht.
    /**
     * @param message Zu verarbeitende Nachricht.
     * @return true, wenn die Nachricht korrekt verarbeitet wurde
     */
    virtual bool operate( const GameboardEndMessage& message );

    /// Behandelt eine Textnachricht.
    /**
     * @param message Zu verarbeitende Nachricht.
     * @return true, wenn die Nachricht korrekt verarbeitet wurde
     */
    virtual bool operate( const TextMessage& message );

    /// Fragt ab, ob ein Kommando zur Verfuegung steht.
    /**
     * Die Methode wird vom Bot nach dem Empfang jeder (!)
     * Nachricht gerufen. In der Regel stoesst die Start-Nachricht
     * die Berechnung an. Stehen Kommandos zur Verfuegung, muessen
     * diese gleich in die cmdList eingetragen werden.
     * @param[out] cmd Das Kommando, das der Bot ausfuehren soll.
     * @return false, falls keine Kommandos abgeholt werden konnten
     */
    virtual bool isCommandAvailable( std::string& cmd );

    /// Gibt zurueck, ob das Spiel zu Ende sein soll.
    /**
     * Die Methode wird vom Bot nach dem Empfang jeder (!)
     * Nachricht gerufen. In der Regel wird true geliefert, nachdem
     * die Ende-Nachricht empfangen wurde. Ggf. aber auch, wenn es
     * zu einem internen Fehler kam und der Bot die Abarbeitung
     * abbrechen soll.
     * @return true, wenn der Bot stoppen soll
     */
    virtual bool isEnd() const;

  private:

    struct StatusCalcCommand
    {
    	bool b;
    	unsigned int anz_aufrufe_rek;
    };

    /// Berechne die Aktion, die spaeter ausgegeben werden soll.
    /**
     * @return true, wenn die Berechnung korrekt verlief.
     */
    StatusCalcCommand calcCommand2();

    // Abstand zwischen zwei Positionen
    double distance(GameboardBot::Pos p1,GameboardBot::Pos p2);

    /// Die Strategie-Daten.
    StrategyData mData;

    /// Die Aktion des Bots.
    std::string mCommand;

    /// Flag, dass die Strategie nicht weiter aufgerufen werden soll.
    bool mIsFinished;

    /// Flag, dass Spielfeld gerade uebertragen wird.
    bool mGameboardStarted;
    
    /// Hinzugefügt Marco:
    
    /// Anzahl der Zeilen des Spielfeldes
    int nr_zeilen;      
    
    /// Anzahl der Spalten des Spielfeldes
    int nr_spalten;
    
    /// Gameboard
    GameboardBot mGameboardBot;
    
    struct Performance_data
    {
    	double time;
    	unsigned int anz_aufrufe_rek;
    };

    std::vector<Performance_data> p_data;
    
    std::string botName;
    
    StatesStategy state_strategy;
    StatesStategy state_strategy_old;
    GameboardBot::DirRel dir_rel_prio;



};

#endif // STRATEGY_HH
