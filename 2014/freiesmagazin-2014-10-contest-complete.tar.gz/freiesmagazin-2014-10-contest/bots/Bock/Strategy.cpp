/**
    (C) Copyright 2012,2014 Dominik Wagenfuehr, Marco Bock

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "Strategy.hh"

#include "EndMessage.hh"
#include "GameboardEndMessage.hh"
#include "GameboardLineMessage.hh"
#include "GameboardStartMessage.hh"
#include "PlayerMessage.hh"
#include "PlayerOutMessage.hh"
#include "PlayerSetMessage.hh"
#include "StartMessage.hh"
#include "TextMessage.hh"
#include "GameboardBot.hh"

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <string.h>
#include <iomanip>
#include <cmath>

// Konstruktor.
Strategy::Strategy()
  : mData(), mIsFinished(false), mGameboardStarted(false), mGameboardBot()
{ 
    nr_zeilen = 0;
    nr_spalten = 0;
    // gameboardBot = new GameboardBot();

    state_strategy = TO_ENEMY;
    state_strategy_old = TO_ENEMY;
    dir_rel_prio = GameboardBot::LEFT;
}


// Destruktor.
Strategy::~Strategy()
{ }


// Werte zuruecksetzen.
void Strategy::reset()
{
}


// Behandelt eine Start-Nachricht.
// Es muss die Richtung des Bots für den Zug berechnet werden.
bool Strategy::operate( const StartMessage& message )
{
    mData.numRound = message.getNumRound();
    
    // Todo: Hier muss mGamboardBot aktualisiert werden!
    mGameboardBot.checkWays(mGameboardBot.getHeadAct());


#ifdef DEBUG     
    // mGameboardBot.printBoard();
#endif    


    double time_0 = clock();
        
    StatusCalcCommand scc = calcCommand2();
    
    double time_elapsed = 1000.0 * ( clock() - time_0 ) / CLOCKS_PER_SEC;
    
    Performance_data p_data_tmp;
    p_data_tmp.time = time_elapsed;
    p_data_tmp.anz_aufrufe_rek = scc.anz_aufrufe_rek;
    p_data.push_back(p_data_tmp);
    
#ifdef DEBUG
    std::ostringstream out;
    out << mGameboardBot.getPrefix("Bot1") << "Zeitdauer Berechnung Strategie: " << time_elapsed << " ms" << std::endl 
        << mGameboardBot.getPrefix("Bot1") << "Ende einer Runde!" << std::endl
        << mGameboardBot.getPrefix("Bot1") << "-----------------------------------------------------------" << std::endl 
        << mGameboardBot.getPrefix("Bot1") << " " << std::endl;
    std::cerr << out.str();
#endif
    
    return scc.b;
}


// Behandelt eine Ende-Nachricht.
// Das Spiel ist zu Ende
bool Strategy::operate( const EndMessage& /* message */ )
{
    const bool store_times=false;

    if (store_times)
    {
		// Zeiten, die die Berechnungen in jeder Runde gebraucht haben,
		// in eine Datei schreiben:
		std::ofstream file_times("times_strategy.txt",std::ios::out);
		double sum = 0;
		for (unsigned int i=0; i<p_data.size();i++)
		{
			file_times << std::setprecision(10) << p_data[i].time << ";" << p_data[i].anz_aufrufe_rek << std::endl;
			sum+=p_data[i].time;
		}
		file_times << std::setprecision(10) << sum << ";0" << std::endl;
		file_times.close();
    }
    
    mIsFinished = true;
    return true;
}


// Behandelt eine Spieler-Daten-Nachricht.
// Startpositionen der Bots werden übergeben.
bool Strategy::operate( const PlayerMessage& message )
{
    bool retValue = false;
    
    if ( mData.playerNo > 0 )
    {
        const unsigned int playerNo = message.getPlayerNo();
        if ( playerNo > 0 ) 
        {
            const Position& pos = message.getPosition();
            const Direction dir = message.getDirection();

            if ( playerNo == mData.playerNo )
            {
                mData.position = pos;
                mData.direction = dir;
                retValue = true;
                
                // Gameboard-Speicher des Bots aktualisieren.
                mGameboardBot.setTile(pos.x(),pos.y(),playerNo,mData.numRound);
                mGameboardBot.setHeadAct(pos.y(),pos.x());
                
            }
            else
            {
                // Speichere den Wert auch fuer die Gegner.
                retValue = true;
                
                // Gameboard-Speicher des Bots aktualisieren.
                mGameboardBot.setTile(pos.x(),pos.y(),playerNo,mData.numRound);
                mGameboardBot.setHeadEnemyAct(pos.y(),pos.x());
            }
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Strategy::operate PlayerMessage"
                << std::hex << this << std::dec
                << " Player number is not set!"
                << std::endl;
            std::cerr << out.str();
            retValue = false;
        }        
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate PlayerMessage"
            << std::hex << this << std::dec
            << " Own player number is not set yet!"
            << std::endl;
        std::cerr << out.str();
        retValue = false;
    }
    
    return retValue;
}


// Behandelt eine Spieler-Todes-Nachricht.
bool Strategy::operate( const PlayerOutMessage& message )
{
    bool retValue = false;
    
    if ( mData.playerNo > 0 )
    {
        const unsigned int playerNo = message.getPlayerNo();
        if ( playerNo > 0 ) 
        {
            if ( playerNo == mData.playerNo )
            {
                // Man selbst ist ausgeschieden ...
                retValue = true;
            }
            else
            {
                // Speichere den Wert auch fuer die Gegner.
                retValue = true;
            }
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Strategy::operate PlayerOutMessage"
                << std::hex << this << std::dec
                << " Player number is not set!"
                << std::endl;
            std::cerr << out.str();
            retValue = false;
        }        
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate PlayerOutMessage"
            << std::hex << this << std::dec
            << " Own player number is not set yet!"
            << std::endl;
        std::cerr << out.str();
        retValue = false;
    }
    
    return retValue;
}


// Behandelt eine Spieler-Setzen-Nachricht.
bool Strategy::operate( const PlayerSetMessage& message )
{
    bool retValue = false;
    
    if ( 0 == mData.playerNo )
    {
        const unsigned int playerNo = message.getPlayerNo();
        if ( playerNo > 0 ) 
        {
            mData.playerNo = playerNo;
            mGameboardBot.setPlayerNumber(playerNo);
            retValue = true;
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Strategy::operate PlayerSetMessage"
                << std::hex << this << std::dec
                << " Player number is not set!"
                << std::endl;
            std::cerr << out.str();
            retValue = false;
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate PlayerSetMessage"
            << std::hex << this << std::dec
            << " Player number is set a second time!"
            << std::endl;
        std::cerr << out.str();
        // retValue = false;
        retValue = true;
    }
    
    return retValue;
}


// Behandelt eine Spielbrett-Start-Nachricht.
bool Strategy::operate( const GameboardStartMessage& message )
{
    mGameboardStarted = true;
    
    return true;
}


// Behandelt eine Spielbrett-Zeile-Nachricht.
// Spielfeld wird übertragen
bool Strategy::operate( const GameboardLineMessage& message )
{
    bool retValue = false;

    if ( mGameboardStarted )
    {
        // Zeile interpretieren ...
        retValue = true;

/*
#ifdef DEBUG        
        std::ostringstream out;
        out << mGameboardBot.getPrefix("Bot1") 
            << message.getLine()
            << std::endl;
        std::cerr << out.str();
#endif
*/
        
        nr_zeilen++;
        std::string s1 = message.getLine();
        nr_spalten = s1.size();
        
        // Daten gameboardBot schreiben
        for (int i=1; i<=nr_spalten; i++)
        {
            std::string s2 = s1.substr(i-1,1);
            std::string s3 ("#");
            mGameboardBot.appendTile(!s2.compare(s3));
        }
        
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate GameboardLineMessage"
            << std::hex << this << std::dec
            << " Gameboard transfer has not been started yet!"
            << std::endl;
        std::cerr << out.str();
        retValue = false;
    }
    
    return retValue;
}


// Behandelt eine Spielbrett-Ende-Nachricht.
bool Strategy::operate( const GameboardEndMessage& message )
{
    mGameboardStarted = false;
    
#ifdef DEBUG
    std::ostringstream out;
    out << mGameboardBot.getPrefix("Bot1")<< "Das Spielfeld hat " << nr_zeilen << " Zeilen und "
        << nr_spalten << " Spalten." << std::endl;
    std::cerr << out.str();
#endif
    
    mGameboardBot.setSize(nr_zeilen,nr_spalten);
    
/*
#ifdef DEBUG
    mGameboardBot.printBoard();
#endif    
*/
    
    return true;
}


// Behandelt eine Textnachricht.
bool Strategy::operate( const TextMessage& message  )
{
    std::ostringstream out;
    out << "(EE) " << "Strategy::operate TextMessage "
        << std::hex << this << std::dec
        << "'" << message.getText() << "'."
        << " Cannot operate on text messages!"
        << std::endl;
    std::cerr << out.str();
    
    return false;
}


// Fragt ab, ob Kommandos zur Verfuegung stehen.
bool Strategy::isCommandAvailable( std::string& cmd )
{
    bool isAvail = false;

    cmd.clear();
    if ( !mCommand.empty() )
    {
        // Nur, wenn wir ein Kommando haben, wird dieses
        // uebermittelt.
        cmd = mCommand;
        isAvail = true;

        // Nach dem Kopieren sollte man das Kommando unbedingt
        // loeschen, damit bei der naechsten Abfrage nicht aus
        // Versehen noch ein Kommando ansteht.
        mCommand.clear();
    }

    return isAvail;
}


// Gibt zurueck, ob das Spiel zu Ende sein soll.
bool Strategy::isEnd() const
{
    return mIsFinished;
}


// Berechnde Richtung für die Aktuelle Runde
/*
 * Grobe Beschreibung der Strategie:
 * Bot läuft solange auf den Kopf des Gegners zu, bis er eine bestimmte Nähe erreicht hat.
 * Dann dreht er um und läuft am Rand weg, bis er wieder eine bestimmte Distanz erreicht hat und
 * es geht wieder von vorne los.
 */
Strategy::StatusCalcCommand Strategy::calcCommand2()
{
	mCommand = "AHEAD";
    GameboardBot::DirRel dr = GameboardBot::LEFT;

    unsigned int tmp_anz = 0;
    unsigned int* p_tmp_anz = &tmp_anz;


    // Übergeordnete Checks für Zustandswechsel
    if (!mGameboardBot.wayToHeadEnemyPossible())
    {
    	// Wenn es eh keinen Weg mehr zum Kopf des Gegners gibt,
    	// dann bleibt nur noch die Überlebensstrategie.
    	state_strategy = JUST_SURVIVE;
    }

    // Zum Test
    // state_strategy = JUST_SURVIVE;


#ifdef DEBUG
    std::string s1;
    switch (state_strategy)
    {
		case JUST_SURVIVE:
			s1 = "JUST_SURVIVE";
			break;
		case TO_ENEMY:
			s1 = "TO_ENEMY";
			break;
		default:
			s1 = "JUST_SURVIVE";
    }
    std::ostringstream out1;
    out1 << mGameboardBot.getPrefix("Bot1")<< "Strategie Zug: " << s1 << std::endl;
    std::cerr << out1.str();
#endif

    GameboardBot::Pos pos_enemy = mGameboardBot.getHeadEnemyAct();
	GameboardBot::Pos pos_act = mGameboardBot.getHeadAct();

        // Zustandsautomat für die einzelnen Strategiephasen des Spiels
    switch (state_strategy)
    {

    	case JUST_SURVIVE:
    	{

    		if (state_strategy_old!=JUST_SURVIVE)
    		{
				// Priorität bestimmen
				GameboardBot::Pos p_left = mGameboardBot.getNeighbor(mGameboardBot.getHeadAct(),mGameboardBot.getNewDirAbs(mGameboardBot.directionToDir(mData.direction),GameboardBot::LEFT));
				double dist_left = distance(p_left,pos_enemy);
				GameboardBot::Pos p_right = mGameboardBot.getNeighbor(mGameboardBot.getHeadAct(),mGameboardBot.getNewDirAbs(mGameboardBot.directionToDir(mData.direction),GameboardBot::RIGHT));
				double dist_right = distance( p_right,pos_enemy);
				if (std::abs(dist_right-dist_left)<0.0001)
				{
					// Die Abstände sind quasi gleich.
					if ( mGameboardBot.posInBoard(p_left) && mGameboardBot.tileEmpty(p_left) )
					{
						dir_rel_prio = GameboardBot::LEFT;
					}
					else
					{
						dir_rel_prio = GameboardBot::RIGHT;
					}
				}
				else
				{
					dir_rel_prio = (dist_left>dist_right)?GameboardBot::LEFT:GameboardBot::RIGHT;
				}
    		}

    		dr = mGameboardBot.getOptDirection(mGameboardBot.getHeadAct(),mGameboardBot.directionToDir(mData.direction),dir_rel_prio, p_tmp_anz);

    		double dist1 = 0.5 * ( nr_spalten/2.0 + nr_zeilen/2.0 );

    		if (distance(pos_enemy,pos_act)>dist1)
    		{
    			state_strategy = TO_ENEMY;
    			state_strategy_old = JUST_SURVIVE;
    		}
    		break;
    	}

    	case TO_ENEMY:
    	{
    		GameboardBot::Pos pos_target = pos_act;

    		for (int dirInt=GameboardBot::D_NORTH;dirInt!=GameboardBot::D_NODIR;dirInt++)
    		{
    			GameboardBot::Dir dir = static_cast<GameboardBot::Dir>(dirInt);
    			GameboardBot::Pos p_tmp = mGameboardBot.getNeighbor(mGameboardBot.getPos(mGameboardBot.getPosAbsolute(pos_enemy.m,pos_enemy.n)),dir);
    			if (mGameboardBot.tileEmpty(p_tmp))
    			{
    				// Ein leeres Feld neben dem Kopf des Gegners ist die Zielposition
    				pos_target = p_tmp;
    				break;
    			}
    		}

    		GameboardBot::Dir d = mGameboardBot.goToTarget(pos_target);
    		dr = mGameboardBot.getDirRel(mGameboardBot.getHeadAct(),mGameboardBot.directionToDir(mData.direction),d);

    		if (distance(pos_enemy,pos_act)<5.2)
    		{
    			state_strategy = JUST_SURVIVE;
    			state_strategy_old = TO_ENEMY;
    		}

    		break;
    	}

    }
    

    // Noch den passenden String berechnen:
    switch (dr)
    {
        case GameboardBot::LEFT:
            mCommand = "LEFT";
            break;
        case GameboardBot::AHEAD:
            mCommand = "AHEAD";
            break;
        case GameboardBot::RIGHT:
        default:
            mCommand = "RIGHT";
            break;
    }

#ifdef DEBUG
    std::ostringstream out;
    out << mGameboardBot.getPrefix("Bot1")<< "Richtung Zug: " << mCommand << std::endl;
    std::cerr << out.str();
#endif

    StatusCalcCommand stat;
    stat.b = true;
    stat.anz_aufrufe_rek = *p_tmp_anz;
    return stat;
}




double Strategy::distance(GameboardBot::Pos p1,GameboardBot::Pos p2)
{
	return sqrt( (p1.m-p2.m)*(p1.m-p2.m) + (p1.n-p2.n)*(p1.n-p2.n) );
}


