/*
 * Copyright (C) 2014 Stefan Schmidhuber
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package lasvegasbot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 *
 * @author stefan
 */
public class LasVegasStrategy implements Strategy {

    private static int i = 1;
    
    private final int COUNTER = 500;
    private final Random RANDOM = new Random();

    @Override
    public Steering steeringAlgorithm(Game game) {
        //AnalyseUtility.writeOut("\n### STEP " + i + " ###");
        i++;
        
        game.evaluate();
        
        //AnalyseUtility.writeOut(game.toString());
        //AnalyseUtility.writeOut(game.showEvaluationValue());
        
        Steering move = standardProcedure(game);
        
        if (move == null) {
            //AnalyseUtility.writeOut("\ncouldn't find a way, use fallback\n");
            move = fallback(game);
        }
        
        return move;
    }
    
    private Steering standardProcedure(Game game) {
        List<Game> possiblePaths = new ArrayList<>(COUNTER);
        List<Field> target = game.findTargets();

        //try different random paths to the target
        path:
        for (int i = 0; i < COUNTER; i++) {
            Game copyOfGame = new Game(game);

            while (!hitATagret(copyOfGame, target)) {
                Steering move = randomMove(copyOfGame);
                if (move == null) {
                    //out of steering options, couldn't find an empty field
                    continue path;
                }
                
                copyOfGame.move(move);
            }

            //reached target
            //System.err.println("valid:\n" + copyOfGame);
            possiblePaths.add(copyOfGame);
        }

        //AnalyseUtility.writeOut("found " + possiblePaths.size() + " paths with " + COUNTER + " tries");
        if (possiblePaths.isEmpty()) {
            return null;
        }

        Collections.sort(possiblePaths);
        //AnalyseUtility.writeOut("evaluation points: " + possiblePaths.get(0).getEvaluationPoints() + ", " + possiblePaths.get(1).getEvaluationPoints() + ", " + possiblePaths.get(2).getEvaluationPoints() + ", " + possiblePaths.get(3).getEvaluationPoints() + ", " + possiblePaths.get(4).getEvaluationPoints());
        //AnalyseUtility.writeOut("best found path:\n" + possiblePaths.get(0));
        return possiblePaths.get(0).getFirstMove();
    }
    
    private Steering fallback(Game game) {
        List<Game> possiblePaths = new ArrayList<>(100);        
        
        for (int steps = 5; steps > 1; steps--) {
            for (int i = 0; i < Math.pow(3, steps); i++) {
                Game path = randomPath(game, steps);
                if (path == null) {
                    continue;
                }
                possiblePaths.add(path);
            }
            if (!possiblePaths.isEmpty()) {
                //AnalyseUtility.writeOut("found paths with " + steps + " steps");
                break;
            }
        }
        
        //AnalyseUtility.writeOut(possiblePaths.size() + " paths found");
        if (possiblePaths.isEmpty()) {
            return new SimpleRandomStrategy().steeringAlgorithm(game);
        }
        
        Collections.sort(possiblePaths);
        //AnalyseUtility.writeOut("best path:\n" + possiblePaths.get(0));
        return possiblePaths.get(0).getFirstMove();
    }
    
    private Game randomPath(Game game, int steps) {
        Game copyOfGame = new Game(game);
            for (int step = 0; step < steps; step++) {
                Steering move = randomMove(copyOfGame);
                
                if (move == null) {
                    return null;
                }
                
                copyOfGame.move(move);
            }
            return copyOfGame;
    }
    
    /**
     * returns a valid steering option or null
     * 
     * @param game
     * @return 
     */
    private Steering randomMove(Game game) {
        //make a random move
        List<Steering> options = new ArrayList<>(3);
        options.add(Steering.AHEAD);
        options.add(Steering.LEFT);
        options.add(Steering.RIGHT);

        option:
        while (!options.isEmpty()) {
            int dice = RANDOM.nextInt(options.size());

            if (game.fieldCheck(options.get(dice))) {
                return options.get(dice);
            }

            options.remove(dice);
        }
        return null;
    }

    private boolean hitATagret(Game game, List<Field> targets) {
        boolean hit = false;
        
        for (Field target : targets) {
            if (target.fits(game.getCurrentPosition())) {
                hit = true;
                break;
            }
        }
        
        return hit;
    }
}
