/*
 * Copyright (C) 2014 Stefan Schmidhuber
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package lasvegasbot;

import java.util.ArrayList;
import java.util.List;
import java.util.OptionalInt;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 *
 * @author stefan
 */
public class Game implements Comparable<Game> {
    
    private static final Logger LOGGER = Logger.getLogger(Game.class.getName());
    private final List<Position> POSITIONS = new ArrayList<>();     //position of the head of each bot
    private final List<Field> FIELDS;   //all fields in this gameboard
    private final int WIDTH;
    private final int HEIGHT;
    private final int ID;               //id of the own bot
    private final Strategy STRATEGY;    //steering strategy
    private Steering firstMove = null;  //first move of a path
    private int aheadCounter = 0;       //moves ahead for a path
    private int stepCounter = 0;        //seps to target for a path
    private int ratingCounter = 0;      //accumulated rating of all fields in a path
    
    public Game(int width, int height, String board, int id, Strategy strategy) throws InvalidInputException{
        FIELDS = new ArrayList<>(width*height);
        Scanner boardScanner = new Scanner(board);
        String line;
        int xCoordinate = 1;
        int yCoordinate = 1;
        
        WIDTH = width;
        HEIGHT = height;
        
        while(boardScanner.hasNextLine()){
            line = boardScanner.nextLine();
            LOGGER.log(Level.FINE, "board scanner next line: {0}", line);
            for(char c : line.toCharArray()){
                FIELDS.add(new Field(xCoordinate, yCoordinate, c));
                xCoordinate++;
            }
            xCoordinate = 1;
            yCoordinate++;
        }
        FIELDS.forEach(field -> field.link(FIELDS, width, height));
        
        ID = id;
        STRATEGY = strategy;
    }
    
    //copy constructor
    public Game(Game game){
        this.WIDTH = game.WIDTH;
        this.HEIGHT = game.HEIGHT;
        this.ID = game.ID;
        this.STRATEGY = game.STRATEGY;
        this.FIELDS = new ArrayList<>(game.WIDTH*game.HEIGHT);
        game.FIELDS.forEach(field -> this.FIELDS.add(new Field(field)));
        game.POSITIONS.forEach(position -> this.POSITIONS.add(new Position(position)));
        
        this.FIELDS.forEach(field -> field.link(this.FIELDS, this.WIDTH, this.HEIGHT));
    }
    
    public void initPosition(int id, int x, int y, String direction) throws InvalidInputException {
        Position position = new Position(x, y, getDirection(direction));
        POSITIONS.add(position);
        get(position).setFieldType((id == this.ID) ? FieldType.HEAD_MY : FieldType.HEAD_OPPONENT);
    }
    
    public void setPosition(int id, int x, int y, String direction) throws InvalidInputException {
        setPosition(id, x, y, getDirection(direction));
    }
    
    public void setPosition(int id, int x, int y, Direction direction) throws InvalidInputException {
        Position position = POSITIONS.get(id-1);
        get(position).setFieldType(FieldType.BODY);
        
        position.setxCoordinate(x);
        position.setyCoordinate(y);
        position.setDirection(direction);
        get(position).setFieldType((id == this.ID) ? FieldType.HEAD_MY : FieldType.HEAD_OPPONENT); 
    }
    
    /**
     * makes a move, this will change the position of this bot
     * it doesn't make any checks, so it's fast but dangerous
     * 
     * @param steering 
     */
    public void move(Steering steering) {
        try {
            Position pos = POSITIONS.get(ID-1);
            if (firstMove == null) {
                firstMove = steering;
            }
            
            switch (steering) {
                case AHEAD:
                    switch (pos.getDirection()) {
                        case NORTH:
                            setPosition(ID, pos.getxCoordinate(), pos.getyCoordinate() - 1, pos.getDirection());
                            break;
                        case EAST:
                            setPosition(ID, pos.getxCoordinate() + 1, pos.getyCoordinate(), pos.getDirection());
                            break;
                        case SOUTH:
                            setPosition(ID, pos.getxCoordinate(), pos.getyCoordinate() + 1, pos.getDirection());
                            break;
                        case WEST:
                            setPosition(ID, pos.getxCoordinate() - 1, pos.getyCoordinate(), pos.getDirection());
                            break;
                    }
                    aheadCounter++;
                    break;
                case RIGHT:
                    switch (pos.getDirection()) {
                        case NORTH:
                            setPosition(ID, pos.getxCoordinate() + 1, pos.getyCoordinate(), Direction.EAST);
                            break;
                        case EAST:
                            setPosition(ID, pos.getxCoordinate(), pos.getyCoordinate() + 1, Direction.SOUTH);
                            break;
                        case SOUTH:
                            setPosition(ID, pos.getxCoordinate() - 1, pos.getyCoordinate(), Direction.WEST);
                            break;
                        case WEST:
                            setPosition(ID, pos.getxCoordinate(), pos.getyCoordinate() - 1, Direction.NORTH);
                            break;
                    }
                    break;
                case LEFT:
                    switch (pos.getDirection()) {
                        case NORTH:
                            setPosition(ID, pos.getxCoordinate() - 1, pos.getyCoordinate(), Direction.WEST);
                            break;
                        case EAST:
                            setPosition(ID, pos.getxCoordinate(), pos.getyCoordinate() - 1, Direction.NORTH);
                            break;
                        case SOUTH:
                            setPosition(ID, pos.getxCoordinate() + 1, pos.getyCoordinate(), Direction.EAST);
                            break;
                        case WEST:
                            setPosition(ID, pos.getxCoordinate(), pos.getyCoordinate() + 1, Direction.SOUTH);
                            break;
                    }
                    break;
            }
            stepCounter++;
            ratingCounter += get(pos).getContextualEvaluation();
        } catch (InvalidInputException ex) {
            Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Position getCurrentPosition() {
        return POSITIONS.get(ID-1);
    }
    
    public Steering getFirstMove() {
        return firstMove;
    }
    
    /**
     * returns true if the bot is out
     * 
     * @param id
     * @return
     * @throws InvalidInputException
     */
    public boolean out(int id) throws InvalidInputException{
        Position position = POSITIONS.get(id-1);
        get(position).setFieldType(FieldType.BODY);
        
        return this.ID == id;
    }
    
    public Steering steering() {
        return STRATEGY.steeringAlgorithm(this);
    }
    
    /**
     * evaluates each field of the gameboard
     */
    public void evaluate() {
        FIELDS.forEach(field -> field.evaluateIsolated());
        FIELDS.forEach(field -> field.evaluateContextSensitive());
    }
    
    /**
     * returns the most attractive Target (high evaluated and close to the
     * current position)
     * 
     * @return returns the nears field with the highest rating
     */
    public List<Field> findTargets() {
        OptionalInt maxValue = FIELDS.stream().mapToInt(field -> field.getContextualEvaluation()).max();
        
        if (!maxValue.isPresent()) {
            LOGGER.severe("couldn't get max value of the contextual evaluation");
            System.exit(1);
        }
        
        return FIELDS.stream()
                .filter(field -> field.getContextualEvaluation() >= maxValue.getAsInt()-1)
                .collect(Collectors.toList());
    }
    
    /**
     * returns true if the given steering direction heads to an empty field
     * 
     * @param steering
     * @return 
     */
    public boolean fieldCheck(Steering steering) {
        Field neighbour = null;
        
        try {
            Position position = POSITIONS.get(ID - 1);
            LOGGER.log(Level.FINE, "position: {0}, {1}, {2}", new Object[]{position.getxCoordinate(), position.getyCoordinate(), position.getDirection()});
            Field field = get(position);
            LOGGER.log(Level.FINE, "field: {0}", field);
            Direction direction = calculateDirection(position, steering);
            LOGGER.log(Level.FINE, "direction: {0}", direction.name());
            neighbour = field.getNeighbourByDirection(direction);
            LOGGER.log(Level.FINE, "neighour: {0}", neighbour);
            
        } catch (InvalidInputException ex) {
            Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        return neighbour != null ? neighbour.isEmpty() : false;
    }
    
    public String showEvaluationValue() {
        StringBuilder output = new StringBuilder(WIDTH*HEIGHT+HEIGHT);
        int charCounter = 0;
        
        for (Field field : FIELDS){
            output.append(field.showEvaluationValue());
            charCounter++;
            if (charCounter == WIDTH){
                output.append('\n');
                charCounter = 0;
            }
        }
        
        return output.toString();
    }
    
    @Override
    public String toString(){
        StringBuilder output = new StringBuilder(WIDTH*HEIGHT+HEIGHT);
        int charCounter = 0;
        
        for (Field field : FIELDS){
            output.append(field.toString());
            charCounter++;
            if (charCounter == WIDTH){
                output.append('\n');
                charCounter = 0;
            }
        }
        
        return output.toString();
    }
        
    /**
     * returns the direction in which the bot is heading, considered the given
     * position and steering
     * 
     * @param position
     * @param steering
     * @return 
     */
    private Direction calculateDirection(Position position, Steering steering) throws InvalidInputException  {
        Direction[] directions = Direction.values();
        
        switch (steering) {
            case AHEAD:
                return position.getDirection();
            case RIGHT:
                for (int i = 0; i < directions.length; i++){
                    if(directions[i] == position.getDirection()){
                        if(i < directions.length - 1){
                            return directions[i + 1];
                        } else {
                            return directions[0];
                        }
                    }
                }
            case LEFT:
                for (int i = 0; i < directions.length; i++){
                    if(directions[i] == position.getDirection()){
                        if(i > 0){
                            return directions[i - 1];
                        } else {
                            return directions[directions.length - 1];
                        }
                    }
                }
            default:
                throw new InvalidInputException("invalid steering direction: " + steering.name());
        }
    }
    
    public void checkLinkage() {
        FIELDS.forEach(field -> field.checkLinkage());
    }
    
    private Field get(Position position) throws InvalidInputException {
        return get(position.getxCoordinate(), position.getyCoordinate());
    }
    
    private Field get(int x, int y) throws InvalidInputException {
        if (x < 1 || y < 1 || x > WIDTH || y > HEIGHT){
            throw new InvalidInputException("invalid coordinates: (" + x + ", " + y + ")");
        }        
        return FIELDS.get(WIDTH * (y - 1) + x -1);
    }
    
    private Direction getDirection(String direction) throws InvalidInputException {
        switch (direction) {
            case "NORTH":
            case "N":
                return Direction.NORTH;
            case "SOUTH":
            case "S":
                return Direction.SOUTH;
            case "EAST":
            case "E":
                return Direction.EAST;
            case "WEST":
            case "W":
                return Direction.WEST;
            default:
                throw new InvalidInputException("invalid direction: " + direction);
        }
    }

    @Override
    public int compareTo(Game o) {
        int steps = this.stepCounter - o.stepCounter;
        
        if (steps == 0) {
            return this.ratingCounter - o.ratingCounter;
        } else {
            return steps;
        }
    }
    
    public double getEvaluationPoints() {
        return stepCounter;
    }
}
