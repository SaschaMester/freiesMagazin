/*
 * Copyright (C) 2014 Stefan Schmidhuber
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package lasvegasbot;

import java.util.List;
import java.util.logging.Logger;

/**
 *
 * @author stefan
 */
public class Field implements Comparable<Field>{
    
    private static final Logger LOGGER = Logger.getLogger(Field.class.getName());
    private final int xCoordinate;
    private final int yCoordinate;
    private FieldType fieldType;    
    private Field north = null;
    private Field south = null;
    private Field east = null;
    private Field west = null;
    private int isolatedEvaluation;
    private int contextualEvaluation;
    
    public Field(int x, int y, char type) throws InvalidInputException{
        xCoordinate = x;
        yCoordinate = y;
        switch (type){
            case '.':
                fieldType = FieldType.EMPTY;
                break;
            case '#':
                fieldType = FieldType.BARRIER;
                break;
            default:
                throw new InvalidInputException("invalid field repesentation: " + type);
        }
    }
    
    //copy constructor
    public Field(Field field) {
        this.xCoordinate = field.xCoordinate;
        this.yCoordinate = field.yCoordinate;
        this.fieldType = field.fieldType;
    }
    
    public void link(List<Field> fields, int width, int height){
        //link north
        if (yCoordinate != 1 && checkIndex(fields, (yCoordinate - 2) * width + xCoordinate - 1)){
            north = fields.get((yCoordinate - 2) * width + xCoordinate - 1);
        }
        
        //link south
        if (yCoordinate != height && checkIndex(fields, yCoordinate * width + xCoordinate - 1)){
            south = fields.get(yCoordinate * width + xCoordinate - 1);
        }
        
        //link east
        if (xCoordinate != width && checkIndex(fields, (yCoordinate - 1) * width + xCoordinate)){
            east = fields.get((yCoordinate - 1) * width + xCoordinate);
        }
        
        //link west
        if (xCoordinate != 1 && checkIndex(fields, (yCoordinate - 1) * width + xCoordinate - 2)){
            west = fields.get((yCoordinate - 1) * width + xCoordinate - 2);
        }
    }
    
    public double getDistanceTo(Field other) {
        return Math.sqrt(Math.pow(this.xCoordinate-other.xCoordinate, 2) + Math.pow(this.yCoordinate - other.yCoordinate, 2));
    }
    
    public void evaluateIsolated() {
        isolatedEvaluation = -1;
        if (fieldType == FieldType.EMPTY) {
            if (north != null) {
                if (north.fieldType == FieldType.EMPTY) {
                    isolatedEvaluation++;
                } else if (north.fieldType == FieldType.HEAD_OPPONENT) {
                    isolatedEvaluation -= 3;
                }
            }
            
            if (south != null) {
                if (south.fieldType == FieldType.EMPTY) {
                    isolatedEvaluation++;
                } else if (south.fieldType == FieldType.HEAD_OPPONENT) {
                    isolatedEvaluation -= 3;
                }
            }
            
            if (west != null) {
                if (west.fieldType == FieldType.EMPTY) {
                    isolatedEvaluation++;
                } else if (west.fieldType == FieldType.HEAD_OPPONENT) {
                    isolatedEvaluation -= 3;
                }
            }
            
            if (east != null) {
                if (east.fieldType == FieldType.EMPTY) {
                    isolatedEvaluation++;
                } else if (east.fieldType == FieldType.HEAD_OPPONENT) {
                    isolatedEvaluation -= 3;
                }
            }
        }
    }
    
    public void evaluateContextSensitive() {
        if (isolatedEvaluation > 0) {
            contextualEvaluation = isolatedEvaluation +
                (north != null ? north.getIsolatedEvaluation() : 0) +
                (south != null ? south.getIsolatedEvaluation() : 0) +
                (east != null ? east.getIsolatedEvaluation() : 0) +
                (west != null ? west.getIsolatedEvaluation() : 0);
        } else {
            contextualEvaluation = isolatedEvaluation;
        }
    }
    
    public void checkLinkage(){
        System.out.println(xCoordinate + ", " + yCoordinate + ": " + toString());
        
        if(getNorth() != null)
            System.out.println("NORTH: " + getNorth().toString());
        
        if(getEast()!= null)
            System.out.println("EAST: " + getEast().toString());
        
        if(getSouth()!= null)
            System.out.println("SOUTH: " + getSouth().toString());
        
        if(getWest()!= null)
            System.out.println("WEST: " + getWest().toString());
        
        System.out.println("----\n");
    }
    
    private boolean checkIndex(List list, int index) {
        return index >= 0 && index < list.size();
    }

    public int getIsolatedEvaluation() {
        return isolatedEvaluation;
    }

    public int getContextualEvaluation() {
        return contextualEvaluation;
    }
    
    public Field getNeighbourByDirection(Direction direction) throws InvalidInputException{
        switch (direction){
            case NORTH:
                return getNorth();
            case EAST:
                return getEast();
            case SOUTH:
                return getSouth();
            case WEST:
                return getWest();
            default:
                throw new InvalidInputException("invalid direction: " + direction.name());
        }
    }
    
    public boolean isEmpty() {
        return fieldType == FieldType.EMPTY;
    }
    
    public Field getNorth() {
        return north;
    }
    
    public Field getSouth() {
        return south;
    }
    
    public Field getEast() {
        return east;
    }
    
    public Field getWest() {
        return west;
    }

    public void setFieldType(FieldType fieldType) {
        this.fieldType = fieldType;
    }
    
    /**
     * returns true if the given position has the same coordinates as this field
     * 
     * @param position
     * @return 
     */
    public boolean fits(Position position) {
        return xCoordinate == position.getxCoordinate() && yCoordinate == position.getyCoordinate();
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + this.xCoordinate;
        hash = 29 * hash + this.yCoordinate;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Field other = (Field) obj;
        if (this.xCoordinate != other.xCoordinate) {
            return false;
        }
        if (this.yCoordinate != other.yCoordinate) {
            return false;
        }
        return true;
    }
    
    public String showEvaluationValue() {
        return "\t" + contextualEvaluation;
    }
    
    public String printCoordinates() {
        return "(" + xCoordinate + ", " + yCoordinate + ")";
    }
    
    @Override
    public String toString(){
        return fieldType.toString();
    }

    @Override
    public int compareTo(Field o) {
        return this.contextualEvaluation - o.contextualEvaluation;
    }
}
