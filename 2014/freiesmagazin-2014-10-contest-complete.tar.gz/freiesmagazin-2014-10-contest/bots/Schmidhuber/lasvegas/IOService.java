/*
 * Copyright (C) 2014 Stefan Schmidhuber
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package lasvegasbot;

import java.util.Scanner;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/**
 *
 * @author stefan
 */
public class IOService {
    
    private static final Logger LOGGER = Logger.getLogger(IOService.class.getName());
    private final Scanner INPUT;
    private final Strategy STRATEGY;
    private boolean nextRound = true;
    private boolean out = false;
    
    private Game game;
    
    public IOService(String[] args) {
        INPUT = new Scanner(System.in);
        // use "horizontal white space", "comma" or "newline" as delimiter
        INPUT.useDelimiter(Pattern.compile("\\h|,|\\n"));
        
        if (args.length == 1) {
            switch (args[0]) {
                case "stupid":
                    STRATEGY = new StupidRandomStrategy();
                    break;

                case "simple":
                    STRATEGY = new SimpleRandomStrategy();
                    break;

                case "random":
                    STRATEGY = new SimpleMoreRandomStrategy();
                    break;

                case "lasvegas":
                    STRATEGY = new LasVegasStrategy();
                    break;

                default:
                    STRATEGY = new LasVegasStrategy();
            }
        } else {
            STRATEGY = new LasVegasStrategy();
        }
    }
    
    public void start() {
        try {
            game = initGame();
            readStartPositions();
            
            do {
                if (!out) {
                    steerBot();
                }
                readPosition();
            } while (nextRound);
            
        } catch (InvalidInputException e){
            LOGGER.severe(e.toString());
            System.exit(1);
        }
    }

    private Game initGame() throws InvalidInputException {
        int width;
        int height;
        int id;
        StringBuilder board;
        String line;
        
        if(!"GAMEBOARDSTART".equalsIgnoreCase(INPUT.next())) {
            throw new InvalidInputException("no \"GEMEBOARDSTART\" found");
        }
        //get width and height
        width = INPUT.nextInt();
        height = INPUT.nextInt();
        
        /* initialise the StringBuilder with all characters neccessary to draw
           the field and the newline symbols at the end of each row*/
        board = new StringBuilder(width * height + height);
        
        INPUT.nextLine();           //go to end of line
        line = INPUT.nextLine();    //read first line
        while (!"GAMEBOARDEND".equalsIgnoreCase(line)){
            board.append(line);
            board.append("\n");
            line = INPUT.nextLine();
        }
        
        if(!"SET".equalsIgnoreCase(INPUT.next())) {
            throw new InvalidInputException("no \"SET\" message found");
        }
        //get bot id
        id = INPUT.nextInt();
        
        return new Game(width, height, board.toString(), id, STRATEGY);
    }

    private void readStartPositions() throws InvalidInputException {
        while (INPUT.hasNext()) {
            if (!"POS".equalsIgnoreCase(INPUT.next())) {
                break;
            }
            
            game.initPosition(INPUT.nextInt(), INPUT.nextInt(), INPUT.nextInt(), INPUT.next());
        }
    }

    private void steerBot() {
        System.out.println(game.steering());
    }

    private void readPosition() throws InvalidInputException {
        boolean stop = false;
        while (!stop && INPUT.hasNext()) {
            switch (INPUT.next()) {
                case "POS":
                    game.setPosition(INPUT.nextInt(), INPUT.nextInt(), INPUT.nextInt(), INPUT.next());
                    break;
                case "OUT":
                    out = game.out(INPUT.nextInt());
                    break;
                case "ROUND":
                    stop = true;
                    break;
                case "END":
                    nextRound = false;
                    stop = true;
                    break;
            }
        }
    }
}
