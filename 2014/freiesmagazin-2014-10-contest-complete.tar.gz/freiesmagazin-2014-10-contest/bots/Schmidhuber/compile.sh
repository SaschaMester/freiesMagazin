#! /bin/sh

# delete previous built files
if [ -d build ]; then
rm -r build
fi

mkdir build
# compile java files
javac -d ./build lasvegas/*.java
cd build
# create JAR archiv
jar cvfm Bot.jar ../lasvegas/MANIFEST.MF *
chmod u+x Bot.jar

exit 0
