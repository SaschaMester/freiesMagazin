#!/bin/bash
cd $(dirname $0)
SOURCES=`find "$PWD" -name '*.java' -type f`
javac $SOURCES
CLASSES=`find . -name '*.class' -type f`

JARFILE=edrbot.jar
jar cfm ./$JARFILE ./manifest.mf $CLASSES;
chmod +x ./$JARFILE
