package de.rochefort.tron.strategy;

import java.util.ArrayList;
import java.util.List;

import de.rochefort.tron.commands.Orientation;
import de.rochefort.tron.game.GameBoard;
import de.rochefort.tron.game.GameManager;
import de.rochefort.tron.game.Player;

public abstract class Strategy {
	protected final Player ownPlayer;
	protected final GameBoard gameboard;

	public Strategy() {
		this.gameboard = GameManager.instance().getGameboard();
		this.ownPlayer = GameManager.instance().getOwnPlayer();
	}
	
	public abstract Orientation getNextOrientation();
	
	protected static List<Orientation> getOptions(){
		List<Orientation> options = new ArrayList<Orientation>();
		for(Orientation o : Orientation.values()){
			options.add(o);
		}
		return options;
	}
	
	protected Orientation lastResort(){
		return Orientation.AHEAD;
	}
}
