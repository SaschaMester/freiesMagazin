package de.rochefort.tron.game;

import de.rochefort.tron.bot.Logger;
import de.rochefort.tron.commands.Orientation;

public class GameBoard {
	private static final char EMPTY_TILE 	= '.';
	private static final char OCCUPIED_TILE = '#';
	public static final int TILE_STATE_FREE = -1;
	public static final int TILE_STATE_OBSTACLE = 0;
	private int[][] tiles;
	private int parsedRows = 0;
	private int width;
	private int height;

	public GameBoard(int width, int height) {
		tiles = new int[width][height];
		this.width  = width;
		this.height = height;
	}

	public boolean parseRow(String row){
		if(parsedRows >= this.height){
			Logger.error("Too many gameboard rows!");
			return false;
		}
		if(row == null || row.isEmpty()){
			Logger.error("Empty gameboard row");
			return false;
		}
		if(row.length() != this.width){
			Logger.error("Invalid gameboard row length: "+row.length()+". Expected: "+tiles.length);
			return false;
		}
		for(int i=0; i<row.length(); i++){
			char c = row.charAt(i);
			if(c == EMPTY_TILE){
				tiles[i][parsedRows] = TILE_STATE_FREE;
			}
			else if(c == OCCUPIED_TILE){
				tiles[i][parsedRows] = 0;
			}
			else{
				Logger.error("Invalid gameboard tile character: "+c+" at position ("+i+","+parsedRows+")");
				return false;
			}
		}
		parsedRows++;	
		return true;
	}
	
	public boolean isValidPosition(Position position){
		return position.getX()>0 && position.getY() > 0 && position.getX() <= width && position.getY() <= height;
	}
	
	public boolean isPositionFree(Position position){
		if(!isValidPosition(position))
			return false;
		return tiles[position.getX()-1][position.getY()-1] == TILE_STATE_FREE;
	}
	
	public void occupyPosition(Position position, int playerNo){
		tiles[position.getX()-1][position.getY()-1] = playerNo;
	}

	public boolean isAdjacentPositionFree(Position referencePosition, Direction direction){
		Position adj = referencePosition.copy();
		adj.move(direction);
		return isPositionFree(adj);
	}
	
	public boolean isAdjacentPositionFree(Position referencePosition, Direction referenceDirection, Orientation orient){
		return isAdjacentPositionFree(referencePosition, referenceDirection.turn(orient));
	}
	
	
}
