package de.rochefort.tron.game;

import de.rochefort.tron.commands.Orientation;

public enum Direction {
		NORTH("N"),
		SOUTH("S"),
		EAST("E"),
		WEST("W");
		private String character;
		
		Direction(String character){
			this.character = character;
		}
		
		public static Direction fromChar(String c){
			for(Direction d: Direction.values()){
				if(d.character.equals(c))
					return d;
			}
			return NORTH;
		}
		
		public Direction leftOf(){
			switch(this){
				case EAST:
					return NORTH;
				case NORTH:
					return WEST;
				case SOUTH:
					return EAST;
				case WEST:
					return SOUTH;
				default:
					return this;
				
			}
		}
		public Direction rightOf(){
			switch(this){
				case EAST:
					return SOUTH;
				case NORTH:
					return EAST;
				case SOUTH:
					return WEST;
				case WEST:
					return NORTH;
				default:
					return this;
					
			}
		}
		
		public Direction turn(Orientation orient){
			switch(orient){
				case LEFT:
					return this.leftOf();
				case RIGHT:
					return this.rightOf();
				default:
					return this;
				
			}
		}
		
}
