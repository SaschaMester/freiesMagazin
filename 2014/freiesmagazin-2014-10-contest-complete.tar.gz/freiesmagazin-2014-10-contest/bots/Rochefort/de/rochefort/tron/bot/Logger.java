package de.rochefort.tron.bot;

public class Logger {
	private static final boolean INFO  = false;
	private static final boolean DEBUG = false;
	private static final boolean ERROR = false;

	public static void info(String message){
		if(INFO)
			System.err.println("(II) EDR BOT: "+message);
	}
	public static void debug(String message){
		if(DEBUG)
			System.err.println("(DD) EDR BOT: "+message);
	}
	public static void error(String message){
		if(ERROR)
			System.err.println("(EE) EDR BOT: "+message);
	}
}
