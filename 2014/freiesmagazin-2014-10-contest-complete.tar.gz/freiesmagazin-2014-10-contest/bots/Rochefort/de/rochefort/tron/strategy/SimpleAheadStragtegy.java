package de.rochefort.tron.strategy;

import de.rochefort.tron.commands.Orientation;

public class SimpleAheadStragtegy extends Strategy{

	public SimpleAheadStragtegy() {
	}

	@Override
	public Orientation getNextOrientation() {
		return Orientation.AHEAD;
	}

}
