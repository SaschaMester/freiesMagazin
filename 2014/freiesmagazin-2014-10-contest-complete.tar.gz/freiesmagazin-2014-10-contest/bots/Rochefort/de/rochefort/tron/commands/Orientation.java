package de.rochefort.tron.commands;

public enum Orientation {
	AHEAD,
	LEFT,
	RIGHT;	
}
