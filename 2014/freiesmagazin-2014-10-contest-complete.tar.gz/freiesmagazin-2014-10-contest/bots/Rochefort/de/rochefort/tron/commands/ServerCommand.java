package de.rochefort.tron.commands;

import java.util.List;

public interface ServerCommand {
	public void execute(List<String> args);
}
