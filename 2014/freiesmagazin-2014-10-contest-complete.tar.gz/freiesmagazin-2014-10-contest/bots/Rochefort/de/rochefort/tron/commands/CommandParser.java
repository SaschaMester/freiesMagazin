package de.rochefort.tron.commands;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import de.rochefort.tron.bot.Logger;

public class CommandParser {
	private static CommandParser INSTANCE = new CommandParser();
	private AtomicBoolean active = new AtomicBoolean(false);
	private BufferedReader br;
	
	private CommandParser() {
		
		
	}
	
	public void start (){
		if(active.compareAndSet(false, true)){
			br = new BufferedReader(new InputStreamReader(System.in));
			while(active.get()){
				String commandLine = null;
				String command = null;
				try {
					commandLine = br.readLine();
					Logger.debug("Parsing command "+commandLine+"!");
				} catch (IOException ioe) {
					handleError(ioe);
					continue;
				}
				
	
				try {
					if (commandLine == null ){
						handleError(new RuntimeException("NULL command line received"));
						return;
					}
					if (commandLine.equals("")){
						handleError(new RuntimeException("Empty command line received"));
						return;
					}
					String[] commandLineWords = commandLine.split("\\s+");
					command = commandLineWords[0];
					if(command != null){
						List<String> args = new ArrayList<String>();
						for(int i = 1; i<commandLineWords.length; i++){
							args.add(commandLineWords[i]);
						}
						handleCommand(command, args);
					}
					
				} catch (Throwable e) {
					handleError(e);
					continue;
				}
			}

			try {
				br.close();
			} catch (IOException e) {
				handleError(e);
			}
		}
	}
	private void handleCommand(String command, List<String> args) {
		CommandInterpreter.instance().dispatchCommand(command, args);
	}
	
	private void handleError(Throwable e) {
		Logger.error("Error encountered: "+(e.getLocalizedMessage()!=null?e.getLocalizedMessage():e.getClass().getSimpleName()));
		e.printStackTrace();
		System.exit(-1);
		
	}

	public boolean isActive() {
		return active.get();
	}
	
	public void stop() {
		this.active.set(false);
	}
	
	public static CommandParser instance() {
		return INSTANCE;
	}
}
