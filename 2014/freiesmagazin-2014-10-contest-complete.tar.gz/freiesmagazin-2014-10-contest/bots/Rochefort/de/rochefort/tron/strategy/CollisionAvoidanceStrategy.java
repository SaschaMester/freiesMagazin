package de.rochefort.tron.strategy;

import java.util.List;
import de.rochefort.tron.commands.Orientation;
import de.rochefort.tron.game.Direction;
import de.rochefort.tron.game.Position;

public class CollisionAvoidanceStrategy extends Strategy{

	public CollisionAvoidanceStrategy() {
		super();
	}

	@Override
	public Orientation getNextOrientation() {
		Position currentPos = ownPlayer.getPosition();
		Direction currentDirection = ownPlayer.getDirection();
		List<Orientation> options = getOptions();
		for(Orientation o : Orientation.values()){
			if(!gameboard.isAdjacentPositionFree(currentPos, currentDirection, o)){
				options.remove(o);
			}
		}
		
		if(options.contains(Orientation.AHEAD)){
			return Orientation.AHEAD;
		}
		else if(options.size()>=1){
			return options.get(0);
		}
		return lastResort();
	}

}
