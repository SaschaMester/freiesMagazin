package de.rochefort.tron.strategy;

public class DecisionMaker {
private static DecisionMaker INSTANCE = new DecisionMaker();
	private Strategy currentStrategy;
	private DecisionMaker() {
		this.currentStrategy = new CollisionAvoidanceStrategy();
	}

	public static DecisionMaker instance() {
		return INSTANCE;
	}
	
	public void decide(){
		System.out.println(this.currentStrategy.getNextOrientation().toString());
	}
}
