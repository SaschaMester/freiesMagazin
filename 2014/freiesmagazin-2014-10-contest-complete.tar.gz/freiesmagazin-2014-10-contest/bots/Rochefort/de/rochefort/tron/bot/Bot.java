package de.rochefort.tron.bot;

import de.rochefort.tron.commands.CommandParser;

public class Bot {

	public Bot() {
		CommandParser.instance().start();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new Bot();
	}
}
