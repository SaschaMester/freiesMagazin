package de.rochefort.tron.game;

import java.util.LinkedList;
import java.util.List;

import de.rochefort.tron.bot.Logger;
import de.rochefort.tron.commands.CommandParser;

public class GameManager {
	private static GameManager INSTANCE = new GameManager();
	private GameBoard gameboard;
	private int currentRound = 0;
	private int ownPlayerNumber;
	private List<Player> players = new LinkedList<Player>();
	private GameManager() {
	}

	public static GameManager instance(){
		return INSTANCE;
	}
	
	public void initializeGameboard(int width, int height){
		this.gameboard = new GameBoard(width, height);
	}
	
	public boolean parseGameboardRow(String row){
		if(this.gameboard == null){
			Logger.debug("Gameboard row before GAMEBOARDSTART!");
			return false;
		}
		return this.gameboard.parseRow(row);
	}
	
	public void setCurrentRound(int currentRound) {
		this.currentRound = currentRound;
	}
	
	public int getCurrentRound() {
		return currentRound;
	}
	
	public void setOwnPlayerNumber(int playerNumber){
		this.ownPlayerNumber = playerNumber;
	}
	
	public void killPlayer(int playerNumber){
		getPlayerById(playerNumber).kill();
	}
	
	public void handlePlayerPosition(int playerNumber, Position position, Direction direction){
		int index = playerNumber - 1;
		if(currentRound == 0){
			addNewPlayer(playerNumber, position, direction, index);
		}
		else{
			updatePlayerPosition(playerNumber, position, direction, index);
		}
		this.gameboard.occupyPosition(position, playerNumber);
	}

	private void updatePlayerPosition(int playerNumber, Position position, Direction direction, int index) {
		Player p = getPlayerById(playerNumber);
		p.setDirection(direction);
		p.setPosition(position);
	}

	private void addNewPlayer(int playerNumber, Position position, Direction direction, int index) {
		int size = players.size();
		if(index != size){
			Logger.error("Unexpected Player number "+playerNumber+"! Expected: "+(size+1));
			System.exit(-1);
		}
		players.add(new Player(this.gameboard, playerNumber, position, direction));
	}

	public Player getOwnPlayer() {
		return getPlayerById(ownPlayerNumber);
	}
	
	public Player getPlayerById(int id){
		int index = id - 1;
		if(index < 0 || index >= players.size()){
			Logger.error("Unexpected Player number "+id+"! Expected: Value > 0 && Value <= "+(players.size()));
			System.exit(-1);
		}
		return players.get(index);
	}

	public GameBoard getGameboard() {
		return gameboard;
	}
}
