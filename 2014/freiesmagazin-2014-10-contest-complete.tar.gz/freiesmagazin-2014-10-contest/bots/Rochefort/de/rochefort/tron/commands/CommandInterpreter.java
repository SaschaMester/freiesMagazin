package de.rochefort.tron.commands;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import de.rochefort.tron.bot.Logger;
import de.rochefort.tron.game.Direction;
import de.rochefort.tron.game.GameManager;
import de.rochefort.tron.game.Position;
import de.rochefort.tron.strategy.DecisionMaker;

public class CommandInterpreter {
	
	private static CommandInterpreter INSTANCE = new CommandInterpreter();
	private Map<String, ServerCommand> commands = new Hashtable<String, ServerCommand>();
	private boolean receivingGameBoard = false;
	private CommandInterpreter() {
		initializeCommandList();
	}
	
	public static CommandInterpreter instance() {
		return INSTANCE;
	}
	
	public void dispatchCommand(String command, List<String> args){

		Logger.debug("Received command "+command+"!");
		if(receivingGameBoard && !command.equals("GAMEBOARDEND")){
			receiveGameboardRow(command);
		}
		else{
			ServerCommand cmd = commands.get(command);
			if(cmd != null){
				cmd.execute(args);
			}
			else {
				Logger.debug("Unknown Command \""+command+"\"");
			}
		}
	}
	
	private void receiveGameboardRow(String command) {

		Logger.debug("Received gameboard row "+command+"!");
		if(!GameManager.instance().parseGameboardRow(command)){
			System.exit(-1);
		}
	}

	private void initializeCommandList(){
		commands.put("GAMEBOARDSTART", new ServerCommand() {
			@Override
			public void execute(List<String> args) {
				receivingGameBoard = true;
				int width = Integer.parseInt(args.get(0).split(",")[0]);
				int height = Integer.parseInt(args.get(0).split(",")[1]);
				GameManager.instance().initializeGameboard(width, height);
			}
		});
		
		commands.put("GAMEBOARDEND", new ServerCommand() {
			@Override
			public void execute(List<String> args) {
				receivingGameBoard = false;
			}
		});
		
		commands.put("SET", new ServerCommand() {
			@Override
			public void execute(List<String> args) {
				int pNumber = Integer.parseInt(args.get(0));
				GameManager.instance().setOwnPlayerNumber(pNumber);
			}
		});
		
		commands.put("POS", new ServerCommand() {
			@Override
			public void execute(List<String> args) {
				int playerNumber = Integer.parseInt(args.get(0));
				String pos = args.get(1);
				int x = Integer.parseInt(pos.split(",")[0]);
				int y = Integer.parseInt(pos.split(",")[1]);
				Direction direction = Direction.fromChar(args.get(2));
				Position position = new Position(x, y);
				GameManager.instance().handlePlayerPosition(playerNumber, position, direction);
			}
		});
		
		commands.put("ROUND", new ServerCommand() {
			@Override
			public void execute(List<String> args) {
				Logger.debug("Received ROUND command!");
				int round = Integer.parseInt(args.get(0));
				GameManager.instance().setCurrentRound(round);
				DecisionMaker.instance().decide();
			}
		});
		
		commands.put("OUT", new ServerCommand() {
			@Override
			public void execute(List<String> args) {
				int pNumber = Integer.parseInt(args.get(0));
				GameManager.instance().killPlayer(pNumber);
			}
		});

		commands.put("END", new ServerCommand() {
			@Override
			public void execute(List<String> args) {
				System.exit(0);
			}
		});
	}

}
