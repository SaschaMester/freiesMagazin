package de.rochefort.tron.game;

public class Player {
	private final GameBoard gameBoard;
	private final int playerNo;
	private Position position;
	private Direction direction;
	private boolean alive;
	
	public Player(GameBoard gameBoard, int playerNo, Position position, Direction direction) {
		this.gameBoard = gameBoard;
		this.playerNo = playerNo;
		this.position = position;
		this.direction = direction;
		this.alive = true;
	}

	public int getPlayerNo() {
		return playerNo;
	}
	
	public Position getPosition() {
		return position;
	}
	
	public void setPosition(Position position) {
		this.position = position;
	}
	
	public Direction getDirection() {
		return direction;
	}
	
	public void setDirection(Direction direction) {
		this.direction = direction;
	}
	
	public void moveAhead(){
		this.position.move(direction);
	}
	
	public void moveLeft(){
		this.position.move(direction.leftOf());
	}
	
	public void moveRight(){
		this.position.move(direction.rightOf());
	}
	
	public void kill(){
		this.alive = false;
	}
	
	public boolean isAlive() {
		return alive;
	}
}
