#!/bin/sh
cd `dirname $0`
java tron/MyBot
