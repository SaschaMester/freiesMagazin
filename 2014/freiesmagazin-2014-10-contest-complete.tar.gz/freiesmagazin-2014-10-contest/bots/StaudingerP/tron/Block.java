package tron;
import java.util.ArrayList;

/**
    (C) Copyright 2014 Philipp Staudinger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

public class Block {
	private int size;
	private boolean[][] border;
	private Position[] borderPos;
	
	public Block(int width, int height) {
		this.size = 0;
		border = new boolean[height][width];
	}
	
	public void addPos() {
		size++;
	}
	
	public void addBorderPos(Position pos) {
		border[pos.y-1][pos.x-1] = true;
	}
	
	public boolean containsBorderPos(Position pos) {
		return border[pos.y-1][pos.x-1];
	}
	
	public void calcBorderPosArr() {
		ArrayList<Position> list = new ArrayList<Position>();
		for(int i=0; i<border.length; i++) {
			for(int j=0; j<border[0].length; j++) {
				if(border[i][j]) {
					list.add(new Position(j+1, i+1));
				}
			}
		}
		borderPos = list.toArray(new Position[0]);
	}
	
	public Position[] getAllBorderPos() {
		return borderPos;
	}
	
	public int getSize() {
		return size;
	}
}

