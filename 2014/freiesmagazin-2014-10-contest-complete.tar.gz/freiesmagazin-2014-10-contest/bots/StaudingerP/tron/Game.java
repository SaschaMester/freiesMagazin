package tron;
import java.util.ArrayList;

/**
    (C) Copyright 2014 Philipp Staudinger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// represents the board of the game.
public class Game {
	private int width, height;					// dimensions of the board
	private boolean[][] board;					// states of the fields (true -> taken)
	private int myPlayer;
	private Player[] players = new Player[0];
	private int numStepsNear, numStepsFar, numStepsGo;
	
	public Game(int width, int height, String str) {
		this.width = width;
		this.height = height;
		board = new boolean[height][width];
		int s=0;
		for(Position pos: getAllPositions()) {
			switch(str.charAt(s)) {
				case '.': 	board[pos.y-1][pos.x-1] = false;
						  	break;
				case '#': 	board[pos.y-1][pos.x-1] = true;
				  		  	break;
			}
			s++;
		}
		numStepsNear = 6;
		numStepsFar = 25;
		numStepsGo = 10;
		if(width*height > 1000) {
			numStepsNear = 5;
		}
		int tmp = width*height/250;
		if(tmp > 10) {
			tmp = 10;
		}
		numStepsFar -= tmp;
	}
	
	public String move() {
		// some variables needed
		boolean near = false;
		int[][] stepsToMe, stepsToOpp, stepsToMin;
		Block[] blocks;
		int min, max;
		Player me = players[myPlayer-1];
		
		// find possible positions
		Position[] possPos = getValidNeighbors(myPlayer);
		
		// no possible direction -> AHEAD
		if(possPos.length == 0) {
			return "AHEAD";
		}
		
		// find nearest opponent -> strategy only considers nearest opponent
		int nearestOpp = -1;
		int nearest = -1;
		for(int o: getLivingOpponents()) {
			if(nearest < 0 || me.pos.distance(players[o-1].pos) < nearest) {
				nearest = me.pos.distance(players[o-1].pos);
				nearestOpp = o;
			}
		}
		
		// no opponent left -> maximize steps
		stepsToMe = null;
		if(nearestOpp < 0) {
			stepsToMe = stepsTo(myPlayer, numStepsGo);
			blocks = calcBlocks(stepsToMe, numStepsGo);
			int[] steps = maxSteps(stepsToMe, possPos, blocks, numStepsGo, numStepsGo);
			max = steps[0];
			for(int i: steps) {
				max = Math.max(max, i);
			}
			possPos = reduce(possPos, steps, max);
			int[] neighbors = new int[possPos.length];
			for(int i=0; i<possPos.length; i++) {
				neighbors[i] = 0;
				for(Direction dir: Direction.all()) {
					Position p = possPos[i].neighbor(dir);
					if(!isValidPosition(p) || stepsToMe[p.y-1][p.x-1] < 0) {
						neighbors[i]++;
					}
				}
			}
			max = neighbors[0];
			for(int i: neighbors) {
				max = Math.max(max, i);
			}
			possPos = reduce(possPos, neighbors, max);
			return me.getDirection(possPos[0]);
		}
		Player opp = players[nearestOpp-1];
		
		// stepsTo arrays
		stepsToMe = stepsTo(myPlayer, numStepsFar);
		stepsToOpp = stepsTo(nearestOpp, numStepsFar);
		
		// stepsToMin -> minimal stepsTo from both players
		// near = true if stepsTo are overlapping
		stepsToMin = clone2D(stepsToMe);
		for(int i=0; i<height; i++) {
			for(int j=0; j<width; j++) {
				if(stepsToMe[i][j] > 0 && stepsToMe[i][j] <= numStepsNear && stepsToOpp[i][j] > 0 && stepsToOpp[i][j] <= numStepsNear) {
					near = true;
				}
				if(stepsToOpp[i][j] > 0 && (stepsToMin[i][j] < 0 || stepsToOpp[i][j] < stepsToMin[i][j])) {
					stepsToMin[i][j] = stepsToOpp[i][j];
				}
			}
		}
		blocks = calcBlocks(stepsToMin, numStepsNear);
		
		// checks if players are connected -> else removes opponent
		if(reachableFields(clone2D(stepsToMin), me.pos, blocks, numStepsNear) != reachableFields(clone2D(stepsToMin), opp.pos, blocks, numStepsNear) || me.pos.distance(opp.pos) <= 6) {
			int[][] stepsTo = stepsTo(myPlayer, 100000);
			boolean splitted = true;
			for(Position p: getValidNeighbors(nearestOpp)) {
				if(stepsTo[p.y-1][p.x-1] < 100000 && stepsTo[p.y-1][p.x-1] > 0) {
					splitted = false;
				}
			}
			if(splitted) {
				removePlayer(nearestOpp);
			}
		}
		
		// only one possible direction
		if(possPos.length == 1) {
			return me.getDirection(possPos[0]);
		}
		
		// if players are near enough -> full simulation of worst case scenario
		if(near) {
			int[] simGame = simGame(clone2D(stepsToMin), me.pos, opp.pos, possPos, blocks, numStepsNear);
			max = simGame[0];
			for(int i: simGame) {
				max = Math.max(max, i);
			}
			possPos = reduce(possPos, simGame, max);
			// if only one direction left -> return that direction
			if(possPos.length == 1) {
				return me.getDirection(possPos[0]);
			}
		}

		// reverse simulation
		for(Position pos: getValidNeighbors(nearestOpp)) {
			if(stepsToMe[pos.y-1][pos.x-1] > numStepsFar) {
				stepsToMe[pos.y-1][pos.x-1] = numStepsFar;
			}
		}
		blocks = calcBlocks(stepsToMe, numStepsFar);
		int[] reverseSim = simReverse(stepsToMe, stepsToOpp, opp.pos, possPos, blocks, numStepsFar);
		min = reverseSim[0];
		for(int i: reverseSim) {
			min = Math.min(min, i);
		}
		possPos = reduce(possPos, reverseSim, min);
		// if only one direction left -> return that direction
		if(possPos.length == 1) {
			return me.getDirection(possPos[0]);
		}
		
		// find directions which lead on the shortest way to opponent
		int[] stepsToNearestOpp = new int[possPos.length];
		for(int p=0; p<possPos.length; p++) {
			stepsToNearestOpp[p] = stepsToOpp[possPos[p].y-1][possPos[p].x-1];
		}
		nearest = stepsToNearestOpp[0];
		for(int i: stepsToNearestOpp) {
			if(nearest < 0) {
				nearest = i;
			} else if(i > 0) {
				nearest = Math.min(nearest, i);
			}
		}
		if(nearest > 0) {
			possPos = reduce(possPos, stepsToNearestOpp, nearest);
		}
		if(possPos.length == 1) {
			return me.getDirection(possPos[0]);
		}
		
		// find maximal steps to go
		blocks = calcBlocks(stepsToMe, numStepsGo);
		int[] steps = maxSteps(stepsToMe, possPos, blocks, numStepsGo, numStepsGo);
		max = steps[0];
		for(int i: steps) {
			max = Math.max(max, i);
		}
		possPos = reduce(possPos, steps, max);
		if(possPos.length == 1) {
			return me.getDirection(possPos[0]);
		}
		
		// find directions  which are closest to opponent
		stepsToNearestOpp = new int[possPos.length];
		for(int p=0; p<possPos.length; p++) {
			stepsToNearestOpp[p] = possPos[p].distance(opp.pos);
		}
		nearest = stepsToNearestOpp[0];
		for(int i: stepsToNearestOpp) {
			nearest = Math.min(nearest, i);
		}
		possPos = reduce(possPos, stepsToNearestOpp, nearest);
		
		// return one of the remaining directions
		return me.getDirection(possPos[0]);
	}

	// set position and direction of player number num
	public void setPlayerPosition(int num, Position pos, Direction dir) {
		if(num > players.length) {
			Player[] tmp = new Player[num];
			for(int i=0; i<players.length; i++) {
				tmp[i] = players[i];
			}
			players = tmp;
			players[num-1] = new Player(pos, dir);
		} else {
			players[num-1].pos = pos;
			players[num-1].dir = dir;
		}
		board[pos.y-1][pos.x-1] = true;
	}
	
	// removes player number num
	public void removePlayer(int num) {
		players[num-1].alive = false;
	}
	
	// set myPlayer
	public void setMyPlayer(int num) {
		myPlayer = num;
	}
	
	// uses reverse simulation to calculate minimal steps to win for all given positions
	// fields which can be reached first by opponent are ignored
	private int[] simReverse(int[][] stepsTo, int[][] stepsToOpp, Position p2, Position[] pos, Block[] blocks, int thresh) {
		int[] ret = new int[pos.length];
		for(int i=0; i<pos.length; i++) {
			ret[i] = 1000;
		}
		for(int i=0; i<height; i++) {
			for(int j=0; j<width; j++) {
				if(stepsTo[i][j] > 0 && stepsTo[i][j] < stepsToOpp[i][j]) {
					Position p1 = new Position(j+1, i+1);
					boolean lessSteps = false;
					for(int p=0; p<pos.length; p++) {
						if(stepsTo[i][j] < ret[p]) {
							lessSteps = true;
						}
					}
					boolean neighInv = false;
					for(Direction dir: Direction.all()) {
						if(!isValidPosition(p1.neighbor(dir)) || stepsTo[p1.neighbor(dir).y-1][p1.neighbor(dir).x-1] == -1) {
							neighInv = true;
						}
					}
					if(lessSteps && neighInv) {
						Position pret = simReverse(clone2D(stepsTo), p1, p1, p2, blocks, thresh);
						for(int p=0; p<pos.length; p++) {
							if(stepsTo[i][j] < ret[p] && pos[p].equals(pret)) {
								ret[p] = stepsTo[i][j];
							}
						}
					}
				}
			}
		}
		return ret;
	}
	
	// simulates game only for one player backwards from position p1end
	// changes stepsTo -> clone first
	private Position simReverse(int[][] stepsTo, Position p1, Position p1end, Position p2, Block[] blocks, int thresh) {
		int steps = stepsTo[p1.y-1][p1.x-1] - 1;
		stepsTo[p1.y-1][p1.x-1] = -1;
		if(steps <= 0) {
			int s1 = maxSteps(clone2D(stepsTo), p1end, blocks, thresh, 1);
			int s2 = maxSteps(clone2D(stepsTo), p2, blocks, thresh, 1);
			if(s1 > s2) {
				return p1;
			}
			return null;
		}
		for(Direction dir: Direction.all()) {
			Position p1new = p1.neighbor(dir);
			if(isValidPosition(p1new) && stepsTo[p1new.y-1][p1new.x-1] == steps) {
				Position ret = simReverse(clone2D(stepsTo), p1new, p1end, p2, blocks, thresh);
				if(ret != null) {
					return ret;
				}
			}
		}
		return null;
	}

	// returns simGame for every position pos of player p1
	// changes stepsTo -> clone first
	private int[] simGame(int[][] stepsTo, Position p1, Position p2, Position[] pos, Block[] blocks, int thresh) {
		stepsTo[p1.y-1][p1.x-1] = -1;
		stepsTo[p2.y-1][p2.x-1] = -1;
		int[] ret = new int[pos.length];
		for(int i=0; i<pos.length; i++) {
			Position p1new = pos[i];
			int tmp, ret2 = 1000;						// certain win
			for(Direction dir2: Direction.all()) {
				Position p2new = p2.neighbor(dir2);
				if(isValidPosition(p2new)) {
					if(stepsTo[p2new.y-1][p2new.x-1] > 0) {
						if (p1new.equals(p2new)) {
							tmp = -1;					// draw
						} else {
							tmp = simGame(clone2D(stepsTo), p1new, p1.getDirection(p1new), p2new, dir2, blocks, thresh, thresh-1);
						}
						ret2 = Math.min(ret2, tmp);
					}
				}
			}
			ret[i] = ret2;
		}
		return ret;
	}
	
	// simulates worst case scenario for player number p1
	// returns score after rek rounds
	// -2 -> num2 wins
	// -1 -> draw
	//  0 -> players still connected
	// >0 -> num1 wins
	private int simGame(int[][] stepsTo, Position p1, Direction d1, Position p2, Direction d2, Block[] blocks, int thresh, int rek) {
		stepsTo[p1.y-1][p1.x-1] = -1;
		stepsTo[p2.y-1][p2.x-1] = -1;
		if(takenAhead(stepsTo, p1, d1) || takenAhead(stepsTo, p2, d2)) {
			int s1 = maxSteps(clone2D(stepsTo), p1, blocks, thresh, 1);
			int s2 = maxSteps(clone2D(stepsTo), p2, blocks, thresh, 1);
			if(s1 > s2) {								// num1 wins
				return s1 - s2;
			} else if(s2 > s1) {						// num2 wins
				return -2;
			}
		}
		if(rek <= 0) {
			return 0;									// still connected
		}
		int ret1 = -2;									// certain lose (if num1 has no valid neighbors)
		for(Direction dir1: Direction.all()) {
			Position p1new = p1.neighbor(dir1);
			if(isValidPosition(p1new)) {
				if(stepsTo[p1new.y-1][p1new.x-1] > 0) {
					int tmp, ret2 = 1000;				// certain win (if num2 has no valid neighbors)
					for(Direction dir2: Direction.all()) {
						Position p2new = p2.neighbor(dir2);
						if(isValidPosition(p2new)) {
							if(stepsTo[p2new.y-1][p2new.x-1] > 0) {
								if (p1new.equals(p2new)) {
									tmp = -1;			// draw
								} else {
									tmp = simGame(clone2D(stepsTo), p1new, dir1, p2new, dir2, blocks, thresh, rek-1);
								}
								ret2 = Math.min(ret2, tmp);
							}
						}
					}
					ret1 = Math.max(ret1, ret2);
				}
			}
		}
		return ret1;
	}
	
	// returns maxSteps for all given positions
	private int[] maxSteps(int[][] stepsTo, Position pos[], Block[] blocks, int thresh, int rek) {
		int[] ret = new int[pos.length];
		for(int i=0; i<pos.length; i++) {
			ret[i] = maxSteps(clone2D(stepsTo), pos[i], blocks, thresh, rek);
		}
		return ret;
	}
	
	// calculate the maximal number of steps possible for a given position
	// approximately uses reachableFields after rek steps
	private int maxSteps(int[][] stepsTo, Position pos, Block[] blocks, int thresh, int rek) {
		if(rek <= 0) {
			int ret = reachableFields(clone2D(stepsTo), pos, blocks, thresh) - 1;
			return ret;
		}
		stepsTo[pos.y-1][pos.x-1] = -1;
		int tmp, ret = -1;

		for(Direction dir: Direction.all()) {
			Position p = pos.neighbor(dir);
			if(isValidPosition(p) && stepsTo[p.y-1][p.x-1] > 0) {
				tmp = maxSteps(clone2D(stepsTo), p, blocks, thresh, rek-1);
				if(tmp > ret) {
					ret = tmp;
				}
			}
		}
		return ret+1;
	}
	
	// calculates the number of steps possible from given position
	// changes stepsTo -> clone first
	private int reachableFields(int[][] stepsTo, Position pos, Block[] blocks, int thresh) {
		int ret = 0;
		if(stepsTo[pos.y-1][pos.x-1] > 0) {
			ret++;
		}
		if(stepsTo[pos.y-1][pos.x-1] == thresh) {
			stepsTo[pos.y-1][pos.x-1] = -1;
			for(int i=0; i<blocks.length; i++) {
				if(blocks[i].containsBorderPos(pos)) {
					ret += reachableFields(stepsTo, i, blocks, thresh);
				}
			}
		}
		stepsTo[pos.y-1][pos.x-1] = -1;
		for(Direction dir: Direction.all()) {
			Position p = pos.neighbor(dir);
			if(isValidPosition(p) && stepsTo[p.y-1][p.x-1] > 0) {
				ret += reachableFields(stepsTo, p, blocks, thresh);
			}
		}
		return ret;
	}
	
	// calculates the number of steps possible from block
	// changes stepsTo -> clone first
	private int reachableFields(int[][] stepsTo, int b, Block[] blocks, int thresh) {
		int ret = blocks[b].getSize();
		Block[] newBlocks = new Block[blocks.length-1];
		int i=0;
		for(int j=0; j<blocks.length; j++) {
			if(j != b) {
				newBlocks[i] = blocks[j];
				i++;
			}
		}
		for(Position p: blocks[b].getAllBorderPos()) {
			if(stepsTo[p.y-1][p.x-1] > 0) {
				ret += reachableFields(stepsTo, p, newBlocks, thresh);
			}
		}
		return ret;
	}
	
	// calculates all blocks
	// changes stepsTo -> clone first
	private Block[] calcBlocks(int[][] stepsTo, int thresh) {
		ArrayList<Block> blocksList = new ArrayList<Block>();
		for(int i=0; i<height; i++) {
			for(int j=0; j<width; j++) {
				if(stepsTo[i][j] > thresh) {
					blocksList.add(calcBlock(stepsTo, new Position(j+1,i+1), thresh));
				}
			}
		}
		return blocksList.toArray(new Block[0]);
	}
	
	// calculates Block for given stepsTo and position
	// changes stepsTo -> clone first
	private Block calcBlock(int[][] stepsTo, Position pos, int thresh) {
		Block block = new Block(width, height);
		if(stepsTo[pos.y-1][pos.x-1] <= thresh) {
			return block;
		}
		Position[] next = {pos};
		boolean[][] end = new boolean[height][width];
		while(next.length > 0) {
			for(Position p: next) {
				calcBlock(stepsTo, p, thresh, 1000, end, block);
			}
			ArrayList<Position> nextList = new ArrayList<Position>();
			for(int i=0; i<height; i++) {
				for(int j=0; j<width; j++) {
					if(end[i][j]) {
						nextList.add(new Position(j+1, i+1));
						end[i][j] = false;
					}
				}
			}
			next = nextList.toArray(new Position[0]);
		}
		block.calcBorderPosArr();
		return block;
	}

	// recursive function for calcBlock
	private void calcBlock(int[][] stepsTo, Position pos, int thresh, int rek, boolean[][] end, Block block) {
		if(stepsTo[pos.y-1][pos.x-1] == thresh) {
			block.addBorderPos(pos);
			for(Direction dir: Direction.all()) {
				Position p = pos.neighbor(dir);
				if(isValidPosition(p) && stepsTo[p.y-1][p.x-1] > thresh) {
					calcBlock(stepsTo, p, thresh, rek-1, end, block);
				}
			}
			return;
		}
		if(stepsTo[pos.y-1][pos.x-1] < thresh) {
			return;
		}
		if(rek <= 0) {
			end[pos.y-1][pos.x-1] = true;
			return;
		}
		stepsTo[pos.y-1][pos.x-1] = -2;
		block.addPos();
		for(Direction dir: Direction.all()) {
			Position p = pos.neighbor(dir);
			if(isValidPosition(p)) {
				calcBlock(stepsTo, p, thresh, rek-1, end, block);
			}
		}
	}
	
	// returns for every position how many steps are needed to get there for player number num
	// -1 -> not reachable
	private int[][] stepsTo(int num, int thresh) {
		int[][] stepsTo = new int[height][width];
		for(int i=0; i<height; i++) {
			for(int j=0; j<width; j++) {
				if(board[i][j]) {
					stepsTo[i][j] = -1;
				} else {
					stepsTo[i][j] = thresh+1;
				}
			}
		}
		for(Position p: getValidNeighbors(num)) {
			stepsTo(stepsTo, p, 1);
		}
		return stepsTo;
	}
	
	// recursive function for stepsTo
	private void stepsTo(int[][] stepsTo, Position pos, int curr) {
		stepsTo[pos.y-1][pos.x-1] = curr;
		for(Direction dir: Direction.all()) {
			Position p = pos.neighbor(dir);
			if(isValidPosition(p) && stepsTo[p.y-1][p.x-1] >= 0 && curr+1 < stepsTo[p.y-1][p.x-1]) {
				stepsTo(stepsTo, p, curr+1);
			}
		}
	}
	
	// returns true when one of the 3 positions in front of pos is taken
	private boolean takenAhead(int[][] stepsTo, Position pos, Direction d) {
		Position a = pos.neighbor(d);
		Position l = a.neighbor(d.left());
		Position r = a.neighbor(d.right());
		if(a.x < 1 || a.x > stepsTo[0].length || a.y < 1 || a.y > stepsTo.length || stepsTo[a.y-1][a.x-1] == -1) {
			return true;
		}
		if(l.x < 1 || l.x > stepsTo[0].length || l.y < 1 || l.y > stepsTo.length || stepsTo[l.y-1][l.x-1] == -1) {
			return true;
		}
		if(r.x < 1 || r.x > stepsTo[0].length || r.y < 1 || r.y > stepsTo.length || stepsTo[r.y-1][r.x-1] == -1) {
			return true;
		}
		return false;
	}
	
	
	// reduces position array to given values
	private Position[] reduce(Position[] pos, int[] arr, int val) {
		int i=0;
		Position[] tmp = new Position[pos.length];
		for(int p=0; p<pos.length; p++) {
			if(arr[p] == val) {
				tmp[i] = pos[p];
				i++;
			}
		}
		pos = new Position[i];
		for(int p=0; p<i; p++) {
			pos[p] = tmp[p];
		}
		return pos;
	}
	
	// clones a 2D int array
	private int[][] clone2D(int[][] original) {
		int[][] ret = new int[original.length][];
		for(int i=0; i<original.length; i++) {
		    ret[i] = original[i].clone();
		}
		return ret;
	}
	
	// get numbers of living opponent players
	private int[] getLivingOpponents() {
		int[] tmp = new int[players.length-1];
		int i=0;
		for(int p=1; p<=players.length; p++) {
			if(p != myPlayer && players[p-1].alive) {
				tmp[i] = p;
				i++;
			}
		}
		int[] ret = new int[i];
		for(int j=0; j<i; j++) {
			ret[j] = tmp[j];
		}
		return ret;
	}
	
	// returns all Positions
	private Position[] getAllPositions() {
		Position[] retArr = new Position[width*height];
		for(int i=0; i < height; i++) {
			for(int j=0; j < width; j++) {
				retArr[i*width+j] = new Position(j+1, i+1);
			}
		}
		return retArr;
	}
	
	// get valid neighbors of player number num
	private Position[] getValidNeighbors(int num) {
		Position[] tmp = new Position[4];
		int i = 0;
		for(Direction dir: Direction.all()) {
			if(players[num-1].dir.opposite() != dir && isValidPosition(players[num-1].pos.neighbor(dir)) && !isTaken(players[num-1].pos.neighbor(dir))) {
				tmp[i] = players[num-1].pos.neighbor(dir);
				i++;
			}
		}
		Position[] ret = new Position[i];
		for(int j=0; j<i; j++) {
			ret[j] = tmp[j];
		}
		return ret;
	}
	
	// returns true if pos is valid
	public boolean isValidPosition(Position pos) {
		if(pos.x < 1 || pos.x > width || pos.y < 1 || pos.y > height) {
			return false;
		}
		return true;
	}
	
	// returns true if pos is taken
	public boolean isTaken(Position pos) {
		return board[pos.y-1][pos.x-1];
	}
}

