package tron;
/**
    (C) Copyright 2014 Philipp Staudinger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// represents the coordinates of one position
public class Position {

	public int x, y;

	public Position(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
	
	// returns the neighbor to the field by given direction
	public Position neighbor(Direction dir) {
		Position pos = new Position(x,y);
		switch(dir) {
			case NORTH: 	pos.y--;
							break;
			case SOUTH: 	pos.y++;
							break;
			case WEST: 		pos.x--;
							break;
			case EAST: 		pos.x++;
							break;
		}
		return pos;
	}

	public Direction getDirection(Position pos) {
		if(neighbor(Direction.NORTH).equals(pos)) {
			return Direction.NORTH;
		}
		if(neighbor(Direction.SOUTH).equals(pos)) {
			return Direction.SOUTH;
		}
		if(neighbor(Direction.WEST).equals(pos)) {
			return Direction.WEST;
		}
		if(neighbor(Direction.EAST).equals(pos)) {
			return Direction.EAST;
		}
		return null;
	}
	
	public int distance(Position pos) {
		return Math.abs(x-pos.x) + Math.abs(y-pos.y) + Math.abs(Math.abs(x-pos.x) - Math.abs(y-pos.y));
	}
	
	public boolean equals(Position pos) {
		if(pos == null) {
			return false;
		}
		return x == pos.x && y == pos.y;
	}

	@Override
	public String toString() {
		return x + "," + y;
	}
}
