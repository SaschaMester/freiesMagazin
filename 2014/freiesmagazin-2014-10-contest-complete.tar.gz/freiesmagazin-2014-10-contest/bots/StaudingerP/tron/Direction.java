package tron;
/**
    (C) Copyright 2014 Philipp Staudinger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// represents the 4 directions
public enum Direction {
	NORTH, SOUTH, WEST, EAST;
	
	// return all directions
	public static Direction[] all() {
		Direction[] ret = {NORTH, SOUTH, WEST, EAST};
		return ret;
	}
	
	public Direction opposite() {
		switch(this) {
			case NORTH: 	return SOUTH;
			case SOUTH:     return NORTH;
			case WEST:      return EAST;
			case EAST:      return WEST;
		}
		return null;
	}
	
	public Direction left() {
		switch(this) {
			case NORTH: 	return WEST;
			case SOUTH: 	return EAST;
			case WEST: 		return SOUTH;
			case EAST: 		return NORTH;
		}
		return null;
	}
	
	public Direction right() {
		switch(this) {
			case NORTH: 	return EAST;
			case SOUTH: 	return WEST;
			case WEST: 		return NORTH;
			case EAST: 		return SOUTH;
		}
		return null;
	}
}
