package tron;
/**
    (C) Copyright 2014 Philipp Staudinger

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

import java.io.*;
import java.util.regex.*;

public class MyBot {
	private Game game;
	int round;
	
	public static void main(String[] args) {
		MyBot myBot = new MyBot();
		
		try {
			myBot.start();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void start() throws IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		String in = input.readLine();
		
		while(!in.equals("END")) {	// until END
			
			// GAMEBOARDSTART -> initialize game 
			if(in.startsWith("GAMEBOARDSTART")) {
				int[] dim = parseInt(in, 2);
				in = input.readLine();
				for(int i=0; i < dim[1]-1; i++) {
					in += input.readLine();
				}
				game = new Game(dim[0], dim[1], in);
			
			// SET -> set number of my player
			} else if(in.startsWith("SET")) {
				game.setMyPlayer(parseInt(in, 1)[0]);
				
			// POS -> set new player positions
			} else if(in.startsWith("POS")) {
				int[] pos = parseInt(in, 3);
				Direction dir = null;
				if(in.endsWith("N")) {
					dir = Direction.NORTH;
				} else if(in.endsWith("S")) {
					dir = Direction.SOUTH;
				} else if(in.endsWith("W")) {
					dir = Direction.WEST;
				} else if(in.endsWith("E")) {
					dir = Direction.EAST;
				}
				game.setPlayerPosition(pos[0], new Position(pos[1],pos[2]), dir);
			
			// ROUND -> make move by calling strategy
			} else if(in.startsWith("ROUND")) {
				round = parseInt(in, 1)[0];
				System.out.println(game.move());
				
			
			// OUT -> remove player
			} else if(in.startsWith("OUT")) {
				game.removePlayer(parseInt(in, 1)[0]);
			}
			
			in = input.readLine();
		}
		
		input.close();
	}
	
	// returns nmb integers out of str
	private int[] parseInt(String str, int nmb) {
		Matcher m = Pattern.compile("[0-9]+").matcher(str);
		int out[] = new int[nmb];
		int i=0;

		while(m.find() && i < nmb) {
			out[i] = Integer.parseInt(str.substring(m.start(), m.end()));
			i++;
		}
		
		return out;
	}
}
