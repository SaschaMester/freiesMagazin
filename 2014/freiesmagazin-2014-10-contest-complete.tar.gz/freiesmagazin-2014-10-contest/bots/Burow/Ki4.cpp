/**
    (C) Copyright 2014 Falk Burow

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/



int Ki4_SucheRichtung(){
    // Berechnungen starten
    #ifdef Threads
        // Threads starten
        pthread_create(&Ki2_Thread_pp , NULL, Ki2_Thread , NULL);
        pthread_create(&Ki3_Thread_pp , NULL, Ki3_Thread , NULL);

        // Warte auf das Ende der Threads
        pthread_join  (Ki2_Thread_pp , NULL);
        pthread_join  (Ki3_Thread_pp , NULL);
    #else
        Ki2_Thread(NULL);
        Ki3_Thread(NULL);
    #endif

    // Punkte auswerten
    const Pointer Pos1      = Spieler[SpielerID ].Pos;
    const int     Richtung1 = Spieler[SpielerID ].Richtung;
    float Punkte_Links  = Ki2_Punkte_Links  + Ki3_Punkte_Links  + Ki_ZusatzPunkte(Pos1, Richtung1_Links , Links );
    float Punkte_Gerade = Ki2_Punkte_Gerade + Ki3_Punkte_Gerade + Ki_ZusatzPunkte(Pos1, Richtung1_Gerade, Gerade);
    float Punkte_Rechts = Ki2_Punkte_Rechts + Ki3_Punkte_Rechts + Ki_ZusatzPunkte(Pos1, Richtung1_Rechts, Rechts);

    // geht den Weg mit der bersten Punktzahl
    float Punkte   = Punkte_Gerade;
    int   Richtung = Gerade;

    if (Punkte_Links >Punkte){ Punkte = Punkte_Links ; Richtung = Links ; }
    if (Punkte_Rechts>Punkte){ Punkte = Punkte_Rechts; Richtung = Rechts; }

    // Log & Ausgabe
    #ifdef LOG
        Log( "Ki4: " + IntToStr(round(Punkte)) + " (" + IntToStr(round(Punkte_Links)) + "," + IntToStr(round(Punkte_Gerade)) + "," + IntToStr(round(Punkte_Rechts)) + ")   Dauer: " + DoubleToStr(round((Time()-StartTime)*1000)/1000) + " sek." );
    #endif
    return Richtung;
}

// *******************  Ki4  ******************************************************
int Ki4(){

    // teste ob nur 1 Weg frei ist
    int Richtung = Ki_Test_1_Weg();
    if (Richtung!=Nix){
        Ki2_Grenze /= 1.02;
        Ki3_Grenze /= 1.02;
        return Richtung;
    }

    // suche Richtung
    return Ki4_SucheRichtung();
}

