/**
    (C) Copyright 2014 Falk Burow

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// *******************  Variablen ******************************************************
bool         Ki5_First_init    = false;
int volatile Ki5_MaxTiefe      = 1;
float        Ki5_Grenze        = 3;
double       Ki5_Dauer         = 0;
Pointer      Ki5_Mem           = NULL;
int64        Ki5_Mem_Diff      = 0;
int          Ki5_Durchlaeufe   = 0;

#define Ki5Dauer {double temp=time;time=Time();temp=time-temp;MAX(Ki5_Dauer,temp);}

void Ki5_First_init_Berechnungsgrenzen(){
        // Berechnungsgrenzen anhand der freien Felder festlegen
        const int Anz = ZaehleFreieFelder(Ki5_Mem, Spieler[SpielerID].Pos + Ki5_Mem_Diff);
        if (Anz<100)  Ki5_Grenze = 10; else
        if (Anz<1000) Ki5_Grenze = 10; else
        if (Anz<3000) Ki5_Grenze = 3; else
                      Ki5_Grenze = 1;
    }

void Ki5_init_Berechnungsgrenzen(){
    if (!Ki5_First_init){
        Ki5_First_init = true;
        Ki5_First_init_Berechnungsgrenzen();
    }
    // Berechnungsgrenzen anpassen
    if (Ki5_Grenze<1.0  ) Ki5_Grenze = 1.0;
    if (Ki5_Grenze>100.0) Ki5_Grenze = 100.0;


    Ki5_MaxTiefe = round(Ki5_Grenze);
    if (Ki5_MaxTiefe>=FreieFelder)Ki5_MaxTiefe=FreieFelder-1;

    #ifdef LOG
        Log("Ki5_Grenzen: "+FloatToStr(round(Ki5_Grenze*10)/10)+"  /   MaxTiefe: "+IntToStr(Ki5_MaxTiefe) );
    #endif
}

// Berechnungsgrenzen anhand der Berechnungsdauer dynamisch anpassen
void Ki5_Berechnungsgrenzen_anpassen(const double Punkte){
    // Berechnungsgrenzen anhand der Berechnungsdauer dynamisch anpassen
    Ki5_Dauer = Ki5_Dauer * 3.0 / MaxRechenZeit;
    if (Abbruch)Ki5_Dauer += 100;
    // if (Ki5_Dauer<0.01 ) Ki5_Grenze++;
    if (Ki5_Dauer<0.3 ) Ki5_Grenze++;
    if (Ki5_Dauer>0.7 ) Ki5_Grenze--;
    if (Ki5_Dauer>5.0 ) Ki5_Grenze--;

    if (Ki5_Grenze<1.0  ) Ki5_Grenze = 1.0;
    if (Ki5_Grenze>100.0) Ki5_Grenze = 100.0;

}




