/**
    (C) Copyright 2014 Falk Burow

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// *******************  Ki0 - Analyse   ******************************************************
float Ki0_Analyse(const Pointer Pos1, const int Richtung1){
    // �berpr�fen, ob die Spieler in die Richtungen gehen k�nnen
    const Pointer NewPos1 = Pos1 + PosAenderung[Richtung1];
    if (*NewPos1!=0)return -999999;

    // Punkte berechnen
    float Punkte = ZaehleFreieFelder(Mem, NewPos1);

    Pointer PosG = NewPos1 + PosAenderung[Richtung1_Gerade];
    Pointer PosL = NewPos1 + PosAenderung[Richtung1_Links ];
    Pointer PosR = NewPos1 + PosAenderung[Richtung1_Rechts];

    if (Richtung1==Gerade)Punkte += 0.09;
    if (*PosG!=0 || *PosL!=0 || *PosR!=0)Punkte += 0.1;
    // test auf Kollision
    for (int i = 1; i<=MaxSpieler; i++)
        if (SpielerID!=i            // selber nicht mitz�hlen
            && Spieler[i].Pos!=0)   // nur aktive spieler
            if (PosG==Spieler[i].Pos || PosL==Spieler[i].Pos || PosR==Spieler[i].Pos)Punkte -= 0.6;

    return Punkte;
}

// *******************  Ki0   ******************************************************
int Ki0(){
    int Richtung;

    // teste ob nur 1 Weg frei ist
    Richtung = Ki_Test_1_Weg();
    if (Richtung!=Nix)return Richtung;

    // berechne
    const Pointer Pos1 = Spieler[SpielerID].Pos;
    const int Richtung1 = Spieler[SpielerID].Richtung;

    const float P_Gerade = Ki0_Analyse(Pos1, Richtung1_Gerade) + ZufallsWert;
    const float P_Links  = Ki0_Analyse(Pos1, Richtung1_Links ) + ZufallsWert;
    const float P_Rechts = Ki0_Analyse(Pos1, Richtung1_Rechts) + ZufallsWert;

    // Punkte auswerten
    // geht den Weg mit der h�chsten Punktzahl
    float Punkte   = P_Gerade;
          Richtung = Gerade;
    if (P_Links >Punkte){Punkte=P_Links ;Richtung=Links ;}
    if (P_Rechts>Punkte){Punkte=P_Rechts;Richtung=Rechts;}


    // Ausgabe
    Log("Ki0: "+IntToStr(round(Punkte))+" ("+IntToStr(round(P_Links))+","+IntToStr(round(P_Gerade))+","+IntToStr(round(P_Rechts))+")");
    return Richtung;
}
//}

