/**
    (C) Copyright 2014 Falk Burow

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/



// Hier wird �berwacht, dass die Berechnung nicht zu lange dauert.
// Sollte das Zeitlimit von 1 Sek. erreicht werden, werden die Grenzen
// runter gesetzt und dadurch die Berechnung automatisch beendet.


// Variablen
volatile int Ueberwachung_Counter = 0;

// Abbruch bei zu langer Berechnung
void* Ueberwachung_Thread(void* d){
    int ID = Ueberwachung_Counter;
    double Ende;

    while (ID == Ueberwachung_Counter){
        Ende = Time() + AbbruchZeit;
        while (Time() < Ende  &&  ID == Ueberwachung_Counter )usleep(10000);

        if (ID != Ueberwachung_Counter)return 0;
        Stop(Ki1_Grenze1);
        Stop(Ki1_Grenze1_intervall);
        Stop(Ki1_Grenze2);
        Stop(Ki1_Grenze2_intervall);
        Stop(Ki1_Grenze3);
        Stop(Ki1_Grenze4);

        Stop(Ki2_Grenze1);
        Stop(Ki2_Grenze1_intervall);
        Stop(Ki2_Grenze2);
        Stop(Ki2_Grenze2_intervall);
        Stop(Ki2_Grenze3);
        Stop(Ki2_Grenze4);

        Stop(Ki3_MaxTiefe);
        Stop(Ki5_MaxTiefe);

        Abbruch=true;
        #ifdef LOG
            Log("Abbruch");
        #endif
    }
    return 0;
}

// �berwachung starten
void Ueberwachung_Start(){
    Ueberwachung_Counter++;
    Abbruch = false;
    #ifdef Threads
        pthread_t Ueberwachung_Thread_pp;
        pthread_create(&Ueberwachung_Thread_pp , NULL, Ueberwachung_Thread , NULL);
        pthread_detach(Ueberwachung_Thread_pp);
    #endif
}

// �berwachung beenden
void Ueberwachung_Ende(){
    Ueberwachung_Counter++;
}

