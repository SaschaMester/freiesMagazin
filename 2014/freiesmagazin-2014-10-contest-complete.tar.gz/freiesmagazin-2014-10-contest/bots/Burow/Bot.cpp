/**
    (C) Copyright 2014 Falk Burow

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

class TBot{
    private:
        double  Zeit;
        double  SpielStart;
        int     Runde;
        char    _INPUT[101];
        void Befehl_ROUND(string Text);
        void Befehl_SET(string Text);
        void Befehl_POS(string Text);
        void Befehl_OUT(string Text);
        void Befehl_END();
        void Befehl_GAMEBOARDSTART(string Text);
        void SetFeld(const int x, const int y, const Byte id);
        Byte GetFeld(const int x, const int y);
        void LogSpielFeld();
        void SpeedTest();
    public:
        void Go();
        TBot();
        ~TBot();
};

// *******************  Konstruktor  *******************
TBot::TBot(){
    SpielStart = Time();
    Zeit = 0;
}

// *******************  Destruktor  *******************
TBot::~TBot(){
    if (Mem     != NULL) free(Mem);
}

// *******************  Spielsteuerung ( Go ) *******************
void TBot::Go(){
    string Befehl = "";

    while(Befehl != "END"){
        // Warte Auf Eingabe
        cin.getline(_INPUT,100);_INPUT[100]='\0';
        string Text=_INPUT; Text=Text+" ";

        #ifdef LOG
            if (Text == "ROUND 1 ")Log("________________________________________________________________________");
            Log("> " + Text); // LOG
        #endif

        // Teste Eingabe
        if (Text.length()<3 || Text.length()>90)Text="END ";

        // Eingabe aufteilen in Befehl und Text
        int p=Text.find(' ');
        Befehl=Text.substr(0,p);
        Text=Text.substr(p+1,Text.length()-p-1);

        // Befehle
        if (Befehl=="GAMEBOARDSTART") Befehl_GAMEBOARDSTART(Text);
        if (Befehl=="ROUND")          Befehl_ROUND(Text);
        if (Befehl=="SET")            Befehl_SET(Text);
        if (Befehl=="POS")            Befehl_POS(Text);
        if (Befehl=="OUT")            Befehl_OUT(Text);
        if (Befehl=="END")            Befehl_END();
    }
}

// *******************  Befehl: ROUND  *******************
void TBot::Befehl_ROUND(string Text){
    // Vorbereitung
    Runde = StrToInt(Text);
    StartTime = Time();
    Ueberwachung_Counter++;
    #ifdef LOG
        // Log SpielFeld
        if (Width*Height<=100*100)LogSpielFeld();
    #endif


    // Strategy starten
    int richtung = Strategy();


    // Ausgabe der Richtung
    string Richtung;
    switch(richtung){
         case Links : Richtung = "LEFT"; break;
         case Gerade: Richtung = "AHEAD";break;
         case Rechts: Richtung = "RIGHT";break;
         default    : Richtung = "AHEAD";
     }
    cout << Richtung << endl;


    // Log
    #ifdef LOG
        // Log Richtung
        Log("< Richtung: " + Richtung);
        // Zeitmessung
        double dauer = Time()-StartTime;
        Zeit+=dauer;
        Log("Dauer: " + DoubleToStr(round(dauer*1000)/1000) + " sek." );
        if (dauer>MaxRechenZeit*1.05) for (int i=0;i<dauer;i++)Log("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        Log("________________________________________________________________________");
    #endif
}

// *******************  Set- / Get-Feld  *******************
void TBot::SetFeld(const int x, const int y, const Byte id){*GET_Pos(x,y)=id;}
Byte TBot::GetFeld(const int x, const int y){return *GET_Pos(x,y);}

// *******************  Befehl: SET  *******************
void TBot::Befehl_SET(string Text){
    SpielerID = StrToInt(Text);
}

// *******************  Befehl: POS  *******************
void TBot::Befehl_POS(string Text){
    // POS 1 8,5 E
    // POS 2 23,6 W

    // ermittel Werte
            int p=Text.find(' ');
    int id= StrToInt(Text.substr(0,p));
            Text=Text.substr(p+1,Text.length()-p-1);
            p=Text.find(',');
    int x = StrToInt(Text.substr(0,p));
            Text=Text.substr(p+1,Text.length()-p-1);
            p=Text.find(' ');
    int y = StrToInt(Text.substr(0,p));
    string R = Text.substr(p+1,1);

    int Richtung = 0;
        if (R=="N")Richtung=0; else
        if (R=="E")Richtung=1; else
        if (R=="S")Richtung=2; else
        if (R=="W")Richtung=3;

    // Werte speichern
    Spieler[id].Pos=GET_Pos(x,y);
    Spieler[id].Richtung=Richtung;
    Spieler[id].X=x;
    Spieler[id].Y=y;
    MAX(MaxSpieler,id);

    // Position auf Spielfeld setzen
    if (id<=250)SetFeld(x,y,id);else SetFeld(x,y,250);


    Ueberwachung_Counter++;
}

// *******************  Befehl: OUT  *******************
void TBot::Befehl_OUT(string Text){
    int ID = StrToInt(Text);

    #ifdef LOG
        LogSpielFeld();
    #endif

    Spieler[ID].Richtung = Nix;
    Spieler[ID].Pos      = 0;

    if (ID==SpielerID){
        #ifdef LOG
            // Zeitmessung
            double Dauer = Time()-SpielStart;
            Log("Dauer: " + DoubleToStr(round(Zeit*10)/10) + " / " + DoubleToStr(round(Dauer*10)/10) + " sek.");
        #endif
    }
}

// *******************  Befehl: END  *******************
void TBot::Befehl_END(){
    #ifdef LOG
        Log("Ende");
    #endif
}

// *******************  Befehl: GAMEBOARDSTART  *******************
void TBot::Befehl_GAMEBOARDSTART(string Text){
    // parameter ermitteln
    int p  = Text.find(',');
    Width  = StrToInt(Text.substr(0,p));
    Height = StrToInt(Text.substr(p+1,Text.length()-p-1));
    SpielFeldGroesse = Width*Height;

    // Speicher(Mem) vom Spielfeld vorbereiten
    ZeilenLaenge = Width+1;
    NegZeilenLaenge = 0-ZeilenLaenge;
    MemLaenge    = ZeilenLaenge*(Height+2)+1;       // Speicherplatzgr��e vom Spielfeld berechnen
    MemLaenge    = (MemLaenge+7) & -8;              // Speicherplatzgr��e auf 64Bit erweitern
    Mem          = (Pointer)malloc(MemLaenge*10);   // Speicher f�r Spielfeld reservieren + Speicherplatz f�r die Spielfeld Kopien der Ki's
    for (int64 i=0; i<MemLaenge; i++) *(Mem + i)=251;

    // Daten laden
    char INPUTDaten[Width+10];
    for (int b=1;b<=Height;b++){
        cin.getline(INPUTDaten,Width+10);
        for (int a=1;a<=Width;a++){
            if (INPUTDaten[a-1]=='.')SetFeld(a,b,0);
        }
    }

    Ki_init();
    #ifdef LOG
        LogSpielFeld();
    #endif
}

// *******************  Log SpielFeld  *******************
void TBot::LogSpielFeld(){
    #ifdef LOG
        string s;
        for (int y=0;y<=Height+1;y++){
            Pointer Pos = GET_Pos(0,y);
            s = "";
            for (int x=0;x<=Width+1;x++){
                Byte z = *Pos;
                string            ss = "+";
                if (z==0)         ss = " ";
                if (z==SpielerID) ss = "*";
                if (z==251)       ss = "#";
                for (int i=1;i<=9;i++)if (Spieler[i].Richtung>=0 && Spieler[i].Pos==Pos) ss=char(48+i);
                s += ss;
                Pos++;
            }
            Log(s);
        }
    #endif
}

