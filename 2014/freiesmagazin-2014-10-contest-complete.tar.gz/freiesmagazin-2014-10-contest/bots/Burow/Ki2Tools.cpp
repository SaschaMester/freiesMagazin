/**
    (C) Copyright 2014 Falk Burow

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/


// *** Variablen ***
bool            Ki2_First_init      = false;
double          Ki2_Dauer           = 0;
Pointer         Ki2_Mem             = NULL;
int64           Ki2_Mem_Diff        = 0;
double          Ki2_Grenze          = 4;
int             Ki2_MaximalPunkte   =  2;
int             Ki2_MinimalPunkte   = -2;
int volatile    Ki2_Grenze1;
int volatile    Ki2_Grenze1_intervall;
int volatile    Ki2_Grenze2;
int volatile    Ki2_Grenze2_intervall;
int volatile    Ki2_Grenze3;
int volatile    Ki2_Grenze4;
int             Ki2_Durchlaeufe     = 0;

#define Ki2Dauer {double temp=time;time=Time();temp=time-temp;MAX(Ki2_Dauer,temp);}


void Ki2_First_init_Berechnungsgrenzen(){
        // Berechnungsgrenzen anhand der freien Felder festlegen
        const int Anz = ZaehleFreieFelder(Ki2_Mem, Spieler[SpielerID].Pos + Ki2_Mem_Diff);
        if (Anz <=  10 *  10) Ki2_Grenze =  40;else
        if (Anz <=  20 *  20) Ki2_Grenze =  30;else
        if (Anz <=  30 *  30) Ki2_Grenze =  20;else
        if (Anz <=  50 *  50) Ki2_Grenze =  10;else
        if (Anz <=  70 *  70) Ki2_Grenze =   3;else
                              Ki2_Grenze =   1;
    }

void Ki2_init_Berechnungsgrenzen(){
    if (!Ki2_First_init){
        Ki2_First_init = true;
        Ki2_First_init_Berechnungsgrenzen();
    }
    // Berechnungsgrenzen anpassen
    if (Ki2_Grenze<0.3      ) Ki2_Grenze = 0.3;
    if (Ki2_Grenze>1000000) Ki2_Grenze = 1000000;

    Ki2_Grenze1           = round(Ki2_Grenze/50)+1;
    Ki2_Grenze1_intervall = round(Ki2_Grenze/10)+1;
    Ki2_Grenze2           = round(Ki2_Grenze/20);
    Ki2_Grenze2_intervall = round(Ki2_Grenze);
    Ki2_Grenze3           = round(Ki2_Grenze/25);
    Ki2_Grenze4           = round(Ki2_Grenze*10);


    #ifdef LOG
        Log("Ki2_Grenzen: "+FloatToStr(round(Ki2_Grenze*10)/10)+"  /   1: "+IntToStr(Ki2_Grenze1)+" ("+IntToStr(Ki2_Grenze1_intervall)+")   /   2: "+IntToStr(Ki2_Grenze2)+" ("+IntToStr(Ki2_Grenze2_intervall)+")   /   3: "+IntToStr(Ki2_Grenze3)+"   /   4: "+IntToStr(Ki2_Grenze4)+"   /   Min-Max: "+IntToStr(Ki2_MinimalPunkte)+" / "+IntToStr(Ki2_MaximalPunkte));
    #endif
}

// Berechnungsgrenzen anhand der Berechnungsdauer dynamisch anpassen
void Ki2_Berechnungsgrenzen_anpassen(int Punkte){
    if (!Abbruch){
        // Ki2_MaximalPunkte berechnen
        if (Punkte+2>Ki2_MaximalPunkte){Ki2_MaximalPunkte = Punkte+2;}else{Ki2_MaximalPunkte = 2; MAX(Ki2_MaximalPunkte,Punkte+2);}
        // Ki2_MinimalPunkte berechnen
        if (Punkte-2<Ki2_MinimalPunkte){Ki2_MinimalPunkte = Punkte-2;}else{Ki2_MinimalPunkte =-2; MIN(Ki2_MinimalPunkte,Punkte-2);}
    }

    Ki2_Dauer = Ki2_Dauer * 9.0 / MaxRechenZeit;
    if (Abbruch)Ki2_Dauer += 100;

    if (Ki2_Dauer<0.01)Ki2_Grenze = Ki2_Grenze * 1.05 + 1;
    if (Ki2_Dauer<0.1) Ki2_Grenze = Ki2_Grenze * 1.05;
    if (Ki2_Dauer<0.3) Ki2_Grenze = Ki2_Grenze * 1.05;
    if (Ki2_Dauer<0.5) Ki2_Grenze = Ki2_Grenze * 1.05;
    if (Ki2_Dauer<0.7) Ki2_Grenze = Ki2_Grenze * 1.05;
    if (Ki2_Dauer>0.9) Ki2_Grenze = Ki2_Grenze / 1.05;
    if (Ki2_Dauer>1.1) Ki2_Grenze = Ki2_Grenze / 1.05;
    if (Ki2_Dauer>2.1) Ki2_Grenze = Ki2_Grenze / 1.05;
    if (Ki2_Dauer>5.0) Ki2_Grenze = Ki2_Grenze / 1.05 - 1;

    if (Ki2_Grenze<0.3      ) Ki2_Grenze = 0.3;
    if (Ki2_Grenze>1000000) Ki2_Grenze = 1000000;

}
