/**
    (C) Copyright 2014 Falk Burow

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// *******************  Ki1 - Variablen  ******************************************************
bool         Ki1_First_init  = false;
double       Ki1_Dauer       = 0;
double       Ki1_Grenze      = 12;
int volatile Ki1_Grenze1     = 12;
int volatile Ki1_Grenze2     =  5;
int volatile Ki1_Grenze3     =  5;
int volatile Ki1_Grenze4     = 50;
int volatile Ki1_Grenze1_intervall;
int volatile Ki1_Grenze2_intervall;
Pointer      Ki1_Mem         = NULL;
int64        Ki1_Mem_Diff    = 0;
int          Ki1_Durchlaeufe = 0;

#define Ki1Dauer {double temp=time;time=Time();temp=time-temp;MAX(Ki1_Dauer,temp);}

void Ki1_First_init_Berechnungsgrenzen(){
        // Berechnungsgrenzen anhand der freien Felder festlegen
        const int Anz = ZaehleFreieFelder(Ki1_Mem, Spieler[SpielerID].Pos + Ki1_Mem_Diff);
        if (Anz <=  500)  Ki1_Grenze = 50;  else
        if (Anz <= 1000)  Ki1_Grenze = 50;  else
        if (Anz <= 2000)  Ki1_Grenze = 10;  else
        if (Anz <= 4000)  Ki1_Grenze = 5;  else
        if (Anz <= 8000)  Ki1_Grenze = 2;  else
                          Ki1_Grenze = 1;
    }

void Ki1_init_Berechnungsgrenzen(){
    if (!Ki1_First_init){
        Ki1_First_init = true;
        Ki1_First_init_Berechnungsgrenzen();
    }

    // Berechnungsgrenzen anpassen
    if (Ki1_Grenze<0.3    ) Ki1_Grenze = 0.3;
    if (Ki1_Grenze>1000000) Ki1_Grenze = 1000000;

    Ki1_Grenze1           = round(Ki1_Grenze/50.0)+1;
    Ki1_Grenze1_intervall = round(Ki1_Grenze/10.0)+1;
    Ki1_Grenze2           = round(Ki1_Grenze/20.0);
    Ki1_Grenze2_intervall = round(Ki1_Grenze);
    Ki1_Grenze3           = round(Ki1_Grenze/25.0);
    Ki1_Grenze4           = round(Ki1_Grenze*10.0);


    #ifdef LOG
        Log("Ki1_Grenzen: "+FloatToStr(round(Ki1_Grenze*10)/10)+"  /   1: "+IntToStr(Ki1_Grenze1)+" ("+IntToStr(Ki1_Grenze1_intervall)+")   /   2: "+IntToStr(Ki1_Grenze2)+" ("+IntToStr(Ki1_Grenze2_intervall)+")   /   3: "+IntToStr(Ki1_Grenze3)+"   /   4: "+IntToStr(Ki1_Grenze4));
    #endif
}

// Berechnungsgrenzen anhand der Berechnungsdauer dynamisch anpassen
void Ki1_Berechnungsgrenzen_anpassen(){
    Ki1_Dauer = Ki1_Dauer * 3.0 / MaxRechenZeit;
    if (Abbruch)Ki1_Dauer += 100;

    if (Ki1_Dauer<0.01)Ki1_Grenze = Ki1_Grenze * 1.05 + 1;
    if (Ki1_Dauer<0.1) Ki1_Grenze = Ki1_Grenze * 1.05;
    if (Ki1_Dauer<0.3) Ki1_Grenze = Ki1_Grenze * 1.05;
    if (Ki1_Dauer<0.5) Ki1_Grenze = Ki1_Grenze * 1.05;
    if (Ki1_Dauer>0.7) Ki1_Grenze = Ki1_Grenze / 1.05;
    if (Ki1_Dauer>0.9) Ki1_Grenze = Ki1_Grenze / 1.05;
    if (Ki1_Dauer>1.1) Ki1_Grenze = Ki1_Grenze / 1.05;
    if (Ki1_Dauer>2.1) Ki1_Grenze = Ki1_Grenze / 1.05;
    if (Ki1_Dauer>5.0) Ki1_Grenze = Ki1_Grenze / 1.05 - 1;

    if (Ki1_Grenze<0.3    ) Ki1_Grenze = 0.3;
    if (Ki1_Grenze>1000000) Ki1_Grenze = 1000000;

}
