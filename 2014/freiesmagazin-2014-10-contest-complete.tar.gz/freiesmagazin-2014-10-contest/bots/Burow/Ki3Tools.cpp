/**
    (C) Copyright 2014 Falk Burow

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// *******************  Variablen ******************************************************
bool            Ki3_First_init    = false;
int volatile    Ki3_MaxTiefe      = 1;
double          Ki3_Dauer         = 0;
Pointer         Ki3_Mem           = NULL;
int64           Ki3_Mem_Diff      = 0;
int             Ki3_Durchlaeufe   = 0;
double          Ki3_Grenze        = 3;

#define Ki3Dauer {double temp=time;time=Time();temp=time-temp;MAX(Ki3_Dauer,temp);}

void Ki3_First_init_Berechnungsgrenzen(){
        // Berechnungsgrenzen anhand der freien Felder festlegen
        const int Anz = ZaehleFreieFelder(Ki3_Mem, Spieler[SpielerID].Pos + Ki3_Mem_Diff);
        if (Anz<1000) Ki3_Grenze = 5; else
        if (Anz<3000) Ki3_Grenze = 3; else
                      Ki3_Grenze = 1;
    }

void Ki3_init_Berechnungsgrenzen(){
    if (!Ki3_First_init){
        Ki3_First_init = true;
        Ki3_First_init_Berechnungsgrenzen();
    }
    // Berechnungsgrenzen anpassen
    if (Ki3_Grenze<1.0 ) Ki3_Grenze = 1.0;
    if (Ki3_Grenze>30.0) Ki3_Grenze = 30.0;

    Ki3_MaxTiefe = round(Ki3_Grenze);
    if (Ki3_MaxTiefe>=FreieFelder)Ki3_MaxTiefe=FreieFelder-1;

    #ifdef LOG
        Log("Ki3_Grenzen: "+IntToStr(Ki3_MaxTiefe));
    #endif

}

// Berechnungsgrenzen anhand der Berechnungsdauer dynamisch anpassen
void Ki3_Berechnungsgrenzen_anpassen(const double Punkte){
    // Berechnungsgrenzen anhand der Berechnungsdauer dynamisch anpassen
    Ki3_Dauer = Ki3_Dauer * 9.0 / MaxRechenZeit;
    if (Abbruch)Ki3_Dauer += 100;
    if (Ki3_Dauer<0.5 ) Ki3_Grenze++;
    if (Ki3_Dauer>0.7 ) Ki3_Grenze--;
    //if (Ki3_Dauer>5.0 ) Ki3_Grenze--;


    if (Ki3_Grenze<1.0 ) Ki3_Grenze = 1.0;
    if (Ki3_Grenze>30.0) Ki3_Grenze = 30.0;

}



