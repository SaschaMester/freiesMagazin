/**
    (C) Copyright 2014 Falk Burow

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/
    #if _WIN64
        // Win64
        #define x64
    #elif _WIN32
        // Win32
        #define x32
    #elif __x86_64__
        // Linux64
        #define x64
        #define Threads
    #elif __i386__
        // Linux32
        #define x32
        #define Threads
    #else
        // sonstiges
        #define Threads
    #endif


// include
    #include <iostream>
    #include <stdio.h>
    #include <stdlib.h>
    #include <string>
    #include <cstring>
    #include <sstream>
    #include <fstream>
    #include <unistd.h>
    #include <time.h>
    #include <math.h>
    #include <sys/types.h>
    #include <sys/time.h>
    #ifdef __Threads__
        #include <pthread.h>
        #include <immintrin.h>
        #include <x86intrin.h>
        #include <semaphore.h>
    #endif
    using namespace std;

// type def
    typedef unsigned char Byte;
    typedef Byte*         Pointer;
    #ifdef x64
        typedef int64_t   int64;
    #else
        typedef int       int64; //  int64 soll unter 32Bit nur 32 Bit sein
    #endif

// define
    #define Links -1
    #define Gerade 0
    #define Rechts 1
    #define Nix    4

    #define Nord   0
    #define Ost    1
    #define Sued   2
    #define West   3

    #define NeueRichtung(Richtung, Aenderung)  ((Richtung+Aenderung) & 3)

    #define Richtung1_Gerade Richtung1
    #define Richtung1_Links  NeueRichtung(Richtung1, Links)
    #define Richtung1_Rechts NeueRichtung(Richtung1, Rechts)

    #define Richtung2_Gerade Richtung2
    #define Richtung2_Links  NeueRichtung(Richtung2, Links)
    #define Richtung2_Rechts NeueRichtung(Richtung2, Rechts)

    #define MAX(P,x) if (x>P) P = x
    #define MIN(P,x) if (x<P) P = x

    #define Min3(a,b,c) a<b?a<c?a:c:b<c?b:c
    #define Max3(a,b,c) a>b?a>c?a:c:b>c?b:c

    #define GET_Pos(x,y)(Mem+(y*ZeilenLaenge)+x)
    #define GET_PosX(Pos) (((Pos)-Mem)%ZeilenLaenge)
    #define GET_PosY(Pos) (((Pos)-Mem)/ZeilenLaenge)


    #define ZufallsWert (rand()/1000.1/RAND_MAX*TiefenPunkte)
    #define Stop(x) x = floor( x / 2.0 )
    #define sqr(x) ((x)*(x))

// Globale Variablen
    string  Dateiname;
    int     SpielerID  = 1;
    int     Spieler2ID = 2;
    int     MaxSpieler = 0;
    int     AktiveSpieler = 0;
    int     FreieFelder = 0;
    int     FreiePunkte = 0;
    int64   Width;
    int64   Height;
    Pointer Mem = NULL;
    int64   MemLaenge;
    int     SpielFeldGroesse;
    int64   ZeilenLaenge;
    int64   NegZeilenLaenge;
    double  StartTime;
    double  TiefenPunkte;
    int64   PosAenderung[5];
    bool    volatile Abbruch = false;

    double  Ki1_Punkte_Links    = 0;
    double  Ki1_Punkte_Gerade   = 0;
    double  Ki1_Punkte_Rechts   = 0;
    double  Ki2_Punkte_Links    = 0;
    double  Ki2_Punkte_Gerade   = 0;
    double  Ki2_Punkte_Rechts   = 0;
    double  Ki3_Punkte_Links    = 0;
    double  Ki3_Punkte_Gerade   = 0;
    double  Ki3_Punkte_Rechts   = 0;
    double  Ki5_Punkte_Links    = 0;
    double  Ki5_Punkte_Gerade   = 0;
    double  Ki5_Punkte_Rechts   = 0;


    struct  TSpieler{Pointer Pos; int Richtung,X,Y;};
    TSpieler Spieler[Maximale_Anz_Spieler];

    #ifdef Threads
        pthread_t Ki1_Thread_pp;
        pthread_t Ki2_Thread_pp;
        pthread_t Ki3_Thread_pp;
        pthread_t Ki5_Thread_pp;
    #endif


// forwards
double ZusatzPunkte1Spieler(const int RichtungsAenderung);
double ZusatzPunkte2Spieler(const int RichtungsAenderung);



// kleine Hilfsprogramme

int     StrToInt(string const s){int i;istringstream inStream(s);inStream >> i;return i;}
string  IntToStr(int const i){ostringstream outStream;outStream << i;return outStream.str();}
string  DoubleToStr(double const d){ostringstream outStream;outStream << d;return outStream.str();}
string  FloatToStr(float const d){ostringstream outStream;outStream << d;return outStream.str();}

double  Time(){ timeval Jetzt; gettimeofday(&Jetzt, NULL); return Jetzt.tv_sec + Jetzt.tv_usec / 1000000.0;}



void inline MemCopy(Pointer Von, Pointer Nach){
    // memcpy(Von,Nach,MemLaenge);
    #ifdef x64
        int64 Laenge = MemLaenge >> 3;
        asm volatile("rep movsq;":"+S"(Von),"+D"(Nach),"+c"(Laenge)::"memory","cc");
    #else
        int64 Laenge = MemLaenge >> 2;
        asm volatile("rep movsd;":"+S"(Von),"+D"(Nach),"+c"(Laenge)::"memory","cc");
    #endif
}


int PunkteAuswerten(double *Punkte, double const Punkte_Gerade, double const Punkte_Links, double const Punkte_Rechts){
    int  Richtung = Gerade;
         *Punkte  = Punkte_Gerade;
    if (Punkte_Links  > *Punkte){ *Punkte = Punkte_Links ; Richtung = Links ; }
    if (Punkte_Rechts > *Punkte){ *Punkte = Punkte_Rechts; Richtung = Rechts; }
    return Richtung;
}

// teste ob nur 1 Weg frei ist
int Test_1_Weg(){
    const Pointer Pos1 = Spieler[SpielerID].Pos;
    const int Richtung1 = Spieler[SpielerID].Richtung;

    const Byte P_Gerade = *(Pos1+PosAenderung[Richtung1_Gerade]);
    const Byte P_Links  = *(Pos1+PosAenderung[Richtung1_Links ]);
    const Byte P_Rechts = *(Pos1+PosAenderung[Richtung1_Rechts]);

    if (P_Gerade == 0 && P_Links != 0 && P_Rechts !=0 )return Gerade;
    if (P_Gerade != 0 && P_Links == 0 && P_Rechts !=0 )return Links;
    if (P_Gerade != 0 && P_Links != 0 && P_Rechts ==0 )return Rechts;

    return Nix;
}

// z�hle freie Felder
int ZaehleFreieFelder(const Pointer Mem, Pointer Pos){
    // Vorbereitung
    MemCopy(Mem,Mem+MemLaenge); // Kopie vom Spielfeld erstellen
    Pos+=MemLaenge;
    // const Pointer Ende   = Mem+MemLaenge+(Height+1)*ZeilenLaenge-1;
    const Pointer Ende = Mem+2*MemLaenge-ZeilenLaenge-1;

    int Anz = 0;
    if (*Pos==0)Anz++;

    // suche alle freien angrenzenden Felder
    // schnelle Assembler Routine
    asm volatile(

                    // Markiere StartFeld;
                    "mov byte ptr[%[Pos]],255;"

                "0:"
                    // checke ob links frei ist
                    "cmp byte ptr[%[Pos]-1],0;"
                    "jnz 2f;"
                "1:  sub %[Pos],1;"                                     // ja - markiere Feld und z�hle
                    "add %[Anz],1;"
                    "mov byte ptr[%[Pos]],255;"
                    "cmp byte ptr[%[Pos]-1],0;"                         // �berpr�fe ob das feld links daneben auch Frei ist
                    "jz  1b;"
                "2:"

                    // checke ob rechts frei ist
                    "cmp byte ptr[%[Pos]+1],1;"
                    "sbb byte ptr[%[Pos]+1],0;"                         // ja - markiere Feld und z�hle
                    "adc %[Anz],0;"

                    // checke ob unten frei ist
                    "cmp byte ptr[%[Pos]+%[ZeilenLaenge]],1;"
                    "sbb byte ptr[%[Pos]+%[ZeilenLaenge]],0;"           // ja - markiere Feld und z�hle
                    "adc %[Anz],0;"

                    // checke ob oben frei ist
                    "cmp byte ptr[%[Pos]+%[NegZeilenLaenge]],0;"
                    "jnz 6f;"
                "5:  add %[Pos],%[NegZeilenLaenge];"                    // ja - markiere Feld und z�hle
                    "add %[Anz],1;"
                    "mov byte ptr[%[Pos]],255;"
                    "cmp byte ptr[%[Pos]+%[NegZeilenLaenge]],0;"        // �berpr�fe ob das feld dar�ber auch Frei ist
                    "jz  5b;"
                    "jmp 0b;"
                "6:"

                    // suche n�chstes Markierte Feld, so lange das Ende nicht erreicht ist
                    "add %[Pos],1;"
                    "cmp %[Pos],%[Ende];"
                    "ja  9f;"
                    "cmp byte ptr[%[Pos]],255;"
                    "jnz 6b;"
                    "jmp 0b;"

                "9:"// Ende
                    :[Pos]"+r"(Pos)
                    ,[Anz]"+r"(Anz)
                    :[Ende]"r"(Ende)
                    ,[ZeilenLaenge]"r"(ZeilenLaenge)
                    ,[NegZeilenLaenge]"r"(NegZeilenLaenge)
                    :"memory","cc");
    return Anz;
}

// z�hle freie Felder
int ZaehleFreiePunkte(const Pointer Mem, const Pointer Pos1){
    // Vorbereitung
    MemCopy(Mem,Mem+MemLaenge); // Kopie vom Spielfeld erstellen
    Pointer Pos = Pos1+MemLaenge;
    // const Pointer Ende   = Mem+MemLaenge+(Height+1)*ZeilenLaenge-1;
    const Pointer Ende = Mem+2*MemLaenge-ZeilenLaenge-1;


    // suche alle freien angrenzenden Felder
    // schnelle Assembler Routine
    asm volatile(

                    // Markiere StartFeld;
                    "mov byte ptr[%[Pos]],255;"

                "0:"
                    // checke ob links frei ist
                    "cmp byte ptr[%[Pos]-1],0;"
                    "jnz 2f;"
                "1:  sub %[Pos],1;"                                     // ja - markiere Feld und z�hle
                    "mov byte ptr[%[Pos]],255;"
                    "cmp byte ptr[%[Pos]-1],0;"                         // �berpr�fe ob das feld links daneben auch Frei ist
                    "jz  1b;"
                "2:"

                    // checke ob rechts frei ist
                    "cmp byte ptr[%[Pos]+1],1;"
                    "sbb byte ptr[%[Pos]+1],0;"                         // ja - markiere Feld und z�hle

                    // checke ob unten frei ist
                    "cmp byte ptr[%[Pos]+%[ZeilenLaenge]],1;"
                    "sbb byte ptr[%[Pos]+%[ZeilenLaenge]],0;"           // ja - markiere Feld und z�hle

                    // checke ob oben frei ist
                    "cmp byte ptr[%[Pos]+%[NegZeilenLaenge]],0;"
                    "jnz 6f;"
                "5:  add %[Pos],%[NegZeilenLaenge];"                    // ja - markiere Feld und z�hle
                    "mov byte ptr[%[Pos]],255;"
                    "cmp byte ptr[%[Pos]+%[NegZeilenLaenge]],0;"        // �berpr�fe ob das feld dar�ber auch Frei ist
                    "jz  5b;"
                    "jmp 0b;"
                "6:"

                    // suche n�chstes Markierte Feld, so lange das Ende nicht erreicht ist
                    "add %[Pos],1;"
                    "cmp %[Pos],%[Ende];"
                    "ja  9f;"
                    "cmp byte ptr[%[Pos]],255;"
                    "jnz 6b;"
                    "jmp 0b;"

                "9:"// Ende
                    :[Pos]"+r"(Pos)
                    :[Ende]"r"(Ende)
                    ,[ZeilenLaenge]"r"(ZeilenLaenge)
                    ,[NegZeilenLaenge]"r"(NegZeilenLaenge)
                    :"memory","cc");

    // Z�hle Freie Grenzen
    *(Pos1+MemLaenge) = 1;
    Pos=Mem+ZeilenLaenge;
    int Anz = 0;
    // schnelle Assembler Routine
    asm volatile(
                    // suche n�chstes Markierte Feld, so lange das Ende nicht erreicht ist
                "1:  add %[Pos],1;"
                    "cmp %[Pos],%[Ende];"
                    "ja  9f;"
                    "cmp byte ptr[%[Pos]],255;"
                    "jnz 1b;"

                    // Z�hle Punkte
                    "add %[Anz],1;"
                    "cmp byte ptr[%[Pos]-1],255;"
                    "sbb %[Anz],-1;"
                    "cmp byte ptr[%[Pos]+1],255;"
                    "sbb %[Anz],-1;"
                    "cmp byte ptr[%[Pos]+%[ZeilenLaenge]],255;"
                    "sbb %[Anz],-1;"
                    "cmp byte ptr[%[Pos]+%[NegZeilenLaenge]],255;"
                    "sbb %[Anz],-1;"
                    "jmp 1b;"


                "9:"// Ende
                    :[Pos]"+r"(Pos)
                    ,[Anz]"+r"(Anz)
                    :[Ende]"r"(Ende)
                    ,[ZeilenLaenge]"r"(ZeilenLaenge)
                    ,[NegZeilenLaenge]"r"(NegZeilenLaenge)
                    :"memory","cc");


    return Anz;
}

// z�hle freie Felder2
int ZaehleFreiePunkte2(const Pointer Mem, const Pointer Pos1){
    // Vorbereitung
    MemCopy(Mem,Mem+MemLaenge); // Kopie vom Spielfeld erstellen
    Pointer Pos = Pos1+MemLaenge;
    // const Pointer Ende   = Mem+MemLaenge+(Height+1)*ZeilenLaenge-1;
    const Pointer Ende = Mem+2*MemLaenge-ZeilenLaenge-1;


    // suche alle freien angrenzenden Felder
    // schnelle Assembler Routine
    asm volatile(

                    // Markiere StartFeld;
                    "mov byte ptr[%[Pos]],255;"

                "0:"
                    // checke ob links frei ist
                    "cmp byte ptr[%[Pos]-1],0;"
                    "jnz 2f;"
                "1:  sub %[Pos],1;"                                     // ja - markiere Feld und z�hle
                    "mov byte ptr[%[Pos]],255;"
                    "cmp byte ptr[%[Pos]-1],0;"                         // �berpr�fe ob das feld links daneben auch Frei ist
                    "jz  1b;"
                "2:"

                    // checke ob rechts frei ist
                    "cmp byte ptr[%[Pos]+1],1;"
                    "sbb byte ptr[%[Pos]+1],0;"                         // ja - markiere Feld und z�hle

                    // checke ob unten frei ist
                    "cmp byte ptr[%[Pos]+%[ZeilenLaenge]],1;"
                    "sbb byte ptr[%[Pos]+%[ZeilenLaenge]],0;"           // ja - markiere Feld und z�hle

                    // checke ob oben frei ist
                    "cmp byte ptr[%[Pos]+%[NegZeilenLaenge]],0;"
                    "jnz 6f;"
                "5:  add %[Pos],%[NegZeilenLaenge];"                    // ja - markiere Feld und z�hle
                    "mov byte ptr[%[Pos]],255;"
                    "cmp byte ptr[%[Pos]+%[NegZeilenLaenge]],0;"        // �berpr�fe ob das feld dar�ber auch Frei ist
                    "jz  5b;"
                    "jmp 0b;"
                "6:"

                    // suche n�chstes Markierte Feld, so lange das Ende nicht erreicht ist
                    "add %[Pos],1;"
                    "cmp %[Pos],%[Ende];"
                    "ja  9f;"
                    "cmp byte ptr[%[Pos]],255;"
                    "jnz 6b;"
                    "jmp 0b;"

                "9:"// Ende
                    :[Pos]"+r"(Pos)
                    :[Ende]"r"(Ende)
                    ,[ZeilenLaenge]"r"(ZeilenLaenge)
                    ,[NegZeilenLaenge]"r"(NegZeilenLaenge)
                    :"memory","cc");

    // Z�hle Freie Grenzen
    *(Pos1+MemLaenge) = 1;
    Pos=Mem+ZeilenLaenge;
    int Anz = 0;
    // schnelle Assembler Routine
    asm volatile(
                    // suche n�chstes Markierte Feld, so lange das Ende nicht erreicht ist
                "1:  add %[Pos],1;"
                    "cmp %[Pos],%[Ende];"
                    "ja  9f;"
                    "cmp byte ptr[%[Pos]],255;"
                    "jnz 1b;"

                    "add %[Anz],100;"
                    "cmp byte ptr[%[Pos]-1],255;"
                    "sbb %[Anz],-1;"
                    "cmp byte ptr[%[Pos]+1],255;"
                    "sbb %[Anz],-1;"
                    "cmp byte ptr[%[Pos]+%[ZeilenLaenge]],255;"
                    "sbb %[Anz],-1;"
                    "cmp byte ptr[%[Pos]+%[NegZeilenLaenge]],255;"
                    "sbb %[Anz],-1;"
                    "jmp 1b;"


                "9:"// Ende
                    :[Pos]"+r"(Pos)
                    ,[Anz]"+r"(Anz)
                    :[Ende]"r"(Ende)
                    ,[ZeilenLaenge]"r"(ZeilenLaenge)
                    ,[NegZeilenLaenge]"r"(NegZeilenLaenge)
                    :"memory","cc");


    return Anz;
}

// is Erreichbar
bool is_Erreichbar(const Pointer Mem, Pointer Pos1, Pointer Pos2){
    // Kopie vom Spielfeld erstellen
    MemCopy(Mem,Mem+MemLaenge);
    Pos1+=MemLaenge;
    Pos2+=MemLaenge;
    const Pointer Ende = Mem+2*MemLaenge+NegZeilenLaenge-1;

    // wenn Pos1 gr��er als Pos2 ist, ist die Berechnung schneller
    if (Pos1<Pos2){asm volatile("xchg %[Pos1],%[Pos2];":[Pos1]"+r"(Pos1),[Pos2]"+r"(Pos2)::"memory","cc");} // wenn nicht, Pos1 & Pos2 tauschen

    // schnelle Assembler Routine
    bool Result = false;
    asm volatile(
                    // Setze ZielFeld auf 0, damit es gefunden werden kann
                    "mov byte ptr[%[Pos2]],0;"
                    // Markiere StartFeld;
                    "mov byte ptr[%[Pos1]],255;"

                "1:"// �berpr�fe, ob Pos2 erreicht wurde
                    "cmp %[Pos1],%[Pos2];"
                    "jz  8f;"

                    // checke ob links frei ist
                    "cmp byte ptr[%[Pos1]-1],0;"
                    "jnz 2f;"
                    "sub %[Pos1],1;"                                    // ja - markiere Feld
                    "mov byte ptr[%[Pos1]],255;"
                    "jmp 1b;"

                "2:" // checke ob rechts frei ist
                    "cmp byte ptr[%[Pos1]+1],1;"
                    "sbb byte ptr[%[Pos1]+1],0;"                        // ja - markiere Feld

                    // checke ob unten frei ist
                    "cmp byte ptr[%[Pos1]+%[ZeilenLaenge]],1;"
                    "sbb byte ptr[%[Pos1]+%[ZeilenLaenge]],0;"          // ja - markiere Feld

                    // checke ob oben frei ist
                    "cmp byte ptr[%[Pos1]+%[NegZeilenLaenge]],0;"
                    "jnz 3f;"
                    "add %[Pos1],%[NegZeilenLaenge];"                   // ja - markiere Feld
                    "mov byte ptr[%[Pos1]],255;"
                    "jmp 1b;"

                "3:"// suche n�chstes markierte Feld, so lange das Ende nicht erreicht ist
                    "inc %[Pos1];"
                    "cmp %[Pos1],%[Ende];"
                    "ja  9f;"
                    "cmp byte ptr[%[Pos1]],255;"
                    "jnz 3b;"
                    "jmp 1b;"

                "8:"// Return true
                    "mov %[Result],%[True];"

                "9:"// Ende
                    :[Pos1]"+r"(Pos1)
                    ,[Result]"+r"(Result)
                    :[Pos2]"r"(Pos2)
                    ,[Ende]"r"(Ende)
                    ,[ZeilenLaenge]"r"(ZeilenLaenge)
                    ,[NegZeilenLaenge]"r"(NegZeilenLaenge)
                    ,[True]"i"(true)
                    :"memory","cc");
    return Result;
}

// ermittelt die Anzahl der aktiven Spieler
int Anz_Aktiver_Spieler(){
    int Anz = 1;
    for (int i = 1; i<=MaxSpieler; i++){
        if (i != SpielerID &&                                           // selber nicht mitz�hlen
            Spieler[i].Pos != 0 &&                                      // nur aktive spieler
            is_Erreichbar(Mem, Spieler[SpielerID].Pos, Spieler[i].Pos)  // nur Spieler ber�cksichtigen, die erreichbar sind
           )
           {
                Anz++;                      // einen weiteren Spieler gufunden
                if (Anz==2)Spieler2ID=i;    // Spieler 2 gefunden und speichern
            }
    }
    return Anz;
}

int Entfernung(const int X1, const int Y1, const int X2, const int Y2){
    return abs(X1-X2) + abs(Y1-Y2);
}

