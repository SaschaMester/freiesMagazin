
/**
    (C) Copyright 2014 Falk Burow

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/


// Analyse f�r 1 Spieler
int Ki5_Analyse1Spieler(Pointer Pos1, const int Richtung1, int Tiefe){
    Pos1 += PosAenderung[Richtung1];

    // ich bin gegen die Wand gefahren
    if (*Pos1!=0)return Tiefe;

    // Wenn Maximale Berechnungstiefe erreicht wurde, dann auswerten
    if (Tiefe>=Ki5_MaxTiefe)return ZaehleFreiePunkte(Ki5_Mem, Pos1)+Tiefe*5;
    Tiefe++;

    // markiere meine Position
    *Pos1 = 1;

    // berechne Punkte
    int Punkte   = Ki5_Analyse1Spieler(Pos1, Richtung1_Gerade, Tiefe );
    int P_Links  = Ki5_Analyse1Spieler(Pos1, Richtung1_Links , Tiefe ); MAX(Punkte,P_Links);
    int P_Rechts = Ki5_Analyse1Spieler(Pos1, Richtung1_Rechts, Tiefe ); MAX(Punkte,P_Rechts);

    // Werte zur�cksetzen und Ende
    *Pos1 = 0;
    return Punkte;
}

// Punkte berechnen
void Ki5_PunkteBerechnen(double* Punkte_Links, double* Punkte_Gerade, double* Punkte_Rechts){
    // Vorbereitung
    Ki5_init_Berechnungsgrenzen();
    Ki5_Durchlaeufe++;
    Ki5_Dauer = 0;
    const Pointer Pos1 = Spieler[SpielerID].Pos + Ki5_Mem_Diff;
    const int Richtung1 = Spieler[SpielerID].Richtung;
    double time=Time();

    // Punkte f�r jede einzelne Richtung berechnen
    int P_Gerade = Ki5_Analyse1Spieler(Pos1, Richtung1_Gerade, 0); Ki5Dauer;
    int P_Links  = Ki5_Analyse1Spieler(Pos1, Richtung1_Links , 0); Ki5Dauer;
    int P_Rechts = Ki5_Analyse1Spieler(Pos1, Richtung1_Rechts, 0); Ki5Dauer;

    if (Ki5_Durchlaeufe<=1 || !Abbruch){
        *Punkte_Gerade = P_Gerade;
        *Punkte_Links  = P_Links;
        *Punkte_Rechts = P_Rechts;
    }

    double  Punkte  = Max3(*Punkte_Links,*Punkte_Gerade,*Punkte_Rechts);

    // Berechnungsgrenzen anpassen
    double Old_Grenze = Ki5_Grenze;
    Ki5_Berechnungsgrenzen_anpassen(Punkte);
    // wenn die Berechnung viel zu kurz war, dann nochmal neu berechnen (mit gr��erer Berechnungsgrenzen)
    if (Ki5_Grenze>Old_Grenze && Ki5_Durchlaeufe<5 && Time()-StartTime<MaxRechenZeit*0.3)Ki5_PunkteBerechnen(Punkte_Links, Punkte_Gerade, Punkte_Rechts);
}

// Thread-Steuerung f�r Ki5
void* Ki5_Thread(void* d){
    MemCopy(Mem,Ki5_Mem);
    Ki5_Durchlaeufe   = 0;
    Ki5_Punkte_Links  = 0;
    Ki5_Punkte_Gerade = 0;
    Ki5_Punkte_Rechts = 0;

    Ki5_PunkteBerechnen(&Ki5_Punkte_Links, &Ki5_Punkte_Gerade, &Ki5_Punkte_Rechts);
    #ifdef LOG
        Log( "Ki5:      ("+IntToStr(round(Ki5_Punkte_Links))+","+IntToStr(round(Ki5_Punkte_Gerade))+","+IntToStr(round(Ki5_Punkte_Rechts))+")   Dauer: " + DoubleToStr(round((Time()-StartTime)*1000)/1000) + " sek." );
    #endif
    return 0;
}

// Ki5
int Ki5(){
    // Vorbereitung
    MemCopy(Mem,Ki5_Mem);
    Ki5_Durchlaeufe   = 0;
    double Punkte_Links  = 0;
    double Punkte_Gerade = 0;
    double Punkte_Rechts = 0;

    // Punkte berechnen
    Ki5_PunkteBerechnen(&Punkte_Links, &Punkte_Gerade, &Punkte_Rechts);
    Punkte_Links  += ZusatzPunkte1Spieler(Links );
    Punkte_Gerade += ZusatzPunkte1Spieler(Gerade);
    Punkte_Rechts += ZusatzPunkte1Spieler(Rechts);

    double Punkte;
    int Richtung = PunkteAuswerten(&Punkte, Punkte_Gerade, Punkte_Links, Punkte_Rechts);

    // Ausgabe
    #ifdef LOG
        Log("Ki5: "+IntToStr(round(Punkte))+" ("+IntToStr(round(Punkte_Links))+","+IntToStr(round(Punkte_Gerade))+","+IntToStr(round(Punkte_Rechts))+")   Dauer: " + DoubleToStr(round((Time()-StartTime)*1000)/1000) + " sek." );
    #endif
    return Richtung;
}

