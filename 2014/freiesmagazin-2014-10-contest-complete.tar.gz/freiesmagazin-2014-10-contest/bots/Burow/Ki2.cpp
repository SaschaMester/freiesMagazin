/**
    (C) Copyright 2014 Falk Burow

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

float Ki2_Analyse2Spieler(Pointer Pos1, const int Richtung1, Pointer Pos2, const int Richtung2, int Tiefe, const int Abbiegungen1, const int Abbiegungen2, const int Abbiegungen);






// Spieler 1 gerade - Spieler 2 gerade
float Ki2_1Gerade_2Gerade(const Pointer Pos1, const int Richtung1, const Pointer Pos2, const int Richtung2, const int Tiefe, const int Abbiegungen1, const int Abbiegungen2, const int Abbiegungen){
    return Ki2_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Gerade, Tiefe, Abbiegungen1, Abbiegungen2, Abbiegungen);
}

// Spieler 1 gerade - Spieler 2 abbiegen
float Ki2_1Gerade_2Abbiegen(const Pointer Pos1, const int Richtung1, const Pointer Pos2, const int Richtung2, const int Tiefe, const int Abbiegungen1, const int Abbiegungen2, const int Abbiegungen){
    float Punkte                          = Ki2_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Gerade, Tiefe, Abbiegungen1 , Abbiegungen2  , Abbiegungen  );
    if (Punkte>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Links , Tiefe, Abbiegungen1 , Abbiegungen2+1, Abbiegungen+1); MIN(Punkte,P);}
    if (Punkte>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Rechts, Tiefe, Abbiegungen1 , Abbiegungen2+1, Abbiegungen+1); MIN(Punkte,P);}
    return Punkte;
}

// Spieler 1 gerade - Spieler 2 Wand
float Ki2_1Gerade_2Wand(const Pointer Pos1, const int Richtung1, const Pointer Pos2, const int Richtung2, const int Tiefe, const int Abbiegungen1, const int Abbiegungen2, const int Abbiegungen){
    float Punkte                          = Ki2_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Links , Tiefe, Abbiegungen1 , Abbiegungen2, Abbiegungen+1);
    if (Punkte>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Rechts, Tiefe, Abbiegungen1 , Abbiegungen2, Abbiegungen+1); MIN(Punkte,P);}
    return Punkte;
}



// Spieler 1 abbiegen - Spieler 2 gerade
float Ki2_1Abbiegen_2Gerade(const Pointer Pos1, const int Richtung1, const Pointer Pos2, const int Richtung2, const int Tiefe, const int Abbiegungen1, const int Abbiegungen2, const int Abbiegungen){
    float Punkte                          = Ki2_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Gerade, Tiefe, Abbiegungen1  , Abbiegungen2, Abbiegungen  );
    if (Punkte<Ki2_MaximalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Gerade, Tiefe, Abbiegungen1+1, Abbiegungen2, Abbiegungen+1); MAX(Punkte,P);}
    if (Punkte<Ki2_MaximalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Gerade, Tiefe, Abbiegungen1+1, Abbiegungen2, Abbiegungen+1); MAX(Punkte,P);}
    return Punkte;
}

// Spieler 1 abbiegen - Spieler 2 abbiegen
float Ki2_1Abbiegen_2Abbiegen(const Pointer Pos1, const int Richtung1, const Pointer Pos2, const int Richtung2, const int Tiefe, const int Abbiegungen1, const int Abbiegungen2, const int Abbiegungen){
    float Punkte                          = Ki2_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Gerade, Tiefe, Abbiegungen1 , Abbiegungen2  , Abbiegungen  );
    if (Punkte>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Links , Tiefe, Abbiegungen1 , Abbiegungen2+1, Abbiegungen+1); MIN(Punkte,P);}
    if (Punkte>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Rechts, Tiefe, Abbiegungen1 , Abbiegungen2+1, Abbiegungen+1); MIN(Punkte,P);}
    if (Punkte>=Ki2_MaximalPunkte)return Punkte;

    float PP                          = Ki2_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Gerade, Tiefe, Abbiegungen1+1, Abbiegungen2  , Abbiegungen+1);
    if (PP>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Links , Tiefe, Abbiegungen1+1, Abbiegungen2+1, Abbiegungen+1); MIN(PP,P);}
    if (PP>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Rechts, Tiefe, Abbiegungen1+1, Abbiegungen2+1, Abbiegungen+1); MIN(PP,P);}
    MAX(Punkte,PP);
    if (Punkte>=Ki2_MaximalPunkte)return Punkte;

    PP                              = Ki2_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Gerade, Tiefe, Abbiegungen1+1, Abbiegungen2  , Abbiegungen+1);
    if (PP>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Links , Tiefe, Abbiegungen1+1, Abbiegungen2+1, Abbiegungen+1); MIN(PP,P);}
    if (PP>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Rechts, Tiefe, Abbiegungen1+1, Abbiegungen2+1, Abbiegungen+1); MIN(PP,P);}
    MAX(Punkte,PP);
    return Punkte;
}

// Spieler 1 abbiegen - Spieler 2 Wand
float Ki2_1Abbiegen_2Wand(const Pointer Pos1, const int Richtung1, const Pointer Pos2, const int Richtung2, const int Tiefe, const int Abbiegungen1, const int Abbiegungen2, const int Abbiegungen){
    float Punkte                          = Ki2_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Links , Tiefe, Abbiegungen1 , Abbiegungen2, Abbiegungen+1);
    if (Punkte>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Rechts, Tiefe, Abbiegungen1 , Abbiegungen2, Abbiegungen+1); MIN(Punkte,P);}
    if (Punkte>=Ki2_MaximalPunkte)return Punkte;

    float PP                          = Ki2_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Links , Tiefe, Abbiegungen1+1, Abbiegungen2, Abbiegungen+1);
    if (PP>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Rechts, Tiefe, Abbiegungen1+1, Abbiegungen2, Abbiegungen+1); MIN(PP,P);}
    MAX(Punkte,PP);
    if (Punkte>=Ki2_MaximalPunkte)return Punkte;

    PP                                = Ki2_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Links , Tiefe, Abbiegungen1+1, Abbiegungen2, Abbiegungen+1);
    if (PP>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Rechts, Tiefe, Abbiegungen1+1, Abbiegungen2, Abbiegungen+1); MIN(PP,P);}
    MAX(Punkte,PP);
    return Punkte;
}




// Spieler 1 Wand - Spieler 2 gerade
float Ki2_1Wand_2Gerade(const Pointer Pos1, const int Richtung1, const Pointer Pos2, const int Richtung2, const int Tiefe, const int Abbiegungen1, const int Abbiegungen2, const int Abbiegungen){
    float Punkte                          = Ki2_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Gerade, Tiefe, Abbiegungen1, Abbiegungen2, Abbiegungen+1);
    if (Punkte<Ki2_MaximalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Gerade, Tiefe, Abbiegungen1, Abbiegungen2, Abbiegungen+1); MAX(Punkte,P);}
    return Punkte;
}

// Spieler 1 Wand - Spieler 2 abbiegen
int Ki2_1Wand_2Abbiegen(const Pointer Pos1, const int Richtung1, const Pointer Pos2, const int Richtung2, const int Tiefe, const int Abbiegungen1, const int Abbiegungen2, const int Abbiegungen){
    float Punkte                          = Ki2_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Gerade, Tiefe, Abbiegungen1, Abbiegungen2  , Abbiegungen+1);
    if (Punkte>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Links , Tiefe, Abbiegungen1, Abbiegungen2+1, Abbiegungen+1); MIN(Punkte,P);}
    if (Punkte>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Rechts, Tiefe, Abbiegungen1, Abbiegungen2+1, Abbiegungen+1); MIN(Punkte,P);}
    if (Punkte>=Ki2_MaximalPunkte)return Punkte;

    float PP                          = Ki2_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Gerade, Tiefe, Abbiegungen1, Abbiegungen2  , Abbiegungen+1);
    if (PP>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Links , Tiefe, Abbiegungen1, Abbiegungen2+1, Abbiegungen+1); MIN(PP,P);}
    if (PP>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Rechts, Tiefe, Abbiegungen1, Abbiegungen2+1, Abbiegungen+1); MIN(PP,P);}
    MAX(Punkte,PP);
    return Punkte;
}

// Spieler 1 Wand - Spieler 2 Wand
float Ki2_1Wand_2Wand(const Pointer Pos1, const int Richtung1, const Pointer Pos2, const int Richtung2, const int Tiefe, const int Abbiegungen1, const int Abbiegungen2, const int Abbiegungen){
    float Punkte                          = Ki2_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Links , Tiefe, Abbiegungen1, Abbiegungen2, Abbiegungen+1);
    if (Punkte>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Rechts, Tiefe, Abbiegungen1, Abbiegungen2, Abbiegungen+1); MIN(Punkte,P);}
    if (Punkte>=Ki2_MaximalPunkte)return Punkte;

    float PP                          = Ki2_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Links , Tiefe, Abbiegungen1, Abbiegungen2, Abbiegungen+1);
    if (PP>Ki2_MinimalPunkte){float P = Ki2_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Rechts, Tiefe, Abbiegungen1, Abbiegungen2, Abbiegungen+1); MIN(PP,P);}
    MAX(Punkte,PP);

    return Punkte;
}





// Analyse f�r 2 Spieler
float Ki2_Analyse2Spieler(Pointer Pos1, const int Richtung1, Pointer Pos2, const int Richtung2, int Tiefe, const int Abbiegungen1, const int Abbiegungen2, const int Abbiegungen){
    const int64 NextPos1Add = PosAenderung[Richtung1];
    const int64 NextPos2Add = PosAenderung[Richtung2];
    Pos1 += NextPos1Add;
    Pos2 += NextPos2Add;


    // ich bin gegen die Wand gefahren
    if (*Pos1!=0){
        if (*Pos2==0) return 0 - ZaehleFreiePunkte2(Ki2_Mem,Pos2) + Tiefe*TiefenPunkte;
        // beide sind gegen die Wand gefahren
        return Tiefe*TiefenPunkte;
    }
    // gegner ist gegen die Wand gefahren
    if (*Pos2!=0)return  ZaehleFreiePunkte2(Ki2_Mem,Pos1);
    // zusammensto�
    if (Pos1==Pos2)return 0 + Tiefe*TiefenPunkte;




    // checke, ob das 2 Spieler Spiel fertig ist
    if (!is_Erreichbar(Ki2_Mem, Pos1,Pos2)) return ZaehleFreiePunkte2(Ki2_Mem, Pos1)-ZaehleFreiePunkte2(Ki2_Mem, Pos2);



    *Pos1 = 1; // markiere meine Position
    *Pos2 = 2; // markiere die Position des Gegners
    Tiefe++;
    float Punkte;

    if (Abbiegungen>=Ki2_Grenze4){
        // nicht mehr abbiegen - nur noch gerade aus
        Punkte = Ki2_1Gerade_2Gerade(Pos1, Richtung1, Pos2, Richtung2, Tiefe, Abbiegungen1, Abbiegungen2, Abbiegungen);
    }else{
        if (*(Pos1+NextPos1Add)!=0){
                // Spieler 1 Wand

                if (*(Pos2+NextPos2Add)!=0){
                    // Spieler 1 Wand - Spieler 2 Wand
                    Punkte = Ki2_1Wand_2Wand(Pos1, Richtung1, Pos2, Richtung2, Tiefe, Abbiegungen1, Abbiegungen2, Abbiegungen);
                }else{
                    if (Tiefe<= Ki2_Grenze3 || (Tiefe<= Ki2_Grenze1_intervall && Abbiegungen2<Ki2_Grenze1) || (Tiefe<= Ki2_Grenze2_intervall && Abbiegungen2<Ki2_Grenze2 && *(Pos2+2*NextPos2Add)!=0 )){
                        // Spieler 1 Wand - Spieler 2 Abbiegen
                        Punkte = Ki2_1Wand_2Abbiegen(Pos1, Richtung1, Pos2, Richtung2, Tiefe, Abbiegungen1, Abbiegungen2, Abbiegungen);
                    }else{
                        // Spieler 1 Wand - Spieler 2 gerade aus
                        Punkte = Ki2_1Wand_2Gerade(Pos1, Richtung1, Pos2, Richtung2, Tiefe, Abbiegungen1, Abbiegungen2, Abbiegungen);
                    }
            }
        }else{
            if (Tiefe<= Ki2_Grenze3 || (Tiefe<= Ki2_Grenze1_intervall && Abbiegungen1<Ki2_Grenze1) || (Tiefe<= Ki2_Grenze2_intervall && Abbiegungen1<Ki2_Grenze2 && *(Pos1+2*NextPos2Add)!=0 )){
            // Spieler 1 abbiegen
                if (*(Pos2+NextPos2Add)!=0){
                    // Spieler 1 abbiegen - Spieler 2 Wand
                    Punkte = Ki2_1Abbiegen_2Wand(Pos1, Richtung1, Pos2, Richtung2, Tiefe, Abbiegungen1, Abbiegungen2, Abbiegungen);
                }else{
                    if (Tiefe<= Ki2_Grenze3 || (Tiefe<= Ki2_Grenze1_intervall && Abbiegungen2<Ki2_Grenze1) || (Tiefe<= Ki2_Grenze2_intervall && Abbiegungen2<Ki2_Grenze2 && *(Pos2+2*NextPos2Add)!=0 )){
                        // Spieler 1 abbiegen - Spieler 2 Abbiegen
                        Punkte = Ki2_1Abbiegen_2Abbiegen(Pos1, Richtung1, Pos2, Richtung2, Tiefe, Abbiegungen1, Abbiegungen2, Abbiegungen);
                    }else{
                        // Spieler 1 abbiegen - Spieler 2 gerade aus
                        Punkte = Ki2_1Abbiegen_2Gerade(Pos1, Richtung1, Pos2, Richtung2, Tiefe, Abbiegungen1, Abbiegungen2, Abbiegungen);
                    }
                }
            }else{
            // Spieler 1 gerade aus
                if (*(Pos2+NextPos2Add)!=0){
                    // Spieler 1 gerade aus - Spieler 2 Wand
                    Punkte = Ki2_1Gerade_2Wand(Pos1, Richtung1, Pos2, Richtung2, Tiefe, Abbiegungen1, Abbiegungen2, Abbiegungen);
                }else{
                    if (Tiefe<= Ki2_Grenze3 || (Tiefe<= Ki2_Grenze1_intervall && Abbiegungen2<Ki2_Grenze1) || (Tiefe<= Ki2_Grenze2_intervall && Abbiegungen2<Ki2_Grenze2 && *(Pos2+2*NextPos2Add)!=0 )){
                        // Spieler 1 gerade aus - Spieler 2 Abbiegen
                        Punkte = Ki2_1Gerade_2Abbiegen(Pos1, Richtung1, Pos2, Richtung2, Tiefe, Abbiegungen1, Abbiegungen2, Abbiegungen);
                    }else{
                        // Spieler 1 gerade aus - Spieler 2 gerade aus
                        Punkte = Ki2_1Gerade_2Gerade(Pos1, Richtung1, Pos2, Richtung2, Tiefe, Abbiegungen1, Abbiegungen2, Abbiegungen);
                    }
                }
            }
        }
    }

    // Werte zur�cksetzen und Ende
    *Pos1 = 0;
    *Pos2 = 0;
    return Punkte;
}

// PunkteBerechnen
void Ki2_PunkteBerechnen(double* Punkte_Links, double* Punkte_Gerade, double* Punkte_Rechts){
    // Vorbereitung
    Ki2_init_Berechnungsgrenzen();
    Ki2_Durchlaeufe++;
    Ki2_Dauer = 0;
    const Pointer Pos1      = Spieler[SpielerID ].Pos + Ki2_Mem_Diff;
    const Pointer Pos2      = Spieler[Spieler2ID].Pos + Ki2_Mem_Diff;
    const int     Richtung1 = Spieler[SpielerID ].Richtung;
    const int     Richtung2 = Spieler[Spieler2ID].Richtung;
    double time=Time();

    // Punkte f�r jede einzelne Richtung berechnen
    const float P_GG = Ki2_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Gerade, 0, 0, 0, 0); Ki2Dauer;
    const float P_GL = Ki2_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Links , 0, 0, 0, 0); Ki2Dauer;
    const float P_GR = Ki2_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Rechts, 0, 0, 0, 0); Ki2Dauer;

    const float P_LG = Ki2_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Gerade, 0, 0, 0, 0); Ki2Dauer;
    const float P_LL = Ki2_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Links , 0, 0, 0, 0); Ki2Dauer;
    const float P_LR = Ki2_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Rechts, 0, 0, 0, 0); Ki2Dauer;

    const float P_RG = Ki2_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Gerade, 0, 0, 0, 0); Ki2Dauer;
    const float P_RL = Ki2_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Links , 0, 0, 0, 0); Ki2Dauer;
    const float P_RR = Ki2_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Rechts, 0, 0, 0, 0); Ki2Dauer;


    if (Ki2_Durchlaeufe<=1 || !Abbruch){
        *Punkte_Gerade  = Min3(P_GG, P_GL, P_GR);
        *Punkte_Links   = Min3(P_LG, P_LL, P_LR);
        *Punkte_Rechts  = Min3(P_RG, P_RL, P_RR);
    }

    float Punkte  = Max3(*Punkte_Links,*Punkte_Gerade,*Punkte_Rechts);


    // Berechnungsgrenzen anpassen
    double Old_Grenze = Ki2_Grenze;
    Ki2_Berechnungsgrenzen_anpassen(Punkte);
    // wenn die Berechnung viel zu kurz war, dann nochmal neu berechnen (mit ge�nderten Berechnungsgrenzen)
    if (Ki2_Grenze>Old_Grenze && Ki2_Durchlaeufe<5 && Time()-StartTime<MaxRechenZeit*0.3)Ki2_PunkteBerechnen(Punkte_Links, Punkte_Gerade, Punkte_Rechts);
}

// Thread-Steuerung f�r Ki2
void* Ki2_Thread(void* d){
    MemCopy(Mem,Ki2_Mem);
    Ki2_Durchlaeufe   = 0;
    Ki2_Punkte_Links  = 0;
    Ki2_Punkte_Gerade = 0;
    Ki2_Punkte_Rechts = 0;


    Ki2_PunkteBerechnen(&Ki2_Punkte_Links, &Ki2_Punkte_Gerade, &Ki2_Punkte_Rechts);

    #ifdef LOG
        Log( "Ki2:      ("+IntToStr(round(Ki2_Punkte_Links))+","+IntToStr(round(Ki2_Punkte_Gerade))+","+IntToStr(round(Ki2_Punkte_Rechts))+")   Dauer: " + DoubleToStr(round((Time()-StartTime)*1000)/1000) + " sek." );
    #endif
    return 0;
}

// Ki2
int Ki2(){
    // Vorbereitung
    MemCopy(Mem,Ki2_Mem);
    Ki2_Durchlaeufe   = 0;
    double Punkte_Links  = 0;
    double Punkte_Gerade = 0;
    double Punkte_Rechts = 0;

    // Punkte berechnen
    Ki2_PunkteBerechnen(&Punkte_Links, &Punkte_Gerade, &Punkte_Rechts);
    Punkte_Links  += ZusatzPunkte2Spieler(Links );
    Punkte_Gerade += ZusatzPunkte2Spieler(Gerade);
    Punkte_Rechts += ZusatzPunkte2Spieler(Rechts);

    double Punkte;
    int Richtung = PunkteAuswerten(&Punkte, Punkte_Gerade, Punkte_Links, Punkte_Rechts);

    #ifdef LOG
        Log( "Ki2: "+IntToStr(round(Punkte))+" ("+IntToStr(round(Punkte_Links))+","+IntToStr(round(Punkte_Gerade))+","+IntToStr(round(Punkte_Rechts))+")   Dauer: " + DoubleToStr(round((Time()-StartTime)*1000)/1000) + " sek." );
    #endif
    return Richtung;
}

