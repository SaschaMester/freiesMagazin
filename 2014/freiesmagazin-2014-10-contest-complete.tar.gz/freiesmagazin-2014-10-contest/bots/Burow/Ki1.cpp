/**
    (C) Copyright 2014 Falk Burow

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

// Analyse f�r 1 Spieler
int Ki1_Analyse1Spieler(Pointer Pos1, const int Richtung1, const int Abbiegungen1, const int Abbiegungen4, int Tiefe){
    // bewege in die Richtung
    const int64 NextPosAdd = PosAenderung[Richtung1];
    Pos1+= NextPosAdd;
    if (*Pos1!=0) return 0;  // gegen die Wand gefahren
    *Pos1 = 1; // Setze auf die aktuelle Position ein neues Wandteil
    Tiefe++;
    // Punkte berechnen
    int Punkte;

    if (*(Pos1+NextPosAdd)!=0 ){
        // vor einem liegt eine Mauer
        if (Abbiegungen4<Ki1_Grenze4){
            // abbiegen, wenn Grenze noch nicht erreicht wurde
            Punkte = Ki1_Analyse1Spieler(Pos1, Richtung1_Links ,Abbiegungen1, Abbiegungen4+1, Tiefe);   // Punkte f�r Links berechnen
            int P  = Ki1_Analyse1Spieler(Pos1, Richtung1_Rechts,Abbiegungen1, Abbiegungen4+1, Tiefe);   // Punkte f�r Rechts berechnen
            MAX(Punkte,P);
        }else{
            Punkte = ZaehleFreieFelder(Ki1_Mem,Pos1+PosAenderung[Richtung1_Links]);
            int P  = ZaehleFreieFelder(Ki1_Mem,Pos1+PosAenderung[Richtung1_Rechts]);
            MAX(Punkte,P);
        }
    }else{

        // Punkte f�r gerade berechnen
        Punkte = Ki1_Analyse1Spieler(Pos1, Richtung1_Gerade, Abbiegungen1, Abbiegungen4, Tiefe);  // Punkte f�r gerade berechnen

        // �berpr�fe, ob ein abbiegen sinvoll ist
        if (
             (Tiefe < Ki1_Grenze3) ||
             (Tiefe<= Ki1_Grenze1_intervall && Abbiegungen1<Ki1_Grenze1) ||
             (Tiefe<= Ki1_Grenze2_intervall && Abbiegungen1<Ki1_Grenze2  && *(Pos1+2*NextPosAdd)!=0 )
           ){
                int P_Links  = Ki1_Analyse1Spieler(Pos1, Richtung1_Links ,Abbiegungen1+1, Abbiegungen4, Tiefe); MAX(Punkte,P_Links );  // Punkte f�r Links berechnen
                int P_Rechts = Ki1_Analyse1Spieler(Pos1, Richtung1_Rechts,Abbiegungen1+1, Abbiegungen4, Tiefe); MAX(Punkte,P_Rechts);  // Punkte f�r Rechts berechnen
            }
    }

    // Werte zur�cksetzen und Ende
    *Pos1 = 0;
    return Punkte+1;
}

// Punkte berechnen
void Ki1_PunkteBerechnen(double* Punkte_Links, double* Punkte_Gerade, double* Punkte_Rechts){
    // Vorbereitung
    Ki1_Durchlaeufe++;
    Ki1_init_Berechnungsgrenzen();
    Ki1_Dauer = 0;
    const Pointer Pos1 = Spieler[SpielerID].Pos + Ki1_Mem_Diff;
    const int Richtung1 = Spieler[SpielerID].Richtung;
    // int P;
    double time=Time();

    // Punkte f�r jede einzelne Richtung berechnen
    // P = Ki1_Analyse1Spieler(Pos1, Richtung1_Gerade, 0,0,0); MAX(*Punkte_Gerade,P); Ki1Dauer;
    // P = Ki1_Analyse1Spieler(Pos1, Richtung1_Links , 0,0,0); MAX(*Punkte_Links ,P); Ki1Dauer;
    // P = Ki1_Analyse1Spieler(Pos1, Richtung1_Rechts, 0,0,0); MAX(*Punkte_Rechts,P); Ki1Dauer;

    // Punkte f�r jede einzelne Richtung berechnen
    int P_Gerade = Ki1_Analyse1Spieler(Pos1, Richtung1_Gerade, 0,0,0); Ki1Dauer;
    int P_Links  = Ki1_Analyse1Spieler(Pos1, Richtung1_Links , 0,0,0); Ki1Dauer;
    int P_Rechts = Ki1_Analyse1Spieler(Pos1, Richtung1_Rechts, 0,0,0); Ki1Dauer;

    if (Ki1_Durchlaeufe<=1 || !Abbruch){
        *Punkte_Gerade = P_Gerade;
        *Punkte_Links  = P_Links;
        *Punkte_Rechts = P_Rechts;
    }



    // Berechnungsgrenzen anpassen
    double Old_Grenze = Ki1_Grenze;
    Ki1_Berechnungsgrenzen_anpassen();
    // wenn die Berechnung viel zu kurz war, dann nochmal neu berechnen (mit ge�nderten Berechnungsgrenzen)
    if (Ki1_Grenze>Old_Grenze && Time()-StartTime<MaxRechenZeit*0.3)Ki1_PunkteBerechnen(Punkte_Links, Punkte_Gerade, Punkte_Rechts);
}

// Thread-Steuerung f�r Ki1
void* Ki1_Thread(void* d){
    MemCopy(Mem,Ki1_Mem);
    Ki1_Durchlaeufe   = 0;
    Ki1_Punkte_Links  = 0;
    Ki1_Punkte_Gerade = 0;
    Ki1_Punkte_Rechts = 0;

    Ki1_PunkteBerechnen(&Ki1_Punkte_Links, &Ki1_Punkte_Gerade, &Ki1_Punkte_Rechts);
    #ifdef LOG
        Log( "Ki1:      ("+IntToStr(round(Ki1_Punkte_Links))+","+IntToStr(round(Ki1_Punkte_Gerade))+","+IntToStr(round(Ki1_Punkte_Rechts))+")   Dauer: " + DoubleToStr(round((Time()-StartTime)*1000)/1000) + " sek." );
    #endif
    return 0;
}

// Ki1
int Ki1(){
    // Vorbereitung
    MemCopy(Mem,Ki1_Mem);
    Ki1_Durchlaeufe      = 0;
    double Punkte_Links  = 0;
    double Punkte_Gerade = 0;
    double Punkte_Rechts = 0;

    // Punkte berechnen
    Ki1_PunkteBerechnen(&Punkte_Links, &Punkte_Gerade, &Punkte_Rechts);
    Punkte_Links  += ZusatzPunkte1Spieler(Links );
    Punkte_Gerade += ZusatzPunkte1Spieler(Gerade);
    Punkte_Rechts += ZusatzPunkte1Spieler(Rechts);

    double Punkte;
    int Richtung = PunkteAuswerten(&Punkte, Punkte_Gerade, Punkte_Links, Punkte_Rechts);

    // Log & Ausgabe
    #ifdef LOG
        Log("Ki1: "+IntToStr(round(Punkte))+" ("+IntToStr(round(Punkte_Links))+","+IntToStr(round(Punkte_Gerade))+","+IntToStr(round(Punkte_Rechts))+")   Dauer: " + DoubleToStr(round((Time()-StartTime)*1000)/1000) + " sek." );
    #endif
    return Richtung;
}

