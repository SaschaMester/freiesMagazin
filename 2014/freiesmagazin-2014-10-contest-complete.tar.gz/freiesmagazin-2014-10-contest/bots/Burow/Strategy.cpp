/**
    (C) Copyright 2014 Falk Burow

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

/*
    Ich habe verschiedene Ki's entwickelt, die alle Ihre besonderen F�higkeiten haben.
    Hier wird anhand der aktiven Spieler entschieden, welche Ki zum Einsatz kommt.

    Ki1 = 1 Spieler Ki
    Ki2 = 2 Spieler Ki
    Ki3 = 2 Spieler Ki
    Ki5 = 1 Spieler Ki

    Bei 1 aktiven Spieler wird Ki1 & Ki5 im Thread gestartet und die beste Richtung ermittelt.
    Bei 2 aktiven Spieler wird Ki2 & Ki3 im Thread gestartet und die beste Richtung ermittelt.


    Wissenswertes �ber meine Ki's:
    ------------------------------
    Alle Ki's arbeiten mit einem Punkte System.
    Es wird f�r jeder Richtung eine Punktzahl berechnet.
    Es wird in die Richtung mit der gr��ten Punktzahl gegangen.

    Meine Ki's berechnen mehrere Z�ge im Voraus. Damit die Berechnung nicht zu lange dauert,
    werden Grenzen festgelegt, die anhand der Berechnungsdauer dynamisch angepasst werden.
    Um m�glichst viele Z�ge im Voraus berechnen zu k�nnen, habe ich die Ki's auf
    Geschwindigkeit optimiert.

*/

#include "Ki1Tools.cpp"
#include "Ki2Tools.cpp"
#include "Ki3Tools.cpp"
#include "Ki5Tools.cpp"
#include "Ueberwachung.cpp"
#include "Ki1.cpp"
#include "Ki2.cpp"
#include "Ki3.cpp"
#include "Ki5.cpp"

void Ki_init(){
    PosAenderung[Nord] = NegZeilenLaenge;  // Richtung Nord
    PosAenderung[Ost ] = 1;                // Richtung Ost
    PosAenderung[Sued] = ZeilenLaenge;     // Richtung S�d
    PosAenderung[West] = -1;               // Richtung West
    PosAenderung[Nix ] = 0;                // keine Richtung

    Ki1_Mem_Diff = MemLaenge * 2;
    Ki2_Mem_Diff = MemLaenge * 4;
    Ki3_Mem_Diff = MemLaenge * 6;
    Ki5_Mem_Diff = MemLaenge * 8;
    Ki1_Mem      = Mem + Ki1_Mem_Diff;
    Ki2_Mem      = Mem + Ki2_Mem_Diff;
    Ki3_Mem      = Mem + Ki3_Mem_Diff;
    Ki5_Mem      = Mem + Ki5_Mem_Diff;

    TiefenPunkte = 0.1 / SpielFeldGroesse;
}


// ZusatzPunkte 1 Spieler
double ZusatzPunkte1Spieler(const int RichtungsAenderung){
    const int Richtung1 = NeueRichtung(Spieler[SpielerID].Richtung, RichtungsAenderung);
    const Pointer Pos1  = Spieler[SpielerID].Pos + PosAenderung[Richtung1];

    if (*Pos1!=0)return -999999;

    double Punkte = 0;

    // kleine Zufallswerte hinzurechnen
    // damit der Bot bei Punkt gleichstand nicht immer in dieselbe Richtung geht
    Punkte += ZufallsWert;

    // Bewertung des Spielfeldes
    Punkte += (ZaehleFreiePunkte(Mem, Pos1)-FreiePunkte)/100.0;

    // Zusatzpunkte f�rs gerade aus bewegen
    if (RichtungsAenderung==Gerade) Punkte += 0.09;

    return Punkte;
}

// ZusatzPunkte 2 Spieler
double ZusatzPunkte2Spieler(const int RichtungsAenderung){
    const int Richtung1 = NeueRichtung(Spieler[SpielerID].Richtung, RichtungsAenderung);
    const Pointer Pos1  = Spieler[SpielerID].Pos + PosAenderung[Richtung1];

    if (*Pos1!=0)return -999999;

    double Punkte = 0;

    // kleine Zufallswerte hinzurechnen
    // damit der Bot bei Punkt gleichstand nicht immer in dieselbe Richtung geht
    Punkte += ZufallsWert;

    // Bewertung des Spielfeldes
    Punkte -= (ZaehleFreiePunkte(Mem, Pos1)-FreiePunkte)/100.0;

    // Zusatzpunkte f�rs gerade aus bewegen
    if (RichtungsAenderung==Gerade) Punkte += 0.09;

      return Punkte;
}



// Starte die 1 Spieler Ki's im Thread und ermittel die beste Richtung
int Ki_SucheRichtung_1_Spieler(){
    #ifdef Threads
        // Threads starten
        pthread_create(&Ki1_Thread_pp , NULL, Ki1_Thread , NULL);
        pthread_create(&Ki5_Thread_pp , NULL, Ki5_Thread , NULL);
        // Warte auf das Ende der Threads
        pthread_join  (Ki1_Thread_pp , NULL);
        pthread_join  (Ki5_Thread_pp , NULL);
    #else
        Ki1_Thread(NULL);
        Ki5_Thread(NULL);
    #endif

    // Punkte auswerten
    double Punkte_Links  = Ki1_Punkte_Links  + Ki5_Punkte_Links  + ZusatzPunkte1Spieler(Links );
    double Punkte_Gerade = Ki1_Punkte_Gerade + Ki5_Punkte_Gerade + ZusatzPunkte1Spieler(Gerade);
    double Punkte_Rechts = Ki1_Punkte_Rechts + Ki5_Punkte_Rechts + ZusatzPunkte1Spieler(Rechts);

    double Punkte;
    int Richtung = PunkteAuswerten(&Punkte, Punkte_Gerade, Punkte_Links, Punkte_Rechts);

    // Log & Ausgabe
    #ifdef LOG
        Log( "Ki Thread: " + FloatToStr(round(Punkte*1000)/1000) + " (" + FloatToStr(round(Punkte_Links*1000)/1000) + "," + FloatToStr(round(Punkte_Gerade*1000)/1000) + "," + FloatToStr(round(Punkte_Rechts*1000)/1000) + ")   Dauer: " + DoubleToStr(round((Time()-StartTime)*1000)/1000) + " sek." );
    #endif
    return Richtung;
}

// Starte die 2 spieler Ki's im Thread und ermittel die beste Richtung
int Ki_SucheRichtung_2_Spieler(){
    #ifdef Threads
        // Threads starten
        pthread_create(&Ki2_Thread_pp , NULL, Ki2_Thread , NULL);
        pthread_create(&Ki3_Thread_pp , NULL, Ki3_Thread , NULL);
        // Warte auf das Ende der Threads
        pthread_join  (Ki2_Thread_pp , NULL);
        pthread_join  (Ki3_Thread_pp , NULL);
    #else
        Ki2_Thread(NULL);
        Ki3_Thread(NULL);
    #endif

    // Punkte auswerten
    double Punkte_Links  = Ki2_Punkte_Links  + 20.0*Ki3_Punkte_Links  + ZusatzPunkte2Spieler(Links );
    double Punkte_Gerade = Ki2_Punkte_Gerade + 20.0*Ki3_Punkte_Gerade + ZusatzPunkte2Spieler(Gerade);
    double Punkte_Rechts = Ki2_Punkte_Rechts + 20.0*Ki3_Punkte_Rechts + ZusatzPunkte2Spieler(Rechts);

    double Punkte;
    int Richtung = PunkteAuswerten(&Punkte, Punkte_Gerade, Punkte_Links, Punkte_Rechts);

    // Log & Ausgabe
    #ifdef LOG
        Log( "Ki Thread: " + FloatToStr(round(Punkte*1000)/1000) + " (" + FloatToStr(round(Punkte_Links*1000)/1000) + "," + FloatToStr(round(Punkte_Gerade*1000)/1000) + "," + FloatToStr(round(Punkte_Rechts*1000)/1000) + ")   Dauer: " + DoubleToStr(round((Time()-StartTime)*1000)/1000) + " sek." );
    #endif
    return Richtung;
}

// *******************  Ki                  ******************************************************
int Strategy(){
    int Richtung;

    // teste ob nur 1 Weg frei ist
    Richtung = Test_1_Weg();
    if (Richtung!=Nix){
        Ki1_Grenze /= 1.02;
        Ki2_Grenze /= 1.02;
        Ki3_Grenze /= 1.02;
        Ki5_Grenze /= 1.02;
        return Richtung;
    }

    // �berwacht die Berechnungsdauer und bricht gegebenenfalls die Berechnung ab
    Ueberwachung_Start();

    // Vorbereitung
    AktiveSpieler = Anz_Aktiver_Spieler();
    FreieFelder   = ZaehleFreieFelder(Mem, Spieler[SpielerID].Pos);
    FreiePunkte   = ZaehleFreiePunkte(Mem, Spieler[SpielerID].Pos);

    // w�hle die passende Ki aus
    if (AktiveSpieler==2) Richtung = Ki_SucheRichtung_2_Spieler();
                     else Richtung = Ki_SucheRichtung_1_Spieler();

    // if (AktiveSpieler==1) Richtung = Ki1(); else
    // if (AktiveSpieler==1) Richtung = Ki5(); else
    // if (AktiveSpieler==2) Richtung = Ki2(); else
    // if (AktiveSpieler==2) Richtung = Ki3(); else
    //                       Richtung = Ki1();



    Ueberwachung_Ende();
    return Richtung;
}

