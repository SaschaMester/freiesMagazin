/**
    (C) Copyright 2014 Falk Burow

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/


// Analyse f�r 2 Spieler
int Ki3_Analyse2Spieler(Pointer Pos1, const int Richtung1, Pointer Pos2, const int Richtung2, int Tiefe){
    Pos1 += PosAenderung[Richtung1];
    Pos2 += PosAenderung[Richtung2];

    // Checke
    if (*Pos1!=0){
        if (*Pos2==0) return -100000;   // ich bin gegen die Wand gefahren
        return 0;                       // beide sind gegen die Wand gefahren
    }
    if (*Pos2!=0) return 100000;        // Gegner ist gegen die Wand gefahren
    if (Pos1==Pos2)return 0;            // Zusammensto�

    // Auswerten
    if (!is_Erreichbar(Ki3_Mem, Pos1,Pos2)) return ZaehleFreieFelder(Ki3_Mem, Pos1)-ZaehleFreieFelder(Ki3_Mem, Pos2);

    // Wenn Maximale Berechnungstiefe erreicht wurde, dann abbrechen
    if (++Tiefe>=Ki3_MaxTiefe)return 0;

    *Pos1 = 1; // markiere meine Position
    *Pos2 = 2; // markiere die Position des Gegners

    // berechne Punkte
    int Punkte, P, PP;

        Punkte  = Ki3_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Gerade, Tiefe);
        P       = Ki3_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Links , Tiefe); MIN(Punkte,P);
        P       = Ki3_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Rechts, Tiefe); MIN(Punkte,P);

        PP      = Ki3_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Gerade, Tiefe);
        P       = Ki3_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Links , Tiefe); MIN(PP,P);
        P       = Ki3_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Rechts, Tiefe); MIN(PP,P);
        MAX(Punkte,PP);

        PP      = Ki3_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Gerade, Tiefe);
        P       = Ki3_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Links , Tiefe); MIN(PP,P);
        P       = Ki3_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Rechts, Tiefe); MIN(PP,P);
        MAX(Punkte,PP);


    // Werte zur�cksetzen und Ende
    *Pos1 = 0;
    *Pos2 = 0;
    return Punkte;
}

// berechne Punkte
void Ki3_PunkteBerechnen(double* Punkte_Links, double* Punkte_Gerade, double* Punkte_Rechts){
    // Vorbereitung
    Ki3_init_Berechnungsgrenzen();
    Ki3_Durchlaeufe++;
    Ki3_Dauer = 0;
    const Pointer Pos1      = Spieler[SpielerID ].Pos + Ki3_Mem_Diff;
    const Pointer Pos2      = Spieler[Spieler2ID].Pos + Ki3_Mem_Diff;
    const int     Richtung1 = Spieler[SpielerID ].Richtung;
    const int     Richtung2 = Spieler[Spieler2ID].Richtung;
    double time=Time();

    // Punkte f�r jede einzelne Richtung berechnen
    // G => Gerade  /  L => Links  /  R => rechts
    const double GG = Ki3_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Gerade,0);Ki3Dauer;
    const double GL = Ki3_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Links ,0);Ki3Dauer;
    const double GR = Ki3_Analyse2Spieler(Pos1, Richtung1_Gerade, Pos2, Richtung2_Rechts,0);Ki3Dauer;

    const double LG = Ki3_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Gerade,0);Ki3Dauer;
    const double LL = Ki3_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Links ,0);Ki3Dauer;
    const double LR = Ki3_Analyse2Spieler(Pos1, Richtung1_Links , Pos2, Richtung2_Rechts,0);Ki3Dauer;

    const double RG = Ki3_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Gerade,0);Ki3Dauer;
    const double RL = Ki3_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Links ,0);Ki3Dauer;
    const double RR = Ki3_Analyse2Spieler(Pos1, Richtung1_Rechts, Pos2, Richtung2_Rechts,0);Ki3Dauer;


    if (Ki3_Durchlaeufe<=1 || !Abbruch){
        *Punkte_Gerade  = Min3(GL,GG,GR);
        *Punkte_Links   = Min3(LL,LG,LR);
        *Punkte_Rechts  = Min3(RL,RG,RR);
    }
    double  Punkte  = Max3(*Punkte_Links,*Punkte_Gerade,*Punkte_Rechts);

    // Berechnungsgrenzen anpassen
    double Old_Grenze = Ki3_Grenze;
    Ki3_Berechnungsgrenzen_anpassen(Punkte);
    // wenn die Berechnung viel zu kurz war, dann nochmal neu berechnen (mit gr��erer Berechnungsgrenzen)
    if (Ki3_Grenze>Old_Grenze && Ki3_Durchlaeufe<5 && Time()-StartTime<MaxRechenZeit*0.3)Ki3_PunkteBerechnen(Punkte_Links, Punkte_Gerade, Punkte_Rechts);
}

// Thread-Steuerung f�r Ki3
void* Ki3_Thread(void* d){
    MemCopy(Mem,Ki3_Mem);
    Ki3_Durchlaeufe=0;
    Ki3_Punkte_Links  = 0;
    Ki3_Punkte_Gerade = 0;
    Ki3_Punkte_Rechts = 0;

    Ki3_PunkteBerechnen(&Ki3_Punkte_Links, &Ki3_Punkte_Gerade, &Ki3_Punkte_Rechts);
    #ifdef LOG
        Log( "Ki3:      ("+IntToStr(round(Ki3_Punkte_Links))+","+IntToStr(round(Ki3_Punkte_Gerade))+","+IntToStr(round(Ki3_Punkte_Rechts))+")   Dauer: " + DoubleToStr(round((Time()-StartTime)*1000)/1000) + " sek. ("+DoubleToStr(round(Ki3_Dauer*1000)/1000)+")" );
    #endif
    return 0;
}

// Ki3
int Ki3(){
    // Vorbereitung
    MemCopy(Mem,Ki3_Mem);
    Ki3_Durchlaeufe=0;
    double Punkte_Links  = 0;
    double Punkte_Gerade = 0;
    double Punkte_Rechts = 0;

    // Punkte berechnen
    Ki3_PunkteBerechnen(&Punkte_Links, &Punkte_Gerade, &Punkte_Rechts);
    Punkte_Links  += ZusatzPunkte2Spieler(Links );
    Punkte_Gerade += ZusatzPunkte2Spieler(Gerade);
    Punkte_Rechts += ZusatzPunkte2Spieler(Rechts);

    double Punkte;
    int Richtung = PunkteAuswerten(&Punkte, Punkte_Gerade, Punkte_Links, Punkte_Rechts);

    #ifdef LOG
        Log( "Ki3: "+IntToStr(round(Punkte))+" ("+IntToStr(round(Punkte_Links))+","+IntToStr(round(Punkte_Gerade))+","+IntToStr(round(Punkte_Rechts))+")   Dauer: " + DoubleToStr(round((Time()-StartTime)*1000)/1000) + " sek." );
    #endif
    return Richtung;}

