#pragma once
/**
    (C) Copyright 2014 Falk Burow

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/





// Das Log von meinem Bot wird unter "Dateinamen".log gespeichert

#ifdef LOG
    fstream FLog;
#endif

void Log(const string s){
    #ifdef LOG
        FLog << s << endl;
    #endif
}

void Log_Init(){
    #ifdef LOG
        string LogDatei = Dateiname + ".log";
        const char * _LogDatei = LogDatei.c_str();
        FLog.open(_LogDatei, ios::out);
    #endif
}

void Log_Ende(){
    #ifdef LOG
        FLog.close();
    #endif
}


