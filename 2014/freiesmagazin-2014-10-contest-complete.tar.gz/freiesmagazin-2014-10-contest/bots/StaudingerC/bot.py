#!/usr/bin/env python3
__author__ = 'christoph'
#    bot.py, Tron bot for the freies magazin programming contest 7
#    Copyright (C) 2014 Christoph Staudinger
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>

import sys
import weakref

REC_DEPTH = 3


class Tile:
    directions = ['N', 'E', 'S', 'W']

    def __init__(self, board, x, y, blocked=False):
        self._map = weakref.ref(board)
        self.blocked = blocked
        self.opponent = False
        self.x = x
        self.y = y

    def block(self):
        self.blocked = True

    @property
    def map(self):
        return self._map()

    @property
    def possibly_blocked(self):
        for d in self.directions:
            if self[d] and self[d].opponent:
                return True
        return False

    @property
    def neighbors(self):
        n = []
        for d in self.directions:
            if self[d]:
                n.append(self[d])
        return n

    def __getitem__(self, item):
        if item == 'N':
            x, y = self.x, self.y - 1
        elif item == 'E':
            x, y = self.x + 1, self.y
        elif item == 'S':
            x, y = self.x, self.y + 1
        elif item == 'W':
            x, y = self.x - 1, self.y
        else:
            raise KeyError(item)
        try:
            return self.map.tiles[y][x]
        except KeyError:
            return None

    def get_reachable_tiles(self, save=False):
        active_tiles = {self}
        tiles = set()
        distances = {}
        dist = 0
        while active_tiles:
            neighbors = set()
            for t in active_tiles:
                neighbors.update(t.neighbors)
            active_tiles = set(neighbors).difference(tiles)
            for t in active_tiles.copy():
                if t is None or t.blocked or (save and t.possibly_blocked):
                    active_tiles.remove(t)
            tiles.update(active_tiles)
            for t in active_tiles:
                distances[t] = dist
            dist += 1
        return tiles, distances

    def get_nof_reachable_tiles(self):
        return len(self.get_reachable_tiles(False)[0])

    def get_nof_savely_reachable_tiles(self):
        return len(self.get_reachable_tiles(True)[0])

    def get_opponent_reachable(self):
        for t in self.get_reachable_tiles():
            if t.opponent:
                return True
        return False


class Player:
    def __init__(self, board, x, y, direction):
        self._map = weakref.ref(board)
        self.x = x
        self.y = y
        self.direction = direction

    def __getitem__(self, item):
        return self.get_tile_for_move(item)

    @property
    def map(self):
        return self._map()

    @map.setter
    def map(self, map):
        self._map = weakref.ref(map)

    @property
    def tile(self) -> Tile:
        return self.map[self.y][self.x]

    @property
    def available_moves(self):
        return [m for m in ['AHEAD', 'RIGHT', 'LEFT'] if self[m] and not self[m].blocked]

    @property
    def reachable_tiles(self):
        return self.tile.get_nof_reachable_tiles()

    def move(self, move):
        d = self.get_direction_from_move(move)
        t = self.tile[d]
        t.block()
        self.x, self.y = t.x, t.y
        self.direction = d

    def move_direction(self, direction):
        t = self.tile[direction]
        t.block()
        self.x, self.y = t.x, t.y
        self.direction = direction

    def get_tile_for_move(self, move):
        d = self.get_direction_from_move(move)
        return self.tile[d]

    def get_tile_for_direction(self, direction):
        return self.tile[direction]

    def get_move_for_direction(self, direction):
        for m in ['AHEAD', 'LEFT', 'RIGHT']:
            if self.get_direction_from_move(m) == direction:
                return m
        return None

    def get_direction_from_move(self, move):
        directions = ['N', 'E', 'S', 'W']
        n = directions.index(self.direction)
        if move == 'AHEAD':
            pass
        elif move == 'LEFT':
            n -= 1
        elif move == 'RIGHT':
            n += 1
        return directions[n % 4]

    def copy(self):
        return Player(self.map, self.x, self.y, self.direction)

    def get_nof_first_reachable_tiles(self, opponent=False):
        own_distances = self.tile.get_reachable_tiles()[1]
        if opponent:
            opponent_distances = self.map.player.tile.get_reachable_tiles()[1]
        else:
            opponent_distances = self.map.opponents[0].tile.get_reachable_tiles()[1]
        reachable = 0
        for t in own_distances:
            try:
                if opponent_distances[t] < own_distances[t]:
                    continue
            except KeyError:
                pass
            reachable += 1
        return reachable


class Map:
    def __init__(self, height, width, tiles):
        self.player = None
        self.opponents = []
        self.height = height
        self.width = width
        self.tiles = dict()
        if height * width != len(tiles):
            raise ValueError('Invalid map data.')
        for i in range(1, height + 1):
            self.tiles[i] = dict()
        y = 1
        x = 1
        for i, t in enumerate(tiles):
            if x > self.width:
                y += 1
                x = 1
            self.tiles[y][x] = Tile(self, x, y, t)
            x += 1

    def __getitem__(self, item):
        return self.tiles[item]

    def block_coord(self, x, y):
        self.tiles[y][x].blocked = True

    def copy(self):
        m = Map(self.height, self.width, self.tile_array)
        m.player = self.player.copy()
        m.player.map = m
        m.opponents = [o.copy() for o in self.opponents]
        for o in m.opponents:
            o.map = m
        return m

    @property
    def tile_array(self):
        l = []
        for y in range(1, self.height + 1):
            for x in range(1, self.width + 1):
                if self.tiles[y][x].blocked:
                    l.append(True)
                else:
                    l.append(False)
        return l

    def __repr__(self):
        s = ''
        for i in range(1, self.height + 1):
            for j in range(1, self.width + 1):
                if self.tiles[i][j].opponent:
                    s += 'O'
                elif self.tiles[i][j].blocked:
                    s += '#'
                elif self.tiles[i][j].possibly_blocked:
                    s += 'B'
                else:
                    s += '.'
            s += '\n'
        return s


class Bot:
    def __init__(self, num, map):
        self.num = num
        self.map = map

    @property
    def player(self):
        return self.map.player

    def move(self):
        if not self.player.available_moves:
            return 'AHEAD'
        options = self.player.available_moves[:]
        for i in range(2, REC_DEPTH + 1):
            moves = []
            for m in options:
                moves.append((m, self.rec_rate_move(m, self.map, i)))
            if len(moves) < 2:
                break
            moves.sort(key=lambda x: x[1])
            for j in range(len(moves) - 1):
                if round(moves[j][1], 2) != round(moves[j+1][1], 2):
                    options.remove(moves[j][0])
            if len(set([round(m[1], 2) for m in moves])) > 1:
                break
        return sorted(moves, key=lambda x: x[1])[-1][0]

    def rec_rate_move(self, move, map, depth):
        if depth == 0 or not map.opponents:
            return 0
        m = map.copy()
        m.player.move(move)
        total_points = 0
        for move in m.opponents[0].available_moves:
            points = 0
            m2 = m.copy()
            m2.opponents[0].move(move)
            player_available = m2.player.reachable_tiles
            player_first_available = m2.player.get_nof_first_reachable_tiles()
            opponent_first_available = m2.opponents[0].get_nof_first_reachable_tiles(True)
            if player_first_available > opponent_first_available:
                points += 1
            if player_first_available < opponent_first_available:
                points -= 1
            if points == 0:
                for move in m2.player.available_moves:
                    points += self.rec_rate_move(move, m2, depth - 1) / 10
            points += player_available / 1000
            total_points += points
        return total_points


class Game:
    def __init__(self):
        self.map = None
        self.bot = None
        self.bot_num = None

    def start(self):
        self.map = self.get_map()
        self.bot_num = self.get_bot_num()
        self.bot = Bot(self.bot_num, self.map)
        self.run()

    def get_map(self):
        start = input()
        gameboardstart, size = start.split()
        if gameboardstart != 'GAMEBOARDSTART':
            raise ValueError
        cols, rows = (int(x) for x in size.split(','))
        tiles = []
        for line in range(rows):
            tiles += input()
        gameboardend = input()
        if gameboardend != 'GAMEBOARDEND':
            raise ValueError
        tiles = [False if x == '.' else True for x in tiles]
        return Map(rows, cols, tiles)

    def get_bot_num(self):
        s, num = input().split()
        if s != 'SET':
            raise ValueError
        return int(num)

    def parse_position(self, inp):
        pos, bot_nr, coords, direction = inp.split()
        bot_nr = int(bot_nr)
        col, row = (int(x) for x in coords.split(','))
        return bot_nr, (col, row, direction)

    def wait_for_end(self):
        while True:
            if input() == 'END':
                break

    def reset(self):
        self.map.player = None
        self.map.opponents = []

    def run(self):
        while True:
            inp = input()
            if inp[:3] == 'END':
                break
            elif inp[:3] == 'OUT':
                pass
            elif inp[:3] == 'POS':
                bot, pos = self.parse_position(inp)
                self.map.block_coord(pos[0], pos[1])
                if bot == self.bot_num:
                    self.map.player = Player(self.map, *pos)
                else:
                    self.map.opponents.append(Player(self.map, *pos))
            elif inp[:3] == 'ROU':
                print(self.bot.move())
                self.reset()
            else:
                pass

if __name__ == '__main__':
    g = Game()
    g.start()

