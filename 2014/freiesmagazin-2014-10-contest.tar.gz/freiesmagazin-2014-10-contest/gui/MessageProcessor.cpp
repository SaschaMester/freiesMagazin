/**
    (C) Copyright 2012,2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "MessageProcessor.hh"

#include "EndMessage.hh"
#include "GameboardEndMessage.hh"
#include "GameboardLineMessage.hh"
#include "GameboardStartMessage.hh"
#include "GameData.hh"
#include "PlayerMessage.hh"
#include "PlayerOutMessage.hh"
#include "PlayerSetMessage.hh"
#include "StartMessage.hh"
#include "TextMessage.hh"

#include <iostream>
#include <sstream>

// Konstruktor.
MessageProcessor::MessageProcessor( GameData * dataP )
  : mDataP(dataP), mGameboardStarted(false), mGameboardSize(0,0)
{
    if ( 0 == mDataP )
    {
        std::ostringstream out;
        out << "(EE) MessageProcessor::MessageProcessor "
            << std::hex << this << std::dec
            << " GameData is 0!"
            << std::endl;
        std::cerr << out.str();
    }
}

// Destruktor.
MessageProcessor::~MessageProcessor()
{
    // Zeiger nicht loeschen, da aussen referenziert.
    mDataP = 0;
}

// Werte zuruecksetzen.
void MessageProcessor::reset()
{
    // Achtung: Die Daten setzen wir mit Absicht nicht zurueck.
    // Damit sie weiterhin angezeigt werden koennen.
    mGameboardStarted = false;
    mGameboardSize.setPosition(0,0);
    mGameboardStrings.clear();
    if ( mDataP )
    {
        mDataP->reset();
    }
}
    
// Behandelt eine Start-Nachricht.
bool MessageProcessor::operate( const StartMessage& message )
{
    bool retValue = false;

    if ( mDataP )
    {
        mDataP->numRound = message.getNumRound();
        retValue = true;
    }
    
    return retValue;
}

// Behandelt eine Ende-Nachricht.
bool MessageProcessor::operate( const EndMessage& /* message */ )
{
    bool retValue = false;

    if ( mDataP )
    {
        mDataP->isFinished = true;
        retValue = true;
    }
    
    return retValue;
}

// Behandelt eine Spieler-Daten-Nachricht.
bool MessageProcessor::operate( const PlayerMessage& message )
{
    bool retValue = false;

    const unsigned int playerNo = message.getPlayerNo();
    if ( playerNo > 0 ) 
    {
        if ( playerNo <= mDataP->players.size() )
        {
            // Markiere alte Position auf dem Spielbrett als belegt, wenn
            // sie sich geändert hat.
            if ( !(mDataP->players[playerNo-1].pos == message.getPosition()) )
            {
                if ( mDataP->gameboard.isValidPos( mDataP->players[playerNo-1].pos, true ) )
                {
                    mDataP->gameboard.occupy( mDataP->players[playerNo-1].pos, playerNo );
                }
            }
            
            mDataP->players[playerNo-1].pos = message.getPosition();
            mDataP->players[playerNo-1].dir = message.getDirection();
            retValue = true;
        }
    }

    return retValue;
}

// Behandelt eine Spieler-Todes-Nachricht.
bool MessageProcessor::operate( const PlayerOutMessage& message )
{
    bool retValue = false;

    const unsigned int playerNo = message.getPlayerNo();
    if ( playerNo > 0 ) 
    {
        if ( playerNo <= mDataP->players.size() )
        {
            mDataP->players[playerNo-1].isDead = true;
            retValue = true;
        }
    }
    
    return retValue;
}

// Behandelt eine Spieler-Setzen-Nachricht.
bool MessageProcessor::operate( const PlayerSetMessage& message )
{
    bool retValue = false;

    const unsigned int playerNo = message.getPlayerNo();
    if ( playerNo > 0 ) 
    {
        // Vektor entsprechend vergroessern, falls notwendig.
        mDataP->players.resize(playerNo);
        retValue = true;
    }

    return retValue;
}

// Behandelt eine Spielbrett-Start-Nachricht.
bool MessageProcessor::operate( const GameboardStartMessage& message )
{
    bool retValue = false;

    if ( mDataP )
    {
        mGameboardStarted = true;
        mGameboardStrings.clear();
        mGameboardSize = message.getSize();
        retValue = true;

#ifdef DEBUG
        std::ostringstream out;
        out << "(DD) MessageProcessor::operate GameboardStartMessage"
            << " Size: "
            << mGameboardSize
            << std::endl;
        std::clog << out.str();
#endif
    }
    
    return retValue;
}

// Behandelt eine Spielbrett-Zeile-Nachricht.
bool MessageProcessor::operate( const GameboardLineMessage& message )
{
    bool retValue = false;

    if ( mGameboardStarted )
    {
        mGameboardStrings.push_back( message.getLine() );
        retValue = true;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) MessageProcessor::operate GameboardLineMessage"
            << std::hex << this << std::dec
            << " Gameboard transfer has not been started yet!"
            << std::endl;
        std::cerr << out.str();
    }
    
    return retValue;
}

// Behandelt eine Spielbrett-Ende-Nachricht.
bool MessageProcessor::operate( const GameboardEndMessage& /* message */ )
{
    bool retValue = false;
    
    if ( mGameboardStarted )
    {
        if ( mDataP )
        {
            retValue = mDataP->gameboard.create( mGameboardSize,
                                                 mGameboardStrings );
        }
        mGameboardStarted = false;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) MessageProcessor::operate GameboardEndMessage"
            << std::hex << this << std::dec
            << " Gameboard transfer has not been started yet!"
            << std::endl;
        std::cerr << out.str();
    }
    
    return retValue;
}

// Behandelt eine Textnachricht.
bool MessageProcessor::operate( const TextMessage& message  )
{
    bool retValue = false;
    
    std::ostringstream out;
    out << "(EE) MessageProcessor::operate TextMessage "
        << std::hex << this << std::dec
        << "'" << message.getText() << "'."
        << " Cannot operate on text messages!"
        << std::endl;
    std::cerr << out.str();
    
    return retValue;
}
