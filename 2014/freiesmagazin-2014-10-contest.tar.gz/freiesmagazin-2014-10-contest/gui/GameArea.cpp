/**
    (C) Copyright 2010,2012,2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "GameArea.hh"

#include "Gameboard.hh"
#include "GameData.hh"
#include "Player.hh"

#include <QColor>
#include <QList>
#include <QPainter>
#include <QPoint>

#include <iostream>
#include <sstream>

// Konstruktor.
GameArea::GameArea( QWidget *parent )
: QWidget(parent), mDataP(0)
{
    // create player
    mPlayer.moveTo(-5.0,5.0);
    mPlayer.lineTo(0.0,-5.0);
    mPlayer.lineTo(5.0,5.0);
    mPlayer.lineTo(-5.0,5.0);

    // general data
    const double fontFactor = 0.6;
    mGeneralNoPen.setStyle( Qt::NoPen );
    mGeneralTextPen.setColor( palette().text().color() );
    mGeneralDarkPen.setColor( palette().dark().color() );
    mGeneralNoBrush.setStyle( Qt::NoBrush );
    mGeneralSolidBrush.setStyle( Qt::SolidPattern );
    mGeneralRect.setRect( 0.0, 0.0, 10.0, 10.0 );
    mGeneralFont = font();
    mGeneralFont.setPointSize( mGeneralFont.pointSize() * fontFactor );
    
    // set default sizes
    mSquareSize = QSizeF( 10.0, 10.0 );
    mSquareFactor = QPointF( 1.0, 1.0 );
    
    // set background color as default white
    setBackgroundRole(QPalette::Base);
    setAutoFillBackground(true);
}

// Destruktor.
GameArea::~GameArea()
{
    mDataP = 0;
}

// Initialisiert das Spielfeld.
bool GameArea::init( const GameData* dataP )
{
    bool retValue = false;
    
    if ( dataP )
    {
        mDataP = dataP;
        retValue = true;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) GameArea::init "
            << std::hex << this << std::dec
            << " GameData is 0!"
            << std::endl;
        std::cerr << out.str();
    }

    return retValue;
}

// Das Event zeichnet alle Daten neu.
void GameArea::paintEvent(QPaintEvent* /*event*/)
{
    QPainter painter(this);
    painter.setRenderHints( painter.renderHints() | QPainter::Antialiasing );

    if ( calculateSquareSizeAndFactorFromGameboard() )
    {
#ifdef DEBUG
        {
            std::ostringstream out;
            out << "(DD) GameArea::paintEvent "
                << std::hex << this << std::dec
                << std::endl;
            std::clog << out.str();
        }
#endif
        paintGameboard( painter );
        paintPlayers( painter );
    }
}

// Zeichnet Spielbrett.
void GameArea::paintGameboard( QPainter& painter )
{
#ifdef DEBUG
    {
        std::ostringstream out;
        out << "(DD) GameArea::paintGameboard "
            << std::hex << this << std::dec
            << " " << std::hex << mDataP << std::dec
            << std::endl;
        std::clog << out.str();
    }
#endif
    if ( mDataP )
    {
        const Position& size = mDataP->gameboard.getSize();

#ifdef DEBUG
        {
            std::ostringstream out;
            out << "(DD) GameArea::paintGameboard "
                << std::hex << this << std::dec
                << " " << size
                << std::endl;
            std::clog << out.str();
        }
#endif
        
        QPoint pos;

         // write numbers
        for ( unsigned int ii = 1; ii <= size.x(); ii++ )
        {
            pos.setX(ii);
            pos.setY(0);

            painter.save();
                painter.translate( pos.x()*mSquareSize.width(),
                                   pos.y()*mSquareSize.height() );
                painter.scale( mSquareFactor.x(), mSquareFactor.y() );

                painter.setFont( mGeneralFont );
                painter.setPen( mGeneralTextPen );
                painter.setBrush( mGeneralNoBrush );
                painter.drawText( mGeneralRect, Qt::AlignCenter,
                                  QString::number( ii ) );
            painter.restore();
        }

        for ( unsigned int jj = 1; jj <= size.y(); jj++ )
        {
            pos.setX(0);
            pos.setY(jj);

            painter.save();
                painter.translate( pos.x()*mSquareSize.width(),
                                   pos.y()*mSquareSize.height() );
                painter.scale( mSquareFactor.x(), mSquareFactor.y() );

                painter.setFont( mGeneralFont );
                painter.setPen( mGeneralTextPen );
                painter.setBrush( mGeneralNoBrush );
                painter.drawText( mGeneralRect, Qt::AlignCenter,
                                  QString::number( jj ) );
            painter.restore();
        }

        painter.save();
        painter.translate( mSquareSize.width(), mSquareSize.height() );

        for ( unsigned int ii = 1; ii <= size.x(); ii++ )
        {
            for ( unsigned int jj = 1; jj <= size.y(); jj++ )
            {
                // create position
                Position pos(ii,jj);

                // paint single field
                paintField( painter, pos );
            }
        }

        painter.restore();

        painter.setPen( mGeneralDarkPen );
        painter.setBrush( mGeneralNoBrush );
        painter.drawRect( mAreaRect );
    }
}

// Zeichnet ein einzelnes Feld des Spielbretts.
void GameArea::paintField( QPainter& painter, const Position& pos )
{
    if ( mDataP && mDataP->gameboard.isValidPos( pos ) )
    {
        painter.save();
            painter.translate( (pos.x()-1)*mSquareSize.width(),
                               (pos.y()-1)*mSquareSize.height() );
            painter.scale( mSquareFactor.x(), mSquareFactor.y() );
            painter.setPen( mGeneralNoPen );

            unsigned int id = 0;
            if ( mDataP->gameboard.isOccupied( pos, id ) && mDataP->players.size() > 0 )
            {
                if ( id > 0 )
                {
                    mVarPlayerColor.setHsv((id-1)*360/mDataP->players.size(),255,255);
                }
                else
                {
                    mVarPlayerColor.setRgb(0,0,0);
                }
                mGeneralSolidBrush.setColor( mVarPlayerColor );
            }
            else
            {
                mGeneralSolidBrush.setColor( QColor(255,255,255) );
            }
            
            painter.setBrush( mGeneralSolidBrush );
            painter.drawRect( mGeneralRect );
        painter.restore();
    }
}

// Zeichnet den Spieler.
void GameArea::paintPlayers( QPainter& painter )
{
    if ( mDataP )
    {
        for ( unsigned int ii = 0; ii < mDataP->players.size(); ii++ )
        {
            painter.save();
                painter.translate( 1.5*mSquareSize.width(),
                                   1.5*mSquareSize.height() );

                const Position& pos = mDataP->players[ii].pos;
                const Direction dir = mDataP->players[ii].dir;

                painter.save();
                    painter.translate( (pos.x()-1)*mSquareSize.width(),
                                       (pos.y()-1)*mSquareSize.height() );
                    painter.scale( mSquareFactor.x(), mSquareFactor.y() );

                    painter.save();
                        switch ( dir )
                        {
                            case EAST:
                                painter.rotate(90);
                                break;
                            case SOUTH:
                                painter.rotate(180);
                                break;
                            case WEST:
                                painter.rotate(-90);
                                break;
                            case NORTH:
                            default:
                                break;
                        }

                        painter.setPen( mGeneralDarkPen );
                        mVarPlayerColor.setHsv(ii*360/mDataP->players.size(),255,255);
                        mGeneralSolidBrush.setColor( mVarPlayerColor );
                        painter.setBrush( mGeneralSolidBrush );
                        painter.drawPath( mPlayer );
                    painter.restore();
                painter.restore();
            
            painter.restore();
        }
    }
}

// Berechne Anzeigegroesse fuer das Spielbrett.
bool GameArea::calculateSquareSizeAndFactorFromGameboard()
{
    bool ok = false;

    if ( mDataP )
    {
        // get width and height of map
        const Position& size = mDataP->gameboard.getSize();

        if ( size.x() > 0 && size.y() > 0 &&
             width() > 0 && height() > 0 )
        {
            // if one of these values is 0 we would not see anything

            // Depending on the current dimension of the widget
            // we will calculate the least fitting square for the map.
            double numW = width() * 1.0 / (size.x()+1);
            double numH = height() * 1.0 / (size.y()+1);

            if ( numW < numH )
            {
                // the width is the limiting element
                numH = numW;
            }
            else
            {
                // the height is the limiting element
                numW = numH;
            }

            mSquareSize.setWidth( numW );
            mSquareSize.setHeight( numH );
            mSquareFactor.setX( numW / 10.0 );
            mSquareFactor.setY( numH / 10.0 );

            // set game area rectangle
            mAreaRect.setRect( mSquareSize.width(), mSquareSize.height(),
                               ((size.x())*numW)-1, ((size.y())*numH)-1 );

            ok = true;
        }
    }

    return ok;
}
