/**
    (C) Copyright 2012,2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "Strategy.hh"

#include "EndMessage.hh"
#include "GameboardEndMessage.hh"
#include "GameboardLineMessage.hh"
#include "GameboardStartMessage.hh"
#include "PlayerMessage.hh"
#include "PlayerOutMessage.hh"
#include "PlayerSetMessage.hh"
#include "StartMessage.hh"
#include "TextMessage.hh"

#include <iostream>
#include <sstream>

// Konstruktor.
Strategy::Strategy()
  : mData(), mIsFinished(false), mGameboardStarted(false)
{ }

// Destruktor.
Strategy::~Strategy()
{ }

// Werte zuruecksetzen.
void Strategy::reset()
{
}
    
// Behandelt eine Start-Nachricht.
bool Strategy::operate( const StartMessage& message )
{
    mData.numRound = message.getNumRound();

    // Hier muss nun die Berechnung des Befehls, der an
    // den Server gesendet werden sollen, starten.
    return calcCommand();
}

// Behandelt eine Ende-Nachricht.
bool Strategy::operate( const EndMessage& /* message */ )
{
    mIsFinished = true;
    return true;
}

// Behandelt eine Spieler-Daten-Nachricht.
bool Strategy::operate( const PlayerMessage& message )
{
    bool retValue = false;
    
    if ( mData.playerNo > 0 )
    {
        const unsigned int playerNo = message.getPlayerNo();
        if ( playerNo > 0 ) 
        {
            const Position& pos = message.getPosition();
            const Direction dir = message.getDirection();

            if ( playerNo == mData.playerNo )
            {
                mData.position = pos;
                mData.direction = dir;
                retValue = true;
            }
            else
            {
                // Speichere den Wert auch fuer die Gegner.
                retValue = true;
            }
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Strategy::operate PlayerMessage"
                << std::hex << this << std::dec
                << " Player number is not set!"
                << std::endl;
            std::cerr << out.str();
            retValue = false;
        }        
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate PlayerMessage"
            << std::hex << this << std::dec
            << " Own player number is not set yet!"
            << std::endl;
        std::cerr << out.str();
        retValue = false;
    }
    
    return retValue;
}

// Behandelt eine Spieler-Todes-Nachricht.
bool Strategy::operate( const PlayerOutMessage& message )
{
    bool retValue = false;
    
    if ( mData.playerNo > 0 )
    {
        const unsigned int playerNo = message.getPlayerNo();
        if ( playerNo > 0 ) 
        {
            if ( playerNo == mData.playerNo )
            {
                // Man selbst ist ausgeschieden ...
                retValue = true;
            }
            else
            {
                // Speichere den Wert auch fuer die Gegner.
                retValue = true;
            }
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Strategy::operate PlayerOutMessage"
                << std::hex << this << std::dec
                << " Player number is not set!"
                << std::endl;
            std::cerr << out.str();
            retValue = false;
        }        
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate PlayerOutMessage"
            << std::hex << this << std::dec
            << " Own player number is not set yet!"
            << std::endl;
        std::cerr << out.str();
        retValue = false;
    }
    
    return retValue;
}

// Behandelt eine Spieler-Setzen-Nachricht.
bool Strategy::operate( const PlayerSetMessage& message )
{
    bool retValue = false;
    
    if ( 0 == mData.playerNo )
    {
        const unsigned int playerNo = message.getPlayerNo();
        if ( playerNo > 0 ) 
        {
            mData.playerNo = playerNo;
            retValue = true;
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Strategy::operate PlayerSetMessage"
                << std::hex << this << std::dec
                << " Player number is not set!"
                << std::endl;
            std::cerr << out.str();
            retValue = false;
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate PlayerSetMessage"
            << std::hex << this << std::dec
            << " Player number is set a second time!"
            << std::endl;
        std::cerr << out.str();
        retValue = false;
    }
    
    return retValue;
}

// Behandelt eine Spielbrett-Start-Nachricht.
bool Strategy::operate( const GameboardStartMessage& message )
{
    mGameboardStarted = true;
    return true;
}

// Behandelt eine Spielbrett-Zeile-Nachricht.
bool Strategy::operate( const GameboardLineMessage& /* message */ )
{
    bool retValue = false;

    if ( mGameboardStarted )
    {
        // Zeile interpretieren ...
        retValue = true;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Strategy::operate GameboardLineMessage"
            << std::hex << this << std::dec
            << " Gameboard transfer has not been started yet!"
            << std::endl;
        std::cerr << out.str();
        retValue = false;
    }
    
    return retValue;
}

// Behandelt eine Spielbrett-Ende-Nachricht.
bool Strategy::operate( const GameboardEndMessage& message )
{
    mGameboardStarted = false;
    return true;
}

// Behandelt eine Textnachricht.
bool Strategy::operate( const TextMessage& message  )
{
    std::ostringstream out;
    out << "(EE) " << "Strategy::operate TextMessage "
        << std::hex << this << std::dec
        << "'" << message.getText() << "'."
        << " Cannot operate on text messages!"
        << std::endl;
    std::cerr << out.str();
    
    return false;
}

// Fragt ab, ob Kommandos zur Verfuegung stehen.
bool Strategy::isCommandAvailable( std::string& cmd )
{
    bool isAvail = false;

    cmd.clear();
    if ( !mCommand.empty() )
    {
        // Nur, wenn wir ein Kommando haben, wird dieses
        // uebermittelt.
        cmd = mCommand;
        isAvail = true;

        // Nach dem Kopieren sollte man das Kommando unbedingt
        // loeschen, damit bei der naechsten Abfrage nicht aus
        // Versehen noch ein Kommando ansteht.
        mCommand.clear();
    }

    return isAvail;
}

// Gibt zurueck, ob das Spiel zu Ende sein soll.
bool Strategy::isEnd() const
{
    return mIsFinished;
}

// Berechne die drei Aktionen, die spaeter ausgegeben werden sollen.
bool Strategy::calcCommand()
{
    // Dummy-maessig setzen wir das Kommando auf
    // "AHEAD", wodurch wir immer vorwaerts gehen.
    mCommand = "AHEAD";

    // Bei einer echten Strategy findet hier natuerlich eine ganz
    // komplizierte Berechnung statt ...

    return true;
}
