/**
    (C) Copyright 2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef PLAYERMESSAGE_HH
#define PLAYERMESSAGE_HH

#include "Direction.hh"
#include "MessageIF.hh"
#include "MessageId.hh"
#include "Position.hh"

#include <string>

// Vorwaertsdeklarationen.
class MessageOperatorIF;

/// Spieler-Daten-Nachricht.
/**
 * Die Nachricht enthaelt die Daten ueber Spieler, Position
 * und Blickrichtung.
 */
class PlayerMessage : public MessageIF
{
  public:
    /// Konstruktor.
    PlayerMessage( const unsigned int num,
                   const Position& pos,
                   const std::string& dirStr );
  
    /// Destruktor.
    virtual ~PlayerMessage();

    /// Gibt die Id der Nachricht zurueck.
    virtual MessageId getId() const;

    /// Operiert auf einem Kontext.
    /**
     * @param oper Operator, auf dem operiert werden soll.
     * @return true, wenn die Operation angewendet werden konnte.
     */
    virtual bool operate( MessageOperatorIF& oper ) const;

    /// Gibt die Spielernummer zurueck.
    unsigned int getPlayerNo() const;

    /// Gibt Spielerposition zurueck.
    const Position& getPosition() const;

    /// Gibt die Blickrichtung zurueck.
    Direction getDirection() const;

  private:
    /// Spielernummer
    unsigned int mPlayerNo;

    /// Position des Spielers
    Position mPosition;

    /// Blickrichtung des Spielers
    Direction mDirection;
};

// INLINE ///////////////////////////////////////////////////////////

// Gibt die Spielernummer zurueck.
inline
unsigned int PlayerMessage::getPlayerNo() const
{
    return mPlayerNo;
}

// Gibt Spielerposition zurueck.
inline
const Position& PlayerMessage::getPosition() const
{
    return mPosition;
}

// Gibt die Blickrichtung zurueck.
inline
Direction PlayerMessage::getDirection() const
{
    return mDirection;
}

#endif
