/**
    (C) Copyright 2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef BASECOMMAND_HH
#define BASECOMMAND_HH

#include "CommandIF.hh"

/// Basis-Kommando mit dem Spieler-Index.
class BaseCommand : public CommandIF
{
  public:
    /// Konstruktor.
    BaseCommand();

    /// Destructor.
    virtual ~BaseCommand();
    
    /**
     * Setzt den Spieler, der das Kommando ausfuehrt.
     */
    virtual void setPlayer( unsigned int index );
    
  protected:
    /**
     * Index des Spielers, der das Kommando ausfuehrt.
     */
    unsigned int mPlayerIndex;
};

#endif // COMMANDLEFT_HH
