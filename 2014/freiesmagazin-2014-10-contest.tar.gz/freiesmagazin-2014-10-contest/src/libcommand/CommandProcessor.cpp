/**
    (C) Copyright 2012,2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "CommandProcessor.hh"
#include "CommandInterpreter.hh"

#include <iostream>
#include <sstream>

// Konstruktor.
CommandProcessor::CommandProcessor()
{ }

// Destructor.
CommandProcessor::~CommandProcessor()
{ }

// Wende ein Kommando auf das Spiel an. 
bool CommandProcessor::processCommand( const unsigned int index,
                                       const std::string& commandStr,
                                       CommandContextIF& context ) const
{
    bool retValue = false;

    CommandIF* commandP = CommandInterpreter::interpret( commandStr );
    commandP->setPlayer( index );

    if ( commandP )
    {
        // Wende das Kommando auf das Spiel an.
        retValue = commandP->operate(context);
    }
    else
    {
        std::ostringstream out;
        out << "(EE) CommandProcessor::processSingleCommand "
            << std::hex << this << std::dec
            << " Pointer to command "
            << commandStr
            << " is 0."
            << std::endl;
        std::cerr << out.str();
        retValue = false;
    }

    return retValue;
}
