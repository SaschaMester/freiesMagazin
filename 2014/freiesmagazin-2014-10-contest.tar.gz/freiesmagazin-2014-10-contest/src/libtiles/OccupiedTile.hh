/**
    (C) Copyright 2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef OCCUPIEDTILE_HH
#define OCCUPIEDTILE_HH

#include "BaseTile.hh"

// Vorwartsdeklaration.
class TileContextIF;

/// Ueberflutetes Feld.
class OccupiedTile : public BaseTile
{
  public:
    /// Konstruktor.
    OccupiedTile( TileContextIF * contextP );

    /// Kopiert das Feld.
    /**
     * @return Kopie des Feldes.
     */
    virtual TileIF* copy( TileContextIF * contextP ) const;

    /// Besetzt ein Feld.
    virtual bool occupy( const unsigned int id );

    /// Prueft, ob das Feld besetzt ist.
    virtual bool isOccupied( unsigned int& occupyId ) const;

    /// Gibt Zeichen zur Ausgabe des Feldes zurueck.
    virtual char print() const; 

  private: 
    /// Id des Spielers, der ein Feld besetzt haelt (startet bei 1).
    unsigned int mId;
};

#endif
