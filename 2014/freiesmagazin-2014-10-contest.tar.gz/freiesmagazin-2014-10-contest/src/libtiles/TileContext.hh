/**
    (C) Copyright 2012 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef TILECONTEXT_HH
#define TILECONTEXT_HH

#include "TileContextIF.hh"
#include "TileType.hh"

// Vorwartsdeklarationen
class TileIF;

/// Der Feld-Kontext.
/**
 * Der Feld-Kontext enthaelt ein einfaches Feld
 * und bietet Methoden an, dass die Felder sich
 * untereinander aendern koennen. Damit wird das
 * State-Pattern umgesetzt.
 * Daneben erbt der Kontext die Methoden des
 * Feldes.
 */
class TileContext : public TileContextIF
{
  public:
    /// Konstruktor.
    TileContext();

    /// Kopierkonstruktor.
    TileContext( const TileContext& context );

    /// Zuweisungsoperator.
    TileContext& operator=( const TileContext& context );

    /// Destruktor.
    virtual ~TileContext();

    /// Kopiert den Kontext.
    /**
     * @return Kopie des Kontextes.
     */
    virtual TileContextIF* copy( TileContextIF * contextP ) const;

    /// Setzt ein neues Feld.
    /**
     * @param tileP Das neu zu setzende Feld (darf nicht 0 sein)
     * @return true, wenn das neue Feld gesetzt werden konnte
     */
    virtual bool setTile( TileIF * tileP );

    /// Liefert anhand des Typs ein neues Feld zurueck.
    /**
     * Der Rufer der Methode uebernimmt die Verantwortung ueber
     * das Feld und muss es auch enstprechend destruieren.
     * @param type Der Typ des zu erstellenden Feldes.
     * @return Ein neues Feld, passend zum Typ, oder 0, falls
     * der Typ unbekannt ist.
     */
    virtual TileIF * createNewTile( const TileType type );

    /// Liefert anhand des Typs ein neues Feld zurueck.
    /**
     * Der Rufer der Methode uebernimmt die Verantwortung ueber
     * das Feld und muss es auch enstprechend destruieren.
     * @param type Der Typ des zu erstellenden Feldes.
     * @return Ein neues Feld, passend zum Typ, oder 0, falls
     * der Typ unbekannt ist.
     */
    virtual TileIF * createNewTile( const char type );
    
    /// Besetzt ein Feld.
    virtual bool occupy( const unsigned int id );

    /// Prueft, ob das Feld besetzt ist.
    virtual bool isOccupied( unsigned int& occupyId ) const;

    /// Gibt Zeichen zur Ausgabe des Feldes zurueck.
    virtual char print() const;

  private:
    /// Das aktuell gesetzte Feld.
    TileIF * mTileP;

    /// Das zuletzt gesetzte Feld.
    /**
     * Dies ist notwendig, da das State-Pattern es erlaubt,
     * dass mit getTile() eine Methode gerufen wird, die wiederum
     * setTile() ruft und somit das aktuelle Feld ueberschreibt.
     * Wurde man das aktuelle Feld sofort destruieren, haette dies
     * merkwuerdige Auswirkungen.
     */
    TileIF * mOldTileP;
};

#endif // TILECONTEXT_HH
