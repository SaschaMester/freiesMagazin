/**
    (C) Copyright 2012 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "TileContext.hh"
#include "TileFactory.hh"
#include "TileIF.hh"

#include <iostream>
#include <sstream>

// Konstruktor.
TileContext::TileContext()
  : mTileP(0), mOldTileP(0)
{
}

// Destruktor.
TileContext::~TileContext()
{
    delete mTileP;
    delete mOldTileP;
}

// Kopierkonstruktor.
TileContext::TileContext( const TileContext& context )
  : mTileP(0), mOldTileP(0)
{
    operator=(context);
}

// Zuweisungsoperator.
TileContext& TileContext::operator=( const TileContext& context )
{
    if ( this != &context )
    {
        // Altes Feld loeschen, da es nicht mehr benoetigt wird,
        // und dafuer das aktuelle sichern.
        delete mOldTileP;
        mOldTileP = mTileP;

        if ( context.mTileP )
        {
            mTileP = context.mTileP->copy( this );
        }
        else
        {
            std::ostringstream out;
            out << "(EE) TileContext::operator= "
                << std::hex << this << std::dec
                << " Field is 0!"
                << std::endl;
            std::cerr << out.str();
            
            mTileP = 0;
        }
    }
    return *this;
}

// Kopiert den Kontext.
TileContextIF* TileContext::copy( TileContextIF * contextP ) const
{
    return new TileContext( *this );
}

// Setzt ein neues Feld.
bool TileContext::setTile( TileIF * tileP )
{
    bool valid = false;
    
    if ( 0 == tileP )
    {
        std::ostringstream out;
        out << "(EE) TileContext::setTile "
            << std::hex << this << std::dec
            << " Field is 0."
            << std::endl;
        std::cerr << out.str();
        valid = false;
    }
    else
    {
        // Altes Feld loeschen, da es nicht mehr benoetigt wird,
        // und dafuer das aktuelle sichern.
        delete mOldTileP;
        mOldTileP = mTileP;

        // Neues Feld setzen.
        mTileP = tileP;
        valid = true;
    }

    return valid;
}

// Liefert anhand des Typs ein neues Feld zurueck.
TileIF * TileContext::createNewTile( const TileType type )
{
    return TileFactory::create( type, this );
}

// Liefert anhand des Typs ein neues Feld zurueck.
TileIF * TileContext::createNewTile( const char type )
{
    return TileFactory::create( type, this );
}

// Besetzt ein Feld.
bool TileContext::occupy( const unsigned int id )
{
    if ( 0 != mTileP )
    {
        return mTileP->occupy( id );
    }
    return false;
}

// Prueft, ob das Feld besetzt ist.
bool TileContext::isOccupied( unsigned int& occupyId ) const
{
    if ( 0 != mTileP )
    {
        return mTileP->isOccupied(occupyId);
    }
    return false;
}

// Gibt Zeichen zur Ausgabe des Feldes zurueck.
char TileContext::print() const
{
    if ( 0 != mTileP )
    {
        return mTileP->print();
    }
    return ' ';
}
