/**
    (C) Copyright 2012,2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "TileFactory.hh"
#include "EmptyTile.hh"
#include "OccupiedTile.hh"

#include <iostream>
#include <sstream>

// Erstellt ein neues Feld.
TileIF * TileFactory::create( const TileType type, TileContextIF * contextP )
{
    TileIF * newTileP = 0;

    switch ( type )
    {
        case TILETYPE_EMPTY:
            newTileP = new EmptyTile( contextP );
            break;
        case TILETYPE_OCCUPIED:
            newTileP = new OccupiedTile( contextP );
            break;
        default:
            std::ostringstream out;
            out << "(EE) TileFactory::create "
                << " Unknown field type '"
                << type
                << "'."
                << std::endl;
            std::cerr << out.str();
            break;
    }

    if ( 0 == newTileP )
    {
        std::ostringstream out;
        out << "(EE) TileFactory::create "
            << " Field is 0 for type '"
            << type
            << "'."
            << std::endl;
        std::cerr << out.str();
    }

    return newTileP;
}

// Erstellt ein neues Feld.
TileIF * TileFactory::create( const char type, TileContextIF * contextP )
{
    TileIF * newTileP = 0;
    
    switch ( type )
    {
        case '.':
            newTileP = create( TILETYPE_EMPTY, contextP );
            break;
        case '#':
            newTileP = create( TILETYPE_OCCUPIED, contextP );
            break;
        default:
            std::ostringstream out;
            out << "(EE) TileFactory::create "
                << " Unknown field type '"
                << type
                << "'."
                << std::endl;
            std::cerr << out.str();
            break;
    }

    if ( 0 == newTileP )
    {
        std::ostringstream out;
        out << "(EE) TileFactory::create "
            << " Field is 0 for type '"
            << type
            << "'."
            << std::endl;
        std::cerr << out.str();
    }

    return newTileP;    
}
