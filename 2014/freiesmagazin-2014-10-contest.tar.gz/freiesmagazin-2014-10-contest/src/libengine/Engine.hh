/**
    (C) Copyright 2011,2012,2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef ENGINE_HH
#define ENGINE_HH

#include "CommandProcessor.hh"
#include "EngineConfig.hh"

#include <string>
#include <vector>

/// Vorwaertsdeklaration
class GameIF;
class ServerIF;

/// Spieleengine.
/**
 * Die Spieleengine steuert den gesamten Spielablauf,
 * erstellt und initialisiert alle benoetigten Objekte
 * und sendet und empfaengt Daten an und vom Client.
 */
class Engine
{
  public:
    /// Konstruktor.
    /**
     * @param game Referenz auf die Spieldaten.
     * @param server Referenz auf Server, der die Kommunikation uebernimmt.
     */
    Engine( GameIF& game, ServerIF& server, const EngineConfig& config  );

    /// Destructor.
    ~Engine();

    /// Gibt Anzahl gespielter Runden zurueck.
    unsigned int getNumRounds() const;

    /// Startet ein Spiel.
    /**
     * Die startet das Spiel und kehrt erst zurueck
     * wenn der Spieler untergegangen ist.
     * @return true, falls das Spiel korrekt beendet wurde.
     */
    bool startGame();

  private:
    /// Starte eine einzelne Runde.
    /**
     * @return true, falls alles okay ist.
     */
    bool startRound();
    
    /**
     * Prueft, welche Spieler neu ausgeschieden sind
     * und sendet dies an die Clients.
     */
    bool checkForDeadPlayers();

    /**
     * Starte eine Runde fuer einen Client.
     * 
     * @param index Index des Clients, der spielen soll.
     * @return true, falls alles okay ist.
     */
    bool startRoundClient( const unsigned int index );

    /// Sende Spielbrett an Client.
    /**
     * @return true, falls alles okay ist.
     */
    bool sendGameboard();
    
    /**
     * Sende eigene Spielenummer an Client.
     * @return true, falls alles okay ist.
     */
    bool sendPlayerNumbers();

    /// Sende Start-Kommando an Client.
    /**
     * @param index Index des Clients, der spielen soll.
     * @return true, falls alles okay ist.
     */
    bool sendStartCommand( const unsigned int index );

    /// Sende alle Spielerinformationen an alle aktiven Spieler.
    /**
     * @return true, falls alles okay ist.
     */
    bool sendActivePlayerDataToAllPlayers();

    /// Sende Daten aller aktiven Spieler an einen Client.
    /**
     * @param index Index des Clients, der informiert werden soll.
     * @return true, falls alles okay ist.
     */
    bool sendActivePlayerData( const unsigned int index );

    /// Empfange Antwort mit dem Befehl der Clients.
    /**
     * @param index Index des Clients, auf dessen Antwort man wartet.
     * @param commandStr Empfangenes Kommando.
     * @return true, falls alles okay ist.
     */
    bool receiveClientCommand( const unsigned index, std::string& commandStr );

    /// Sende Nachricht an alle Clients.
    bool sendClients( const std::string& message );

    /// Sende Nachricht an einen Client.
    bool sendClient( const size_t index, const std::string& message );

    /// Schreibe Log-Nachricht (falls aktiv).
    void writeLog( const std::string& message ) const;
    
    /// Schreibe die aktuellen Spielerdaten ins Log
    void writePlayerDataToLog() const;

  private:

    /// Spieldaten fuer das Spiel (bereits initialisiert).
    /**
     * Es wird davon ausgegangen, dass die Spieldabei bereits
     * initialisiert wurden.
     */
    GameIF& mGameR;

    /// Server, der die Kommunikation uebernimmt.
    /**
     * Der Server muss als Referenz von aussen uebergeben werden.
     */
    ServerIF& mServerR;

    /// Konfiguration fuer die Engine.
    EngineConfig mConfig;
    
    /// Anzahl des bisher gespielten Runden.
    unsigned int mRounds;
    
    /// Commando-Prozessor.
    CommandProcessor mCommandProc;
};

#endif // ENGINE_HH
