/**
    (C) Copyright 2011,2012,2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef PLAYERDATA_HH
#define PLAYERDATA_HH

#include "Position.hh"
#include "Direction.hh"

/**
 * Spielerdaten fuer einen Spieler
 * 
 * Das beinhaltet die Position auf dem Spielbrett,
 * die Blickrichtung und die Anzahl der gespielten Runden.
 */
struct PlayerData
{
    /**
     * Konstruktor.
     */
    PlayerData();
    
    /**
     * Aktuelle Position des Spielers.
     */
    Position pos;
    
    /**
     * Richtung, in die der Spieler schaut.
     */
    Direction dir;
    
    /**
     * Anzahl gespielter Runden.
     */
    unsigned int numRounds;
    
    /**
     * Flag, ob der Spieler bereits ausgeschieden ist.
     */
    bool isDead;

    /**
     * Flag, ob der Spieler gegen etwas gefahren ist.
     */
    bool isCrashed;
};

#endif
