/**
    (C) Copyright 2012,2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "Game.hh"

#include <iostream>
#include <sstream>
#include <fstream>

// Konstruktor.
Game::Game()
: mGameBoard(), mPlayers()
{
}

// Destruktor.
Game::~Game()
{}

// Initialisiert das Spiel.
bool Game::init( const std::string& filename, const unsigned int numPlayers )
{
    bool init = false;
    
    if ( 2 == numPlayers )
    {
        mPlayers.resize(numPlayers);
        
        if ( mGameBoard.load( filename ) )
        {
            // Startpositionen auslesen
            if ( readPlayStartPosition( filename ) )
            {
                // Start-Positionen pruefen bzw. neu berechnen,
                // falls keine gesetzt waren.
                if ( setPlayerStartPosition() )
                {
                    init = true;
                }
            }
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Game::init "
            << std::hex << this << std::dec
            << " Number of players "
            << numPlayers
            << " must be 2."
            << std::endl;
        std::cerr << out.str();
    }
    return init;
}

// Liest die Spielerstartposition aus Datei aus.
bool Game::readPlayStartPosition( const std::string& filename )
{
    bool retValue = false;

    // Datei oeffnen
    std::ifstream infile;

    infile.open( filename.c_str() );
    if ( infile.is_open() )
    {
        char charLine[1000];
        std::string line;

        retValue = true;

        while( infile.good() )
        {
            infile.getline(charLine, 1000);
            line = charLine;

            if ( line.compare(0, 4, "POS ") == 0 )
            {
                if ( !extractPlayerPosition( line.substr(4) ) )
                {
                    retValue = false;
                    break;
                }
            }
            else
            {
                // Alles andere ignorieren.
            }
        }

        // Datei schließen.
        infile.close();
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Game::readPlayStartPosition "
            << std::hex << this << std::dec
            << " Could not open file "
            << filename
            << "."
            << std::endl;
        std::cerr << out.str();
    }
    
    return retValue;
}

// Extrahiert Spielerposition aus einer Zeile.
bool Game::extractPlayerPosition( const std::string& param )
{
#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) Game::extractPlayerPosition "
        << std::hex << this << std::dec
        << " " << param
        << std::endl;
    std::cerr << out.str();
#endif

    // Die Syntax ist '1 2,3 N'
    bool retValue = false;

    // Spielernummer, Position und Blickrichtung
    unsigned int playerNo = 0;
    unsigned int x = 0, y = 0;
    std::string dirStr;

    size_t pos = param.find(' ');

    if ( ( std::string::npos != pos ) &&
         ( 0 != pos ) &&
         ( param.length()-1 != pos ) )
    {
        // Der erste Wert ist die Spielernummer
        std::istringstream in( param.substr( 0, pos ) );
        in >> playerNo;

        std::string cmdString = param.substr( pos+1 );

        pos = cmdString.find(' ');
        
        if ( ( std::string::npos != pos ) &&
             ( 0 != pos ) &&
             ( cmdString.length()-1 != pos ) )
        {
            std::string posStr = cmdString.substr( 0, pos );
            dirStr = cmdString.substr( pos+1 );
            
            pos = posStr.find(',');

            if ( ( std::string::npos != pos ) &&
                 ( 0 != pos ) &&
                 ( posStr.length()-1 != pos ) )
            {
                // Danach folgen x- und y-Position eines Feldes.
                std::istringstream in2( posStr.substr( 0, pos ) );
                in2 >> x;

                std::istringstream in3( posStr.substr( pos+1 ) );
                in3 >> y;
            }
            else
            {
                std::ostringstream out;
                out << "(EE) Game::extractPlayerPosition "
                    << std::hex << this << std::dec
                    << " Cannot interpret line '"
                    << posStr
                    << "'. Should be in format '3,5'."
                    << std::endl;
                std::cerr << out.str();
            }
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Game::extractPlayerPosition "
                << std::hex << this << std::dec
                << " Cannot interpret line '"
                << cmdString
                << "'. Should be in format '3,5 N'."
                << std::endl;
            std::cerr << out.str();
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Game::extractPlayerPosition "
            << std::hex << this << std::dec
            << " Cannot interpret line '"
            << param
            << "'. Should be in format '1 2,3 N'."
            << std::endl;
        std::cerr << out.str();
    }
    
    if ( playerNo > 0 && playerNo <= mPlayers.size() )
    {
        if ( ( x > 0 ) && ( y > 0 ) )
        {
            if ( Player::isKnownDirection(dirStr) )
            {
#ifdef DEBUG
                std::ostringstream out;
                out << "(DD) Game::extractPlayerPosition "
                    << std::hex << this << std::dec
                    << " Set player " << playerNo
                    << " position to " << Position(x,y)
                    << " direction " << dirStr
                    << std::endl;
                std::cerr << out.str();
#endif
                mPlayers[playerNo-1].setPosition( Position(x,y) );
                mPlayers[playerNo-1].setDirection(dirStr);
                
                // msgPR = new PlayerMessage( playerNo, Position(x, y), dirStr );
                retValue = true;
            }
            else
            {
                std::ostringstream out;
                out << "(EE) Game::extractPlayerPosition "
                    << std::hex << this << std::dec
                    << " Direction '" << dirStr
                    << "' unknown."
                    << std::endl;
                std::cerr << out.str();
            }
        }
        else
        {
            std::ostringstream out;
            out << "(EE) Game::extractPlayerPosition "
                << std::hex << this << std::dec
                << " Position (" << x << "," << y << ")"
                << " is 0."
                << std::endl;
            std::cerr << out.str();
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Game::extractPlayerPosition "
            << std::hex << this << std::dec
            << " Player number " << playerNo
            << " is 0 or greater than number of players: " << mPlayers.size()
            << std::endl;
        std::cerr << out.str();
    }    

    return retValue;
}

// Gibt aktuelle Spielerdaten zurueck.
const PlayerData& Game::getPlayerData( const unsigned int index ) const
{
    if ( index < mPlayers.size() )
    {
        return mPlayers[index].getData();
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Game::getPlayerData "
            << std::hex << this << std::dec
            << " Index " << index
            << " out of range " << mPlayers.size()
            << "."
            << std::endl;
        std::cerr << out.str();

        // HACK
        return mPlayers[0].getData();
    }
}

// Setzt die aktuelle gespielte Runde.
void Game::setRound( const unsigned int numRounds )
{
    for ( unsigned int ii = 0; ii < mPlayers.size(); ii++ )
    {
        if ( !mPlayers[ii].getData().isDead )
        {
            mPlayers[ii].setRound( numRounds );
        }
    }
}
    
// Gibt TRUE zurueck, wenn das Spiel vorbei ist.
bool Game::isGameEnd() const
{
    unsigned int numSurvivors = mPlayers.size();
    
    for ( unsigned int ii = 0; ii < mPlayers.size(); ii++ )
    {
        const PlayerData& player = mPlayers[ii].getData();
        
        if ( player.isDead )
        {
            numSurvivors--;
        }
        
#ifdef DEBUG
        std::ostringstream out;
        out << "(DD) Game::isGameEnd "
            << std::hex << this << std::dec
            << " Pos: " << player.pos
            << " Dir: " << player.dir
            << " Dead: " << player.isDead
            << " Rounds: " << player.numRounds
            << std::endl;
        std::clog << out.str();
#endif
    }

#ifdef DEBUG
    std::ostringstream out;
    out << "(DD) Game::isGameEnd "
        << std::hex << this << std::dec
        << " Survivors: " << numSurvivors
        << " End: " << ( 0 == numSurvivors )
        << std::endl;
        std::clog << out.str();
#endif

    // Bei mindestens einem Ueberlebenden geht das Spiel weiter.
    return ( 0 == numSurvivors );
}

// Prueft, ob ein Spieler die Runde nicht ueberlebt hat.
bool Game::checkForDeadPlayer( const unsigned int index )
{
    bool isDeceased = false;
    
    if ( index < mPlayers.size() )
    {
        const PlayerData& player = mPlayers[index].getData();
        
        if ( !player.isDead )
        {
            if ( player.isCrashed )
            {
                // Spieler waere im letzten Zug gegen eine Wand gefahren.
                isDeceased = true;
            }
            
            for ( unsigned int jj = 0; jj < mPlayers.size(); jj++ )
            {
                if ( index != jj )
                {
#if DEBUG
                    std::ostringstream out;
                    out << "(DD) Game::checkForDeadPlayer SAMEFIELD "
                        << std::hex << this << std::dec
                        << " P" << index+1 << ": " << player.pos << " vs. "
                        << " P" << jj+1 << ": " << mPlayers[jj].getData().pos
                        << std::endl;
                    std::cerr << out.str();
#endif
                    if ( player.pos == mPlayers[jj].getData().pos )
                    {
                        // Zwei Spieler stehen auf dem gleichen Feld.
                        isDeceased = true;
                    }
                }
            }
            
            if ( isDeceased )
            {
                mPlayers[index].setDead();
            }
        }
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Game::checkForDeadPlayer "
            << std::hex << this << std::dec
            << " Index " << index
            << " out of range " << mPlayers.size()
            << "."
            << std::endl;
        std::cerr << out.str();
    }
    
    return isDeceased;
}

// Holt die Informationen zum Spielbrett.
bool Game::getGameboardInfo( Position& size,
                             std::vector<std::string>& stringVector ) const
{
    bool retValue = false;
    
    if ( mGameBoard.getSize().isValid() )
    {
        size = mGameBoard.getSize();
        mGameBoard.print( stringVector );
        retValue = true;
    }

    return retValue;
}

// Setzt eine sinnvolle Spielerposition abhaengig vom Spielbrett.
bool Game::setPlayerStartPosition()
{
    bool posFound = false;

    if ( mPlayers.size() == 2 )
    {
        // Wir unterteilen das Spielbrett in vier Teilen horizontal und
        // zwei Teile vertikal.
        const unsigned int width = mGameBoard.getSize().x();
        const unsigned int height = mGameBoard.getSize().y();

#ifdef DEBUG
        std::ostringstream out;
        out << "(DD) Game::setPlayerStartPosition "
            << std::hex << this << std::dec
            << " Width: "  << width
            << " Height: " << height
            << std::endl;
        std::clog << out.str();        
#endif // DEBUG

        if ( width > 2 && height > 0 )
        {
            unsigned int startWidth1 = 0, startWidth2 = 0;
            unsigned int startHeight1 = 0, startHeight2 = 0;

            if ( width%2 == 0 )
            {
                const unsigned int halfWidth = width/2;
                if ( halfWidth%2 == 1 )
                {
                    startWidth1 = halfWidth/2 + 1;
                    startWidth2 = halfWidth + halfWidth/2 + 1;
                }
                else
                {
                    startWidth1 = halfWidth/2;
                    startWidth2 = halfWidth + halfWidth/2 + 1;
                }
            }
            else
            {
                const unsigned int halfWidth = width/2;
                if ( halfWidth%2 == 1 )
                {
                    startWidth1 = halfWidth/2 + 1;
                    startWidth2 = halfWidth + 1 + halfWidth/2 + 1;
                }
                else
                {
                    startWidth1 = halfWidth/2 + 1;
                    startWidth2 = halfWidth + 1 + halfWidth/2;
                }
            }

           if ( height%2 == 0 )
            {
                startHeight1 = height/2;
                startHeight2 = height/2 + 1;
            }
            else
            {
                startHeight1 = height/2 + 1;
                startHeight2 = height/2 + 1;
            }

            Position pos1( startWidth1, startHeight1 );
            Position pos2( startWidth2, startHeight2 );

#ifdef DEBUG
            std::ostringstream out;
            out << "(DD) Game::setPlayerStartPosition "
                << std::hex << this << std::dec
                << " New Position: "
                << pos1 << " " << pos2
                << std::endl;
            std::clog << out.str();        
#endif // DEBUG

            // Setze neue Startposition, wenn der Spieler keine hat. 
            if ( !mPlayers[0].getData().pos.isValid() )
            {
                mPlayers[0].setPosition(pos1);
                mPlayers[0].turnRight();
            }
            if ( !mPlayers[1].getData().pos.isValid() )
            {
                mPlayers[1].setPosition(pos2);
                mPlayers[1].turnLeft();
            }
        } // width > 2 && height > 0

        // Pruefe, ob die Positionen der Spieler valide sind.
        unsigned int dummyId = 0;
        Position pos1 = mPlayers[0].getData().pos;
        Position pos2 = mPlayers[1].getData().pos;

#ifdef DEBUG
        {
            std::ostringstream out;
            out << "(DD) Game::setPlayerStartPosition "
                 << std::hex << this << std::dec
                 << " Final Position: "
                 << pos1 << " " << pos2
                 << std::endl;
            std::clog << out.str();
        }
#endif // DEBUG

        if ( mGameBoard.getSize().isValid() &&
             mGameBoard.isValidPos( pos1 ) && mGameBoard.isValidPos( pos2 ) &&
             !mGameBoard.isOccupied( pos1, dummyId ) && !mGameBoard.isOccupied( pos2, dummyId ) &&
             !(pos1==pos2) )
        {
            posFound = true;
        }
    }

    if ( !posFound )
    {
        // Kein valides Feld gefunden oder es kam zu einem Fehler.
        std::ostringstream out;
        out << "(EE) Game::setPlayerStartPosition "
            << std::hex << this << std::dec
            << " Did not find valid start position."
            << std::endl;
        std::cerr << out.str();
    }

    return posFound;
}

// Dreht den Spieler nach links und geht ein Feld geradeaus.
bool Game::movePlayerLeft( const unsigned int index )
{
    bool retValue = false;
    if ( index < mPlayers.size() )
    {
        mPlayers[index].turnLeft();
        retValue = movePlayer(index);
    }
    return retValue;
}

// Dreht den Spieler nach rechts und geht ein Feld geradeaus.
bool Game::movePlayerRight( const unsigned int index )
{
    bool retValue = false;
    if ( index < mPlayers.size() )
    {
        mPlayers[index].turnRight();
        retValue = movePlayer(index);
    }
    return retValue;
}

// Geht ein Feld geradeaus.
bool Game::movePlayerAhead( const unsigned int index )
{
    return movePlayer(index);
}

// Bewegt den Spieler ein Feld in Blickrichtung.
bool Game::movePlayer( const unsigned int index )
{
    bool retValue = false;
    if ( index < mPlayers.size() )
    {
        const Position oldPos = mPlayers[index].getData().pos;
        const Position newPos = mPlayers[index].tryMove();
        
        // mark old position as occupied
        mGameBoard.occupy( oldPos, index+1 );
        
        if ( mGameBoard.isValidPos( newPos, true ) )
        {
            unsigned int dummyId = 0;
            if ( mGameBoard.isOccupied( newPos, dummyId ) )
            {
                std::ostringstream out;
                out << "(II) P" << index+1 
                    << " Crash Occupied Field"
                    << std::endl;
                std::clog << out.str();

                // Zielfeld ist besetzt
                mPlayers[index].markCrashed();
            }
            else
            {
                for ( unsigned int jj = 0; jj < mPlayers.size(); jj++ )
                {
                    if ( index != jj )
                    {
                        if ( newPos == mPlayers[jj].getData().pos )
                        {
                            std::ostringstream out2;
                            out2 << "(II) P" << index+1
                                 << " Crash Other Player"
                                 << std::endl;
                            std::clog << out2.str();
                            
                            // Zwei Spieler wuerden auf dem gleichen Feld stehen.
                            mPlayers[index].markCrashed();
                            
                            // Wichtig: Wir muessen den Spieler dennoch
                            // vorwaerts bewegen, weil bei der abschliessenden
                            // Pruefung am Ende der Runde der Spieler, der das
                            // Feld gerade besetzt, ebenfalls sterben muss.
                            mPlayers[index].setPosition( newPos );
                        }
                    }
                }
            }
        }
        else
        {
            std::ostringstream out3;
            out3 << "(II) P" << index+1
                 << " Crash Boundary"
                 << std::endl;
            std::clog << out3.str();

            // Spieler verlaesst das Spielbrett.
            mPlayers[index].markCrashed();
        }
        
        if ( !mPlayers[index].getData().isCrashed )
        {
            mPlayers[index].setPosition( newPos );
        }
        
        retValue = true;
    }
    
    return retValue;
}

