/**
    (C) Copyright 2011,2012,2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "Player.hh"

#include <iostream>
#include <sstream>

// Konstruktor.
Player::Player()
: mData()
{
}

// Dreht den Spieler nach links.
Direction Player::turnLeft()
{
    switch (mData.dir)
    {
        case NORTH:
            mData.dir = WEST;
            break;
        case EAST:
            mData.dir = NORTH;
            break;
        case SOUTH:
            mData.dir = EAST;
            break;
        case WEST:
            mData.dir = SOUTH;
            break;
        default:
            std::ostringstream out;
            out << "(EE) Player::turnLeft "
                << std::hex << this << std::dec
                << " Unknown direction: "
                << (int)mData.dir
                << "."
                << std::endl;
            std::cerr << out.str();
            break;
    }
    
    return mData.dir;
}

// Dreht den Spieler nach rechts.
Direction Player::turnRight()
{
    switch (mData.dir)
    {
        case NORTH:
            mData.dir = EAST;
            break;
        case EAST:
            mData.dir = SOUTH;
            break;
        case SOUTH:
            mData.dir = WEST;
            break;
        case WEST:
            mData.dir = NORTH;
            break;
        default:
            std::ostringstream out;
            out << "(EE) Player::turnRight "
                << std::hex << this << std::dec
                << " Unknown direction: "
                << (int)mData.dir
                << "."
                << std::endl;
            std::cerr << out.str();
            break;
    }
    
    return mData.dir;
}

// Versucht den Spieler in Blickrichtung zu bewegen.
Position Player::tryMove() const
{
    Position newPos;
    switch ( mData.dir )
    {
        case NORTH:
            newPos.setPosition( mData.pos.x(), mData.pos.y()-1 );
            break;
        case EAST:
            newPos.setPosition( mData.pos.x()+1, mData.pos.y() );
            break;
        case SOUTH:
            newPos.setPosition( mData.pos.x(), mData.pos.y()+1 );
            break;
        case WEST:
            newPos.setPosition( mData.pos.x()-1, mData.pos.y() );
            break;
        default:
            std::ostringstream out;
            out << "(EE) Player::tryMove "
                << std::hex << this << std::dec
                << " Unknown direction: "
                << (int)mData.dir
                << "."
                << std::endl;
            std::cerr << out.str();
            break;
    }
    return newPos;
}

// Gibt TRUE zurueck, wenn der String eine bekannte Richtung ist.
bool Player::isKnownDirection( const std::string& dirStr )
{
    return ( dirStr.compare( "N" ) == 0 ||
             dirStr.compare( "E" ) == 0  ||
             dirStr.compare( "S" ) == 0 ||
             dirStr.compare( "W" ) == 0  );
}

// Setzt eine neue Spielerichtung.
void Player::setDirection( const std::string dirStr )
{
    if ( dirStr.compare( "N" ) == 0 )
    {
        mData.dir = NORTH;
    }
    else if ( dirStr.compare( "E" ) == 0 )
    {
        mData.dir = EAST;
    }
    else if ( dirStr.compare( "S" ) == 0 )
    {
        mData.dir = SOUTH;
    }
    else if ( dirStr.compare( "W" ) == 0 )
    {
        mData.dir = WEST;
    }
    else
    {
        std::ostringstream out;
        out << "(EE) Player::setDirection "
            << std::hex << this << std::dec
            << " Unknown direction '"
            << dirStr
            << "'."
            << std::endl;
        std::cerr << out.str();
    }
}
