/**
    (C) Copyright 2011,2012,2014 Dominik Wagenfuehr

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as
    published by the Free Software Foundation; either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this program. If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef PLAYER_HH
#define PLAYER_HH

#include "PlayerData.hh"

/// Spieler.
/**
 * Dies ist die Spielerklasse fuer die Spieleengine,
 * nicht die fuer den Bot. Hier wird nur die ueberlebte
 * Runde gespeichert und die Position des Spielers
 * auf dem Spielbrett.
 */
class Player
{
  public:
    /// Konstruktor.
    /**
     * Erstellt einen neuen Spieler.
     */
    Player();

    /// Setzt eine neue Position des Spielers.
    /**
     * Es gibt keine Methode, um den Spieler zu bewegen,
     * da nicht geprueft werden kann, ob eine Bewegung
     * legal ist. Dies kann nur in Verbindung mit dem
     * Spielbrett geprueft werden.
     * @param pos Neue Position.
     */
    void setPosition( const Position& pos );
    
    /**
     * Setzt die aktuell gespielte Runde.
     */
    void setRound( const unsigned int numRounds );
    
    /**
     * Legt fest, dass der Spieler gestorben ist.
     */
    void setDead();
    
    /**
     * Markiert den Spieler als gegen etwas gefahren.
     */
    void markCrashed();

    /// Gibt Spielerdaten zurueck.
    const PlayerData& getData() const;

    /// Versucht den Spieler in Blickrichtung zu bewegen.
    Position tryMove() const;

    /// Dreht den Spieler nach links.
    Direction turnLeft();

    /// Dreht den Spieler nach rechts.
    Direction turnRight();

    /// Gibt TRUE zurueck, wenn der String eine bekannte Richtung ist.
    static bool isKnownDirection( const std::string& dirStr );

    /// Setzt eine neue Spielerichtung.
    void setDirection( const std::string dirStr );

  private:
    /**
     * Spielerdaten.
     */
    PlayerData mData;
};

// INLINE ///////////////////////////////////////////////////////////

// Setzt eine neue Position des Spielers.
inline
void Player::setPosition( const Position& pos )
{
    mData.pos = pos;
}

// Setzt die aktuell gespielte Runde.
inline
void Player::setRound( const unsigned int numRounds )
{
    mData.numRounds = numRounds;
}

// Legt fest, dass der Spieler gestorben ist.
inline
void Player::setDead()
{
    mData.isDead = true;
}

// Markiert den Spieler als gegen etwas gefahren.
inline
void Player::markCrashed()
{
    mData.isCrashed = true;
}

// Gibt Spielerdaten zurueck.
inline
const PlayerData& Player::getData() const
{
    return mData;
}

#endif // PLAYER_HH
